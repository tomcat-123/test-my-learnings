# Project notes
	This sheet contains the list of instances which has not been automated.

Sprint5 - Sprint7
``````````````
- Validation of toast messages

Sprint8
``````
- Verify if the cart number incremented when user taps on Plus button
 
- Verify if the cart number doesn't increase when user taps on Plus button where "per weight" item already in cart
 
- Verify if the cart number won't change when user taps on minus button where the more than minimum of "per weight" item is present 

- Verify if the cart number decrease when user taps on minus button where the minimum of "per each" item already in cart
 
- Verify if the cart number doesn't increase when user taps on Plus button where the "per weight" item isn't present in the cart

- Verify the user adds Max product weight with cart empty
 
- Verify the user is able to add multiple weighted products with different unit of measurements (lb/oz)
 
- Verify Tapping outside of the keyboard or textfield re-enable the rest of the screen 

- Validate enter the quantity in Browse/Category page using keyboard

- Validate a new value in the numeric field after tapping keyboard back button 

- Validate - and + buttons sit right above the top of the numeric keyboard 

- Select a Product to enable the Keyboard and disable the outside screen

- Validate the negative quantity entered in quantity field 

- Cut & Paste a special character in Details screen

- Manually enter a zero in the Details screen

- Verify 'Add' button remains same when Zero is entered 

- Verify Done button displayed above the Weight Picker wheel

- Verify other products are greyed out when done button is clicked for a subcategory 

- Verify 2 Column picker wheel displays when Add button clicked for Per Weight products 

- Validate the max quantity of items we can order is 100 when the user is entering a quantity using the keyboard

- Verify the error when maximum of the item entered 

- Verify the error when minimum of the item entered 

- Verify the position of error message 

- Verify able to update the value using keyboard by tapping the numeric field between the - and + buttons 

- Verify the screen outside of the selected product will be disabled, when the keyboard is visible

Sprint 9
```````
- Verify user is able to see the  blank white product image while the image is loading

- As a mobile Android user, I want to understand when an image may not be present for a product on a category page

- Store List Expanded State announcements

- ADD button should be disabled when the product max is reached

- As a user, I would like to see the PDP transition animate.







