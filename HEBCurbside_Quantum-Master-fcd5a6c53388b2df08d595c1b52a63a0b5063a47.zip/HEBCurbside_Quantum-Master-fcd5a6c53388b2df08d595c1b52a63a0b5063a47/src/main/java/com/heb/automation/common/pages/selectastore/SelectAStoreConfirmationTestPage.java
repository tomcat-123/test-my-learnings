package com.heb.automation.common.pages.selectastore;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SelectAStoreConfirmationTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "storeconfirm.lbl.storename")
	private QAFWebElement lblStorename;

	@FindBy(locator = "storeconfirm.lbl.storeaddress")
	private QAFWebElement lblStoreaddress;

	@FindBy(locator = "storeconfirm.lbl.storecity")
	private QAFWebElement lblStorecity;

	@FindBy(locator = "storeconfirm.lbl.pageheader")
	private QAFWebElement lblPageheader;

	@FindBy(locator = "storeconfirm.btn.okgotit")
	private QAFWebElement btnOkgotit;

	@FindBy(locator = "storeconfirm.img.storemarkerview")
	private QAFWebElement imgStoremarkerview;

	@FindBy(locator = "storeconfirm.lbl.storeconfirmdescription")
	private QAFWebElement lblStoreconfirmdescription;

	public QAFWebElement getImgStoremarkerview() {
		return imgStoremarkerview;
	}

	public QAFWebElement getLblStoreconfirmdescription() {
		return lblStoreconfirmdescription;
	}

	public QAFWebElement getBtnOkgotit() {
		return btnOkgotit;
	}

	public QAFWebElement getLblPageheader() {
		return lblPageheader;
	}

	public QAFWebElement getLblStorecity() {
		return lblStorecity;
	}

	public QAFWebElement getLblStoreaddress() {
		return lblStoreaddress;
	}

	public QAFWebElement getLblStorename() {
		return lblStorename;
	}

}