package com.heb.automation.common.pages.browse;

import java.util.List;

import com.heb.automation.common.components.StoreBlocksInListView;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ProductsLandingTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "productsubcat.lnk.viewAll")
	private QAFWebElement lnkViewAll;
	
	public QAFWebElement getLnkViewAll() {
		return lnkViewAll;
	}

	@FindBy(locator = "productslp.lbl.pageheader")
	private QAFWebElement lblPageheader;

	@FindBy(locator = "productslp.lbl.allproducts")
	private QAFWebElement lblAllproducts;

/*	@FindBy(locator = "productslp.lbl.storename")
	private QAFWebElement lblStorename;

	@FindBy(locator = "productslp.txt.searchbox")
	private QAFWebElement txtSearchbox;

	@FindBy(locator = "productslp.lbl.nextpickupdate")
	private QAFWebElement lblNextpickupdate;*/
	
	@FindBy(locator = "productslp.li.addbuttonlist")
	private List<QAFWebElement> liAddbuttonlist;
	
	@FindBy(locator = "productscdp.txt.alertMsg")
	private QAFWebElement txtAlertMsg;
	
	public QAFWebElement getTxtAlertMsg() {
		return txtAlertMsg;
	}

	public List<QAFWebElement> getLiAddbuttonlist() {
		return liAddbuttonlist;
	}

	@FindBy(locator = "productslp.li.headercategorieslist")
	private List<QAFWebElement> liHeadercategorieslist;

	@FindBy(locator = "productslp.li.rowcategorieslist")
	private List<QAFWebElement> liRowcategorieslist;

	@FindBy(locator = "productslp.btn.cart")
	private QAFWebElement btnCart;

	@FindBy(locator = "productslp.btn.myprofile")
	private QAFWebElement btnMyprofile;
	
	@FindBy(locator = "productslp.li.meatandseafood")
	private QAFWebElement liMeatandseafood;

	@FindBy(locator = "productslp.li.drinksbeerandwine")
	private QAFWebElement liDrinksbeerandwine;
	
	@FindBy(locator = "productslp.li.householdandkitchen")
	private QAFWebElement liHouseholdandkitchen;
	
	@FindBy(locator = "productslp.txt.beer")
	private QAFWebElement txtBeer;
	
	@FindBy(locator = "productslp.li.subCategoryblockBeer")
	private List<QAFWebElement> liSubCategoryblockBeer;
	
	@FindBy(locator = "productslp.txt.prodbeerDisabled")
	private QAFWebElement txtProdbeerDisabled;
	
	@FindBy(locator = "productslp.btn.addDisabled")
	private QAFWebElement btnAddDisabled;
	
	@FindBy(locator = "productslp.txt.prodNotavailable")
	private QAFWebElement txtProdNotavailable;
	
	@FindBy(locator = "productslp.txt.enabledBeerProd")
	private QAFWebElement txtEnabledBeerProd;
	
	@FindBy(locator = "productslp.txt.disabledBeerProd")
	private QAFWebElement txtDisabledBeerProd;
	
	@FindBy(locator = "productslp.li.babyandtoys")
	private QAFWebElement liBabyandtoys;
	
	@FindBy(locator = "productslp.li.subCategoryhouseholdandkitchen")
	private List<QAFWebElement> liSubCategoryhouseholdandkitchen;
	
	public List<QAFWebElement> getLiSubCategoryhouseholdandkitchen() {
		return liSubCategoryhouseholdandkitchen;
	}

	@FindBy(locator = "productslp.li.lastsubCategoryhouseholdandkitchen")
	private QAFWebElement liLastsubCategoryhouseholdandkitchen;
	
	public QAFWebElement getLiLastsubCategoryhouseholdandkitchen() {
		return liLastsubCategoryhouseholdandkitchen;
	}


	public QAFWebElement getLiHouseholdandkitchen() {
		return liHouseholdandkitchen;
	}
	
	public QAFWebElement getLiBabyandtoys() {
		return liBabyandtoys;
	}

	public QAFWebElement getTxtDisabledBeerProd() {
		return txtDisabledBeerProd;
	}

	public QAFWebElement getTxtEnabledBeerProd() {
		return txtEnabledBeerProd;
	}

	public QAFWebElement getTxtProdNotavailable() {
		return txtProdNotavailable;
	}

	public QAFWebElement getBtnAddDisabled() {
		return btnAddDisabled;
	}

	public QAFWebElement getTxtProdbeerDisabled() {
		return txtProdbeerDisabled;
	}

	public List<QAFWebElement> getLiSubCategoryblockBeer() {
		return liSubCategoryblockBeer;
	}

	public QAFWebElement getTxtBeer() {
		return txtBeer;
	}

	public QAFWebElement getLiDrinksbeerandwine() {
		return liDrinksbeerandwine;
	}

	public QAFWebElement getLiMeatandseafood() {
		return liMeatandseafood;
	}

	@FindBy(locator = "productslp.li.secondarylevelheadercategorieslist")
	private List<QAFWebElement> liSecondarylevelheadercategorieslist;
	
	public List<QAFWebElement> getLiSecondarylevelheadercategorieslist() {
		return liSecondarylevelheadercategorieslist;
	}

	public QAFWebElement getLblPageheader() {
		return lblPageheader;
	}

	public QAFWebElement getLblAllproducts() {
		return lblAllproducts;
	}

	public List<QAFWebElement> getLiHeadercategorieslist() {
		return liHeadercategorieslist;
	}
	
	

	public List<QAFWebElement> getLiRowcategorieslist() {
		return liRowcategorieslist;
	}

/*	public QAFWebElement getLblStorename() {
		return lblStorename;
	}

	public QAFWebElement getTxtSearchbox() {
		return txtSearchbox;
	}

	public QAFWebElement getLblNextpickupdate() {
		return lblNextpickupdate;
	}
*/
	// DYNAMIC value declaring
	public QAFWebElement getLblTopelevelcatnamedynamic(String lable) {
		String loc = String.format(pageProps.getString("productslp.lbl.topelevelcatnamedynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getBtnCart() {
		return btnCart;
	}

	public QAFWebElement getBtnMyprofile() {
		return btnMyprofile;
	}
}