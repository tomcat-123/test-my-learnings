package com.heb.automation.common.components.Products;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ProductsCDPSubcategoryProductBlocks extends QAFWebComponent {

	public ProductsCDPSubcategoryProductBlocks(String locator) {
		super(locator);
	}

	@FindBy(locator = "productscdp.li.subcatproductname")
	private QAFWebElement liSubcatproductname;

	@FindBy(locator = "productscdp.li.subcatproductprice")
	private QAFWebElement liSubcatproductprice;

	@FindBy(locator = "productscdp.li.subcatproductweight")
	private QAFWebElement liSubcatproductweight;

	@FindBy(locator = "productscdp.li.subcatproductAddbutton")
	private QAFWebElement liSubcatproductAddbutton;

	@FindBy(locator = "productscdp.li.subcatproductimage")
	private QAFWebElement liSubcatproductimage;

	@FindBy(locator = "productscdp.li.subcatproductcouponindicator")
	private QAFWebElement liSubcatproductcouponindicator;

	@FindBy(locator = "productscdp.lnk.subcategoryPlus")
	private QAFWebElement lnkSubcategoryPlus;

	@FindBy(locator = "productscdp.lnk.subcategoryMinus")
	private QAFWebElement lnkSubcategoryMinus;

	@FindBy(locator = "productscdp.txt.subcategoryValue")
	private QAFWebElement txtSubcategoryValue;

	public QAFWebElement getTxtSubcategoryValue() {
		return txtSubcategoryValue;
	}

	public QAFWebElement getLnkSubcategoryMinus() {
		return lnkSubcategoryMinus;
	}

	public QAFWebElement getLnkSubcategoryPlus() {
		return lnkSubcategoryPlus;
	}

	public QAFWebElement getLiSubcatproductname() {
		return liSubcatproductname;
	}

	public QAFWebElement getLiSubcatproductprice() {
		return liSubcatproductprice;
	}

	public QAFWebElement getLiSubcatproductweight() {
		return liSubcatproductweight;
	}

	public QAFWebElement getLiSubcatproductAddbutton() {
		return liSubcatproductAddbutton;
	}

	public QAFWebElement getLiSubcatproductimage() {
		return liSubcatproductimage;
	}

	public QAFWebElement getLiSubcatproductcouponindicator() {
		return liSubcatproductcouponindicator;
	}
}