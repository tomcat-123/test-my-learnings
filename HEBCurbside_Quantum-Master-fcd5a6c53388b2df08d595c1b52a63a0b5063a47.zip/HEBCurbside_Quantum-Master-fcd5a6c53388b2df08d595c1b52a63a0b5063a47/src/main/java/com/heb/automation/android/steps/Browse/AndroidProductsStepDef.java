/**
 * 
 */
package com.heb.automation.android.steps.Browse;

import static com.heb.automation.common.PerfectoUtils.reportMessage;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.Keys;

import static com.heb.automation.common.PerfectoUtils.MIN_WAIT_TIME;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.Cart.CartLandingTestPage;
import com.heb.automation.common.pages.browse.ProductsCDPTestPage;
import com.heb.automation.common.pages.browse.ProductsLandingTestPage;
import com.heb.automation.common.pages.browse.ProductsSubCategoryTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class AndroidProductsStepDef {

	@QAFTestStep(description = "Verify able to scroll up and down to view all sub categories")
	public void verifyAbleToScrollUpAndDownToViewAllSubCategories() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		int subCatSize = pdtcdp.getLiSubcatheadername().size();

		String lastCategoryName = pdtcdp.getLiSubcatheadername().get(subCatSize - 1).getText();

		if (subCatSize > 0) {
			reportMessage(subCatSize + " subcategories found..", MessageTypes.Pass);

			// Scrolling down
			PerfectoUtils.verticalswipe();

			// Validating whether scrolled down
			subCatSize = pdtcdp.getLiSubcatheadername().size();
			String lastCategoryNameAfterSwipe = pdtcdp.getLiSubcatheadername().get(subCatSize - 1).getText();

			if (!lastCategoryName.equals(lastCategoryNameAfterSwipe)) {
				reportMessage("Scrolled down to the next sub category..", MessageTypes.Pass);
			} else {
				reportMessage("Not scrolled down to the next sub category..", MessageTypes.Fail);
			}
		} else {
			reportMessage("No Subcategories found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify navigated to top when cliking on status bar")
	public void verifyNavigatedToTopWhenClikingOnStatusBar() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		int subCatSize = pdtcdp.getLiSubcatheadername().size();

		if (subCatSize > 0) {
			reportMessage(subCatSize + " subcategories found..", MessageTypes.Pass);

			String firstCategoryName = pdtcdp.getLiSubcatheadername().get(0).getText();

			// Scrolling down
			PerfectoUtils.verticalswipe();

			// CLicking on Status bar- selected top level category
			String selectedTopLevelCategory = ConfigurationManager.getBundle().getString("selectingTopLevelCategory");
			pdtslanding.getLblTopelevelcatnamedynamic(selectedTopLevelCategory).click();
			reportMessage("Clicked on: " + selectedTopLevelCategory);

			// Validating whether navigated to top
			String firstCategoryNameAfterSwipe = pdtcdp.getLiSubcatheadername().get(0).getText();

			if (firstCategoryName.equals(firstCategoryNameAfterSwipe))
				reportMessage("Navigated to top on clicking the status bar..", MessageTypes.Pass);
			else
				reportMessage("Not navigated to top on clicking the status bar..", MessageTypes.Fail);

		} else {
			reportMessage("No Subcategories found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Click on View All option for a subcategory")
	public void clickOnViewAllOptionForASubcategory() {
		ProductsCDPTestPage cdp = new ProductsCDPTestPage();

		cdp.getLiSubcategoryblocks().get(0).waitForPresent(MIN_WAIT_TIME);

		int subCatBlocksCount = cdp.getLiSubcategoryblocks().size();

		// Validating the Sub category sections are available
		if (subCatBlocksCount > 0) {

			cdp.getLiSubcategoryblocks().get(0).getLiSubcatviewall().waitForPresent(MIN_WAIT_TIME);
			cdp.getLiSubcategoryblocks().get(0).getLiSubcatviewall().click();
			reportMessage("Clicked on View All...", MessageTypes.Pass);
		} else {
			reportMessage("SubCategory blocks not found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Click on Products from Footer tab")
	public void clickOnProductsFromFooterTab() {
		reportMessage("NA for android..");
	}

	@QAFTestStep(description = "Verify navigated back to top level categories page for ios")
	public void verifyNavigatedBackToTopLevelCategoriesPageForIos() {
		reportMessage("NA for android..");
	}

	@QAFTestStep(description = "Validate able to view all the top level sub categories when swiping right to left")
	public void validateAbleToViewAllTheTopLevelSubCategorieswhenSwipingRightToLeft() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		// Validating the Top level Sub Categories section
		int topLevelcategoriesSize = pdtsubcat.getLiHeadercategorieslist().size();

		if (topLevelcategoriesSize > 0) {
			reportMessage(topLevelcategoriesSize + " top level categories found..", MessageTypes.Pass);

			String firstCategoryNameBeforeSwipe = pdtsubcat.getLiHeadercategorieslist().get(0).getText();

			// Swipe right Operation
			PerfectoUtils.swipeRight(pdtsubcat.getLiHeadercategorieslist().get(0));

			// Validating the swipe operation
			String firstCategoryNameAfterSwipe = pdtsubcat.getLiHeadercategorieslist().get(0).getText();

			if (!firstCategoryNameBeforeSwipe.equals(firstCategoryNameAfterSwipe))
				reportMessage("Swiped and navigated to the Last top level sub category..", MessageTypes.Pass);
			else
				reportMessage("Swiped and not navigated to the Last top level sub category..", MessageTypes.Fail);

		} else {
			reportMessage("Top level categories not found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify row of products will scroll vertically but not horizontally")
	public void verifyRowOfProductsWillScrollVerticallyButNotHorizontally() {

		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();
		// ProductsSubCategoryTestPage prdtsSubCat = new
		// ProductsSubCategoryTestPage();
		pdtsubcat.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		// Validating the Top level Sub Categories section
		int topLevelcategoriesSize = pdtsubcat.getLiHeadercategorieslist().size();

		if (topLevelcategoriesSize > 0) {
			reportMessage(topLevelcategoriesSize + " top level categories found..", MessageTypes.Pass);

			String firstCategoryNameBeforeSwipe = pdtsubcat.getLiHeadercategorieslist().get(0).getText();

			// Swipe right Operation
			PerfectoUtils.rightSwipe();

			// Validating the swipe operation
			String firstCategoryNameAfterSwipe = pdtsubcat.getLiHeadercategorieslist().get(0).getText();

			if (firstCategoryNameBeforeSwipe.equals(firstCategoryNameAfterSwipe))
				reportMessage("Swiped and navigated to the Last top level sub category..", MessageTypes.Pass);
			else
				reportMessage("Swiped and not navigated to the Last top level sub category..", MessageTypes.Fail);

		} else {
			reportMessage("Top level categories not found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify products grid will not have sub headers or View all button")
	public void VerifyProductsGridWillNotHaveSubHeadersOrViewAllButton() {
		reportMessage("Yet to add. Story only delivered for iOS- MAD-259 ");
	}

	@QAFTestStep(description = "Verify able to enter value {0} by using keyboard")
	public void verifyAbleToEnterValueByUsingKeyboard(String strqty) {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleTxtSubcategoryValue = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getTxtSubcategoryValue();

		eleTxtSubcategoryValue.click();
		eleTxtSubcategoryValue.clear();
		eleTxtSubcategoryValue.sendKeys(Keys.chord(Keys.CONTROL, "a"), "");
		eleTxtSubcategoryValue.clear();
		eleTxtSubcategoryValue.sendKeys(strqty);
		// eleTxtSubcategoryValue.sendKeys(Keys.ENTER);

		String subCategoryValueAfterSendkeys = eleTxtSubcategoryValue.getText();

		if (strqty.equals(subCategoryValueAfterSendkeys))
			reportMessage("Able to enter sub category value..", MessageTypes.Pass);
		else
			reportMessage("Not able to enter sub category value..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "verify the error message when adding the maximum quantity")
	public void verifyTheErrorMessageWhenAddingTheMaximumQuantity() {
		reportMessage("Yet to add.");
	}

	@QAFTestStep(description = "Verify outside of the selected product is disabled when the keyboard is visible")
	public void verifyOutsideOfTheSelectedProductIsDisabledWhenTheKeyboardIsVisible() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleTxtSubcategoryValue = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getTxtSubcategoryValue();

		eleTxtSubcategoryValue.click();
		reportMessage("Clicked on Qty text field..", MessageTypes.Pass);

		QAFWebElement eleAddbuttonForSecondProduct = pdtcdp.getLiSubcategoryblocks().get(0)
				.getLiSubcategoryproductblocks().get(1).getLiSubcatproductAddbutton();

		// Clicking outside of the selected product
		eleAddbuttonForSecondProduct.click();
		reportMessage("Clicked on Add button for Second product..");

		// Validating whether the Add button is still present for the Second
		// product
		if (eleAddbuttonForSecondProduct.isPresent()) {
			reportMessage("Outside of the selected product is disabled when the keyboard is visible..",
					MessageTypes.Pass);
		} else {
			reportMessage("Outside of the selected product is not disabled when the keyboard is visible..",
					MessageTypes.Fail);
		}

		// reportMessage("Yet to add. Story only delivered for iOS- MAD-1377 ");
	}

	@QAFTestStep(description = "I verify the Done button is available in keyboard")
	public void iVerifyTheDoneButtonIsAvailableInKeyboard() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.waitForPageToLoad();
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");
		String isBtnDoneVisible = (String) pdtcdp.getTestBase().getDriver().executeScript("mobile:text:find", params1);

		if (isBtnDoneVisible.equalsIgnoreCase("false")) {
			Map<String, Object> params2 = new HashMap<>();
			params2.put("content", "Done");
			params2.put("timeout", "20");
			params2.put("profile", "DocumentConversion_Speed");
			params2.put("analysis", "manual");
			params2.put("inverse", "yes");
			params2.put("screen.top", "69%");
			params2.put("screen.height", "31%");
			params2.put("screen.left", "51%");
			params2.put("screen.width", "49%");
			isBtnDoneVisible = (String) pdtcdp.getTestBase().getDriver().executeScript("mobile:text:find", params2);

		}

		if (isBtnDoneVisible.equalsIgnoreCase("true")) {
			PerfectoUtils.reportMessage("Done button is available in the Keyboard as expected.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Done button is not available in the Keyboard.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify clicking outside of the keyboard that re-enables the rest of the screen")
	public void verifyClickingOutsideOfTheKeyboardThatReEenablesTheRestOfTheScreen() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		QAFWebElement eleAddbuttonForSecondProduct = pdtcdp.getLiSubcategoryblocks().get(0)
				.getLiSubcategoryproductblocks().get(1).getLiSubcatproductAddbutton();

		eleAddbuttonForSecondProduct.click();
		reportMessage("Clicking on Add button again for the second product..");

		// Validating whether the Add button is not present
		if (!eleAddbuttonForSecondProduct.isPresent()) {
			reportMessage("Clicking outside of the keyboard re-enabled the rest of the screen..", MessageTypes.Pass);
		} else {
			reportMessage("Clicking outside of the keyboard doesn't re-enable the rest of the screen",
					MessageTypes.Fail);
		}
	}
	// reportMessage("Yet to add. Story only delivered for iOS- MAD-1377 ");

	@QAFTestStep(description = "Verify the qty gets increased on clicking plus button")
	public void verifyTheQtyGetsIncreasedOnClickingPlusButton() {
		reportMessage("Yet to add. Story only delivered for iOS- MAD-937 ");
	}

	@QAFTestStep(description = "Verify the qty gets decreased on clicking minus button")
	public void verifyTheQtyGetsDecreasedOnClickingPlusButton() {
		reportMessage("Yet to add. Story only delivered for iOS- MAD-937 ");
	}

	@QAFTestStep(description = "Verify a back button is positioned on the far left")
	public void verifyABackButtonIsPositionedOnTheFarLeft() {
		reportMessage("NA for android..");
	}

	@QAFTestStep(description = "Verify the max number of characters is 9 for a category")
	public void verifyTheMaxNumberOfCharactersIs9ForACategory() {
		reportMessage("NA for android..");
	}

	@QAFTestStep(description = "Verify able to scroll left and right within each sub category")
	public void verifyAbleToScrollLeftAndRightWithinEachSubCategory() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		int subCatSize = pdtcdp.getLiSubcategoryblocks().size();

		if (subCatSize > 0) {
			reportMessage(subCatSize + " sub-categories found..", MessageTypes.Pass);

			QAFWebElement eleFirstPdtName = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
					.get(0).getLiSubcatproductname();

			int XCordinateBeforeSwipe = Integer.parseInt(eleFirstPdtName.getAttribute("X"));

			// Swipe Right
			PerfectoUtils.swipeRight(eleFirstPdtName);

			int XCordinateAfterSwipe = Integer.parseInt(eleFirstPdtName.getAttribute("X"));

			// Validating the Swipe right
			if (XCordinateBeforeSwipe > XCordinateAfterSwipe)
				reportMessage("Swipe to right validated successfully..", MessageTypes.Pass);
			else
				reportMessage("Swipe to right validation failed..", MessageTypes.Fail);

			// Swipe left
			eleFirstPdtName = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0)
					.getLiSubcatproductname();

			XCordinateBeforeSwipe = Integer.parseInt(eleFirstPdtName.getAttribute("X"));

			PerfectoUtils.swipeLeft(eleFirstPdtName);

			XCordinateAfterSwipe = Integer.parseInt(eleFirstPdtName.getAttribute("X"));

			// Validating the Swipe left
			if (XCordinateBeforeSwipe < XCordinateAfterSwipe)
				reportMessage("Swipe to left validated successfully..", MessageTypes.Pass);
			else
				reportMessage("Swipe to left validation failed..", MessageTypes.Fail);

		} else {
			reportMessage("No sub-categories found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify Navigated to all products subcategory page")
	public void verifyNavigatedToAllProductsSubcategoryPage() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.getLiSpecifiedsubcategoryblocks().get(0).waitForPresent(MIN_WAIT_TIME);

		int subCategorySize = pdtsubcat.getLiSpecifiedsubcategoryblocks().size();

		if (subCategorySize > 0)
			reportMessage("Navigated to all products sub category page..", MessageTypes.Pass);
		else
			reportMessage("Not navigated to all products sub category page..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Validate able to view all the sub categories when swiping right to left")
	public void validateAbleToViewAllTheSubCategoriesWhenSwipingRightToLeft() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		// Validating the Top level Sub Categories section
		// int topLevelcategoriesSize =
		// pdtsubcat.getLiHeadercategorieslist().size();

		// validating the categories section

		int categoriesSize = pdtcdp.getLiSubcategoryfirstproductblocks().size();

		if (categoriesSize > 0) {
			reportMessage(categoriesSize + " top level categories found..", MessageTypes.Pass);

			// String firstCategoryNameBeforeSwipe =
			// pdtcdp.getLiSubcategoryfirstproductblocks().get(0).getText();

			while (!pdtcdp.getImgAnimation().isPresent())

			{

				PerfectoUtils.swipeRight();
				reportMessage("Animation is reached", MessageTypes.Pass);
			}

			reportMessage("Animation is not reached", MessageTypes.Fail);

		}
	}

	@QAFTestStep(description = "Verify the quantity is entered {0} by using keyboard")
	public void verifyTheQuantityIsEnteredByUsingKeyboard(String strqty) {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleTxtSubcategoryValue = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getTxtSubcategoryValue();

		eleTxtSubcategoryValue.click();
		eleTxtSubcategoryValue.clear();
		eleTxtSubcategoryValue.sendKeys(Keys.chord(Keys.CONTROL, "a"), "");
		eleTxtSubcategoryValue.clear();
		eleTxtSubcategoryValue.click();
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(strqty);
		reportMessage("Successfully typed sub category Quantity value using keyboard.." + strqty, MessageTypes.Pass);
		String subCategoryValueAfterSendkeys = eleTxtSubcategoryValue.getText();

		if (strqty.equals(subCategoryValueAfterSendkeys))
			reportMessage("Able to enter sub category Quantity value..", MessageTypes.Pass);
		else
			reportMessage("Not able to enter sub category Quantity value..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Taps on Done button by using keyboard and becomes invisible")
	public void tapsonDonebuttonusingkeyboardByUsingKeyboardAndBecomesInvisible() {

		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleTxtSubcategoryValue = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getTxtSubcategoryValue();

		pdtcdp.waitForPageToLoad();
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");
		String isBtnDoneInVisible = (String) pdtcdp.getTestBase().getDriver().executeScript("mobile:text:select",
				params1);
		if (eleTxtSubcategoryValue.isDisplayed()) {
			PerfectoUtils.reportMessage("Done button has got clicked in the Keyboard as expected." + isBtnDoneInVisible,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Done button is not been clicked in the Keyboard as expected." + isBtnDoneInVisible,
					MessageTypes.Pass);
		}

	}

	@QAFTestStep(description = "Verify plus and minus buttons display right above the numeric keyboard")
	public void verifyPlusAndMinusButtonsDisplayRightAboveTheNumericKeyboard() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getBtnPlus().isDisplayed()) {
			PerfectoUtils.reportMessage("Plus button has got displayed right above the Keyboard section.",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Plus button has not been displayed right above the Keyboard section.",
					MessageTypes.Pass);
		}
		if (pdtcdp.getBtnMinus().isDisplayed()) {
			PerfectoUtils.reportMessage("Minus button has got displayed right above the Keyboard section.",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Minus button has not been displayed right above the Keyboard section.",
					MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "Verify the button converts back to ADD")
	public void verifyTheButtonConvertsBackToADD() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLiSubcatproductAddbutton()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleAddButton = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0)
				.getLiSubcatproductAddbutton();

		if (eleAddButton.isPresent()) {
			reportMessage("Add button is displayed again..", MessageTypes.Pass);
		} else {
			reportMessage("Add button is not displayed again..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Taps on Done button by using keyboard")
	public void tapsonDonebuttonusingkeyboardByUsingKeyboard() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);
		QAFWebElement eleAddButton = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0)
				.getLiSubcatproductAddbutton();

		pdtcdp.waitForPageToLoad();
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");
		String isBtnDoneInVisible = (String) pdtcdp.getTestBase().getDriver().executeScript("mobile:text:select",
				params1);
		if (eleAddButton.isDisplayed()) {
			PerfectoUtils.reportMessage("Done button has got clicked in the Keyboard as expected." + isBtnDoneInVisible,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Done button is not been clicked in the Keyboard as expected." + isBtnDoneInVisible,
					MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "Verify error message by passing special character(s)")
	public void verifyErrorMessageByPassingSpecialCharacters() {
		reportMessage("Automation is not Required as Confirmed..", MessageTypes.Pass);

	}

	@QAFTestStep(description = "Verify the button greyed out when passing negative quantity")
	public void verifyTheButtonGreyedOutWhenPassingNegativeQuantity() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getBtnAddGreyedout().isPresent()) {
			PerfectoUtils.reportMessage("Add button is Greyed out above the Keyboard as expected.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Add button is not Greyed out above the Keyboard as expected.",
					MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "Verify the numeric value entered after tapping Keyboard back button")
	public void verifyTheNumericValueEnteredAfterTappingKeyboardBackButton() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleTxtSubcategoryValue = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getTxtSubcategoryValue();

		pdtcdp.waitForPageToLoad();
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "DEL");
		String isBtnDELVisible = (String) pdtcdp.getTestBase().getDriver().executeScript("mobile:text:select", params1);
		System.out.println(isBtnDELVisible);
		// if(isBtnDELVisible.equalsIgnoreCase("null")){
		if (eleTxtSubcategoryValue.isDisplayed()) {
			PerfectoUtils.reportMessage("Keyboard Back button (DEL) has got clicked in the Keyboard as expected."
					+ eleTxtSubcategoryValue.getText() + isBtnDELVisible, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Keyboard Back button (DEL) is not present." + eleTxtSubcategoryValue.getText(),
					MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "Verify Cart Icon incremented")
	public void verifyCartIconIncremented() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		if (pdtcdp.getIconCartIcon().isPresent()) {
			PerfectoUtils.reportMessage("Cart Quantity incremented to.." + pdtcdp.getIconCartIcon().getText(),
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cart Quantity is not incremented." + pdtcdp.getIconCartIcon().getText(),
					MessageTypes.Pass);
		}

	}

	@QAFTestStep(description = "Click on done button")
	public void clickOnDoneButton() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();
		pdtsubcat.getBtnDonekey().waitForPresent(MIN_WAIT_TIME);

		if (pdtsubcat.getBtnDonekey().isDisplayed()) {

			pdtsubcat.getBtnDonekey().click();
			pdtsubcat.getBtnDonekey().click();
			PerfectoUtils.reportMessage("Done button has got clicked in the Keyboard as expected.", MessageTypes.Pass);

		} else {
			PerfectoUtils.reportMessage("Done button is not been clicked in the Keyboard as expected.",
					MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify row of grid products will scroll vertically")
	public void verifyRowOfGridProductsWillScrollVertically() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.getLiAddbuttonlist().get(0).waitForPresent(MIN_WAIT_TIME);

		int topLevelsubcategoriesSize = pdtslanding.getLiSecondarylevelheadercategorieslist().size();

		if (topLevelsubcategoriesSize > 0) {

			reportMessage(topLevelsubcategoriesSize + " subcategories found to swipe up vertically..",
					MessageTypes.Pass);

			if (topLevelsubcategoriesSize < 3) {
				reportMessage("Not enough subcategories are available to swipe up..", MessageTypes.Pass);
				// Scrolling up
				PerfectoUtils.verticalswipe();
			} else {

				float YCordinateBeforeSwipe = Float.parseFloat(pdtsubcat.getLiAddbuttonlist().get(0).getAttribute("y"));

				// Scrolling up
				PerfectoUtils.verticalswipe();

				float YCordinateAfterSwipe = 0;

				try {
					YCordinateAfterSwipe = Float.parseFloat(pdtsubcat.getLiAddbuttonlist().get(0).getAttribute("y"));
				} catch (NumberFormatException e) {

				}

				if (YCordinateBeforeSwipe > YCordinateAfterSwipe) {

					reportMessage("Scrolled up to the next sub category..", MessageTypes.Pass);
				} else {
					reportMessage("Not scrolled up to the next sub category..", MessageTypes.Fail);
				}
			}
		} else {
			reportMessage("Not enough Subcategories found to swipe vertically..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify View All button is not displayed")
	public void verifyViewAllButtonIsNotDisplayed() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLiSecondarylevelheadercategorieslist().get(0).waitForPresent(MIN_WAIT_TIME);

		int subCatBlocksCount = pdtslanding.getLiSecondarylevelheadercategorieslist().size();

		// Validating the Sub category sections are available
		if (subCatBlocksCount > 0) {

			pdtslanding.getLnkViewAll().waitForNotPresent(MIN_WAIT_TIME);
			pdtslanding.getLnkViewAll().waitForNotVisible();
			reportMessage("View All is not present as Expected...", MessageTypes.Pass);
		} else {
			reportMessage("View All is found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify sub-categories headers are not displayed")
	public void verifySubCategoriesHeadersAreNotDisplayed() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		int subCatHeadersSize = pdtslanding.getLiSecondarylevelheadercategorieslist().size();

		if (!(subCatHeadersSize > 0)) {
			reportMessage(subCatHeadersSize + " subcategories Headers not found as expected..", MessageTypes.Pass);
			reportMessage(subCatHeadersSize + " subcategories Headers found as not expected..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate able to view all the last level categories when swiping Left to Right")
	public void validateAbleToViewAllTheLastLevelCategoriesWhenSwipingLeftToRight() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtsubcat.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		// Validating the Last level Sub Categories section
		int lastLevelcategoriesSize = pdtslanding.getLiSecondarylevelheadercategorieslist().size();

		if (lastLevelcategoriesSize > 0) {
			reportMessage(lastLevelcategoriesSize + " Last level categories found..", MessageTypes.Pass);

			String firstCategoryNameBeforeSwipe = pdtslanding.getLiSecondarylevelheadercategorieslist().get(0)
					.getText();

			// Swipe right Operation
			PerfectoUtils.swipeRight(pdtslanding.getLiSecondarylevelheadercategorieslist().get(0));

			// Validating the swipe operation
			String firstCategoryNameAfterSwipe = pdtslanding.getLiSecondarylevelheadercategorieslist().get(0).getText();

			if (!firstCategoryNameBeforeSwipe.equals(firstCategoryNameAfterSwipe))
				reportMessage("Swiped and navigated to the Last level sub category.." + firstCategoryNameBeforeSwipe
						+ firstCategoryNameAfterSwipe, MessageTypes.Pass);
			else
				reportMessage("Swiped and not navigated to the Last level sub category..", MessageTypes.Fail);

		} else {
			reportMessage("Last level categories not found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify two columns at least displayed at Last level")
	public void verifyTwoColumnsAtLeastDisplayedAtLastLevel() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		int CategoriesListFromLastlevelSize = pdtslanding.getLiSecondarylevelheadercategorieslist().size();

		if (CategoriesListFromLastlevelSize > 2) {
			reportMessage("Last Level Category displayed at least two columns..", MessageTypes.Pass);
		} else {
			reportMessage("Last Level Category is not displayed two columns..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify last level category page displayed where secondary level category page is not present")
	public void VerifyLastLevelCategoryPageDisplayedWhereSecondaryLevelCategoryPageIsNotPresent() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		pdtslanding.getLiSecondarylevelheadercategorieslist().get(0).isDisplayed();

		String strLastLvlPrdtname = pdtslanding.getLiSecondarylevelheadercategorieslist().get(0).getText();

		String selectedTopLevelCategory = ConfigurationManager.getBundle().getString("browse.catname.TopLevelCategory");
		// String strSecondarylvlpdt =
		// pdtslanding.getLblTopelevelcatnamedynamic(selectedTopLevelCategory).getText();

		if (!(strLastLvlPrdtname.matches(selectedTopLevelCategory))) {
			reportMessage("Secondary level category page not displayed ", MessageTypes.Pass);

			if (pdtsubcat.getLblTopelevelcatnamedynamic(selectedTopLevelCategory).verifyNotPresent()) {
				reportMessage("Last Level Category displayed Where Secondary level Category is not present..",
						MessageTypes.Pass);
			} else {
				if (pdtsubcat.getLblTopelevelcatnamedynamic(selectedTopLevelCategory).verifyPresent())
					reportMessage("Secondary Level Category page displayed..", MessageTypes.Fail);
			}
		} else {
			reportMessage("Secondary Level Category page is displayed..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify that horizontal level navigation is not possible at Last Level")
	public void verifyThatHorizontalLevelNavigationIsNotPossibleAtLastLevel() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		// Validating the Last level Sub Categories section
		int lastLevelcategoriesSize = pdtslanding.getLiSecondarylevelheadercategorieslist().size();

		if (lastLevelcategoriesSize > 0) {
			reportMessage(lastLevelcategoriesSize + " Last level categories found..", MessageTypes.Pass);

			// Horizontal swipe Naviagation
			PerfectoUtils.swipeRight(pdtslanding.getLiSecondarylevelheadercategorieslist().get(0));
			reportMessage("Horizontal level is not possible after attaining to the last product..", MessageTypes.Pass);
		} else {

			reportMessage("Last product is displayed and horizontal naviagation is possible..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify Search and Date sections should be minimized when able to scroll up")
	public void verifySearchAndDateSectionsShouldBeMinimizedWhenAbleToScrollUp() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		if (pdtsubcat.getTxtDateAndtime().verifyNotVisible()) {
			reportMessage("Date and Time is minimized..", MessageTypes.Pass);
		} else {

			reportMessage("Date and Time is not minimized..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify default product in the last level underlined in yellow")
	public void verifyDefaultProductInTheLastLevelUnderlinedInYellow() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		int CategoriesListFromToplevelSize = pdtslanding.getLiSecondarylevelheadercategorieslist().size();

		if (CategoriesListFromToplevelSize > 0) {
			reportMessage("Navigated to Selected category page..", MessageTypes.Pass);
			try {
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", "GROUP:Curbside/Android/Data/yellow_line.png");
				String isImgVisible = (String) pdtslanding.getTestBase().getDriver().executeScript("mobile:image:find",
						params1);
				reportMessage("Default first Product underlined in Yellow color.." + isImgVisible, MessageTypes.Pass);
			} catch (Exception e) {
				reportMessage("Default first Product is not underlined in Yellow color..", MessageTypes.Fail);
			}
		}
	}

	@QAFTestStep(description = "Click on a Meat and Sea Food Category from top level options")
	public void clickOnAMeatAndSeaFoodCategoryFromTopLevelOptions() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		if (pdtslanding.getLiMeatandseafood().isPresent()) {

			pdtslanding.getLiMeatandseafood().click();
			pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);
			PerfectoUtils.reportMessage("The Meat and Sea food category is clicked", MessageTypes.Pass);
		} else
			PerfectoUtils.reportMessage("The Meat and Sea food category is not clicked", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I verify user is navigated to last-level products screen")
	public void iVerifyUserIsNavigatedToLastLevelProductsScreen() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		int size = pdtsubcat.getListLastlevelPdts().size();
		String frstpdt = pdtsubcat.getListLastlevelPdts().get(0).getText();

		if (pdtsubcat.getListLastlevelPdts().get(0).isPresent()) {
			reportMessage("Navigated to last-level " + frstpdt + " screen with size " + size, MessageTypes.Pass);
		} else {
			reportMessage("user is not navigated to last-level product screen", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Click on Category name for adding quantity")
	public void clickOnCategoryNameForAddingQuantity() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		// Validating the Row level Categories section
		int categoriesSizeInAllProductsTab = pdtslanding.getLiHeadercategorieslist().size();

		if (categoriesSizeInAllProductsTab > 0) {
			reportMessage(categoriesSizeInAllProductsTab + " Categories found in All products tab..",
					MessageTypes.Pass);

			String selectingCategory = pdtslanding.getLiHeadercategorieslist().get(2).getText();
			pdtslanding.getLiHeadercategorieslist().get(2).click();
			reportMessage("Clicked on: " + selectingCategory);

		} else {
			reportMessage("No Categories found in All products tab..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I navigate to qty for product item")
	public void iNavigateToQtyForProductItem() {

		reportMessage("NA for android");

	}

	@QAFTestStep(description = "I verify product price and ADD button")
	public void iVerifyProductPriceAndADDButton() {

		reportMessage("NA for android");

	}

	@QAFTestStep(description = "I verify custom stepper and the cart")
	public void iVerifyCustomStepperAndTheCart() {

		reportMessage("NA for android");

	}

	@QAFTestStep(description = "I verify quantity will adjust by one by tapping either of the adjust quantity buttons")
	public void iVerifyQuantityWillAdjustByOneByTappingEitherOfTheAdjustQuantityButtons() {

		reportMessage("NA for android");

	}

	@QAFTestStep(description = "I verify message from the system")
	public void iVerifyMessageFromTheSystem() {

		reportMessage("NA for android");

	}

	@QAFTestStep(description = "I verify pick up time is not available for scrolling up the page")
	public void iVerifyPickUpTimeIsNotAvailableForScrollingUpThePage() {

		reportMessage("NA for android");

	}

	@QAFTestStep(description = "I tap on Select New Time after pickup time has expired")
	public void iTapOnSelectNewTimeAfterPickupTimeHasExpired() {

		reportMessage("NA for android");

	}

	@QAFTestStep(description = "I navigates to placeholder time selection page")
	public void iNavigatesToPlaceholderTimeSelectionPage() {

		reportMessage("NA for android");

	}

	@QAFTestStep(description = "I verify the blank white product image with text and ADD button")
	public void iVerifyTheBlankWhiteProductImageWithTextAndADDButton() {
		reportMessage("Cannot be Automated..");
	}

	@QAFTestStep(description = "Clicks on Add button for minimum qty product")
	public void clicksOnAddButtonForMinimumQtyProduct() {

		reportMessage("NA for android");
	}

	@QAFTestStep(description = "Click on Drinks,Beer and Wine Category from top level options")
	public void clickOnDrinksBeerAndWineCategoryFromTopLevelOptions() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		QAFWebElement firstCategoryNameBeforeSwipe = pdtsubcat.getLiHeadercategorieslist().get(0);
		// Validating the swipe operation
		QAFWebElement firstCategoryNameAfterSwipe = pdtslanding.getLiDrinksbeerandwine();
		// Swipe right Operation
		PerfectoUtils.swipeRightToProduct(firstCategoryNameBeforeSwipe, firstCategoryNameAfterSwipe);

		if (pdtslanding.getLiDrinksbeerandwine().isPresent()) {
			pdtslanding.getLiDrinksbeerandwine().click();
			pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);
			PerfectoUtils.reportMessage("The Drinks,Beer & Wine category is clicked", MessageTypes.Pass);
		} else
			PerfectoUtils.reportMessage("The Drinks,Beer & Wine category is not clicked", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify not available message is displayed when user is browsing a category not available")
	public void verifyNotAvailableMessageIsDisplayedWhenUserIsBrowsingACategoryNotAvailable() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		int subCatSize = pdtslanding.getLiSubCategoryblockBeer().size();

		String lastCategoryName = pdtslanding.getLiSubCategoryblockBeer().get(subCatSize - 1).getText();

		if (subCatSize > 0) {
			reportMessage(subCatSize + " subcategories found..", MessageTypes.Pass);

			// Scrolling down
			PerfectoUtils.verticalswipe();

			// Validating whether scrolled down
			subCatSize = pdtslanding.getLiSubCategoryblockBeer().size();
			String lastCategoryNameAfterSwipe = pdtslanding.getLiSubCategoryblockBeer().get(subCatSize - 1).getText();

			if (!lastCategoryName.equals(lastCategoryNameAfterSwipe)) {
				reportMessage("Scrolled down to the next sub category.." + lastCategoryNameAfterSwipe,
						MessageTypes.Pass);
			} else {
				reportMessage("Not scrolled down to the next sub category..", MessageTypes.Fail);
			}
		} else {
			reportMessage("No Subcategories found..", MessageTypes.Fail);
		}
		if (pdtslanding.getTxtProdbeerDisabled().verifyPresent()) {
			reportMessage("Beer Product is disabled as expected..", MessageTypes.Pass);
		} else {
			reportMessage("Beer Product is Enabled..", MessageTypes.Fail);
		}

		QAFWebElement firstCategoryNameBeforeSwipe = pdtslanding.getTxtEnabledBeerProd();
		QAFWebElement firstCategoryNameAfterSwipe = pdtslanding.getTxtDisabledBeerProd();
		// Validating the swipe operation
		PerfectoUtils.swipeRightToProduct(firstCategoryNameBeforeSwipe, firstCategoryNameAfterSwipe);

		if (pdtslanding.getTxtDisabledBeerProd().isPresent()) {
			reportMessage("Beer Product is not available at the pick up time as it is disabled..", MessageTypes.Pass);
		} else {
			reportMessage("Beer Product is available at the pick up time as it is enabled..", MessageTypes.Fail);
		}
		// Scrolling up
		PerfectoUtils.horizontalswipe();

		String strProductNotAvailableMessage = pdtslanding.getTxtProdNotavailable().getText();
		String ProductNotAvailableMsg = ConfigurationManager.getBundle()
				.getString("browse.catname.productNotAvailableMsg");
		if (strProductNotAvailableMessage.equalsIgnoreCase(ProductNotAvailableMsg)) {
			reportMessage("Product Not availble at the pick up time selected message is displayed..",
					MessageTypes.Pass);
		} else {
			reportMessage("Product Not availble at the pick up time selected message is not displayed..",
					MessageTypes.Fail);

		}
	}

	@QAFTestStep(description = "Verify the product grid when items are not available")
	public void verifyTheProductGridWhenItemsAreNotAvailable() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		int subCatSize = pdtslanding.getLiSubCategoryblockBeer().size();

		String lastCategoryName = pdtslanding.getLiSubCategoryblockBeer().get(subCatSize - 1).getText();

		if (subCatSize > 0) {
			reportMessage(subCatSize + " subcategories found..", MessageTypes.Pass);

			// Scrolling down
			PerfectoUtils.verticalswipe();

			// Validating whether scrolled down
			subCatSize = pdtslanding.getLiSubCategoryblockBeer().size();
			String lastCategoryNameAfterSwipe = pdtslanding.getLiSubCategoryblockBeer().get(subCatSize - 1).getText();

			if (!lastCategoryName.equals(lastCategoryNameAfterSwipe)) {
				reportMessage("Scrolled down to the next sub category.." + lastCategoryNameAfterSwipe,
						MessageTypes.Pass);
			} else {
				reportMessage("Not scrolled down to the next sub category..", MessageTypes.Fail);
			}
		} else {
			reportMessage("No Subcategories found..", MessageTypes.Fail);
		}
		if (pdtslanding.getTxtProdbeerDisabled().verifyPresent()) {
			reportMessage("Beer Product is disabled as expected..", MessageTypes.Pass);
		} else {
			reportMessage("Beer Product is Enabled..", MessageTypes.Fail);
		}

		QAFWebElement firstCategoryNameBeforeSwipe = pdtslanding.getTxtEnabledBeerProd();
		QAFWebElement firstCategoryNameAfterSwipe = pdtslanding.getTxtDisabledBeerProd();
		// Validating the swipe operation
		PerfectoUtils.swipeRightToProduct(firstCategoryNameBeforeSwipe, firstCategoryNameAfterSwipe);

		if (pdtslanding.getTxtDisabledBeerProd().isPresent()) {
			reportMessage("Product Grid is not available at the pick up time as Expected..", MessageTypes.Pass);
		} else {
			reportMessage("Product Grid is available at the pick up time..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I removed added items from the cart")
	public void iRemovedAddedItemsFromTheCart() {
		reportMessage("NA for Android", MessageTypes.Pass);

	}
	
	@QAFTestStep(description = "Verify able to scroll left within each sub category")
	public void verifyAbleToScrollLeftWithinEachSubCategory() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		int subCatSize = pdtcdp.getLiSubcategoryblocks().size();

		if (subCatSize > 0) {
			reportMessage(subCatSize + " sub-categories found..", MessageTypes.Pass);

			QAFWebElement eleFirstPdtName = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
					.get(0).getLiSubcatproductname();

			int XCordinateBeforeSwipe = Integer.parseInt(eleFirstPdtName.getAttribute("X"));

			// Swipe Right
			PerfectoUtils.swipeRight(eleFirstPdtName);

			int XCordinateAfterSwipe = Integer.parseInt(eleFirstPdtName.getAttribute("X"));

			// Validating the Swipe right
			if (XCordinateBeforeSwipe > XCordinateAfterSwipe)
				reportMessage("Swipe to right validated successfully..", MessageTypes.Pass);
			else
				reportMessage("Swipe to right validation failed..", MessageTypes.Fail);


		} else {
			reportMessage("No sub-categories found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the quantity of items selected in the product details page")
	public void verifyTheQuantityOfItemsSelectedInTheProductDetailsPage() {
		reportMessage("OOS for Android..", MessageTypes.Info);
	}
	
	
}
