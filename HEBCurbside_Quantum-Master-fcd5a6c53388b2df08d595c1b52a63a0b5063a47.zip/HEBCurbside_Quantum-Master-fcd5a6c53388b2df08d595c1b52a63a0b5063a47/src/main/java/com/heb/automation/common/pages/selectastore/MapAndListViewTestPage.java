package com.heb.automation.common.pages.selectastore;

import java.util.List;

import com.heb.automation.common.components.StoreBlocksInListView;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MapAndListViewTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "mapandlist.btn.backinheader")
	private QAFWebElement btnBackinheader;

	@FindBy(locator = "mapandlist.li.mapiconslist")
	private List<QAFWebElement> liMapiconslist;

	@FindBy(locator = "mapandlist.btn.save")
	private QAFWebElement btnSave;

	@FindBy(locator = "mapandlist.icon.closelistview")
	private QAFWebElement iconCloselistview;

	@FindBy(locator = "mapandlist.btn.searchhere")
	private QAFWebElement btnSearchhere;

	@FindBy(locator = "mapandlist.li.storeblocksinlistview")
	private List<QAFWebElement> LiStoreblocksinlistview;

	@FindBy(locator = "mapandlist.btn.close")
	private QAFWebElement btnClose;

	public QAFWebElement getBtnClose() {
		return btnClose;
	}

	public List<QAFWebElement> getLiStoreblocksinlistview() {
		return LiStoreblocksinlistview;
	}

	public QAFWebElement getIconCloselistview() {
		return iconCloselistview;
	}

	public QAFWebElement getBtnSave() {
		return btnSave;
	}

	public QAFWebElement getBtnBackinheader() {
		return btnBackinheader;
	}

	public List<QAFWebElement> getLiMapiconslist() {
		return liMapiconslist;
	}

	public QAFWebElement getBtnSearchhere() {
		return btnSearchhere;
	}
}