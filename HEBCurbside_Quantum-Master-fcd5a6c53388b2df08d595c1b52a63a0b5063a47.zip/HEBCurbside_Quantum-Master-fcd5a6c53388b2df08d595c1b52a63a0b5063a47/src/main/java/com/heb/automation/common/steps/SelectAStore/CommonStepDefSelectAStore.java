/**
 * 
 */
package com.heb.automation.common.steps.SelectAStore;

import static com.heb.automation.common.PerfectoUtils.MIN_WAIT_TIME;
import static com.heb.automation.common.PerfectoUtils.VerticalswipeDown;
import static com.heb.automation.common.PerfectoUtils.getDriver;
import static com.heb.automation.common.PerfectoUtils.pressKeyboardSearch;
import static com.heb.automation.common.PerfectoUtils.reportMessage;
import static com.heb.automation.common.PerfectoUtils.verticalswipe;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.HashMap;
import java.util.Map;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MaximizeAction;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.StoreBlocksInListView;
import com.heb.automation.common.pages.appcommon.AppCommonTestPage;
import com.heb.automation.common.pages.homepage.RootViewControllerTestPage;
import com.heb.automation.common.pages.selectastore.ListViewTestPage;
import com.heb.automation.common.pages.selectastore.LocationPermissionPopupTestPage;
import com.heb.automation.common.pages.selectastore.MapAndListViewTestPage;
import com.heb.automation.common.pages.selectastore.SearchStoreErrTestPage;
import com.heb.automation.common.pages.selectastore.SelectAStoreConfirmationTestPage;
import com.heb.automation.common.pages.selectastore.SelectStoreTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
/* List of Steps in CommonStepDefSelectAStore

I am on Select a store homepage
Validate the properties of Select a Store homepage
Click on Near Me and navigate to map and list view page
Verify the properties of Map and list view page
Select back button from the header
Verify the Select a store homepage is getting displayed
Validate the properties of Select a store page with Select button
Select a Store from map View
Verify the Save button is getting displayed
Verify navigated to Map and List view page
Perform the Swipe up operation in Map and List View page
Verify the map view is not displayed
Perform the Swipe down operation
Click on View All option
Verify navigated to Select a Store list view screen
Click on Search option and verify the search screen gets opened
Enter valid search term and select search button
Enter valid search term
Verify the stores are listed for the entered store term
Click on Close button from the header
Verify the entered search term got cleared
*/

public class CommonStepDefSelectAStore {

	/**
	 * Verify the properties of Select A Store HOMEPAGE
	 */
	@QAFTestStep(description = "Validate the properties of Select a Store homepage")
	public void validateThePropertiesOfSelectAStoreHomepage() {
		SelectStoreTestPage selectstore = new SelectStoreTestPage();

		selectstore.getSelectstoreLblPagetitle().waitForPresent(MIN_WAIT_TIME);
		selectstore.getSelectstoreLblPagetitle().verifyPresent();
		selectstore.getImgPageimage().verifyPresent();
		selectstore.getLblPagetext().verifyPresent();
		selectstore.getIconPagenearme().verifyPresent();
		selectstore.getLblPagenearme().verifyPresent();
		selectstore.getIconPagesearch().verifyPresent();
		selectstore.getLblPagesearch().verifyPresent();
		selectstore.getIconPageviewall().verifyPresent();
		selectstore.getLblPageviewall().verifyPresent();
	}

	@QAFTestStep(description = "Click on Near Me and navigate to map and list view page")
	public void clickOnNearMeAndNavigateToMapAndListViewPage() {
		SelectStoreTestPage selectstore = new SelectStoreTestPage();

		selectstore.getIconPagenearme().waitForPresent(MIN_WAIT_TIME);
		selectstore.getIconPagenearme().click();
		reportMessage("Clicked on Nearme option..", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify the properties of Map and list view page")
	public static void verifyThePropertiesOfMapAndListViewPage() {
		AppCommonTestPage appcommon = new AppCommonTestPage();
		StoreBlocksInListView storeblocks = new StoreBlocksInListView();
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();

		appcommon.getTxtEnterzip().waitForPresent(MIN_WAIT_TIME);
		appcommon.getTxtEnterzip().verifyPresent();
		appcommon.getBtnBackinheader().verifyPresent();

		// Validating the map view
		int mapsIconSize = mapandlistview.getLiMapiconslist().size();
		if (mapsIconSize > 0) {
			reportMessage(mapsIconSize + " stores found in map view..", MessageTypes.Pass);
		} else {
			reportMessage("No Stores found in map view..", MessageTypes.Fail);
		}

		// Validating the list view
		int listviewSize = storeblocks.getLblStorename().size();
		if (listviewSize > 0) {
			reportMessage(listviewSize + " stores found in list view..", MessageTypes.Pass);

			for (int i = 0; i < listviewSize - 1; i++) {
				storeblocks.getLblStorename().get(i).verifyPresent();
				storeblocks.getLblStreetaddress().get(i).verifyPresent();
				storeblocks.getLblCitystate().get(i).verifyPresent();
				storeblocks.getLblCurbsidehours().get(i).verifyPresent();
			}

			// for (StoreBlocksInListView ele : listview.getLiListviewblocks())
			// {
			// ele.getLblStorename().verifyPresent();
			// ele.getLblStreetaddress().verifyPresent();
			// ele.getLblCitystate().verifyPresent();
			// ele.getLblCurbsidehours().verifyPresent();
			// break;
			// }

		} else {
			reportMessage("No Stores found in list view..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Select back button from the header")
	public void selectBackButtonFromTheHeader() {
		AppCommonTestPage appcommon = new AppCommonTestPage();

		appcommon.getBtnBackinheader().waitForPresent(MIN_WAIT_TIME);
		appcommon.getBtnBackinheader().click();
		reportMessage("Clicked on back button from header..", MessageTypes.Pass);
		appcommon.getBtnBackinheader().waitForNotPresent(MIN_WAIT_TIME);
	}

	@QAFTestStep(description = "Verify the Select a store homepage is getting displayed")
	public static void verifyTheSelectAStoreHomepageIsGettingDisplayed() {
		SelectStoreTestPage selectstore = new SelectStoreTestPage();

		selectstore.getLblPagetext().waitForPresent(MIN_WAIT_TIME);

		if (selectstore.getLblPagetext().isPresent()) {
			reportMessage("User is in Select a Store homepage..", MessageTypes.Pass);
		} else {
			reportMessage("Error occured while navigating to Select a Store homepage..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Validate the properties of Select a store page with Select button")
	public void validateThePropertiesOfSelectAStorePageWithSelectButton() {
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();

		mapandlistview.getBtnSave().waitForPresent(MIN_WAIT_TIME);
		if (mapandlistview.getBtnSave().isPresent()) {
			reportMessage("Save button is present..", MessageTypes.Pass);
		} else {
			reportMessage("Save button is not present..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Select a Store from map View")
	public void selectAStoreFromMapView() {
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();
		AppCommonTestPage appcommon = new AppCommonTestPage();

		appcommon.getTxtEnterzip().waitForPresent(MIN_WAIT_TIME);
		appcommon.getTxtEnterzip().verifyPresent();
		appcommon.getBtnBackinheader().verifyPresent();

		// Validating the map view
		int mapsIconSize = mapandlistview.getLiMapiconslist().size();
		if (mapsIconSize > 0) {
			reportMessage(mapsIconSize + " stores found in map view..", MessageTypes.Pass);

			mapandlistview.getLiMapiconslist().get(mapsIconSize - 2).waitForPresent(MIN_WAIT_TIME);
			mapandlistview.getLiMapiconslist().get(mapsIconSize - 2).click();
			reportMessage("Clicked on Store Icon from Map view..", MessageTypes.Pass);

		} else {
			reportMessage("No Stores found in map view..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Save button is getting displayed")
	public void verifyTheSaveButtonIsGettingDisplayed() {
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();

		mapandlistview.getBtnSave().waitForPresent(MIN_WAIT_TIME);
		if (mapandlistview.getBtnSave().isPresent()) {
			reportMessage("Save button is present..", MessageTypes.Pass);
		} else {
			reportMessage("Save button is not present..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify navigated to Map and List view page")
	public static void verifyNavigatedToMapAndListViewPage() {
		MapAndListViewTestPage mapandlist = new MapAndListViewTestPage();

		mapandlist.getLiMapiconslist().get(0).waitForPresent(MIN_WAIT_TIME);

		// Validating the map view
		int mapsIconSize = mapandlist.getLiMapiconslist().size();
		if (mapsIconSize > 0) {
			reportMessage("Navigated to map and list view page..", MessageTypes.Pass);
		} else {
			reportMessage("Not navigated to map and list view page..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify navigated to Store details page with Save button")
	public static void verifyNavigatedToStoreDetailsPageWithSaveButton() {
		MapAndListViewTestPage mapandlist = new MapAndListViewTestPage();

		mapandlist.getBtnSave().waitForPresent(MIN_WAIT_TIME);

		// Validating the map view
		if (mapandlist.getBtnSave().isPresent()) {
			reportMessage("Navigated to map and list view page..", MessageTypes.Pass);
		} else {
			reportMessage("Not navigated to map and list view page..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Perform the Swipe up operation in Map and List View page")
	public void performTheSwipeUpOperationInMapAndListViewPage() {
		AppCommonTestPage appcommon = new AppCommonTestPage();

		appcommon.getTxtEnterzip().waitForPresent(MIN_WAIT_TIME);

		if (appcommon.getTxtEnterzip().isPresent()) {
			reportMessage("Navigated to Map and list view page..", MessageTypes.Pass);

			verticalswipe();
			reportMessage("Swiped up..", MessageTypes.Pass);

		} else {
			reportMessage("Not Navigated to Map and list view page..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the map view is not displayed")
	public void verifyTheMapViewIsNotDisplayed() {

		String isStoreIconInMapViewPresent;
		try {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "GROUP:Curbside\\Pics\\SelectStore\\storeiconinmapview.png");
			isStoreIconInMapViewPresent = (String) getDriver().executeScript("mobile:checkpoint:image", params1);
		} catch (Exception e) {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "GROUP:Curbside\\Pics\\SelectStore\\storeiconinmapview.png");
			isStoreIconInMapViewPresent = (String) getDriver().executeScript("mobile:image:find", params1);
		}

		if (isStoreIconInMapViewPresent.equalsIgnoreCase("false"))
			reportMessage("Map view is not displayed..", MessageTypes.Pass);
		else
			reportMessage("Map view is still getting displayed..", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Perform the Swipe down operation")
	public void performTheSwipeDownOperation() {
		AppCommonTestPage appcommon = new AppCommonTestPage();

		appcommon.getTxtEnterzip().waitForPresent(MIN_WAIT_TIME);

		if (appcommon.getTxtEnterzip().isPresent()) {
			reportMessage("Navigated to Map and list view page..", MessageTypes.Pass);

			VerticalswipeDown();
			VerticalswipeDown();
			reportMessage("Swiped down..", MessageTypes.Pass);

		} else {
			reportMessage("Not in Map and list view page..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Click on View All option")
	public void clickOnViewAllOption() {
		SelectStoreTestPage selectstore = new SelectStoreTestPage();

		selectstore.getIconPageviewall().waitForPresent(MIN_WAIT_TIME);
		selectstore.getIconPageviewall().click();
		reportMessage("Clicked on View All option..", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify navigated to Select a Store list view screen")
	public void verifyNavigatedToSelectAStoreListViewScreen() {
		AppCommonTestPage androidcommon = new AppCommonTestPage();
		StoreBlocksInListView storeblocks = new StoreBlocksInListView();

		String searchboxText = getBundle().getString("selectastore.searchboxtext");
		androidcommon.getTxtEnterzip().verifyText(searchboxText);

		int listviewSize = storeblocks.getLblStorename().size();
		if (listviewSize > 0) {
			reportMessage(listviewSize + " stores found in list view..", MessageTypes.Pass);
		} else {
			reportMessage("Not navigated to list view page..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Enter valid search term {0} and select search button")
	public void EnterValidSearchTermAndSelectSearchButton(String searchTerm) {

		enterValidSearchTerm(searchTerm);
		pressKeyboardSearch();
	}

	@QAFTestStep(description = "Enter valid search term {0}")
	public void enterValidSearchTerm(String searchTerm) {
		AppCommonTestPage appCommon = new AppCommonTestPage();

		getBundle().setProperty("enteredStorename", searchTerm);

		appCommon.getTxtEnterzip().waitForPresent(MIN_WAIT_TIME);
		appCommon.getTxtEnterzip().click();
		appCommon.getTxtEnterzip().clear();
		getDriver().getKeyboard().sendKeys(searchTerm);
		reportMessage("Entered Search term: " + searchTerm, MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify the stores are listed for the entered store term")
	public void verifyTheStoresAreListedForTheEnteredStoreTerm() {
		StoreBlocksInListView storeblocks = new StoreBlocksInListView();

		String SearchStore = getBundle().getString("enteredStorename").toLowerCase();

		if (storeblocks.getLblCitystate().get(0).getText().toLowerCase().contains(SearchStore))
			reportMessage("Matched the Search Store: " + SearchStore, MessageTypes.Pass);
		else
			reportMessage("Not Matched the Search store..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Click on Close button from the header")
	public void clickOnCloseButtonFromTheHeader() {
		ListViewTestPage lstViewPge = new ListViewTestPage();

		lstViewPge.getIconSearchclose().waitForPresent(MIN_WAIT_TIME);
		lstViewPge.getIconSearchclose().click();
		reportMessage("Clicked the Close button..", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify the entered search term got cleared")
	public void verifyTheEnteredSearchTermGotCleared() {
		AppCommonTestPage appcommon = new AppCommonTestPage();

		String SearchBoxText = appcommon.getTxtEnterzip().getText();
		if (SearchBoxText.contains("Search City or ZIP")) {
			reportMessage("Entered search term got cleared or removed..", MessageTypes.Pass);
			reportMessage("Search box text: " + SearchBoxText);
		} else {
			reportMessage("Entered search term not cleared or removed: " + SearchBoxText, MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Enter invalid characters {0} and select search button")
	public void enterInvalidCharactersAndSelectSearchButton(String strInvalidStore) {
		AppCommonTestPage commonTestPage = new AppCommonTestPage();

		commonTestPage.getTxtEnterzip().waitForPresent(MIN_WAIT_TIME);
		commonTestPage.getTxtEnterzip().click();
		getDriver().getKeyboard().sendKeys(strInvalidStore);
		PerfectoUtils.pressKeyboardSearch();
	}

	@QAFTestStep(description = "Enter valid characters {0} and select search button")
	public void enterValidCharactersAndSelectSearchButton(String strValidZipCode) {
		AppCommonTestPage commonTestPage = new AppCommonTestPage();

		commonTestPage.getTxtEnterzip().waitForPresent(MIN_WAIT_TIME);
		commonTestPage.getTxtEnterzip().click();
		getDriver().getKeyboard().sendKeys(strValidZipCode);
		PerfectoUtils.pressKeyboardSearch();
	}

	@QAFTestStep(description = "Verify the error screen page is displayed")
	public void verifyTheErrorScreenPageIsDisplayed() {
		SearchStoreErrTestPage SrchStoreErrPge = new SearchStoreErrTestPage();

		SrchStoreErrPge.getSearchstrerrorLblTxtviewmessage().waitForPresent(MIN_WAIT_TIME);
		String strErrMsg = SrchStoreErrPge.getSearchstrerrorLblTxtviewmessage().getText();

		if (SrchStoreErrPge.getSearchstrerrorLblTxtviewmessage().isPresent()) {
			reportMessage(" We Could not find any HEB stores message is displayed..", MessageTypes.Pass);
			reportMessage("Message: " + strErrMsg);
		} else {
			reportMessage("Could not find any HEB stores message is not displayed..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Click on view all curbside stores options")
	public void clickOnViewAllCurbsideStoresOptions() {
		SearchStoreErrTestPage SrchStoreErrPge = new SearchStoreErrTestPage();

		SrchStoreErrPge.getSearchstrerrorLnkLinkviewAllcurbsidestores().waitForPresent(MIN_WAIT_TIME);
		if (SrchStoreErrPge.getSearchstrerrorLnkLinkviewAllcurbsidestores().isPresent()) {
			SrchStoreErrPge.getSearchstrerrorLnkLinkviewAllcurbsidestores().click();
			reportMessage("ViewAll curbside store is clicked..", MessageTypes.Pass);
		} else {
			reportMessage("ViewAll curbside store is not clicked..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify view all curbside stores is displayed")
	public void verifyViewAllCurbsideStoresIsDisplayed() {
		SearchStoreErrTestPage SrchStoreErrPge = new SearchStoreErrTestPage();

		SrchStoreErrPge.getSearchstrerrorLnkLinkviewAllcurbsidestores().waitForPresent(MIN_WAIT_TIME);
		if (SrchStoreErrPge.getSearchstrerrorLnkLinkviewAllcurbsidestores().isPresent())
			reportMessage("ViewAll curbside store is displayed..", MessageTypes.Pass);
		else
			reportMessage("ViewAll curbside store is not displayed..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "User Swipes to a new area in Map View")
	public void userSwipesToANewAreaInMapView() {
		AppCommonTestPage appcommon = new AppCommonTestPage();

		appcommon.getTxtEnterzip().waitForPresent(MIN_WAIT_TIME);

		if (appcommon.getTxtEnterzip().isPresent()) {
			reportMessage("Navigated to Map and list view page..", MessageTypes.Pass);

			PerfectoUtils.mapswipe();
			reportMessage("Swiped to a new area in Map View..", MessageTypes.Pass);

		} else {
			reportMessage("Not Navigated to Map and list view page..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Search here button is present")
	public void verifyTheSearchHereButtonIsPresent() {
		SelectStoreTestPage selectstore = new SelectStoreTestPage();

		selectstore.getLblPagesearch().waitForPresent(MIN_WAIT_TIME);

		if (selectstore.getLblPagesearch().isPresent())
			reportMessage("Search here button is present..", MessageTypes.Pass);
		else
			reportMessage("Search here button is not present..", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Verify no map icons are present")
	public void verifyNoMapIconsArePresent() {
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();

		// Validating the map view
		int mapsIconSize = mapandlistview.getLiMapiconslist().size();

		if (mapsIconSize >= 0) {
			reportMessage("Store icons found in map view..", MessageTypes.Pass);
		} else {
			reportMessage("Stores icons not found in map view..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Click on Search here button")
	public void clickOnSearchHereButton() {
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();

		mapandlistview.getBtnSearchhere().waitForPresent(MIN_WAIT_TIME);
		mapandlistview.getBtnSearchhere().click();
		reportMessage("Clicked on Search Here button..", MessageTypes.Pass);

	}

	@QAFTestStep(description = "Verify map icons are present")
	public void verifyMapIconsArePresent() {
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();

		// Validating the map view
		int mapsIconSize = mapandlistview.getLiMapiconslist().size();

		if (mapsIconSize > 0) {
			reportMessage(mapsIconSize + " Store icons found in map view..", MessageTypes.Pass);
		} else {
			reportMessage("Stores icons not found in map view..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify stores are centered to SA")
	public void verifyStoresAreCenteredToSA() {
		StoreBlocksInListView storeblocks = new StoreBlocksInListView();

		storeblocks.getLblCitystate().get(0).waitForPresent(MIN_WAIT_TIME);

		String cityName = storeblocks.getLblCitystate().get(0).getText();
		String expCityname = getBundle().getString("selectastore.centeredCity");

		if (cityName.contains(expCityname))
			reportMessage(cityName + "City Name displayed in list view..", MessageTypes.Pass);
		else
			reportMessage(cityName + "City Name not displayed in list view..", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Validate the properties of listview page")
	public static void validateThePropertiesOfListviewPage() {
		ListViewTestPage listview = new ListViewTestPage();
		AppCommonTestPage appcommon = new AppCommonTestPage();
		StoreBlocksInListView storeblocks = new StoreBlocksInListView();

		appcommon.getTxtEnterzip().waitForPresent(MIN_WAIT_TIME);
		appcommon.getTxtEnterzip().verifyPresent();
		appcommon.getBtnBackinheader().verifyPresent();

		// Validating the list view
		int listviewSize = listview.getLiListviewblocks().size();
		if (listviewSize > 0) {
			reportMessage(listviewSize + " stores found in list view..", MessageTypes.Pass);

			for (int i = 0; i <= listviewSize; i++) {
				storeblocks.getLblStorename().get(i).verifyPresent();
				storeblocks.getLblStreetaddress().get(i).verifyPresent();
				storeblocks.getLblCitystate().get(i).verifyPresent();
				storeblocks.getLblCurbsidehours().get(i).verifyPresent();
			}

			// for (StoreBlocksInListView ele : listview.getLiListviewblocks())
			// {
			// ele.getLblStorename().verifyPresent();
			// ele.getLblStreetaddress().verifyPresent();
			// ele.getLblCitystate().verifyPresent();
			// ele.getLblCurbsidehours().verifyPresent();
			// break;
			// }
		} else {
			reportMessage("No Stores found in list view..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify No Stores are selected by default")
	public void verifyNoStoresAreSelectedByDefault() {
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();

		if (!mapandlistview.getBtnSave().isPresent()) {
			reportMessage("No Stores are selected by default..", MessageTypes.Pass);
		} else {
			reportMessage("Stores are selected by default..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Perform Zoom in operation from map view")
	public static void performZoomInOperationFromMapView() {
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();

		// Validating the map view
		int mapsIconSize = mapandlistview.getLiMapiconslist().size();

		if (mapsIconSize > 0) {
			PerfectoUtils.zoomIn();
			reportMessage("Zoomed in..", MessageTypes.Pass);
		} else {
			reportMessage("Stores icons not found in map view..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Perform Zoom out operation from map view")
	public static void performZoomOutOperationFromMapView() {
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();

		// Validating the map view
		int mapsIconSize = mapandlistview.getLiMapiconslist().size();

		if (mapsIconSize > 0) {
			PerfectoUtils.zoomOut();
			reportMessage("Zoomed Out..", MessageTypes.Pass);
		} else {
			reportMessage("Stores icons not found in map view..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the entered store name is still available in the search box")
	public void verifyTheEnteredStoreNameIsStillAvailableInTheSearchBox() {
		AppCommonTestPage appcommon = new AppCommonTestPage();

		appcommon.getTxtEnterzip().waitForPresent(MIN_WAIT_TIME);

		String enteredStorename = getBundle().getString("enteredStorename");
		String textFromSearchbox = appcommon.getTxtEnterzip().getText();

		if (enteredStorename.equals(textFromSearchbox))
			reportMessage("Entered Storename is still available in the Search box..", MessageTypes.Pass);
		else
			reportMessage("Entered Storename is not available in the Search box..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Click the Save button for selecting store")
	public void clickTheSaveButtonForSelectingStore() {
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();

		mapandlistview.getBtnSave().waitForPresent(MIN_WAIT_TIME);
		if (mapandlistview.getBtnSave().isPresent()) {
			mapandlistview.getBtnSave().click();
			reportMessage("Save button is Clicked..", MessageTypes.Pass);
		} else {
			reportMessage("Save button is not Clicked..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Select a store confirmation page is displayed")
	public void verifyTheSelectAStoreConfirmationPageIsDisplayed() {
		SelectAStoreConfirmationTestPage selectConfirmPge = new SelectAStoreConfirmationTestPage();

		selectConfirmPge.getLblPageheader().waitForPresent(MIN_WAIT_TIME);
		if (selectConfirmPge.getLblPageheader().isPresent()) {
			selectConfirmPge.getBtnOkgotit().isPresent();
			reportMessage("Select a Store name Confirmation page is displayed..", MessageTypes.Pass);
		} else
			reportMessage("Select a Store name Confirmation page is not displayed..", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Clicks on Nearme option")
	public static void clicksOnNearmeOption() {
		SelectStoreTestPage selstore = new SelectStoreTestPage();

		selstore.getLblPagenearme().waitForPresent(MIN_WAIT_TIME);
		selstore.getLblPagenearme().click();
		reportMessage("Clicked on Near Me from homepage..", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify the Location popup is getting displayed")
	public static void verifyTheLocationPopupIsGettingDisplayed() {
		LocationPermissionPopupTestPage locpermission = new LocationPermissionPopupTestPage();

		locpermission.getLblHeadertitle().waitForPresent(MIN_WAIT_TIME);

		if (locpermission.getLblHeadertitle().verifyPresent())
			reportMessage("Location popup is getting displayed", MessageTypes.Pass);
		else
			reportMessage("Location popup is not getting displayed", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Click on Allow button from the location permission popup")
	public void clickOnAllowButtonFromTheLocationPermissionPopup() {
		LocationPermissionPopupTestPage locpermission = new LocationPermissionPopupTestPage();

		locpermission.getBtnAllow().waitForPresent(MIN_WAIT_TIME);
		locpermission.getBtnAllow().click();
		reportMessage("Clicked on Allow button from location permission popup..", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Click on Decline button from the location permission popup")
	public static void clickOnDeclineButtonFromTheLocationPermissionPopup() {
		LocationPermissionPopupTestPage locpermission = new LocationPermissionPopupTestPage();

		locpermission.getBtnDontallow().waitForPresent(MIN_WAIT_TIME);
		locpermission.getBtnDontallow().click();
		reportMessage("Clicked on Don't Allow button from location permission popup..", MessageTypes.Pass);
	}

	@QAFTestStep(description = "verify the Location dialog popup is getting displayed")
	public static void verifyTheLocationDialogPopupIsGettingDisplayed() {
		LocationPermissionPopupTestPage locpermission = new LocationPermissionPopupTestPage();

		// locpermission.getLblLocationdialog().waitForPresent(MIN_WAIT_TIME);

		if (locpermission.getLblLocationdialog().isPresent())
			reportMessage("Location dialog popup is getting displayed", MessageTypes.Pass);
		else
			reportMessage("Location dialog popup is not getting displayed", MessageTypes.Fail);

		locpermission.getBtnAllow().verifyPresent();
		locpermission.getBtnAllow().click();
	}

	@QAFTestStep(description = "clicks on Settings button or link")
	public static void clicksOnSettingsButtonOrLink() {
		LocationPermissionPopupTestPage locpermission = new LocationPermissionPopupTestPage();

		locpermission.getLblLocationpopupsettings().waitForPresent(MIN_WAIT_TIME);

		if (locpermission.getLblLocationpopupsettings().verifyPresent()) {
			locpermission.getLblLocationpopupsettings().click();
			reportMessage("Location dialog popup Settings has got clicked", MessageTypes.Pass);
		} else {
			reportMessage("Location dialog popup Settings has not got clicked", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "verify page navigates to device settings page")
	public static void verifyPageNavigatesToDeviceSettingsPage() {
		LocationPermissionPopupTestPage locpermission = new LocationPermissionPopupTestPage();

		locpermission.getLblLocationsettings().waitForPresent(MIN_WAIT_TIME);

		if (locpermission.getLblLocationsettings().verifyPresent())
			reportMessage("Settings page is displayed", MessageTypes.Pass);
		else
			reportMessage("Settings page is not displayed", MessageTypes.Fail);
	}

	@QAFTestStep(description = "clicks on Search button or link")
	public static void clicksOnSearchButtonOrLink() {
		LocationPermissionPopupTestPage locpermission = new LocationPermissionPopupTestPage();

		locpermission.getLblLocationpopupsearch().waitForPresent(MIN_WAIT_TIME);

		if (locpermission.getLblLocationpopupsearch().verifyPresent()) {
			locpermission.getLblLocationpopupsearch().click();
			reportMessage("Location dialog popup Search has got clicked", MessageTypes.Pass);
		} else {
			reportMessage("Location dialog popup Search has not got clicked", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "clicks on Cancel button or link")
	public static void clicksOnCancelButtonOrLink() {
		LocationPermissionPopupTestPage locpermission = new LocationPermissionPopupTestPage();

		locpermission.getLblLocationpopupcancel().waitForPresent(MIN_WAIT_TIME);

		if (locpermission.getLblLocationpopupcancel().verifyPresent()) {
			locpermission.getLblLocationpopupcancel().click();
			reportMessage("Location dialog popup Cancel has got clicked", MessageTypes.Pass);
		} else {
			reportMessage("Location dialog popup Cancel has not got clicked", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "User closes and reopen the application")
	public static void userClosesAndReopenTheApplication() {

		PerfectoUtils.closeApplication(getBundle().getString("app.name"));
		PerfectoUtils.openApplication(PerfectoUtils.getDriver(), getBundle().getString("app.name"));
	}

	@QAFTestStep(description = "Turns off the location services")
	public static void turnsOffTheLocationServices() {
		clicksOnNearmeOption();
		verifyTheLocationPopupIsGettingDisplayed();
		clickOnDeclineButtonFromTheLocationPermissionPopup();
		verifyTheSelectAStoreHomepageIsGettingDisplayed();
	}

	@QAFTestStep(description = "Verify non curbside stores are not listed in listview page")
	public static void verifyNonCurbsideStoresAreNotListedInListviewPage() {
		ListViewTestPage listview = new ListViewTestPage();
		StoreBlocksInListView storeblocks = new StoreBlocksInListView();

		boolean isPresent = false;
		String noncurbsidestore = getBundle().getString("selectastore.noncurbside");

		// Validating the list view
		int listviewSize = listview.getLiListviewblocks().size();
		if (listviewSize > 0) {
			reportMessage(listviewSize + " stores found in list view..", MessageTypes.Pass);

			for (int i = 0; i <= listviewSize; i++) {

				if (storeblocks.getLblStorename().get(i).getText().equalsIgnoreCase(noncurbsidestore)) {
					isPresent = true;
					break;
				}
			}

			// Validation
			if (!isPresent)
				reportMessage("Non-curbside stores are not listed..", MessageTypes.Pass);
			else
				reportMessage("Non-curbside stores are listed..", MessageTypes.Fail);

		} else {
			reportMessage("No Stores found in list view..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify device back button is disabled")
	public static void verifyDeviceBackButtonIsDisabled() {
		LocationPermissionPopupTestPage locpermission = new LocationPermissionPopupTestPage();

		PerfectoUtils.androiddeviceback();

		locpermission.getBtnAllow().waitForPresent(MIN_WAIT_TIME);
		if (locpermission.getBtnAllow().isPresent())
			reportMessage("Device back button is disabled..", MessageTypes.Pass);
		else
			reportMessage("Device back button is not disabled..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Navigate to Select a store homepage")
	public void navigateToSelectAStoreHomepage() {
		SelectStoreTestPage selectstore = new SelectStoreTestPage();
		RootViewControllerTestPage rvc = new RootViewControllerTestPage();

		rvc.getBtnTostoresearch().waitForPresent(MIN_WAIT_TIME);
		rvc.getBtnTostoresearch().click();
		reportMessage("Clicked on- To Store Search buton..", MessageTypes.Pass);

		selectstore.getSelectstoreLblPagetitle().waitForPresent(MIN_WAIT_TIME);

		if (selectstore.getSelectstoreLblPagetitle().isDisplayed())
			reportMessage("Navigated to Select A Store Page..", MessageTypes.Pass);
		else
			reportMessage("Not Navigated to Select A Store Page..", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Click on back button from the header")
	public void clickOnBackButtonFromTheHeader() {
		AppCommonTestPage AppCommonPage = new AppCommonTestPage();

		AppCommonPage.getBtnBackinheader().waitForPresent(MIN_WAIT_TIME);
		if (AppCommonPage.getBtnBackinheader().isPresent()) {
			AppCommonPage.getBtnBackinheader().click();
			reportMessage("Header button has got clicked..", MessageTypes.Pass);
		} else {
			reportMessage("Header button has not been clicked..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify phone Image is displayed in select a store homepage")
	public void verifyPhoneImageIsDisplayedInSelectAStoreHomepage() {
		SearchStoreErrTestPage selectStoreErrPge = new SearchStoreErrTestPage();

		selectStoreErrPge.getImgPageerrimage().waitForPresent(MIN_WAIT_TIME);
		if (selectStoreErrPge.getImgPageerrimage().isPresent())
			reportMessage("Phone Image is displayed in Error message page..", MessageTypes.Pass);
		else
			reportMessage("Phone Image is not displayed in Error message page..", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Verify re-prompt displayed")
	public static void verifyRepromptDisplayed() {
		LocationPermissionPopupTestPage locpermission = new LocationPermissionPopupTestPage();

		// locpermission.getLblHeadertitle().waitForPresent(MIN_WAIT_TIME);

		if (locpermission.getLblHeadertitle().verifyPresent())
			reportMessage("Location popup is getting displayed", MessageTypes.Pass);
		else
			reportMessage("Location popup is not getting displayed", MessageTypes.Fail);
	}

}
