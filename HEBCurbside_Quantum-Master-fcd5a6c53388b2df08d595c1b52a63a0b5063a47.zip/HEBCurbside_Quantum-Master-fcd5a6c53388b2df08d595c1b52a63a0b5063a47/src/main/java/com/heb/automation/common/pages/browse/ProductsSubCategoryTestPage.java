package com.heb.automation.common.pages.browse;

import java.util.List;

import com.heb.automation.common.components.Products.ProductsCDPSubcategoryBlocks;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ProductsSubCategoryTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "productsubcat.lnk.viewAll")
	private QAFWebElement lnkViewAll;

	@FindBy(locator = "productsubcat.li.specifiedsubcategoryblocks")
	private List<QAFWebElement> liSpecifiedsubcategoryblocks;

	@FindBy(locator = "productsubcat.lbl.pageheader")
	private QAFWebElement lblPageheader;

	@FindBy(locator = "productsubcat.lbl.allsubproducts")
	private QAFWebElement lblAllsubproducts;

	@FindBy(locator = "productsubcat.btn.back")
	private QAFWebElement btnBack;

	@FindBy(locator = "productsubcat.btn.donekey")
	private QAFWebElement btnDonekey;

	@FindBy(locator = "productscdp.btn.subcatproductDonebutton")
	private QAFWebElement btnSubcatproductDonebutton;

	@FindBy(locator = "productsubcat.btn.doneKeygreyedout")
	private QAFWebElement btnDoneKeygreyedout;

	@FindBy(locator = "productsubcat.txt.minqtypdt")
	private QAFWebElement txtMinqtypdt;

	public QAFWebElement getTxtMinqtypdt() {
		return txtMinqtypdt;
	}

	public QAFWebElement getBtnDoneKeygreyedout() {
		return btnDoneKeygreyedout;
	}

	public QAFWebElement getBtnSubcatproductDonebutton() {
		return btnSubcatproductDonebutton;
	}

	public QAFWebElement getBtnDonekey() {
		return btnDonekey;
	}

	@FindBy(locator = "productsubcat.lbl.cartnumber")
	private QAFWebElement lblCartnumber;

	public QAFWebElement getLblCartnumber() {
		return lblCartnumber;
	}

	@FindBy(locator = "productsubcat.txt.subcatchar")
	private QAFWebElement txtSubcatchar;

	@FindBy(locator = "productsubcat.li.subcategoryproducts")
	private List<QAFWebElement> liSubcategoryproducts;

	@FindBy(locator = "productsubcat.li.addbuttonlist")
	private List<QAFWebElement> liAddbuttonlist;

	@FindBy(locator = "productsubcat.btn.addbuttonperweight")
	private List<QAFWebElement> btnAddButtonperweight;

	public QAFWebElement getLblAllsubproducts() {
		return lblAllsubproducts;
	}

	@FindBy(locator = "productsubcat.li.lastlevelpdts")
	private List<QAFWebElement> listLastlevelPdts;

	@FindBy(locator = "productsubcat.li.headercategorieslist")
	private List<QAFWebElement> liHeadercategorieslist;

	@FindBy(locator = "productsubcat.txt.dateAndtime")
	private QAFWebElement txtDateAndtime;

	@FindBy(locator = "productsubcat.txt.qtyfor$")
	private QAFWebElement txtQtyFor$;

	@FindBy(locator = "productsubcat.txt.addqty")
	private QAFWebElement txtAddQty;

	@FindBy(locator = "productsubcat.txt.qtyfield")
	private QAFWebElement txtQtyField;

	@FindBy(locator = "productsubcat.txt.plusicon")
	private QAFWebElement txtPlusIcon;

	@FindBy(locator = "productsubcat.txt.minusicon")
	private QAFWebElement txtMinusIcon;

	@FindBy(locator = "productsubcat.txt.minmaxpdt")
	private QAFWebElement txtMinMaxPdt;

	@FindBy(locator = "productscdp.btn.subaddproduct")
	private QAFWebElement btnSubaddproduct;

	@FindBy(locator = "productsubcat.lis.additem")   
	private List<QAFWebElement> lisAddItem;

	@FindBy(locator = "productsubcat.lis.subtractitem")
	private List<QAFWebElement> lisSubtractItem;

	public QAFWebElement getTxtDateAndtime() {
		return txtDateAndtime;
	}

	public List<QAFWebElement> getLiHeadercategorieslist() {
		return liHeadercategorieslist;
	}

	public List<QAFWebElement> getBtnAddButtonperweight() {
		return btnAddButtonperweight;
	}

	// DYNAMIC value declaring
	public QAFWebElement getLblTopelevelcatnamedynamic(String lable) {
		String loc = String.format(pageProps.getString("productsubcat.lbl.toplevelsubcatnamedynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getLblPageheader() {
		return lblPageheader;
	}

	public List<QAFWebElement> getLiSpecifiedsubcategoryblocks() {
		return liSpecifiedsubcategoryblocks;
	}

	public QAFWebElement getLnkViewAll() {
		return lnkViewAll;
	}

	public List<QAFWebElement> getLiSubcategoryproducts() {
		return liSubcategoryproducts;
	}

	public QAFWebElement getTxtSubcatchar() {
		return txtSubcatchar;
	}

	public QAFWebElement getBtnBack() {
		return btnBack;
	}

	public List<QAFWebElement> getLiAddbuttonlist() {
		return liAddbuttonlist;
	}

	public List<QAFWebElement> getListLastlevelPdts() {
		return listLastlevelPdts;
	}

	public QAFWebElement getTxtQtyFor$() {
		return txtQtyFor$;
	}

	public QAFWebElement getTxtAddQty() {
		return txtAddQty;
	}

	public QAFWebElement getTxtQtyField() {
		return txtQtyField;
	}

	public QAFWebElement getTxtPlusIcon() {
		return txtPlusIcon;
	}

	public QAFWebElement getTxtMinusIcon() {
		return txtMinusIcon;
	}

	public QAFWebElement getTxtMinMaxPdt() {    
		return txtMinMaxPdt;
	}
	
	public List<QAFWebElement> getLisAddItem(){
		return lisAddItem;
	}
	
	public List<QAFWebElement> getLisSubtractItem(){
		return lisSubtractItem;
	}

}