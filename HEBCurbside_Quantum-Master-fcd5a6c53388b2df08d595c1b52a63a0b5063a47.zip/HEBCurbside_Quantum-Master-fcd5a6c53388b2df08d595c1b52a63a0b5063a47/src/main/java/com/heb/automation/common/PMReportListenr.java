package com.heb.automation.common;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import com.qmetry.qaf.automation.step.StepExecutionTracker;
import com.qmetry.qaf.automation.step.client.TestNGScenario;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.perfecto.reportium.client.ReportiumClient;
import com.perfecto.reportium.client.ReportiumClientFactory;
import com.perfecto.reportium.model.PerfectoExecutionContext;
import com.perfecto.reportium.model.Project;
import com.perfecto.reportium.test.TestContext;
import com.perfecto.reportium.test.result.TestResultFactory;
public class PMReportListenr extends TestListenerAdapter {
	
	public static final String PERFECTO_REPORT_CLIENT = "perfecto.report.client";

	@Override
	public void onTestStart(ITestResult testResult) {
		 QAFExtendedWebDriver driver = new WebDriverTestBase().getDriver();
		 String prjName = testResult.getTestContext().getName();
		 String contextName =
		 testResult.getTestContext().getSuite().getName();
		 PerfectoExecutionContext perfectoExecutionContext = new
		 PerfectoExecutionContext.PerfectoExecutionContextBuilder()
		 .withProject(new Project(prjName,
		 "1.0")).withContextTags(contextName).withWebDriver(driver).build();
		 ReportiumClient reportClient = new ReportiumClientFactory()
		 .createPerfectoReportiumClient(perfectoExecutionContext);
		 TestContext context = new
		 TestContext(testResult.getMethod().getGroups());
		 reportClient.testStart(testResult.getMethod().getMethodName(),
		 context);
		 ((TestNGScenario)
		 testResult.getMethod()).getMetaData().put("Perfecto-report",
		 "<a href=\""+reportClient.getReportUrl()+"\" target=\"_blank\">view</a>");
		 getBundle().setProperty(PERFECTO_REPORT_CLIENT, reportClient);

	}

	public void beforExecute(StepExecutionTracker stepExecutionTracker) {
		try {
			
			ReportiumClient reportClient = (ReportiumClient) getBundle().getObject(PERFECTO_REPORT_CLIENT);
			reportClient.testStep(stepExecutionTracker.getStep().getDescription());
		} catch (Exception e) {
			/** 
			 * ignore
			 */
		}
	}

	@Override
	public void onTestSuccess(ITestResult testResult)	 {
		 ReportiumClient reportClient = (ReportiumClient)
		 getBundle().getObject(PERFECTO_REPORT_CLIENT);
		 reportClient.testStop(TestResultFactory.createSuccess());
	}

	@Override
	public void onTestFailure(ITestResult testResult) {
		 ReportiumClient reportClient = (ReportiumClient)
		 getBundle().getObject(PERFECTO_REPORT_CLIENT);
		 reportClient.testStop(TestResultFactory.createFailure("An error occurred", testResult.getThrowable()));
	}

}
