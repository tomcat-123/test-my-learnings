package com.heb.automation.ios.pages.ioscommon;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class IOSCommonTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "ioscommon.btn.tabbarproducts")
	private QAFWebElement btnTabbarproducts;

	@FindBy(locator = "ioscommon.btn.tabbarcart")
	private QAFWebElement btnTabbarcart;

	@FindBy(locator = "ioscommon.btn.tabbarprofile")
	private QAFWebElement btnTabbarprofile;
	
	
	@FindBy(locator = "productsubcat.btn.addbuttonperweight")
	private QAFWebElement btnAaddbuttonperweight;
	
	@FindBy(locator = "productsubcat.txt.maxqtyalert")
	private QAFWebElement txtMaxqtyalert;
	
	
	@FindBy(locator = "productslp.lbl.pickuptime")
	private QAFWebElement lblPickuptime;
	
	
	@FindBy(locator = "productslp.lbl.placeholderselection")
	private QAFWebElement lblPlaceholderselection;
	
	@FindBy(locator = "productsubcat.btn.addminqty")
	private QAFWebElement btnAddminqty;
	
	@FindBy(locator = "productsubcat.txt.minqtyalert")
	private QAFWebElement txtMinqtyalert;
	
	@FindBy(locator = "productsubcat.txt.minqtytext")
	private QAFWebElement txtMinqtytext;

	@FindBy(locator = "productsubcat.li.qtyeachlist")
	private QAFWebElement liQtyeachlist;
	
	@FindBy(locator = "productsubcat.li.productsname")
	private QAFWebElement liProductsname;
	
	@FindBy(locator = "productsubcat.btn.productclose")
	private QAFWebElement btnproductclose;
	
	@FindBy(locator = "productsubcat.btn.plussubqty")
	private QAFWebElement btnPlussubqty;
	
	@FindBy(locator = "productsubcat.btn.minussubqty")
	private QAFWebElement btnMinussubqty;
	
	@FindBy(locator = "productsubcat.txt.subqtyitem")
	private QAFWebElement txtSubqtyitem ;

	@FindBy(locator = "productslp.li.lbl.productavailablity")
	private List <QAFWebElement> liLblProductavailablity;
	

	@FindBy(locator = "productscdp.li.browseProducts")
	private List <QAFWebElement> liBrowseProducts;
	
	public List<QAFWebElement> getLiBrowseProducts() {
		return liBrowseProducts;
	}

	public QAFWebElement getBtnAaddbuttonperweight() {
		return btnAaddbuttonperweight;
	}

	public QAFWebElement getBtnTabbarproducts() {
		return btnTabbarproducts;
	}

	public QAFWebElement getBtnTabbarcart() {
		return btnTabbarcart;
	}

	public QAFWebElement getBtnTabbarprofile() {
		return btnTabbarprofile;
	}

	public QAFWebElement getLblPickuptime() {
		return lblPickuptime;
	}

	public QAFWebElement getTxtMaxqtyalert() {
		return txtMaxqtyalert;
	}
	
	public QAFWebElement getLblPlaceholderselection() {
		return lblPlaceholderselection;
	}
	
	public List<QAFWebElement> getLiLblProductavailablity() {
		return liLblProductavailablity;
	}
	
	public QAFWebElement getBtnAddminqty() {
		return btnAddminqty;
	}
	
	public QAFWebElement getTxtMinqtyalert() {
		return txtMinqtyalert;
	}
	
	public QAFWebElement getTxtMinqtytext() {
		return txtMinqtytext;
	}
	
	public QAFWebElement getLiQtyeachlist() {
		return liQtyeachlist;
	}
	public QAFWebElement getLiProductsname() {
		return liProductsname;
	}


	public QAFWebElement getBtnproductclose() {
		return btnproductclose;
	}
	
	public QAFWebElement getBtnPlussubqty() {
		return btnPlussubqty;
	}

	public QAFWebElement getBtnMinussubqty() {
		return btnMinussubqty;
	}
	
	public QAFWebElement getTxtSubqtyitem() {
		return txtSubqtyitem;
	}
	
}