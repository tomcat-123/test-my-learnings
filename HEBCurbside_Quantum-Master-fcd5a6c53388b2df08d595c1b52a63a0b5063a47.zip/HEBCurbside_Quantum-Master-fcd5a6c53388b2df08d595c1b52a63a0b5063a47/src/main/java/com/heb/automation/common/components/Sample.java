package com.heb.automation.common.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class Sample extends QAFWebComponent {

	@FindBy(locator = "sample.lbl.locatorname")
	private QAFWebElement lblLocatorname;
	
	public Sample(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}
	
	public QAFWebElement getLblLocatorname() {
		return lblLocatorname;
	}
	
}