/**
 * 
 */
package com.heb.automation.ios.steps.SelectAStore;

import static com.heb.automation.common.PerfectoUtils.MIN_WAIT_TIME;
import static com.heb.automation.common.PerfectoUtils.reportMessage;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.HashMap;
import java.util.Map;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.StoreBlocksInListView;
import com.heb.automation.common.pages.appcommon.AppCommonTestPage;
import com.heb.automation.common.pages.selectastore.ListViewTestPage;
import com.heb.automation.common.pages.selectastore.LocationPermissionPopupTestPage;
import com.heb.automation.common.pages.selectastore.MapAndListViewTestPage;
import com.heb.automation.common.pages.selectastore.SelectAStoreConfirmationTestPage;
import com.heb.automation.common.pages.selectastore.SelectStoreTestPage;
import com.heb.automation.common.steps.SelectAStore.CommonStepDefSelectAStore;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;

/*List of Steps in IOSStepDefSelectStore

Verify navigates back to Map and List view page on selecting close icon
Verify the Map view is getting displayed
Select a Store from List View
*/
public class IOSStepDefSelectAStore {

	@QAFTestStep(description = "Verify navigates back to Map and List view page on selecting close icon")
	public void verifyNavigatesBackToMapAndListViewPageOnSelectingCloseIcon() {

		SelectCloseButtonFromTheBottomOfTheScreen();
		CommonStepDefSelectAStore.verifyThePropertiesOfMapAndListViewPage();
	}

	private void SelectCloseButtonFromTheBottomOfTheScreen() {
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();

		mapandlistview.getIconCloselistview().waitForPresent(MIN_WAIT_TIME);
		mapandlistview.getIconCloselistview().click();
		PerfectoUtils.reportMessage("Clicked on Close Icon near the list view..", MessageTypes.Pass);

	}

	@QAFTestStep(description = "Verify the Map view is getting displayed")
	public void verifyTheMapViewIsGettingDisplayed() {
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();

		// Validating the map view
		int mapsIconSize = mapandlistview.getLiMapiconslist().size();
		if (mapsIconSize > 0) {
			reportMessage("Map view is getting diaplayed..", MessageTypes.Pass);
			reportMessage(mapsIconSize + " stores found in map view..");
		} else {
			reportMessage("Map View is not displayed..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Select a Store from List View")
	public void selectAStoreFromListView() {
		StoreBlocksInListView storeblocks = new StoreBlocksInListView();

		// Validating the list view
		int listviewSize = storeblocks.getLblStorename().size();
		if (listviewSize > 0) {
			reportMessage(listviewSize + " stores found in list view..", MessageTypes.Pass);
			storeblocks.getLblStorename().get(listviewSize - 1).waitForPresent(MIN_WAIT_TIME);
			String storename = storeblocks.getLblStorename().get(listviewSize - 1).getText();
			storeblocks.getLblStorename().get(listviewSize - 1).click();
			reportMessage("Clicked on Store name: " + storename + " from list view..", MessageTypes.Pass);
		} else {
			reportMessage("No Stores found in list view..", MessageTypes.Fail);
		}
	}

	/**
	 * Select on Search Option
	 */
	@QAFTestStep(description = "Click on Search option and verify the search screen gets opened")
	public void ClickOnSearchOptionAndVerifyTheSearchScreenGetsOpened() {
		SelectStoreTestPage selectstore = new SelectStoreTestPage();
		AppCommonTestPage androidcommon = new AppCommonTestPage();

		selectstore.getLblPagesearch().waitForPresent(MIN_WAIT_TIME);
		selectstore.getLblPagesearch().click();
		reportMessage("Clicked on Search option successfully..", MessageTypes.Pass);

		// Verify the Keyboard is opened
		/* verifyKeyBoardOpened(); */

		// Validating the hint text
		String searchboxText = getBundle().getString("selectastore.searchboxtext");
		androidcommon.getTxtEnterzip().verifyText(searchboxText);
	}

	public void verifyKeyBoardOpened() {
		try {

			String iosKeyboardSpaceImage = getBundle().getString("selectastore.iosKeyboardSpaceImage");

			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", iosKeyboardSpaceImage);
			String result = (String) PerfectoUtils.getDriver().executeScript("mobile:checkpoint:image", params1);

			if (result.equals("true"))
				reportMessage("Clicking on Search Icon from the homepage brings up the Keyboard..", MessageTypes.Pass);
			else
				reportMessage("Clicking on Search Icon from the homepage doen't bring up the Keyboard..",
						MessageTypes.Fail);
		} catch (Exception e) {
			reportMessage("Error occured while Validating the Keyboard..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Click on device back button")
	public void ClickOnBackButton() {
		reportMessage("NA for iOS..");

	}

	@QAFTestStep(description = "Verify navigated to Select a store homepage from confirmation page")
	public void verifyNavigatedToSelectAStoreHomepageFromConfirmationPage() {
		reportMessage("NA for iOS..");
	}

	@QAFTestStep(description = "Click on device back button/Back button from confirmation page")
	public void clickOnDeviceBackButtonBackButtonFromConfirmationPage() {
		reportMessage("NA for iOS..");
	}

	@QAFTestStep(description = "Click on back button from the header from confirmation page")
	public void clickOnBackButtonFromTheHeaderFromConfirmationPage() {
		AppCommonTestPage AppCommonPage = new AppCommonTestPage();

		AppCommonPage.getBtnBackinheader().waitForPresent(MIN_WAIT_TIME);
		if (AppCommonPage.getBtnBackinheader().isPresent()) {
			AppCommonPage.getBtnBackinheader().click();
			reportMessage("Header button has got clicked..", MessageTypes.Pass);
		} else {
			reportMessage("Header button has not been clicked..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Click on Back button from confirmation page")
	public void clickOnBackButtonFromConfirmationPage() {
		AppCommonTestPage appcommon = new AppCommonTestPage();

		appcommon.getBtnBackinheader().waitForPresent(MIN_WAIT_TIME);
		if (appcommon.getBtnBackinheader().isPresent()) {
			appcommon.getBtnBackinheader().click();
			reportMessage("Back button is clicked from Confirmation page..", MessageTypes.Pass);
		} else
			reportMessage("Back button is not clicked from Confirmation page..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify navigated to Store and map view page from confirmation page")
	public void verifyNavigatedToStoreAndMapViewPageFromConfirmationPage() {
		verifyTheMapViewIsGettingDisplayed();
	}

	@QAFTestStep(description = "Verify Navgated to Select a Store Homepage from popup page")
	public void verifyNavgatedToSelectAStoreHomepageFromPopupPage() {
		reportMessage("NA for iOS..");
	}

	@QAFTestStep(description = "Verify the properties of select a store confirmation page")
	public void verifyThePropertiesOfSelectAStoreConfirmationPage() {
		SelectAStoreConfirmationTestPage selectConfirmPge = new SelectAStoreConfirmationTestPage();

		selectConfirmPge.getImgStoremarkerview().waitForPresent(MIN_WAIT_TIME);
		selectConfirmPge.getLblPageheader().verifyPresent();
		selectConfirmPge.getImgStoremarkerview().verifyPresent();
		selectConfirmPge.getBtnOkgotit().verifyPresent();
	}

	@QAFTestStep(description = "Verify the properties of Location permission first time popup")
	public void verifyThePropertiesOfLocationPermissionFirstTimePopup() {
		LocationPermissionPopupTestPage locpermission = new LocationPermissionPopupTestPage();

		locpermission.getLblHeadertitle().waitForPresent(MIN_WAIT_TIME);
		locpermission.getLblHeadertitle().verifyPresent();
		locpermission.getLblHeadersubtitle().verifyPresent();
		locpermission.getBtnAllow().verifyPresent();
		locpermission.getBtnDontallow().verifyPresent();
	}

	@QAFTestStep(description = "Verify the properties of Location permission Re-prompt Popup")
	public void verifyThePropertiesOfLocationPermissionRepromptPopup() {
		reportMessage("Yet to add.. pending due to the issue..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify re-prompt displayed")
	public static void verifyRepromptDisplayed() {

		reportMessage("To be added.. Re-prompt getting displayed..", MessageTypes.Fail);
	}

}
