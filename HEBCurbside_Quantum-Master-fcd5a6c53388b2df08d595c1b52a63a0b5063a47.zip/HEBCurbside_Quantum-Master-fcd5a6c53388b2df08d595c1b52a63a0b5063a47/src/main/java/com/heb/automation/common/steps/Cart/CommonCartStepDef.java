/**
 * 
 */
package com.heb.automation.common.steps.Cart;

import static com.heb.automation.common.PerfectoUtils.reportMessage;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.HashMap;
import java.util.Map;

import javax.security.auth.login.Configuration;

import static com.heb.automation.common.PerfectoUtils.MIN_WAIT_TIME;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.Products.ProductsCDPSubcategoryBlocks;
import com.heb.automation.common.components.Products.ProductsCDPSubcategoryProductBlocks;
import com.heb.automation.common.pages.Cart.CartLandingTestPage;
import com.heb.automation.common.pages.browse.ProductsCDPTestPage;
import com.heb.automation.common.pages.browse.ProductsLandingTestPage;
import com.heb.automation.common.pages.browse.ProductsSubCategoryTestPage;
import com.heb.automation.common.pages.homepage.RootViewControllerTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

/*
 * 
	"I add {0} item to the cart"
	"I verify user navigates to the cart page"
	"I verify product card will display"
	"Verify the Product to be added to cart"
	
 */
public class CommonCartStepDef {

	@QAFTestStep(description = "I verify the Next Pickup placeholder is scrolling up")
	public void iVerifyTheNextPickupPlaceholderIsScrollingUp() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.getTxtDateAndtime().verifyPresent();
		PerfectoUtils.verticalswipe();
		reportMessage("srolling..", MessageTypes.Info);
		if (!pdtsubcat.getTxtDateAndtime().isPresent()) {
			reportMessage("user is able to scroll Next Pickup placeholder", MessageTypes.Pass);
		} else {
			reportMessage("Next Pickup placeholder is not scrolling", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I verify the Next Pickup placeholder will not scroll up")
	public void iVerifyTheNextPickupPlaceholderWillNotScrollUp() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.getTxtDateAndtime().verifyPresent();
		PerfectoUtils.verticalswipe();
		if (pdtsubcat.getTxtDateAndtime().isPresent()) {
			reportMessage("Next Pickup placeholder is not scrolling", MessageTypes.Pass);
		} else {
			reportMessage("user is able to scroll Next Pickup placeholder", MessageTypes.Fail);
		}

	}
}
