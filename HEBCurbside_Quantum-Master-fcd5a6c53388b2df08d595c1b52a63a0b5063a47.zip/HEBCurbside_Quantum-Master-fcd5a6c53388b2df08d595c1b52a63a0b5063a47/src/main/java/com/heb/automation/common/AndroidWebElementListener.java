package com.heb.automation.common;

import org.openqa.selenium.remote.DriverCommand;

import com.qmetry.qaf.automation.ui.webdriver.CommandTracker;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElementCommandAdapter;

public class AndroidWebElementListener extends QAFWebElementCommandAdapter {
	public void afterCommand(QAFExtendedWebElement element, CommandTracker commandTracker) {
		try {
			if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.SEND_KEYS_TO_ELEMENT)) {
				PerfectoUtils.getAppiumDriver().hideKeyboard();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void onFailure(QAFExtendedWebElement element, CommandTracker commandTracker) {

	}

}
