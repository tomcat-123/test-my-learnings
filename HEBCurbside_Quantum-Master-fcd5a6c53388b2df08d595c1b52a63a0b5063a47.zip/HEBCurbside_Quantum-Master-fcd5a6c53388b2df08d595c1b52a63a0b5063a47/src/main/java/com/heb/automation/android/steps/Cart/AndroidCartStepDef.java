package com.heb.automation.android.steps.Cart;

import static com.heb.automation.common.PerfectoUtils.MIN_WAIT_TIME;
import static com.heb.automation.common.PerfectoUtils.reportMessage;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.Cart.CartLandingTestPage;
import com.heb.automation.common.pages.browse.ProductsCDPTestPage;
import com.heb.automation.common.pages.browse.ProductsSubCategoryTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class AndroidCartStepDef {

	@QAFTestStep(description = "Verify the Product to be added to cart")
	public void verifyTheProductToBeAddedToCart() {
		ProductsCDPTestPage productscdp = new ProductsCDPTestPage();

		String strProductCard = productscdp.getLiBrowseProducts().get(0).getText();
		System.out.println(strProductCard);
		ConfigurationManager.getBundle().setProperty("strBrowseProductCard", strProductCard);
	}

	@QAFTestStep(description = "I validate product card")
	public void iValidateProductCard() {
		CartLandingTestPage cartlanding = new CartLandingTestPage();

		cartlanding.getTxtCart().waitForPresent(MIN_WAIT_TIME);
		QAFWebElement elmProdsImg = cartlanding.getListProductsImage().get(0);

		String strProductImg = elmProdsImg.getText();
		if (elmProdsImg.verifyPresent()) {
			reportMessage("Product Image is displayed in the cart" + strProductImg, MessageTypes.Pass);
		} else {
			reportMessage("Product Image is not displayed in the cart", MessageTypes.Fail);

		}
		QAFWebElement elmProdsName = cartlanding.getListProductsName().get(0);
		String strProductName = elmProdsName.getText();
		if (elmProdsName.verifyPresent()) {
			reportMessage("Product Name is displayed in the cart" + strProductName, MessageTypes.Pass);
		} else {
			reportMessage("Product Name is not displayed in the cart", MessageTypes.Fail);

		}
		QAFWebElement elmProdsPrice = cartlanding.getListProductsPrice().get(0);
		String strProductPrice = elmProdsPrice.getText();
		if (elmProdsName.verifyPresent()) {
			reportMessage("Product Price is displayed in the cart" + strProductPrice, MessageTypes.Pass);
		} else {
			reportMessage("Product Price is not displayed in the cart", MessageTypes.Fail);

		}
		QAFWebElement elmProdsRemoveBtn = cartlanding.getListRemoveButton().get(0);
		if (elmProdsRemoveBtn.verifyPresent()) {
			reportMessage("Product Remove button is displayed in the cart", MessageTypes.Pass);
		} else {
			reportMessage("Product Remove button is not displayed in the cart", MessageTypes.Fail);

		}

	}

	@QAFTestStep(description = "I verify user navigates to the cart page")
	public void iVerifyUserNavigatesToTheCartPage() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();
		CartLandingTestPage cartlanding = new CartLandingTestPage();

		pdtsubcat.getLblCartnumber().click();
		cartlanding.getTxtCart().waitForPresent(MIN_WAIT_TIME);

		if (cartlanding.getTxtCart().isPresent()) {
			reportMessage("user navigates to cart page.", MessageTypes.Pass);
		} else {
			reportMessage("user is not in cart page", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I add {0} item to the cart")
	public void iAddAItemToTheCart(int items) {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		int count = 0;
		for (int i = 0; i < items; i++) {
			pdtsubcat.getLiAddbuttonlist().get(i).verifyPresent();
			pdtsubcat.getLiAddbuttonlist().get(i).click();
			count++;
		}
		int cartNumber = Integer.parseInt(pdtsubcat.getLblCartnumber().getText());
		if (count == cartNumber) {
			reportMessage(count + " Item added to the cart..", MessageTypes.Pass);
		} else {
			reportMessage("Items getting mismatch", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify product card will display")
	public void iVerifyProductCardWillDisplay() {
		CartLandingTestPage cartlanding = new CartLandingTestPage();

		cartlanding.getTxtCart().waitForPresent(MIN_WAIT_TIME);
		int productsListSize = cartlanding.getListProductsName().size();

		if (productsListSize > 0) {

			QAFWebElement elmListOfProds = cartlanding.getListProductsName().get(0);

			String strFirstProduct = elmListOfProds.getText();

			elmListOfProds.isDisplayed();

			reportMessage("Cart product " + strFirstProduct + " is Displayed successfully..", MessageTypes.Pass);
			String strProductfromBrowse = ConfigurationManager.getBundle().getString("strBrowseProductCard");

			if (strProductfromBrowse.equalsIgnoreCase(strFirstProduct)) {
				reportMessage("Cart product " + strProductfromBrowse
						+ " is matched successfully as per adding the product to cart..", MessageTypes.Pass);
			} else {
				reportMessage("Cart product " + strProductfromBrowse + strFirstProduct
						+ " is not matched successfully in the Cart displayed..", MessageTypes.Fail);
			}
		} else
			reportMessage("No Products found in Cart..", MessageTypes.Fail);

	}
	
	@QAFTestStep(description = "I navigates to cart without adding any product")
	public void iNavigatesToCartWithoutAddingAnyProduct() {
		reportMessage("NA for Android", MessageTypes.Pass);

	}

	@QAFTestStep(description = "I verify Empty Cart page")
	public void iVerifyEmptyCartPage() {
		reportMessage("NA for Android", MessageTypes.Pass);

	}

	@QAFTestStep(description = "I clicked Start Shopping button")
	public void iClickedStartShoppingButton() {
		reportMessage("NA for Android", MessageTypes.Pass);

	}

	@QAFTestStep(description = "I verify user navigates to Products subcategory screen")
	public void iVerifyUserNavigatesToProductsSubcategoryScreen() {
		reportMessage("NA for Android", MessageTypes.Pass);

	}
	
	@QAFTestStep(description = "I verify the Next Pickup placeholder is scrolling up")
	public void iVerifyTheNextPickupPlaceholderIsScrollingUp() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.getTxtDateAndtime().verifyPresent();
		PerfectoUtils.verticalswipe();
		reportMessage("srolling..", MessageTypes.Info);
		if (!pdtsubcat.getTxtDateAndtime().isPresent()) {
			reportMessage("user is able to scroll Next Pickup placeholder", MessageTypes.Pass);
		} else {
			reportMessage("Next Pickup placeholder is not scrolling", MessageTypes.Fail);
		}
	}
	@QAFTestStep(description = "I Verify the Cart total and Checkout Now button")
	public void iVerifyTheCartTotalAndCheckoutNowButton() {
		reportMessage("OOS for Android..", MessageTypes.Info);
	}
	
	@QAFTestStep(description = "Validate the price of the selected product")
	public void validateThePriceOfTheSelectedProduct() {
		reportMessage("OOS for Android..", MessageTypes.Info);
	}
}