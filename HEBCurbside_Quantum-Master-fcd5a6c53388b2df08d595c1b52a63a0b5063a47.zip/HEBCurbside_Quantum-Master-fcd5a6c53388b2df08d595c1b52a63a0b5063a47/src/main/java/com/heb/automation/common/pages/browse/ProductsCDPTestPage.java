package com.heb.automation.common.pages.browse;

import java.util.List;

import com.heb.automation.common.components.Products.ProductsCDPSubcategoryBlocks;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ProductsCDPTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "productscdp.li.subcategoryblocks")
	private List<ProductsCDPSubcategoryBlocks> liSubcategoryblocks;

	@FindBy(locator = "productscdp.li.subcategoryproductblocks")
	private List<QAFWebElement> liSubcategoryproductblocks;

	@FindBy(locator = "productscdp.li.subcategoryfirstproductblocks")
	private List<QAFWebElement> liSubcategoryfirstproductblocks;

	@FindBy(locator = "productscdp.img.animation")
	private QAFWebElement ImgAnimation;

	@FindBy(locator = "productsubcat.lbl.cartnumber")
	private QAFWebElement lblCartnumber;

	@FindBy(locator = "productscdp.txt.subcategoryValue")
	private QAFWebElement TxtSubcategoryValue;

	@FindBy(locator = "productscdp.btn.plus")
	private QAFWebElement BtnPlus;

	@FindBy(locator = "productscdp.btn.minus")
	private QAFWebElement BtnMinus;

	@FindBy(locator = "productsubcat.lbl.subcategoryPlus")
	private QAFWebElement lblSubcategoryPlus;

	@FindBy(locator = "productscdp.btn.subaddproductperweight")
	private QAFWebElement btnSubaddproductperweight;

	@FindBy(locator = "productscdp.btn.subaddproductpereach")
	private QAFWebElement btnSubaddproductpereach;

	@FindBy(locator = "productscdp.li.subcatheadername")
	private List<QAFWebElement> liSubcatheadername;

	@FindBy(locator = "productscdp.btn.addGreyedout")
	private QAFWebElement btnAddGreyedout;

	@FindBy(locator = "productscdp.icon.cartIcon")
	private QAFWebElement iconCartIcon;

	@FindBy(locator = "productscdp.btn.subcatproductDonebutton")
	private QAFWebElement btnSubcatproductDonebutton;

	@FindBy(locator = "productscdp.btn.subcatproductdeletebutton")
	private QAFWebElement btnSubcatproductdeletebutton;

	@FindBy(locator = "productscdp.btn.subcatqtyplus")
	private QAFWebElement btnSubcatqtyplus;

	@FindBy(locator = "productscdp.txt.firstpdt")
	private QAFWebElement txtFirstPdt;

	@FindBy(locator = "productscdp.lbl.datentime")
	private QAFWebElement lblDateNTime;

	
	@FindBy(locator = "productscdp.lbl.placeholderselection")
	private QAFWebElement lblPlaceholderSelection;
	
	@FindBy(locator = "productscdp.lbl.expiredtime")   
	private QAFWebElement lblExpiredTime;
	
	
	@FindBy(locator = "productscdp.li.subcatproducteach")
	private QAFWebElement liSubcatproducteach;
	
	@FindBy(locator = "productscdp.btn.subcatproductclose")
	private QAFWebElement btnSubcatproductclose;
	
	@FindBy(locator = "productscdp.li.subproductsimage")
	private QAFWebElement liSubproductsimage;
	
	@FindBy(locator = "productscdp.li.subproductsname")
	private QAFWebElement liSubproductsname;
	
	@FindBy(locator = "productscdp.li.browseProducts")
	private List<QAFWebElement> liBrowseProducts;
	
	public List<QAFWebElement> getLiBrowseProducts() {
		return liBrowseProducts;
	}

	public QAFWebElement getLiSubproductsname() {
		return liSubproductsname;
	}

	public QAFWebElement getLiSubproductsimage() {
		return liSubproductsimage;
	}

	public QAFWebElement getBtnSubcatproductclose() {
		return btnSubcatproductclose;
	}

	public QAFWebElement getLiSubcatproducteach() {
		return liSubcatproducteach;
	}

	public QAFWebElement getBtnSubaddproductpereach() {
		return btnSubaddproductpereach;
	}

	public QAFWebElement getBtnSubcatqtyplus() {
		return btnSubcatqtyplus;
	}

	public QAFWebElement getBtnSubcatproductdeletebutton() {
		return btnSubcatproductdeletebutton;
	}

	public QAFWebElement getBtnSubcatproductDonebutton() {
		return btnSubcatproductDonebutton;
	}

	public QAFWebElement getIconCartIcon() {
		return iconCartIcon;
	}

	public QAFWebElement getBtnAddGreyedout() {
		return btnAddGreyedout;
	}

	public QAFWebElement getLblCartnumber() {
		return lblCartnumber;
	}

	public QAFWebElement getLblSubcategoryPlus() {
		return lblSubcategoryPlus;
	}

	public QAFWebElement getBtnSubaddproductperweight() {
		return btnSubaddproductperweight;
	}

	public QAFWebElement getBtnMinus() {
		return BtnMinus;
	}

	public QAFWebElement getBtnPlus() {
		return BtnPlus;
	}

	public QAFWebElement getTxtSubcategoryValue() {
		return TxtSubcategoryValue;
	}

	public QAFWebElement getImgAnimation() {
		return ImgAnimation;
	}

	public List<ProductsCDPSubcategoryBlocks> getLiSubcategoryblocks() {
		return liSubcategoryblocks;
	}

	public List<QAFWebElement> getLiSubcatheadername() {
		return liSubcatheadername;
	}

	public List<QAFWebElement> getliSubcategoryproductblocks() {
		return liSubcategoryproductblocks;
	}

	public List<QAFWebElement> getLiSubcategoryfirstproductblocks() {
		return liSubcategoryfirstproductblocks;
	}

	public QAFWebElement getTxtFirstPdt() {
		return txtFirstPdt;
	}

	public QAFWebElement getLblDateNTime() {    
		return lblDateNTime;
	}
	
	public QAFWebElement getLblPlaceholderSelection() {
		return lblPlaceholderSelection;
	}
	
	public QAFWebElement getLblExpiredTime() {
		return lblExpiredTime;
	}

}