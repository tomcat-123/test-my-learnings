package com.heb.automation.common.pages.selectastore;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SearchStoreErrTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "searchstrerror.lbl.txtviewmessage")
	private QAFWebElement searchstrerrorLblTxtviewmessage;

	@FindBy(locator = "searchstrerror.lnk.linkviewAllcurbsidestores")
	private QAFWebElement searchstrerrorLnkLinkviewAllcurbsidestores;

	@FindBy(locator = "searchstrerror.img.pageerrimage")
	private QAFWebElement imgPageerrimage;

	/**
	 * TextView of Search Store Error page
	 */
	public QAFWebElement getSearchstrerrorLblTxtviewmessage() {
		return searchstrerrorLblTxtviewmessage;
	}

	/**
	 * Link of View All Curbside Stores
	 */
	public QAFWebElement getSearchstrerrorLnkLinkviewAllcurbsidestores() {
		return searchstrerrorLnkLinkviewAllcurbsidestores;
	}

	public QAFWebElement getImgPageerrimage() {
		return imgPageerrimage;
	}
}