package com.heb.automation.common.perfecto;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

public class PerfectoLabconnection {

public static void main(String[] args) throws UniformInterfaceException, ClientHandlerException, Exception {

	 ArrayList<String> iOSDeviceIDList = new ArrayList<String>();
	 ArrayList<String> AndroidDeviceIDList = new ArrayList<String>();
	ClientResponse rClient= GET();
	stringToDom(prettyFormat(rClient.getEntity(String.class), 2));
	
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse("my-file.xml");
	doc.getDocumentElement().normalize();
	NodeList nList = doc.getElementsByTagName("handset");

		System.out.println("----------------------------");

		System.out.println("Total list : " + nList.getLength());

		for (int temp = 0; temp < nList.getLength(); temp++) {

			Node nNode = nList.item(temp);

			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;
				String DeviceID = eElement.getElementsByTagName("deviceId").item(0).getTextContent();
				String OSName = eElement.getElementsByTagName("os").item(0).getTextContent();
				 if(OSName.equalsIgnoreCase("Android")) {
					 AndroidDeviceIDList.add(DeviceID);
				 }
				 if(OSName.equalsIgnoreCase("iOS")) {
					 iOSDeviceIDList.add(DeviceID);
				 }
		}
		
		
	}
    
		System.out.println("Total iOS devices count : "+ iOSDeviceIDList.size());
		System.out.println("List of iOS devices : "+ iOSDeviceIDList);
		System.out.println("Total Android devices count : "+ AndroidDeviceIDList.size());
		System.out.println("List of Android devices : "+ AndroidDeviceIDList);
}

public static void stringToDom(String xmlSource) 
        throws IOException {
    FileWriter fw = new FileWriter("my-file.xml");
    
    String pretty = prettyFormat(xmlSource, 0);
    fw.write(pretty);
    fw.close();
    
}

public static String prettyFormat(String input, int indent) {
    try {
        Source xmlInput = new StreamSource(new StringReader(input));
        StringWriter stringWriter = new StringWriter();
        StreamResult xmlOutput = new StreamResult(stringWriter);
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
       // transformerFactory.setAttribute("indent-number", indent);
        Transformer transformer = transformerFactory.newTransformer(); 
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.transform(xmlInput, xmlOutput);
        return xmlOutput.getWriter().toString();
    } catch (Exception e) {
        throw new RuntimeException(e); // simple exception handling, please review it
    }
}


private static Builder createWebResourceBuilder() {

	Client client = Client.create();

	String url = "https://heb.perfectomobile.com/services/handsets?operation=list&user=vn01109@heb.com&password=perfecto123&status=connected" ;
	System.out.println(url);
	
	WebResource webResource = client.resource(url);

	Builder builder = webResource.type("application/json").accept("application/json");
	
	
	return builder;
		
	}

public static ClientResponse GET() throws UniformInterfaceException, ClientHandlerException, Exception {
	ClientResponse rClient = null ;
	
	rClient = createWebResourceBuilder().get(ClientResponse.class);
	System.out.println(rClient);
	return rClient;
}



}
