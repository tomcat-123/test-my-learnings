package com.heb.automation.ios.steps.Browse;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.HashMap;
import java.util.Map;

import static com.heb.automation.common.PerfectoUtils.MIN_WAIT_TIME;
import static com.heb.automation.common.PerfectoUtils.reportMessage;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.Cart.CartLandingTestPage;
import com.heb.automation.common.pages.browse.ProductsCDPTestPage;
import com.heb.automation.common.pages.browse.ProductsLandingTestPage;
import com.heb.automation.common.pages.browse.ProductsSubCategoryTestPage;
import com.heb.automation.common.pages.homepage.RootViewControllerTestPage;
import com.heb.automation.ios.pages.ioscommon.IOSCommonTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.thoughtworks.selenium.webdriven.commands.GetAllButtons;

public class IOSProductsStepDef {

	@QAFTestStep(description = "Verify able to scroll up and down to view all sub categories")
	public void verifyAbleToScrollUpAndDownToViewAllSubCategories() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		int subCatSize = pdtcdp.getLiSubcatheadername().size();

		String lastCategoryName = pdtcdp.getLiSubcatheadername().get(subCatSize - 1).getText();

		if (subCatSize > 0) {
			reportMessage(subCatSize + " subcategories found..", MessageTypes.Pass);

			if (subCatSize < 2) {
				reportMessage("Not enough subcategories are available to scroll..", MessageTypes.Pass);
			} else {
				// Scrolling down
				PerfectoUtils.verticalswipe();

				// validating whether scrolled down
				subCatSize = pdtcdp.getLiSubcatheadername().size();
				String lastCategoryNameAfterSwipe = pdtcdp.getLiSubcatheadername().get(subCatSize - 1).getText();

				if (lastCategoryName.equals(lastCategoryNameAfterSwipe)) {
					reportMessage("Scrolled down to the next sub category..", MessageTypes.Pass);
				} else {
					reportMessage("Not scrolled down to the next sub category..", MessageTypes.Fail);
				}
			}
		} else {
			reportMessage("No Subcategories found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify navigated to top when cliking on status bar")
	public void verifyNavigatedToTopWhenClikingOnStatusBar() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		int subCatSize = pdtcdp.getLiSubcatheadername().size();

		if (subCatSize > 0) {
			reportMessage(subCatSize + " subcategories found..", MessageTypes.Pass);

			String firstCategoryName = pdtcdp.getLiSubcatheadername().get(subCatSize - 1).getText();

			// Scrolling down
			PerfectoUtils.verticalswipe();

			// CLicking on Status bar- selected top level category
			String selectedTopLevelCategory = ConfigurationManager.getBundle().getString("selectingTopLevelCategory");
			pdtslanding.getLblTopelevelcatnamedynamic(selectedTopLevelCategory).click();
			reportMessage("Clicked on: " + selectedTopLevelCategory);

			// Validating whether navigated to top
			String firstCategoryNameAfterSwipe = pdtcdp.getLiSubcatheadername().get(subCatSize - 1).getText();

			if (firstCategoryName.equals(firstCategoryNameAfterSwipe))
				reportMessage("Navigated to top on clicking the status bar..", MessageTypes.Pass);
			else
				reportMessage("Not navigated to top on clicking the status bar..", MessageTypes.Fail);

		} else {
			reportMessage("No Subcategories found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Click on View All option for a subcategory")
	public void clickOnViewAllOptionForASubcategory() {
		ProductsCDPTestPage cdp = new ProductsCDPTestPage();

		cdp.getLiSubcategoryblocks().get(0).waitForPresent(MIN_WAIT_TIME);

		int subCatBlocksCount = cdp.getLiSubcategoryblocks().size();

		// Validating the Sub category sections are available
		if (subCatBlocksCount > 0) {
			cdp.getLiSubcategoryblocks().get(subCatBlocksCount - 1).getLiSubcatviewall().waitForPresent(MIN_WAIT_TIME);
			cdp.getLiSubcategoryblocks().get(subCatBlocksCount - 1).getLiSubcatviewall().click();
			reportMessage("Clicked on View All...", MessageTypes.Pass);

		} else {
			reportMessage("SubCategory blocks not found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify products grid will not have sub headers or View all button")
	public void VerifyProductsGridWillNotHaveSubHeadersOrViewAllButton() {
		ProductsSubCategoryTestPage prdtsubcat = new ProductsSubCategoryTestPage();

		prdtsubcat.getLnkViewAll().verifyNotPresent();
	}

	@QAFTestStep(description = "Click on Products from Footer tab")
	public void clickOnProductsFromFooterTab() {
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();

		ioscommon.getBtnTabbarproducts().waitForPresent(MIN_WAIT_TIME);
		ioscommon.getBtnTabbarproducts().click();
		reportMessage("Clicked on Products tab from footer..", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify navigated back to top level categories page for ios")
	public void verifyNavigatedBackToTopLevelCategoriesPageForIos() {
		ProductsCDPTestPage cdp = new ProductsCDPTestPage();

		cdp.getLiSubcategoryblocks().get(0).waitForPresent(MIN_WAIT_TIME);

		int subCatBlocksCount = cdp.getLiSubcategoryblocks().size();

		if (cdp.getLiSubcategoryblocks().get(subCatBlocksCount - 1).getLiSubcatviewall().isPresent()) {
			reportMessage("Navigated back to top level Categories page..", MessageTypes.Pass);
		} else {
			reportMessage("Not navigated back to top level Categories page..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate able to view all the top level sub categories when swiping right to left")
	public void validateAbleToViewAllTheTopLevelSubCategorieswhenSwipingRightToLeft() {
		reportMessage("NA for iOS..");
	}

	@QAFTestStep(description = "Verify a back button is positioned on the far left")
	public void verifyABackButtonIsPositionedOnTheFarLeft() {
		ProductsSubCategoryTestPage prdtsSubCat = new ProductsSubCategoryTestPage();

		prdtsSubCat.getBtnBack().waitForPresent(MIN_WAIT_TIME);
		if (prdtsSubCat.getBtnBack().isPresent()) {
			reportMessage("Back button is positioned on the far left in sub category page..", MessageTypes.Pass);

		} else {
			reportMessage("Back button is not positioned on the far left in sub category page..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the max number of characters is 9 for a category")
	public void verifyTheMaxNumberOfCharactersIs9ForACategory() {
		ProductsSubCategoryTestPage prdtsSubCat = new ProductsSubCategoryTestPage();

		prdtsSubCat.getTxtSubcatchar().waitForPresent(MIN_WAIT_TIME);

		if (prdtsSubCat.getTxtSubcatchar().isPresent()) {

			String catNameNearBackButton = prdtsSubCat.getTxtSubcatchar().getText();

			int charCount = PerfectoUtils.removeSpecialCharacters(catNameNearBackButton).length();

			if (charCount <= 9) {
				reportMessage("Maximum sub category characters present is 9 as expected..", MessageTypes.Pass);

			} else {
				reportMessage("Maximum sub category characters present is not 9 as expected..", MessageTypes.Fail);
			}
		}
	}

	@QAFTestStep(description = "Verify cart amount badge gets updated on adding the product to Cart")
	public void verifyCartAmountBadgeGetsUpdatedOnAddingTheProductToCart() {

		/* # De-Scoped in sprint_7# */

	}

	@QAFTestStep(description = "Verify row of products will scroll vertically but not horizontally")
	public void verifyRowOfProductsWillScrollVerticallyButNotHorizontally() {
		ProductsSubCategoryTestPage prdtsSubCat = new ProductsSubCategoryTestPage();

		int topLevelsubcategoriesSize = prdtsSubCat.getLiSubcategoryproducts().size();

		if (topLevelsubcategoriesSize > 0) {

			reportMessage(topLevelsubcategoriesSize + " subcategories found to swipe up vertically..",
					MessageTypes.Pass);

			if (topLevelsubcategoriesSize < 3) {
				reportMessage("Not enough subcategories are available to swipe up..", MessageTypes.Pass);
			} else {

				float YCordinateBeforeSwipe = Float
						.parseFloat(prdtsSubCat.getLiAddbuttonlist().get(0).getAttribute("y"));

				// Scrolling up
				PerfectoUtils.verticalswipe();

				float YCordinateAfterSwipe = 0;

				try {
					YCordinateAfterSwipe = Float.parseFloat(prdtsSubCat.getLiAddbuttonlist().get(0).getAttribute("y"));
				} catch (NumberFormatException e) {

				}

				if (YCordinateBeforeSwipe > YCordinateAfterSwipe) {
					reportMessage("Scrolled up to the next sub category..", MessageTypes.Pass);
				} else {
					reportMessage("Not scrolled up to the next sub category..", MessageTypes.Fail);
				}
			}
		} else {
			reportMessage("Not enough Subcategories found to swipe vertically..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify able to enter value {0} by using keyboard")
	public void verifyAbleToEnterValueByUsingKeyboard(String strqty) {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);
		
		

		QAFWebElement eleTxtSubcategoryValue = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getTxtSubcategoryValue();
		


		eleTxtSubcategoryValue.click();
		eleTxtSubcategoryValue.clear();
		//eleTxtSubcategoryValue.sendKeys(Keys.chord(Keys.CONTROL, "a"), "");
		// eleTxtSubcategoryValue.clear();
		eleTxtSubcategoryValue.sendKeys(strqty);
		/*
		 * eleTxtSubcategoryValue.clear();
		 * eleTxtSubcategoryValue.sendKeys(strqty);
		 */
	}

	@QAFTestStep(description = "Verify able to enter maximum value by using keyboard")
	public void verifyAbleToEnterMaximumValueByUsingKeyboard() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getBtnSubcatproductdeletebutton().isPresent()) {
			pdtcdp.getBtnSubcatproductdeletebutton().click();
			reportMessage("Delete button is clicked..", MessageTypes.Pass);

		} else {
			reportMessage("Delete button is not present..", MessageTypes.Fail);
		}
		QAFWebElement eleTxtSubcategoryValue = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getTxtSubcategoryValue();
		String strMaxquantityValue = ConfigurationManager.getBundle().getString("browse.catname.maxQuantityVal");
		eleTxtSubcategoryValue.sendKeys(strMaxquantityValue);
		String subCategoryValueAfterSendkeys = eleTxtSubcategoryValue.getText();

		if (strMaxquantityValue.equals(subCategoryValueAfterSendkeys))

			reportMessage("Able to enter Maximum Quantity value..", MessageTypes.Pass);
		else
			reportMessage("Not able to Maximum Quantity value..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify able to enter the value by using keyboard")
	public void verifyAbleToEnterTheValueByUsingKeyboard() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getBtnSubcatproductdeletebutton().isPresent()) {
			pdtcdp.getBtnSubcatproductdeletebutton().click();
			reportMessage("Delete button is clicked..", MessageTypes.Pass);

		} else {
			reportMessage("Delete button is not present..", MessageTypes.Fail);
		}
		QAFWebElement eleTxtSubcategoryValue = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getTxtSubcategoryValue();
		String quantityValue = ConfigurationManager.getBundle().getString("browse.catname.quantityVal");
		eleTxtSubcategoryValue.sendKeys(quantityValue);
		String subCategoryValueAfterSendkeys = eleTxtSubcategoryValue.getText();

		if (quantityValue.equals(subCategoryValueAfterSendkeys))

			reportMessage("Able to enter sub category value..", MessageTypes.Pass);
		else
			reportMessage("Not able to enter sub category value..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I verify the Done button is available in keyboard")
	public void iVerifyTheDoneButtonIsAvailableInKeyboard() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtcdp.waitForPageToLoad();

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");
		String isBtnDoneVisible = (String) pdtcdp.getTestBase().getDriver().executeScript("mobile:text:find", params1);

		if (isBtnDoneVisible.equalsIgnoreCase("false")) {
			Map<String, Object> params2 = new HashMap<>();
			params2.put("content", "Done");
			params2.put("timeout", "20");
			params2.put("profile", "DocumentConversion_Speed");
			params2.put("analysis", "manual");
			params2.put("inverse", "yes");
			params2.put("screen.top", "69%");
			params2.put("screen.height", "31%");
			params2.put("screen.left", "51%");
			params2.put("screen.width", "49%");
			isBtnDoneVisible = (String) pdtcdp.getTestBase().getDriver().executeScript("mobile:text:find", params2);

		}

		if (isBtnDoneVisible.equalsIgnoreCase("true")) {
			PerfectoUtils.reportMessage("Done button is available in the Keyboard as expected.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Done button is not available in the Keyboard.", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "verify the error message when adding the maximum quantity")
	public void verifyTheErrorMessageWhenAddingTheMaximumQuantity() {
		reportMessage("Yet to add.");
	}

	@QAFTestStep(description = "Verify outside of the selected product is disabled when the keyboard is visible")
	public void verifyOutsideOfTheSelectedProductIsDisabledWhenTheKeyboardIsVisible() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleTxtSubcategoryValue = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getTxtSubcategoryValue();

		eleTxtSubcategoryValue.click();
		reportMessage("Clicked on Qty text field..", MessageTypes.Pass);

		QAFWebElement eleAddbuttonForSecondProduct = pdtcdp.getLiSubcategoryblocks().get(0)
				.getLiSubcategoryproductblocks().get(1).getLiSubcatproductAddbutton();

		// Clicking outside of the selected product
		eleAddbuttonForSecondProduct.click();
		reportMessage("Clicked on Add button for Second product..");

		// Validating whether the Add button is still present for the Second
		// product
		if (eleAddbuttonForSecondProduct.isPresent()) {
			reportMessage("Outside of the selected product is disabled when the keyboard is visible..",
					MessageTypes.Pass);
		} else {
			reportMessage("Outside of the selected product is not disabled when the keyboard is visible..",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify clicking outside of the keyboard that re-enables the rest of the screen")
	public void verifyClickingOutsideOfTheKeyboardThatReEenablesTheRestOfTheScreen() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		QAFWebElement eleAddbuttonForSecondProduct = pdtcdp.getLiSubcategoryblocks().get(0)
				.getLiSubcategoryproductblocks().get(1).getLiSubcatproductAddbutton();

		eleAddbuttonForSecondProduct.click();
		reportMessage("Clicking on Add button again for the second product..");

		// Validating whether the Add button is not present
		if (!eleAddbuttonForSecondProduct.isPresent()) {
			reportMessage("Clicking outside of the keyboard re-enabled the rest of the screen..", MessageTypes.Pass);
		} else {
			reportMessage("Clicking outside of the keyboard doesn't re-enable the rest of the screen",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the qty gets increased on clicking plus button")
	public void verifyTheQtyGetsIncreasedOnClickingPlusButton1() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleLnkSubcategoryPlus = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getLnkSubcategoryPlus();

		int cartQtyBeforeClickingPlus = PerfectoUtils
				.getIntCharacters(ioscommon.getBtnTabbarcart().getAttribute("value"));

		if (eleLnkSubcategoryPlus.isPresent()) {
			eleLnkSubcategoryPlus.click();
			reportMessage("Plus button is clicked..", MessageTypes.Pass);

			int cartQtyAfterClickingPlus = PerfectoUtils
					.getIntCharacters(ioscommon.getBtnTabbarcart().getAttribute("value"));

			// Comparing the Qty values
			if (cartQtyBeforeClickingPlus < cartQtyAfterClickingPlus)
				reportMessage("Cart Qty increased on clicking plus button.." + cartQtyAfterClickingPlus,
						MessageTypes.Pass);
			else
				reportMessage("Cart Qty not increased on clicking plus button.." + cartQtyBeforeClickingPlus,
						MessageTypes.Fail);

		} else {
			reportMessage("Plus button is not present..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the qty gets decreased on clicking minus button")
	public void verifyTheQtyGetsDecreasedOnClickingMinusButton() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryMinus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleLnkSubcategoryMinus = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getLnkSubcategoryMinus();

		QAFWebElement eleTxtSubcategoryValue = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getTxtSubcategoryValue();

		float intQtyBeforeClickingMinus = Float.parseFloat(eleTxtSubcategoryValue.getText());

		if (eleLnkSubcategoryMinus.isPresent()) {
			eleLnkSubcategoryMinus.click();
			reportMessage("Minus button is clicked..", MessageTypes.Pass);

			float intQtyAfterClickingMinus = Float.parseFloat(eleTxtSubcategoryValue.getText());

			if (intQtyAfterClickingMinus < intQtyBeforeClickingMinus)
				reportMessage("Qty decreases on clicking minus button..", MessageTypes.Pass);
			else
				reportMessage("Qty not decreased on clicking minus button..", MessageTypes.Fail);

		} else {
			reportMessage("Minus button is not present..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify able to scroll left and right within each sub category")
	public void verifyAbleToScrollLeftAndRightWithinEachSubCategory() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		int subCatSize = pdtcdp.getLiSubcategoryblocks().size();

		if (subCatSize > 0) {
			reportMessage(subCatSize + " sub-categories found..", MessageTypes.Pass);

			QAFWebElement eleFirstAddButton = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
					.get(1).getLiSubcatproductAddbutton();

			int XCordinateBeforeSwipe = Integer.parseInt(eleFirstAddButton.getAttribute("x"));

			// Swipe Right
			PerfectoUtils.swipeRight(eleFirstAddButton);

			int XCordinateAfterSwipe = Integer.parseInt(eleFirstAddButton.getAttribute("x"));

			// Validating the Swipe right
			if (XCordinateBeforeSwipe > XCordinateAfterSwipe)
				reportMessage("Swipe to right validated successfully..", MessageTypes.Pass);
			else
				reportMessage("Swipe to right validation failed..", MessageTypes.Fail);

			// Swipe left
			XCordinateBeforeSwipe = Integer.parseInt(eleFirstAddButton.getAttribute("x"));

			PerfectoUtils.swipeLeft(eleFirstAddButton);

			XCordinateAfterSwipe = Integer.parseInt(eleFirstAddButton.getAttribute("x"));

			// Validating the Swipe left
			if (XCordinateBeforeSwipe < XCordinateAfterSwipe)
				reportMessage("Swipe to left validated successfully..", MessageTypes.Pass);
			else
				reportMessage("Swipe to left validation failed..", MessageTypes.Fail);

		} else {
			reportMessage("No sub-categories found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Cart qty gets decreased on clicking minus button")
	public void verifyTheCartQtyGetsDecreasedOnClickingMinusButton() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryMinus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleLnkSubcategoryMinus = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getLnkSubcategoryMinus();

		int cartQtyBeforeClickingMinus = PerfectoUtils
				.getIntCharacters(ioscommon.getBtnTabbarcart().getAttribute("value"));

		if (eleLnkSubcategoryMinus.isPresent()) {
			eleLnkSubcategoryMinus.click();
			reportMessage("Minus button is clicked..", MessageTypes.Pass);

			int cartQtyAfterClickingMinus = PerfectoUtils
					.getIntCharacters(ioscommon.getBtnTabbarcart().getAttribute("value"));

			if (cartQtyBeforeClickingMinus > cartQtyAfterClickingMinus)
				reportMessage("Cart Qty decreases on clicking minus button..", MessageTypes.Pass);
			else
				reportMessage("Cart Qty not decreased on clicking minus button..", MessageTypes.Fail);

		} else {
			reportMessage("Minus button is not present..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify the Cart qty gets increased on clicking plus button")
	public void verifyTheCartQtyGetsIncreasedOnClickingPlusButton() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleLnkSubcategoryPlus = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getLnkSubcategoryPlus();

		int cartQtyBeforeClickingPlus = PerfectoUtils
				.getIntCharacters(ioscommon.getBtnTabbarcart().getAttribute("value"));

		if (eleLnkSubcategoryPlus.isPresent()) {
			eleLnkSubcategoryPlus.click();
			reportMessage("Plus button is clicked..", MessageTypes.Pass);

			int cartQtyAfterClickingPlus = PerfectoUtils
					.getIntCharacters(ioscommon.getBtnTabbarcart().getAttribute("value"));

			// Comparing the Qty values
			if (cartQtyBeforeClickingPlus < cartQtyAfterClickingPlus)
				reportMessage("Cart Qty increased on clicking plus button..", MessageTypes.Pass);
			else
				reportMessage("Cart Qty not increased on clicking plus button..", MessageTypes.Fail);

		} else {
			reportMessage("Plus button is not present..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify Navigated to all products subcategory page")
	public void verifyNavigatedToAllProductsSubcategoryPage() {
		reportMessage("NA for IOS..");

	}

	@QAFTestStep(description = "Clicks on Add button per weight product")
	public void clicksOnAddButtonPerWeightProduct() {

		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();

		// pdtcdp.getBtnSubaddproductperweight().waitForPresent(MIN_WAIT_TIME);
		ioscommon.getBtnAaddbuttonperweight().waitForPresent(MIN_WAIT_TIME);

		if (ioscommon.getBtnAaddbuttonperweight().isPresent())

		{

			ioscommon.getBtnAaddbuttonperweight().click();
			reportMessage("Clicked on Add product per weight button..", MessageTypes.Pass);
		}

		else {
			reportMessage("Add per weight button not found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "click on done button the category page")
	public void clickOnDoneButtonTheCategoryPage() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();

		pdtcdp.getBtnSubcatproductDonebutton().waitForPresent(MIN_WAIT_TIME);
		if (pdtcdp.getBtnSubcatproductDonebutton().isPresent()) {
			pdtcdp.getBtnSubcatproductDonebutton().click();
			reportMessage("Done button is clicked..", MessageTypes.Pass);

		} else {
			reportMessage("Done button is not present..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify done button is present in the category page")
	public void verifyDoneButtonispresentinthecategorypage() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();

		pdtcdp.getBtnSubcatproductDonebutton().waitForPresent(MIN_WAIT_TIME);
		if (pdtcdp.getBtnSubcatproductDonebutton().isPresent()) {

			reportMessage("Done button is present..", MessageTypes.Pass);

		} else {
			reportMessage("Done button is not present..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Clicks delete button in the keyboard")
	public void ClicksDeleteButtonInTheKeyboard() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();

		pdtcdp.getBtnSubcatproductdeletebutton().waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getBtnSubcatproductdeletebutton().isPresent()) {
			pdtcdp.getBtnSubcatproductdeletebutton().click();
			reportMessage("Delete button is clicked..", MessageTypes.Pass);

		} else {
			reportMessage("Delete button is not present..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Click on a Meat and Sea Food Category from top level options")
	public void clickOnAMeatAndSeaFoodCategoryFromTopLevelOptions() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		int CategoriesListFromToplevelSize = pdtslanding.getLiHeadercategorieslist().size();

		if (CategoriesListFromToplevelSize > 0) {

			QAFWebElement secondTopLevelCategory = pdtslanding.getLiHeadercategorieslist()
					.get(CategoriesListFromToplevelSize - (CategoriesListFromToplevelSize - 2));

			String selectingTopLevelCategory = secondTopLevelCategory.getText();
			getBundle().setProperty("selectingTopLevelCategory", selectingTopLevelCategory);

			secondTopLevelCategory.click();
			reportMessage("Clicked on Meat & Sea Food Category" + selectingTopLevelCategory
					+ " from Top Level Category section..", MessageTypes.Pass);

		} else
			reportMessage("No categories found in top level..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify Search and Date sections should be minimized when able to scroll up")
	public void verifySearchAndDateSectionsShouldBeMinimizedWhenAbleToScrollUp() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.waitForPageToLoad();
		if (pdtsubcat.getTxtDateAndtime().verifyNotVisible()) {
			reportMessage("Date and Time is minimized..", MessageTypes.Pass);
		} else {

			reportMessage("Date and Time is not minimized..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify row of grid products will scroll vertically")
	public void verifyRowOfGridProductsWillScrollVertically() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		int topLevelsubcategoriesSize = pdtslanding.getLiSecondarylevelheadercategorieslist().size();

		if (topLevelsubcategoriesSize > 0) {

			reportMessage(topLevelsubcategoriesSize + " subcategories found to swipe up vertically..",
					MessageTypes.Pass);

			if (topLevelsubcategoriesSize < 3) {
				reportMessage("Not enough subcategories are available to swipe up..", MessageTypes.Pass);
			} else {
				pdtsubcat.getLiAddbuttonlist().get(0).waitForPresent(MIN_WAIT_TIME);

				float YCordinateBeforeSwipe = Float.parseFloat(pdtsubcat.getLiAddbuttonlist().get(0).getAttribute("y"));

				// Scrolling up
				PerfectoUtils.verticalswipe();
			}
		}
		
//				float YCordinateAfterSwipe = 0;
//
//				try {
//					YCordinateAfterSwipe = Float.parseFloat(pdtsubcat.getLiAddbuttonlist().get(0).getAttribute("y"));
//				} catch (NumberFormatException e) {
//
//				}
//
//				if (YCordinateBeforeSwipe > YCordinateAfterSwipe) {
//					reportMessage("Scrolled up to the next sub category..", MessageTypes.Pass);
//				} else {
//					reportMessage("Not scrolled up to the next sub category..", MessageTypes.Fail);
//				}
//			}
	//	}
	//		else {
		//	reportMessage("Not enough Subcategories found to swipe vertically..", MessageTypes.Fail);
		//}

	}

	@QAFTestStep(description = "Verify Cart Icon incremented")
	public void verifyCartIconIncremented() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.waitForPageToLoad();
		String strCartNumbr = pdtcdp.getIconCartIcon().getAttribute("value");

		strCartNumbr = strCartNumbr.split(" ")[0];
		System.out.println(strCartNumbr);
		String quantityValue = ConfigurationManager.getBundle().getString("browse.catname.quantityVal");
		if (quantityValue.equals(strCartNumbr)) {
			reportMessage("Cart Incremented is Done and displayed sucessfully...." + strCartNumbr, MessageTypes.Pass);
		} else {
			reportMessage("Cart Incremented is not displayed.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify error message by passing special character(s)")
	public void verifyErrorMessageByPassingSpecialCharacters() {
		reportMessage("NA for Automation..", MessageTypes.Pass);

	}

	@QAFTestStep(description = "Validate able to view all the sub categories when swiping right to left")
	public void validateAbleToViewAllTheSubCategoriesWhenSwipingRightToLeft() {

		reportMessage("NA for Automation..", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify the button greyed out when passing negative quantity")
	public void verifyTheButtonGreyedOutWhenPassingNegativeQuantity() {

		reportMessage("NA for Automation..", MessageTypes.Pass);

	}

	@QAFTestStep(description = "Verify the quantity is entered {0} by using keyboard")
	public void verifyTheQuantityIsEnteredByUsingKeyboard(String strqty) {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleTxtSubcategoryValue = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getTxtSubcategoryValue();

		eleTxtSubcategoryValue.click();

		if (pdtcdp.getBtnSubcatproductdeletebutton().isPresent()) {
			pdtcdp.getBtnSubcatproductdeletebutton().click();
			reportMessage("Delete button is clicked..", MessageTypes.Pass);

		} else {
			reportMessage("Delete button is not present..", MessageTypes.Fail);
		}

		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(strqty);
		reportMessage("Successfully typed sub category Quantity value using keyboard.." + strqty, MessageTypes.Pass);
		String subCategoryValueAfterSendkeys = eleTxtSubcategoryValue.getText();

		if (strqty.equals(subCategoryValueAfterSendkeys))
			reportMessage("Able to enter sub category Quantity value..", MessageTypes.Pass);
		else
			reportMessage("Not able to enter sub category Quantity value..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Taps on Done button by using keyboard and becomes invisible")
	public void tapsonDonebuttonusingkeyboardByUsingKeyboardAndBecomesInvisible() {

		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleTxtSubcategoryValue = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getTxtSubcategoryValue();

		pdtcdp.waitForPageToLoad();
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");
		String isBtnDoneInVisible = (String) pdtcdp.getTestBase().getDriver().executeScript("mobile:text:select",
				params1);
		if (eleTxtSubcategoryValue.isDisplayed()) {
			PerfectoUtils.reportMessage("Done button has got clicked in the Keyboard as expected." + isBtnDoneInVisible,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Done button is not been clicked in the Keyboard as expected." + isBtnDoneInVisible,
					MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "Verify the numeric value entered after tapping Keyboard back button")
	public void verifyTheNumericValueEnteredAfterTappingKeyboardBackButton() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleTxtSubcategoryValue = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getTxtSubcategoryValue();

		pdtcdp.waitForPageToLoad();
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "DEL");
		String isBtnDELVisible = (String) pdtcdp.getTestBase().getDriver().executeScript("mobile:text:select", params1);
		System.out.println(isBtnDELVisible);
		// if(isBtnDELVisible.equalsIgnoreCase("null")){
		if (eleTxtSubcategoryValue.isDisplayed()) {
			PerfectoUtils.reportMessage("Keyboard Back button (DEL) has got clicked in the Keyboard as expected."
					+ eleTxtSubcategoryValue.getText() + isBtnDELVisible, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Keyboard Back button (DEL) is not present." + eleTxtSubcategoryValue.getText(),
					MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "Verify plus and minus buttons display right above the numeric keyboard")
	public void verifyPlusAndMinusButtonsDisplayRightAboveTheNumericKeyboard() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getBtnPlus().isDisplayed()) {
			PerfectoUtils.reportMessage("Plus button has got displayed right above the Keyboard section.",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Plus button has not been displayed right above the Keyboard section.",
					MessageTypes.Pass);
		}
		if (pdtcdp.getBtnMinus().isDisplayed()) {
			PerfectoUtils.reportMessage("Minus button has got displayed right above the Keyboard section.",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Minus button has not been displayed right above the Keyboard section.",
					MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "Taps on Done button by using keyboard")
	public void tapsonDonebuttonusingkeyboardByUsingKeyboard() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		if (pdtsubcat.getBtnSubcatproductDonebutton().isDisplayed()) {
			pdtsubcat.getBtnSubcatproductDonebutton().click();
			reportMessage("Done button has got clicked in the Keyboard as expected.", MessageTypes.Pass);
		} else {
			reportMessage("Done button is not been clicked in the Keyboard as expected.", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "Verify the button converts back to ADD")
	public void verifyTheButtonConvertsBackToADD() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLiSubcatproductAddbutton()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleAddButton = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0)
				.getLiSubcatproductAddbutton();

		if (eleAddButton.isPresent()) {
			reportMessage("Add button is displayed again..", MessageTypes.Pass);
		} else {
			reportMessage("Add button is not displayed again..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify Last level Category page")
	public void verifyLastLevelCategoryPage() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		int CategoriesListFromToplevelSize = pdtslanding.getLiSecondarylevelheadercategorieslist().size();

		if (CategoriesListFromToplevelSize > 0) {

			QAFWebElement secondTopLevelCategory = pdtslanding.getLiSecondarylevelheadercategorieslist()
					.get(CategoriesListFromToplevelSize - (CategoriesListFromToplevelSize - 1));

			String selectingTopLevelCategory = secondTopLevelCategory.getText();
			getBundle().setProperty("selectingTopLevelCategory", selectingTopLevelCategory);

			secondTopLevelCategory.click();
			reportMessage("Clicked on Last level category " + selectingTopLevelCategory
					+ " from Top Level Category section..", MessageTypes.Pass);

		} else
			reportMessage("No categories found in top level..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify sub-categories headers are not displayed")
	public void verifySubCategoriesHeadersAreNotDisplayed() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		int subCatHeadersSize = pdtslanding.getLiSecondarylevelheadercategorieslist().size();

		if (!(subCatHeadersSize > 0)) {
			reportMessage(subCatHeadersSize + " subcategories Headers not found as expected..", MessageTypes.Pass);
			reportMessage(subCatHeadersSize + " subcategories Headers found as not expected..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify View All button is not displayed")
	public void verifyViewAllButtonIsNotDisplayed() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLiSecondarylevelheadercategorieslist().get(0).waitForPresent(MIN_WAIT_TIME);

		int subCatBlocksCount = pdtslanding.getLiSecondarylevelheadercategorieslist().size();

		// Validating the Sub category sections are available
		if (subCatBlocksCount > 0) {

			pdtslanding.getLnkViewAll().waitForNotPresent(MIN_WAIT_TIME);
			pdtslanding.getLnkViewAll().waitForNotVisible();
			reportMessage("View All is not present as Expected...", MessageTypes.Pass);
		} else {
			reportMessage("View All is found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate able to view all the last level categories when swiping Left to Right")
	public void validateAbleToViewAllTheLastLevelCategoriesWhenSwipingLeftToRight() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtsubcat.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		// Validating the Last level Sub Categories section
		int lastLevelcategoriesSize = pdtslanding.getLiSecondarylevelheadercategorieslist().size();

		if (lastLevelcategoriesSize > 0) {
			reportMessage(lastLevelcategoriesSize + " Last level categories found..", MessageTypes.Pass);

			String firstCategoryNameBeforeSwipe = pdtslanding.getLiSecondarylevelheadercategorieslist().get(0)
					.getText();

			// Swipe right Operation
			PerfectoUtils.swipeRight(pdtslanding.getLiSecondarylevelheadercategorieslist().get(0));

			// Validating the swipe operation
			String firstCategoryNameAfterSwipe = pdtslanding.getLiSecondarylevelheadercategorieslist().get(0).getText();

			if (!firstCategoryNameBeforeSwipe.equals(firstCategoryNameAfterSwipe))
				reportMessage("Swiped and navigated to the Last level sub category.." + firstCategoryNameBeforeSwipe
						+ firstCategoryNameAfterSwipe, MessageTypes.Pass);
			else
				reportMessage("Swiped and not navigated to the Last level sub category..", MessageTypes.Fail);

		} else {
			reportMessage("Last level categories not found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify two columns at least displayed at Last level")
	public void verifyTwoColumnsAtLeastDisplayedAtLastLevel() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		int CategoriesListFromLastlevelSize = pdtslanding.getLiSecondarylevelheadercategorieslist().size();

		if (CategoriesListFromLastlevelSize > 2) {
			reportMessage("Last Level Category displayed at least two columns..", MessageTypes.Pass);
		} else {
			reportMessage("Last Level Category is not displayed two columns..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify last level category page displayed where secondary level category page is not present")
	public void VerifyLastLevelCategoryPageDisplayedWhereSecondaryLevelCategoryPageIsNotPresent() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		pdtslanding.getLiSecondarylevelheadercategorieslist().get(0).isDisplayed();

		String strLastLvlPrdtname = pdtslanding.getLiSecondarylevelheadercategorieslist().get(0).getText();

		String selectedTopLevelCategory = ConfigurationManager.getBundle().getString("browse.catname.TopLevelCategory");
		// String strSecondarylvlpdt =
		// pdtslanding.getLblTopelevelcatnamedynamic(selectedTopLevelCategory).getText();

		if (!(strLastLvlPrdtname.matches(selectedTopLevelCategory))) {
			reportMessage("Secondary level category page not displayed ", MessageTypes.Pass);

			if (pdtsubcat.getLblTopelevelcatnamedynamic(selectedTopLevelCategory).verifyNotPresent()) {
				reportMessage("Last Level Category displayed Where Secondary level Category is not present..",
						MessageTypes.Pass);
			} else {
				if (pdtsubcat.getLblTopelevelcatnamedynamic(selectedTopLevelCategory).verifyPresent())
					reportMessage("Secondary Level Category page displayed..", MessageTypes.Fail);
			}
		} else {
			reportMessage("Secondary Level Category page is displayed..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify Navigated to Product subcategory page")
	public void verifyNavigatedToProductSubcategoryPage() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).waitForPresent(MIN_WAIT_TIME);

		int subCategorySize = pdtcdp.getLiSubcategoryblocks().size();

		if (subCategorySize > 0)
			reportMessage("Navigated to Selected category page..", MessageTypes.Pass);
		else
			reportMessage("Not navigated to Selected category page..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify that horizontal level navigation is not possible at Last Level")
	public void verifyThatHorizontalLevelNavigationIsNotPossibleAtLastLevel() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		// Validating the Last level Sub Categories section
		int lastLevelcategoriesSize = pdtslanding.getLiSecondarylevelheadercategorieslist().size();

		if (lastLevelcategoriesSize > 0) {
			reportMessage(lastLevelcategoriesSize + " Last level categories found..", MessageTypes.Pass);

			// Horizontal swipe Naviagation
			PerfectoUtils.swipeRight(pdtslanding.getLiSecondarylevelheadercategorieslist().get(0));
			reportMessage("Horizontal level is not possible after attaining to the last product..", MessageTypes.Pass);
		} else {

			reportMessage("Last product is displayed and horizontal naviagation is possible..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the qty gets decreased on clicking minus button")
	public void verifyTheQtyGetsDecreasedOnClickingMinusButton1() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryMinus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleLnkSubcategoryMinus = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks()
				.get(0).getLnkSubcategoryMinus();

		int cartQtyBeforeClickingMinus = PerfectoUtils
				.getIntCharacters(ioscommon.getBtnTabbarcart().getAttribute("value"));

		if (eleLnkSubcategoryMinus.isPresent()) {
			eleLnkSubcategoryMinus.click();
			reportMessage("Minus button is clicked..", MessageTypes.Pass);

			int cartQtyAfterClickingMinus = PerfectoUtils
					.getIntCharacters(ioscommon.getBtnTabbarcart().getAttribute("value"));

			if (cartQtyBeforeClickingMinus > cartQtyAfterClickingMinus)
				reportMessage("Cart Qty decreases on clicking minus button..", MessageTypes.Pass);
			else
				reportMessage("Cart Qty not decreased on clicking minus button..", MessageTypes.Fail);

		} else {
			reportMessage("Minus button is not present..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify the default cart Icon before incrementation")
	public void verifyTheDefaultCartIconBeforeIncrementation() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.waitForPageToLoad();
		String strCartNumbr = pdtcdp.getIconCartIcon().getAttribute("value");

		strCartNumbr = strCartNumbr.split(" ")[0];
		System.out.println(strCartNumbr);
		getBundle().setProperty("StrBeforeIncrentation", strCartNumbr);

	}

	@QAFTestStep(description = "I verify user is navigated to last-level products screen")
	public void iVerifyUserIsNavigatedToLastLevelProductsScreen() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		int size = pdtsubcat.getLiSubcategoryproducts().size();
		String frstpdt = pdtsubcat.getLiSubcategoryproducts().get(size - 1).getText();

		if (pdtsubcat.getLiSubcategoryproducts().get(size - 1).isPresent()) {
			reportMessage("Navigated to last-level " + frstpdt + " screen with size " + size, MessageTypes.Pass);
		} else {
			reportMessage("user is not navigated to last-level product screen", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Click on Category name for adding quantity")
	public void clickOnCategoryNameForAddingQuantity() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		// Validating the Row level Categories section
		int categoriesSizeInAllProductsTab = pdtslanding.getLiRowcategorieslist().size();

		if (categoriesSizeInAllProductsTab > 0) {
			reportMessage(categoriesSizeInAllProductsTab + " Categories found in All products tab..",
					MessageTypes.Pass);

			String selectingCategory = pdtslanding.getLiRowcategorieslist().get(categoriesSizeInAllProductsTab - 2)
					.getText();
			pdtslanding.getLiRowcategorieslist().get(categoriesSizeInAllProductsTab - 2).click();
			reportMessage("Clicked on: " + selectingCategory);

		} else {
			reportMessage("No Categories found in All products tab..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify product added to the cart by weight")
	public void verifyProductAddedToTheCartByWeight() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getIconCartIcon().waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getIconCartIcon().isPresent()) {
			reportMessage("Cart number is incremented..", MessageTypes.Pass);
		} else {
			reportMessage("Cart number is not incremented..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify product added to the cart by each")
	public void verifyProductAddedToTheCartByEach() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getIconCartIcon().waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getIconCartIcon().isPresent()) {
			reportMessage("Cart number is incremented..", MessageTypes.Pass);
		} else {
			reportMessage("Cart number is not incremented..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify product added to the cart by weight adding additional product")
	public void verifyProductAddedToTheCartByWeightAddingAdditionalProduct() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.waitForPageToLoad();
		String strCartNumbr = pdtcdp.getIconCartIcon().getAttribute("value");
		strCartNumbr = strCartNumbr.split(" ")[0];

		int newValue = Integer.parseInt(strCartNumbr);
		System.out.println(strCartNumbr);

		String strQuantityVal = ConfigurationManager.getBundle().getString("StrBeforeIncrentation");
		int oldValue = Integer.parseInt(strQuantityVal);
		if (newValue > oldValue) {
			reportMessage("Cart Incremented is Done and displayed sucessfully...." + strCartNumbr, MessageTypes.Pass);
		} else {
			reportMessage("Cart Incremented is not displayed.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the product is added to cart by each adding additional product")
	public void verifyTheProductIsAddedToCartByEachAddingAdditionalProduct() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.waitForPageToLoad();
		String strCartNumbr = pdtcdp.getIconCartIcon().getAttribute("value");

		String[] strCart = strCartNumbr.split(" ");
		int newValue = Integer.parseInt(strCart[0]);
		System.out.println(newValue);
		String strQuantityVal = ConfigurationManager.getBundle().getString("StrBeforeIncrentation");
		int oldValue = Integer.parseInt(strQuantityVal);
		if (newValue > oldValue) {
			reportMessage("Cart Incremented is Done and displayed sucessfully...." + strCartNumbr, MessageTypes.Pass);
		} else {
			reportMessage("Cart Incremented is not displayed.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I navigate to qty for product item")

	public void iNavigateToQtyForProductItem() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		// Swiping till # for $ text
		PerfectoUtils.scrollToElement(pdtsubcat.getTxtAddQty());

		pdtsubcat.getTxtQtyFor$().waitForPresent(2000);
		if (pdtsubcat.getTxtQtyFor$().isPresent()) {
			reportMessage("Navigated to # for $ item.", MessageTypes.Pass);
		} else {
			reportMessage("Unable to see # for $ item.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify product price and ADD button")
	public void iVerifyProductPriceAndADDButton() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		if (pdtsubcat.getTxtAddQty().isPresent()) {
			String addText = pdtsubcat.getTxtAddQty().getText();
			reportMessage("ADD button is present with text.." + addText, MessageTypes.Pass);
		} else {
			reportMessage("ADD button is not present with text # for $..", MessageTypes.Fail);
		}

		if (pdtsubcat.getTxtQtyFor$().isPresent()) {
			String priceText = pdtsubcat.getTxtQtyFor$().getText();
			reportMessage("Price Text is present with.." + priceText, MessageTypes.Pass);
		} else {
			reportMessage("Price Text is not present", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I verify custom stepper and the cart")
	public void iVerifyCustomStepperAndTheCart() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		// Verifying Custom Stepper
		pdtsubcat.getTxtAddQty().verifyPresent();
		String addText = pdtsubcat.getTxtAddQty().getText();
		String[] addQty = addText.split(" ");
		pdtsubcat.getTxtAddQty().click();
		reportMessage("Add Button clicked..", MessageTypes.Pass);
		pdtsubcat.getTxtQtyField().verifyPresent();
		String stepperQty = pdtsubcat.getTxtQtyField().getText();
		int qty = Integer.parseInt(stepperQty);

		if (addQty[1].equals(stepperQty)) {
			reportMessage("Stepper Quantity is same as Button ..", MessageTypes.Pass);
		} else {
			reportMessage("Stepper Quantity is showing different value.", MessageTypes.Fail);
		}

		// Verifying Cart
		pdtcdp.getIconCartIcon().verifyPresent();
		String cartValueAfterADD = pdtcdp.getIconCartIcon().getAttribute("value");
		String[] cartAfterADD = cartValueAfterADD.split(" ");
		int qtyAfterAdd = Integer.parseInt(cartAfterADD[0]);

		if (qtyAfterAdd == qty) {
			reportMessage("Cart is incremented by " + qty, MessageTypes.Pass);
		} else {
			reportMessage("Cart value is mismatched..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I verify quantity will adjust by one by tapping either of the adjust quantity buttons")
	public void iVerifyQuantityWillAdjustByOneByTappingEitherOfTheAdjustQuantityButtons() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		// Clicking on + icon
		pdtsubcat.getTxtAddQty().verifyPresent();
		pdtsubcat.getTxtAddQty().click();
		reportMessage("Add Button clicked..", MessageTypes.Pass);
		pdtsubcat.getTxtQtyField().verifyPresent();
		String stepperQtyBeforeIncrement = pdtsubcat.getTxtQtyField().getText();
		int qtyBeforeIncrement = Integer.parseInt(stepperQtyBeforeIncrement);

		pdtsubcat.getTxtPlusIcon().verifyPresent();
		pdtsubcat.getTxtPlusIcon().click();

		String stepperQtyAfterIncrement = pdtsubcat.getTxtQtyField().getText();
		int qtyAfterIncrement = Integer.parseInt(stepperQtyAfterIncrement);

		if (qtyAfterIncrement > qtyBeforeIncrement) {
			reportMessage("Quantity is increased by one..", MessageTypes.Pass);
		} else {
			reportMessage("Quantity is not increased", MessageTypes.Fail);
		}

		// Clicking - icon
		pdtsubcat.getTxtMinusIcon().verifyPresent();
		pdtsubcat.getTxtMinusIcon().click();
		pdtsubcat.getTxtMinusIcon().click();

		String stepperQtyAfterDecrement = pdtsubcat.getTxtQtyField().getText();
		int qtyAfterDecrement = Integer.parseInt(stepperQtyAfterDecrement);

		if (qtyBeforeIncrement > qtyAfterDecrement) {
			reportMessage("Quantity is decreased by one..", MessageTypes.Pass);
		} else {
			reportMessage("Quantity is not decreased", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I navigated to the product")
	public void iNavigatedToTheProduct() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		// Swiping till # for $ text
		PerfectoUtils.swipeRightToProduct(pdtcdp.getTxtFirstPdt(), pdtsubcat.getTxtMinMaxPdt());

		pdtsubcat.getTxtMinMaxPdt().waitForPresent(MIN_WAIT_TIME);
		if (pdtsubcat.getTxtMinMaxPdt().isPresent()) {
			reportMessage("Navigated to the product.", MessageTypes.Pass);
		} else {
			reportMessage("Unable to see the product", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify message from the system")
	public void iVerifyMessageFromTheSystem() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLblDateNTime().waitForPresent(MIN_WAIT_TIME);
		if (pdtcdp.getLblDateNTime().isPresent()) {
			String errmssg = pdtcdp.getLblDateNTime().getText();
			reportMessage("Able to see Date and TIme in Product Landing Page. " + errmssg, MessageTypes.Pass);
		} else {
			reportMessage("Date and TIme message is not present in Product Landing Page.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify pick up time is not available for scrolling up the page")
	public void iVerifyPickUpTimeIsNotAvailableForScrollingUpThePage() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		PerfectoUtils.verticalswipe();

		pdtcdp.getLblDateNTime().waitForNotPresent(MIN_WAIT_TIME);
		if (!pdtcdp.getLblDateNTime().isPresent()) {
			reportMessage("Date and TIme is not visible.", MessageTypes.Pass);
		} else {
			reportMessage("Still Able to see Date and TIme in Product Landing Page.", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I tap on Select New Time after pickup time has expired")
	public void iTapOnSelectNewTimeAfterPickupTimeHasExpired() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLblDateNTime().verifyPresent();
		pdtcdp.getLblDateNTime().click();

		pdtcdp.getLblPlaceholderSelection().verifyPresent();
		try {
			pdtcdp.getLblExpiredTime().verifyPresent();
			pdtcdp.getLblExpiredTime().click();
			reportMessage("Expired Time clicked..", MessageTypes.Pass);
		} catch (Exception e) {
			reportMessage("Unable to see expired time..", MessageTypes.Fail);
		}
		pdtcdp.getLblDateNTime().waitForPresent(MIN_WAIT_TIME);
		pdtcdp.getLblDateNTime().verifyPresent();
		String newTime = pdtcdp.getLblDateNTime().getText();
		if (newTime.equalsIgnoreCase("Select New Time")) {
			reportMessage("Select New Time is present and clicked..", MessageTypes.Pass);
			pdtcdp.getLblDateNTime().click();
		} else {
			reportMessage("Select New Time text is not present.", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I navigates to placeholder time selection page")
	public void iNavigatesToPlaceholderTimeSelectionPage() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		if (pdtcdp.getLblPlaceholderSelection().isPresent()) {
			reportMessage("Navigate to Placeholder Time Selection page..", MessageTypes.Pass);
		} else {
			reportMessage("Unable to see Placeholder Time Selection page..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Click on the pick up time selected")
	public void clickOnThePickUpTimeSelected() {
		// ProductsSubCategoryTestPage pdtsubcat = new
		// ProductsSubCategoryTestPage();
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getLblPickuptime().waitForPresent(MIN_WAIT_TIME);
		if (ioscommon.getLblPickuptime().isPresent()) {

			ioscommon.getLblPickuptime().click();
			reportMessage("The pick up time is clicked", MessageTypes.Pass);
		} else {
			reportMessage("The pick up time is not clicked", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Navigate to the Placeholder Time Selection")
	public void navigateToThePlaceholderTimeSelection() {
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getLblPlaceholderselection().waitForPresent(MIN_WAIT_TIME);
		if (ioscommon.getLblPlaceholderselection().isDisplayed())
			reportMessage("Navigated to the Placeholder Time Selection page", MessageTypes.Pass);
		else
			reportMessage("Could Not navigated to the Placeholder Time Selection page", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify the alert message for the maximum quantity enterted")
	public void verifyTheAlertmessagefortheMaximumquantityEnterted() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getTxtMaxqtyalert().waitForPresent(MIN_WAIT_TIME);
		if (ioscommon.getTxtMaxqtyalert().isPresent()) {
			reportMessage("The alert message for the maximum qty enterd is displayed ", MessageTypes.Pass);
		} else {
			reportMessage("The alert message for the maximum qty enterd is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the error message displayed for the product availablity")
	public void verifyTheErrorMessageDisplayedForTheProductAvailablity() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getLiLblProductavailablity().get(0).waitForPresent(MIN_WAIT_TIME);
		int productavailablity = ioscommon.getLiLblProductavailablity().size();
		if (productavailablity > 0) {
			reportMessage("The error message displayed for the product availablity is displayed", MessageTypes.Pass);
		} else {
			reportMessage("The error message displayed for the product availablity is not displayed",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify an alert message in Products landing page")
	public void VerifyAnAlertMessageInProductsLandingPage() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.waitForPageToLoad();
		String strAlert = pdtslanding.getTxtAlertMsg().getText();
		if (pdtslanding.getTxtAlertMsg().isDisplayed()) {
			reportMessage("Alert message is displayed successfully...." + strAlert, MessageTypes.Pass);
		} else {
			reportMessage("Alert message is not displayed successfully..." + strAlert, MessageTypes.Fail);

		}
	}

	@QAFTestStep(description = "Verify ADD button is disabled")
	public void VerifyADDButtonIsDisabled() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getBtnSubaddproductpereach().waitForPresent(MIN_WAIT_TIME);

		if (!pdtcdp.getBtnSubaddproductpereach().isEnabled()) {
			reportMessage("ADD button is disabled as expected..", MessageTypes.Pass);
		} else {
			reportMessage("ADD button in per each product enabled..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify Done and plus button are disabled")
	public void VerifyDoneAndPlusButtonAreDisabled() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtcdp.waitForPageToLoad();

		if (pdtsubcat.getBtnDoneKeygreyedout().getAttribute("enabled").equalsIgnoreCase("false")) {
			PerfectoUtils.reportMessage("Done button is not enabled in the Keyboard as expected.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Done button is enabled in the Keyboard.", MessageTypes.Fail);
		}

		if (!pdtcdp.getBtnPlus().isEnabled()) {
			PerfectoUtils.reportMessage("Plus button is not enabled as expected...", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Plus button is enabled...", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify not available message is displayed when user is browsing a category not available")
	public void verifyNotAvailableMessageIsDisplayedWhenUserIsBrowsingACategoryNnotAvailable() {
		reportMessage("NA for iOS..");
	}

	@QAFTestStep(description = "Verify the product grid when items are not available")
	public void verifyTheProductGridWhenItemsAreNotAvailable() {
		reportMessage("NA for iOS..");
	}

	@QAFTestStep(description = "Clicks on Add button for minimum qty product")
	public void clicksOnAddButtonForMinimumQtyProduct() {
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getBtnAddminqty().waitForPresent(MIN_WAIT_TIME);

		if (ioscommon.getBtnAddminqty().isDisplayed()) {
			ioscommon.getBtnAddminqty().click();
			reportMessage("The Add button for the minimum quantity is selected", MessageTypes.Pass);
		} else
			reportMessage("The Add button for the minimum quantity is not selected", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify the alert message for the minimum quantity enterted")
	public void verifyTheAlertMessageForTheMinimumQuantityEnterted() {
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getTxtMinqtyalert().waitForPresent(MIN_WAIT_TIME);

		if (ioscommon.getTxtMinqtyalert().isDisplayed()) {

			reportMessage("The alert message for the minimum quantity is displayed", MessageTypes.Pass);
		} else
			reportMessage("The alert message for the minimum quantity is not displayed", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify able to enter the minimum value in quantity field")
	public void verifyAbleToEnterTheMinimumValueInQuantityField() {
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getTxtMinqtytext().waitForPresent(MIN_WAIT_TIME);

		if (ioscommon.getTxtMinqtytext().isPresent()) {
			ioscommon.getTxtMinqtytext().sendKeys("2");
			reportMessage("The Minimum value is entered in the quantity field", MessageTypes.Pass);
		} else {
			reportMessage("The Minimum value cannot be entered in the quantity field", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify able to enter the maximum value in quantity field")
	public void verifyAbleToEnterTheMaximumValueInQuantityField() {
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getTxtMinqtytext().waitForPresent(MIN_WAIT_TIME);
		if (ioscommon.getTxtMinqtytext().isPresent()) {
			ioscommon.getTxtMinqtytext().sendKeys("1000");
			reportMessage("The Minimum value is entered in the quantity field", MessageTypes.Pass);
		} else {
			reportMessage("The Minimum value cannot be entered in the quantity field", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Clicks on item having Each in subcategory")
	public void clicksOnItemHavingEachInSubcategory() {
		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getLiQtyeachlist().waitForPresent(MIN_WAIT_TIME);

		if (ioscommon.getLiQtyeachlist().isPresent()) {
			ioscommon.getLiQtyeachlist().waitForPresent(MIN_WAIT_TIME);
			ioscommon.getLiQtyeachlist().click();
			ioscommon.getLiQtyeachlist().waitForPresent(MIN_WAIT_TIME);
			reportMessage("Clicked on item containing Each in sub category", MessageTypes.Pass);
		} else {
			reportMessage("Item containing Each in sub category not found", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify if the product details page is displayed with Close button, product image and product name")
	public void verifyIfTheProductDetailsPageIsDisplayedWithCloseButtonProductImageandProductName() {

		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getBtnproductclose().waitForPresent(MIN_WAIT_TIME);
		if (ioscommon.getBtnproductclose().isPresent()) {
			reportMessage("The product details page is displayed with Close Button", MessageTypes.Pass);
		} else {
			reportMessage("The close button is not found", MessageTypes.Fail);
		}

		reportMessage("The product details page is displayed with product image", MessageTypes.Pass);

		ioscommon.getLiProductsname().waitForPresent(MIN_WAIT_TIME);

		if (ioscommon.getLiProductsname().isPresent()) {
			reportMessage("The product details page is displayed with product name", MessageTypes.Pass);
		}

		else {
			reportMessage("The product name is not found", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Clicks on close button in the product details page")
	public void clicksOnCloseButtonInTheProductDetailsPage() {

		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getBtnproductclose().waitForPresent(MIN_WAIT_TIME);

		if (ioscommon.getBtnproductclose().isPresent())

		{
			reportMessage("The product details page is displayed with Close Button", MessageTypes.Pass);
			ioscommon.getBtnproductclose().click();
			reportMessage("The Close Button is clicked in the product details page", MessageTypes.Pass);
		}

		else {
			reportMessage("The close button is not found", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify if the user is navigated back to the products sub category page")
	public void verifyIfTheUserIsNavigatedBackToTheProductsSubCategoryPage() {

		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getLiQtyeachlist().waitForPresent(MIN_WAIT_TIME);
		if (ioscommon.getLiQtyeachlist().isPresent()) {
			ioscommon.getLiQtyeachlist().waitForPresent(MIN_WAIT_TIME);
			reportMessage("The user is navigated back to the products sub category page and the image is visible",
					MessageTypes.Pass);
		} else {
			reportMessage("The user is not in the products sub category page", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the quantity of items selected in the product details page")
	public void verifyTheQuantityOfItemsSelectedInTheProductDetailsPage() {

		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getTxtSubqtyitem().waitForPresent(MIN_WAIT_TIME);
		if (ioscommon.getTxtSubqtyitem().isPresent()) {
			String TxtSubqtyitem = ioscommon.getTxtSubqtyitem().getText();
			reportMessage("The user is navigated to the products detail page and the quantity of item selected is "
					+ TxtSubqtyitem, MessageTypes.Pass);
		} else {
			reportMessage("The user is not in the products sub category page", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Clicks on plus button in the product details page")
	public void clicksOnPlusButtonInTheProductDetailsPage() {

		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getBtnPlussubqty().waitForPresent(MIN_WAIT_TIME);
		if (ioscommon.getBtnPlussubqty().isPresent()) {
			ioscommon.getBtnPlussubqty().waitForPresent(MIN_WAIT_TIME);
			ioscommon.getBtnPlussubqty().click();
			reportMessage("The user clicked on plus button in the products detail page", MessageTypes.Pass);
		} else {
			reportMessage("The plus button is not clicked", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Clicks on minus button in the product details page")
	public void clicksOnMinusButtonInTheProductDetailsPage() {

		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getBtnMinussubqty().waitForPresent(MIN_WAIT_TIME);
		if (ioscommon.getBtnMinussubqty().isPresent()) {
			ioscommon.getBtnMinussubqty().waitForPresent(MIN_WAIT_TIME);
			ioscommon.getBtnMinussubqty().click();
			reportMessage("The user clicked on minus button in the products detail page", MessageTypes.Pass);
		} else {
			reportMessage("The minus button is not clicked", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "Clicks on the quantity of items field in the product sub category page")
	public void clicksOnTheQuantityOfItemsFieldInTheProductSubCategoryPage() {

		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getTxtSubqtyitem().waitForPresent(MIN_WAIT_TIME);
		if (ioscommon.getTxtSubqtyitem().isPresent()) {
			ioscommon.getTxtSubqtyitem().click();
			reportMessage("The user is navigated to the productsub category page and the quantity of item is clicked ", MessageTypes.Pass);
		} else {
			reportMessage("Quantity of item field is not clicked", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "Entering 0 in quantity of items field in the product sub category page")
	public void entering0InTheQuantityOfItemsFieldInTheProductSubCategoryPage() {

		IOSCommonTestPage ioscommon = new IOSCommonTestPage();
		ioscommon.getTxtSubqtyitem().waitForPresent(MIN_WAIT_TIME);
		if (ioscommon.getTxtSubqtyitem().isPresent()) {
			ioscommon.getTxtSubqtyitem().click();
			ioscommon.getTxtSubqtyitem().sendKeys("0");
			reportMessage("Quantity button is entered with 0", MessageTypes.Pass);
		} else {
			reportMessage("Quantity of item field is not clicked", MessageTypes.Fail);
		}
	}
	
}

