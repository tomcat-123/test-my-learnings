package com.heb.automation.ios.steps.Cart;

import static com.heb.automation.common.PerfectoUtils.MIN_WAIT_TIME;
import static com.heb.automation.common.PerfectoUtils.reportMessage;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.Cart.CartLandingTestPage;
import com.heb.automation.common.pages.browse.ProductsCDPTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.heb.automation.common.pages.browse.ProductsLandingTestPage;
import com.heb.automation.common.pages.browse.ProductsSubCategoryTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

public class IOSCartStepDef {

	@QAFTestStep(description = "I verify user navigates to the cart page")
	public void iVerifyUserNavigatesToTheCartPage() {
		ProductsCDPTestPage pdtCDP = new ProductsCDPTestPage();
		CartLandingTestPage cartlanding = new CartLandingTestPage();

		pdtCDP.getIconCartIcon().click();
		cartlanding.getTxtCart().waitForPresent(MIN_WAIT_TIME);

		if (cartlanding.getTxtCart().isPresent()) {
			reportMessage("user navigates to cart page.", MessageTypes.Pass);
		} else {
			reportMessage("user is not in cart page", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Product to be added to cart")
	public void verifyTheProductToBeAddedToCart() {
		ProductsCDPTestPage productscdp = new ProductsCDPTestPage();

		String strProductCard = productscdp.getLiBrowseProducts().get(0).getText();
		System.out.println(strProductCard);
		ConfigurationManager.getBundle().setProperty("strBrowseProductCard", strProductCard);

	}

	@QAFTestStep(description = "I validate product card")
	public void iValidateProductCard() {
		CartLandingTestPage cartlanding = new CartLandingTestPage();

		// Validation of Remove button
		QAFWebElement elmProdsRemoveBtn = cartlanding.getListRemoveButton().get(0);
		if (elmProdsRemoveBtn.verifyPresent()) {
			reportMessage("Product Remove button is displayed in the cart", MessageTypes.Pass);
		} else {
			reportMessage("Product Remove button is not displayed in the cart", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I navigates to cart without adding any product")
	public void iNavigatesToCartWithoutAddingAnyProduct() {
		ProductsCDPTestPage pdtCDP = new ProductsCDPTestPage();
		CartLandingTestPage cartlanding = new CartLandingTestPage();

		pdtCDP.getIconCartIcon().click();
		cartlanding.getTxtCart().waitForPresent(MIN_WAIT_TIME);

		if (cartlanding.getTxtCart().isPresent()) {
			reportMessage("user navigates to cart page without adding any product.", MessageTypes.Pass);
		} else {
			reportMessage("user is not in cart page", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify Empty Cart page")
	public void iVerifyEmptyCartPage() {
		CartLandingTestPage cartlanding = new CartLandingTestPage();

		if (cartlanding.getTxtEmptyCart().isPresent()) {
			String emptyCart = cartlanding.getTxtEmptyCart().getText();
			reportMessage(emptyCart, MessageTypes.Pass);
		} else {
			reportMessage("Cart is not empty", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I add {0} item to the cart")
	public void iAddAItemToTheCart(int items) {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();
		ProductsCDPTestPage pdtCDP = new ProductsCDPTestPage();

		int count = 0;
		for (int i = items - 1; i >= 0; i--) {
			pdtsubcat.getLiAddbuttonlist().get(i).verifyPresent();
			pdtsubcat.getLiAddbuttonlist().get(i).click();
			count++;
		}
		String cartValue = pdtCDP.getIconCartIcon().getAttribute("value");
		String[] value = cartValue.split(" ");
		int cartNumber = Integer.parseInt(value[0]);
		getBundle().setProperty("Count", count);

		if (count == cartNumber) {
			reportMessage(count + " Item added to the cart..", MessageTypes.Pass);
		} else {
			reportMessage("Items getting mismatch", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I removed added items from the cart")
	public void iRemovedAddedItemsFromTheCart() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		int count = getBundle().getInt("Count");
		for (int i = 0; i < count; i++) {
			if (pdtsubcat.getLisSubtractItem().get(i).isPresent()) {
				pdtsubcat.getLisSubtractItem().get(i).click();
				reportMessage("Items removed", MessageTypes.Pass);
			} else {
				reportMessage("Minus button is not clicked", MessageTypes.Fail);
			}
		}
	}

	@QAFTestStep(description = "I clicked Start Shopping button")
	public void iClickedStartShoppingButton() {
		CartLandingTestPage cartlanding = new CartLandingTestPage();

		cartlanding.getBtnStartShoppping().verifyPresent();
		cartlanding.getBtnStartShoppping().click();
		reportMessage("Start shopping button clicked..", MessageTypes.Info);
	}

	@QAFTestStep(description = "I verify user navigates to Products subcategory screen")
	public void iVerifyUserNavigatesToProductsSubcategoryScreen() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);
		int size = pdtslanding.getLiHeadercategorieslist().size();
		String subCategory = getBundle().getString("selectingTopLevelCategory");
		String searchCat = pdtslanding.getLiHeadercategorieslist().get(size - 2).getText();

		if (subCategory.equalsIgnoreCase(searchCat)) {
			reportMessage("user navigated to All products screen", MessageTypes.Pass);
		} else {
			reportMessage("unable to see All products screen", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I verify product card will display")
	public void iVerifyProductCardWillDisplay() {
		CartLandingTestPage cartlanding = new CartLandingTestPage();

		cartlanding.getTxtCartProduct().waitForPresent(MIN_WAIT_TIME);
		String strIosCartProduct = cartlanding.getTxtCartProduct().getText();
		if (cartlanding.getTxtCartProduct().isDisplayed()) {
			reportMessage("Product available in the cart is displayed with Product Image,name,weight & price "
					+ strIosCartProduct, MessageTypes.Pass);
		} else {
			reportMessage("Product available in the cart is not displayed with Product Image,name,weight & price",
					MessageTypes.Fail);
			if (cartlanding.getTxtCartProduct().isDisplayed()) {
				reportMessage("Product available in the cart is displayed with Product name,weight & price "
						+ strIosCartProduct, MessageTypes.Pass);
			} else {
				reportMessage("Product available in the cart is not displayed with Product name,weight & price",
						MessageTypes.Fail);
			}
		}
	}

	@QAFTestStep(description = "I verify the Next Pickup placeholder is scrolling up")
	public void iVerifyTheNextPickupPlaceholderIsScrollingUp() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.getTxtDateAndtime().verifyPresent();
		PerfectoUtils.verticalswipeInIOSCart();
		reportMessage("srolling..", MessageTypes.Info);
		if (pdtsubcat.getTxtDateAndtime().isPresent()) {
			reportMessage("user is able to scroll Next Pickup placeholder", MessageTypes.Pass);
		} else {
			reportMessage("Next Pickup placeholder is not scrolling", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate the price of the selected product")
	public void validateThePriceOfTheSelectedProduct() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).waitForPresent(MIN_WAIT_TIME);
		String strMeatandSeafoodProductName = pdtcdp.getLiBrowseProducts().get(0).getAttribute("name");
		System.out.println(strMeatandSeafoodProductName);
		String strProductPrice = strMeatandSeafoodProductName.split(" ")[6];
		System.out.println(strProductPrice);
		char[] ch1 = strProductPrice.toCharArray();
		for (int i = 1; i <= ch1.length - 1; i++) {
		System.out.print(ch1[i]);
		}
		reportMessage("The Price of the selected producted is displayed"+strProductPrice, MessageTypes.Pass);
	}

	@QAFTestStep(description = "Validate the Cart Count")
	public void validateTheCartCount() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.waitForPageToLoad();
		String strCartNumbr = pdtcdp.getIconCartIcon().getAttribute("value");
		String[] value = strCartNumbr.split(" ");
		int cartNumber = Integer.parseInt(value[0]);
		
		System.out.println(cartNumber);
		getBundle().setProperty("StrAfterIncrementation", strCartNumbr);

	}

	@QAFTestStep(description = "I Verify the Cart total and Checkout Now button")
	public void iVerifyTheCartTotalAndCheckoutNowButton() {
		CartLandingTestPage cartlanding = new CartLandingTestPage();

		String strCartTotal = cartlanding.getTxtCartTotal().getAttribute("value");
			
		
		if(cartlanding.getTxtCartTotal().isDisplayed()){
			reportMessage("Cart total is Displayed"+strCartTotal, MessageTypes.Pass);
		} else {
			reportMessage("Cart Total is not displayed", MessageTypes.Fail);
		}
		
		if(cartlanding.getBtnCheckOutNow().isEnabled()){
			reportMessage("Cart Check out now button is available", MessageTypes.Pass);
		} else {
			reportMessage("Cart Check out now button is not available", MessageTypes.Fail);
		}
	}
}