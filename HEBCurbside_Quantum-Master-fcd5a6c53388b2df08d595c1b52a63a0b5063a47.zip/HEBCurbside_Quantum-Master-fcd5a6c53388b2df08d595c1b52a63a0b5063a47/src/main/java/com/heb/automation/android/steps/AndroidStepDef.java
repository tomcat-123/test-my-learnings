package com.heb.automation.android.steps;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import com.heb.automation.common.pages.selectastore.SelectStoreTestPage;

import java.io.IOException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import com.heb.automation.common.InstallAppAndroid;
import com.heb.automation.common.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

import io.appium.java_client.android.AndroidDriver;

public class AndroidStepDef {

	@Test
	@QAFTestStep(description = "User installs new app")
	public void userInstallsNewApp() throws Exception {

		String securityToken = getBundle().getString("driver.capabilities.securityToken");
		String deviceName_ = getBundle().getString("driver.capabilities.deviceName");
		String repository_url = getBundle().getString("repository_url_android");
		String application_name = getBundle().getString("app.name");
		String app_instrument = getBundle().getString("app_instrument");
		String sensor_instrument = getBundle().getString("sensor_instrument");

		try {
			InstallApp_Android(deviceName_, repository_url, application_name, securityToken, app_instrument,
					sensor_instrument);
			Reporter.log("App Installation completed successfully.", MessageTypes.Pass);

		} catch (Exception e) {
			Reporter.log("Error occured during App Installation.", MessageTypes.Fail);
		}
	}

	public static void InstallApp_Android(String deviceName_, String repository_url, String application_name,
			String securityToken, String app_instrument, String cam_instrument) throws IOException {
		InstallAppAndroid installApp = new InstallAppAndroid();
		System.out.println("Run started");

		DesiredCapabilities capabilities = new DesiredCapabilities("", "", Platform.ANY);
		String host = "heb.perfectomobile.com";

		capabilities.setCapability("securityToken", securityToken);
		capabilities.setCapability("deviceName", deviceName_);
		PerfectoUtils.setExecutionIdCapability(capabilities, host);

		@SuppressWarnings("unchecked")
		AndroidDriver<WebElement> driver = (AndroidDriver<WebElement>) PerfectoUtils.getAppiumDriver();
	
		try {
			installApp.uninstallApp(driver, application_name);
		} catch (Exception e) {
			e.printStackTrace();

		}
		// Old version
		InstallAppAndroid.installApp(driver, repository_url, app_instrument, cam_instrument);
		InstallAppAndroid.openApp(driver, application_name);


	}
	
}
