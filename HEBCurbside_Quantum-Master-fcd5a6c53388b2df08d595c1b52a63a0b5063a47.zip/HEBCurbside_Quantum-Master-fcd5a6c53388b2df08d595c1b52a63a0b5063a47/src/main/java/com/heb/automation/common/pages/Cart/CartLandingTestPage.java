package com.heb.automation.common.pages.Cart;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CartLandingTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "cartlanding.lis.cartplaceholder")
	private List<QAFWebElement> lisCartPlaceholder;

	@FindBy(locator = "cartlanding.txt.cart")
	private QAFWebElement txtCart;

	@FindBy(locator = "cartlanding.lis.productsimage")
	private List<QAFWebElement> lisProductsImage;

	@FindBy(locator = "cartlanding.lis.productsname")
	private List<QAFWebElement> lisProductsName;

	@FindBy(locator = "cartlanding.lis.productsprice")
	private List<QAFWebElement> lisProductsPrice;

	@FindBy(locator = "cartlanding.lis.productseachprice")
	private List<QAFWebElement> lisProductsEachPrice;

	@FindBy(locator = "cartlanding.lis.productstotalprice")
	private List<QAFWebElement> lisProductsTotalPrice;

	@FindBy(locator = "cartlanding.lis.removebutton")
	private List<QAFWebElement> lisRemoveButton;

	@FindBy(locator = "cartlanding.txt.carttotal")
	private QAFWebElement txtCartTotal;

	@FindBy(locator = "cartlanding.txt.totalamount")
	private QAFWebElement txtTotalAmount;

	@FindBy(locator = "cartlanding.btn.checkoutnow")
	private QAFWebElement btnCheckOutNow;
	
	@FindBy(locator = "cartlanding.lis.pdtcell")
	private List<QAFWebElement> lisPdtCell;
	
	@FindBy(locator = "cartlanding.txt.emptycart")
	private QAFWebElement txtEmptyCart;
	 
	@FindBy(locator = "cartlanding.btn.startshoppping")  
	private QAFWebElement btnStartShoppping;
	
	@FindBy(locator = "cartlanding.txt.cartProduct")
	private QAFWebElement txtCartProduct;

	
	public QAFWebElement getTxtCartProduct() {
		return txtCartProduct;
	}

	
	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public List<QAFWebElement> getListCartplaceholder() {
		return lisCartPlaceholder;
	}

	public QAFWebElement getTxtCart() {
		return txtCart;
	}

	public List<QAFWebElement> getListProductsImage() {
		return lisProductsImage;
	}

	public List<QAFWebElement> getListProductsName() {
		return lisProductsName;
	}

	public List<QAFWebElement> getListProductsPrice() {
		return lisProductsPrice;
	}

	public List<QAFWebElement> getListProductsEachPrice() {
		return lisProductsEachPrice;
	}

	public List<QAFWebElement> getListProductsTotalPrice() {
		return lisProductsTotalPrice;
	}

	public List<QAFWebElement> getListRemoveButton() {
		return lisRemoveButton;
	}

	public QAFWebElement getTxtCartTotal() {
		return txtCartTotal;
	}

	public QAFWebElement getTxtTotalAmount() {
		return txtTotalAmount;
	}

	public QAFWebElement getBtnCheckOutNow() {    
		return btnCheckOutNow;
	}
	
	public List<QAFWebElement> getLisPdtCell() {
		return lisPdtCell;
	}
	
	public QAFWebElement getTxtEmptyCart() {
		return txtEmptyCart;
	}
	
	public QAFWebElement getBtnStartShoppping() {
		return btnStartShoppping;
	}

}