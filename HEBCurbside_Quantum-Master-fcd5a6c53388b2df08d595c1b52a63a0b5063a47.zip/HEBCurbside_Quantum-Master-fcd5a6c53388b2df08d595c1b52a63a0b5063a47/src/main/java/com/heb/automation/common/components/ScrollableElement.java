/**
 * 
 */
package com.heb.automation.common.components;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;

import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;

import io.appium.java_client.AppiumDriver;

public class ScrollableElement extends QAFWebComponent {

	public ScrollableElement(String locator) {
		super(locator);
	}

	@Override
	protected By getBy() {

		boolean b = super.getBy().findElements(getWrappedDriver()).size() > 0;
		if (!b && getMetaData().containsKey("scrollText")) {
			if (getWrappedDriver().getCapabilities().getCapability("platformName").toString().equalsIgnoreCase("ios")) {
				QAFExtendedWebElement ele = new QAFExtendedWebElement("name=//UIATableCell[2]");
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("direction", "down");
				// params.put("element", (ele).getId());
				params.put("element", ele.getId());
				getWrappedDriver().executeScript("mobile: scroll", params);

			} else {
				String text = (String) getMetaData().get("scrollText");
				AppiumDriver<?> driver = (AppiumDriver<?>) getWrappedDriver().getUnderLayingDriver();
				driver.scrollTo(text);
			}
		}

		return super.getBy();
	}
}
