package com.heb.automation.common.pages.selectastore;

import java.util.List;

import com.heb.automation.common.components.StoreBlocksInListView;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class LocationPermissionPopupTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "locpermission.lbl.headertitle")
	private QAFWebElement lblHeadertitle;

	@FindBy(locator = "locpermission.lbl.headersubtitle")
	private QAFWebElement lblHeadersubtitle;

	@FindBy(locator = "locpermission.btn.allow")
	private QAFWebElement btnAllow;

	@FindBy(locator = "locpermission.btn.dontallow")
	private QAFWebElement btnDontallow;

	@FindBy(locator = "locpermission.chk.donotask")
	private QAFWebElement chkDonotask;
	
	@FindBy(locator = "locpermission.lbl.locationdialog")
	private QAFWebElement lblLocationdialog;

	@FindBy(locator = "locpermission.lbl.locationpopupsettings")
	private QAFWebElement lblLocationpopupsettings;
	
	@FindBy(locator = "locpermission.lbl.locationpopupsearch")
	private QAFWebElement lblLocationpopupsearch;
		
	@FindBy(locator = "locpermission.lbl.locationpopupcancel")
	private QAFWebElement lblLocationpopupcancel;
	
	@FindBy(locator = "locpermission.lbl.locationsettings")
	private QAFWebElement lblLocationsettings;
	
	public QAFWebElement getLblLocationsettings() {
		return lblLocationsettings;
	}

	public QAFWebElement getLblLocationpopupcancel() {
		return lblLocationpopupcancel;
	}

	public QAFWebElement getLblLocationpopupsearch() {
		return lblLocationpopupsearch;
	}
	
	public QAFWebElement getLblLocationpopupsettings() {
		return lblLocationpopupsettings;
	}
	
	
	public QAFWebElement getLblLocationdialog() {
		return lblLocationdialog;
	}

	public QAFWebElement getLblHeadertitle() {
		return lblHeadertitle;
	}

	public QAFWebElement getLblHeadersubtitle() {
		return lblHeadersubtitle;
	}

	public QAFWebElement getBtnAllow() {
		return btnAllow;
	}

	public QAFWebElement getBtnDontallow() {
		return btnDontallow;
	}

	public QAFWebElement getChkDonotask() {
		return chkDonotask;
	}
}