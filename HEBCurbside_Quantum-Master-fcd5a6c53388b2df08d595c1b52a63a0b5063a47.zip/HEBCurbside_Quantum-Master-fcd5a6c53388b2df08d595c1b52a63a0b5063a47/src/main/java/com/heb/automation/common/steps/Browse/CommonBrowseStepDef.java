/**
 * 
 */
package com.heb.automation.common.steps.Browse;

import static com.heb.automation.common.PerfectoUtils.reportMessage;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.HashMap;
import java.util.Map;

import static com.heb.automation.common.PerfectoUtils.MIN_WAIT_TIME;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.Products.ProductsCDPSubcategoryBlocks;
import com.heb.automation.common.components.Products.ProductsCDPSubcategoryProductBlocks;
import com.heb.automation.common.pages.browse.ProductsCDPTestPage;
import com.heb.automation.common.pages.browse.ProductsLandingTestPage;
import com.heb.automation.common.pages.browse.ProductsSubCategoryTestPage;
import com.heb.automation.common.pages.homepage.RootViewControllerTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

/*
 * 
	"The user is on Homepage"
	"Navigate to Products landing page"
	"Validate the properties of Products landing page"
	"Validate All Products section is the default category"
	"Click on a Category from top level options"
	"Verify Last level Category page"
	"Click on {0} Category from top level options"
	"Verify Navigated to Product subcategory page"
	"Clicks on view all in Product subcategory page"
	"Validate Product blocks displays with Add button"
	"Click on Category name from All products screen"
	"Clicks on Add button"
	"Clicks on quantity field"
	"Clicks on minus button"
	"Verify the Add button is visible on tapping on minus bu
	"Verify the properties of Product subcategory page"
	"Verify the last element in the product list is an end o
	"Verify the coupon icon if its associated with the produ
	"Validate able to view all the top level categories when
	"Enter the maximum values for the item selected"
	"Verify the cart number increments"
	"Clicks on plus button"
	"Clicks on Add button per weight product"
	"Verify able to scroll the categories vertically"
	"I select view all from categories page"
	"Clicks on quantity field for minimum value"

 */
public class CommonBrowseStepDef {

	@QAFTestStep(description = "The user is on Homepage")
	public void theUserIsOnHomepage() {
		RootViewControllerTestPage rvc = new RootViewControllerTestPage();

		rvc.getBtnToproductsearch().waitForPresent(MIN_WAIT_TIME);

		if (rvc.getBtnToproductsearch().isPresent())
			reportMessage("In Homepage..", MessageTypes.Pass);
		else
			reportMessage("Not in Homepage..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Navigate to Products landing page")
	public void navigateToProductsLandingPage() {
		RootViewControllerTestPage rvc = new RootViewControllerTestPage();
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		rvc.getBtnToproductsearch().waitForPresent(MIN_WAIT_TIME);
		rvc.getBtnToproductsearch().click();
		reportMessage("Clicked on- To Product Search..", MessageTypes.Pass);

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		if (pdtslanding.getLblPageheader().isPresent())
			reportMessage("Navigated to Products page..", MessageTypes.Pass);
		else
			reportMessage("Not navigated to Products page..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Validate the properties of Products landing page")
	public void validateThePropertiesOfProductsLandingPage() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);
		pdtslanding.getLblPageheader().verifyPresent();

		// Validating the Top level Categories section
		int topLevelcategoriesSize = pdtslanding.getLiHeadercategorieslist().size();

		if (topLevelcategoriesSize > 0) {
			reportMessage(topLevelcategoriesSize + " top level categories found..", MessageTypes.Pass);

			for (QAFWebElement ele : pdtslanding.getLiHeadercategorieslist()) {
				reportMessage(ele.getText());
			}
		} else {
			reportMessage("Top level categories not found..", MessageTypes.Fail);
		}

		// Validating the Row level Categories section
		int categoriesSizeInAllProductsTab = pdtslanding.getLiRowcategorieslist().size();

		if (categoriesSizeInAllProductsTab > 0) {
			reportMessage(categoriesSizeInAllProductsTab + " Categories found in All products tab..",
					MessageTypes.Pass);

			for (QAFWebElement ele : pdtslanding.getLiRowcategorieslist()) {
				reportMessage(ele.getText());
			}
		} else {
			reportMessage("No Categories found in All products tab..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Validate All Products section is the default category")
	public void validateAllProductsSectionIsTheDefaultCategory() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		int CategoriesListFromAllProductsSize = pdtslanding.getLiRowcategorieslist().size();

		if (CategoriesListFromAllProductsSize > 0)
			reportMessage("All Products section is the default category..", MessageTypes.Pass);
		else
			reportMessage("All Products section is not the default category..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Click on a Category from top level options")
	public void clickOnACategoryFromTopLevelOptions() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		int CategoriesListFromToplevelSize = pdtslanding.getLiHeadercategorieslist().size();

		if (CategoriesListFromToplevelSize > 0) {

			QAFWebElement secondTopLevelCategory = pdtslanding.getLiHeadercategorieslist()
					.get(CategoriesListFromToplevelSize - (CategoriesListFromToplevelSize - 1));

			String selectingTopLevelCategory = secondTopLevelCategory.getText();
			getBundle().setProperty("selectingTopLevelCategory", selectingTopLevelCategory);

			secondTopLevelCategory.click();
			reportMessage("Clicked on " + selectingTopLevelCategory + " from Top Level Category section..",
					MessageTypes.Pass);

		} else
			reportMessage("No categories found in top level..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify Last level Category page")
	public void verifyLastLevelCategoryPage() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		int CategoriesListFromToplevelSize = pdtslanding.getLiSecondarylevelheadercategorieslist().size();

		if (CategoriesListFromToplevelSize > 0) {

			QAFWebElement secondTopLevelCategory = pdtslanding.getLiSecondarylevelheadercategorieslist()
					.get(CategoriesListFromToplevelSize - (CategoriesListFromToplevelSize - 1));

			String selectingTopLevelCategory = secondTopLevelCategory.getText();
			getBundle().setProperty("selectingTopLevelCategory", selectingTopLevelCategory);

			secondTopLevelCategory.click();
			reportMessage("Clicked on Last level category " + selectingTopLevelCategory
					+ " from Top Level Category section..", MessageTypes.Pass);

		} else
			reportMessage("No categories found in top level..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Click on {0} Category from top level options")
	public void clickOnCategoryFromTopLevelOptions(String catName) {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		int i = 0;
		boolean isCatFound = false;
		int CategoriesListFromToplevelSize = pdtslanding.getLiHeadercategorieslist().size();

		if (CategoriesListFromToplevelSize > 0) {

			while (i < 10) {
				for (QAFWebElement ele : pdtslanding.getLiHeadercategorieslist()) {

					if (ele.getText().equals(catName)) {
						ele.click();
						reportMessage("Clicked on Category: " + catName);
						isCatFound = true;
						break;
					}
				}
				if (isCatFound)
					break;
				else {
					PerfectoUtils.halfSwipeRight(pdtslanding.getLiHeadercategorieslist().get(0));
					i++;
				}
			}

			if (isCatFound) {
				reportMessage("category: " + catName + ": not found..", MessageTypes.Fail);
			}

		} else
			reportMessage("No categories found in top level..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify Navigated to Product subcategory page")
	public void verifyNavigatedToProductSubcategoryPage() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).waitForPresent(MIN_WAIT_TIME);

		int subCategorySize = pdtcdp.getLiSubcategoryblocks().size();

		if (subCategorySize > 0)
			reportMessage("Navigated to Selected category page..", MessageTypes.Pass);
		else
			reportMessage("Not navigated to Selected category page..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Clicks on view all in Product subcategory page")
	public void clicksOnViewAllInProductSubcategoryPage() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.getLnkViewAll().waitForPresent(MIN_WAIT_TIME);
		if (pdtsubcat.getLnkViewAll().isPresent()) {
			pdtsubcat.getLnkViewAll().click();
			reportMessage("View All link is clicked in Product Subcategory page..", MessageTypes.Pass);
		} else {
			reportMessage("View All link is not clicked in Product Subcategory page..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate Product blocks displays with Add button")
	public void validateProductBlocksDisplaysWithAddButton() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		boolean isNotPresent = false;

		pdtcdp.getLiSubcategoryblocks().get(0).waitForPresent(MIN_WAIT_TIME);

		int subCategorySize = pdtcdp.getLiSubcategoryblocks().size();

		if (subCategorySize > 0) {

			for (ProductsCDPSubcategoryBlocks ele : pdtcdp.getLiSubcategoryblocks()) {

				int subCategoryProductBlocksSize = ele.getLiSubcategoryproductblocks().size();

				if (subCategoryProductBlocksSize > 0) {

					for (ProductsCDPSubcategoryProductBlocks tmp : ele.getLiSubcategoryproductblocks()) {

						if (!tmp.getLiSubcatproductAddbutton().isPresent()) {
							isNotPresent = true;
							break;
						}
						break;
					}
					break;
				} else {
					reportMessage("No Products found in Category..", MessageTypes.Fail);
				}
			}

			if (!isNotPresent) {
				reportMessage("Product blocks displays with Add button..", MessageTypes.Pass);
			} else {
				reportMessage("Product blocks not displays with Add button..", MessageTypes.Fail);
			}
		} else {
			reportMessage("No Category blocks found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Click on Category name from All products screen")
	public void clickOnCategoryNameFromAllProductsScreen() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		// Validating the Row level Categories section
		int categoriesSizeInAllProductsTab = pdtslanding.getLiRowcategorieslist().size();

		if (categoriesSizeInAllProductsTab > 0) {
			reportMessage(categoriesSizeInAllProductsTab + " Categories found in All products tab..",
					MessageTypes.Pass);

			for (QAFWebElement ele : pdtslanding.getLiRowcategorieslist()) {
				String selectingCategory = ele.getText();
				ele.click();
				reportMessage("Clicked on: " + selectingCategory);
				break;
			}
		} else {
			reportMessage("No Categories found in All products tab..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Clicks on Add button")
	public void clicksOnAddButton() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLiSubcatproductAddbutton()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleAddButton = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0)
				.getLiSubcatproductAddbutton();

		if (eleAddButton.isPresent()) {
			eleAddButton.click();
			reportMessage("Clicked on Add button..", MessageTypes.Pass);
		} else {
			reportMessage("Add button not found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Clicks on quantity field")
	public void clicksOnQuantityField() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getTxtSubcategoryValue()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleQtyValue = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0)
				.getTxtSubcategoryValue();

		if (eleQtyValue.isPresent()) {
			eleQtyValue.click();
			reportMessage("Clicked on Quantity field..", MessageTypes.Pass);
		} else {
			reportMessage("Quantity field not found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Clicks on minus button")
	public void clicksonMinusButton() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryMinus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleMinusButton = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0)
				.getLnkSubcategoryMinus();

		if (eleMinusButton.isPresent()) {
			eleMinusButton.click();
			reportMessage("Minus button is clicked..", MessageTypes.Pass);
		} else {
			reportMessage("Minus button is not clicked..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Add button is visible on tapping on minus button")
	public void verifyTheAddButtonIsVisibleOnTappingOnMinusButton() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		QAFWebElement eleMinusButton = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0)
				.getLnkSubcategoryMinus();
		QAFWebElement eleAddButton = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0)
				.getLiSubcatproductAddbutton();

		eleMinusButton.waitForPresent(MIN_WAIT_TIME);

		eleMinusButton.click();
		reportMessage("Clicked on Minus button..", MessageTypes.Pass);

		if (eleAddButton.isPresent()) {
			reportMessage("Add button got visibled..", MessageTypes.Pass);
		} else {
			reportMessage("Add button not visibled..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify the properties of Product subcategory page")
	public void verifyThePropertiesOfProductSubcategoryPage() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		int subCatSize = pdtcdp.getLiSubcategoryblocks().size();

		if (subCatSize > 0) {
			reportMessage(subCatSize + " sub-categories found..", MessageTypes.Pass);

			for (ProductsCDPSubcategoryBlocks subCatBlock : pdtcdp.getLiSubcategoryblocks()) {

				subCatBlock.getLiSubcatheadername().verifyPresent();
				subCatBlock.getLiSubcatviewall().verifyPresent();

				for (ProductsCDPSubcategoryProductBlocks productBlocks : subCatBlock.getLiSubcategoryproductblocks()) {

					productBlocks.getLiSubcatproductname().verifyPresent();
					productBlocks.getLiSubcatproductAddbutton().verifyPresent();
// Locators have been modified as a single locator.
					/*productBlocks.getLiSubcatproductimage().verifyPresent();
					productBlocks.getLiSubcatproductprice().verifyPresent();
					productBlocks.getLiSubcatproductweight().verifyPresent();
					*/
					break;
				}
				break;
			}

		} else {
			reportMessage("No sub-categories found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the last element in the product list is an end of list image")
	public void verifyTheLastElementInTheProductListIsAnEndOfListImage() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		QAFWebElement firstCategoryNameBeforeSwipe = pdtsubcat.getLiHeadercategorieslist().get(0);
		// Validating the swipe operation
		QAFWebElement firstCategoryNameAfterSwipe = pdtslanding.getLiHouseholdandkitchen();
		// Swipe right Operation
		PerfectoUtils.swipeRightToProduct(firstCategoryNameBeforeSwipe, firstCategoryNameAfterSwipe);

		if (pdtslanding.getLiHouseholdandkitchen().isPresent()) {
			pdtslanding.getLiHouseholdandkitchen().click();
			pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);
			PerfectoUtils.reportMessage("The Last Category in the product list is an end of the category list image"+firstCategoryNameAfterSwipe, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("The Last Category in the product list is not an end of the category list image", MessageTypes.Fail);
		}
		QAFWebElement firstSubCategoryNameBeforeSwipe = pdtslanding.getLiSubCategoryhouseholdandkitchen().get(0);
		// Validating the swipe operation
		QAFWebElement firstSubCategoryNameAfterSwipe = pdtslanding.getLiLastsubCategoryhouseholdandkitchen();
		// Swipe right Operation
		PerfectoUtils.swipeRightToProduct(firstSubCategoryNameBeforeSwipe, firstSubCategoryNameAfterSwipe);
			PerfectoUtils.reportMessage("The Last element in the product list is an end of the list image", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify the coupon icon if its associated with the product")
	public void verifyTheCouponIconIfItsAssociatedWithTheProduct() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		boolean isCouponIconPresent = false;
		int subCatSize = pdtcdp.getLiSubcategoryblocks().size();

		if (subCatSize > 0) {
			reportMessage(subCatSize + " sub-categories found..", MessageTypes.Pass);

			for (ProductsCDPSubcategoryBlocks subCatBlocks : pdtcdp.getLiSubcategoryblocks()) {

				for (ProductsCDPSubcategoryProductBlocks subCarProductBlocks : subCatBlocks
						.getLiSubcategoryproductblocks()) {

					if (subCarProductBlocks.getLiSubcatproductcouponindicator().isPresent()) {
						isCouponIconPresent = true;
						break;
					}
				}

				if (isCouponIconPresent)
					break;
				else
					continue;
			}

			if (isCouponIconPresent)
				reportMessage("Coupon icon validated if its associated with the product..", MessageTypes.Pass);
			else
				reportMessage("Coupon icon validation failed..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate able to view all the top level categories when swiping right to left")
	public void validateAbleToViewAllTheTopLevelCategorieswhenSwipingRightToLeft() {
		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();

		pdtslanding.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		// Validating the Top level Categories section
		int topLevelcategoriesSize = pdtslanding.getLiHeadercategorieslist().size();

		if (topLevelcategoriesSize > 0) {
			reportMessage(topLevelcategoriesSize + " top level categories found..", MessageTypes.Pass);

			String firstCategoryNameBeforeSwipe = pdtslanding.getLiHeadercategorieslist().get(0).getText();

			// Swipe right Operation
			PerfectoUtils.swipeRight(pdtslanding.getLiHeadercategorieslist().get(0));

			// Validating the Swipe operation is successful
			String firstCategoryNameAfterSwipe = pdtslanding.getLiHeadercategorieslist().get(0).getText();

			if (!firstCategoryNameBeforeSwipe.equals(firstCategoryNameAfterSwipe))
				reportMessage("Swiped and additional top level sub categories are visible..", MessageTypes.Pass);
			else
				reportMessage("Swiped and additional top level sub categories are not visible..", MessageTypes.Fail);

		} else {
			reportMessage("Top level categories not found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Enter the maximum values for the item selected")
	public void enterTheMaximumValuesForTheItemSelected() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLiSubcatproductAddbutton()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement eleAddButton = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0)
				.getLiSubcatproductAddbutton();

		eleAddButton.clear();

		eleAddButton.sendKeys("100");

	}

	@QAFTestStep(description = "Verify the cart number increments")
	public void verifyCartNumberIncrements() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getIconCartIcon().waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getIconCartIcon().isPresent()) {
			reportMessage("Cart number is incremented..", MessageTypes.Pass);
		} else {
			reportMessage("Cart number is not incremented..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Clicks on plus button")
	public void clicksonPlusButton() {
		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0).getLnkSubcategoryPlus()
				.waitForPresent(MIN_WAIT_TIME);

		QAFWebElement elePlusButton = pdtcdp.getLiSubcategoryblocks().get(0).getLiSubcategoryproductblocks().get(0)
				.getLnkSubcategoryPlus();

		if (elePlusButton.isPresent()) {
			elePlusButton.click();
			reportMessage("Plus button is clicked..", MessageTypes.Pass);
		} else {
			reportMessage("Plus button is not clicked..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Clicks on Add button per weight product")
	public void clicksOnAddButtonPerWeightProduct() {

		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getBtnSubaddproductperweight().waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getBtnSubaddproductperweight().isPresent()) {
			pdtcdp.getBtnSubaddproductperweight().click();
			reportMessage("Clicked on Add product per weight button..", MessageTypes.Pass);
		} else {
			reportMessage("Add per weight button not found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Clicks on Add button per each product")
	public void clicksOnAddButtonPerEachProduct() {

		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();

		pdtcdp.getBtnSubaddproductpereach().waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getBtnSubaddproductpereach().isPresent()) {
			pdtcdp.getBtnSubaddproductpereach().click();
			reportMessage("Clicked on Add button in per each product..", MessageTypes.Pass);
		} else {
			reportMessage("Add button in per each product is not found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify able to scroll the categories vertically")
	public void verifyAbleToScrollTheCategoriesVertically() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.getLblPageheader().waitForPresent(MIN_WAIT_TIME);

		// Validating the Top level Sub Categories section
		int topLevelcategoriesSize = pdtsubcat.getLiHeadercategorieslist().size();

		if (topLevelcategoriesSize > 0) {
			reportMessage(topLevelcategoriesSize + " top level categories found..", MessageTypes.Pass);

			PerfectoUtils.verticalswipe();

			reportMessage("The category is scrolled sucessfully", MessageTypes.Pass);

		} else {
			reportMessage("The category is not scrolled sucessfully", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I select view all from categories page")
	public void iSelectViewAllFromCategoriesPage() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();

		pdtsubcat.getLnkViewAll().verifyPresent();
		pdtsubcat.getLnkViewAll().click();
		reportMessage("View All clicked..", MessageTypes.Pass);

	}

	@QAFTestStep(description = "Clicks on quantity field for minimum value")
	public void clicksOnQuantityFieldForMinimumValue() {
		ProductsSubCategoryTestPage pdtsubcat = new ProductsSubCategoryTestPage();
		pdtsubcat.getTxtMinqtypdt().waitForPresent(MIN_WAIT_TIME);

		if (pdtsubcat.getTxtMinqtypdt().isPresent()) {
			pdtsubcat.getTxtMinqtypdt().click();
			reportMessage("Clicked on Quantity field..", MessageTypes.Pass);
		} else {
			reportMessage("Quantity field not found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Clicks on baby and toys category")
	public void clicksOnBabyAndToysCategory() {

		ProductsLandingTestPage pdtslanding = new ProductsLandingTestPage();
		pdtslanding.getLiBabyandtoys().waitForPresent(MIN_WAIT_TIME);

		if (pdtslanding.getLiBabyandtoys().isPresent()) {
			pdtslanding.getLiBabyandtoys().click();
			reportMessage("Clicked on baby and toys category", MessageTypes.Pass);
		} else {
			reportMessage("baby and toys category not found", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Clicks on item having Each in subcategory")
	public void clicksOnItemHavingEachInSubcategory() {

		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		pdtcdp.getLiSubcatproducteach().waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getLiSubcatproducteach().isPresent()) {
			pdtcdp.getLiSubcatproducteach().waitForPresent(MIN_WAIT_TIME);
			pdtcdp.getLiSubcatproducteach().click();
			pdtcdp.getLiSubcatproducteach().waitForPresent(MIN_WAIT_TIME);
			reportMessage("Clicked on item containing Each in sub category", MessageTypes.Pass);
		} else {
			reportMessage("Item containing Each in sub category not found", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify if the product details page is displayed with Close button, product image and product name")
	public void verifyIfTheProductDetailsPageIsDisplayedWithCloseButtonProductImageandProductName() {

		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		pdtcdp.getBtnSubcatproductclose().waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getBtnSubcatproductclose().isPresent()) {
			reportMessage("The product details page is displayed with Close Button", MessageTypes.Pass);
		} else {
			reportMessage("The close button is not found", MessageTypes.Fail);
		}

		pdtcdp.getLiSubproductsimage().waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getLiSubproductsimage().isPresent()) {
			reportMessage("The product details page is displayed with product image", MessageTypes.Pass);
		} else {
			reportMessage("The product image is not found", MessageTypes.Fail);
		}

		pdtcdp.getLiSubproductsname().waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getLiSubproductsname().isPresent()) {
			reportMessage("The product details page is displayed with product name", MessageTypes.Pass);
		} else {
			reportMessage("The product name is not found", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Clicks on close button in the product details page")
	public void clicksOnCloseButtonInTheProductDetailsPage() {

		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		pdtcdp.getBtnSubcatproductclose().waitForPresent(MIN_WAIT_TIME);

		if (pdtcdp.getBtnSubcatproductclose().isPresent())

		{
			reportMessage("The product details page is displayed with Close Button", MessageTypes.Pass);
			pdtcdp.getBtnSubcatproductclose().click();
			pdtcdp.getBtnSubcatproductclose().waitForNotPresent(MIN_WAIT_TIME);
			reportMessage("The Close Button is clicked in the product details page", MessageTypes.Pass);
		} else {
			reportMessage("The close button is not found", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify if the user is navigated back to the products sub category page")
	public void verifyIfTheUserIsNavigatedBackToTheProductsSubCategoryPage() {

		ProductsCDPTestPage pdtcdp = new ProductsCDPTestPage();
		pdtcdp.getLiSubcatproducteach().waitForPresent(MIN_WAIT_TIME);
		if (pdtcdp.getLiSubcatproducteach().isPresent()) {
			pdtcdp.getLiSubcatproducteach().waitForPresent(MIN_WAIT_TIME);
			reportMessage("The user is navigated back to the products sub category page and the image is visible",
					MessageTypes.Pass);
		} else {
			reportMessage("The user is not in the products sub category page", MessageTypes.Fail);
		}
	}
}
