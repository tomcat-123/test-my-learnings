/**
 * 
 */
package com.heb.automation.common.steps.SelectAStore;

import static com.heb.automation.common.PerfectoUtils.VerticalswipeDown;
import static com.heb.automation.common.PerfectoUtils.getDriver;
import static com.heb.automation.common.PerfectoUtils.pressKeyboardSearch;
import static com.heb.automation.common.PerfectoUtils.verticalswipe;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.HashMap;
import java.util.Map;

import com.heb.automation.common.components.StoreBlocksInListView;
import com.heb.automation.common.pages.appcommon.AppCommonTestPage;
import com.heb.automation.common.pages.selectastore.ListViewTestPage;
import com.heb.automation.common.pages.selectastore.MapAndListViewTestPage;
import com.heb.automation.common.pages.selectastore.SelectStoreTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class SelectStoreStepDef {

	@QAFTestStep(description = "I am on Select a store homepage")
	public void iAmOnSelectAStoreHomepage() {
		SelectStoreTestPage selectstore = new SelectStoreTestPage();

		selectstore.getSelectstoreLblPagetitle().waitForPresent(5000);

		if (selectstore.getSelectstoreLblPagetitle().isPresent())
			Reporter.log("In Select A Store Page..", MessageTypes.Pass);
		else
			Reporter.log("Not in Select A Store Page..", MessageTypes.Fail);

	}

	/**
	 * Verify the properties of Select A Store HOMEPAGE
	 */
	@QAFTestStep(description = "Validate the properties of Select a Store homepage")
	public void validateThePropertiesOfSelectAStoreHomepage() {
		SelectStoreTestPage selectstore = new SelectStoreTestPage();

		selectstore.getSelectstoreLblPagetitle().waitForPresent(5000);
		selectstore.getSelectstoreLblPagetitle().verifyPresent();
		selectstore.getImgPageimage().verifyPresent();
		selectstore.getLblPagetext().verifyPresent();
		selectstore.getIconPagenearme().verifyPresent();
		selectstore.getLblPagenearme().verifyPresent();
		selectstore.getIconPagesearch().verifyPresent();
		selectstore.getLblPagesearch().verifyPresent();
		selectstore.getIconPageviewall().verifyPresent();
		selectstore.getLblPageviewall().verifyPresent();
	}

	@QAFTestStep(description = "Click on Near Me and navigate to map and list view page")
	public void clickOnNearMeAndNavigateToMapAndListViewPage() {
		SelectStoreTestPage selectstore = new SelectStoreTestPage();

		selectstore.getIconPagenearme().waitForPresent(5000);
		selectstore.getIconPagenearme().click();
		Reporter.log("Clicked on Nearme option..", MessageTypes.Pass);
	}

//	@QAFTestStep(description = "Verify the properties of Map and list view page")
//	public static void verifyThePropertiesOfMapAndListViewPage() {
//		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();
//		AppCommonTestPage appcommon = new AppCommonTestPage();
//		StoreBlocksInListView storeblocks = new StoreBlocksInListView();
//
//		appcommon.getTxtEnterzip().waitForPresent(5000);
//		appcommon.getTxtEnterzip().verifyPresent();
//		appcommon.getBtnBackinheader().verifyPresent();
//
//		// Validating the map view
//		int mapsIconSize = mapandlistview.getLiMapiconslist().size();
//		if (mapsIconSize > 0) {
//			Reporter.log(mapsIconSize + " stores found in map view..", MessageTypes.Pass);
//		} else {
//			Reporter.log("No Stores found in map view..", MessageTypes.Fail);
//		}
//
//		// Validating the list view
//		int listviewSize = mapandlistview.getLiStoreblocksinlistview().size();
//		if (listviewSize > 0) {
//			Reporter.log(listviewSize + " stores found in list view..", MessageTypes.Pass);
//
//			for (int i = 0; i < listviewSize-1; i++) {
//				storeblocks.getLblStorename().get(i).verifyPresent();
//				storeblocks.getLblStreetaddress().get(i).verifyPresent();
//				storeblocks.getLblCitystate().get(i).verifyPresent();
//				storeblocks.getLblCurbsidehours().get(i).verifyPresent();
//			}
//			// for (QAFWebElement ele :
//			// mapandlistview.getLiStoreblocksinlistview()) {
//			// ((StoreBlocksInListView) ele).getLblStorename().verifyPresent();
//			// ((StoreBlocksInListView)
//			// ele).getLblStreetaddress().verifyPresent();
//			// ((StoreBlocksInListView) ele).getLblCitystate().verifyPresent();
//			// ((StoreBlocksInListView)
//			// ele).getLblCurbsidehours().verifyPresent();
//			// break;
//			// }
//
//		} else {
//			Reporter.log("No Stores found in list view..", MessageTypes.Fail);
//		}
//	}

//	@QAFTestStep(description = "Select back button from the header")
//	public void selectBackButtonFromTheHeader() {
//		AppCommonTestPage appcommon = new AppCommonTestPage();
//
//		appcommon.getBtnBackinheader().waitForPresent(5000);
//		appcommon.getBtnBackinheader().click();
//		Reporter.log("Clicked on back button from header..", MessageTypes.Pass);
//	}

//	@QAFTestStep(description = "Verify the Select a store homepage is getting displayed")
//	public void verifyTheSelectAStoreHomepageIsGettingDisplayed() {
//		SelectStoreTestPage selectstore = new SelectStoreTestPage();
//
//		selectstore.getLblPagetext().waitForPresent(5000);
//
//		if (selectstore.getLblPagetext().isPresent()) {
//			Reporter.log("User is in Select a Store homepage..", MessageTypes.Pass);
//		} else {
//			Reporter.log("Error occured while navigating to Select a Store homepage..", MessageTypes.Fail);
//		}
//
//	}

//	@QAFTestStep(description = "Select a Store from List View")
//	public void selectAStoreFromListView() {
//		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();
//
//		// Validating the list view
//		int listviewSize = mapandlistview.getLiStoreblocksinlistview().size();
//		if (listviewSize > 0) {
//			Reporter.log(listviewSize + " stores found in list view..", MessageTypes.Pass);
//
//			for (QAFWebElement ele : mapandlistview.getLiStoreblocksinlistview()) {
//				((StoreBlocksInListView) ele).getLblStorename().get(0).waitForPresent(5000);
//				String storename = ((StoreBlocksInListView) ele).getLblStorename().get(0).getText();
//				((StoreBlocksInListView) ele).getLblStorename().get(0).click();
//				Reporter.log("Clicked on Store name: " + storename + " from list view..", MessageTypes.Pass);
//				break;
//			}
//		} else {
//			Reporter.log("No Stores found in list view..", MessageTypes.Fail);
//		}
//	}

	@QAFTestStep(description = "Validate the properties of Select a store page with Select button")
	public void validateThePropertiesOfSelectAStorePageWithSelectButton() {
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();

		mapandlistview.getBtnSave().waitForPresent(5000);
		if (mapandlistview.getBtnSave().isPresent()) {
			Reporter.log("Save button is present..", MessageTypes.Pass);
		} else {
			Reporter.log("Save button is not present..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Select a Store from map View")
	public void selectAStoreFromMapView() {
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();
		AppCommonTestPage appcommon = new AppCommonTestPage();

		appcommon.getTxtEnterzip().waitForPresent(5000);
		appcommon.getTxtEnterzip().verifyPresent();
		appcommon.getBtnBackinheader().verifyPresent();

		// Validating the map view
		int mapsIconSize = mapandlistview.getLiMapiconslist().size();
		if (mapsIconSize > 0) {
			Reporter.log(mapsIconSize + " stores found in map view..", MessageTypes.Pass);

			mapandlistview.getLiMapiconslist().get(mapsIconSize - 2).waitForPresent(5000);
			mapandlistview.getLiMapiconslist().get(mapsIconSize - 2).click();
			Reporter.log("Clicked on Store Icon from Map view..", MessageTypes.Pass);

		} else {
			Reporter.log("No Stores found in map view..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Save button is getting displayed")
	public void verifyTheSaveButtonIsGettingDisplayed() {
		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();

		mapandlistview.getBtnSave().waitForPresent(5000);
		if (mapandlistview.getBtnSave().isPresent()) {
			Reporter.log("Save button is present..", MessageTypes.Pass);
		} else {
			Reporter.log("Save button is not present..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify navigated to Map and List view page")
	public static void verifyNavigatedToMapAndListViewPage() {
		//verifyThePropertiesOfMapAndListViewPage();
	}

	@QAFTestStep(description = "Perform the Swipe up operation in Map and List View page")
	public void performTheSwipeUpOperationInMapAndListViewPage() {
		AppCommonTestPage appcommon = new AppCommonTestPage();

		appcommon.getTxtEnterzip().waitForPresent(5000);

		if (appcommon.getTxtEnterzip().isPresent()) {
			Reporter.log("Navigated to Map and list view page..", MessageTypes.Pass);

			verticalswipe();
			Reporter.log("Swiped up..", MessageTypes.Pass);

		} else {
			Reporter.log("Not Navigated to Map and list view page..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the map view is not displayed")
	public void verifyTheMapViewIsNotDisplayed() {

		String isStoreIconInMapViewPresent;
		try {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "GROUP:Curbside\\Pics\\SelectStore\\storeiconinmapview.png");
			isStoreIconInMapViewPresent = (String) getDriver().executeScript("mobile:checkpoint:image", params1);
		} catch (Exception e) {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "GROUP:Curbside\\Pics\\SelectStore\\storeiconinmapview.png");
			isStoreIconInMapViewPresent = (String) getDriver().executeScript("mobile:image:find", params1);
		}

		if (isStoreIconInMapViewPresent.equalsIgnoreCase("false"))
			Reporter.log("Map view is not displayed..", MessageTypes.Pass);
		else
			Reporter.log("Map view is still getting displayed..", MessageTypes.Fail);

	}

//	@QAFTestStep(description = "Perform the Swipe down operation")
//	public void performTheSwipeDownOperation() {
//		AppCommonTestPage appcommon = new AppCommonTestPage();
//
//		appcommon.getTxtEnterzip().waitForPresent(5000);
//
//		if (appcommon.getTxtEnterzip().isPresent()) {
//			Reporter.log("Navigated to Map and list view page..", MessageTypes.Pass);
//
//			VerticalswipeDown();
//			Reporter.log("Swiped down..", MessageTypes.Pass);
//
//		} else {
//			Reporter.log("Not in Map and list view page..", MessageTypes.Fail);
//		}
//	}

	@QAFTestStep(description = "Verify the Map view is getting displayed")
	public void verifyTheMapViewIsGettingDisplayed() {

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "GROUP:Curbside\\Pics\\SelectStore\\storeiconinmapview.png");

		String isStoreIconInMapViewPresent = (String) getDriver().executeScript("mobile:checkpoint:image", params1);

		if (isStoreIconInMapViewPresent.equalsIgnoreCase("true"))
			Reporter.log("Map view is getting displayed..", MessageTypes.Pass);
		else
			Reporter.log("Map view is not getting displayed..", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Click on View All option")
	public void clickOnViewAllOption() {
		SelectStoreTestPage selectstore = new SelectStoreTestPage();

		selectstore.getLblPageviewall().waitForPresent(5000);
		selectstore.getLblPageviewall().click();
		Reporter.log("Clicked on View All option..", MessageTypes.Pass);
	}

//	@QAFTestStep(description = "Verify navigated to Select a Store list view screen")
//	public void verifyNavigatedToSelectAStoreListViewScreen() {
//		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();
//		AppCommonTestPage androidcommon = new AppCommonTestPage();
//
//		String searchboxText = getBundle().getString("selectastore.searchboxtext");
//		androidcommon.getTxtEnterzip().verifyText(searchboxText);
//
//		int listviewSize = mapandlistview.getLiStoreblocksinlistview().size();
//		if (listviewSize > 0) {
//			Reporter.log(listviewSize + " stores found in list view..", MessageTypes.Pass);
//		} else {
//			Reporter.log("Not navigated to list view page..", MessageTypes.Fail);
//		}
//	}

	/**
	 * Select on Search Option
	 */
//	@QAFTestStep(description = "Click on Search option and verify the search screen gets opened")
//	public void ClickOnSearchOptionAndVerifyTheSearchScreenGetsOpened() {
//		SelectStoreTestPage selectstore = new SelectStoreTestPage();
//		AppCommonTestPage androidcommon = new AppCommonTestPage();
//
//		selectstore.getLblPagesearch().waitForPresent(5000);
//		selectstore.getLblPagesearch().click();
//		Reporter.log("Clicked on Search option successfully..", MessageTypes.Pass);
//
//		// Validating the hint text
//		String searchboxText = getBundle().getString("selectastore.searchboxtext");
//		androidcommon.getTxtEnterzip().verifyText(searchboxText);
//	}

	@QAFTestStep(description = "Enter valid search term and select search button")
	public void EnterValidSearchTermAndSelectSearchButton() {
		ListViewTestPage lstViewPge = new ListViewTestPage();

		String SearchStore = getBundle().getString("selectastore.searchstore");
		lstViewPge.getTxtSearchbox().waitForPresent(5000);
		lstViewPge.getTxtSearchbox().sendKeys(SearchStore);
		Reporter.log("Entered Search term: " + SearchStore);

		// Tap on Search from keyboard
		pressKeyboardSearch();
	}

	@QAFTestStep(description = "Enter valid search term")
	public void enterValidSearchTerm() {
		ListViewTestPage lstViewPge = new ListViewTestPage();

		String SearchStore = getBundle().getString("selectastore.searchstore");
		lstViewPge.getTxtSearchbox().waitForPresent(5000);
		lstViewPge.getTxtSearchbox().sendKeys(SearchStore);
		Reporter.log("Entered Search Store: " + SearchStore, MessageTypes.Pass);
	}

//	@QAFTestStep(description = "Verify the stores are listed for the entered store term")
//	public void verifyTheStoresAreListedForTheEnteredStoreTerm() {
//		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();
//
//		String SearchStore = getBundle().getString("selectastore.searchstore").toLowerCase();
//		if (((StoreBlocksInListView) mapandlistview.getLiStoreblocksinlistview().get(0)).getLblCitystate().get(0)
//				.getText().toLowerCase().contains(SearchStore))
//			Reporter.log("Matched the Search Store: " + SearchStore, MessageTypes.Pass);
//		else
//			Reporter.log("Not Matched the Search store..", MessageTypes.Fail);
//	}

//	@QAFTestStep(description = "Click on Close button from the header")
//	public void clickOnCloseButtonFromTheHeader() {
//		ListViewTestPage lstViewPge = new ListViewTestPage();
//		MapAndListViewTestPage mapandlistview = new MapAndListViewTestPage();
//
//		mapandlistview.getBtnClose().waitForPresent(5000);
//		mapandlistview.getBtnClose().click();
//		Reporter.log("Clicked the Close button..", MessageTypes.Pass);
//
//	}

//	@QAFTestStep(description = "Verify the entered search term got cleared")
//	public void verifyTheEnteredSearchTermGotCleared() {
//		AppCommonTestPage appcommon = new AppCommonTestPage();
//
//		String SearchBoxText = appcommon.getTxtEnterzip().getText();
//		if (SearchBoxText.contains("Search City or ZIP")) {
//			Reporter.log("Entered search term got cleared or removed..", MessageTypes.Pass);
//			Reporter.log("Search box text: " + SearchBoxText);
//		} else {
//			Reporter.log("Entered search term not cleared or removed: " + SearchBoxText, MessageTypes.Fail);
//		}
//	}
}
