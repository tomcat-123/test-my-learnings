package com.heb.automation.common;

import org.openqa.selenium.remote.DriverCommand;
import org.openqa.selenium.remote.Response;

import com.qmetry.qaf.automation.ui.webdriver.CommandTracker;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElementCommandAdapter;

public class IOSWebElementListener extends QAFWebElementCommandAdapter {

	@Override
	public void beforeCommand(QAFExtendedWebElement element, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.IS_ELEMENT_DISPLAYED)) {
			Response response = new Response();

			response.setValue(true);
			commandTracker.setResponce(response);
		}

		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.CLEAR_ELEMENT)) {
			Response response = new Response();
			commandTracker.setResponce(response);
		}
	}

	@Override
	public void afterCommand(QAFExtendedWebElement element, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.SEND_KEYS_TO_ELEMENT)) {
			try {
				PerfectoUtils.getAppiumDriver().hideKeyboard();
			} catch (Exception e) {
				/* Just ignore it */
			}
		}
	}

	@Override
	public void onFailure(QAFExtendedWebElement element, CommandTracker commandTracker) {

	}
}
