/**
 * 
 */
package com.heb.automation.common.databean;

import java.util.Map;

import com.heb.automation.common.components.ScrollableElement;
import com.qmetry.qaf.automation.data.BaseFormDataBean;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.annotations.UiElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.RandomStringGenerator.RandomizerTypes;
import com.qmetry.qaf.automation.util.Randomizer;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

/**
 * @author chirag.jayswal
 *
 */
public class RegistrationBean extends BaseFormDataBean {

	@Randomizer(type = RandomizerTypes.LETTERS_ONLY, length = 4)
	@UiElement(fieldLoc = "reg.txt.firstname", order = 2)
	private String firstName;

	@Randomizer(type = RandomizerTypes.LETTERS_ONLY, length = 4)
	@UiElement(fieldLoc = "reg.txt.lastname", order = 3)
	private String lastName;
	
	@Randomizer(type = RandomizerTypes.MIXED, length = 5, suffix = "@mailer.com")
	@UiElement(fieldLoc = "reg.txt.email", order = 4)
	private String email;
	
	@Randomizer(type = RandomizerTypes.LETTERS_ONLY, length = 5, suffix = "@123")
	@UiElement(fieldLoc = "reg.txt.password", order = 1)
	private String password;


	@Randomizer
	@UiElement(fieldLoc = "registration.chk.iagree", order = 7)
	private Boolean iAgree;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
		getBundle().setProperty("strpassword", password);
	}

	
	public boolean isiAgree() {
		return iAgree;
	}

	public void setiAgree(boolean iAgree) {
		this.iAgree = iAgree;
	}

	public void filliAgree() {
		QAFExtendedWebElement ele = new QAFExtendedWebElement("reg.chk.iagree");
		boolean isSelected = ele.isSelected();
		if (!(iAgree && isSelected)) {
			ele.click();
		}
	}

	@QAFTestStep(description = "fill Registration Form")
	public void fillRegistrationForm() {
		fillRandomData();
		fillUiElements();
	}

	@QAFTestStep(description = "fill Registration Form for {RegistrationData}")
	public void fillRegistrationForm(Map<String, Object> o) {
		
		fillData(o);
		fillUiElements();
		ScrollableElement submit = new ScrollableElement("");
	}

}
