/**
 * 
 */
package com.heb.automation.common.steps;

import com.heb.automation.common.PerfectoUtils;
import com.qmetry.qaf.automation.step.QAFTestStep;

/* List of Steps in CommonSteps

I navigate back to homepage

*/

public class CommonSteps {

	/**
	 * Navigate back to home page
	 */
	@QAFTestStep(description = "I navigate back to homepage")
	public void iNavigateToHomepageUsingBackButton() {

		PerfectoUtils.getAppiumDriver().navigate().back();
	}

}
