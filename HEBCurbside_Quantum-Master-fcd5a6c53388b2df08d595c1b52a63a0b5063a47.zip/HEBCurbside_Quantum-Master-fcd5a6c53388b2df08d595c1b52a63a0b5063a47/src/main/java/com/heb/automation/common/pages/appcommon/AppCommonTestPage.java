package com.heb.automation.common.pages.appcommon;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class AppCommonTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "appcom.lnk.backinheader")
	private QAFWebElement btnBackinheader ;

	@FindBy(locator = "appcom.btn.enterzip")
	private QAFWebElement txtEnterzip;

	public QAFWebElement getBtnBackinheader() {
		return btnBackinheader;
	}

	public QAFWebElement getTxtEnterzip() {
		return txtEnterzip;
	}
}