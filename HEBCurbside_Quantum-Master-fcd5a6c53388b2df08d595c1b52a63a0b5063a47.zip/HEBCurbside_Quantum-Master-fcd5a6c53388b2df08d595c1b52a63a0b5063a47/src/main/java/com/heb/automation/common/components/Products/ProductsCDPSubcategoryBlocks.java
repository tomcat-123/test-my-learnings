package com.heb.automation.common.components.Products;

import java.util.List;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ProductsCDPSubcategoryBlocks extends QAFWebComponent {

	public ProductsCDPSubcategoryBlocks(String locator) {
		super(locator);
	}

	@FindBy(locator = "productscdp.li.subcatviewall")
	private QAFWebElement liSubcatviewall;

	@FindBy(locator = "productscdp.li.subcatheadername")
	private QAFWebElement liSubcatheadername;

	@FindBy(locator = "productscdp.li.subcatendofproductsimage")
	private QAFWebElement liSubcatendofproductsimage;

	@FindBy(locator = "productscdp.li.subcategoryproductblocks")
	private List<ProductsCDPSubcategoryProductBlocks> liSubcategoryproductblocks;
	
	

	
	public QAFWebElement getLiSubcatviewall() {
		return liSubcatviewall;
	}

	public QAFWebElement getLiSubcatheadername() {
		return liSubcatheadername;
	}

	public List<ProductsCDPSubcategoryProductBlocks> getLiSubcategoryproductblocks() {
		return liSubcategoryproductblocks;
	}

	public QAFWebElement getLiSubcatendofproductsimage() {
		return liSubcatendofproductsimage;
	}
}