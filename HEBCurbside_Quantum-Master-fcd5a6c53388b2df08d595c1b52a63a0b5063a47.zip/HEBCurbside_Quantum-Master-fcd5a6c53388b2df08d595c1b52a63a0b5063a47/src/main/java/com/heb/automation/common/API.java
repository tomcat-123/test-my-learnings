package com.heb.automation.common;

import java.io.IOException;
import java.io.StringReader;

import javax.swing.text.Document;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.HttpClientBuilder;
import org.w3c.dom.DOMException;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.qmetry.qaf.automation.step.QAFTestStep;

/**
 * 
 */

public class API {

	@QAFTestStep(description = "Execute API to retrieve Perfecto cloud devices data")
	public void executeAPIToRetrievePerfectoCloudDevicesData()
			throws ClientProtocolException, IOException, Exception, SAXException {

		String USER_AGENT = "Chrome";
		String url = "https://heb.perfectomobile.com/services/handsets?operation=list&user=Dhinakaran.Kalaiselvi@heb.com&password=perfectoHEB1234&status=connected";

		HttpClient client = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet(url);

		// add request header
		request.addHeader("User-Agent", USER_AGENT);
		HttpResponse response = client.execute(request);

		System.out.println("Response Code : " + response.getStatusLine().getStatusCode());
		HttpEntity entity = response.getEntity();

		ResponseHandler<String> handler = new BasicResponseHandler();
		String body = handler.handleResponse(response);

		System.out.println(body);

		DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		InputSource src = new InputSource();
		src.setCharacterStream(new StringReader(body));

		String deviceId = builder.parse(src).getElementsByTagName("deviceId").item(0).getTextContent();
						
		System.out.println(deviceId);
		
	}
}