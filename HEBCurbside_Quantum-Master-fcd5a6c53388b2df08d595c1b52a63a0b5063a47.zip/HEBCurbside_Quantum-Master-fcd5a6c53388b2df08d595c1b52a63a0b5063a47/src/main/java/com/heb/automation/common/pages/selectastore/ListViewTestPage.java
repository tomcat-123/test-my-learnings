package com.heb.automation.common.pages.selectastore;

import java.util.List;

import com.heb.automation.common.components.StoreBlocksInListView;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ListViewTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "listview.txt.searchbox")
	private QAFWebElement txtSearchbox;

	@FindBy(locator = "listview.li.listviewblocks")
	private List<StoreBlocksInListView> liListviewblocks;
	
	@FindBy(locator = "listview.icon.searchclose")
	private QAFWebElement iconSearchclose;

	
	public QAFWebElement getIconSearchclose() {
		return iconSearchclose;
	}

	public QAFWebElement getTxtSearchbox() {
		return txtSearchbox;
	}

	public List<StoreBlocksInListView> getLiListviewblocks() {
		return liListviewblocks;
	}

}