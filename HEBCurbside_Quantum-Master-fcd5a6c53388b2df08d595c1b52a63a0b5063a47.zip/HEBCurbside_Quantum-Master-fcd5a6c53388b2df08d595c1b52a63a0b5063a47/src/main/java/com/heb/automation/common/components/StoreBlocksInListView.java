package com.heb.automation.common.components;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class StoreBlocksInListView extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "listview.lbl.storename")
	private List<QAFWebElement> lblStorename;

	@FindBy(locator = "listview.lbl.streetaddress")
	private List<QAFWebElement> lblStreetaddress;

	@FindBy(locator = "listview.lbl.citystate")
	private List<QAFWebElement> lblCitystate;

	@FindBy(locator = "listview.lbl.curbsidehours")
	private List<QAFWebElement> lblCurbsidehours;

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public List<QAFWebElement> getLblStorename() {
		return lblStorename;
	}

	public List<QAFWebElement> getLblStreetaddress() {
		return lblStreetaddress;
	}

	public List<QAFWebElement> getLblCitystate() {
		return lblCitystate;
	}

	public List<QAFWebElement> getLblCurbsidehours() {
		return lblCurbsidehours;
	}

}