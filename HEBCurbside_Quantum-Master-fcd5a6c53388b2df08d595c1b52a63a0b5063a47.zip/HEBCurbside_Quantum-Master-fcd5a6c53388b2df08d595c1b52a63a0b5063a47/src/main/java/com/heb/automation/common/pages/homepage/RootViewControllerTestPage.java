package com.heb.automation.common.pages.homepage;

import java.util.List;

import com.heb.automation.common.components.StoreBlocksInListView;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RootViewControllerTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "rvc.lbl.rootviewcontrollertitle")
	private QAFWebElement lblRootviewcontrollertitle;

	@FindBy(locator = "rvc.lbl.currentstore")
	private QAFWebElement lblCurrentstore;

	@FindBy(locator = "rvc.lbl.storename")
	private QAFWebElement lblStorename;

	@FindBy(locator = "rvc.btn.tostoresearch")
	private QAFWebElement btnTostoresearch;

	@FindBy(locator = "rvc.btn.toproductsearch")
	private QAFWebElement btnToproductsearch;

	public QAFWebElement getLblRootviewcontrollertitle() {
		return lblRootviewcontrollertitle;
	}

	public QAFWebElement getLblCurrentstore() {
		return lblCurrentstore;
	}

	public QAFWebElement getLblStorename() {
		return lblStorename;
	}

	public QAFWebElement getBtnTostoresearch() {
		return btnTostoresearch;
	}

	public QAFWebElement getBtnToproductsearch() {
		return btnToproductsearch;
	}
}