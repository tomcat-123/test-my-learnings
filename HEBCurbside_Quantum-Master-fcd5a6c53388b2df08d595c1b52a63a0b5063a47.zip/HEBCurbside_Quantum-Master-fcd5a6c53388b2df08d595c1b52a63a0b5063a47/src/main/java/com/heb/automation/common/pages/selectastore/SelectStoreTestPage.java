package com.heb.automation.common.pages.selectastore;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SelectStoreTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "selectstore.img.pageimage")
	private QAFWebElement imgPageimage;

	@FindBy(locator = "selectstore.lbl.pagetext")
	private QAFWebElement lblPagetext;

	@FindBy(locator = "selectstore.icon.pagenearme")
	private QAFWebElement iconPagenearme;

	@FindBy(locator = "selectstore.lbl.pagenearme")
	private QAFWebElement lblPagenearme;

	@FindBy(locator = "selectstore.icon.pagesearch")
	private QAFWebElement iconPagesearch;

	@FindBy(locator = "selectstore.lbl.pagesearch")
	private QAFWebElement lblPagesearch;

	@FindBy(locator = "selectstore.icon.pageviewall")
	private QAFWebElement iconPageviewall;

	@FindBy(locator = "selectstore.lbl.pageviewall")
	private QAFWebElement lblPageviewall;

	@FindBy(locator = "selectstore.lbl.pagetitle")
	private QAFWebElement selectstoreLblPagetitle;

	public QAFWebElement getImgPageimage() {
		return imgPageimage;
	}

	public QAFWebElement getLblPagetext() {
		return lblPagetext;
	}

	public QAFWebElement getIconPagenearme() {
		return iconPagenearme;
	}

	public QAFWebElement getLblPagenearme() {
		return lblPagenearme;
	}

	public QAFWebElement getIconPagesearch() {
		return iconPagesearch;
	}

	public QAFWebElement getLblPagesearch() {
		return lblPagesearch;
	}

	public QAFWebElement getIconPageviewall() {
		return iconPageviewall;
	}

	public QAFWebElement getLblPageviewall() {
		return lblPageviewall;
	}

	/**
	 * TextView of page title Select A Store
	 */
	public QAFWebElement getSelectstoreLblPagetitle() {
		return selectstoreLblPagetitle;
	}

}