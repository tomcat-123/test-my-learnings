package com.heb.automation.Utils;

import static org.testng.Assert.assertTrue;

import com.perfecto.reportium.client.ReportiumClient;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.util.Reporter;
import com.heb.automation.Utils.TestDataContainer;


public class PerfectoUtils {
	
	public static final String PERFECTO_REPORT_CLIENT = "perfecto.report.client";
	private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	private static final String ALPHA_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

	// Constants for timing in Mili seconds
	public static final int MAX_WAIT_TIME = 10000;
	private static final int SLEEP_TIME = 3000;
	private int headerOffset = 0;

	public static void reportMessage(String msg, MessageTypes result) {

		
		ReportiumClient reportClient = (ReportiumClient)TestDataContainer.getTestObject(PERFECTO_REPORT_CLIENT);
		boolean asrtResult = false;

		if (result.equals(MessageTypes.Pass) || result.equals(MessageTypes.TestStepPass)) {
			asrtResult = true;
		} else if (result.equals(MessageTypes.Fail) || result.equals(MessageTypes.TestStepFail)) {
			asrtResult = false;
		} else if (result.equals(MessageTypes.Info) || result.equals(MessageTypes.TestStep)
				|| result.equals(MessageTypes.Warn)) {
			asrtResult = true;
		}

		System.out.println(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        System.out.println(msg +" Result :   "+result);
        System.out.println(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
		
		reportClient.reportiumAssert(msg, asrtResult);
		Reporter.log(msg, result);
		assertTrue(asrtResult, msg);

	}

	public static void reportMessage(String msg) {
		reportMessage(msg, MessageTypes.Info);

	}
}
