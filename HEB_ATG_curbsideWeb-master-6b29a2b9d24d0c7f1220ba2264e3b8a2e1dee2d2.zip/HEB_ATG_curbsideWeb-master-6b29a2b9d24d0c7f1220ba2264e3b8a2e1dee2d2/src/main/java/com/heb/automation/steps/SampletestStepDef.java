package com.heb.automation.steps;

import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.NotYetImplementedException;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.heb.automation.Utils.PerfectoUtils;

public class SampletestStepDef {

	@QAFTestStep(description="user validates application loaded successfully")
	public void userValidatesApplicationLoadedSuccessfully(){
	
		System.out.println("In STEP DEFINITION ....");
		PerfectoUtils.reportMessage("In STEP DEFINITION ....", MessageTypes.Pass);
		
	}
	
	@QAFTestStep(description="user checks the content_TEST")
	public void userChecksTheContent_TEST(){
		
		System.out.println("Content....");
		PerfectoUtils.reportMessage("Content....", MessageTypes.Info);
	}
	
	@QAFTestStep(description="Step to fail")
	public void stepToFail(){
		
		PerfectoUtils.reportMessage("Content Miss match....", MessageTypes.Fail);
	}
}
