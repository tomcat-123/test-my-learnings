package com.heb.automation.ErrorMessages;

import org.apache.commons.lang.builder.ToStringBuilder;

public class Object {

private String contactInfo;
private String description;

public String getContactInfo() {
return contactInfo;
}

public void setContactInfo(String contactInfo) {
this.contactInfo = contactInfo;
}

public String getDescription() {
return description;
}

public void setDescription(String description) {
this.description = description;
}

@Override
public String toString() {
return new ToStringBuilder(this).append("contactInfo", contactInfo).append("description", description).toString();
}

}