package com.heb.automation.Services.HomeDelivery.Zones;

public class Zones_Post {
	
	private String apiStatus;

    private Zones_Data data = new Zones_Data();

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

    public Zones_Data getData ()
    {
        return data;
    }

    public void setData (Zones_Data data)
    {
        this.data = data;
    }

}
