package com.heb.automation.Pages.HD_WebApp;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CommonTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "Navigation.btn.hamburger")
	private QAFWebElement Navigationbtnhamburger;

	@FindBy(locator = "Navigation.btn.close_hamburger")
	private QAFWebElement Navigationbtnclosehamburger;

	@FindBy(locator = "Navigation.lbl.driversnapshot")
	private QAFWebElement Navigationlbldriversnapshot;

	@FindBy(locator = "Navigation.lbl.zoneconfiguration")
	private QAFWebElement Navigationlblzoneconfiguration;

	@FindBy(locator = "Navigation.lbl.zone")
	private QAFWebElement Navigationlblzone;

	@FindBy(locator = "Navigation.lbl.city")
	private QAFWebElement Navigationlblcity;

	@FindBy(locator = "Navigation.lbl.messaging")
	private QAFWebElement Navigationlblmessaging;

	@FindBy(locator = "Navigation.lbl.order")
	private QAFWebElement Navigationlblorder;
	
	@FindBy(locator = "Navigation.lbl.driver")
	private QAFWebElement Navigationlbldriver;
	
	@FindBy(locator = "Navigation.lbl.drivertimesheet")
	private QAFWebElement Navigationlbldrivertimesheet;
	
	@FindBy(locator = "Navigation.lbl.drivershiftplanner")
	private QAFWebElement Navigationlbldrivershiftplanner;
	
	@FindBy(locator = "Navigation.lbl.drivershiftupload")
	private QAFWebElement Navigationlbldrivershiftupload;
	
	
	@FindBy(locator = "Common.lbl.homeicon")
	private QAFWebElement Commonlblhomeicon;

	@FindBy(locator = "Common.lbl.homerightarrow")
	private QAFWebElement Commonlblhomerightarrow;

	@FindBy(locator = "Common.lbl.header")
	private QAFWebElement Commonlblheader;

	@FindBy(locator = "Common.btn.search")
	private QAFWebElement Commonbtnsearch;

	@FindBy(locator = "Common.btn.reset")
	private QAFWebElement Commonbtnreset;

	@FindBy(locator = "table.lbl.tablebody")
	private QAFWebElement tablelbltablebody;

	@FindBy(locator = "table.lbl.tablehead")
	private QAFWebElement tablelbltablehead;
	
	
	@FindBy(locator = "Common.btn.pagenum")
	private List<QAFWebElement> Commonbtnpagenum;
	
	@FindBy(locator = "Common.lnk.backwardlastpage")
	private QAFWebElement Commonlnkbackwardlastpage;
	
	@FindBy(locator = "Common.lnk.forwardlast")
	private QAFWebElement Commonlnkforwardlast;
	
	@FindBy(locator = "Common.lnk.backwardnext")
	private QAFWebElement Commonlnkbackwardnext;
	
	@FindBy(locator = "Common.lnk.forwardnext")
	private QAFWebElement Commonlnkforwardnext;
	
	@FindBy(locator = "Common.lbl.displayingrecords")
	private QAFWebElement Commonlbldisplayingrecords;
	
	@FindBy(locator = "Common.lbl.pagevalue")
	private List<QAFWebElement> Commonlblpagevalue;
	
	@FindBy(locator = "Common.dropdown.pagination")
	private List<QAFWebElement> Commondropdownpagination;
	
	@FindBy(locator = "Common.dropdown.pagenationvalue")
	private List<QAFWebElement> Commondropdownpagenationvalue;
	
	public List<QAFWebElement> getCommonDropDownPageNationValue() {
		return Commondropdownpagenationvalue;
	}
	
	public List<QAFWebElement> getCommonDropdownPagination() {
		return Commondropdownpagination;
	}
	
	public List<QAFWebElement> getCommonLblPageValue() {
		return Commonlblpagevalue;
	}
	
	public QAFWebElement getCommonLblDisplayingRecords() {
		return Commonlbldisplayingrecords;
	}
	
	public QAFWebElement getCommonLnkForwardNext() {
		return Commonlnkforwardnext;
	}
	
	public QAFWebElement getCommonLnkBackwardNext() {
		return Commonlnkbackwardnext;
	}
	
	public QAFWebElement getCommonLnkForwardLast() {
		return Commonlnkforwardlast;
	}
	
	public QAFWebElement getCommonLnkBackwardLastpage() {
		return Commonlnkbackwardlastpage;
	}
	
	public List<QAFWebElement> getCommonBtnPageNum() {
		return Commonbtnpagenum;
	}
	
	public QAFWebElement getNavigationLblDriver() {
		return Navigationlbldriver;
	}

	public QAFWebElement getNavigationLblDriverTimeSheet() {
		return Navigationlbldrivertimesheet;
	}

		
	public QAFWebElement getNavigationBtnHamburger() {
		return Navigationbtnhamburger;
	}

	public QAFWebElement getNavigationBtnCloseHamburger() {
		return Navigationbtnclosehamburger;
	}

	public QAFWebElement getNavigationLblDriverSnapshot() {
		return Navigationlbldriversnapshot;
	}

	public QAFWebElement getNavigationLblZoneConfiguration() {
		return Navigationlblzoneconfiguration;
	}

	public QAFWebElement getNavigationLblZone() {
		return Navigationlblzone;
	}

	public QAFWebElement getNavigationLblCity() {
		return Navigationlblcity;
	}

	public QAFWebElement getNavigationLblMessaging() {
		return Navigationlblmessaging;
	}

	public QAFWebElement getNavigationLblOrder() {
		return Navigationlblorder;
	}

	public QAFWebElement getLblHomeIcon() {
		return Commonlblhomeicon;
	}

	public QAFWebElement getLblHomeRightArrow() {
		return Commonlblhomerightarrow;
	}

	public QAFWebElement getLblHeader() {
		return Commonlblheader;
	}

	public QAFWebElement getBtnSearch() {
		return Commonbtnsearch;
	}

	public QAFWebElement getBtnReset() {
		return Commonbtnreset;
	}

	public QAFWebElement getLblTableBody() {
		return tablelbltablebody;
	}

	public QAFWebElement getLblTableHead() {
		return tablelbltablehead;
	}
	
	public QAFWebElement getNavigationLblDriverShiftPlanner() {
		return Navigationlbldrivershiftplanner;
	}
	
	public QAFWebElement getNavigationLblDriverShiftUpload() {
		return Navigationlbldrivershiftupload;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {

	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
}
