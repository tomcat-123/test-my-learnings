package com.heb.automation.Services.HomeDelivery.Shifts;

public class DataZone {

	private String id;

    private String lastModifiedTimestamp;

    private String archived;

    private String name;

    private String externalIdOnfleet;

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getLastModifiedTimestamp ()
    {
        return lastModifiedTimestamp;
    }

    public void setLastModifiedTimestamp (String lastModifiedTimestamp)
    {
        this.lastModifiedTimestamp = lastModifiedTimestamp;
    }

    public String getArchived ()
    {
        return archived;
    }

    public void setArchived (String archived)
    {
        this.archived = archived;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getExternalIdOnfleet ()
    {
        return externalIdOnfleet;
    }

    public void setExternalIdOnfleet (String externalIdOnfleet)
    {
        this.externalIdOnfleet = externalIdOnfleet;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [id = "+id+", lastModifiedTimestamp = "+lastModifiedTimestamp+", archived = "+archived+", name = "+name+", externalIdOnfleet = "+externalIdOnfleet+"]";
    }
}
