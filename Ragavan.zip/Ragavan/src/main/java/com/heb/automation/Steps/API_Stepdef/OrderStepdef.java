package com.heb.automation.Steps.API_Stepdef;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.ErrorMessages.ErrorMessage;
import com.heb.automation.Services.BodyParameter.Geocode.Geocode_Body;
import com.heb.automation.Services.BodyParameter.Order.Customer;
import com.heb.automation.Services.BodyParameter.Order.Delivery_from;
import com.heb.automation.Services.BodyParameter.Order.Delivery_schedule;
import com.heb.automation.Services.BodyParameter.Order.Delivery_to;
import com.heb.automation.Services.BodyParameter.Order.Notes;
import com.heb.automation.Services.BodyParameter.Order.Notes_Root;
import com.heb.automation.Services.BodyParameter.Order.Order;
import com.heb.automation.Services.BodyParameter.Order.Order_PostRoot;
import com.heb.automation.Services.BodyParameter.Order.Recipient;
import com.heb.automation.Services.BodyParameter.Order.Status;
import com.heb.automation.Services.BodyParameter.Order.Store;
import com.heb.automation.Services.BodyParameter.Order.PUT_Order.Order_PUT_Notes;
import com.heb.automation.Services.BodyParameter.Order.PUT_Order.Order_PutRoot;
import com.heb.automation.Services.BodyParameter.Order.PUT_Order.ProntoOrder;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.ServiceUtils;
import com.heb.automation.Services.HomeDelivery.GeoCode.Geocode_RootObject;
import com.heb.automation.Services.HomeDelivery.Order.HomeDelivery_RootObject;
import com.heb.automation.Services.HomeDelivery.Order.HomeDelivery_Tasks;
import com.heb.automation.Services.HomeDelivery.Order.Orders_Post;
import com.heb.automation.Services.HomeDelivery.Search.Post_Search;
import com.heb.automation.Services.HomeDelivery.Search.Post_SearchCriteria;
import com.heb.automation.Services.HomeDelivery.Search.SearchResults_RootObject;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class OrderStepdef extends TestDataContainer {

	@QAFTestStep(description = "Build URL for read HomeDelivery orders")
	public void buildURLForReadHomeDeliverOrders() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getOrders") + "/"
				+ getTestObject("comsID");
		System.out.println(baseurl);
		System.out.println(resource);
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for read HomeDelivery specific orders")
	public void buildURLForReadHomeDeliverSpecificOrders() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getOrders") + "/"
				+ "699637";
		System.out.println(baseurl);
		System.out.println(resource);
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for create HomeDelivery orders")
	public void buildURLForCreateHomeDeliverOrders() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getOrders");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for update HomeDelivery orders")
	public void buildURLForUpdateHomeDeliverOrders() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getOrders") + "/"
				+ getTestString("HomeDelivery.Order.comsID");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for read HomeDelivery Single Collection orders")
	public void buildURLForReadHomeDeliverSingleCollectionOrders() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getOrders") + "/1/1";
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for Searching HomeDelivery Orders")
	public void buildURLForSearchingHomeDeliveryOrders() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.searchOrders");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for read HomeDelivery geocode")
	public void buildURLForReadHomeDeliverGeoCode() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getGeoCode");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for searching HomeDelivery Orders with {0} {1} {2} {3} {4} {5} {6}")
	public void SearchOrders(String searchKey, String searchOp, String searchVal, String PgNo, String PgSize,
			String sortDir, String srtBy) throws JsonProcessingException {

		Post_Search pr = new Post_Search();
		Post_SearchCriteria sc = new Post_SearchCriteria();
		ArrayList<Post_SearchCriteria> bodySc = new ArrayList<Post_SearchCriteria>();
		ObjectMapper objm = new ObjectMapper();

		String key = searchKey;
		String operation = searchOp;
		// String value = searchVal;
		// sc.setValue(searchVal);

		if (key.equals("comsId")) {
			int value = Integer.parseInt(searchVal);
			sc.setValue(value);

		} else {
			String value = searchVal;
			sc.setValue(value);

		}
		;

		sc.setKey(key);
		sc.setOperation(operation);
		bodySc.add(sc);

		String pageNumber = PgNo;
		String pageSize = PgSize;
		String sortDirection = sortDir;
		String sortBy = srtBy;

		pr.setPageNumber(Integer.parseInt(pageNumber));
		pr.setPageSize(Integer.parseInt(pageSize));
		pr.setsortDirection(sortDirection);
		pr.setSortBy(sortBy);
		pr.setSearchCriteria(bodySc);

		String jsonInString = objm.writeValueAsString(pr);

		// System.out.println("CHoosen Name is :" + pr.toString());
		System.out.println("Full search body is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for searching HomeDelivery Orders with null parameters {0} {1} {2} {3} {4} {5} {6}")
	public void SearchOrdersNull(String searchKey, String searchOp, String searchVal, String PgNo, String PgSize,
			String sortDir, String srtBy) throws JsonProcessingException {

		Post_Search pr = new Post_Search();
		Post_SearchCriteria sc = new Post_SearchCriteria();
		ArrayList<Post_SearchCriteria> bodySc = new ArrayList<Post_SearchCriteria>();
		ObjectMapper objm = new ObjectMapper();

		String key = searchKey;
		String operation = searchOp;
		// String value = searchVal;
		// sc.setValue(searchVal);

		if (key.equals("comsId")) {
			int value = Integer.parseInt(searchVal);
			sc.setValue(value);

		} else {
			String value = searchVal;
			sc.setValue(value);

		}
		;

		sc.setKey(key);
		sc.setOperation(operation);
		bodySc.add(sc);

		String pageNumber = PgNo;
		String pageSize = PgSize;
		String sortDirection = sortDir;
		String sortBy = srtBy;

		// pr.setPageNumber(pageNumber);
		// pr.setPageSize(pageSize);
		pr.setsortDirection(sortDirection);
		pr.setSortBy(sortBy);
		pr.setSearchCriteria(bodySc);

		String jsonInString = objm.writeValueAsString(pr);

		// System.out.println("CHoosen Name is :" + pr.toString());
		System.out.println("Full search body is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for searching HomeDelivery Orders with multiple search criteria {0} {1} {2} {3} {4} {5} {6} {7} {8} {9} {10} {11} {12} {13}")
	public void SearchOrdersMultipleSearchCriteria(String searchKey1, String searchOpCn, String searchVal1, String PgNo,
			String PgSize, String sortDir, String srtBy, String searchKey2, String searchVal2, String searchKey3,
			String searchVal3, String searchKey4, String searchVal4, String searchOpEq) throws JsonProcessingException {

		Post_Search pr = new Post_Search();
		Post_SearchCriteria sc1 = new Post_SearchCriteria();
		Post_SearchCriteria sc2 = new Post_SearchCriteria();
		Post_SearchCriteria sc3 = new Post_SearchCriteria();
		Post_SearchCriteria sc4 = new Post_SearchCriteria();
		ArrayList<Post_SearchCriteria> bodySc = new ArrayList<Post_SearchCriteria>();
		ObjectMapper objm = new ObjectMapper();

		String operationContains = searchOpCn;
		String operationEquals = searchOpEq;
		String custFnKey = searchKey1;
		String custLnKey = searchKey2;
		String strNmKey = searchKey3;
		String statusKey = searchKey4;

		/*
		 * String custFnVal = searchVal1; String custLnVal = searchVal2; String
		 * strNmVal = searchVal3; String statusVal = searchVal4;
		 */

		sc1.setKey(custFnKey);
		sc1.setOperation(operationContains);
		// sc.setValue(searchVal1);
		if (custFnKey.equals("comsId")) {
			int custFnVal = Integer.parseInt(searchVal1);
			sc1.setValue(custFnVal);
		} else {
			String custFnVal = searchVal1;
			sc1.setValue(custFnVal);

		}
		;
		bodySc.add(sc1);

		sc2.setKey(custLnKey);
		sc2.setOperation(operationContains);
		// sc2.setValue(searchVal2);
		if (custLnKey.equals("comsId")) {
			int custLnVal = Integer.parseInt(searchVal2);
			sc2.setValue(custLnVal);

		} else {
			String custLnVal = searchVal2;
			sc2.setValue(custLnVal);

		}
		;
		bodySc.add(sc2);

		sc3.setKey(strNmKey);
		sc3.setOperation(operationContains);
		// sc3.setValue(searchVal3);
		if (strNmKey.equals("comsId")) {
			int strNmVal = Integer.parseInt(searchVal3);
			sc3.setValue(strNmVal);

		} else {
			String strNmVal = searchVal3;
			sc3.setValue(strNmVal);

		}
		;
		bodySc.add(sc3);

		sc4.setKey(statusKey);
		sc4.setOperation(operationEquals);
		// sc4.setValue(searchVal4);
		if (statusKey.equals("comsId")) {
			int statusVal = Integer.parseInt(searchVal4);
			sc4.setValue(statusVal);

		} else {
			String statusVal = searchVal4;
			sc4.setValue(statusVal);

		}
		;
		bodySc.add(sc4);

		String pageNumber = PgNo;
		String pageSize = PgSize;
		String sortDirection = sortDir;
		String sortBy = srtBy;

		pr.setPageNumber(Integer.parseInt(pageNumber));
		pr.setPageSize(Integer.parseInt(pageSize));
		pr.setsortDirection(sortDirection);
		pr.setSortBy(sortBy);
		pr.setSearchCriteria(bodySc);

		String jsonInString = objm.writeValueAsString(pr);

		// System.out.println("CHoosen Name is :" + pr.toString());
		System.out.println("Full search body is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User POST the Search HomeDelivery Orders call")
	public void userPOSTTheSearchHomeDeliveryOrdersCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Orders is being searched ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				SearchResults_RootObject gson1 = new Gson().fromJson(RESPONSE, SearchResults_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String searchResultsCount = gson1.getData().getTotalElements();
				// String ZoneName = gson1.getData().getName();
				// String ZoneOnfleetID =
				// gson1.getData().getexternalIdOnfleet();
				putTestObject("searchResultsCount", searchResultsCount);
				// putTestObject("ZoneName", ZoneName);
				// putTestObject("ZoneOnfleetID", ZoneOnfleetID);
				Reporter.log("Search Success- Search Results Count : " + searchResultsCount);
				// Reporter.log("Created Success-HomeDelivery Zone Name: " +
				// ZoneName);
				// Reporter.log("Created Success-HomeDelivery Zone OnfleetID: "
				// + ZoneOnfleetID);
				System.out.println("Search Success- Search Results Count : " + searchResultsCount);
				// System.out.println("Created Success-HomeDelivery Zone Name: "
				// + ZoneName);
				// System.out.println("Created Success-HomeDelivery Zone
				// OnfleetID: " + ZoneOnfleetID);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Orders search failed with " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("Orders search failed with " + 503);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		// ArrayList<Order_Notes> notes = new ArrayList<Order_Notes>();
		// Order_Notes notes1=new Order_Notes();
		// notes1.setNoteId("1");
		// notes1.setType("ORDER");
		// notes1.setNote("Note1");
		//
		// Order_Notes notes2=new Order_Notes();
		// notes2.setNoteId("2");
		// notes2.setType("ORDER");
		// notes2.setNote("Note2");
		//
		// Order_Notes notes3=new Order_Notes();
		// notes3.setNoteId("3");
		// notes3.setType("ORDER");
		// notes3.setNote("Note3");
		//
		// notes.add(notes1);
		// notes.add(notes2);
		// notes.add(notes3);
		// System.out.println(notes);

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		ord.setInvoice("");
		Float Gross_Bill = Float.valueOf(getTestString("HomeDelivery.Order.gross_bill"));
		ord.setGross_bill(Gross_Bill);

		ord.setTip(Float.valueOf(getTestString("HomeDelivery.Order.tip")));
		ord.setInvoice(getTestString("HomeDelivery.Order.invoice"));

		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey(getTestString("HomeDelivery.Order.notes_key"));
		note.setValue(getTestString("HomeDelivery.Order.notes_value"));
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id(getTestString("HomeDelivery.Order.store_externalID"));
		str.setEmail(getTestString("HomeDelivery.Order.store_email"));
		str.setPhone(generateRandom());
		str.setName(getTestString("HomeDelivery.Order.store_name"));
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id(getTestString("HomeDelivery.Order.customer_externalID"));
		ctr.setFirst_name(getTestString("HomeDelivery.Order.customer_firstname"));
		ctr.setLast_name(getTestString("HomeDelivery.Order.customer_lastname"));
		ctr.setPhone(generateRandom());
		ctr.setEmail(getTestString("HomeDelivery.Order.customer_email"));
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1(getTestString("HomeDelivery.Order.deliveryfrom_add1"));
		del.setAddress_2(getTestString("HomeDelivery.Order.deliveryfrom_add2"));
		del.setCity(getTestString("HomeDelivery.Order.deliveryfrom_city"));
		del.setState(getTestString("HomeDelivery.Order.deliveryfrom_state"));
		del.setZip(getTestString("HomeDelivery.Order.deliveryfrom_zip"));
		del.setNote(getTestString("HomeDelivery.Order.deliveryfrom_note"));

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1(getTestString("HomeDelivery.Order.deliveryto_add1"));
		delTo.setAddress_2(getTestString("HomeDelivery.Order.deliveryto_add2"));
		delTo.setCity(getTestString("HomeDelivery.Order.deliveryto_city"));
		delTo.setState(getTestString("HomeDelivery.Order.deliveryto_state"));
		delTo.setZip(getTestString("HomeDelivery.Order.deliveryto_zip"));
		delTo.setNote(getTestString("HomeDelivery.Order.deliveryto_note"));

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id(getTestString("HomeDelivery.Order.recipient_externalID"));
		rcp.setFirst_name(getTestString("HomeDelivery.Order.recipient_firstname"));
		rcp.setLast_name(getTestString("HomeDelivery.Order.receipient_lastname"));
		rcp.setPhone(generateRandom());
		rcp.setEmail(getTestString("HomeDelivery.Order.recipient_email"));

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey(getTestString("HomeDelivery.Order.notes_key_signature"));
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey(getTestString("HomeDelivery.Order.notes_key_alcohol"));
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey(getTestString("HomeDelivery.Order.notes_key_itemcount"));
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);
		// pr.setOrdernotes(notes);
		pr.setDriverName("Driver");
		pr.setOnFleetDriver("Onfleet");

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter with duplicate COMS id for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterWithDuplicateCOMSIdForCreatingHomeDeliveryOrder()
			throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getTestString("comsID"));
		Float Gross_Bill = Float.valueOf(getTestString("HomeDelivery.Order.gross_bill"));
		ord.setGross_bill(Gross_Bill);

		ord.setTip(Float.valueOf(getTestString("HomeDelivery.Order.tip")));
		ord.setInvoice(getTestString("HomeDelivery.Order.invoice"));
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey(getTestString("HomeDelivery.Order.notes_key"));
		note.setValue(getTestString("HomeDelivery.Order.notes_value"));
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id(getTestString("HomeDelivery.Order.store_externalID"));
		str.setEmail(getTestString("HomeDelivery.Order.store_email"));
		str.setPhone(generateRandom());
		str.setName(getTestString("HomeDelivery.Order.store_name"));
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id(getTestString("HomeDelivery.Order.customer_externalID"));
		ctr.setFirst_name(getTestString("HomeDelivery.Order.customer_firstname"));
		ctr.setLast_name(getTestString("HomeDelivery.Order.customer_lastname"));
		ctr.setPhone(generateRandom());
		ctr.setEmail(getTestString("HomeDelivery.Order.customer_email"));
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1(getTestString("HomeDelivery.Order.deliveryfrom_add1"));
		del.setAddress_2(getTestString("HomeDelivery.Order.deliveryfrom_add2"));
		del.setCity(getTestString("HomeDelivery.Order.deliveryfrom_city"));
		del.setState(getTestString("HomeDelivery.Order.deliveryfrom_state"));
		del.setZip(getTestString("HomeDelivery.Order.deliveryfrom_zip"));
		del.setNote(getTestString("HomeDelivery.Order.deliveryfrom_note"));

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1(getTestString("HomeDelivery.Order.deliveryto_add1"));
		delTo.setAddress_2(getTestString("HomeDelivery.Order.deliveryto_add2"));
		delTo.setCity(getTestString("HomeDelivery.Order.deliveryto_city"));
		delTo.setState(getTestString("HomeDelivery.Order.deliveryto_state"));
		delTo.setZip(getTestString("HomeDelivery.Order.deliveryto_zip"));
		delTo.setNote(getTestString("HomeDelivery.Order.deliveryto_note"));

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id(getTestString("HomeDelivery.Order.recipient_externalID"));
		rcp.setFirst_name(getTestString("HomeDelivery.Order.recipient_firstname"));
		rcp.setLast_name(getTestString("HomeDelivery.Order.receipient_lastname"));
		rcp.setPhone(generateRandom());
		rcp.setEmail(getTestString("HomeDelivery.Order.recipient_email"));

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey(getTestString("HomeDelivery.Order.notes_key_signature"));
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey(getTestString("HomeDelivery.Order.notes_key_alcohol"));
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey(getTestString("HomeDelivery.Order.notes_key_itemcount"));
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Missing Mandatory Body Parameter for creating HomeDelivery Order")
	public void userUsesAnArrayOfMissingMandatoryBodyParameterForCreatingHomeDeliveryOrder()
			throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		Float Gross_Bill = Float.valueOf(getTestString("HomeDelivery.Order.gross_bill"));
		ord.setGross_bill(Gross_Bill);

		ord.setTip(Float.valueOf(getTestString("HomeDelivery.Order.tip")));
		ord.setInvoice(getTestString("HomeDelivery.Order.invoice"));
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey(getTestString("HomeDelivery.Order.notes_key"));
		note.setValue(getTestString("HomeDelivery.Order.notes_value"));
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id(getTestString("HomeDelivery.Order.store_externalID"));
		str.setEmail("");
		str.setPhone(generateRandom());
		str.setName(getTestString("HomeDelivery.Order.store_name"));
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id(getTestString("HomeDelivery.Order.customer_externalID"));
		ctr.setFirst_name(getTestString("HomeDelivery.Order.customer_firstname"));
		ctr.setLast_name(getTestString("HomeDelivery.Order.customer_lastname"));
		ctr.setPhone(generateRandom());
		ctr.setEmail(getTestString("HomeDelivery.Order.customer_email"));
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1(getTestString("HomeDelivery.Order.deliveryfrom_add1"));
		del.setAddress_2(getTestString("HomeDelivery.Order.deliveryfrom_add2"));
		del.setCity(getTestString("HomeDelivery.Order.deliveryfrom_city"));
		del.setState(getTestString("HomeDelivery.Order.deliveryfrom_state"));
		del.setZip(getTestString("HomeDelivery.Order.deliveryfrom_zip"));
		del.setNote(getTestString("HomeDelivery.Order.deliveryfrom_note"));

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1(getTestString("HomeDelivery.Order.deliveryto_add1"));
		delTo.setAddress_2(getTestString("HomeDelivery.Order.deliveryto_add2"));
		delTo.setCity(getTestString("HomeDelivery.Order.deliveryto_city"));
		delTo.setState(getTestString("HomeDelivery.Order.deliveryto_state"));
		delTo.setZip(getTestString("HomeDelivery.Order.deliveryto_zip"));
		delTo.setNote(getTestString("HomeDelivery.Order.deliveryto_note"));

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id(getTestString("HomeDelivery.Order.recipient_externalID"));
		rcp.setFirst_name(getTestString("HomeDelivery.Order.recipient_firstname"));
		rcp.setLast_name(getTestString("HomeDelivery.Order.receipient_lastname"));
		rcp.setPhone(generateRandom());
		rcp.setEmail(getTestString("HomeDelivery.Order.recipient_email"));

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey(getTestString("HomeDelivery.Order.notes_key_signature"));
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey(getTestString("HomeDelivery.Order.notes_key_alcohol"));
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey(getTestString("HomeDelivery.Order.notes_key_itemcount"));
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Missing All Mandatory Body Parameter for creating HomeDelivery Order")
	public void userUsesAnArrayOfMissingAllMandatoryBodyParameterForCreatingHomeDeliveryOrder()
			throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id("");
		Float Gross_Bill = Float.valueOf(getTestString("HomeDelivery.Order.gross_bill"));
		ord.setGross_bill(Gross_Bill);

		ord.setTip(Float.valueOf(getTestString("HomeDelivery.Order.tip")));
		ord.setInvoice("");
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey(getTestString("HomeDelivery.Order.notes_key"));
		note.setValue(getTestString("HomeDelivery.Order.notes_value"));
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id(getTestString("HomeDelivery.Order.store_externalID"));
		str.setEmail(getTestString("HomeDelivery.Order.store_email"));
		str.setPhone("");
		str.setName(getTestString("HomeDelivery.Order.store_name"));
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id(getTestString("HomeDelivery.Order.customer_externalID"));
		ctr.setFirst_name(getTestString("HomeDelivery.Order.customer_firstname"));
		ctr.setLast_name(getTestString("HomeDelivery.Order.customer_lastname"));
		ctr.setPhone("");
		ctr.setEmail(getTestString("HomeDelivery.Order.customer_email"));
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1(getTestString("HomeDelivery.Order.deliveryfrom_add1"));
		del.setAddress_2(getTestString("HomeDelivery.Order.deliveryfrom_add2"));
		del.setCity(getTestString("HomeDelivery.Order.deliveryfrom_city"));
		del.setState(getTestString("HomeDelivery.Order.deliveryfrom_state"));
		del.setZip(getTestString("HomeDelivery.Order.deliveryfrom_zip"));
		del.setNote(getTestString("HomeDelivery.Order.deliveryfrom_note"));

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1(getTestString("HomeDelivery.Order.deliveryto_add1"));
		delTo.setAddress_2(getTestString("HomeDelivery.Order.deliveryto_add2"));
		delTo.setCity(getTestString("HomeDelivery.Order.deliveryto_city"));
		delTo.setState(getTestString("HomeDelivery.Order.deliveryto_state"));
		delTo.setZip(getTestString("HomeDelivery.Order.deliveryto_zip"));
		delTo.setNote(getTestString("HomeDelivery.Order.deliveryto_note"));

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id(getTestString("HomeDelivery.Order.recipient_externalID"));
		rcp.setFirst_name(getTestString("HomeDelivery.Order.recipient_firstname"));
		rcp.setLast_name(getTestString("HomeDelivery.Order.receipient_lastname"));
		rcp.setPhone(generateRandom());
		rcp.setEmail(getTestString("HomeDelivery.Order.recipient_email"));

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey(getTestString("HomeDelivery.Order.notes_key_signature"));
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey(getTestString("HomeDelivery.Order.notes_key_alcohol"));
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey(getTestString("HomeDelivery.Order.notes_key_itemcount"));
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter With Blank comsID for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterWithBlankcomsIDForCreatingHomeDeliveryOrder()
			throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id("");
		Float Gross_Bill = Float.valueOf(getTestString("HomeDelivery.Order.gross_bill"));
		ord.setGross_bill(Gross_Bill);

		ord.setTip(Float.valueOf(getTestString("HomeDelivery.Order.tip")));
		ord.setInvoice("");
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey(getTestString("HomeDelivery.Order.notes_key"));
		note.setValue(getTestString("HomeDelivery.Order.notes_value"));
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id(getTestString("HomeDelivery.Order.store_externalID"));
		str.setEmail(getTestString("HomeDelivery.Order.store_email"));
		str.setPhone(generateRandom());
		str.setName(getTestString("HomeDelivery.Order.store_name"));
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id(getTestString("HomeDelivery.Order.customer_externalID"));
		ctr.setFirst_name(getTestString("HomeDelivery.Order.customer_firstname"));
		ctr.setLast_name(getTestString("HomeDelivery.Order.customer_lastname"));
		ctr.setPhone(generateRandom());
		ctr.setEmail(getTestString("HomeDelivery.Order.customer_email"));
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1(getTestString("HomeDelivery.Order.deliveryfrom_add1"));
		del.setAddress_2(getTestString("HomeDelivery.Order.deliveryfrom_add2"));
		del.setCity(getTestString("HomeDelivery.Order.deliveryfrom_city"));
		del.setState(getTestString("HomeDelivery.Order.deliveryfrom_state"));
		del.setZip(getTestString("HomeDelivery.Order.deliveryfrom_zip"));
		del.setNote(getTestString("HomeDelivery.Order.deliveryfrom_note"));

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1(getTestString("HomeDelivery.Order.deliveryto_add1"));
		delTo.setAddress_2(getTestString("HomeDelivery.Order.deliveryto_add2"));
		delTo.setCity(getTestString("HomeDelivery.Order.deliveryto_city"));
		delTo.setState(getTestString("HomeDelivery.Order.deliveryto_state"));
		delTo.setZip(getTestString("HomeDelivery.Order.deliveryto_zip"));
		delTo.setNote(getTestString("HomeDelivery.Order.deliveryto_note"));

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id(getTestString("HomeDelivery.Order.recipient_externalID"));
		rcp.setFirst_name(getTestString("HomeDelivery.Order.recipient_firstname"));
		rcp.setLast_name(getTestString("HomeDelivery.Order.receipient_lastname"));
		rcp.setPhone(generateRandom());
		rcp.setEmail(getTestString("HomeDelivery.Order.recipient_email"));

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey(getTestString("HomeDelivery.Order.notes_key_signature"));
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey(getTestString("HomeDelivery.Order.notes_key_alcohol"));
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey(getTestString("HomeDelivery.Order.notes_key_itemcount"));
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter With Invalid Store for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterWithInvalidStoreForCreatingHomeDeliveryOrder()
			throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		Float Gross_Bill = Float.valueOf(getTestString("HomeDelivery.Order.gross_bill"));
		ord.setGross_bill(Gross_Bill);

		ord.setTip(Float.valueOf(getTestString("HomeDelivery.Order.tip")));
		ord.setInvoice(getTestString("HomeDelivery.Order.invoice"));
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey(getTestString("HomeDelivery.Order.notes_key"));
		note.setValue(getTestString("HomeDelivery.Order.notes_value"));
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id("18");
		str.setEmail(getTestString("HomeDelivery.Order.store_email"));
		str.setPhone(generateRandom());
		str.setName(getTestString("HomeDelivery.Order.store_name"));
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id(getTestString("HomeDelivery.Order.customer_externalID"));
		ctr.setFirst_name(getTestString("HomeDelivery.Order.customer_firstname"));
		ctr.setLast_name(getTestString("HomeDelivery.Order.customer_lastname"));
		ctr.setPhone(generateRandom());
		ctr.setEmail(getTestString("HomeDelivery.Order.customer_email"));
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1(getTestString("HomeDelivery.Order.deliveryfrom_add1"));
		del.setAddress_2(getTestString("HomeDelivery.Order.deliveryfrom_add2"));
		del.setCity(getTestString("HomeDelivery.Order.deliveryfrom_city"));
		del.setState(getTestString("HomeDelivery.Order.deliveryfrom_state"));
		del.setZip(getTestString("HomeDelivery.Order.deliveryfrom_zip"));
		del.setNote(getTestString("HomeDelivery.Order.deliveryfrom_note"));

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1(getTestString("HomeDelivery.Order.deliveryto_add1"));
		delTo.setAddress_2(getTestString("HomeDelivery.Order.deliveryto_add2"));
		delTo.setCity(getTestString("HomeDelivery.Order.deliveryto_city"));
		delTo.setState(getTestString("HomeDelivery.Order.deliveryto_state"));
		delTo.setZip(getTestString("HomeDelivery.Order.deliveryto_zip"));
		delTo.setNote(getTestString("HomeDelivery.Order.deliveryto_note"));

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id(getTestString("HomeDelivery.Order.recipient_externalID"));
		rcp.setFirst_name(getTestString("HomeDelivery.Order.recipient_firstname"));
		rcp.setLast_name(getTestString("HomeDelivery.Order.receipient_lastname"));
		rcp.setPhone(generateRandom());
		rcp.setEmail(getTestString("HomeDelivery.Order.recipient_email"));

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey(getTestString("HomeDelivery.Order.notes_key_signature"));
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey(getTestString("HomeDelivery.Order.notes_key_alcohol"));
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey(getTestString("HomeDelivery.Order.notes_key_itemcount"));
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter With InActive Store for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterWithInActiveStoreForCreatingHomeDeliveryOrder()
			throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		Float Gross_Bill = Float.valueOf(getTestString("HomeDelivery.Order.gross_bill"));
		ord.setGross_bill(Gross_Bill);

		ord.setTip(Float.valueOf(getTestString("HomeDelivery.Order.tip")));
		ord.setInvoice(getTestString("HomeDelivery.Order.invoice"));
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey(getTestString("HomeDelivery.Order.notes_key"));
		note.setValue(getTestString("HomeDelivery.Order.notes_value"));
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id("13");
		str.setEmail(getTestString("HomeDelivery.Order.store_email"));
		str.setPhone(generateRandom());
		str.setName(getTestString("HomeDelivery.Order.store_name"));
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id(getTestString("HomeDelivery.Order.customer_externalID"));
		ctr.setFirst_name(getTestString("HomeDelivery.Order.customer_firstname"));
		ctr.setLast_name(getTestString("HomeDelivery.Order.customer_lastname"));
		ctr.setPhone(generateRandom());
		ctr.setEmail(getTestString("HomeDelivery.Order.customer_email"));
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1(getTestString("HomeDelivery.Order.deliveryfrom_add1"));
		del.setAddress_2(getTestString("HomeDelivery.Order.deliveryfrom_add2"));
		del.setCity(getTestString("HomeDelivery.Order.deliveryfrom_city"));
		del.setState(getTestString("HomeDelivery.Order.deliveryfrom_state"));
		del.setZip(getTestString("HomeDelivery.Order.deliveryfrom_zip"));
		del.setNote(getTestString("HomeDelivery.Order.deliveryfrom_note"));

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1(getTestString("HomeDelivery.Order.deliveryto_add1"));
		delTo.setAddress_2(getTestString("HomeDelivery.Order.deliveryto_add2"));
		delTo.setCity(getTestString("HomeDelivery.Order.deliveryto_city"));
		delTo.setState(getTestString("HomeDelivery.Order.deliveryto_state"));
		delTo.setZip(getTestString("HomeDelivery.Order.deliveryto_zip"));
		delTo.setNote(getTestString("HomeDelivery.Order.deliveryto_note"));

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id(getTestString("HomeDelivery.Order.recipient_externalID"));
		rcp.setFirst_name(getTestString("HomeDelivery.Order.recipient_firstname"));
		rcp.setLast_name(getTestString("HomeDelivery.Order.receipient_lastname"));
		rcp.setPhone(generateRandom());
		rcp.setEmail(getTestString("HomeDelivery.Order.recipient_email"));

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey(getTestString("HomeDelivery.Order.notes_key_signature"));
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey(getTestString("HomeDelivery.Order.notes_key_alcohol"));
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey(getTestString("HomeDelivery.Order.notes_key_itemcount"));
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter With Invalid DeliveryTo for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterWithInvalidDeliveryToForCreatingHomeDeliveryOrder()
			throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		Float Gross_Bill = Float.valueOf(getTestString("HomeDelivery.Order.gross_bill"));
		ord.setGross_bill(Gross_Bill);

		ord.setTip(Float.valueOf(getTestString("HomeDelivery.Order.tip")));
		ord.setInvoice(getTestString("HomeDelivery.Order.invoice"));
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey(getTestString("HomeDelivery.Order.notes_key"));
		note.setValue(getTestString("HomeDelivery.Order.notes_value"));
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id(getTestString("HomeDelivery.Order.store_externalID"));
		str.setEmail(getTestString("HomeDelivery.Order.store_email"));
		str.setPhone(generateRandom());
		str.setName(getTestString("HomeDelivery.Order.store_name"));
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id(getTestString("HomeDelivery.Order.customer_externalID"));
		ctr.setFirst_name(getTestString("HomeDelivery.Order.customer_firstname"));
		ctr.setLast_name(getTestString("HomeDelivery.Order.customer_lastname"));
		ctr.setPhone(generateRandom());
		ctr.setEmail(getTestString("HomeDelivery.Order.customer_email"));
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1(getTestString("HomeDelivery.Order.deliveryfrom_add1"));
		del.setAddress_2(getTestString("HomeDelivery.Order.deliveryfrom_add2"));
		del.setCity(getTestString("HomeDelivery.Order.deliveryfrom_city"));
		del.setState(getTestString("HomeDelivery.Order.deliveryfrom_state"));
		del.setZip(getTestString("HomeDelivery.Order.deliveryfrom_zip"));
		del.setNote(getTestString("HomeDelivery.Order.deliveryfrom_note"));

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1("");
		delTo.setAddress_2("");
		delTo.setCity("");
		delTo.setState("");
		delTo.setZip("");
		delTo.setNote("");

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id(getTestString("HomeDelivery.Order.recipient_externalID"));
		rcp.setFirst_name(getTestString("HomeDelivery.Order.recipient_firstname"));
		rcp.setLast_name(getTestString("HomeDelivery.Order.receipient_lastname"));
		rcp.setPhone(generateRandom());
		rcp.setEmail(getTestString("HomeDelivery.Order.recipient_email"));

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey(getTestString("HomeDelivery.Order.notes_key_signature"));
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey(getTestString("HomeDelivery.Order.notes_key_alcohol"));
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey(getTestString("HomeDelivery.Order.notes_key_itemcount"));
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter Invalid DeliverySchedule for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterInvalidDeliverySchedulForCreatingHomeDeliveryOrder()
			throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		Float Gross_Bill = Float.valueOf(getTestString("HomeDelivery.Order.gross_bill"));
		ord.setGross_bill(Gross_Bill);

		ord.setTip(Float.valueOf(getTestString("HomeDelivery.Order.tip")));
		ord.setInvoice(getTestString("HomeDelivery.Order.invoice"));
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey(getTestString("HomeDelivery.Order.notes_key"));
		note.setValue(getTestString("HomeDelivery.Order.notes_value"));
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id(getTestString("HomeDelivery.Order.store_externalID"));
		str.setEmail(getTestString("HomeDelivery.Order.store_email"));
		str.setPhone(generateRandom());
		str.setName(getTestString("HomeDelivery.Order.store_name"));
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id(getTestString("HomeDelivery.Order.customer_externalID"));
		ctr.setFirst_name(getTestString("HomeDelivery.Order.customer_firstname"));
		ctr.setLast_name(getTestString("HomeDelivery.Order.customer_lastname"));
		ctr.setPhone(generateRandom());
		ctr.setEmail(getTestString("HomeDelivery.Order.customer_email"));
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1(getTestString("HomeDelivery.Order.deliveryfrom_add1"));
		del.setAddress_2(getTestString("HomeDelivery.Order.deliveryfrom_add2"));
		del.setCity(getTestString("HomeDelivery.Order.deliveryfrom_city"));
		del.setState(getTestString("HomeDelivery.Order.deliveryfrom_state"));
		del.setZip(getTestString("HomeDelivery.Order.deliveryfrom_zip"));
		del.setNote(getTestString("HomeDelivery.Order.deliveryfrom_note"));

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1(getTestString("HomeDelivery.Order.deliveryto_add1"));
		delTo.setAddress_2(getTestString("HomeDelivery.Order.deliveryto_add2"));
		delTo.setCity(getTestString("HomeDelivery.Order.deliveryto_city"));
		delTo.setState(getTestString("HomeDelivery.Order.deliveryto_state"));
		delTo.setZip(getTestString("HomeDelivery.Order.deliveryto_zip"));
		delTo.setNote(getTestString("HomeDelivery.Order.deliveryto_note"));

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time("");
		delShe.setEnd_time("");

		Recipient rcp = new Recipient();
		rcp.setExternal_id(getTestString("HomeDelivery.Order.recipient_externalID"));
		rcp.setFirst_name(getTestString("HomeDelivery.Order.recipient_firstname"));
		rcp.setLast_name(getTestString("HomeDelivery.Order.receipient_lastname"));
		rcp.setPhone(generateRandom());
		rcp.setEmail(getTestString("HomeDelivery.Order.recipient_email"));

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey(getTestString("HomeDelivery.Order.notes_key_signature"));
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey(getTestString("HomeDelivery.Order.notes_key_alcohol"));
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey(getTestString("HomeDelivery.Order.notes_key_itemcount"));
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter With Invalid TipAmount for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterWithInvalidTipAmountForCreatingHomeDeliveryOrder()
			throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		Float Gross_Bill = Float.valueOf(getTestString("HomeDelivery.Order.gross_bill"));
		ord.setGross_bill(Gross_Bill);

		ord.setTip(1000);
		ord.setInvoice(getTestString("HomeDelivery.Order.invoice"));
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey(getTestString("HomeDelivery.Order.notes_key"));
		note.setValue(getTestString("HomeDelivery.Order.notes_value"));
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id(getTestString("HomeDelivery.Order.store_externalID"));
		str.setEmail(getTestString("HomeDelivery.Order.store_email"));
		str.setPhone(generateRandom());
		str.setName(getTestString("HomeDelivery.Order.store_name"));
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id(getTestString("HomeDelivery.Order.customer_externalID"));
		ctr.setFirst_name(getTestString("HomeDelivery.Order.customer_firstname"));
		ctr.setLast_name(getTestString("HomeDelivery.Order.customer_lastname"));
		ctr.setPhone(generateRandom());
		ctr.setEmail(getTestString("HomeDelivery.Order.customer_email"));
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1(getTestString("HomeDelivery.Order.deliveryfrom_add1"));
		del.setAddress_2(getTestString("HomeDelivery.Order.deliveryfrom_add2"));
		del.setCity(getTestString("HomeDelivery.Order.deliveryfrom_city"));
		del.setState(getTestString("HomeDelivery.Order.deliveryfrom_state"));
		del.setZip(getTestString("HomeDelivery.Order.deliveryfrom_zip"));
		del.setNote(getTestString("HomeDelivery.Order.deliveryfrom_note"));

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1(getTestString("HomeDelivery.Order.deliveryto_add1"));
		delTo.setAddress_2(getTestString("HomeDelivery.Order.deliveryto_add2"));
		delTo.setCity(getTestString("HomeDelivery.Order.deliveryto_city"));
		delTo.setState(getTestString("HomeDelivery.Order.deliveryto_state"));
		delTo.setZip(getTestString("HomeDelivery.Order.deliveryto_zip"));
		delTo.setNote(getTestString("HomeDelivery.Order.deliveryto_note"));

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id(getTestString("HomeDelivery.Order.recipient_externalID"));
		rcp.setFirst_name(getTestString("HomeDelivery.Order.recipient_firstname"));
		rcp.setLast_name(getTestString("HomeDelivery.Order.receipient_lastname"));
		rcp.setPhone(generateRandom());
		rcp.setEmail(getTestString("HomeDelivery.Order.recipient_email"));

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey(getTestString("HomeDelivery.Order.notes_key_signature"));
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey(getTestString("HomeDelivery.Order.notes_key_alcohol"));
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey(getTestString("HomeDelivery.Order.notes_key_itemcount"));
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for creating HomeDelivery Alcohol Order")
	public void userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryAlcoholOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		Float Gross_Bill = Float.valueOf(getTestString("HomeDelivery.Order.gross_bill"));
		ord.setGross_bill(Gross_Bill);

		ord.setTip(Float.valueOf(getTestString("HomeDelivery.Order.tip")));
		ord.setInvoice(getTestString("HomeDelivery.Order.invoice"));
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey(getTestString("HomeDelivery.Order.notes_key"));
		note.setValue(getTestString("HomeDelivery.Order.notes_value"));
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id(getTestString("HomeDelivery.Order.store_externalID"));
		str.setEmail(getTestString("HomeDelivery.Order.store_email"));
		str.setPhone(generateRandom());
		str.setName(getTestString("HomeDelivery.Order.store_name"));
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id(getTestString("HomeDelivery.Order.customer_externalID"));
		ctr.setFirst_name(getTestString("HomeDelivery.Order.customer_firstname"));
		ctr.setLast_name(getTestString("HomeDelivery.Order.customer_lastname"));
		ctr.setPhone(generateRandom());
		ctr.setEmail(getTestString("HomeDelivery.Order.customer_email"));
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1(getTestString("HomeDelivery.Order.deliveryfrom_add1"));
		del.setAddress_2(getTestString("HomeDelivery.Order.deliveryfrom_add2"));
		del.setCity(getTestString("HomeDelivery.Order.deliveryfrom_city"));
		del.setState(getTestString("HomeDelivery.Order.deliveryfrom_state"));
		del.setZip(getTestString("HomeDelivery.Order.deliveryfrom_zip"));
		del.setNote(getTestString("HomeDelivery.Order.deliveryfrom_note"));

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1(getTestString("HomeDelivery.Order.deliveryto_add1"));
		delTo.setAddress_2(getTestString("HomeDelivery.Order.deliveryto_add2"));
		delTo.setCity(getTestString("HomeDelivery.Order.deliveryto_city"));
		delTo.setState(getTestString("HomeDelivery.Order.deliveryto_state"));
		delTo.setZip(getTestString("HomeDelivery.Order.deliveryto_zip"));
		delTo.setNote(getTestString("HomeDelivery.Order.deliveryto_note"));

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id(getTestString("HomeDelivery.Order.recipient_externalID"));
		rcp.setFirst_name(getTestString("HomeDelivery.Order.recipient_firstname"));
		rcp.setLast_name(getTestString("HomeDelivery.Order.receipient_lastname"));
		rcp.setPhone(generateRandom());
		rcp.setEmail(getTestString("HomeDelivery.Order.recipient_email"));

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey(getTestString("HomeDelivery.Order.notes_key_signature"));
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey(getTestString("HomeDelivery.Order.notes_key_alcohol"));
		notesRoot2.setValue("yes");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey(getTestString("HomeDelivery.Order.notes_key_itemcount"));
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for creating HomeDelivery NonAlcohol Order")
	public void userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryNonAlcoholOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		Float Gross_Bill = Float.valueOf(getTestString("HomeDelivery.Order.gross_bill"));
		ord.setGross_bill(Gross_Bill);

		ord.setTip(Float.valueOf(getTestString("HomeDelivery.Order.tip")));
		ord.setInvoice(getTestString("HomeDelivery.Order.invoice"));
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey(getTestString("HomeDelivery.Order.notes_key"));
		note.setValue(getTestString("HomeDelivery.Order.notes_value"));
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id(getTestString("HomeDelivery.Order.store_externalID"));
		str.setEmail(getTestString("HomeDelivery.Order.store_email"));
		str.setPhone(generateRandom());
		str.setName(getTestString("HomeDelivery.Order.store_name"));
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id(getTestString("HomeDelivery.Order.customer_externalID"));
		ctr.setFirst_name(getTestString("HomeDelivery.Order.customer_firstname"));
		ctr.setLast_name(getTestString("HomeDelivery.Order.customer_lastname"));
		ctr.setPhone(generateRandom());
		ctr.setEmail(getTestString("HomeDelivery.Order.customer_email"));
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1(getTestString("HomeDelivery.Order.deliveryfrom_add1"));
		del.setAddress_2(getTestString("HomeDelivery.Order.deliveryfrom_add2"));
		del.setCity(getTestString("HomeDelivery.Order.deliveryfrom_city"));
		del.setState(getTestString("HomeDelivery.Order.deliveryfrom_state"));
		del.setZip(getTestString("HomeDelivery.Order.deliveryfrom_zip"));
		del.setNote(getTestString("HomeDelivery.Order.deliveryfrom_note"));

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1(getTestString("HomeDelivery.Order.deliveryto_add1"));
		delTo.setAddress_2(getTestString("HomeDelivery.Order.deliveryto_add2"));
		delTo.setCity(getTestString("HomeDelivery.Order.deliveryto_city"));
		delTo.setState(getTestString("HomeDelivery.Order.deliveryto_state"));
		delTo.setZip(getTestString("HomeDelivery.Order.deliveryto_zip"));
		delTo.setNote(getTestString("HomeDelivery.Order.deliveryto_note"));

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id(getTestString("HomeDelivery.Order.recipient_externalID"));
		rcp.setFirst_name(getTestString("HomeDelivery.Order.recipient_firstname"));
		rcp.setLast_name(getTestString("HomeDelivery.Order.receipient_lastname"));
		rcp.setPhone(generateRandom());
		rcp.setEmail(getTestString("HomeDelivery.Order.recipient_email"));

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey(getTestString("HomeDelivery.Order.notes_key_signature"));
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey(getTestString("HomeDelivery.Order.notes_key_alcohol"));
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey(getTestString("HomeDelivery.Order.notes_key_itemcount"));
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter with all mandatory and optional fields for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterWithAllMandatoryAndOptionalFieldsForCreatingHomeDeliveryOrder()
			throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		Float Gross_Bill = Float.valueOf(getTestString("HomeDelivery.Order.gross_bill"));
		ord.setGross_bill(Gross_Bill);

		ord.setTip(Float.valueOf(getTestString("HomeDelivery.Order.tip")));
		ord.setInvoice(getTestString("HomeDelivery.Order.invoice"));
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey(getTestString("HomeDelivery.Order.notes_key"));
		note.setValue(getTestString("HomeDelivery.Order.notes_value"));
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id(getTestString("HomeDelivery.Order.store_externalID"));
		str.setEmail(getTestString("HomeDelivery.Order.store_email"));
		str.setPhone(generateRandom());
		str.setName(getTestString("HomeDelivery.Order.store_name"));
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id(getTestString("HomeDelivery.Order.customer_externalID"));
		ctr.setFirst_name(getTestString("HomeDelivery.Order.customer_firstname"));
		ctr.setLast_name(getTestString("HomeDelivery.Order.customer_lastname"));
		ctr.setPhone(generateRandom());
		ctr.setEmail(getTestString("HomeDelivery.Order.customer_email"));
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1(getTestString("HomeDelivery.Order.deliveryfrom_add1"));
		del.setAddress_2(getTestString("HomeDelivery.Order.deliveryfrom_add2"));
		del.setCity(getTestString("HomeDelivery.Order.deliveryfrom_city"));
		del.setState(getTestString("HomeDelivery.Order.deliveryfrom_state"));
		del.setZip(getTestString("HomeDelivery.Order.deliveryfrom_zip"));
		del.setNote(getTestString("HomeDelivery.Order.deliveryfrom_note"));

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1(getTestString("HomeDelivery.Order.deliveryto_add1"));
		delTo.setAddress_2(getTestString("HomeDelivery.Order.deliveryto_add2"));
		delTo.setCity(getTestString("HomeDelivery.Order.deliveryto_city"));
		delTo.setState(getTestString("HomeDelivery.Order.deliveryto_state"));
		delTo.setZip(getTestString("HomeDelivery.Order.deliveryto_zip"));
		delTo.setNote(getTestString("HomeDelivery.Order.deliveryto_note"));

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id(getTestString("HomeDelivery.Order.recipient_externalID"));
		rcp.setFirst_name(getTestString("HomeDelivery.Order.recipient_firstname"));
		rcp.setLast_name(getTestString("HomeDelivery.Order.receipient_lastname"));
		rcp.setPhone(generateRandom());
		rcp.setEmail(getTestString("HomeDelivery.Order.recipient_email"));

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey(getTestString("HomeDelivery.Order.notes_key_signature"));
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey(getTestString("HomeDelivery.Order.notes_key_alcohol"));
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey(getTestString("HomeDelivery.Order.notes_key_itemcount"));
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Geocode body parameter contains all valid editable fields")
	public void userUPDATEHomeDeliveryGeocodeBodyParameterContainsAllValidEditableFields()
			throws JsonProcessingException {

		Geocode_Body pr = new Geocode_Body();
		ObjectMapper objm = new ObjectMapper();

		pr.setStreet(getTestString("HomeDelivery.Order.geocode_street"));
		pr.setCity(getTestString("HomeDelivery.Order.geocode_city"));
		pr.setState(getTestString("HomeDelivery.Order.geocode_state"));
		pr.setZip(getTestString("HomeDelivery.Order.geocode_zip"));

		String jsonInString = objm.writeValueAsString(pr);
		jsonInString = jsonInString.replace("\"street\"", "\"street-address\"");

		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Geocode body parameter contains invalid valid editable fields")
	public void userUPDATEHomeDeliveryGeocodeBodyParameterContainsInvalidEditableFields()
			throws JsonProcessingException {

		Geocode_Body pr = new Geocode_Body();
		ObjectMapper objm = new ObjectMapper();

		pr.setStreet(getTestString("HomeDelivery.Order.geocode_invalidstreet"));
		pr.setCity(getTestString("HomeDelivery.Order.geocode_city"));
		pr.setState(getTestString("HomeDelivery.Order.geocode_state"));

		String jsonInString = objm.writeValueAsString(pr);
		jsonInString = jsonInString.replace("\"street\"", "\"street-address\"");

		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User GET response call for HomeDelivery orders")
	public static void userGETResponseCallForHomeDeliverOrders() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Orders");
				putTestObject("rClient", rClient);

				String RESPONSE = rClient.getEntity(String.class);
				HomeDelivery_RootObject gson1 = new Gson().fromJson(RESPONSE, HomeDelivery_RootObject.class);
				// Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				int ID = gson1.getdata().getId();
				String comsID = gson1.getdata().getComsId();
				putTestObject("OrderID", ID);
				putTestObject("comsID", comsID);
				Reporter.log("Read Success-HomeDelivery Order ID: " + ID);
				Reporter.log("Read Success-HomeDelivery Order ComsID: " + comsID);
				System.out.println("Read Success-HomeDelivery Order ID: " + ID);
				System.out.println("Read Success-HomeDelivery Order ComsID: " + comsID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "User POST the Create HomeDelivery Order call")
	public void userPOSTTheCreateHomeDeliveryOrderCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Teams is created ");
				putTestObject("rClient", rClient);

				String RESPONSE = rClient.getEntity(String.class);
				Orders_Post gson1 = new Gson().fromJson(RESPONSE, Orders_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				int OrderID = gson1.getData().getId();
				String comsID = gson1.getData().getComsId();
				putTestObject("OrderID", OrderID);
				putTestObject("comsID", comsID);
				Reporter.log("Created Success-HomeDelivery Order ID: " + OrderID);
				Reporter.log("Created Success-HomeDelivery Order ComsID: " + comsID);
				System.out.println("Created Success-HomeDelivery Order ID: " + OrderID);
				System.out.println("Created Success-HomeDelivery Order ComsID: " + comsID);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Order created with failed  " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User POST the Create HomeDelivery Order call for Alcohol")
	public void userPOSTTheCreateHomeDeliveryOrderCallForAlcohol() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Teams is created ");
				putTestObject("rClient", rClient);

				String RESPONSE = rClient.getEntity(String.class);
				Orders_Post gson1 = new Gson().fromJson(RESPONSE, Orders_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				List<HomeDelivery_Tasks> task = gson1.getData().gettasks();
				putTestObject("onFleetID", gson1.getData().getOnFleetDriver());
				

				if (task.size() == 3)
					Reporter.log("Order associated wiht 3onFleet tasks", MessageTypes.Pass);
				else
					Reporter.log("Order not associated wiht 3onFleet tasks", MessageTypes.Fail);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Order created with failed  " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User POST the Create HomeDelivery Order call for NonAlcohol")
	public void userPOSTTheCreateHomeDeliveryOrderCallForNonAlcohol() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Teams is created ");
				putTestObject("rClient", rClient);

				String RESPONSE = rClient.getEntity(String.class);
				Orders_Post gson1 = new Gson().fromJson(RESPONSE, Orders_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				List<HomeDelivery_Tasks> task = gson1.getData().gettasks();

				if (task.size() == 2)
					Reporter.log("Order associated wiht 2onFleet tasks", MessageTypes.Pass);
				else
					Reporter.log("Order not associated wiht 2onFleet tasks", MessageTypes.Fail);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Order created with failed  " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	public static String getexternalID() {
		Random random = new Random();
		char[] digits = new char[6];
		digits[0] = (char) (random.nextInt(4) + '1');
		for (int i = 1; i < 6; i++) {
			digits[i] = (char) (random.nextInt(5) + '0');
		}
		return (new String(digits));
	}

	public static String startDate() {
		String strdate = null;
		LocalDateTime time = LocalDateTime.now();
		LocalDateTime day = time.plusDays(1);
		String s1 = day.toString();
		String b[] = s1.split("\\.");

		for (String temp : b) {
			strdate = temp + "Z";
			break;
		}
		return strdate;
	}

	public static String endDate() {
		String strdate = null;
		LocalDateTime time = LocalDateTime.now();
		LocalDateTime day = time.plusDays(1).plusHours(1);
		String s1 = day.toString();
		String b[] = s1.split("\\.");

		for (String temp : b) {
			strdate = temp + "Z";
			break;
		}
		return strdate;
	}

	public static String generateRandom() {
		Random random = new Random();
		char[] digits = new char[5];
		digits[0] = (char) (random.nextInt(4) + '1');
		for (int i = 1; i < 5; i++) {
			digits[i] = (char) (random.nextInt(5) + '0');
		}

		return "83075"+(new String(digits));
	}
	

	@QAFTestStep(description = "validate the response schema with GET Orders")
	public static void validateTheResponseSchemaWithGETOrders() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Orders");
				putTestObject("rClient", rClient);

				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "GET_ORDERS");
				HomeDelivery_ReusableUtils.validateJSONschema("Orders_GET", "GET_ORDERS");
			}
			if (rClient.getStatus() != 200) {
				Reporter.log("Order created with failed", MessageTypes.Fail);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "validate the response schema with POST Orders")
	public void validateTheResponseSchemaWithPOSTOrders() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Teams is created ");
				putTestObject("rClient", rClient);

				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");

				Orders_Post gson1 = new Gson().fromJson(RESPONSE, Orders_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				int OrderID = gson1.getData().getId();
				putTestObject("OrderID", OrderID);
				Reporter.log("Created Success-HomeDelivery Order ID: " + OrderID);
				System.out.println("Created Success-HomeDelivery Order ID: " + OrderID);

				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "POST_ORDER");
				HomeDelivery_ReusableUtils.validateJSONschema("Order_POST", "POST_ORDER");

			}
			if (rClient.getStatus() != 200) {
				Reporter.log("Order created with failed", MessageTypes.Fail);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			System.out.println(e);
			Reporter.log("Order created with failed  ", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "User PUT the Update HomeDelivery Order call")
	public void userPUTTheUpdateHomeDeliveryOrderCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			rClient = ServiceUtils.PUT(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {
				Reporter.log("HomeDelivery Order is updated ");
				putTestObject("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				HomeDelivery_RootObject gson1 = new Gson().fromJson(RESPONSE, HomeDelivery_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				Reporter.log("DeliveryStartTime_Updated "+gson1.getdata().getDeliveryStartDateTime());
				Reporter.log("DeliveryEndTime_Updated "+gson1.getdata().getDeliveryEndDateTime());
				Reporter.log("Status_Updated "+gson1.getdata().getStatus());
				Reporter.log("SignatureRequired_Updated "+gson1.getdata().getSignatureRequired());
				Reporter.log("AlcoholOrder_Updated "+gson1.getdata().getAlcoholOrder());
				Reporter.log("Notes1_Updated "+gson1.getdata().getNotes().get(0).getNote());
				Reporter.log("Notes2_Updated "+gson1.getdata().getNotes().get(1).getNote());
				Reporter.log("Notes3_Updated "+gson1.getdata().getNotes().get(2).getNote());
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Order update failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery Order update failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery Order update failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("HomeDelivery Order update failed  ");
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	@QAFTestStep(description = "User PUT the Update HomeDelivery Geocode call")
	public void userPUTTheUpdateHomeDeliveryGeocodeCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			rClient = ServiceUtils.PUT(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Team is updated ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Geocode_RootObject gson1 = new Gson().fromJson(RESPONSE, Geocode_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				int ID = gson1.getData().getId();
				putTestObject("GeoID", ID);
				Reporter.log("Update Success-HomeDelivery GeoCode ID: " + ID);
				System.out.println("Update Success-HomeDelivery GeoCode ID: " + ID);
			}
			if (rClient.getStatus() != 200) {
				Reporter.log("HomeDelivery Geocode creation failed  ");
				putTestObject("rClient", rClient);
			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for updating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterForUpdatingHomeDeliveryOrder() throws JsonProcessingException {

		Order_PutRoot pr = new Order_PutRoot();
		Order_PUT_Notes notes = new Order_PUT_Notes();
		Order_PUT_Notes notes1 = new Order_PUT_Notes();
		Order_PUT_Notes notes2 = new Order_PUT_Notes();
		ProntoOrder pronto = new ProntoOrder();
		ProntoOrder pronto1 = new ProntoOrder();
		ProntoOrder pronto2 = new ProntoOrder();
		ObjectMapper objm = new ObjectMapper();
		
		Calendar cal = Calendar.getInstance();
		String dateFormatedDeliveryStart = new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime()) +getTestString("HomeDelivery.Order.deliverystartsuffix");
		String dateFormatedDeliveryEnd = new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime()) +getTestString("HomeDelivery.Order.deliveryendsuffix");
		putTestObject("DeliveryStart", dateFormatedDeliveryStart);
		putTestObject("DeliveryEnd", dateFormatedDeliveryEnd);
		pr.setDeliveryStartDateTime(dateFormatedDeliveryStart);
		pr.setDeliveryEndDateTime(dateFormatedDeliveryEnd);
		String status = chooseRandomStatus();
		putTestObject("OrderStatus", status);
		pr.setStatus(status);
		String signatureReq = chooseRandomTrueFalse();
		String alcoholOrder = chooseRandomTrueFalse();
		putTestObject("SignatureRequired", signatureReq);
		putTestObject("AlcoholOrder", alcoholOrder);
		pr.setSignatureRequired(signatureReq);
		pr.setAlcoholOrder(alcoholOrder);
		
		ArrayList<Order_PUT_Notes> notesAll = new ArrayList<Order_PUT_Notes>();
		
		notes.setNoteId(getTestString("HomeDelivery.Order.noteID1"));
		pronto.setComsId(getTestString("HomeDelivery.Order.comsID"));
		pronto.setId(getTestString("HomeDelivery.Order.prontoID"));
		notes.setProntoOrder(pronto);
		notes.setType(getTestString("HomeDelivery.Order.type1"));
		String randomNotes = getTestString("HomeDelivery.Order.notePrefix")+PerfectoUtils.randomAlphaNumeric(10);
		putTestObject("Notes1", randomNotes);
		notes.setNote(randomNotes);
		
		notes1.setNoteId(getTestString("HomeDelivery.Order.noteID2"));
		pronto1.setComsId(getTestString("HomeDelivery.Order.comsID"));
		pronto1.setId(getTestString("HomeDelivery.Order.prontoID"));
		notes1.setProntoOrder(pronto1);
		notes1.setType(getTestString("HomeDelivery.Order.type2"));
		String randomNotes1 = getTestString("HomeDelivery.Order.notePrefix")+PerfectoUtils.randomAlphaNumeric(10);
		putTestObject("Notes2", randomNotes1);
		notes1.setNote(randomNotes1);
		
		notes2.setNoteId(getTestString("HomeDelivery.Order.noteID3"));
		pronto2.setComsId(getTestString("HomeDelivery.Order.comsID"));
		pronto2.setId(getTestString("HomeDelivery.Order.prontoID"));
		notes2.setProntoOrder(pronto2);
		notes2.setType(getTestString("HomeDelivery.Order.type3"));
		String randomNotes2 = getTestString("HomeDelivery.Order.notePrefix")+PerfectoUtils.randomAlphaNumeric(10);
		putTestObject("Notes3", randomNotes2);
		notes2.setNote(randomNotes2);
		
		notesAll.add(notes);
		notesAll.add(notes1);
		notesAll.add(notes2);
		
		
		pr.setNotes(notesAll);
		
		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}
	
	private String chooseRandomStatus(){
		List<String> status = getTestList("HomeDelivery.Order.status.value");
		int noOfStatus = status.size();
		int randomvalue = mathRandom(0, noOfStatus-1);
		return status.get(randomvalue);
	}
	
	private String chooseRandomTrueFalse(){
		List<String> status = getTestList("HomeDelivery.Order.signaturerequired_alcoholorder.value");
		int randomvalue = mathRandom(0, 1);
		return status.get(randomvalue);
	}
	
	private int mathRandom(int min, int max) {
		int range = (max - min) + 1;
		return (int) (Math.random() * range) + min;
	}
	
	@QAFTestStep(description = "Create multiple test orders using POST order api {0}")
	public void createMultipleTestOrdersUsingPOSTOrderApi(int CreateOrderCount) throws JsonProcessingException {
		
		int i =1;
		while(i<=CreateOrderCount){
		Common_APIStepDef.userWithValidAPIkeyForHomeDelivery();
		buildURLForCreateHomeDeliverOrders();
		userUsesAnArrayOfBodyParameterWithAllMandatoryAndOptionalFieldsForCreatingHomeDeliveryOrder();
		userPOSTTheCreateHomeDeliveryOrderCall();
		i++;
		}
	}
}
