package com.heb.automation.Services.HomeDelivery.Teams;

import java.util.ArrayList;

public class Teams_RootObject {
	
	private String apiStatus;

    private ArrayList<Teams_Data> data = new ArrayList<Teams_Data>() ;

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

    public ArrayList<Teams_Data> getData ()
    {
        return data;
    }

    public void setData (ArrayList<Teams_Data> data)
    {
        this.data = data;
    }

}
