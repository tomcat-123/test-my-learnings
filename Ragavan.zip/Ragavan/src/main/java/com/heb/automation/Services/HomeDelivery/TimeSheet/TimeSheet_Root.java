package com.heb.automation.Services.HomeDelivery.TimeSheet;

public class TimeSheet_Root {
	
	private String apiStatus;

    private TimeSheet_Data data;

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

    public TimeSheet_Data getData ()
    {
        return data;
    }

    public void setData (TimeSheet_Data data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [apiStatus = "+apiStatus+", data = "+data+"]";
    }

}
