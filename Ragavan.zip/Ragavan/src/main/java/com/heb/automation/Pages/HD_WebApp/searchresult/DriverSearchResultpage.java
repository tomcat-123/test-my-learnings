package com.heb.automation.Pages.HD_WebApp.searchresult;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class DriverSearchResultpage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator locator, Object... args) {

	}

	public QAFWebElement getDriverFirstNameresult(int count) {

		String loc = String.format(pageProps.getString("driverResult.lbl.firstnamevalue"), count);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getDriverLastNameresult(int count) {
		String loc = String.format(pageProps.getString("driverResult.lbl.Lastnamevalue"), count);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getDriverPhoneNumresult(int count) {
		String loc = String.format(pageProps.getString("driverResult.lbl.PhoneNumbervalue"), count);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getDriverDateresult(int count) {
		String loc = String.format(pageProps.getString("driverResult.lbl.Datevalue"), count);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getDriverZoneresult(int count) {
		String loc = String.format(pageProps.getString("driverResult.lbl.Zonevalue"), count);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getDriverShiftresult(int count) {
		String loc = String.format(pageProps.getString("driverResult.lbl.ShiftTimevalue"), count);
		return new QAFExtendedWebElement(loc);
	}
}
