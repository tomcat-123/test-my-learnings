package com.heb.automation.Steps.API_Stepdef;
//package com.heb.automation.Services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.aspectj.org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo.AssertionFailedException;
import org.testng.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.ErrorMessages.ErrorMessage;
//import com.heb.automation.Services.BodyParameter.Drivers.Driver_Post;
//import com.heb.automation.Services.BodyParameter.Drivers.Drivers_Body;
//import com.heb.automation.Services.BodyParameter.Drivers.Vehicles_Body;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_Success;
import com.heb.automation.Services.HomeDelivery.ServiceUtils;
//import com.heb.automation.Services.HomeDelivery.Drivers.Drivers_Post;
//import com.heb.automation.Services.HomeDelivery.Drivers.Drivers_RootObject;
import com.heb.automation.Services.HomeDelivery.Zones.City_Data;
import com.heb.automation.Services.HomeDelivery.Search.Post_Search;
import com.heb.automation.Services.HomeDelivery.Search.Post_SearchCriteria;
import com.heb.automation.Services.HomeDelivery.Search.SearchResults_RootObject;
import com.heb.automation.Services.HomeDelivery.Search.SearchResults_ZonesData;
import com.heb.automation.Services.HomeDelivery.Search.SearchResults_SortParameters;
import com.heb.automation.Services.HomeDelivery.Zones.Zones_Data;
import com.heb.automation.Services.HomeDelivery.Zones.Zones_Post;
import com.heb.automation.Services.HomeDelivery.Zones.Zones_RootObject;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class ZonesStepdef extends TestDataContainer {

	@QAFTestStep(description = "Build URL for reading HomeDelivery zone using zoneID")
	public void buildURLForReadHomeDeliveryZoneUsingZoneID() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getZone") + "/"
				+ getTestString("ZoneID");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for Creating HomeDelivery Zone")
	public void buildURLForCreatingHomeDeliveryZone() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getZone");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for Searching HomeDelivery Zones")
	public void buildURLForSearchingHomeDeliveryZones() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.searchZones");
		//String resource = getTestString("HomeDelivery.endpoint.searchCities");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for Delete HomeDelivery Zone")
	public void buildURLForDeleteHomeDeliveryZone() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getZone") + "/"
				+ getTestString("ZoneID");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for Delete HomeDelivery Zone With invalidID")
	public void buildURLForDeletHomeDeliveryZoneWithInvalidID() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getZone") + "/"
				+ getTestString("ZoneID") + "999";
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for creating HomeDelivery Zone")
	public void userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryZone() throws JsonProcessingException {

		Zones_Data pr = new Zones_Data();
		ObjectMapper objm = new ObjectMapper();
		
		pr.setId(null);
		pr.setLastModifiedTimestamp(null);
		pr.setName(getName());
		pr.setArchived(false);
		pr.setexternalIdOnfleet(null);
		//pr.setPhone(generateRandom());

/*		List<String> zipCodes = new ArrayList<String>();
		zipCodes.add("78210");
		zipCodes.add("78211");
		zipCodes.add("78212");
		pr.setZipCodes(zipCodes);*/

/*		String[] zipCodes = new String[3];		
		zipCodes[0] = "78210";
		zipCodes[1] = "78211";
		zipCodes[2] = "78212";
		pr.setZipCodes(zipCodes);*/
		
		String[] zipCodes = {"78210", "78211", "78212"};
		pr.setZipCodes(zipCodes);
		
		String cityId = "82";
		String cityName = "City UI For API Automation - Do not update";
		String[] cityZones = {};
		
		City_Data city = new City_Data();
		city.setArchived(false);
		city.setDriverCount(0);
		city.setHourlyRate(0);
		city.setId(cityId);
		city.setLastModifiedTimestamp(null);
		city.setMapLink(null);
		city.setName(cityName);
		city.setParkingIdOnfleet(null);
		city.setTipsAndTricksIdOnfleet(null);
		city.setZones(cityZones);

		pr.setCity(city);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + pr.getName());
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for searching HomeDelivery Zone with {0} {1} {2} {3} {4} {5} {6}")
	public void userUsesAnArrayOfBodyParameterForSearchingHomeDeliveryZone(String searchKey, String searchOp, String searchVal, String PgNo, String PgSize, String sortDir, String srtBy) 
			throws JsonProcessingException {

		Post_Search pr = new Post_Search();
		Post_SearchCriteria sc = new Post_SearchCriteria();
		ArrayList<Post_SearchCriteria> bodySc = new ArrayList<Post_SearchCriteria>();
		ObjectMapper objm = new ObjectMapper();
		
		String key = searchKey;
		String operation = searchOp;
		String value = searchVal;

		String pageNumber = PgNo;
		String pageSize = PgSize;
		String sortDirection = sortDir;
		String sortBy = srtBy;
		
		sc.setKey(key);
		sc.setOperation(operation);
		sc.setValue(value);
		bodySc.add(sc);
		
		pr.setPageNumber(pageNumber);
		pr.setPageSize(pageSize);		
		pr.setsortDirection(sortDirection);
		pr.setSortBy(sortBy);		
		pr.setSearchCriteria(bodySc);
		
/*		City_Data city = new City_Data();
		city.setArchived(null);
		city.setDriverCount(driverCount);
		city.setHourlyRate(hourlyRate);
		city.setId(id);
		city.setLastModifiedTimestamp(lastModifiedTimestamp);
		city.setMapLink(mapLink);
		city.setName(name);
		city.setParkingIdOnfleet(parkingIdOnfleet);
		city.setTipsAndTricksIdOnfleet(tipsAndTricksIdOnfleet);
		city.setZones(zones);*/

		String jsonInString = objm.writeValueAsString(pr);
		
		//System.out.println("CHoosen Name is  :" + pr.toString());
		System.out.println("Full search body is : " + jsonInString);
		
		putTestObject("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Some Missing Mandatory Body Parameter for creating HomeDelivery Zone")
	public void userUsesAnArrayOfSomeMissingMandatoryBodyParameterForCreatingHomeDeliveryZone()
			throws JsonProcessingException {

		Zones_Data pr = new Zones_Data();
		ObjectMapper objm = new ObjectMapper();
		
		pr.setId(null);
		pr.setLastModifiedTimestamp(null);
		pr.setName(null);
		pr.setArchived(false);
		pr.setexternalIdOnfleet(null);
		
		String[] zipCodes = {"78210", "78211", "78212"};
		pr.setZipCodes(zipCodes);
		
/*		String cityId = "82";
		String cityName = "City UI For API Automation - Do not update";
		String[] cityZones = {};
		
		City_Data city = new City_Data();
		city.setArchived(false);
		city.setDriverCount(0);
		city.setHourlyRate(0);
		city.setId(cityId);
		city.setLastModifiedTimestamp(null);
		city.setMapLink(null);
		city.setName(cityName);
		city.setParkingIdOnfleet(null);
		city.setTipsAndTricksIdOnfleet(null);
		city.setZones(cityZones);*/

		pr.setCity(null);
		
		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + pr.getName());
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of existing Body Parameter for creating HomeDelivery Zone")
	public void userUsesAnArrayOfExistingBodyParameterForCreatingHomeDeliveryZone() throws JsonProcessingException {

		Zones_Data pr = new Zones_Data();
		ObjectMapper objm = new ObjectMapper();
		
		pr.setId(null);
		pr.setLastModifiedTimestamp(null);
		pr.setName(getTestString("ZoneName"));
		pr.setArchived(false);
		pr.setexternalIdOnfleet(null);
		
		String[] zipCodes = {"78210", "78211", "78212"};
		pr.setZipCodes(zipCodes);
		
		//String cityId = "82";
		//String cityName = "City UI For API Automation - Do not update";
		String[] cityZones = {};
		
		City_Data city = new City_Data();
		city.setArchived(false);
		city.setDriverCount(0);
		city.setHourlyRate(0);
		city.setId(getTestString("CityID"));
		city.setLastModifiedTimestamp(null);
		city.setMapLink(null);
		city.setName(getTestString("CityName"));
		city.setParkingIdOnfleet(null);
		city.setTipsAndTricksIdOnfleet(null);
		city.setZones(cityZones);
		
		pr.setCity(city);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + pr.getName());
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Zone body parameter contains all valid editable fields")
	public void userUPDATEHomeDeliveryZoneBodyParameterContainsAllValidEditableFields()
			throws JsonProcessingException {

		Zones_Data pr = new Zones_Data();
		ObjectMapper objm = new ObjectMapper();
		
		pr.setId(getTestString("ZoneID"));
		pr.setLastModifiedTimestamp(null);
		pr.setName(getTestString("ZoneName")+"_Updated");
		pr.setArchived(false);
		pr.setexternalIdOnfleet(getTestString("ZoneOnfleetID"));
		
		String[] zipCodes = {"78210", "78211", "78212", "78213", "78240"};
		pr.setZipCodes(zipCodes);
		
		//String cityId = "82";
		//String cityName = "City UI For API Automation - Do not update";
		String[] cityZones = {};
		
		City_Data city = new City_Data();
		city.setArchived(false);
		city.setDriverCount(0);
		city.setHourlyRate(0);
		city.setId(getTestString("CityID"));
		city.setLastModifiedTimestamp(null);
		city.setMapLink(null);
		city.setName(getTestString("CityName"));
		city.setParkingIdOnfleet(null);
		city.setTipsAndTricksIdOnfleet(null);
		city.setZones(cityZones);

		pr.setCity(city);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + pr.getName());
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);

	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Zone body parameter containing all valid editable fields to archived")
	public void userUPDATEHomeDeliveryZoneBodyParameterContainingAllValidEditableFieldsToArchived()
			throws JsonProcessingException {

		Zones_Data pr = new Zones_Data();
		ObjectMapper objm = new ObjectMapper();
		
		pr.setId(getTestString("ZoneID"));
		pr.setLastModifiedTimestamp(null);
		pr.setName(getTestString("ZoneName")+"_Archived");
		pr.setArchived(true);
		pr.setexternalIdOnfleet(getTestString("ZoneOnfleetID"));
		
		String[] zipCodes = {"78210", "78211", "78212", "78213", "78240"};
		pr.setZipCodes(zipCodes);
		
		//String cityId = "82";
		//String cityName = "City UI For API Automation - Do not update";
		String[] cityZones = {};
		
		City_Data city = new City_Data();
		city.setArchived(false);
		city.setDriverCount(0);
		city.setHourlyRate(0);
		city.setId(getTestString("CityID"));
		city.setLastModifiedTimestamp(null);
		city.setMapLink(null);
		city.setName(getTestString("CityName"));
		city.setParkingIdOnfleet(null);
		city.setTipsAndTricksIdOnfleet(null);
		city.setZones(cityZones);

		pr.setCity(city);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + pr.getName());
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);

	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Zone body parameter with existing onfleetID")
	public void userUPDATEHomeDeliveryZoneBodyParameterWithExistingOnfleetID() throws JsonProcessingException {

		Zones_Data pr = new Zones_Data();
		ObjectMapper objm = new ObjectMapper();
		
		pr.setId(getTestString("ZoneID"));
		pr.setLastModifiedTimestamp(null);
		pr.setName(getTestString("ZoneName"));
		pr.setArchived(false);
		pr.setexternalIdOnfleet(getTestString("ZoneOnfleetID2"));
		
		String[] zipCodes = {"78210", "78211", "78212", "78213", "78240"};
		pr.setZipCodes(zipCodes);
		
		//String cityId = "82";
		//String cityName = "City UI For API Automation - Do not update";
		String[] cityZones = {};
		
		City_Data city = new City_Data();
		city.setArchived(false);
		city.setDriverCount(0);
		city.setHourlyRate(0);
		city.setId(getTestString("CityID"));
		city.setLastModifiedTimestamp(null);
		city.setMapLink(null);
		city.setName(getTestString("CityName"));
		city.setParkingIdOnfleet(null);
		city.setTipsAndTricksIdOnfleet(null);
		city.setZones(cityZones);

		pr.setCity(city);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + pr.getName());
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	//Not Used
	@QAFTestStep(description = "User GET response call for HomeDelivery Zones")
	public static void userGETResponseCallForHomeDeliveryZones() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery zones");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Zones_RootObject gson1 = new Gson().fromJson(RESPONSE,
						Zones_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String zoneID = gson1.getData().get(0).getId();
				putTestObject("ZoneID", zoneID);
				Reporter.log("Read Success-HomeDelivery Zone ID: " + zoneID);
				System.out.println("Read Success-HomeDelivery Zone ID: " + zoneID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "User POST the Create HomeDelivery Zone calls")
	public void userPOSTTheCreateHomeDeliveryZoneCalls() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Zone is created ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Zones_Post gson1 = new Gson().fromJson(RESPONSE, Zones_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String ZoneID = gson1.getData().getId();
				//String ZoneName = gson1.getData().getName();
				String ZoneOnfleetID2 = gson1.getData().getexternalIdOnfleet();
				putTestObject("ZoneID", ZoneID);
				//putTestObject("ZoneName", ZoneName);
				putTestObject("ZoneOnfleetID2", ZoneOnfleetID2);
				Reporter.log("Created Success-HomeDelivery Zone ID: " + ZoneID);
				//Reporter.log("Created Success-HomeDelivery Zone Name: " + ZoneName);
				Reporter.log("Created Success-HomeDelivery Zone OnfleetID: " + ZoneOnfleetID2);
				System.out.println("Created Success-HomeDelivery Zone ID: " + ZoneID);
				//System.out.println("Created Success-HomeDelivery Zone Name: " + ZoneName);
				System.out.println("Created Success-HomeDelivery Zone OnfleetID: " + ZoneOnfleetID2);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Zone creation failed with " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("Zone creation failed with " + 503);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User POST the Create HomeDelivery Zone call")
	public void userPOSTTheCreateHomeDeliveryZoneCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Zone is created ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Zones_Post gson1 = new Gson().fromJson(RESPONSE, Zones_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String ZoneID = gson1.getData().getId();
				String ZoneName = gson1.getData().getName();
				String ZoneOnfleetID = gson1.getData().getexternalIdOnfleet();
				String CityID = gson1.getData().getCity().getId();
				String CityName = gson1.getData().getCity().getName();

				putTestObject("ZoneID", ZoneID);
				putTestObject("ZoneName", ZoneName);
				putTestObject("ZoneOnfleetID", ZoneOnfleetID);
				putTestObject("CityID", CityID);
				putTestObject("CityName", CityName);
				
				Reporter.log("Created Success-HomeDelivery Zone ID: " + ZoneID);
				Reporter.log("Created Success-HomeDelivery Zone Name: " + ZoneName);
				Reporter.log("Created Success-HomeDelivery Zone OnfleetID: " + ZoneOnfleetID);
				Reporter.log("Created Success-HomeDelivery City ID: " + CityID);
				Reporter.log("Created Success-HomeDelivery City Name: " + CityName);
				
				System.out.println("Created Success-HomeDelivery Zone ID: " + ZoneID);
				System.out.println("Created Success-HomeDelivery Zone Name: " + ZoneName);
				System.out.println("Created Success-HomeDelivery Zone OnfleetID: " + ZoneOnfleetID);
				System.out.println("Created Success-HomeDelivery City ID: " + CityID);
				System.out.println("Created Success-HomeDelivery City Name: " + CityName);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Zone created with failed  " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("Zone creation failed with " + 503);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User POST the Search HomeDelivery Zone call")
	public void userPOSTTheSearchHomeDeliveryZoneCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Zone is created ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				SearchResults_RootObject gson1 = new Gson().fromJson(RESPONSE, SearchResults_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String searchResultsCount = gson1.getData().getTotalElements();
				//String ZoneName = gson1.getData().getName();
				//String ZoneOnfleetID = gson1.getData().getexternalIdOnfleet();
				putTestObject("searchResultsCount", searchResultsCount);
				//putTestObject("ZoneName", ZoneName);
				//putTestObject("ZoneOnfleetID", ZoneOnfleetID);
				Reporter.log("Search Success- Search Results Count : " + searchResultsCount);
				//Reporter.log("Created Success-HomeDelivery Zone Name: " + ZoneName);
				//Reporter.log("Created Success-HomeDelivery Zone OnfleetID: " + ZoneOnfleetID);
				System.out.println("Search Success- Search Results Count : " + searchResultsCount);
				//System.out.println("Created Success-HomeDelivery Zone Name: " + ZoneName);
				//System.out.println("Created Success-HomeDelivery Zone OnfleetID: " + ZoneOnfleetID);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Zone created with failed  " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("Zone creation failed with " + 503);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	//Not Used
	@QAFTestStep(description="User uses batch POST to Create Multiple HomeDelivery Zones {0}")
	public void userUsesBatchPOSTToCreateMultipleHomeDeliveryZones(int batchCount){
		int batchPostCount = batchCount;
		//String[] dispatcherID = new String[batchPostCount];
		List<String> zoneID = new ArrayList<>();
		
		for (int i=1; i<=batchPostCount; i++) {
			
			try {
				
				userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryZone();  	//Zone
				userPOSTTheCreateHomeDeliveryZoneCall();						//Zone
				
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			
			//dispatcherID[i] = getTestString("DispatcherID");
			zoneID.add(getTestString("ZoneID"));
			System.out.println("Zone is :" + zoneID);
			
		}
		
		putTestObject("ZoneIDList", zoneID);		
		System.out.println("Final Zone is :" + getTestObject("ZoneIDList"));
	}
	
	
	@QAFTestStep(description = "User GET response call for Specific HomeDelivery zone")
	public static void userGETResponseCallForSpecificHomeDeliveryZone() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery zones");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Zones_Post gson1 = new Gson().fromJson(RESPONSE, Zones_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String ZoneID = gson1.getData().getId();
				boolean archived = gson1.getData().getArchived();
				putTestObject("ZoneID", ZoneID);
				putTestObject("ZoneID_isArchived", archived);
				Reporter.log("Read Success-HomeDelivery Zone ID: " + ZoneID);
				System.out.println("Read Success-HomeDelivery Zone ID: " + ZoneID);
				System.out.println("Read Success-HomeDelivery Zone ID archived: " + archived);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);
			String RESPONSE = rClient.getEntity(String.class);
			ErrorMessage json = new Gson().fromJson(RESPONSE, ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}
	

	@QAFTestStep(description = "User PUT the Update HomeDelivery Zone call")
	public void userPUTTheUpdateHomeDeliveryZoneCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			rClient = ServiceUtils.PUT(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Zone is updated ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Zones_Post gson1 = new Gson().fromJson(RESPONSE, Zones_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String zoneID = gson1.getData().getId();
				String updatedZoneName = gson1.getData().getName();
				String[] updatedZipCodes = gson1.getData().getZipCodes();
				putTestObject("ZoneID", zoneID);
				putTestObject("Updated_ZoneName",updatedZoneName);
				putTestObject("Updated_ZoneZipCodes", updatedZipCodes.toString());
				Reporter.log("Update Success-HomeDelivery Zone ID: " + zoneID);
				Reporter.log("Update Success-HomeDelivery Zone Name: " + updatedZoneName);
				Reporter.log("Update Success-HomeDelivery Zone ZipCodes: " + updatedZipCodes.toString());
				System.out.println("Update Success-HomeDelivery Zone ID: " + zoneID);
				System.out.println("Update Success-HomeDelivery Zone Name: " + updatedZoneName);
				System.out.println("Update Success-HomeDelivery Zone ZipCodes: " + updatedZipCodes.toString());
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Zone updation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery Zone updation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery Zone updation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 500) {
				Reporter.log("HomeDelivery Zone updation failed  ");
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User DELETE the HomeDelivery Zone")
	public void userDELETETheHomeDeliveryZone() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.DELETE(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("HomeDelivery Zone is deleted ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				HomeDelivery_Success gson1 = new Gson().fromJson(RESPONSE,
						HomeDelivery_Success.class);
				putTestObject("rGSON", gson1);
				System.out.println(" : " + gson1.getApiStatus());
				Reporter.log("Deleted HomeDelivery Zone : " + gson1.getApiStatus());
			}
			if (rClient.getStatus() == 207) {
				Reporter.log("HomeDelivery Zone Deleted with Partial success  ");
				putTestObject("rClient", rClient);
				ErrorMessage gson1 = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
				putTestObject("rGSON", gson1);
			}

			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Zone Deletion failed with 400");
				putTestObject("rClient", rClient);
			}

			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery Zone Deletion failed with 404");
				putTestObject("rClient", rClient);
			}
			
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery Zone Deletion failed with 401");
				putTestObject("rClient", rClient);
			}
			
			if (rClient.getStatus() == 503) {
				Reporter.log("HomeDelivery Zone Deletion failed with 503");
				putTestObject("rClient", rClient);
			}
			
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Zone Deletion failed with 400");
				putTestObject("rClient", rClient);
			}

		}
	}

	public static String getName() {
		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 10;
		
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();

		return "Test Zone automation" + generatedString;
	}

	public static String getNameMoreThan101Characters() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "Automation zone name more than 101 characters in length should return an exception "
				+ name.substring(3, name.length());

	}

	public static String generateRandom() {
		Random random = new Random();
		char[] digits = new char[5];
		digits[0] = (char) (random.nextInt(4) + '1');
		for (int i = 1; i < 5; i++) {
			digits[i] = (char) (random.nextInt(5) + '0');
		}
		return "83075" + (new String(digits));
	}

	public static String generateRandomInvalidFormat() {
		Random random = new Random();
		char[] digits = new char[5];
		digits[0] = (char) (random.nextInt(4) + '1');
		for (int i = 1; i < 5; i++) {
			digits[i] = (char) (random.nextInt(5) + '0');
		}
		return "+1-830-75" + (new String(digits));
	}
	
	@QAFTestStep(description = "Validate success of the HomeDelivery Zone deletion")
	public void validateSuccessOfTheHomeDeliveryZoneDeletion() throws Exception {

/*		ClientResponse rClient = (ClientResponse) getTestObject("rClient");
		CommonUtils.getAllStatusupdates(rClient);
		HomeDelivery_ReusableUtils.compareHomeDeliveryZoneActualandExpected();*/
		
		boolean validateArchived = (boolean) getTestObject("ZoneID_isArchived");
	
		try {
			
			Assert.assertEquals(validateArchived, true);
			Reporter.log("Zone deleted successfully!", MessageTypes.Pass);
			
		} catch (AssertionFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
	
	}

	@QAFTestStep(description = "Validate failure of the HomeDelivery Zone deletion")
	public void validateFailureOfTheHomeDeliveryZoneDeletion() throws Exception {

/*		ClientResponse rClient = (ClientResponse) getTestObject("rClient");
		CommonUtils.getAllStatusupdates(rClient);
		HomeDelivery_ReusableUtils.compareHomeDeliveryZoneActualandExpected();*/
		
		boolean validateArchived = (boolean) getTestObject("ZoneID_isArchived");
	
		try {
			
			Assert.assertEquals(validateArchived, false);
			Reporter.log("Zone not deleted successfully!", MessageTypes.Pass);
			
		} catch (AssertionFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}

	}

	//Not Used
	@QAFTestStep(description = "validate the response schema with GET Zones")
	public static void validateTheResponseSchemaWithGETZones() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery zones");
				putTestObject("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");

				Zones_RootObject gson1 = new Gson().fromJson(RESPONSE,
						Zones_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String zoneID = gson1.getData().get(0).getId();
				putTestObject("ZoneID", zoneID);
				Reporter.log("Read Success-HomeDelivery Zone ID: " + zoneID);
				System.out.println("Read Success-HomeDelivery Zone ID: " + zoneID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "GET_ZONES");
				HomeDelivery_ReusableUtils.validateJSONschema("Zones_GET", "GET_ZONES");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);
		}
	}
	
	//Not Used
	@QAFTestStep(description = "validate the response schema with POST Zone")
	public void validateTheResponseSchemaWithPOSTZone() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Zones is created ");
				putTestObject("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");

				Zones_Post gson1 = new Gson().fromJson(RESPONSE, Zones_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String zoneID = gson1.getData().getId();
				putTestObject("ZoneID", zoneID);
				Reporter.log("Created Success-HomeDelivery Zone ID: " + zoneID);
				System.out.println("Created Success-HomeDelivery Zone ID: " + zoneID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "POST_ZONE");
				HomeDelivery_ReusableUtils.validateJSONschema("Zone_POST", "POST_ZONE");
				
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Zone created with failed  " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	//Not Used
	@QAFTestStep(description = "validate the response schema with PUT Zone")
	public void validateTheResponseSchemaWithPUTZone() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			rClient = ServiceUtils.PUT(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Zone is updated ");
				putTestObject("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");

				Zones_Post gson1 = new Gson().fromJson(RESPONSE, Zones_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String zoneID = gson1.getData().getId();
				//String PhoneNum = gson1.getData().getPhone();
				putTestObject("ZoneID", zoneID);
				//putTestObject("PhoneNum", PhoneNum);
				Reporter.log("Created Success-HomeDelivery Zone ID: " + zoneID);
				System.out.println("Created Success-HomeDelivery Zone ID: " + zoneID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "PUT_ZONE");
				HomeDelivery_ReusableUtils.validateJSONschema("Zone_PUT", "PUT_ZONE");
				
			}
			if (rClient.getStatus() != 200) {
				Reporter.log("HomeDelivery Zone created with failed  ",MessageTypes.Fail);
				putTestObject("rClient", rClient);

			}

		} catch (Exception e) {

			Reporter.log("Exceptions :" + e,MessageTypes.Fail);
		}
	}
	
	//Not Used
	@QAFTestStep(description = "validate the response schema with GET Zone")
	public static void validateTheResponseSchemaWithGETZone() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);
			
			String RESPONSE = rClient.getEntity(String.class);
			putTestObject(RESPONSE, "RESPONSE");

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery zones");
				putTestObject("rClient", rClient);

				Zones_Post gson1 = new Gson().fromJson(RESPONSE, Zones_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String zoneID = gson1.getData().getId();
				putTestObject("ZoneID", zoneID);
				Reporter.log("Read Success-HomeDelivery Zone ID: " + zoneID);
				System.out.println("Read Success-HomeDelivery Zone ID: " + zoneID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "GET_ZONE");
				HomeDelivery_ReusableUtils.validateJSONschema("Zone_GET", "GET_ZONE");
			}
			if (rClient.getStatus() != 200) {
				Reporter.log("HomeDelivery Zone created with failed  ",MessageTypes.Fail);
				putTestObject("rClient", rClient);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}

}
