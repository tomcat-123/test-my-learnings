package com.heb.automation.Steps.HD_WebApp.city;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.openqa.selenium.support.ui.Select;

import com.heb.automation.Pages.HD_WebApp.CommonTestPage;
import com.heb.automation.Pages.HD_WebApp.city.CityDisplayTestPage;
import com.heb.automation.Pages.HD_WebApp.city.CityListingTestPage;
import com.heb.automation.Pages.HD_WebApp.searchresult.CitySearchResultpage;
import com.heb.automation.Pages.HD_WebApp.searchresult.SearchResultPage;
import com.heb.automation.common.CommonDBUtils;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class City_WebAppStepdef extends TestDataContainer {

	@QAFTestStep(description = "navigate to City listing Page")
	public void iNavigateToCityListingPage() {
		CommonTestPage common = new CommonTestPage();
		common.getNavigationBtnHamburger().click();
		common.getNavigationLblDriverSnapshot().waitForPresent(1000);
		common.getNavigationLblZoneConfiguration().click();
		common.getNavigationLblCity().waitForPresent(1000);
		common.getNavigationLblCity().click();

	}

	// Script will choose the first row in default

	@QAFTestStep(description = "navigate to city Display page")
	public void iNavigateToCityDisplayPage() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		CitySearchResultpage CityResult = new CitySearchResultpage();
		String cityDisplayed = CityResult.getCityNameresult(Rowcount).getText();
		if(cityDisplayed.equals(getTestString("HomeDelivery.ZoneCity"))){
			// Do not Update or Delete City
			Rowcount = Rowcount + 1;
			String cityNextDisplayed = CityResult.getCityNameresult(Rowcount).getText();
			putTestObject("SelectedCity", cityNextDisplayed);
		}else{
			putTestObject("SelectedCity", cityDisplayed);
		}
		CityResult.getCityNameresult(Rowcount).click();

	}

	@QAFTestStep(description = "verify city list page displays all cities")
	public void iVerifyCityListPageDisplaysAllCities() {
		
		
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		CitySearchResultpage cityResult = new CitySearchResultpage();
		cityResult.waitForPageToLoad();
		cityResult.getResultDropdown().waitForVisible(5000);
		
		List<String> cityList=new ArrayList<String>();
		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			String CityNameDisplayed = cityResult.getCityNameresult(Rowcount).getText();
			Rowcount++;
			cityList.add(CityNameDisplayed.trim());
			}
		putTestObject("CityNameList", cityList);
		System.out.println("City List : "+ cityList);
	}

	@QAFTestStep(description = "verify city list page displays all zones")
	public void iVerifyCityListPageDisplaysAllZones() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		CitySearchResultpage CityResult = new CitySearchResultpage();

		putTestObject("CityName", CityResult.getCityNameresult(1).getText());
		String ZoneNameDisplayed = CityResult.getCityZoneresult(Rowcount).getText();
		System.out.println(ZoneNameDisplayed);

		List<String> list = new ArrayList<String>(Arrays.asList(ZoneNameDisplayed.split("[\\s]*,[\\s]*")));
		putTestObject("Zonedetails_for_selectedCity", list);
		System.out.println("List of Zones for the choosen City :"+list );

	}
	
	
	
	
	@QAFTestStep(description = "User retrives all the City details")
	public void userRetrivesAllTheCityDetails() {
		CityDisplayTestPage cDisplay = new CityDisplayTestPage();

		Map<String, String> mapActual = new HashMap<String, String>();

		String cName1 = cDisplay.getCitydisplaytxtcityname().getAttribute("value");
		System.out.println("City Name " + cName1);
		mapActual.put("CityName", cName1);
		String cFunnel = cDisplay.getCitydisplaytxtfountainfunnel().getAttribute("value");
		System.out.println("City Fountain Funnel IF " + cFunnel);

		String cFountainTip = cDisplay.getCitydisplaytxtfountaintips().getAttribute("value");
		System.out.println("City FountainTip " + cFountainTip);

		String cApprover = cDisplay.getCitydisplaytxfountainapproved().getAttribute("value");
		System.out.println("City Approver " + cApprover);

		String cFountainrejected = cDisplay.getCitydisplaytxtfountainrejected().getAttribute("value");
		System.out.println("City Fountainrejected " + cFountainrejected);

		String cOnFleetTip = cDisplay.getCitydisplaytxtonfleettips().getAttribute("value");
		System.out.println("City cOnFleetTip " + cOnFleetTip);

		String cOnfleetpartjing = cDisplay.getCitydisplaytxtonfleetparking().getAttribute("value");
		System.out.println("City cOnfleetpartjing " + cOnfleetpartjing);

		String cHourlyrate = cDisplay.getCitydisplaytxthourlyrate().getAttribute("value");
		System.out.println("City hourlyrate " + cHourlyrate);

		mapActual.put("HourlyRate", cHourlyrate);

		String cMaplink = cDisplay.getCitydisplaytxtmaplink().getAttribute("value");
		System.out.println("City Maplink " + cMaplink);

		mapActual.put("MapLink", cMaplink);

		putTestObject("mapActual", mapActual);

	}

	@QAFTestStep(description = "verify city is not deleted")
	public void iVerifyCityIsNotDeleted() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		CitySearchResultpage CityResult = new CitySearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String cityNotdeleted = CityResult.getCityNameresult(Rowcount).getText();

			if (cityNotdeleted.equals(getTestString("SelectedCity")))
				PerfectoUtils.reportMessage("Selected City is not Deleted", MessageTypes.Pass);

			else
				PerfectoUtils.reportMessage("Selected City is Deleted", MessageTypes.Fail);
			Rowcount++;
		}

	}

	@QAFTestStep(description = "verify city is deleted")
	public void iVerifyCityIsDeleted() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		CitySearchResultpage CityResult = new CitySearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String cityNotdeleted = CityResult.getCityNameresult(Rowcount).getText();

			if (!cityNotdeleted.equals(getTestString("SelectedCity")))
				PerfectoUtils.reportMessage("Selected City is Deleted", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Selected City is not Deleted", MessageTypes.Fail);
			Rowcount++;
		}

	}

	/**
	 * Auto-generated code snippet by QMetry Automation Framework.
	 */
	
	@QAFTestStep(description = "verify the city listing page")
	public void iVerifyTheCityListingPage() {
		CityListingTestPage cityList = new CityListingTestPage();
		CommonTestPage common = new CommonTestPage();
		SearchResultPage sResult = new SearchResultPage();
		ArrayList<String> data = new ArrayList<>();

		cityList.getLblTitle().verifyPresent();
		cityList.getBtnCityCrumb().verifyPresent();
		cityList.getBtnCityCrumb().click();
		cityList.getBtnAddnew().waitForPresent(1000);
		cityList.getBtnAddnew().verifyPresent();
		common.getLblHomeRightArrow().verifyPresent();
		common.getLblHomeIcon().verifyPresent();
		common.getLblHomeRightArrow().verifyPresent();
		common.getCommonLblDisplayingRecords().verifyPresent();
		common.getCommonBtnPageNum().get(0).verifyPresent();

		for (QAFWebElement rCount : sResult.getTableColumnName()) {

			data.add(rCount.getText());
		}

		if (data.contains("Name"))
			PerfectoUtils.reportMessage("Name is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Name is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Zones"))
			PerfectoUtils.reportMessage("Zones is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Zones is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Onfleet"))
			PerfectoUtils.reportMessage("Onfleet is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Onfleet is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("# of Drivers"))
			PerfectoUtils.reportMessage("# of Drivers is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("# of Drivers is not Avilable in Grid", MessageTypes.Fail);
	}

	@QAFTestStep(description = "getting value from input box")
	public void gettingvaluefrominputbox() {
		CityDisplayTestPage cDisplay = new CityDisplayTestPage();

		String inputval = PerfectoUtils.getTxt("cityName");
		System.out.println(inputval);

	}

	@QAFTestStep(description = "verify input fields non editable")
	public void verifyinputfieldsnoneditabl() {

	}

	@QAFTestStep(description = "click on add new button in city listing page")
	public void iClickOnAddnewButtonInCityListingPage() {
		CityListingTestPage cityLTP = new CityListingTestPage();
		cityLTP.getBtnAddnew().waitForVisible(5000);
		cityLTP.getBtnAddnew().click();
	}

	@QAFTestStep(description = "verify city listing page displays newly created City")
	public void iVerifyCityListingPageDisplaysNewlyCreatedCity() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		CitySearchResultpage CityResult = new CitySearchResultpage();
		CommonTestPage common = new CommonTestPage();
		
		common.getCommonLnkForwardLast().waitForPresent(5000);
		common.getCommonLnkForwardLast().click();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String cityCreated = CityResult.getCityNameresult(Rowcount).getText();

			if (cityCreated.equals(getTestString("CityName"))) {
				PerfectoUtils.mouseoverandclick(CityResult.getCityNameresult(Rowcount));
				PerfectoUtils.reportMessage("Created City diaplayed in CityListing Page", MessageTypes.Pass);
			}
			Rowcount++;
		}

	}

}
