package com.heb.automation.Steps.HD_WebApp.db_validations;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.heb.automation.Pages.HD_WebApp.city.CityDisplayTestPage;
import com.heb.automation.Pages.HD_WebApp.searchresult.CitySearchResultpage;
import com.heb.automation.Pages.HD_WebApp.searchresult.SearchResultPage;
import com.heb.automation.Pages.HD_WebApp.searchresult.ZoneSearchResultpage;
import com.heb.automation.common.CommonDBUtils;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class DB_validations extends TestDataContainer {

	@QAFTestStep(description="User verifies city page details with DB using {0}")
	public void userVerifiesCityPageDetailsWithDBUsing(String query){
		Map<Integer,String> mapExpected = new HashMap<Integer,String>();
		Map<Integer,String> mapActual = new HashMap<Integer,String>();
		TreeMap<Integer,HashMap<String,String>> selectResult=null;
		
		CityDisplayTestPage cDisplay = new CityDisplayTestPage();
		
		String cName1 = cDisplay.getCitydisplaytxtcityname().getAttribute("value");
		System.out.println("City Name "+cName1 );
		putTestObject("SelectedCity", cName1);
		int keyValue =1;
		
		mapActual.put(keyValue, cName1);
		CommonDBUtils dbUtil= new CommonDBUtils();
		String str=getTestString("SelectedCity"); // Please look for zone selected.
		System.out.println(query);
		query=query.replace("{City Name}", str);
		System.out.println(query);
		Connection con=null;
		
		try {
			 con=dbUtil.getConnection();
			 selectResult=	dbUtil.selectQuery(con,query);		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtil.closeConnection(con);
		}
		
		for (int i=1;i<=selectResult.size();i++) {
			System.out.println(selectResult.get(i));
			mapExpected.put(i, selectResult.get(i).get("City Name"));
			System.out.println(selectResult);
		}
				
		if(mapActual.equals(mapExpected)) {
			PerfectoUtils.reportMessage("The user is able to verify City Name", MessageTypes.Pass);
		}else {
			PerfectoUtils.reportMessage("The user is unable to verify City Name", MessageTypes.Fail);
		}
	}
	
	
	
	/**
	* Auto-generated code snippet by QMetry Automation Framework.
	*/
	@QAFTestStep(description="Validate ZoneCount with DB {0}")
	public void validateZoneCountWithDB(String query){
		Connection con=null;
		TreeMap<Integer,HashMap<String,String>> selectResult=null;
		CommonDBUtils dbUtil= new CommonDBUtils();
		try {
			 con=dbUtil.getConnection();
			 selectResult=dbUtil.selectQuery(con,query);			 
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtil.closeConnection(con);
		}
		
		//  compare all the zones and count. 
		if(selectResult.get(1).get("Count").equals(getTestObject("zonecount"))){
			
			PerfectoUtils.reportMessage("The user is able to verify Zone Count", MessageTypes.Pass);
		}else {
			PerfectoUtils.reportMessage("The user is unable to verify Zone Count", MessageTypes.Fail);
		}
		
		
	}
	
	
	/**
	* Auto-generated code snippet by QMetry Automation Framework.
	*/
	@QAFTestStep(description="verify city list of All available Cities in DB {0}")
	public void iVerifyCityListPageDisplaysAllNonArchivedCities(String query){
		Connection con=null;
		TreeMap<Integer,HashMap<String,String>> selectResult=null;
		CommonDBUtils dbUtil= new CommonDBUtils();
		List<String> listCityNameActual= (List<String>) getTestObject("CityNameList");
		System.out.println(query);
		try {
			 con=dbUtil.getConnection();
			 selectResult=dbUtil.selectQuery(con,query);			 
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtil.closeConnection(con);
		}
		List<String> listCitynameexpected= new ArrayList<String>();
		
		for (int i=1;i<=selectResult.size();i++) {
			listCitynameexpected.add((selectResult.get(i).get("Name").trim()));
			System.out.println(selectResult.get(i).get("Name"));
		}
		
		if (listCitynameexpected.equals(listCityNameActual)) {
			PerfectoUtils.reportMessage("The user is able to verify Zone Count", MessageTypes.Pass);
		}else {
			PerfectoUtils.reportMessage("The user is unable to verify Zone Count", MessageTypes.Fail);
	}
	
	}
	
	
	
	/**
	* Auto-generated code snippet by QMetry Automation Framework.
	*/
	@QAFTestStep(description="verify a city has zone required for non-archived cities {0}")
	public void iVerifyCityHasZoneAllForNonArchivedCities(String query){
		Connection con=null;
		TreeMap<Integer,HashMap<String,String>> selectResult=null;
		CommonDBUtils dbUtil= new CommonDBUtils();
		
		String str=(String) getTestObject("CityName"); // Please look for zone selected.
		List<String> listZonenameActual= (List<String>) getTestObject("Zonedetails_for_selectedCity");
		System.out.println(query);
		query=query.replace("{City Name}", str);
		System.out.println(query);
		try {
			 con=dbUtil.getConnection();
			 selectResult=dbUtil.selectQuery(con,query);			 
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtil.closeConnection(con);
		}
		List<String> listZonename= new ArrayList<String>();
		
		for (int i=1;i<=selectResult.size();i++) {
			
			
			listZonename.add((selectResult.get(i).get("Zone Name").trim()));
			System.out.println(selectResult.get(i).get("Zone Name"));
		}
		
		if (listZonename.equals(listZonenameActual)) {
			PerfectoUtils.reportMessage("The user is able to verify Zone Count", MessageTypes.Pass);
		}else {
			PerfectoUtils.reportMessage("The user is unable to verify Zone Count", MessageTypes.Fail);
	}
	
	}
	
	@QAFTestStep(description="user validate the zone list for all the cities in DB {0}")
	public void userValidateTheZoneListForAllTheCitiesInDB(String Querry){
		int Rowcount = 1;
		List<String> cityList=new ArrayList<String>();
		SearchResultPage sResult = new SearchResultPage();
		CitySearchResultpage cityResult = new CitySearchResultpage();
		
		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			String CityNameDisplayed = cityResult.getCityNameresult(Rowcount).getText();
			String ZoneDetails = cityResult.getCityZoneresult(Rowcount).getText();
			System.out.println(ZoneDetails);
			List<String> Zonelist = new ArrayList<String>(Arrays.asList(ZoneDetails.split("[\\s]*,[\\s]*")));
			ValidatezoneDetailsforchoosenCity(CityNameDisplayed,Zonelist,Querry);
			
			Rowcount++;
			cityList.add(CityNameDisplayed.trim());
			}
		
	}

	public static void ValidatezoneDetailsforchoosenCity(String CityName , List ZoneList, String Querry) {
		Connection con=null;
		TreeMap<Integer,HashMap<String,String>> selectResult=null;
		CommonDBUtils dbUtil= new CommonDBUtils();
		
		
		List<String> listZonenameActual= (List<String>) getTestObject("Zonedetails_for_selectedCity");
		System.out.println(Querry);
		Querry=Querry.replace("{City Name}", CityName);
		System.out.println(Querry);
		try {
			 con=dbUtil.getConnection();
			 selectResult=dbUtil.selectQuery(con,Querry);			 
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbUtil.closeConnection(con);
		}
		List<String> listZonename= new ArrayList<String>();
		
		for (int i=1;i<=selectResult.size();i++) {
			
			listZonename.add((selectResult.get(i).get("Zone Name").trim()));
			System.out.println(selectResult.get(i).get("Zone Name"));
		}
		
		if (listZonename.equals(listZonenameActual)) {
			PerfectoUtils.reportMessage("The user is able to verify Zone Count", MessageTypes.Pass);
		}else {
			PerfectoUtils.reportMessage("The user is unable to verify Zone Count", MessageTypes.Fail);
	}
	}
	
	
	@QAFTestStep(description = "Verify City page displays valid data for a sample city with query {citynameQuery}")
	public void iVerifyZonePageDisplaysValidDataForASampleCityWithQuery(String citynameQuery) {
		System.out.println(citynameQuery);
		Map<String, String> mapActual = (Map<String, String>) getTestObject("mapActual");
		TreeMap<Integer, HashMap<String, String>> selectResult = null;
		CityDisplayTestPage cDisplay = new CityDisplayTestPage();
		CommonDBUtils dbUtil = new CommonDBUtils();
		System.out.println(citynameQuery);
		citynameQuery = citynameQuery.replace("{City Name}",
				cDisplay.getCitydisplaytxtcityname().getAttribute("value"));
		System.out.println(citynameQuery);
		Connection con = null;
		try {
			con = dbUtil.getConnection();
			selectResult = dbUtil.selectQuery(con, citynameQuery);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbUtil.closeConnection(con);
		}

		for (Map.Entry<String, String> entry : mapActual.entrySet()) {
			System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());

			String expecteddata = selectResult.get(1).get(entry.getKey());

			if (expecteddata.equals(entry.getValue())) {
				System.out.println("The user is able to verify   !!" + entry.getKey() + ": " + entry.getValue());
			} else {
				System.out.println("The user is able to verify   !!" + entry.getKey() + ": " + entry.getValue());
			}

		}
	}

	@QAFTestStep(description = "verify city associated with the zone db validation {0}")
	public void iVerifyCityAssociatedWithTheZoneDbValidation(String query) {
		
	
		
		Connection con=null;
		TreeMap<Integer,HashMap<String,String>> selectResult=null;
		CommonDBUtils dbUtil= new CommonDBUtils();
		
		String str=(String) getTestObject("zoneselected"); // Please look for zone selected.
		String citiesnameActual= (String) getTestObject("actualcity");
		System.out.println(query);
		query=query.replace("{Zone_Name}", str);
		System.out.println(query);
		try {
			 con=dbUtil.getConnection();
			 selectResult=dbUtil.selectQuery(con,query);			 
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtil.closeConnection(con);
		}
		
	
		
		if (citiesnameActual.equals(selectResult.get(1).get("City").trim())) {
			PerfectoUtils.reportMessage("The user is able to verify Zone Count", MessageTypes.Pass);
		}else {
			PerfectoUtils.reportMessage("The user is unable to verify Zone Count", MessageTypes.Fail);
	}
		
		
	}
	
	/**
	* Auto-generated code snippet by QMetry Automation Framework.
	*/
	@QAFTestStep(description="Get inacitve stores associated to the zone {0}")
	public void iVerifyinActiveStoresAssociatedToTheZone(String SQLQuery){
		
		Connection con=null;
		TreeMap<Integer,HashMap<String,String>> selectResult=null;
		CommonDBUtils dbUtil= new CommonDBUtils();
		System.out.println(SQLQuery);		
		try {
			 con=dbUtil.getConnection();
			 selectResult=dbUtil.selectQuery(con,SQLQuery);			 
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtil.closeConnection(con);
		}	
		
		HashMap<String,String> inactiveStroes = new HashMap<String, String>();
		
		inactiveStroes= selectResult.get(1);
		putTestObject("inactiveStores",inactiveStroes);
		
		
	}
	
	
	@QAFTestStep(description="select assigned drivers order id {0}")
	public void sElectAssignedDriversOrderId(String SQLQuery) throws SQLException{
		Connection con=null;
		TreeMap<Integer,HashMap<String,String>> selectResult=null;
		CommonDBUtils dbUtil= new CommonDBUtils();
		
		System.out.println(SQLQuery);
		
		con=dbUtil.getConnection();
		 selectResult=dbUtil.selectQuery(con,SQLQuery);
		 
		 System.out.println(selectResult);
		 
		 List<String> orderId= new ArrayList<String>();
			
			for (int i=1;i<=selectResult.size();i++) {
				
				
				orderId.add((selectResult.get(i).get("coms_id").trim()));
				System.out.println(selectResult.get(i).get("coms_id"));
			}
			String ordId = orderId.get(0);
			putTestObject("SelectedOrderID", ordId);
			System.out.println(ordId);
	}
	
	@QAFTestStep(description="select order information {0}")
	public void sElectOrderInformation(String SQLQuery) throws SQLException{
		Connection con=null;
		TreeMap<Integer,HashMap<String,String>> selectResult=null;
		CommonDBUtils dbUtil= new CommonDBUtils();
		
		System.out.println(SQLQuery);
		
		con=dbUtil.getConnection();
		 selectResult=dbUtil.selectQuery(con,SQLQuery);
		 
		 System.out.println(selectResult);
		 
		 List<String> orderId= new ArrayList<String>();
			
			for (int i=1;i<=selectResult.size();i++) {
				
				
				orderId.add((selectResult.get(i).get("coms_id").trim()));
				orderId.add((selectResult.get(i).get("first_name").trim()));
				orderId.add((selectResult.get(i).get("last_name").trim()));
				break;
			}
			String ordId = orderId.get(0);
			String firstName = orderId.get(1);
			String lastName = orderId.get(2);
			putTestObject("SelectedOrderID", ordId);
			putTestObject("FirstName", firstName);
			putTestObject("LastName", lastName);
			System.out.println(ordId);
			System.out.println(firstName);
			System.out.println(lastName);	 
	}
	
	@QAFTestStep(description="select customer information {0}")
	public void sElectCustomerInformation(String SQLQuery) throws SQLException{
		Connection con=null;
		TreeMap<Integer,HashMap<String,String>> selectResult=null;
		CommonDBUtils dbUtil= new CommonDBUtils();
		
		System.out.println(SQLQuery);	
		String ordId = getTestString("SelectedOrderID");	
		SQLQuery = SQLQuery.replace("{order id}", ordId);
		System.out.println(SQLQuery);
		
		con=dbUtil.getConnection();
		 selectResult=dbUtil.selectQuery(con,SQLQuery);
		 
		 System.out.println(selectResult);
		 
		 List<String> address= new ArrayList<String>();
			
			for (int i=1;i<=selectResult.size();i++) {
				
				
				address.add((selectResult.get(i).get("line_1").trim()));
				address.add((selectResult.get(i).get("address_line2").trim()));
				address.add((selectResult.get(i).get("city").trim()));
				address.add((selectResult.get(i).get("last_name").trim()));
				address.add((selectResult.get(i).get("state").trim()));
				address.add((selectResult.get(i).get("first_name").trim()));
				address.add((selectResult.get(i).get("zip_code").trim()));
				address.add((selectResult.get(i).get("email").trim()));
				address.add((selectResult.get(i).get("phone").trim()));
				break;
			}
			String line1 = address.get(0);
			String line2 = address.get(1);
			String city = address.get(2);
			String lastName = address.get(3);
			String state = address.get(4);
			String firstName = address.get(5);
			String zipCode = address.get(6);
			String eMail = address.get(7);
			String pHone = address.get(8);
			
			putTestObject("addressLine1", line1);
			putTestObject("addressLine2", line2);
			putTestObject("City", city);
			putTestObject("LastName", lastName);
			putTestObject("State", state);
			putTestObject("FirstName", firstName);
			putTestObject("ZipCode", zipCode);
			putTestObject("Email", eMail);
			putTestObject("Phone", pHone);	
	}
	
	@QAFTestStep(description="select customer details {0}")
	public void sElectCustomerDetails(String SQLQuery) throws SQLException{
		Connection con=null;
		TreeMap<Integer,HashMap<String,String>> selectResult=null;
		CommonDBUtils dbUtil= new CommonDBUtils();
		
		System.out.println(SQLQuery);	
		String ordId = getTestString("SelectedOrderID");	
		SQLQuery = SQLQuery.replace("{order id}", ordId);
		System.out.println(SQLQuery);
		
		con=dbUtil.getConnection();
		 selectResult=dbUtil.selectQuery(con,SQLQuery);
		 
		 System.out.println(selectResult);
		 
		 List<String> address= new ArrayList<String>();
			
			for (int i=1;i<=selectResult.size();i++) {
						
				address.add((selectResult.get(i).get("phone").trim()));
				address.add((selectResult.get(i).get("name").trim()));
				break;
			}	
			String phone = address.get(0);
			String name = address.get(1);
			
			putTestObject("Phone", phone);
			putTestObject("Name", name);
	}
	
	@QAFTestStep(description="select all current day orders {0}")
	public void selectAllCurrentDayOrders(String SQLQuery) throws SQLException{
		Connection con=null;
		TreeMap<Integer,HashMap<String,String>> selectResult=null;
		CommonDBUtils dbUtil= new CommonDBUtils();
		
		System.out.println(SQLQuery);	
		String currDate = getTestString("CurrentDateSQL");	
		String currDatePlusOne = getTestString("CurrentDatePlusOneSQL");	
		SQLQuery = SQLQuery.replace("{currdate}", currDate);
		SQLQuery = SQLQuery.replace("{currdateEndDate}", currDatePlusOne);
		SQLQuery = SQLQuery.replace("=>", "<=");
		System.out.println(SQLQuery);
		
		con=dbUtil.getConnection();
		selectResult=dbUtil.selectQuery(con,SQLQuery);
		System.out.println(selectResult);
		putTestObject("currentDayTotalOrdersSQL", selectResult.get(1).get("count(*)"));
	}
	
/*	@QAFTestStep(description="Update to Archives {0}")
	public void updatetoArchives(String SQLQuery) throws SQLException{
		Connection con=null;
		TreeMap<Integer,HashMap<String,String>> selectResult=null;
		CommonDBUtils dbUtil= new CommonDBUtils();
		
		System.out.println(SQLQuery);	
		
		con=dbUtil.getConnection();
		selectResult=dbUtil.selectQuery(con,SQLQuery);
		System.out.println(selectResult);
	}*/
	
	@QAFTestStep(description="Update to Archives {0}")
	public void updatetoArchives(String SQLQuery) throws SQLException{
		Connection con=null;
		int updateResult=0;
		CommonDBUtils dbUtil= new CommonDBUtils();
		
		System.out.println(SQLQuery);	
		
		con=dbUtil.getConnection();
		updateResult=dbUtil.updateQuery(con,SQLQuery);
		System.out.println(updateResult + " rows updated by query");
	}
	
	@QAFTestStep(description="Insert new entity {0}")
	public void insertNewEntity(String SQLQuery) throws SQLException{
		Connection con=null;
		int updateResult=0;
		CommonDBUtils dbUtil= new CommonDBUtils();
		
		System.out.println(SQLQuery);	
		
		con=dbUtil.getConnection();
		updateResult=dbUtil.updateQuery(con,SQLQuery);
		System.out.println(updateResult + " rows updated by query");
		
	}
	
	@QAFTestStep(description="Retrieve details of db entity {0}")
	public void retrieveDetailsOfDBEntity(String SQLQuery) throws SQLException{
		Connection con=null;
		TreeMap<Integer,HashMap<String,String>> selectResult=null;
		CommonDBUtils dbUtil= new CommonDBUtils();
		
		System.out.println(SQLQuery);	
		
		con=dbUtil.getConnection();
		selectResult=dbUtil.selectQuery(con,SQLQuery);
		System.out.println(selectResult);
		
		//putTestObject("ShiftID", ShiftID);
	}
	
}
