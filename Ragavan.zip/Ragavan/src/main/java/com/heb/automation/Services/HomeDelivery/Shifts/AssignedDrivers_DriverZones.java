package com.heb.automation.Services.HomeDelivery.Shifts;

public class AssignedDrivers_DriverZones {
	
	private String lastModifiedTimestamp;

    private String primary;

    private AssignedDrivers_DriverZones_Zone zone;

    public String getLastModifiedTimestamp ()
    {
        return lastModifiedTimestamp;
    }

    public void setLastModifiedTimestamp (String lastModifiedTimestamp)
    {
        this.lastModifiedTimestamp = lastModifiedTimestamp;
    }

    public String getPrimary ()
    {
        return primary;
    }

    public void setPrimary (String primary)
    {
        this.primary = primary;
    }

    public AssignedDrivers_DriverZones_Zone getZone ()
    {
        return zone;
    }

    public void setZone (AssignedDrivers_DriverZones_Zone zone)
    {
        this.zone = zone;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [lastModifiedTimestamp = "+lastModifiedTimestamp+", primary = "+primary+", zone = "+zone+"]";
    }

}
