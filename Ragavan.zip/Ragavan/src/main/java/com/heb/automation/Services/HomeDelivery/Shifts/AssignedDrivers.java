package com.heb.automation.Services.HomeDelivery.Shifts;

import java.util.ArrayList;

public class AssignedDrivers {
	
	private String licenseExpirationDate;

    private String lastModifiedTimestamp;

    private String phone;

    private ArrayList<AssignedDrivers_Timesheets> timesheets;

    private String allowSms;

    private String id;

    private String hearingStatus;

    private String lastLoginTimestamp;

    private String role;

    private ArrayList<AssignedDrivers_DriverZones> driverZones;

    private String firstName;

    private String lastName;

    private String rapidPayAccountNumber;

    private int completedOrderCount;

    private int rejectedOrderCount;

    private String status;

    private int averageCustomerRating;

    private String profilePicture;

    private String driversLicenseActive;

    private String externalOnfleetId;

    private String email;

    private String allowEmail;

    private String alcoholEligible;

    private String vehicleType;

    private String fountainStage;

    private int onTimeOrderCount;

    public String getLicenseExpirationDate ()
    {
        return licenseExpirationDate;
    }

    public void setLicenseExpirationDate (String licenseExpirationDate)
    {
        this.licenseExpirationDate = licenseExpirationDate;
    }

    public String getLastModifiedTimestamp ()
    {
        return lastModifiedTimestamp;
    }

    public void setLastModifiedTimestamp (String lastModifiedTimestamp)
    {
        this.lastModifiedTimestamp = lastModifiedTimestamp;
    }

    public String getPhone ()
    {
        return phone;
    }

    public void setPhone (String phone)
    {
        this.phone = phone;
    }

    public ArrayList<AssignedDrivers_Timesheets> getTimesheets ()
    {
        return timesheets;
    }

    public void setTimesheets (ArrayList<AssignedDrivers_Timesheets> timesheets)
    {
        this.timesheets = timesheets;
    }

    public String getAllowSms ()
    {
        return allowSms;
    }

    public void setAllowSms (String allowSms)
    {
        this.allowSms = allowSms;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getHearingStatus ()
    {
        return hearingStatus;
    }

    public void setHearingStatus (String hearingStatus)
    {
        this.hearingStatus = hearingStatus;
    }

    public String getLastLoginTimestamp ()
    {
        return lastLoginTimestamp;
    }

    public void setLastLoginTimestamp (String lastLoginTimestamp)
    {
        this.lastLoginTimestamp = lastLoginTimestamp;
    }

    public String getRole ()
    {
        return role;
    }

    public void setRole (String role)
    {
        this.role = role;
    }

    public ArrayList<AssignedDrivers_DriverZones> getDriverZones ()
    {
        return driverZones;
    }

    public void setDriverZones (ArrayList<AssignedDrivers_DriverZones> driverZones)
    {
        this.driverZones = driverZones;
    }

    public String getFirstName ()
    {
        return firstName;
    }

    public void setFirstName (String firstName)
    {
        this.firstName = firstName;
    }

    public String getLastName ()
    {
        return lastName;
    }

    public void setLastName (String lastName)
    {
        this.lastName = lastName;
    }

    public String getRapidPayAccountNumber ()
    {
        return rapidPayAccountNumber;
    }

    public void setRapidPayAccountNumber (String rapidPayAccountNumber)
    {
        this.rapidPayAccountNumber = rapidPayAccountNumber;
    }

    public int getCompletedOrderCount ()
    {
        return completedOrderCount;
    }

    public void setCompletedOrderCount (int completedOrderCount)
    {
        this.completedOrderCount = completedOrderCount;
    }

    public int getRejectedOrderCount ()
    {
        return rejectedOrderCount;
    }

    public void setRejectedOrderCount (int rejectedOrderCount)
    {
        this.rejectedOrderCount = rejectedOrderCount;
    }

    public String getStatus ()
    {
        return status;
    }

    public void setStatus (String status)
    {
        this.status = status;
    }

    public int getAverageCustomerRating ()
    {
        return averageCustomerRating;
    }

    public void setAverageCustomerRating (int averageCustomerRating)
    {
        this.averageCustomerRating = averageCustomerRating;
    }

    public String getProfilePicture ()
    {
        return profilePicture;
    }

    public void setProfilePicture (String profilePicture)
    {
        this.profilePicture = profilePicture;
    }

    public String getDriversLicenseActive ()
    {
        return driversLicenseActive;
    }

    public void setDriversLicenseActive (String driversLicenseActive)
    {
        this.driversLicenseActive = driversLicenseActive;
    }

    public String getExternalOnfleetId ()
    {
        return externalOnfleetId;
    }

    public void setExternalOnfleetId (String externalOnfleetId)
    {
        this.externalOnfleetId = externalOnfleetId;
    }

    public String getEmail ()
    {
        return email;
    }

    public void setEmail (String email)
    {
        this.email = email;
    }

    public String getAllowEmail ()
    {
        return allowEmail;
    }

    public void setAllowEmail (String allowEmail)
    {
        this.allowEmail = allowEmail;
    }

    public String getAlcoholEligible ()
    {
        return alcoholEligible;
    }

    public void setAlcoholEligible (String alcoholEligible)
    {
        this.alcoholEligible = alcoholEligible;
    }

    public String getVehicleType ()
    {
        return vehicleType;
    }

    public void setVehicleType (String vehicleType)
    {
        this.vehicleType = vehicleType;
    }

    public String getFountainStage ()
    {
        return fountainStage;
    }

    public void setFountainStage (String fountainStage)
    {
        this.fountainStage = fountainStage;
    }

    public int getOnTimeOrderCount ()
    {
        return onTimeOrderCount;
    }

    public void setOnTimeOrderCount (int onTimeOrderCount)
    {
        this.onTimeOrderCount = onTimeOrderCount;
    }

}
