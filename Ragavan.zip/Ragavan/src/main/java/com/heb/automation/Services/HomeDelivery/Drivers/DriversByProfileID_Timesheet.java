package com.heb.automation.Services.HomeDelivery.Drivers;

public class DriversByProfileID_Timesheet
{
	private String lastModifiedTimestamp;

    private int id;

    private String startTime;

    private String endTime;

    private boolean archived;

    private String driverName;

    private int driverId;

    public void setLastModifiedTimestamp(String lastModifiedTimestamp){
        this.lastModifiedTimestamp = lastModifiedTimestamp;
    }
    public String getLastModifiedTimestamp(){
        return this.lastModifiedTimestamp;
    }
    public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return this.id;
    }
    public void setStartTime(String startTime){
        this.startTime = startTime;
    }
    public String getStartTime(){
        return this.startTime;
    }
    public void setEndTime(String endTime){
        this.endTime = endTime;
    }
    public String getEndTime(){
        return this.endTime;
    }
    public void setArchived(boolean archived){
        this.archived = archived;
    }
    public boolean getArchived(){
        return this.archived;
    }
    public void setDriverName(String driverName){
        this.driverName = driverName;
    }
    public String getDriverName(){
        return this.driverName;
    }
    public void setDriverId(int driverId){
        this.driverId = driverId;
    }
    public int getDriverId(){
        return this.driverId;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [startTime = "+startTime+", id = "+id+", lastModifiedTimestamp = "+lastModifiedTimestamp+", archived = "+archived+", driverId = "+driverId+", endTime = "+endTime+", driverName = "+driverName+"]";
    }
}