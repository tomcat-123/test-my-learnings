package com.heb.automation.Pages.HD_WebApp.order;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class OrderEditTestPage extends WebDriverBaseTestPage<WebDriverTestPage>{

	@FindBy (locator="orderedit.txt.deliverystart")
	private QAFWebElement orderedittxtdeliverystart;
	
	@FindBy (locator="orderedit.txt.deliveryend")
	private QAFWebElement orderedittxtdeliveryend;
	
	@FindBy (locator="orderedit.txt.orderstatus")
	private QAFWebElement orderedittxtorderstatus;
	
	@FindBy (locator="orderedit.txt.adminnotes")
	private QAFWebElement orderedittxtadminnotes;
	
	@FindBy (locator="orderedit.txt.ordernotes")
	private QAFWebElement orderedittxtordernotes;
	 
	@FindBy (locator="orderedit.btn.yessignaturerequired")
	private QAFWebElement ordereditbtnyessignaturerequired;
	
	@FindBy (locator="orderedit.btn.nosignaturerequired")
	private QAFWebElement ordereditbtnnosignaturerequired;
	
	@FindBy (locator="orderedit.lbl.signaturerequiredcurrentvalue")
	private QAFWebElement ordereditlblsignaturerequiredcurrentvalue;
	
	@FindBy (locator="orderedit.btn.yeshasalcohol")
	private QAFWebElement ordereditbtnyeshasalcohol;
	 
	@FindBy (locator="orderedit.btn.nohasalcohol")
	private QAFWebElement ordereditbtnnohasalcohol;
	
	@FindBy (locator="orderedit.lbl.hasalcoholcurrentvalue")
	private QAFWebElement ordereditlblhasalcoholcurrentvalue;
	
	@FindBy (locator="orderedit.btn.cancel")
	private QAFWebElement ordereditbtncancel;
	
	@FindBy (locator="orderedit.btn.save")
	private QAFWebElement ordereditbtnsave;
	 
	
	public QAFWebElement getTxtDeliveryStart() {
		return orderedittxtdeliverystart;
	}

	public QAFWebElement getTxtDeliveryEnd() {
		return orderedittxtdeliveryend;
	}

	public QAFWebElement getTxtOrderStatus() {
		return orderedittxtorderstatus;
	}

	public QAFWebElement getTxtAdminNotes() {
		return orderedittxtadminnotes;
	}

	public QAFWebElement getTxtOrderNotes() {
		return orderedittxtordernotes;
	}

	public QAFWebElement getbtnyessignaturerequired() {
		return ordereditbtnyessignaturerequired;
	}

	public QAFWebElement getBtnNoSignatureRequired() {
		return ordereditbtnnosignaturerequired;
	}

	public QAFWebElement getLblSignatureRequiredCurrentValue() {
		return ordereditlblsignaturerequiredcurrentvalue;
	}

	public QAFWebElement getBtnYesHasAlcohol() {
		return ordereditbtnyeshasalcohol;
	}

	public QAFWebElement getBtnNoHasAlcohol() {
		return ordereditbtnnohasalcohol;
	}

	public QAFWebElement getLblHasAlcoholCurrentValue() {
		return ordereditlblhasalcoholcurrentvalue;
	}
	
	public QAFWebElement getBtnCancel() {
		return ordereditbtncancel;
	}
	
	public QAFWebElement getBtnSave() {
		return ordereditbtnsave;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}

}
