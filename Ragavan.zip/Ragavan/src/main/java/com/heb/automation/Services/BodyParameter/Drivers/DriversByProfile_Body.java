package com.heb.automation.Services.BodyParameter.Drivers;

public class DriversByProfile_Body {
	
	private String firstName;

    private String lastName;

    private boolean allowSms;

    private boolean allowEmail;

    public String getFirstName ()
    {
        return firstName;
    }

    public void setFirstName (String firstName)
    {
        this.firstName = firstName;
    }

    public String getLastName ()
    {
        return lastName;
    }

    public void setLastName (String lastName)
    {
        this.lastName = lastName;
    }

    public boolean getAllowSms()
    {
        return allowSms;
    }

    public void setAllowSms (boolean allowSms)
    {
        this.allowSms = allowSms;
    }

    public boolean getAllowEmail ()
    {
        return allowEmail;
    }

    public void setAllowEmail (boolean allowEmail)
    {
        this.allowEmail = allowEmail;
    }

}
