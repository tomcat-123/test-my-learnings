package com.heb.automation.Services.HomeDelivery;

import com.heb.automation.common.TestDataContainer;

import org.testng.Assert;

import com.google.gson.Gson;
import com.heb.automation.ErrorMessages.ErrorMessage;
import com.heb.automation.ErrorMessages.Errors;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class CommonUtils extends TestDataContainer {

	public static void buildURL(String resource, String baseurl) {

		putTestObject("resource", resource);
		putTestObject("env.baseurl", baseurl);
		System.out.println("URL is "+ getTestObject("env.baseurl")+getTestObject("resource"));
		Reporter.log("URL is "+ getTestObject("env.baseurl")+getTestObject("resource"));

	}
	
	public static void emptyArrayBodyParameter() {
		
		String BodyParameter = "[]";
		putTestObject("BodyParameter", BodyParameter);
		
	}
	
public static void emptyJsonBodyParameter() {
		
		String BodyParameter = "{}";
		putTestObject("BodyParameter", BodyParameter);
		
	}
	
	public static void invalidArrayBodyParameter() {
		String BodyParameterValue = "[\"ares63\", \"ares64\", \"ares65\",]";
		Reporter.log(BodyParameterValue);
		putTestObject("BodyParameter", BodyParameterValue);
	}
	
	public static void invalidJsonBodyParameter() {
		String BodyParameterValue = "{ \"serviceDescriptionId\": 656	,}";
		putTestObject("BodyParameter", BodyParameterValue);
	}
	
	public static void getAllStatusupdates(ClientResponse rCLient) {

		Reporter.log("Get Status is : " + rCLient.getStatus());
		Reporter.log("Get StatusInfo is : " + rCLient.getStatusInfo());
		Reporter.log("Get Type is : " + rCLient.getType());
		
		System.out.println("Get Status is : " + rCLient.getStatus());
		System.out.println("Get StatusInfo is : " + rCLient.getStatusInfo());
		System.out.println("Get Type is : " + rCLient.getType());

	}
	
	@QAFTestStep(description="validate the response")
	public void validateTheResponse(){
		ClientResponse rClient = (ClientResponse) getTestObject("rClient");
		CommonUtils.getAllStatusupdates(rClient);
	}
	
	@QAFTestStep(description="Validate the Error Response{0}")
	public void validateTheErrorResponse(String errorCode){
		
		try {
		ClientResponse rClient = (ClientResponse) getTestObject("rClient");
		CommonUtils.getAllStatusupdates(rClient);
		Assert.assertEquals(rClient.getStatus(),errorCode);
		
		} catch (Exception e) {
			Reporter.log("Exceptions :"+e);
		}
	
	}
}
