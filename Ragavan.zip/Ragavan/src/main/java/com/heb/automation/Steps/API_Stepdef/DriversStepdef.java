package com.heb.automation.Steps.API_Stepdef;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.heb.automation.ErrorMessages.ErrorMessage;
import com.heb.automation.Services.BodyParameter.Drivers.Driver_Post;
import com.heb.automation.Services.BodyParameter.Drivers.DriversByProfile_Body;
import com.heb.automation.Services.BodyParameter.Drivers.Drivers_Body;
import com.heb.automation.Services.BodyParameter.Drivers.Vehicles_Body;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_Success;
import com.heb.automation.Services.HomeDelivery.ServiceUtils;
import com.heb.automation.Services.HomeDelivery.Drivers.DriversByProfileID_RootObject;
import com.heb.automation.Services.HomeDelivery.Drivers.Drivers_Post;
import com.heb.automation.Services.HomeDelivery.Drivers.Drivers_RootObject;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class DriversStepdef extends TestDataContainer {

	@QAFTestStep(description = "Build URL for read HomeDelivery drivers using location")
	public void buildURLForReadHomeDeliverDriversUsingLocation() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		// String resource =
		// getTestString("HomeDelivery.endpoint.getLocation");
		String resource = "/pronto_api/of/worker/location?longitude=-98.4975345&latitude=29.4184891&radius=6000";
		CommonUtils.buildURL(resource, baseurl);

	}

	@QAFTestStep(description = "Build URL for read HomeDelivery driver using driverID")
	public void buildURLForReadHomeDeliverDriversUsingDriverID() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getDrivers") + "/"
				+ getTestString("DriverID");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for read HomeDelivery Off drivers using driverBystate")
	public void buildURLForReadHomeDeliverOffDriversUsingDriverByState() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getOffDrivers");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for read HomeDelivery On drivers using driverBystate")
	public void buildURLForReadHomeDeliverOnDriversUsingDriverByState() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getOnDrivers");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for Creating HomeDelivery Driver")
	public void buildURLForCreatingHomeDeliveryDriver() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getDrivers");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for Delete HomeDelivery Driver")
	public void buildURLForDeleteHomeDeliveryDriver() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getDrivers") + "/"
				+ getTestString("DriverID");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for Delet HomeDelivery Driver With invalidID")
	public void buildURLForDeletHomeDeliveryDriverWithInvalidID() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getDrivers") + "/12345678910";
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for read HomeDelivery drivers using profileByID")
	public void buildURLForReadHomeDeliveryDriversUsingprofileByID() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getProfileByID")+getTestString("HomeDelivery.driverprofileID");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for Updating HomeDelivery drivers using profileByID")
	public void buildURLforUpdatingHomeDeliverydriversusingprofileByID() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getProfileByID")+getTestString("HomeDelivery.driverprofileIDUpdate");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for creating HomeDelivery Driver")
	public void userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryDriver() throws JsonProcessingException {

		Drivers_Body pr = new Drivers_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setId(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setOrganization(null);
		pr.setName(getName());
		pr.setPhone(generateRandom());
		pr.setActiveTask(null);

		List<String> tsk = new ArrayList<String>();
		pr.setTasks(tsk);

		pr.setOnDuty(null);
		pr.setTimeLastSeen(null);
		pr.setDelayTime(null);

		List<String> team = new ArrayList<String>();
		team.add(getTestString("TeamID"));
		pr.setTeams(team);

		List<String> mData = new ArrayList<String>();
		pr.setMetadata(mData);

		Vehicles_Body vehicles = new Vehicles_Body();
		vehicles.setId(null);
		vehicles.setType("CAR");
		vehicles.setColor("black");
		vehicles.setDescription("Coupe");
		vehicles.setLicensePlate("FFJ 7892");
		pr.setVehicle(vehicles);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Some Missing Mandatory Body Parameter for creating HomeDelivery Driver")
	public void userUsesAnArrayOfSomeMissingMandatoryBodyParameterForCreatingHomeDeliveryDriver()
			throws JsonProcessingException {

		Drivers_Body pr = new Drivers_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setId(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setOrganization(null);
		pr.setName(getName());
		pr.setPhone("");
		pr.setActiveTask(null);

		List<String> tsk = new ArrayList<String>();
		pr.setTasks(tsk);

		pr.setOnDuty(null);
		pr.setTimeLastSeen(null);
		pr.setDelayTime(null);

		List<String> team = new ArrayList<String>();
		team.add("");
		pr.setTeams(team);

		List<String> mData = new ArrayList<String>();
		pr.setMetadata(mData);

		Vehicles_Body vehicles = new Vehicles_Body();
		vehicles.setId(null);
		vehicles.setType("CAR");
		vehicles.setColor("black");
		vehicles.setDescription("Coupe");
		vehicles.setLicensePlate("FFJ 7892");
		pr.setVehicle(vehicles);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of all Missing Mandatory Body Parameter for creating HomeDelivery Driver")
	public void userUsesAnArrayOfallMissingMandatoryBodyParameterForCreatingHomeDeliveryDriver()
			throws JsonProcessingException {

		Drivers_Body pr = new Drivers_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setId(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setOrganization(null);
		pr.setName(null);
		pr.setPhone(null);
		pr.setActiveTask(null);

		List<String> tsk = new ArrayList<String>();
		pr.setTasks(tsk);

		pr.setOnDuty(null);
		pr.setTimeLastSeen(null);
		pr.setDelayTime(null);

		List<String> team = new ArrayList<String>();
		team.add(null);
		pr.setTeams(team);

		List<String> mData = new ArrayList<String>();
		pr.setMetadata(mData);

		Vehicles_Body vehicles = new Vehicles_Body();
		vehicles.setId(null);
		vehicles.setType("CAR");
		vehicles.setColor("black");
		vehicles.setDescription("Coupe");
		vehicles.setLicensePlate("FFJ 7892");
		pr.setVehicle(vehicles);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of existing Body Parameter for creating HomeDelivery Driver")
	public void userUsesAnArrayOfExistingBodyParameterForCreatingHomeDeliveryDriver() throws JsonProcessingException {

		Drivers_Body pr = new Drivers_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setId(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setOrganization(null);
		pr.setName(getName());
		String phNum = (getTestString("PhoneNum").replace("+1", ""));
		pr.setPhone(phNum);
		pr.setActiveTask(null);

		List<String> tsk = new ArrayList<String>();
		pr.setTasks(tsk);

		pr.setOnDuty(null);
		pr.setTimeLastSeen(null);
		pr.setDelayTime(null);

		List<String> team = new ArrayList<String>();
		team.add(getTestString("TeamID"));
		pr.setTeams(team);

		List<String> mData = new ArrayList<String>();
		pr.setMetadata(mData);

		Vehicles_Body vehicles = new Vehicles_Body();
		vehicles.setId(null);
		vehicles.setType("CAR");
		vehicles.setColor("black");
		vehicles.setDescription("Coupe");
		vehicles.setLicensePlate("FFJ 7892");
		pr.setVehicle(vehicles);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of invalid VehicleType Body Parameter for creating HomeDelivery Driver")
	public void userUsesAnArrayOfInvalidVehicleTypeBodyParameterForCreatingHomeDeliveryDriver()
			throws JsonProcessingException {

		Drivers_Body pr = new Drivers_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setId(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setOrganization(null);
		pr.setName(getName());
		pr.setPhone(generateRandom());
		pr.setActiveTask(null);

		List<String> tsk = new ArrayList<String>();
		pr.setTasks(tsk);

		pr.setOnDuty(null);
		pr.setTimeLastSeen(null);
		pr.setDelayTime(null);

		List<String> team = new ArrayList<String>();
		team.add(getTestString("TeamID"));
		pr.setTeams(team);

		List<String> mData = new ArrayList<String>();
		pr.setMetadata(mData);

		Vehicles_Body vehicles = new Vehicles_Body();
		vehicles.setId(null);
		vehicles.setType("BUS");
		vehicles.setColor("black");
		vehicles.setDescription("Coupe");
		vehicles.setLicensePlate("FFJ 7892");
		pr.setVehicle(vehicles);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of invalid TeamID Body Parameter for creating HomeDelivery Driver")
	public void userUsesAnArrayOfInvalidTeamIDBodyParameterForCreatingHomeDeliveryDriver()
			throws JsonProcessingException {

		Drivers_Body pr = new Drivers_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setId(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setOrganization(null);
		pr.setName(getName());
		pr.setPhone(generateRandom());
		pr.setActiveTask(null);

		List<String> tsk = new ArrayList<String>();
		pr.setTasks(tsk);

		pr.setOnDuty(null);
		pr.setTimeLastSeen(null);
		pr.setDelayTime(null);

		List<String> team = new ArrayList<String>();
		team.add("12345678910");
		pr.setTeams(team);

		List<String> mData = new ArrayList<String>();
		pr.setMetadata(mData);

		Vehicles_Body vehicles = new Vehicles_Body();
		vehicles.setId(null);
		vehicles.setType("CAR");
		vehicles.setColor("black");
		vehicles.setDescription("Coupe");
		vehicles.setLicensePlate("FFJ 7892");
		pr.setVehicle(vehicles);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses Body Parameter with More than 101character name for creating HomeDelivery Driver")
	public void userUsesBodyParameterWithMoreThan101CharacterNameForCreatingHomeDeliveryDriver()
			throws JsonProcessingException {

		Drivers_Body pr = new Drivers_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setId(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setOrganization(null);
		pr.setName(getNameMoreThan101Characters());
		pr.setPhone(generateRandom());
		pr.setActiveTask(null);

		List<String> tsk = new ArrayList<String>();
		pr.setTasks(tsk);

		pr.setOnDuty(null);
		pr.setTimeLastSeen(null);
		pr.setDelayTime(null);

		List<String> team = new ArrayList<String>();
		team.add(getTestString("TeamID"));
		pr.setTeams(team);

		List<String> mData = new ArrayList<String>();
		pr.setMetadata(mData);

		Vehicles_Body vehicles = new Vehicles_Body();
		vehicles.setId(null);
		vehicles.setType("CAR");
		vehicles.setColor("black");
		vehicles.setDescription("Coupe");
		vehicles.setLicensePlate("FFJ 7892");
		pr.setVehicle(vehicles);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses Body Parameter with invalid phone number format for creating HomeDelivery Driver")
	public void userUsesBodyParameterWithInvalidPhoneNumberFormatForCreatingHomeDeliveryDriver()
			throws JsonProcessingException {

		Drivers_Body pr = new Drivers_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setId(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setOrganization(null);
		pr.setName(getName());
		pr.setPhone(generateRandomInvalidFormat());
		pr.setActiveTask(null);

		List<String> tsk = new ArrayList<String>();
		pr.setTasks(tsk);

		pr.setOnDuty(null);
		pr.setTimeLastSeen(null);
		pr.setDelayTime(null);

		List<String> team = new ArrayList<String>();
		team.add(getTestString("TeamID"));
		pr.setTeams(team);

		List<String> mData = new ArrayList<String>();
		pr.setMetadata(mData);

		Vehicles_Body vehicles = new Vehicles_Body();
		vehicles.setId(null);
		vehicles.setType("CAR");
		vehicles.setColor("black");
		vehicles.setDescription("Coupe");
		vehicles.setLicensePlate("FFJ 7892");
		pr.setVehicle(vehicles);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Driver body parameter contains all valid editable fields")
	public void userUPDATEHomeDeliveryDriverBodyParameterContainsAllValidEditableFields()
			throws JsonProcessingException {

		Drivers_Body pr = new Drivers_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setId(getTestString("DriverID"));
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setOrganization(null);
		pr.setName(getName());
		String phNum = (getTestString("PhoneNum").replace("+1", ""));
		pr.setPhone(phNum);
		pr.setActiveTask(null);

		List<String> tsk = new ArrayList<String>();
		pr.setTasks(tsk);

		pr.setOnDuty(null);
		pr.setTimeLastSeen(null);
		pr.setDelayTime(null);

		List<String> team = new ArrayList<String>();
		team.add(getTestString("TeamID"));
		pr.setTeams(team);

		List<String> mData = new ArrayList<String>();
		pr.setMetadata(mData);

		Vehicles_Body vehicles = new Vehicles_Body();
		vehicles.setId(null);
		vehicles.setType("CAR");
		vehicles.setColor("black");
		vehicles.setDescription("Coupe");
		vehicles.setLicensePlate("FFJ 7892");
		pr.setVehicle(vehicles);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User UPDATE HomeDelivery Driver profile body parameter with all mandatory and optional fields")
	public void userUPDATEHomeDeliveryDriverProfileBodyParameterwithAllMandatoryAndOptionalFields()
			throws JsonProcessingException {

		DriversByProfile_Body pr = new DriversByProfile_Body();
		ObjectMapper objm = new ObjectMapper();
		
		String firstName = "QA"+PerfectoUtils.randomAlphabets(5);
		pr.setFirstName(firstName);
		putTestObject("Updated_DriverFirstName", firstName);
		String lastName = "QA"+PerfectoUtils.randomAlphabets(4);
		pr.setLastName(lastName);
		putTestObject("Updated_DriverLastName", lastName);
		pr.setAllowSms(Boolean.valueOf(ConfigurationManager.getBundle().getString("HomeDelivery.driverByProfile.allowSMS")));
		pr.setAllowEmail(Boolean.valueOf(ConfigurationManager.getBundle().getString("HomeDelivery.driverByProfile.allowEmail")));
		
		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Driver body parameter With Some Mandatory Fields Missing")
	public void userUPDATEHomeDeliveryDriverBodyParameterWithSomeMandatoryFieldsMissing()
			throws JsonProcessingException {

		Drivers_Body pr = new Drivers_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setId(getTestString("DriverID"));
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setOrganization(null);
		pr.setName("");
		pr.setPhone("");
		pr.setActiveTask(null);

		List<String> tsk = new ArrayList<String>();
		pr.setTasks(tsk);

		pr.setOnDuty(null);
		pr.setTimeLastSeen(null);
		pr.setDelayTime(null);

		List<String> team = new ArrayList<String>();
		team.add(getTestString("TeamID"));
		pr.setTeams(team);

		List<String> mData = new ArrayList<String>();
		pr.setMetadata(mData);

		Vehicles_Body vehicles = new Vehicles_Body();
		vehicles.setId(null);
		vehicles.setType("CAR");
		vehicles.setColor("black");
		vehicles.setDescription("Coupe");
		vehicles.setLicensePlate("FFJ 7892");
		pr.setVehicle(vehicles);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Driver body parameter With all Mandatory Fields Missing")
	public void userUPDATEHomeDeliveryDriverBodyParameterWithAllMandatoryFieldsMissing()
			throws JsonProcessingException {

		Drivers_Body pr = new Drivers_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setId("");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setOrganization(null);
		pr.setName("");
		pr.setPhone("");
		pr.setActiveTask(null);

		List<String> tsk = new ArrayList<String>();
		pr.setTasks(tsk);

		pr.setOnDuty(null);
		pr.setTimeLastSeen(null);
		pr.setDelayTime(null);

		List<String> team = new ArrayList<String>();
		team.add("");
		pr.setTeams(team);

		List<String> mData = new ArrayList<String>();
		pr.setMetadata(mData);

		Vehicles_Body vehicles = new Vehicles_Body();
		vehicles.setId(null);
		vehicles.setType("CAR");
		vehicles.setColor("black");
		vehicles.setDescription("Coupe");
		vehicles.setLicensePlate("FFJ 7892");
		pr.setVehicle(vehicles);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Driver body parameter with existing phoneNumber")
	public void userUPDATEHomeDeliveryDriverBodyParameterWithExistingPhoneNumber() throws JsonProcessingException {

		Drivers_Body pr = new Drivers_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setId(getTestString("DriverID"));
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setOrganization(null);
		pr.setName(getName());
		String phNum = (getTestString("PhoneNum").replace("+1", ""));
		pr.setPhone(phNum);
		pr.setActiveTask(null);

		List<String> tsk = new ArrayList<String>();
		pr.setTasks(tsk);

		pr.setOnDuty(null);
		pr.setTimeLastSeen(null);
		pr.setDelayTime(null);

		List<String> team = new ArrayList<String>();
		team.add(getTestString("TeamID"));
		pr.setTeams(team);

		List<String> mData = new ArrayList<String>();
		pr.setMetadata(mData);

		Vehicles_Body vehicles = new Vehicles_Body();
		vehicles.setId(null);
		vehicles.setType("CAR");
		vehicles.setColor("black");
		vehicles.setDescription("Coupe");
		vehicles.setLicensePlate("FFJ 7892");
		pr.setVehicle(vehicles);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User GET response call for HomeDelivery drivers")
	public static void userGETResponseCallForHomeDeliveryDrivers() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery drivers");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Drivers_RootObject gson1 = new Gson().fromJson(RESPONSE,
						Drivers_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DriverID = gson1.getData().get(0).getId();
				putTestObject("DriverID", DriverID);
				Reporter.log("Read Success-HomeDelivery Driver ID: " + DriverID);
				System.out.println("Read Success-HomeDelivery Driver ID: " + DriverID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}
	
	@QAFTestStep(description = "User GET response call for HomeDelivery drivers by profile ID")
	public static void userGETResponseCallForHomeDeliveryDriversbyProfileID() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery drivers");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				DriversByProfileID_RootObject gson1 = new Gson().fromJson(RESPONSE,
						DriversByProfileID_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				int DriverID = gson1.getData().getId();
				putTestObject("DriverID", DriverID);
				Reporter.log("Read Success-HomeDelivery Driver ID: " + DriverID);
				System.out.println("Read Success-HomeDelivery Driver ID: " + DriverID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "User POST the Create HomeDelivery Driver call")
	public void userPOSTTheCreateHomeDeliveryDriverCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Teams is created ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Driver_Post gson1 = new Gson().fromJson(RESPONSE, Driver_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DriverID = gson1.getData().getId();
				String DriverName = gson1.getData().getName();
				putTestObject("DriverID", DriverID);
				putTestObject("DriverName", DriverName);
				Reporter.log("Created Success-HomeDelivery Driver ID: " + DriverID);
				Reporter.log("Created Success-HomeDelivery Driver Name: " + DriverName);
				System.out.println("Created Success-HomeDelivery Driver ID: " + DriverID);
				System.out.println("Created Success-HomeDelivery Driver Name: " + DriverName);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Driver created with failed  " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("Driver created with failed  " + 503);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User POST the Create HomeDelivery Driver calls")
	public void userPOSTTheCreateHomeDeliveryDriverCalls() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Teams is created ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Driver_Post gson1 = new Gson().fromJson(RESPONSE, Driver_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DriverID = gson1.getData().getId();
				String DriverName = gson1.getData().getName();
				String PhoneNum = gson1.getData().getPhone();
				putTestObject("DriverID", DriverID);
				putTestObject("DriverName", DriverName);
				putTestObject("PhoneNum", PhoneNum);
				Reporter.log("Created Success-HomeDelivery Driver ID: " + DriverID);
				Reporter.log("Created Success-HomeDelivery Driver Name: " + DriverName);
				System.out.println("Created Success-HomeDelivery Driver ID: " + DriverID);
				System.out.println("Created Success-HomeDelivery Driver Name: " + DriverName);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Driver created with failed  " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description="User uses batch POST to Create Multiple HomeDelivery Drivers {0}")
	public void userUsesBatchPOSTToCreateMultipleHomeDeliveryDrivers(int batchCount){
		int batchPostCount = batchCount;
		//String[] dispatcherID = new String[batchPostCount];
		List<String> driverID = new ArrayList<>();
		
		for (int i=1; i<=batchPostCount; i++) {
			
			try {
				
				userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryDriver();
				userPOSTTheCreateHomeDeliveryDriverCall();
				
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			
			//dispatcherID[i] = getTestString("DispatcherID");
			driverID.add(getTestString("DriverID"));
			System.out.println("Driver is :" + driverID);
			
		}
		
		putTestObject("DriverIDList", driverID);		
		System.out.println("Final Driver is :" + getTestObject("DriverIDList"));
	}
	
	
	@QAFTestStep(description = "User GET response call for Specific HomeDelivery drivers")
	public static void userGETResponseCallForSpecificHomeDeliveryDrivers() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery drivers");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Drivers_Post gson1 = new Gson().fromJson(RESPONSE, Drivers_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DriverID = gson1.getData().getId();
				putTestObject("DriverID", DriverID);
				Reporter.log("Read Success-HomeDelivery Driver ID: " + DriverID);
				System.out.println("Read Success-HomeDelivery Driver ID: " + DriverID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}
	
	@QAFTestStep(description = "User GET response call for Specific HomeDelivery drivers by using Location")
	public static void userGETResponseCallForSpecificHomeDeliveryDriversByUsingLocation() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery drivers");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Drivers_RootObject gson1 = new Gson().fromJson(RESPONSE, Drivers_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DriverID = gson1.getData().get(0).getId();
				putTestObject("DriverID", DriverID);
				Reporter.log("Read Success-HomeDelivery Driver ID: " + DriverID);
				System.out.println("Read Success-HomeDelivery Driver ID: " + DriverID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);
			String RESPONSE = rClient.getEntity(String.class);
			ErrorMessage json = new Gson().fromJson(RESPONSE, ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "User PUT the Update HomeDelivery Driver call")
	public void userPUTTheUpdateHomeDeliveryDriverCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			rClient = ServiceUtils.PUT(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Driver is updated ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Driver_Post gson1 = new Gson().fromJson(RESPONSE, Driver_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DriverID = gson1.getData().getId();
				String UpdatedDriverName = gson1.getData().getName();
				String PhoneNum = gson1.getData().getPhone();
				putTestObject("DriverID", DriverID);
				putTestObject("Updated_DriverName", UpdatedDriverName);
				putTestObject("PhoneNum", PhoneNum);
				Reporter.log("Created Success-HomeDelivery Driver ID: " + DriverID);
				Reporter.log("Created Success-HomeDelivery Driver Name: " + UpdatedDriverName);
				System.out.println("Created Success-HomeDelivery Driver ID: " + DriverID);
				System.out.println("Created Success-HomeDelivery Driver Name: " + UpdatedDriverName);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Driver creation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery Driver creation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery Driver creation failed  ");
				putTestObject("rClient", rClient);

			}

		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	@QAFTestStep(description = "User PUT the Update HomeDelivery Driver call by profile ID")
	public void userPUTTheUpdateHomeDeliveryDriverCallbyprofileID() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			rClient = ServiceUtils.PUT(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Driver is updated ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				DriversByProfileID_RootObject gson1 = new Gson().fromJson(RESPONSE, DriversByProfileID_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				int DriverID = gson1.getData().getId();
				String UpdatedDriverFirstName = gson1.getData().getFirstName();
				String UpdatedDriverLastName = gson1.getData().getLastName();
				boolean UpdatedAllowSMS = gson1.getData().getAllowSms();
				boolean UpdatedAllowEmail = gson1.getData().getAllowEmail();
				putTestObject("DriverID", DriverID);
				Reporter.log("Created Success-HomeDelivery Driver ID: " + DriverID);
				Reporter.log("Created Success-HomeDelivery Driver First Name: " + UpdatedDriverFirstName);
				Reporter.log("Created Success-HomeDelivery Driver Last Name: " + UpdatedDriverLastName);
				Reporter.log("Created Success-HomeDelivery Driver Allow SMS: " + UpdatedAllowSMS);
				Reporter.log("Created Success-HomeDelivery Driver Allow Email: " + UpdatedAllowEmail);
				System.out.println("Created Success-HomeDelivery Driver ID: " + DriverID);
				System.out.println("Created Success-HomeDelivery Driver First Name: " + UpdatedDriverFirstName);
				System.out.println("Created Success-HomeDelivery Driver Last Name: " + UpdatedDriverLastName);
				System.out.println("Created Success-HomeDelivery Driver Allow SMS: " + UpdatedAllowSMS);
				System.out.println("Created Success-HomeDelivery Driver Allow Email: " + UpdatedAllowEmail);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Driver update failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery Driver update failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery Driver update failed  ");
				putTestObject("rClient", rClient);

			}

		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User DELETE the HomeDelivery Driver DELETE call")
	public void userDELETETheHomeDeliveryDriverDELETECall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.DELETE(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("HomeDelivery Driver is deleted ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				HomeDelivery_Success gson1 = new Gson().fromJson(RESPONSE,
						HomeDelivery_Success.class);
				putTestObject("rGSON", gson1);
				System.out.println(" : " + gson1.getApiStatus());
				Reporter.log("Deleted HomeDelivery Driver : " + gson1.getApiStatus());
			}
			if (rClient.getStatus() == 207) {
				Reporter.log("HomeDelivery Driver Deleted with Partial success  ");
				putTestObject("rClient", rClient);
				ErrorMessage gson1 = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
				putTestObject("rGSON", gson1);
			}

			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Driver Deletion failed with 400");
				putTestObject("rClient", rClient);
			}

			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery Driver Deletion failed with 404");
				putTestObject("rClient", rClient);
			}
			
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery Driver Deletion failed with 401");
				putTestObject("rClient", rClient);
			}
			
			if (rClient.getStatus() == 503) {
				Reporter.log("HomeDelivery Driver Deletion failed with 503");
				putTestObject("rClient", rClient);
			}
			
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Driver Deletion failed with 400");
				putTestObject("rClient", rClient);
			}

		}
	}

	public static String getName() {
		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 10;
		
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();

		return "automation" + generatedString;
	}

	public static String getNameMoreThan101Characters() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "Automation driver name more than 101 characters in length should return an exception "
				+ name.substring(3, name.length());

	}

	public static String generateRandom() {
		Random random = new Random();
		char[] digits = new char[5];
		digits[0] = (char) (random.nextInt(4) + '1');
		for (int i = 1; i < 5; i++) {
			digits[i] = (char) (random.nextInt(5) + '0');
		}
		return "83075" + (new String(digits));
	}

	public static String generateRandomInvalidFormat() {
		Random random = new Random();
		char[] digits = new char[5];
		digits[0] = (char) (random.nextInt(4) + '1');
		for (int i = 1; i < 5; i++) {
			digits[i] = (char) (random.nextInt(5) + '0');
		}
		return "+1-830-75" + (new String(digits));
	}
	
	@QAFTestStep(description = "validate the response schema with GET Drivers")
	public static void validateTheResponseSchemaWithGETDrivers() {

		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			RESPONSE = ServiceUtils.GET(headers);
			Reporter.log("Status :" + RESPONSE.getStatus());
			Reporter.log("rClient list is : " + RESPONSE.getStatusInfo());
			putTestObject("rClient", RESPONSE);

			if (RESPONSE.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery drivers");
				putTestObject("rClient", RESPONSE);
				
				String StringResponse = RESPONSE.getEntity(String.class);
				putTestObject(StringResponse, "STRINGRESPONSE");

				Drivers_RootObject gson1 = new Gson().fromJson(StringResponse,
						Drivers_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DriverID = gson1.getData().get(0).getId();
				putTestObject("DriverID", DriverID);
				Reporter.log("Read Success-HomeDelivery Driver ID: " + DriverID);
				System.out.println("Read Success-HomeDelivery Driver ID: " + DriverID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(StringResponse, "GET_DRIVERS");
				HomeDelivery_ReusableUtils.validateJSONschema("Drivers_GET", "GET_DRIVERS");
			}
			if (RESPONSE.getStatus() != 200) {
				Reporter.log("Driver created with failed", MessageTypes.Fail);
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = RESPONSE.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);
		}
	}
	
	@QAFTestStep(description = "validate the response schema with POST Driver")
	public void validateTheResponseSchemaWithPOSTDriver() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			RESPONSE = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + RESPONSE.getStatus());
			if (RESPONSE.getStatus() == 200) {

				Reporter.log("Teams is created ");
				putTestObject("rClient", RESPONSE);
				
				String StringResponse = RESPONSE.getEntity(String.class);
				putTestObject(StringResponse, "STRINGRESPONSE");

				Driver_Post gson1 = new Gson().fromJson(StringResponse, Driver_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DriverID = gson1.getData().getId();
				putTestObject("DriverID", DriverID);
				Reporter.log("Created Success-HomeDelivery Driver ID: " + DriverID);
				System.out.println("Created Success-HomeDelivery Driver ID: " + DriverID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(StringResponse, "POST_DRIVER");
				HomeDelivery_ReusableUtils.validateJSONschema("Driver_POST", "POST_DRIVER");
				
			}
			if (RESPONSE.getStatus() != 200) {
				Reporter.log("HomeDelivery Driver created with failed  ",MessageTypes.Fail);
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	@QAFTestStep(description = "validate the response schema with PUT Driver")
	public void validateTheResponseSchemaWithPUTDriver() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			RESPONSE = ServiceUtils.PUT(headers, bodyParam);
			Reporter.log("Status :" + RESPONSE.getStatus());
			if (RESPONSE.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Driver is updated ");
				putTestObject("rClient", RESPONSE);
				
				String StringResponse = RESPONSE.getEntity(String.class);
				putTestObject(StringResponse, "STRINGRESPONSE");

				Driver_Post gson1 = new Gson().fromJson(StringResponse, Driver_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DriverID = gson1.getData().getId();
				String PhoneNum = gson1.getData().getPhone();
				putTestObject("DriverID", DriverID);
				putTestObject("PhoneNum", PhoneNum);
				Reporter.log("Created Success-HomeDelivery Driver ID: " + DriverID);
				System.out.println("Created Success-HomeDelivery Driver ID: " + DriverID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(StringResponse, "PUT_DRIVER");
				HomeDelivery_ReusableUtils.validateJSONschema("Driver_PUT", "PUT_DRIVER");
				
			}
			if (RESPONSE.getStatus() != 200) {
				Reporter.log("HomeDelivery Driver created with failed  ",MessageTypes.Fail);
				putTestObject("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 404) {
				Reporter.log("HomeDelivery Driver created with failed  ",MessageTypes.Fail);
				putTestObject("rClient", RESPONSE);

			}

		} catch (Exception e) {

			Reporter.log("Exceptions :" + e,MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "validate the response schema with GET Driver")
	public static void validateTheResponseSchemaWithGETDriver() {

		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			RESPONSE = ServiceUtils.GET(headers);
			Reporter.log("Status :" + RESPONSE.getStatus());
			Reporter.log("rClient list is : " + RESPONSE.getStatusInfo());
			putTestObject("rClient", RESPONSE);
			
			String StringResponse = RESPONSE.getEntity(String.class);
			putTestObject(StringResponse, "STRINGRESPONSE");

			if (RESPONSE.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery drivers");
				putTestObject("rClient", RESPONSE);

				Drivers_Post gson1 = new Gson().fromJson(StringResponse, Drivers_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DriverID = gson1.getData().getId();
				putTestObject("DriverID", DriverID);
				Reporter.log("Read Success-HomeDelivery Driver ID: " + DriverID);
				System.out.println("Read Success-HomeDelivery Driver ID: " + DriverID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(StringResponse, "GET_DRIVER");
				HomeDelivery_ReusableUtils.validateJSONschema("Driver_GET", "GET_DRIVER");
			} 
			if (RESPONSE.getStatus() != 200) {
				Reporter.log("HomeDelivery Driver created with failed  ",MessageTypes.Fail);
				putTestObject("rClient", RESPONSE);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = RESPONSE.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(RESPONSE.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}

}
