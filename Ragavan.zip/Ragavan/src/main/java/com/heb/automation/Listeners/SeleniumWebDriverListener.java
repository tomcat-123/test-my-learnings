/**
 * 
 */
package com.heb.automation.Listeners;

import com.heb.automation.common.TestDataContainer;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.DriverCommand;

import com.qmetry.qaf.automation.ui.webdriver.CommandTracker;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriverCommandAdapter;;

public class SeleniumWebDriverListener extends QAFWebDriverCommandAdapter {

	@Override
	public void onInitialize(QAFExtendedWebDriver driver) {
		
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		System.out.println("[[[[[ Started.........]]] ");
		driver.manage().deleteAllCookies();
		driver.get(TestDataContainer.getTestString("env.baseurl"));
		driver.manage().window().maximize();
	}

	

	@Override
	public void beforeCommand(QAFExtendedWebDriver driver, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.QUIT)) {
			try {
				closeApp();
				driver.close();
				if (driver != null) {
					driver.close();
				}

			} catch (Exception e) {
				// ignore
			}
		}
	}

	@Override
	public void afterCommand(QAFExtendedWebDriver driver, CommandTracker commandTracker) {

		// commandTracker.setEndTime(60000);
		super.afterCommand(driver, commandTracker);
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.CLOSE)) {
			try {
			} catch (Exception e) {
				// ignore
			}
		}
	}

	@Override
	public void beforeInitialize(Capabilities desiredCapabilities) {

		if (TestDataContainer.getTestString("driver.name").equalsIgnoreCase("FirefoxDriver")) {
			System.setProperty("webdriver.gecko.driver", "lib\\geckodriver.exe");
		}
		

	}

	private void closeApp() {

		
	}

}
