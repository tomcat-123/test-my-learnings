package com.heb.automation.Pages.HD_WebApp.city;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CityDisplayTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	
	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}
	
	@FindBy (locator="citydisplay.lbl.title")
	private QAFWebElement citydisplaylbltitle;
	
	@FindBy (locator="citydisplay.btn.displaycitycrumb")
	private QAFWebElement citydisplaybtndisplaycitycrumb;
	
	@FindBy (locator="citydisplay.txt.cityname")
	private QAFWebElement citydisplaytxtcityname;
	
	@FindBy (locator="citydisplay.txt.fountainfunnel")
	private QAFWebElement citydisplaytxtfountainfunnel;
	
	@FindBy (locator="citydisplay.txt.fountaintips")
	private QAFWebElement citydisplaytxtfountaintips;
	
	@FindBy (locator="citydisplay.txt.fountainrejected")
	private QAFWebElement citydisplaytxtfountainrejected;
	
	@FindBy (locator="citydisplay.txt.onfleettips")
	private QAFWebElement citydisplaytxtonfleettips;
	
	@FindBy (locator="citydisplay.txt.onfleetparking")
	private QAFWebElement citydisplaytxtonfleetparking;
	
	@FindBy (locator="citydisplay.txt.hourlyrate")
	private QAFWebElement citydisplaytxthourlyrate;
	
	@FindBy (locator="citydisplay.txt.maplink")
	private QAFWebElement citydisplaytxtmaplink;
	
	@FindBy (locator="citydisplay.txt.fountainapproved")
	private QAFWebElement citydisplaytxfountainapproved;
	
	@FindBy (locator="citydisplay.btn.edit")
	private QAFWebElement citydisplaybtnedit;
	
	@FindBy (locator="citydisplay.btn.delete")
	private QAFWebElement citydisplaybtndelete;
	
	@FindBy (locator="citydisplay.btn.cancel")
	private QAFWebElement citydisplaybtncancel;
		
	@FindBy (locator="citydisplay.lbl.deleteconfirmation")
	private QAFWebElement citydisplaylbldeleteconfirmation;
	
	@FindBy (locator="citydisplay.lbl.deletewarningmessage")
	private QAFWebElement citydisplaylbldeletewarningmessage;
	
	@FindBy (locator="citydisplay.btn.yes")
	private QAFWebElement citydisplaybtnyes;
	
	@FindBy (locator="citydisplay.btn.no")
	private QAFWebElement citydisplaybtnno;

	public QAFWebElement getCitydisplaylbltitle() {
		return citydisplaylbltitle;
	}

	public QAFWebElement getCitydisplaybtndisplaycitycrumb() {
		return citydisplaybtndisplaycitycrumb;
	}

	public QAFWebElement getCitydisplaytxtcityname() {
		return citydisplaytxtcityname;
	}

	public QAFWebElement getCitydisplaytxtfountainfunnel() {
		return citydisplaytxtfountainfunnel;
	}

	public QAFWebElement getCitydisplaytxtfountaintips() {
		return citydisplaytxtfountaintips;
	}

	public QAFWebElement getCitydisplaytxtfountainrejected() {
		return citydisplaytxtfountainrejected;
	}

	public QAFWebElement getCitydisplaytxtonfleettips() {
		return citydisplaytxtonfleettips;
	}

	public QAFWebElement getCitydisplaytxtonfleetparking() {
		return citydisplaytxtonfleetparking;
	}

	public QAFWebElement getCitydisplaytxthourlyrate() {
		return citydisplaytxthourlyrate;
	}

	public QAFWebElement getCitydisplaytxtmaplink() {
		return citydisplaytxtmaplink;
	}

	public QAFWebElement getCitydisplaytxfountainapproved() {
		return citydisplaytxfountainapproved;
	}

	public QAFWebElement getCitydisplaybtnedit() {
		return citydisplaybtnedit;
	}

	public QAFWebElement getCitydisplaybtndelete() {
		return citydisplaybtndelete;
	}

	public QAFWebElement getCitydisplaybtncancel() {
		return citydisplaybtncancel;
	}

	public QAFWebElement getCitydisplaylbldeleteconfirmation() {
		return citydisplaylbldeleteconfirmation;
	}

	public QAFWebElement getCitydisplaylbldeletewarningmessage() {
		return citydisplaylbldeletewarningmessage;
	}

	public QAFWebElement getCitydisplaybtnyes() {
		return citydisplaybtnyes;
	}

	public QAFWebElement getCitydisplaybtnno() {
		return citydisplaybtnno;
	}	
}
