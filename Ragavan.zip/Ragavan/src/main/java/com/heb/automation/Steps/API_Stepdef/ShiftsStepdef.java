package com.heb.automation.Steps.API_Stepdef;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.ErrorMessages.ErrorMessage;
import com.heb.automation.Services.BodyParameter.Drivers.Driver_Post;
import com.heb.automation.Services.BodyParameter.Shifts.SearchAllShifts_BodyRoot;
import com.heb.automation.Services.BodyParameter.Shifts.SearchAllShifts_SearchCriteria;
import com.heb.automation.Services.BodyParameter.Shifts.SearchPlanner_SearchCriteria;
import com.heb.automation.Services.BodyParameter.Shifts.SearchShiftPlanner_BodyRoot;
import com.heb.automation.Services.BodyParameter.Shifts.ShiftsPUT_Body;
import com.heb.automation.Services.BodyParameter.Shifts.ShiftsPUT_Zone;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_Success;
import com.heb.automation.Services.HomeDelivery.ServiceUtils;
import com.heb.automation.Services.HomeDelivery.Search.ShiftsSearchResult.SearchAllShifts_Root;
import com.heb.automation.Services.HomeDelivery.Search.ShiftsSearchResult.SearchShiftPlanner_Root;
import com.heb.automation.Services.HomeDelivery.Shifts.Shifts_Root;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class ShiftsStepdef extends TestDataContainer {

	@QAFTestStep(description = "Build URL for read specific HomeDelivery shifts")
	public void bUildURLForReadSpecificHomeDeliveryShifts() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.shifts");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for read invalid HomeDelivery shifts")
	public void bUildURLForReadInvalidHomeDeliveryShifts() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.Invalidshifts");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for delete specific HomeDelivery shift")
	public void buildURLForDeleteSpecificHomeDeliveryShift() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.shiftsDelete");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for delete invalid HomeDelivery shift")
	public void buildURLForDeleteinvalidHomeDeliveryShift() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.Invalidshifts");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for search HomeDelivery shifts")
	public void buildURLForSearchHomeDeliveryShifts() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.allshifts");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for search HomeDelivery shifts planner")
	public void buildURLForSearchHomeDeliveryShiftsPlanner() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.shiftplanner");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "User GET response call for HomeDelivery Shifts")
	public static void userGETResponseCallForHomeDeliveryShifts() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Shifts");
				putTestObject("rClient", rClient);

				String RESPONSE = rClient.getEntity(String.class);
				Shifts_Root gson = new Gson().fromJson(RESPONSE, Shifts_Root.class);
				Arrays.asList(gson);
				putTestObject("rGSON", gson);
				String ShiftID = gson.getData().getId();

				putTestObject("ShiftID", ShiftID);
				Reporter.log("Read Success-HomeDelivery ShiftID: " + ShiftID);
				System.out.println("Read Success-HomeDelivery ShiftID: " + ShiftID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}
	@QAFTestStep(description = "Validate the response schema with GET Shifts Call")
	public static void validateTheResponseSchemaWithGETShifts() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Shifts");
				putTestObject("rClient", rClient);

				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "GET_SHIFTS");
				HomeDelivery_ReusableUtils.validateJSONschema("Shift_GET", "GET_SHIFTS");
			}
			
			if (rClient.getStatus() != 200) {
				Reporter.log("Shift Read with failed", MessageTypes.Fail);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}
	
	@QAFTestStep(description = "Validate the response schema with POST Shifts Call")
	public void validateTheResponseSchemaWithPOSTShiftsCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("POST the HomeDelivery Shifts Search");
				putTestObject("rClient", rClient);

				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "POST_SHIFTS_SEARCH");
				HomeDelivery_ReusableUtils.validateJSONschema("ShiftSearch_POST", "POST_SHIFTS_SEARCH");
			}
			if (rClient.getStatus() != 200) {
				Reporter.log("Shift Search POST is failed", MessageTypes.Fail);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	@QAFTestStep(description = "User UPDATE HomeDelivery Shifts body parameter")
	public void userUPDATEHomeDeliveryShiftsBodyParameter() throws JsonProcessingException {

		ShiftsPUT_Body pr = new ShiftsPUT_Body();
		ShiftsPUT_Zone zr = new ShiftsPUT_Zone();
		ObjectMapper objm = new ObjectMapper();

		pr.setLastModifiedTimestamp("");
		pr.setId(getTestString("shifts.ShiftID"));
		pr.setStartWindowDateTime(getTestString("shifts.StartWindowDate"));
		pr.setEndWindowDateTime(getTestString("shifts.StartWindowDate"));
		zr.setLastModifiedTimestamp("");
		zr.setId(getTestString("shifts.ZoneId"));
		zr.setExternalIdOnfleet(getTestString("shifts.externalIdOnfleet"));
		zr.setName(getTestString("shifts.name"));
		zr.setArchived(getTestString("shifts.archived"));
		pr.setZone(zr);
		pr.setPublished(getTestString("shifts.published"));
		pr.setShiftCapacity(getTestString("shifts.shiftCapacity"));
		pr.setPublishDateTime(getTestString("shifts.publishDateTime"));
		pr.setArchived(getTestString("shifts.archived"));
		pr.setStartOfWeek(getTestString("shifts.startOfWeek"));

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Shifts body parameter with invalid shiftID")
	public void userUPDATEHomeDeliveryShiftsBodyParameterWithInvalidShiftID() throws JsonProcessingException {

		ShiftsPUT_Body pr = new ShiftsPUT_Body();
		ShiftsPUT_Zone zr = new ShiftsPUT_Zone();
		ObjectMapper objm = new ObjectMapper();

		pr.setLastModifiedTimestamp("");
		pr.setId(getTestString("shifts.InvalidShiftID"));
		pr.setStartWindowDateTime(getTestString("shifts.StartWindowDate"));
		pr.setEndWindowDateTime(getTestString("shifts.StartWindowDate"));
		zr.setLastModifiedTimestamp("");
		zr.setId(getTestString("shifts.ZoneId"));
		zr.setExternalIdOnfleet(getTestString("shifts.externalIdOnfleet"));
		zr.setName(getTestString("shifts.name"));
		zr.setArchived(getTestString("shifts.archived"));
		pr.setZone(zr);
		pr.setPublished(getTestString("shifts.published"));
		pr.setShiftCapacity(getTestString("shifts.shiftCapacity"));
		pr.setPublishDateTime(getTestString("shifts.publishDateTime"));
		pr.setArchived(getTestString("shifts.archived"));
		pr.setStartOfWeek(getTestString("shifts.startOfWeek"));

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User PUT the Update HomeDelivery Shifts call")
	public void userPUTTheUpdateHomeDeliveryShiftsCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			rClient = ServiceUtils.PUT(headers, bodyParam);
			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Shift is updated ");
				putTestObject("rClient", rClient);

				String RESPONSE = rClient.getEntity(String.class);
				Shifts_Root gson1 = new Gson().fromJson(RESPONSE, Shifts_Root.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String ShiftID = gson1.getData().getId();
				putTestObject("Updated_ShiftID", ShiftID);
				Reporter.log("Update Success-HomeDelivery ShiftID : " + ShiftID);
				System.out.println("Update Success-HomeDelivery ShiftID : " + ShiftID);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Shift creation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery Shift creation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery Shift creation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("HomeDelivery Shift creation failed  ");
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User DELETE the HomeDelivery Shifts DELETE call")
	public void UserDELETETheHomeDeliveryShiftsDELETECall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.DELETE(headers, bodyParam);
			if (rClient.getStatus() == 200) {

				Reporter.log("HomeDelivery Shifts is deleted ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				HomeDelivery_Success gson1 = new Gson().fromJson(RESPONSE, HomeDelivery_Success.class);
				putTestObject("rGSON", gson1);
				System.out.println(" : " + gson1.getApiStatus());
				Reporter.log("Deleted HomeDelivery Shifts : " + gson1.getApiStatus());
			}
			if (rClient.getStatus() == 207) {
				Reporter.log("HomeDelivery Shifts Deletion with Partial success  ");
				putTestObject("rClient", rClient);
				ErrorMessage gson1 = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
				putTestObject("rGSON", gson1);
			}

			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Shifts Deletion failed with 400");
				putTestObject("rClient", rClient);
			}

			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery Shifts Deletion failed with 404");
				putTestObject("rClient", rClient);
			}
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery Shifts Deletion failed with 401");
				putTestObject("rClient", rClient);
			}
			if (rClient.getStatus() == 503) {
				Reporter.log("HomeDelivery Shifts Deletion failed with 503");
				putTestObject("rClient", rClient);
			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Shifts Deletion failed with 400");
				putTestObject("rClient", rClient);
			}

		}
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter for searching HomeDelivery all shifts")
	public void userUsesAnArrayOfBodyParameterForSearchingHomeDeliveryAllShifts() 
			throws JsonProcessingException {
		
		ObjectMapper objm = new ObjectMapper();
		SearchAllShifts_BodyRoot pr = new SearchAllShifts_BodyRoot();
		
		pr.setPageNumber(getTestString("shifts.pageNumber"));
		pr.setPageSize(getTestString("shifts.pageSize"));
		
		ArrayList<SearchAllShifts_SearchCriteria> search = new ArrayList<SearchAllShifts_SearchCriteria>();
		
		SearchAllShifts_SearchCriteria sc1 = new SearchAllShifts_SearchCriteria();
		
		int id = Integer.parseInt(getTestString("shifts.IdValue"));
		sc1.setValue(id);
		sc1.setKey(getTestString("shifts.SearchByID"));
		sc1.setOperation(getTestString("shifts.operationEqual"));
		search.add(sc1);
	
		pr.setSearchCriteria(search);	
		pr.setSortDirection(getTestString("shifts.sortDirection"));
		pr.setSortBy(getTestString("shifts.sortBy"));
			
		String jsonInString = objm.writeValueAsString(pr);		
		//System.out.println("CHoosen Name is  :" + pr.toString());
		System.out.println("Full search body is : " + jsonInString);		
		putTestObject("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User POST the Search HomeDelivery Shifts call")
	public void userPOSTTheSearchHomeDeliveryShiftsCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Shifts is being searched "); 
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				SearchAllShifts_Root gson1 = new Gson().fromJson(RESPONSE, SearchAllShifts_Root.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String searchResultsCount = gson1.getData().getTotalElements();
						//String ZoneName = gson1.getData().getName();
						//String ZoneOnfleetID = gson1.getData().getexternalIdOnfleet();
				putTestObject("searchResultsCount", searchResultsCount);
						//putTestObject("ZoneName", ZoneName);
						//putTestObject("ZoneOnfleetID", ZoneOnfleetID);
				Reporter.log("Search Success- Search Results Count : " + searchResultsCount);
						//Reporter.log("Created Success-HomeDelivery Zone Name: " + ZoneName);
						//Reporter.log("Created Success-HomeDelivery Zone OnfleetID: " + ZoneOnfleetID);
				System.out.println("Search Success- Search Results Count : " + searchResultsCount);
						//System.out.println("Created Success-HomeDelivery Zone Name: " + ZoneName);
						//System.out.println("Created Success-HomeDelivery Zone OnfleetID: " + ZoneOnfleetID);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Orders search failed with " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("Orders search failed with " + 503);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter for searching HomeDelivery Shitfs Planner")
	public void userUsesAnArrayOfBodyParameterForSearchingHomeDeliveryShitfsPlanner() 
			throws JsonProcessingException {
		
		ObjectMapper objm = new ObjectMapper();
		SearchShiftPlanner_BodyRoot pr = new SearchShiftPlanner_BodyRoot();
			
		ArrayList<SearchPlanner_SearchCriteria> search = new ArrayList<SearchPlanner_SearchCriteria>();
		
		SearchPlanner_SearchCriteria sc1 = new SearchPlanner_SearchCriteria();
		sc1.setKey(getTestString("shifts.sppublishDateTime"));
		sc1.setOperation("shifts.operationEqual");
		sc1.setValue(getTestString("shifts.sppublishDateTimeValue"));
		
		SearchPlanner_SearchCriteria sc2 = new SearchPlanner_SearchCriteria();
		sc2.setKey(getTestString("shifts.spzonename"));
		sc2.setOperation("shifts.operationEqual");
		sc2.setValue(getTestString("shifts.spzonenamevalue"));
			
		search.add(sc1);
		search.add(sc2);
		
		pr.setSearchCriteria(search);
		
		String jsonInString = objm.writeValueAsString(pr);		
		//System.out.println("CHoosen Name is  :" + pr.toString());
		System.out.println("Full search body is : " + jsonInString);		
		putTestObject("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User POST the Search HomeDelivery Shifts Planner call")
	public void userPOSTTheSearchHomeDeliveryShiftsPlannerCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Shifts is being searched "); 
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				SearchShiftPlanner_Root gson1 = new Gson().fromJson(RESPONSE, SearchShiftPlanner_Root.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String ZoneName = gson1.getData().get(0).getZone();
						//String ZoneName = gson1.getData().getName();
						//String ZoneOnfleetID = gson1.getData().getexternalIdOnfleet();
				putTestObject("SearchZoneName", ZoneName);
						//putTestObject("ZoneName", ZoneName);
						//putTestObject("ZoneOnfleetID", ZoneOnfleetID);
				Reporter.log("Search Success- Search Results Count : " + ZoneName);
						//Reporter.log("Created Success-HomeDelivery Zone Name: " + ZoneName);
						//Reporter.log("Created Success-HomeDelivery Zone OnfleetID: " + ZoneOnfleetID);
				System.out.println("Search Success- Search Results Count : " + ZoneName);
						//System.out.println("Created Success-HomeDelivery Zone Name: " + ZoneName);
						//System.out.println("Created Success-HomeDelivery Zone OnfleetID: " + ZoneOnfleetID);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Orders search failed with " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("Orders search failed with " + 503);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	@QAFTestStep(description = "Validate the response schema with POST Shift Planner")
	public void validateTheResponseSchemaWithPOSTDriver() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);
			if (rClient.getStatus() == 200) {
				
				System.out.println("inside..");
				Reporter.log("Post the HomeDelivery ShiftPlanner");
				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");

				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "POST_SHIFT_PLANNER");
				HomeDelivery_ReusableUtils.validateJSONschema("ShiftPlanner_POST", "POST_SHIFT_PLANNER");
				
			}
			if (rClient.getStatus() != 200) {
				Reporter.log("HomeDelivery Driver created with failed  ",MessageTypes.Fail);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
}
