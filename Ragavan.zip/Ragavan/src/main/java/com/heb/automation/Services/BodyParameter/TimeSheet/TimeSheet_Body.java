package com.heb.automation.Services.BodyParameter.TimeSheet;

public class TimeSheet_Body {
	
	 private String startTime;

	    private TimeSheet_BodyDriver driver = new TimeSheet_BodyDriver();

	    private String endTime;

	    private String date;

	    public String getStartTime ()
	    {
	        return startTime;
	    }

	    public void setStartTime (String startTime)
	    {
	        this.startTime = startTime;
	    }

	    public TimeSheet_BodyDriver getDriver ()
	    {
	        return driver;
	    }

	    public void setDriver (TimeSheet_BodyDriver driver)
	    {
	        this.driver = driver;
	    }

	    public String getEndTime ()
	    {
	        return endTime;
	    }

	    public void setEndTime (String endTime)
	    {
	        this.endTime = endTime;
	    }

	    public String getDate ()
	    {
	        return date;
	    }

	    public void setDate (String date)
	    {
	        this.date = date;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [startTime = "+startTime+", driver = "+driver+", endTime = "+endTime+", date = "+date+"]";
	    }

}
