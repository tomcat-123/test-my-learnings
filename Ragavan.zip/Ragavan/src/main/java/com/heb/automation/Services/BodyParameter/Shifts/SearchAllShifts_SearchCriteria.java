package com.heb.automation.Services.BodyParameter.Shifts;

public class SearchAllShifts_SearchCriteria {
	
	private String operation;

    private int value;

    private String key;

    public String getOperation ()
    {
        return operation;
    }

    public void setOperation (String operation)
    {
        this.operation = operation;
    }

    public int getValue ()
    {
        return value;
    }

    public void setValue (int id)
    {
        this.value = id;
    }

    public String getKey ()
    {
        return key;
    }

    public void setKey (String id)
    {
        this.key = id;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [operation = "+operation+", value = "+value+", key = "+key+"]";
    }

}
