package com.heb.automation.Services.HomeDelivery.Search.ShiftsSearchResult;

public class SearchAllShifts_Data_Sort {

	private String nullHandling;

    private String direction;

    private String ascending;

    private String property;

    private String ignoreCase;

    private String descending;

    public String getNullHandling ()
    {
        return nullHandling;
    }

    public void setNullHandling (String nullHandling)
    {
        this.nullHandling = nullHandling;
    }

    public String getDirection ()
    {
        return direction;
    }

    public void setDirection (String direction)
    {
        this.direction = direction;
    }

    public String getAscending ()
    {
        return ascending;
    }

    public void setAscending (String ascending)
    {
        this.ascending = ascending;
    }

    public String getProperty ()
    {
        return property;
    }

    public void setProperty (String property)
    {
        this.property = property;
    }

    public String getIgnoreCase ()
    {
        return ignoreCase;
    }

    public void setIgnoreCase (String ignoreCase)
    {
        this.ignoreCase = ignoreCase;
    }

    public String getDescending ()
    {
        return descending;
    }

    public void setDescending (String descending)
    {
        this.descending = descending;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [nullHandling = "+nullHandling+", direction = "+direction+", ascending = "+ascending+", property = "+property+", ignoreCase = "+ignoreCase+", descending = "+descending+"]";
    }
}
