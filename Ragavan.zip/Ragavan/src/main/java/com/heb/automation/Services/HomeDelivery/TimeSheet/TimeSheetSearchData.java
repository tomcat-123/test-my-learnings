package com.heb.automation.Services.HomeDelivery.TimeSheet;

import java.util.ArrayList;

public class TimeSheetSearchData {
	
	 	private String endOfWeek;

	    private String driverLastName;

	    private String driverFirstName;

	    private ArrayList<Timesheets> timesheets;

	    private String totalHours;

	    private String startOfWeek;

	    public String getEndOfWeek ()
	    {
	        return endOfWeek;
	    }

	    public void setEndOfWeek (String endOfWeek)
	    {
	        this.endOfWeek = endOfWeek;
	    }

	    public String getDriverLastName ()
	    {
	        return driverLastName;
	    }

	    public void setDriverLastName (String driverLastName)
	    {
	        this.driverLastName = driverLastName;
	    }

	    public String getDriverFirstName ()
	    {
	        return driverFirstName;
	    }

	    public void setDriverFirstName (String driverFirstName)
	    {
	        this.driverFirstName = driverFirstName;
	    }

	    public ArrayList<Timesheets> getTimesheets ()
	    {
	        return timesheets;
	    }

	    public void setTimesheets (ArrayList<Timesheets> timesheets)
	    {
	        this.timesheets = timesheets;
	    }

	    public String getTotalHours ()
	    {
	        return totalHours;
	    }

	    public void setTotalHours (String totalHours)
	    {
	        this.totalHours = totalHours;
	    }

	    public String getStartOfWeek ()
	    {
	        return startOfWeek;
	    }

	    public void setStartOfWeek (String startOfWeek)
	    {
	        this.startOfWeek = startOfWeek;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [endOfWeek = "+endOfWeek+", driverLastName = "+driverLastName+", driverFirstName = "+driverFirstName+", timesheets = "+timesheets+", totalHours = "+totalHours+", startOfWeek = "+startOfWeek+"]";
	    }

}
