package com.heb.automation.Services.HomeDelivery.TimeSheet;

public class Timesheets {
	
	private String startTime;

    private String id;

    private String hours;

    private String endTime;

    private String date;

    public String getStartTime ()
    {
        return startTime;
    }

    public void setStartTime (String startTime)
    {
        this.startTime = startTime;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getHours ()
    {
        return hours;
    }

    public void setHours (String hours)
    {
        this.hours = hours;
    }

    public String getEndTime ()
    {
        return endTime;
    }

    public void setEndTime (String endTime)
    {
        this.endTime = endTime;
    }

    public String getDate ()
    {
        return date;
    }

    public void setDate (String date)
    {
        this.date = date;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [startTime = "+startTime+", id = "+id+", hours = "+hours+", endTime = "+endTime+", date = "+date+"]";
    }

}
