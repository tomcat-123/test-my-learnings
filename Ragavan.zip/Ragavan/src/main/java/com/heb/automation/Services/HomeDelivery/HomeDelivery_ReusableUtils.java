package com.heb.automation.Services.HomeDelivery;

import com.heb.automation.common.TestDataContainer;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.aspectj.org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo.AssertionFailedException;
import org.testng.Assert;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.heb.automation.Services.BodyParameter.Drivers.Driver_Post;
import com.heb.automation.Services.HomeDelivery.Cities.Cities_Put;
import com.heb.automation.Services.HomeDelivery.Dispatchers.Dispatchers_Data;
import com.heb.automation.Services.HomeDelivery.Dispatchers.Dispatchers_Post;
import com.heb.automation.Services.HomeDelivery.Dispatchers.Dispatchers_RootObject;
import com.heb.automation.Services.HomeDelivery.Drivers.DriversByProfileID_RootObject;
import com.heb.automation.Services.HomeDelivery.GeoCode.Geocode_RootObject;
import com.heb.automation.Services.HomeDelivery.Order.HomeDelivery_RootObject;
import com.heb.automation.Services.HomeDelivery.Shifts.Shifts_Root;
import com.heb.automation.Services.HomeDelivery.Teams.Teams_Post;
import com.heb.automation.Services.HomeDelivery.TimeSheet.TimeSheet_Root;
import com.heb.automation.Services.HomeDelivery.Zones.Zones_Post;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*
Should contain Utils specific to *Service 
- Building Header 

*/
public class HomeDelivery_ReusableUtils extends TestDataContainer {

	public static Map<String, String> Common_headers() {

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("x-api-key", getTestString("HomeDelivery.APIkey"));
		headers.put("Referer", getTestString("HomeDelivery.Referer"));

		putTestObject("headers", headers);

		return headers;
	}
	
	public static Map<String, String> onFleet_headers() {

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("x-api-key", getTestString("HomeDelivery.APIkey"));
		headers.put("Referer", getTestString("HomeDelivery.Referer"));
		headers.put("Authorization", getTestString("HomeDelivery.Authorization"));
		putTestObject("headers", headers);

		return headers;
	}

	public static Map<String, String> InvalidApi_Common_headers() {

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("x-api-key", getTestString("HomeDelivery.InvalidAPIKey"));
		headers.put("Referer", getTestString("HomeDelivery.Referer"));

		putTestObject("headers", headers);

		return headers;
	}

	public static Map<String, String> BlankApi_Common_headers() {

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("x-api-key", null);
		headers.put("Referer", getTestString("HomeDelivery.Referer"));

		putTestObject("headers", headers);

		return headers;
	}
	
	
	public static void validatetextfieldforEditable(QAFWebElement QAFElement , String EditString){
		
		String BeforeEdit = QAFElement.getText();
		
		QAFElement.clear();
		QAFElement.sendKeys(EditString);
		String AfterEdit = QAFElement.getText();
		PerfectoUtils.reportMessage("Before Edit :"+ BeforeEdit + " After Edit :"+ AfterEdit , MessageTypes.Pass);
		Reporter.log("Before Edit :"+ BeforeEdit + " After Edit :"+ AfterEdit , MessageTypes.Pass);
		if(!BeforeEdit.equals(AfterEdit)) {
		
			PerfectoUtils.reportMessage(QAFElement + "Is Editable" , MessageTypes.Pass);
			
		}else {
			PerfectoUtils.reportMessage(QAFElement + "Is Non Editable" , MessageTypes.Fail);
		}
		
	}
	
public static void validatetextfieldforNonEditable(QAFWebElement QAFElement , String EditString){
		
		String BeforeEdit = QAFElement.getText();
		
		QAFElement.clear();
		QAFElement.sendKeys(EditString);
		String AfterEdit = QAFElement.getText();
		if(!BeforeEdit.equals(AfterEdit)) {
		
			PerfectoUtils.reportMessage(QAFElement + "Is Editable" , MessageTypes.Fail);
			
		}else {
			PerfectoUtils.reportMessage(QAFElement + "Is Non Editable" , MessageTypes.Pass);
		}
		
	}
	
	
	public static void compareHomeDeliveryTeamActualandExpected() {
		try {
			Teams_Post gson1 = (Teams_Post) getTestObject("rGSON");
			Assert.assertEquals(gson1.getData().getName(), getTestObject("Updated_TeamName"));

			Reporter.log("Editable fields are updated successfully!", MessageTypes.Pass);
		} catch (AssertionFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
	}
	
	public static void compareHomeDeliveryTimeSheetActualandExpected() {
		try {
			TimeSheet_Root gson1 = (TimeSheet_Root) getTestObject("rGSON");
			Assert.assertEquals(gson1.getData().getStartTime(), getTestString("timeSheet.UpdateStartTime"));
			Assert.assertEquals(gson1.getData().getEndTime(), getTestString("timeSheet.UpdateEndTime"));		
			Reporter.log("Editable fields are updated successfully!", MessageTypes.Pass);
		} catch (AssertionFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
	}
	
	public static void compareHomeDeliveryOrderActualandExpected() {
		try {
			HomeDelivery_RootObject gson1 = (HomeDelivery_RootObject) getTestObject("rGSON");
			Assert.assertEquals(gson1.getdata().getDeliveryStartDateTime(), getTestString("DeliveryStart"));
			Assert.assertEquals(gson1.getdata().getDeliveryEndDateTime(), getTestString("DeliveryEnd"));
			Assert.assertEquals(gson1.getdata().getStatus(), getTestString("OrderStatus"));
			Assert.assertEquals(gson1.getdata().getSignatureRequired(), getTestString("SignatureRequired"));
			Assert.assertEquals(gson1.getdata().getAlcoholOrder(), getTestString("AlcoholOrder"));
			Assert.assertEquals(gson1.getdata().getNotes().get(0).getNote(), getTestString("Notes1"));
			Assert.assertEquals(gson1.getdata().getNotes().get(1).getNote(), getTestString("Notes2"));
			Assert.assertEquals(gson1.getdata().getNotes().get(2).getNote(), getTestString("Notes3"));
			Reporter.log("Editable fields are updated successfully!", MessageTypes.Pass);
		} catch (AssertionFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
	}
	
	public static void compareHomeDeliveryShiftsActualandExpected() {
		try {
			Shifts_Root gson1 = (Shifts_Root) getTestObject("rGSON");
			Assert.assertEquals(gson1.getData().getId(), getTestString("shifts.ShiftID"));	
			Reporter.log("Editable fields are updated successfully!", MessageTypes.Pass);
		} catch (AssertionFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
	}
	
	public static void compareHomeDeliveryGeocodeActualandExpected() {
		try {
			Geocode_RootObject gson1 = (Geocode_RootObject) getTestObject("rGSON");
			Assert.assertEquals(gson1.getData().getId(), getTestObject("GeoID"));

			Reporter.log("Editable fields are updated successfully!", MessageTypes.Pass);
		} catch (AssertionFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
	}

	public static void compareHomeDeliveryDriverActualandExpected() {
		try {
			Driver_Post gson1 = (Driver_Post) getTestObject("rGSON");
			Assert.assertEquals(gson1.getData().getName(), getTestObject("Updated_DriverName"));

			Reporter.log("Editable fields are updated successfully!", MessageTypes.Pass);
		} catch (AssertionFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
	}
	
	public static void compareHomeDeliveryDriverProfileActualandExpected() {
		try {
			DriversByProfileID_RootObject gson1 = (DriversByProfileID_RootObject) getTestObject("rGSON");
			Assert.assertEquals(gson1.getData().getFirstName(), getTestObject("Updated_DriverFirstName"));
			Assert.assertEquals(gson1.getData().getLastName(), getTestObject("Updated_DriverLastName"));
			Assert.assertEquals(String.valueOf(gson1.getData().getAllowSms()), ConfigurationManager.getBundle().getString("HomeDelivery.driverByProfile.allowSMS"));
			Assert.assertEquals(String.valueOf(gson1.getData().getAllowEmail()), ConfigurationManager.getBundle().getString("HomeDelivery.driverByProfile.allowEmail"));

			Reporter.log("Editable fields are updated successfully!", MessageTypes.Pass);
		} catch (AssertionFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
	}

	public static void compareHomeDeliveryZoneActualandExpected() {
		try {
			Zones_Post gson1 = (Zones_Post) getTestObject("rGSON");
			Assert.assertEquals(gson1.getData().getName(), getTestObject("Updated_ZoneName"));

			Reporter.log("Editable fields are updated successfully!", MessageTypes.Pass);
		} catch (AssertionFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
	}

	public static void compareHomeDeliveryCityActualandExpected() {
		try {
			Cities_Put gson1 = (Cities_Put) getTestObject("rGSON");
			Assert.assertEquals(gson1.getData().getName(), getTestObject("Updated_CityName"));

			Reporter.log("Editable fields are updated successfully!", MessageTypes.Pass);
		} catch (AssertionFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
	}
	
	public static void compareHomeDeliveryDispatcherActualandExpected() {
		try {
			Dispatchers_Post gson1 = (Dispatchers_Post) getTestObject("rGSON");
			Assert.assertEquals(gson1.getData().getName(), getTestObject("Updated_DispatchereName"));

			Reporter.log("Editable fields are updated successfully!", MessageTypes.Pass);
		} catch (AssertionFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
	}

	public static void GetAllDispatcherID() {
		ArrayList DispatcherList = new ArrayList<>();
		Dispatchers_RootObject gson1 = (Dispatchers_RootObject) getTestObject("rGSON");
		ArrayList<Dispatchers_Data> dispt_Data = gson1.getData();
		System.out.println("Total Dispatcher List count :"+ dispt_Data.size());
		Reporter.log("Total Dispatcher List count :"+ dispt_Data.size());
		for(Dispatchers_Data data : dispt_Data) {
			DispatcherList.add(data.getId());
		}
		System.out.println("Dispatcher List :"+ DispatcherList);
		Reporter.log("Dispatcher List :"+ DispatcherList);
		}

	

	public static String getAppMessage() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String appId = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "appmessage_" + appId.substring(3, appId.length());

	}

	public static int getrandumNumber() {
		Random rand = new Random();
		int n = rand.nextInt(50) + 1;
		return n;

	}
	
	public static int getrandumNumber(int num) {
		Random rand = new Random();
		int n = rand.nextInt(num);
		return n;

	}
	
public static void writeJSONreponse(String Response, String filename) throws IOException{
		
		FileWriter sample = new FileWriter("resources/JSON_Generated/"+filename +".json");
		
		sample.write(Response);
		sample.close();
		    	
	}

public static void validateJSONschema(String schemaname , String filename) throws ProcessingException, IOException{
	
	File schemaFile = new File("resources"+File.separator+"API_schema_validation"+File.separator+ schemaname +".json");
   
	File jsonFile = new File("resources"+File.separator+"JSON_Generated"+File.separator+filename +".json");
    System.out.println(schemaFile.getCanonicalPath());
    System.out.println(jsonFile.getCanonicalPath());
    if (ValidationUtils.isJsonValid(schemaFile, jsonFile)){
    	System.out.println("JSON validated successful");
    	Reporter.log("JSON validated successful", MessageTypes.Pass);
    }else{
    	System.out.println("JSON is NOT valid!");
    	Reporter.log("JSON validation Failed ", MessageTypes.Fail);
    	
    }
}
	
}
