package com.heb.automation.Services.HomeDelivery.Dispatchers;

public class Dispatchers_Data {
	
	private boolean isActive;

    private String id;

    private String organization;

    private String email;

    private String name;

    private String timeCreated;

    private String timeLastModified;

    public boolean getIsActive ()
    {
        return isActive;
    }

    public void setIsActive (boolean isActive)
    {
        this.isActive = isActive;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getOrganization ()
    {
        return organization;
    }

    public void setOrganization (String organization)
    {
        this.organization = organization;
    }

    public String getEmail ()
    {
        return email;
    }

    public void setEmail (String email)
    {
        this.email = email;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getTimeCreated ()
    {
        return timeCreated;
    }

    public void setTimeCreated (String timeCreated)
    {
        this.timeCreated = timeCreated;
    }

    public String getTimeLastModified ()
    {
        return timeLastModified;
    }

    public void setTimeLastModified (String timeLastModified)
    {
        this.timeLastModified = timeLastModified;
    }

}
