package com.heb.automation.Services.HomeDelivery.Shifts;

public class ShiftAssignments {
	
	 private String id;

	    private String lastModifiedTimestamp;

	    private String unassignedReason;

	    private ShiftsDriver driver;

	    private String assignedDateTime;

	    private String unassignedDateTime;

	    public String getId ()
	    {
	        return id;
	    }

	    public void setId (String id)
	    {
	        this.id = id;
	    }

	    public String getLastModifiedTimestamp ()
	    {
	        return lastModifiedTimestamp;
	    }

	    public void setLastModifiedTimestamp (String lastModifiedTimestamp)
	    {
	        this.lastModifiedTimestamp = lastModifiedTimestamp;
	    }

	    public String getUnassignedReason ()
	    {
	        return unassignedReason;
	    }

	    public void setUnassignedReason (String unassignedReason)
	    {
	        this.unassignedReason = unassignedReason;
	    }

	    public ShiftsDriver getDriver ()
	    {
	        return driver;
	    }

	    public void setDriver (ShiftsDriver driver)
	    {
	        this.driver = driver;
	    }

	    public String getAssignedDateTime ()
	    {
	        return assignedDateTime;
	    }

	    public void setAssignedDateTime (String assignedDateTime)
	    {
	        this.assignedDateTime = assignedDateTime;
	    }

	    public String getUnassignedDateTime ()
	    {
	        return unassignedDateTime;
	    }

	    public void setUnassignedDateTime (String unassignedDateTime)
	    {
	        this.unassignedDateTime = unassignedDateTime;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [id = "+id+", lastModifiedTimestamp = "+lastModifiedTimestamp+", unassignedReason = "+unassignedReason+", driver = "+driver+", assignedDateTime = "+assignedDateTime+", unassignedDateTime = "+unassignedDateTime+"]";
	    }

}
