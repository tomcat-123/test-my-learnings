package com.heb.automation.Pages.HD_WebApp.searchresult;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CitySearchResultpage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy (locator="CityResult.dropdown.select")
	private QAFWebElement ResultDropdown;
	
	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
	
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}
	
	public QAFWebElement getCityNameresult(int count) {

		String loc = String.format(pageProps.getString("CityResult.lbl.namevalue"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getCityZoneresult(int count) {

		String loc = String.format(pageProps.getString("CityResult.lbl.zonevalue"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getCityOnfleetresult(int count) {

		String loc = String.format(pageProps.getString("CityResult.lbl.onfleet"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getCityOfdriversresult(int count) {

		String loc = String.format(pageProps.getString("CityResult.lbl.ofdrivers"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getResultDropdown() {
		return ResultDropdown;
	}
	
	
}
