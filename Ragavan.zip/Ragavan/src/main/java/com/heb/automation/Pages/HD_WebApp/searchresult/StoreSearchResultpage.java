package com.heb.automation.Pages.HD_WebApp.searchresult;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class StoreSearchResultpage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}
	
	public QAFWebElement getStoreLnkNameresult(int count) {

		String loc = String.format(pageProps.getString("StoreResult.lnk.name"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getStoreStatusResult(int count) {

		String loc = String.format(pageProps.getString("StoreResult.lbl.status"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getStoreNameresult(int count) {

		String loc = String.format(pageProps.getString("StoreResult.lbl.name"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getStoreCorpId(int count) {

		String loc = String.format(pageProps.getString("StoreResult.lbl.corpid"), count);
		return new QAFExtendedWebElement(loc);
	}
}
