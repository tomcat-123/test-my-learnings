package com.heb.automation.Services.BodyParameter.Order.PUT_Order;

public class ProntoOrder {
	 private String id;

	    private String comsId;

	    public String getId ()
	    {
	        return id;
	    }

	    public void setId (String id)
	    {
	        this.id = id;
	    }

	    public String getComsId ()
	    {
	        return comsId;
	    }

	    public void setComsId (String comsId)
	    {
	        this.comsId = comsId;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [id = "+id+", comsId = "+comsId+"]";
	    }
}
