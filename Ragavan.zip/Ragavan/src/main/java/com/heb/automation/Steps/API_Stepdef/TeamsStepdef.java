package com.heb.automation.Steps.API_Stepdef;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.ErrorMessages.ErrorMessage;
import com.heb.automation.Services.BodyParameter.Teams.Teams_Body;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_Success;
import com.heb.automation.Services.HomeDelivery.ServiceUtils;
import com.heb.automation.Services.HomeDelivery.Teams.Teams_Post;
import com.heb.automation.Services.HomeDelivery.Teams.Teams_RootObject;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class TeamsStepdef extends TestDataContainer {

	
	@QAFTestStep(description = "Build URL for read all the HomeDelivery teams")
	public void buildURLForReadAllTheHomeDeliverTeams() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getTeams");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for read HomeDelivery team using teamId")
	public void buildURLForReadHomeDeliverTeamUsingTeamId() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getTeams") + "/"
				+ getTestString("TeamID");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for Creating HomeDelivery team")
	public void buildURLForCreatingHomeDeliveryTeam() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getTeams");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for Delete HomeDelivery team")
	public void buildURLForDeleteHomeDeliveryTeam() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getTeams") + "/"
				+ getTestString("TeamID");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for Delete HomeDelivery team with invalid Id")
	public void buildURLForDeleteHomeDeliveryTeamWithInvalidId() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getTeams") + "/Llh61RFjeqVXnnRFJRW6Nk";
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for creating HomeDelivery team")
	public void userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryTeam() throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getName());
		pr.setHub(null);
		pr.setId(null);
		pr.setManagers(null);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@SuppressWarnings("unchecked")
	@QAFTestStep(description = "User uses an array of Body Parameter with all values for creating HomeDelivery team")
	public void userUsesAnArrayOfBodyParameterWithAllValuesForCreatingHomeDeliveryTeam()
			throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();

		/*
		 * List<String> workers = new ArrayList<>(); List<String> managers = new
		 * ArrayList<>(); List<String> tasks = new ArrayList<>();
		 * 
		 * String worker1 = getTestString("DispatcherID"); String
		 * worker2 = getTestString("DispatcherID2"); String worker3 =
		 * getTestString("DispatcherID3");
		 * 
		 * workers.add(getTestString("DispatcherID"));
		 * managers.add(getTestString("DispatcherID"));
		 * tasks.add("G3fCaTlfCSUVv2sW*3pY9TAE");
		 * tasks.add("fJPOvPLD85LRHEQyMTbo3oso");
		 * tasks.add("K3~PYGcXb*amQtjTjX7IZK8I");
		 */

		List<String> batchPostDispatcherID = new ArrayList<>();
		List<String> batchPostDriverID = new ArrayList<>();	
		List<String> a = (List<String>) getTestObject("DispatcherIDList");
		List<String> b = (List<String>) getTestObject("DriverIDList");
		
		batchPostDispatcherID.addAll(a);
		batchPostDriverID.addAll(b);
		
		//batchPostDispatcherID = (List<String>) getTestObject("DispatcherIDList");
		// batchPostDispatcherID.add(getTestString("DispatcherIDList"));
		// batchPostDispatcherID.add(getTestObject("DispatcherIDList"));
		//batchPostDriverID = (List<String>) getTestObject("DriverIDList");
		// batchPostDriverID.add(getTestString("DriverIDList"));
		// batchPostDriverID.add(getTestObject("DriverIDList"));

		pr.setName(getName());
		pr.setHub(null);
		pr.setId(null);
		pr.setManagers(batchPostDispatcherID);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(batchPostDriverID);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses a Body Parameter with team name More than Fiftycharacters for creating HomeDelivery team")
	public void userUsesABodyParameterWithTeamNameMoreThanFiftycharactersForCreatingHomeDeliveryTeam()
			throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getNameMoreThan50Characters());
		pr.setHub(null);
		pr.setId(null);
		pr.setManagers(null);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses a Body Parameter with team ID More than Thirtycharacters for creating HomeDelivery team")
	public void userUsesABodyParameterWithTeamIDMoreThanThirtycharactersForCreatingHomeDeliveryTeam()
			throws JsonProcessingException {

		String thirtyCharTeamId = getTestString("TeamID") + "Invalid";
		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getName());
		pr.setHub(null);
		pr.setId(thirtyCharTeamId);
		pr.setManagers(null);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Missing Body Parameter for creating HomeDelivery team")
	public void userUsesAnArrayOfMissingBodyParameterForCreatingHomeDeliveryTeam() throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(null);
		pr.setHub(null);
		pr.setId(null);
		pr.setManagers(null);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(null);
		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Existing Body Parameter for creating HomeDelivery team")
	public void userUsesAnArrayOfExistingBodyParameterForCreatingHomeDeliveryTeam() throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getTestString("TeamName"));
		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Team body parameter contains all valid editable fields")
	public void userUPDATEHomeDeliveryTeamBodyParameterContainsAllValidEditableFields() throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getName());
		pr.setHub(null);
		pr.setId(getTestString("TeamID"));
		pr.setManagers(null);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Team body parameter contains only optional fields")
	public void userUPDATEHomeDeliveryTeamBodyParameterContainsOnlyOptionalFields() throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(null);
		pr.setHub(null);
		pr.setId(getTestString("TeamID"));
		pr.setManagers(null);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Team body parameter contains duplicate team name")
	public void userUPDATEHomeDeliveryTeamBodyParameterContainsDuplicateTeamName() throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getTestString("TeamName"));
		pr.setHub(null);
		pr.setId(getTestString("TeamID"));
		pr.setManagers(null);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User GET response call for HomeDelivery teams")
	public static void userGETResponseCallForHomeDeliverTeams() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Teams");
				putTestObject("rClient", rClient);

				Teams_RootObject gson1 = new Gson().fromJson(rClient.getEntity(String.class), Teams_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String TeamID = gson1.getData().get(0).getId();
				String TeamName = gson1.getData().get(0).getName();
				putTestObject("TeamID", TeamID);
				putTestObject("TeamName", TeamName);
				Reporter.log("Read Success-HomeDelivery Teams ID: " + TeamID);
				Reporter.log("Read Success-HomeDelivery Teams Name: " + TeamName);
				System.out.println("Read Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Read Success-HomeDelivery Teams Name: " + TeamName);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "User POST the Create HomeDelivery team call")
	public void userPOSTTheCreateHomeDeliveryTeamCall() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			RESPONSE = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + RESPONSE.getStatus());
			if (RESPONSE.getStatus() == 200) {

				Reporter.log("Teams is created ");
				putTestObject("rClient", RESPONSE);

				Teams_Post gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class), Teams_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String TeamID = gson1.getData().getId();
				String TeamName = gson1.getData().getName();
				putTestObject("TeamID", TeamID);
				putTestObject("TeamName", TeamName);
				Reporter.log("Created Success-HomeDelivery Teams ID: " + TeamID);
				Reporter.log("Created Success-HomeDelivery Teams Name: " + TeamName);
				System.out.println("Created Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Created Success-HomeDelivery Teams Name: " + TeamName);
			}
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("Team created with failed  " + 400);
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 503) {
				Reporter.log("Team created with failed  " + 503);
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User GET response call for Specific HomeDelivery teams")
	public static void userGETResponseCallForSpecificHomeDeliverTeams() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Teams");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Teams_Post gson1 = new Gson().fromJson(RESPONSE, Teams_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String TeamID = gson1.getData().getId();
				String TeamName = gson1.getData().getName();
				putTestObject("TeamID", TeamID);
				putTestObject("TeamName", TeamName);
				Reporter.log("Read Success-HomeDelivery Teams ID: " + TeamID);
				Reporter.log("Read Success-HomeDelivery Teams Name: " + TeamName);
				System.out.println("Read Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Read Success-HomeDelivery Teams Name: " + TeamName);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);
			String RESPONSE = rClient.getEntity(String.class);
			ErrorMessage json = new Gson().fromJson(RESPONSE, ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "User PUT the Update HomeDelivery Team call")
	public void userPUTTheUpdateHomeDeliveryTeamCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			rClient = ServiceUtils.PUT(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Team is updated ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Teams_Post gson1 = new Gson().fromJson(RESPONSE, Teams_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String TeamID = gson1.getData().getId();
				String TeamName = gson1.getData().getName();
				putTestObject("TeamID", TeamID);
				putTestObject("Updated_TeamName", TeamName);
				Reporter.log("Update Success-HomeDelivery Teams ID: " + TeamID);
				Reporter.log("Update Success-HomeDelivery Teams Name: " + TeamName);
				System.out.println("Update Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Update Success-HomeDelivery Teams Name: " + TeamName);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Team creation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery Team creation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery Teams creation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("HomeDelivery Teams creation failed  ");
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User DELETE the HomeDelivery Team DELETE call")
	public void userDELETETheHomeDeliveryTeamDELETECall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.DELETE(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("HomeDelivery Team is deleted ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				HomeDelivery_Success gson1 = new Gson().fromJson(RESPONSE,
						HomeDelivery_Success.class);
				putTestObject("rGSON", gson1);
				System.out.println(" : " + gson1.getApiStatus());
				Reporter.log("Deleted HomeDelivery Team : " + gson1.getApiStatus());
			}
			if (rClient.getStatus() == 207) {
				Reporter.log("HomeDelivery team Deletion with Partial success  ");
				putTestObject("rClient", rClient);
				ErrorMessage gson1 = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
				putTestObject("rGSON", gson1);
			}

			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery team Deletion failed with 400");
				putTestObject("rClient", rClient);
			}

			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery team Deletion failed with 404");
				putTestObject("rClient", rClient);
			}
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery team Deletion failed with 401");
				putTestObject("rClient", rClient);
			}
			if (rClient.getStatus() == 503) {
				Reporter.log("HomeDelivery team Deletion failed with 503");
				putTestObject("rClient", rClient);
			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery team Deletion failed with 400");
				putTestObject("rClient", rClient);
			}

		}
	}

	@QAFTestStep(description = "User POST the Create HomeDelivery team calls")
	public void userPOSTTheCreateHomeDeliveryTeamCalls() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Teams is created ");
				putTestObject("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class); 
				Teams_Post gson1 = new Gson().fromJson(RESPONSE, Teams_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String TeamID = gson1.getData().getId();
				String TeamName = gson1.getData().getName();
				putTestObject("TeamID", TeamID);
				Reporter.log("Created Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Created Success-HomeDelivery Teams ID: " + TeamID);

			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Team created with failed  " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("Team created with failed  " + 503);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	public static String getName() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "name_" + name.substring(3, name.length());

	}

	public static String getNameMoreThan50Characters() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "team name more than 50 characters in length should return an exception"
				+ name.substring(3, name.length());

	}

	@QAFTestStep(description = "validate the response schema with GET Teams")
	public static void validateTheResponseSchemaWithGETTeams() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Teams");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");

				Teams_RootObject gson1 = new Gson().fromJson(RESPONSE, Teams_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String TeamID = gson1.getData().get(0).getId();
				putTestObject("TeamID", TeamID);
				Reporter.log("Read Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Read Success-HomeDelivery Teams ID: " + TeamID);

				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "GET_TEAMS");
				HomeDelivery_ReusableUtils.validateJSONschema("Teams_GET", "GET_TEAMS");
			}
			if (rClient.getStatus() != 200) {
				Reporter.log("Team created with failed", MessageTypes.Fail);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "validate the response schema with GET Team")
	public static void validateTheResponseSchemaWithGETTeam() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Teams");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");

				Teams_Post gson1 = new Gson().fromJson(RESPONSE, Teams_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String TeamID = gson1.getData().getId();
				String TeamName = gson1.getData().getName();
				putTestObject("TeamID", TeamID);
				putTestObject("TeamName", TeamName);
				Reporter.log("Read Success-HomeDelivery Teams ID: " + TeamID);
				Reporter.log("Read Success-HomeDelivery Teams Name: " + TeamName);
				System.out.println("Read Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Read Success-HomeDelivery Teams Name: " + TeamName);

				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "GET_TEAM");
				HomeDelivery_ReusableUtils.validateJSONschema("Team_GET", "GET_TEAM");
			}
			if (rClient.getStatus() != 200) {
				Reporter.log("Team created with failed", MessageTypes.Fail);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "validate the response schema with POST Team")
	public void validateTheResponseSchemaWithPOSTTeam() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Teams is created ");
				putTestObject("rClient", rClient);

				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");

				Teams_Post gson1 = new Gson().fromJson(RESPONSE, Teams_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String TeamID = gson1.getData().getId();
				putTestObject("TeamID", TeamID);
				Reporter.log("Created Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Created Success-HomeDelivery Teams ID: " + TeamID);

				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "POST_TEAM");
				HomeDelivery_ReusableUtils.validateJSONschema("Team_POST", "POST_TEAM");

			}
			if (rClient.getStatus() != 200) {
				Reporter.log("Team created with failed", MessageTypes.Fail);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);
			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "validate the response schema with PUT Team")
	public void validateTheResponseSchemaWithPUTTeam() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			RESPONSE = ServiceUtils.PUT(headers, bodyParam);
			Reporter.log("Status :" + RESPONSE.getStatus());
			if (RESPONSE.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Team is updated ");
				putTestObject("rClient", RESPONSE);

				String StringResponse = RESPONSE.getEntity(String.class);
				putTestObject(StringResponse, "RESPONSE");

				Teams_Post gson1 = new Gson().fromJson(StringResponse, Teams_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String TeamID = gson1.getData().getId();
				putTestObject("TeamID", TeamID);
				Reporter.log("Update Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Update Success-HomeDelivery Teams ID: " + TeamID);

				HomeDelivery_ReusableUtils.writeJSONreponse(StringResponse, "PUT_TEAM");
				HomeDelivery_ReusableUtils.validateJSONschema("Team_PUT", "PUT_TEAM");

			}
			if (RESPONSE.getStatus() != 200) {
				Reporter.log("Team created with failed", MessageTypes.Fail);
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);
			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

}
