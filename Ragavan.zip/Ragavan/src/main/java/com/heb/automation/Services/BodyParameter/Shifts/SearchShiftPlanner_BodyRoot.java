package com.heb.automation.Services.BodyParameter.Shifts;

import java.util.ArrayList;

public class SearchShiftPlanner_BodyRoot {
	
	private ArrayList<SearchPlanner_SearchCriteria> searchCriteria;

    public ArrayList<SearchPlanner_SearchCriteria> getSearchCriteria ()
    {
        return searchCriteria;
    }

    public void setSearchCriteria (ArrayList<SearchPlanner_SearchCriteria> searchCriteria)
    {
        this.searchCriteria = searchCriteria;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [searchCriteria = "+searchCriteria+"]";
    }
	
}
