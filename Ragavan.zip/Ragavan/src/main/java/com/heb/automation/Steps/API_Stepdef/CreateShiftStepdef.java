package com.heb.automation.Steps.API_Stepdef;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.map.MultiValueMap;

import com.qmetry.qaf.automation.step.QAFTestStep;

public class CreateShiftStepdef {

	@QAFTestStep(description="User create Body Parameter for create shift")
	public void userCreateBodyParameterForCreateShift(){

/*		File inFile = new File("C:\\Users\\admin\\Desktop\\Yana-make-up.jpg");
=======
	/*	File inFile = new File("C:\\Users\\admin\\Desktop\\Yana-make-up.jpg");
>>>>>>> bcbb26d0f0d3aa43a82a62fa56b51f07093caa8b
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(inFile);
			DefaultHttpClient httpclient = new DefaultHttpClient(new BasicHttpParams());
			
			// server back-end URL
			HttpPost httppost = new HttpPost("http://localhost:8080/FileUploaderRESTService-1/rest/upload");
			MultipartEntity entity = new MultipartEntity();

			// set the file input stream and file name as arguments
			entity.addPart("file", new InputStreamBody(fis, inFile.getName()));
			httppost.setEntity(entity);

			// execute the request
			HttpResponse response = httpclient.execute(httppost);
			
			int statusCode = response.getStatusLine().getStatusCode();
			HttpEntity responseEntity = response.getEntity();
			String responseString = EntityUtils.toString(responseEntity, "UTF-8");
			
			System.out.println("[" + statusCode + "] " + responseString);
			
		} catch (ClientProtocolException e) {
			System.err.println("Unable to make connection");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Unable to read file");
			e.printStackTrace();
		} finally {
			try {
				if (fis != null) fis.close();
			} catch (IOException e) {}

		}*/
		
	}
}
