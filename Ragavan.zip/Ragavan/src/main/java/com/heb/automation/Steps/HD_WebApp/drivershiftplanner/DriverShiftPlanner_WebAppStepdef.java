package com.heb.automation.Steps.HD_WebApp.drivershiftplanner;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.heb.automation.Pages.HD_WebApp.CommonTestPage;
import com.heb.automation.Pages.HD_WebApp.drivershiftsplanner.DriverShiftsPlannerTestPage;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class DriverShiftPlanner_WebAppStepdef extends TestDataContainer {

	@QAFTestStep(description = "navigate to drivers shifts planner page")
	public void nAvigateToDriversShiftsPlannerPage() {
		CommonTestPage common = new CommonTestPage();

		common.getNavigationBtnHamburger().click();
		common.getNavigationLblDriverSnapshot().waitForPresent(1000);
		common.getNavigationLblDriver().click();
		common.getNavigationLblDriverShiftPlanner().waitForPresent(5000);
		common.getNavigationLblDriverShiftPlanner().click();
	}

	@QAFTestStep(description = "verify the shifts planner page search section")
	public void vErifyTheShiftsPlannerPageSearchSection() {
		DriverShiftsPlannerTestPage shiftPlanner = new DriverShiftsPlannerTestPage();

		shiftPlanner.getBtnAddNew().waitForPresent(5000);
		shiftPlanner.getBtnAddNew().verifyPresent();
		shiftPlanner.getLblTitle().verifyPresent();
		shiftPlanner.getBtnDriverCrumb().verifyPresent();
		shiftPlanner.getTxtZoneName().verifyPresent();
		shiftPlanner.getTxtDate().verifyPresent();
		shiftPlanner.getTxtPublishTimePicker().verifyPresent();
		shiftPlanner.getBtnOpenCalendar().verifyPresent();
		shiftPlanner.getBtnSearch().verifyPresent();
		shiftPlanner.getBtnReset().verifyPresent();
	}

	@QAFTestStep(description = "click on calendar icon in shifts planner page")
	public void cLickOnCalendarIconInShiftsPlannerPage() {
		DriverShiftsPlannerTestPage shiftPlanner = new DriverShiftsPlannerTestPage();

		shiftPlanner.getBtnOpenCalendar().click();
	}

	@QAFTestStep(description = "verify able to enter past date in shifts planner date field")
	public void vErifyAbleToEnterPastDateInShiftsPlannerDateField() {

		String selectedDate = getTestString("SelectedDate");
		System.out.println(selectedDate);

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("M/d/yyyy");
		LocalDateTime now = LocalDateTime.now();
		System.out.println(dtf.format(now));

		if (!selectedDate.equals(dtf.format(now)))
			PerfectoUtils.reportMessage("Able to enter past date in shifts planner date field", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not able to enter past date in shifts planner date field", MessageTypes.Fail);
	}

	@QAFTestStep(description = "verify able to enter future date in shifts planner date field")
	public void vErifyAbleToEnterFutureDateInShiftsPlannerDateField() {

		String selectedDate = getTestString("SelectedDate");
		System.out.println(selectedDate);

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("M/d/yyyy");
		LocalDateTime now = LocalDateTime.now();
		System.out.println(dtf.format(now));

		if (!selectedDate.equals(dtf.format(now)))
			PerfectoUtils.reportMessage("Able to enter future date in shifts planner date field", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not able to enter future date in shifts planner date field", MessageTypes.Fail);
	}
	
	@QAFTestStep(description = "verify the shifts planner page grid section")
	public void vErifyTheShiftsPlannerPageGridSection() {
		DriverShiftsPlannerTestPage shiftPlanner = new DriverShiftsPlannerTestPage();
		
		shiftPlanner.getLblZone().get(0).waitForPresent(5000);
		shiftPlanner.getLblZone().get(0).verifyPresent();
		shiftPlanner.getLblWeekOf().get(0).verifyPresent();
		shiftPlanner.getLblPublishDate().get(0).verifyPresent();
		shiftPlanner.getLblPublishDate().get(0).click();
		String monday = shiftPlanner.getLblDaysOfTheWeek().get(0).getText().toLowerCase();
		shiftPlanner.getLblDaysOfTheWeek().get(0).verifyPresent();
		shiftPlanner.getLblShift().get(0).verifyPresent();
		shiftPlanner.getLblDrivers().get(0).verifyPresent();
		//shiftPlanner.getBtnPlannerLessDrivers().get(0).verifyPresent();
		//shiftPlanner.getBtnPlannerMoreDrivers().get(0).verifyPresent();
		//shiftPlanner.getLblTime().get(0).verifyPresent();
		
		if(monday.equals("monday"))
			PerfectoUtils.reportMessage("Days of the week is getting Displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Days of the week is not getting Displayed", MessageTypes.Fail);
	}
	
	@QAFTestStep(description = "click on driver shifts planner crumb")
	public void cLickOnDriverShiftsPlannerCrumb() {
		DriverShiftsPlannerTestPage shiftPlanner = new DriverShiftsPlannerTestPage();
		
		shiftPlanner.getBtnDriverCrumb().click();
	}
	
	@QAFTestStep(description = "verify user navigate to drivers shifts planner page")
	public void vErifyUsernAvigateToDriversShiftsPlannerPage() {
		DriverShiftsPlannerTestPage shiftPlanner = new DriverShiftsPlannerTestPage();
		
		shiftPlanner.getLblTitle().waitForPresent(5000);
		shiftPlanner.getLblTitle().verifyPresent();
	}
}
