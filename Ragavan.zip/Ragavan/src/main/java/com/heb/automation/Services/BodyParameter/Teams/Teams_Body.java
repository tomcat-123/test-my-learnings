package com.heb.automation.Services.BodyParameter.Teams;

import java.util.List;

public class Teams_Body {
	
	 	private String id;

	    private List<String> managers;

	    private String name;

	    private String timeCreated;

	    private String tasks;

	    private String hub;

	    private List<String> workers;

	    private String timeLastModified;

	    public String getId ()
	    {
	        return id;
	    }

	    public void setId (String id)
	    {
	        this.id = id;
	    }

	    public List<String> getManagers ()
	    {
	        return managers;
	    }

	    public void setManagers (List<String> managers)
	    {
	        this.managers = managers;
	    }

	    public String getName ()
	    {
	        return name;
	    }

	    public void setName (String name)
	    {
	        this.name = name;
	    }

	    public String getTimeCreated ()
	    {
	        return timeCreated;
	    }

	    public void setTimeCreated (String timeCreated)
	    {
	        this.timeCreated = timeCreated;
	    }

	    public String getTasks ()
	    {
	        return tasks;
	    }

	    public void setTasks (String tasks)
	    {
	        this.tasks = tasks;
	    }

	    public String getHub ()
	    {
	        return hub;
	    }

	    public void setHub (String hub)
	    {
	        this.hub = hub;
	    }

	    public List<String> getWorkers ()
	    {
	        return workers;
	    }

	    public void setWorkers (List<String> workers)
	    {
	        this.workers = workers;
	    }

	    public String getTimeLastModified ()
	    {
	        return timeLastModified;
	    }

	    public void setTimeLastModified (String timeLastModified)
	    {
	        this.timeLastModified = timeLastModified;
	    }

}
