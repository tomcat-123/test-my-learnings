package com.heb.automation.Services.HomeDelivery.Drivers;

import java.util.List;

public class DriversByProfileID_City
{
	private String lastModifiedTimestamp;

    private int id;

    private String name;

    private boolean archived;

    private List<String> zones;

    private String mapLink;

    private int hourlyRate;

    private String tipsAndTricksIdOnfleet;

    private String parkingIdOnfleet;

    private int driverCount;

    public void setLastModifiedTimestamp(String lastModifiedTimestamp){
        this.lastModifiedTimestamp = lastModifiedTimestamp;
    }
    public String getLastModifiedTimestamp(){
        return this.lastModifiedTimestamp;
    }
    public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return this.id;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return this.name;
    }
    public void setArchived(boolean archived){
        this.archived = archived;
    }
    public boolean getArchived(){
        return this.archived;
    }
    public void setZones(List<String> zones){
        this.zones = zones;
    }
    public List<String> getZones(){
        return this.zones;
    }
    public void setMapLink(String mapLink){
        this.mapLink = mapLink;
    }
    public String getMapLink(){
        return this.mapLink;
    }
    public void setHourlyRate(int hourlyRate){
        this.hourlyRate = hourlyRate;
    }
    public int getHourlyRate(){
        return this.hourlyRate;
    }
    public void setTipsAndTricksIdOnfleet(String tipsAndTricksIdOnfleet){
        this.tipsAndTricksIdOnfleet = tipsAndTricksIdOnfleet;
    }
    public String getTipsAndTricksIdOnfleet(){
        return this.tipsAndTricksIdOnfleet;
    }
    public void setParkingIdOnfleet(String parkingIdOnfleet){
        this.parkingIdOnfleet = parkingIdOnfleet;
    }
    public String getParkingIdOnfleet(){
        return this.parkingIdOnfleet;
    }
    public void setDriverCount(int driverCount){
        this.driverCount = driverCount;
    }
    public int getDriverCount(){
        return this.driverCount;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [id = "+id+", lastModifiedTimestamp = "+lastModifiedTimestamp+", hourlyRate = "+hourlyRate+", archived = "+archived+", mapLink = "+mapLink+", name = "+name+", zones = "+zones+", driverCount = "+driverCount+", parkingIdOnfleet = "+parkingIdOnfleet+", tipsAndTricksIdOnfleet = "+tipsAndTricksIdOnfleet+"]";
    }
}