package com.heb.automation.Steps.HD_WebApp.city;

import java.util.Random;

import com.heb.automation.common.TestDataContainer;
import com.heb.automation.Pages.HD_WebApp.city.CityEditTestPage;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class CityEdit_WebAppStepdef extends TestDataContainer {

	@QAFTestStep(description = "enter hourly rate in edit city page")
	public void iEnterHourlyRateInEditCityPage() {
		CityEditTestPage cityDeit = new CityEditTestPage();

		cityDeit.getTxtHourlyRate().waitForPresent(1000);
		cityDeit.getTxtHourlyRate().click();
		cityDeit.getTxtHourlyRate().clear();
		int hourlyRate = generateRandomHourlrRate();
		String houRate = Integer.toString(hourlyRate);
		putTestObject("HourlyRate", houRate);
		cityDeit.getTxtHourlyRate().sendKeys(houRate);
	}
	
	@QAFTestStep(description = "enter map link in edit city page")
	public void iEnterMapLinkInEditCityPage() {
		CityEditTestPage cityDeit = new CityEditTestPage();

		cityDeit.getTxtMapLink().click();
		cityDeit.getTxtMapLink().clear();
		String mapLink = generaterandomMapLink();
		putTestObject("MapLink", mapLink);
		cityDeit.getTxtMapLink().sendKeys(mapLink);
	}
	
	@QAFTestStep(description = "click on save button in edit city page")
	public void iClickOnSaveButtonInEditCityPage() {
		CityEditTestPage cityDeit = new CityEditTestPage();

		cityDeit.getBtnSave().click();
	}
	
	@QAFTestStep(description = "click on cancel button in edit city page")
	public void iClickOnCancelButtonInEditCityPage() {
		CityEditTestPage cityDeit = new CityEditTestPage();

		cityDeit.getBtnCancel().click();
	}
	
	private String generaterandomMapLink() {
		
		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 6;
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();

		return "https://www.google.com/AutomationMapLink&"+generatedString;
	}

	private int generateRandomHourlrRate() {
		Random random = new Random();
		int hRate = random.nextInt(100);
		return hRate;
	}
}
