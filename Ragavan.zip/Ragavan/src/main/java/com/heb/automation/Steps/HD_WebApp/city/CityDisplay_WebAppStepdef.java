package com.heb.automation.Steps.HD_WebApp.city;

import java.util.Random;

import com.heb.automation.Pages.HD_WebApp.CommonTestPage;
import com.heb.automation.Pages.HD_WebApp.city.CityDisplayTestPage;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class CityDisplay_WebAppStepdef extends TestDataContainer {

	@QAFTestStep(description = "click on Delete button in city Display Page")
	public void iClickOnDeleteButtonInCityDisplayPage() {
		CityDisplayTestPage cityDisplay = new CityDisplayTestPage();

		cityDisplay.getCitydisplaybtndelete().waitForPresent(5000);
		cityDisplay.getCitydisplaybtndelete().click();

	}

	@QAFTestStep(description = "click Yes on the Delete Confirmation pop-up modal in city Display Page")
	public void iClickYesOnTheDeleteConfirmationPopUpModalInCityDisplayPage() {
		CityDisplayTestPage cityDisplay = new CityDisplayTestPage();

		cityDisplay.getCitydisplaylbldeleteconfirmation().waitForPresent();
		cityDisplay.getCitydisplaybtnyes().click();

	}

	@QAFTestStep(description = "click NO on the Delete Confirmation pop-up modal in city Display Page")
	public void iClickNoOnTheDeleteConfirmationPopUpModalInCityDisplayPage() {
		CityDisplayTestPage cityDisplay = new CityDisplayTestPage();

		cityDisplay.getCitydisplaylbldeleteconfirmation().waitForPresent();
		cityDisplay.getCitydisplaybtnno().click();

	}
	
	@QAFTestStep(description = "click on edit button in city display page")
	public void iClickOnEditButtonInCityDisplayPage() {
		CityDisplayTestPage cityDisplay = new CityDisplayTestPage();
		
		cityDisplay.getCitydisplaybtnedit().waitForPresent(1000);
		cityDisplay.getCitydisplaybtnedit().click();
	}

	@QAFTestStep(description = "verify display city page")
	public void iverifyDisplayCityPage() {
		CityDisplayTestPage cityDisplay = new CityDisplayTestPage();
		CommonTestPage common = new CommonTestPage();

		cityDisplay.getCitydisplaylbltitle().verifyPresent();
		common.getLblHomeIcon().verifyPresent();
		common.getLblHomeRightArrow().verifyPresent();
		cityDisplay.getCitydisplaybtndisplaycitycrumb().verifyPresent();
		cityDisplay.getCitydisplaybtndisplaycitycrumb().click();
		cityDisplay.getCitydisplaylbltitle().waitForPresent(1000);
		cityDisplay.getCitydisplaybtncancel().verifyPresent();
		cityDisplay.getCitydisplaybtndelete().verifyPresent();
		cityDisplay.getCitydisplaybtnedit().verifyPresent();
		cityDisplay.getCitydisplaytxfountainapproved().verifyPresent();
		cityDisplay.getCitydisplaytxtcityname().verifyPresent();
		cityDisplay.getCitydisplaytxtfountainfunnel().verifyPresent();
		cityDisplay.getCitydisplaytxtfountainrejected().verifyPresent();
		cityDisplay.getCitydisplaytxtfountaintips().verifyPresent();
		cityDisplay.getCitydisplaytxthourlyrate().verifyPresent();
		cityDisplay.getCitydisplaytxtmaplink().verifyPresent();
		cityDisplay.getCitydisplaytxtonfleetparking().verifyPresent();
		cityDisplay.getCitydisplaytxtonfleettips().verifyPresent();

		if (cityDisplay.getCitydisplaybtndisplaycitycrumb().getText()
				.equals(getTestString("SelectedCity")))
			PerfectoUtils.reportMessage("City Edit Crupm is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("City Edit Crupm is not displayed", MessageTypes.Fail);
	}
	
	@QAFTestStep(description = "verify city displays updated information")
	public void iVerifyCityDisplaysUpdatedInformation() {
		CityDisplayTestPage cityDisplay = new CityDisplayTestPage();
		
		String updatedHourlyRate = cityDisplay.getCitydisplaytxthourlyrate().getAttribute("value");
		String updatedMapLink = cityDisplay.getCitydisplaytxtmaplink().getAttribute("value");
		
		if(updatedHourlyRate.equals(getTestString("HourlyRate")))
			PerfectoUtils.reportMessage("Hourly Rate is updated", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Hourly Rate is not updated", MessageTypes.Fail);
		
		if(updatedMapLink.equals(getTestString("MapLink")))
			PerfectoUtils.reportMessage("MapLink is updated", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("MapLink is not updated", MessageTypes.Fail);			
	}
	
	@QAFTestStep(description = "verify city does not display updated information")
	public void iVerifyCityDoesNotDisplayUpdatedInformation() {
		CityDisplayTestPage cityDisplay = new CityDisplayTestPage();
		
		String updatedHourlyRate = cityDisplay.getCitydisplaytxthourlyrate().getAttribute("value");
		String updatedMapLink = cityDisplay.getCitydisplaytxtmaplink().getAttribute("value");
		
		if(!updatedHourlyRate.equals(getTestString("HourlyRate")))
			PerfectoUtils.reportMessage("Hourly Rate is not updated", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Hourly Rate is updated", MessageTypes.Fail);
		
		if(!updatedMapLink.equals(getTestString("MapLink")))
			PerfectoUtils.reportMessage("MapLink is not updated", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("MapLink is updated", MessageTypes.Fail);		
	}
	
	@QAFTestStep(description = "verify city displays information entered during creation")
	public void iVerifyCityDisplaysInformationEnteredDuringCreation() {
		CityDisplayTestPage cityDisplay = new CityDisplayTestPage();
		
		cityDisplay.getCitydisplaytxthourlyrate().waitForPresent(5000);
		
		String updatedHourlyRate = cityDisplay.getCitydisplaytxthourlyrate().getAttribute("value");
		String updatedMapLink = cityDisplay.getCitydisplaytxtmaplink().getAttribute("value");
		String cityName = cityDisplay.getCitydisplaytxtcityname().getAttribute("value");
		
		if(updatedHourlyRate.equals(getTestString("CreatedHourlyRate")))
			PerfectoUtils.reportMessage("Hourly Rate is updated", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Hourly Rate is not updated", MessageTypes.Fail);
		
		if(updatedMapLink.equals(getTestString("CreatedMapLink")))
			PerfectoUtils.reportMessage("MapLink is updated", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("MapLink is not updated", MessageTypes.Fail);
		
		if(cityName.equals(getTestString("CityName")))
			PerfectoUtils.reportMessage("City is updated", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("City is not updated", MessageTypes.Fail);
				
	}

	@QAFTestStep(description = "verify fields are not editable in display city page")
	public void iVerifyFieldsAreNotEditableInDisplayCityPage() {
		CityDisplayTestPage cityDisplay = new CityDisplayTestPage();
		
		String cityName = "Automation"+generateRandomString();
		cityDisplay.getCitydisplaytxtcityname().click();
		cityDisplay.getCitydisplaytxtcityname().sendKeys(cityName);
		
		String fountainApprove = generateRandomString();
		cityDisplay.getCitydisplaytxfountainapproved().click();
		cityDisplay.getCitydisplaytxfountainapproved().sendKeys(fountainApprove);
		
		String fountainFunnel = generateRandomString();
		cityDisplay.getCitydisplaytxtfountainfunnel().click();
		cityDisplay.getCitydisplaytxfountainapproved().sendKeys(fountainFunnel);
		
		String fountainRejected = generateRandomString();
		cityDisplay.getCitydisplaytxtfountainrejected().click();
		cityDisplay.getCitydisplaytxtfountainrejected().sendKeys(fountainRejected);
		
		String fountainTips = generateRandomString();
		cityDisplay.getCitydisplaytxtfountaintips().click();
		cityDisplay.getCitydisplaytxtfountaintips().sendKeys(fountainTips);
		
		String horlyRate = generateRandomString();
		cityDisplay.getCitydisplaytxthourlyrate().click();
		cityDisplay.getCitydisplaytxthourlyrate().sendKeys(horlyRate);
		
		String mapLink = generateRandomString();
		cityDisplay.getCitydisplaytxtmaplink().click();
		cityDisplay.getCitydisplaytxtmaplink().sendKeys(mapLink);
		
		String fleetParking = generateRandomString();
		cityDisplay.getCitydisplaytxtonfleetparking().click();
		cityDisplay.getCitydisplaytxtonfleetparking().sendKeys(fleetParking);
		
		String fleetTips = generateRandomString();
		cityDisplay.getCitydisplaytxtonfleettips().click();
		cityDisplay.getCitydisplaytxtonfleettips().sendKeys(fleetTips);
		
		if(!cityName.contains(cityDisplay.getCitydisplaytxtcityname().getAttribute("value")))
			PerfectoUtils.reportMessage("City is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("City is editable", MessageTypes.Fail);
		
		if(!fountainApprove.contains(cityDisplay.getCitydisplaytxfountainapproved().getAttribute("value")))
			PerfectoUtils.reportMessage("Fountain Approve is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Fountain Approve is editable", MessageTypes.Fail);
		
		if(!fountainFunnel.contains(cityDisplay.getCitydisplaytxtfountainfunnel().getAttribute("value")))
			PerfectoUtils.reportMessage("Fountain Funnel is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Fountain Funnel is editable", MessageTypes.Fail);
		
		if(!fountainRejected.contains(cityDisplay.getCitydisplaytxtfountainrejected().getAttribute("value")))
			PerfectoUtils.reportMessage("Fountain Rejected is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Fountain Rejected is editable", MessageTypes.Fail);
		
		if(!fountainTips.contains(cityDisplay.getCitydisplaytxtfountaintips().getAttribute("value")))
			PerfectoUtils.reportMessage("Fountain Tips is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Fountain Tips is editable", MessageTypes.Fail);
		
		if(!horlyRate.contains(cityDisplay.getCitydisplaytxthourlyrate().getAttribute("value")))
			PerfectoUtils.reportMessage("HorlyRate is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("HorlyRate Tips is editable", MessageTypes.Fail);
		
		if(!mapLink.equals(cityDisplay.getCitydisplaytxtmaplink().getAttribute("value")))
			PerfectoUtils.reportMessage("MapLink is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("MapLink is editable", MessageTypes.Fail);
		
		if(!fleetParking.contains(cityDisplay.getCitydisplaytxtonfleetparking().getAttribute("value")))
			PerfectoUtils.reportMessage("FleetParking is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("FleetParking is editable", MessageTypes.Fail);
		
		if(!fleetTips.contains(cityDisplay.getCitydisplaytxtonfleettips().getAttribute("value")))
			PerfectoUtils.reportMessage("FleetTips is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("FleetTips is editable", MessageTypes.Fail);
	}
	
	public static String generateRandomString() {

		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 6;
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();

		return "Automation_"+generatedString;

	}
}