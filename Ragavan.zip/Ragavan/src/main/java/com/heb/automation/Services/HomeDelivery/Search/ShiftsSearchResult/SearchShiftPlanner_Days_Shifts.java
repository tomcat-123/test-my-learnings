package com.heb.automation.Services.HomeDelivery.Search.ShiftsSearchResult;

public class SearchShiftPlanner_Days_Shifts {
	
	 private String startTime;

	    private String id;

	    private String slots;

	    private String endTime;

	    public String getStartTime ()
	    {
	        return startTime;
	    }

	    public void setStartTime (String startTime)
	    {
	        this.startTime = startTime;
	    }

	    public String getId ()
	    {
	        return id;
	    }

	    public void setId (String id)
	    {
	        this.id = id;
	    }

	    public String getSlots ()
	    {
	        return slots;
	    }

	    public void setSlots (String slots)
	    {
	        this.slots = slots;
	    }

	    public String getEndTime ()
	    {
	        return endTime;
	    }

	    public void setEndTime (String endTime)
	    {
	        this.endTime = endTime;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [startTime = "+startTime+", id = "+id+", slots = "+slots+", endTime = "+endTime+"]";
	    }

}
