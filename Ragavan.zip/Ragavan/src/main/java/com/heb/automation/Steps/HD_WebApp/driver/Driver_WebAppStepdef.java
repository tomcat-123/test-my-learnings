package com.heb.automation.Steps.HD_WebApp.driver;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.heb.automation.Pages.HD_WebApp.CommonTestPage;
import com.heb.automation.Pages.HD_WebApp.driver.DriverTestPage;
import com.heb.automation.Pages.HD_WebApp.searchresult.DriverSearchResultpage;
import com.heb.automation.Pages.HD_WebApp.searchresult.SearchResultPage;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class Driver_WebAppStepdef extends TestDataContainer {

	@QAFTestStep(description = "User is in HomeDelivery driver page")
	public void UserIsInHomeDeliveryDriverPage() {
		DriverTestPage driverpage = new DriverTestPage();
		driverpage.getLblPagetitle().waitForPresent(10000 * 3);
		driverpage.getLblPagetitle().isDisplayed();
		PerfectoUtils.reportMessage("User is in HomeDelivery driver page ", MessageTypes.Pass);
	}

	@QAFTestStep(description = "enter date in date field")
	public void eNterDateInDateField() {
		DriverTestPage driverpage = new DriverTestPage();
		String Currentdate = null;
		driverpage.getTxtCurrentDate().clear();
		driverpage.getTxtCurrentDate().sendKeys(getTestString("HomeDelivery.searchdate"));
		Currentdate = driverpage.getTxtCurrentDate().getAttribute("ng-reflect-model");
		Currentdate = Currentdate.substring(3, 15).trim();
		putTestObject("Currentdate", Currentdate);
		System.out.println(Currentdate);
	}

	@QAFTestStep(description = "enter valid firstName")
	public void eNterValidFirstName() {
		DriverTestPage driverpage = new DriverTestPage();

		driverpage.getTxtFirstname().sendKeys(getTestString("HomeDelivery.FirstName"));
	}

	@QAFTestStep(description = "enter valid FirstName with 3 Characters")
	public void iEnterValidFirstNameWith3Characters() {
		DriverTestPage driverpage = new DriverTestPage();

		driverpage.getTxtFirstname()
				.sendKeys(getTestString("HomeDelivery.FirstName3Characters"));
	}

	@QAFTestStep(description = "enter valid lastName")
	public void iEnterValidLastName() {
		DriverTestPage driverpage = new DriverTestPage();

		driverpage.getTxtLastname().sendKeys(getTestString("HomeDelivery.LastName"));
	}

	@QAFTestStep(description = "verify the search result for FirstName")
	public void vErifyTheSearchResultForFirstName() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		DriverSearchResultpage DriverResult = new DriverSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String FirstNameDisplayed = DriverResult.getDriverFirstNameresult(Rowcount).getText();

			if (FirstNameDisplayed.equals(getTestString("HomeDelivery.FirstName"))) {

				PerfectoUtils.reportMessage("FirstName matches with the search result", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("FirstName Does not matches with the search result", MessageTypes.Fail);
			}

			Rowcount++;
		}
		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("FirstName Does not return any result", MessageTypes.Fail);

	}

	@QAFTestStep(description = "verify the search result for LastName")
	public void vErifyTheSearchResultForLastName() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		DriverSearchResultpage DriverResult = new DriverSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String LastNameDisplayed = DriverResult.getDriverLastNameresult(Rowcount).getText();

			if (LastNameDisplayed.equals(getTestString("HomeDelivery.LastName"))) {

				PerfectoUtils.reportMessage("LastName matches with the search result", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("LastName Does not matches with the search result", MessageTypes.Fail);
			}

			Rowcount++;
		}

		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("LasttName Does not return any result", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I press enter key")
	public void iPressEnterKey() {

		PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.ENTER);
	}

	@QAFTestStep(description = "I enter valid LastName with 2 Characters")
	public void iEnterValidLastNameWith2Characters() {
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getTxtLastname()
				.sendKeys(getTestString("HomeDelivery.LastName2Characters"));
	}

	@QAFTestStep(description = "I see the search result for LastName with 2 Characters")
	public void iSeeTheSearchResultForLastNameWith2Characters() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		DriverSearchResultpage DriverResult = new DriverSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String LastNameDisplayed = DriverResult.getDriverLastNameresult(Rowcount).getText();

			if (LastNameDisplayed
					.contains(getTestString("HomeDelivery.LastName2Characters"))) {

				PerfectoUtils.reportMessage("LastName matches with the search result", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("LastName Does not matches with the search result", MessageTypes.Fail);
			}

			Rowcount++;
		}

		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("LasttName Does not return any result", MessageTypes.Fail);
	}

	@QAFTestStep(description = "verify date field defaults to current date")
	public void iVerifyDateFieldDefaultsToCurrentDate() {
		String Currentdate = null;
		DriverTestPage driverTP = new DriverTestPage();

		Currentdate = driverTP.getTxtCurrentDate().getAttribute("ng-reflect-model");
		Currentdate = Currentdate.substring(0, 15);
		System.out.println(Currentdate);

		SimpleDateFormat formatter = new SimpleDateFormat("E MMM dd yyyy");
		Date date = new Date();
		System.out.println(formatter.format(date));

		if (Currentdate.equals(formatter.format(date)))
			PerfectoUtils.reportMessage("The date field is default To CurrentDate", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("The date field is not default To CurrentDate", MessageTypes.Fail);
	}

	@QAFTestStep(description = "verify past date is not allowed")
	public void iVerifyPastDateIsNotAllowed() {
		DriverTestPage driverTP = new DriverTestPage();

		try {
			driverTP.getBtnOpencalendar().click();
			int size = driverTP.getLblPastDate().size();
			if (driverTP.getLblPastDate().get(0).isPresent()) {
				driverTP.getLblPastDate().get(size - 1).click();
				driverTP.getLblPastDate().get(size - 1).verifyPresent();
			} else {
				int size1 = driverTP.getLblPastDate().size();
				driverTP.getBtnPreviousMonth().click();
				driverTP.getLblPastDate().get(0).waitForPresent(5000);
				driverTP.getLblPastDate().get(size1 - 1).click();
				driverTP.getLblPastDate().get(size1 - 1).verifyPresent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@QAFTestStep(description = "Verify breadcrumb is available")
	public void iVerifyBreadCrumbIsAvailable() {
		DriverTestPage driverTP = new DriverTestPage();
		CommonTestPage commonPage = new CommonTestPage();

		driverTP.getBtnDriverCrumb().verifyPresent();
		commonPage.getLblHomeRightArrow().verifyPresent();
		commonPage.getLblHomeIcon().verifyPresent();
		commonPage.getLblHomeIcon().click();
		driverTP.getTxtFirstname().waitForPresent(5000);
		driverTP.getBtnDriverCrumb().click();
		commonPage.getLblHomeIcon().waitForPresent(5000);
		driverTP.getTxtFirstname().waitForPresent(5000);
		driverTP.getTxtFirstname().verifyPresent();
	}

	@QAFTestStep(description = "I clear data from date field")
	public void iClearDataFromDateField() {
		DriverTestPage driverTP = new DriverTestPage();
		// driverTP.getLblCurrentDate().click();
		driverTP.getTxtCurrentDate().clear();
		PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.TAB);

	}

	@QAFTestStep(description = "I verify search button is disabled")
	public void iVerifySearchButtonIsDisabled() {
		DriverTestPage driverTP = new DriverTestPage();
		CommonTestPage common = new CommonTestPage();

		boolean search = common.getBtnSearch().isEnabled();

		if (search == false)
			PerfectoUtils.reportMessage("Search Button is Disabled", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Search Button is not Disabled", MessageTypes.Fail);
	}

	@QAFTestStep(description = "verify the Driver Snapshot Page")
	public void iVerifyTheDriverSnapshotPage() {
		DriverTestPage driverTP = new DriverTestPage();
		SearchResultPage sResult = new SearchResultPage();
		ArrayList<String> data = new ArrayList<>();

		driverTP.getLblPagetitle().verifyPresent();
		driverTP.getBtnDriverCrumb().verifyPresent();
		driverTP.getLnkPaginationNum().verifyPresent();
		driverTP.getLblPagetitle().verifyPresent();
		driverTP.getLblFirstName().verifyPresent();
		driverTP.getLblLastname().verifyPresent();
		driverTP.getLblDate().verifyPresent();
		driverTP.getLblZone().verifyPresent();

		for (QAFWebElement rCount : sResult.getTableColumnName()) {

			data.add(rCount.getText());
		}

		if (data.contains("First Name"))
			PerfectoUtils.reportMessage("First Name is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("First Name is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Last Name"))
			PerfectoUtils.reportMessage("Last Name is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Last Name is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Phone Number"))
			PerfectoUtils.reportMessage("Phone Number is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Phone Number is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Date"))
			PerfectoUtils.reportMessage("Date is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Date is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Zone"))
			PerfectoUtils.reportMessage("Zone is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Zone is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Shift Time"))
			PerfectoUtils.reportMessage("Shift Time is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Shift Time is not Avilable in Grid", MessageTypes.Fail);

	}

	@QAFTestStep(description = "verify the Left navigation")
	public void iVerifyTheLeftNavigation() {
		CommonTestPage common = new CommonTestPage();

		common.getNavigationBtnHamburger().click();
		common.getNavigationLblDriverSnapshot().waitForPresent(1000);
		common.getNavigationLblDriverSnapshot().verifyPresent();
		common.getNavigationLblZoneConfiguration().click();
		common.getNavigationLblZone().waitForPresent(1000);
		common.getNavigationLblZone().verifyPresent();
		common.getNavigationLblCity().verifyPresent();
		common.getNavigationLblMessaging().verifyPresent();
		common.getNavigationLblOrder().verifyPresent();
		common.getNavigationLblDriver().click();
		common.getNavigationLblDriverTimeSheet().waitForPresent(1000);
		common.getNavigationLblDriverTimeSheet().verifyPresent();
	}

	@QAFTestStep(description = "select a zone")
	public void iSelectAZone() {
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getTxtZone().click();
		System.out.println("Zone Selected :" + getTestString("HomeDelivery.SelectZone"));
		PerfectoUtils.reportMessage(
				"Zone Selected :" + getTestString("HomeDelivery.SelectZone"));
		driverTP.getZoneValue(getTestString("HomeDelivery.SelectZone"))
				.waitForVisible(5000);
		driverTP.getZoneValue(getTestString("HomeDelivery.SelectZone")).click();
	}

	@QAFTestStep(description = "verify Selected zone returns matching search results")
	public void iVerifyZoneReturnsMatchingSearchResults() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		DriverSearchResultpage DriverResult = new DriverSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String ZoneDisplayed = DriverResult.getDriverZoneresult(Rowcount).getText();

			if (ZoneDisplayed.equals(getTestString("HomeDelivery.SelectZone"))) {

				PerfectoUtils.reportMessage("Zone matches with the search result", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Zone Does not matches with the search result", MessageTypes.Fail);
			}

			Rowcount++;
		}

		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("Zone Does not return any result", MessageTypes.Fail);
	}

	@QAFTestStep(description = "select a new zone")
	public void iSelectANewZone() {
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getTxtZone().click();
		driverTP.getNewZoneValue(getTestString("HomeDelivery.SelectNewZone"))
				.waitForPresent(1000);
		driverTP.getNewZoneValue(getTestString("HomeDelivery.SelectNewZone")).click();

	}

	@QAFTestStep(description = "verify changing zone updates search results")
	public void iVerifyChangingZoneUpdatesSearchResults() {
		SearchResultPage sResult = new SearchResultPage();
		DriverSearchResultpage DriverResult = new DriverSearchResultpage();
		int Rowcount = 1;

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String ZoneDisplayed = DriverResult.getDriverZoneresult(Rowcount).getText();

			if (!ZoneDisplayed.equals(getTestString("HomeDelivery.SelectZone"))) {

				PerfectoUtils.reportMessage("Zone matches with the search result", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Zone Does not matches with the search result", MessageTypes.Fail);
			}

			Rowcount++;
		}
	}

	@QAFTestStep(description = "click reset button")
	public void iClickResetButton() {

		/*
		 * PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.TAB);
		 * PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.TAB);
		 * PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.TAB);
		 * PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.ENTER);
		 */

		CommonTestPage commonPage = new CommonTestPage();
		// Thread.sleep(50000);
		commonPage.getBtnReset().click();
	}

	@QAFTestStep(description = "verify click of reset button clears search criteria")
	public void iVerifyClickOfResetButtonClearsSearchCriteria() {

		DriverTestPage driverTP = new DriverTestPage();

		if (driverTP.getTxtFirstname().getText().equals(""))
			PerfectoUtils.reportMessage("First Name is Cleared", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("First Name is not Cleared", MessageTypes.Fail);

		if (driverTP.getTxtLastname().getText().equals(""))
			PerfectoUtils.reportMessage("Last Name is Cleared", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Last Name is not Cleared", MessageTypes.Fail);

		driverTP.getTxtZoneempty().isPresent();

	}

	@QAFTestStep(description = "I Select a future date in Calender")
	public void iSelectAFutureDateInCalender() {
		DriverTestPage driverTP = new DriverTestPage();
		CommonTestPage common = new CommonTestPage();
		String Currentdate = null;

		driverTP.getBtnOpencalendar().click();
		driverTP.getLblFutureDate().get(0).click();
		common.getLblTableBody().waitForPresent(1000);
		Currentdate = driverTP.getTxtCurrentDate().getAttribute("ng-reflect-model");
		Currentdate = Currentdate.substring(0, 15);
		putTestObject("Currentdate", Currentdate);
		System.out.println(Currentdate);

	}

	@QAFTestStep(description = "I press enter key for date")
	public void iPressEnterKeyForDate() {
		// PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.TAB);
		// PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.TAB);
		PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.ENTER);
	}

	@QAFTestStep(description = "verify the search result for search by date")
	public void vErifyTheSearchResultForSearchByDate() throws ParseException, InterruptedException {
		int Rowcount = 1;
		DriverTestPage driverTP = new DriverTestPage();
		CommonTestPage common = new CommonTestPage();
		SearchResultPage sResult = new SearchResultPage();
		DriverSearchResultpage DriverResult = new DriverSearchResultpage();

		Thread.sleep(5000);
		driverTP.waitForPageToLoad();
		common.getLblTableBody().verifyPresent();
		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String ZoneDisplayed = DriverResult.getDriverDateresult(Rowcount).getText();

			Date formatter = new SimpleDateFormat("E, MMM dd, yyyy").parse(ZoneDisplayed);
			String date = formatter.toString();
			date = date.substring(4, 11) + date.substring(24, 28);
			System.out.println(date);

			if (date.equals(getTestString("Currentdate"))) {

				PerfectoUtils.reportMessage("Date matches with the search result", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Date Does not matches with the search result", MessageTypes.Fail);
			}

			Rowcount++;
		}

		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("LasttName Does not return any result", MessageTypes.Fail);

	}

	@QAFTestStep(description = "verify drivers sorted by the Shift Time")
	public void iVerifyDriversSortedByTheShiftTime() throws ParseException {
		long temp1 = 0;
		int Rowcount = 1;
		String ShiftDisplayed = null;
		SearchResultPage sResult = new SearchResultPage();
		DriverSearchResultpage DriverResult = new DriverSearchResultpage();

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(rCount.getText());

			ShiftDisplayed = DriverResult.getDriverShiftresult(Rowcount).getText();

			String s2[] = ShiftDisplayed.split("to");
			String n1 = s2[0];

			DateFormat formatter = new SimpleDateFormat("HH:mm aa");

			Date begins1 = (Date) formatter.parse(n1);
			long startTime = begins1.getTime();

			if (temp1 != 0 && n1.contains("AM")) {

				if (startTime >= temp1) {

					PerfectoUtils.reportMessage("Drivers sorted by the Shift Time", MessageTypes.Pass);

				} else {
					PerfectoUtils.reportMessage("Drivers sorted by the Shift Time", MessageTypes.Fail);
				}

			}

			if (temp1 != 0 && n1.contains("PM")) {

				if (startTime <= temp1) {

					PerfectoUtils.reportMessage("Drivers sorted by the Shift Time", MessageTypes.Pass);

				} else {
					PerfectoUtils.reportMessage("Drivers not sorted by the Shift Time", MessageTypes.Info);
				}

			}

			temp1 = startTime;
			Rowcount++;
		}
	}

	@QAFTestStep(description = "verify Driver Snapshot page does not display completed shifts")
	public void iVerifyDriverSnapshotPageDoesNotDisplayCompletedShifts() throws ParseException {
		long systemTime;
		int Rowcount = 1;
		Date date = null;
		String output;
		String ShiftDisplayed = null;
		SearchResultPage sResult = new SearchResultPage();
		DriverSearchResultpage DriverResult = new DriverSearchResultpage();

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(rCount.getText());

			ShiftDisplayed = DriverResult.getDriverShiftresult(Rowcount).getText();

			String s2[] = ShiftDisplayed.split("to");
			String n1 = s2[0];

			DateFormat formatter = new SimpleDateFormat("hh:mm aa");
			DateFormat outputformat = new SimpleDateFormat("HH:mm");

			date = formatter.parse(n1);
			output = outputformat.format(date);

			Date begins1 = null;
			DateFormat sf = new SimpleDateFormat("HH:mm");

			begins1 = (Date) sf.parse(output);

			long startTime = begins1.getTime();

			Date dateobj = new Date();
			String system = sf.format(dateobj);

			Date temp = null;

			temp = (Date) sf.parse(system);
			systemTime = temp.getTime();

			if (systemTime < startTime) {

				PerfectoUtils.reportMessage("Closed shift times are Not Displayed", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Closed shift times are Displayed", MessageTypes.Fail);
			}
			Rowcount++;
		}

		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("No Records Found in Current Date", MessageTypes.Pass);

	}

	@QAFTestStep(description = "verify drivers sorted by the shortest shift")
	public void iVerifyDriversSortedByTheShortestShift() throws ParseException {
		String data = null;
		int Rowcount = 1;
		String data1 = null;
		long temp = 0;
		CommonTestPage common = new CommonTestPage();
		SearchResultPage sResult = new SearchResultPage();
		DriverSearchResultpage DriverResult = new DriverSearchResultpage();

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(rCount.getText());

			data = DriverResult.getDriverShiftresult(Rowcount).getText();

			if (Rowcount < sResult.getTableRowList().size() - 1) {
				data1 = DriverResult.getDriverShiftresult(Rowcount + 1).getText();
			}
			String s2[] = data.split("to");
			String n1 = s2[0];
			String n2 = s2[1];

			String s3[] = data1.split("to");
			String n3 = s3[0];

			DateFormat formatter = new SimpleDateFormat("HH:mm aa");

			Date begins1 = (Date) formatter.parse(n1);
			Date begins2 = (Date) formatter.parse(n2);
			long diffMs = begins2.getTime() - begins1.getTime();

			if (diffMs >= temp) {
				PerfectoUtils.reportMessage("Drivers sorted by the shortest shift", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Drivers not sorted by the shortest shift", MessageTypes.Fail);

			}

			if (n3.equals(n1))
				temp = diffMs;
			else
				temp = 0;
		}
	}

	@QAFTestStep(description = "verify shift times are displayed in Civilian time format")
	public void iVerifyShiftTimesAreDisplayedInCivilianTimeFormat() throws ParseException {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		DriverSearchResultpage DriverResult = new DriverSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String ShiftTimeDisplayed = DriverResult.getDriverShiftresult(Rowcount).getText();

			if (ShiftTimeDisplayed.contains("AM to"))
				PerfectoUtils.reportMessage("Shif time is in Civilian Format", MessageTypes.Pass);
			else if (ShiftTimeDisplayed.contains("PM to"))
				PerfectoUtils.reportMessage("Shif time is in Civilian Format", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Shif time is not in Civilian Format", MessageTypes.Fail);

			Rowcount++;
		}

		String data = null;
		CommonTestPage common = new CommonTestPage();

		QAFWebElement tobody = common.getLblTableBody();
		List<WebElement> rows = tobody.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("td"));
			for (int cnum = 5; cnum < columns.size(); cnum++) {
				data = columns.get(cnum).getText();

			}
		}
	}

	@QAFTestStep(description = "Verify available Zones match with phd_zones table")
	public void iVerifyAvailableZonesMatchWithPhdZonesTable() {
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getDropdownZone().click();
		driverTP.getDropdownZoneoptions().get(0).waitForPresent(1000);
		int availableOptions = driverTP.getDropdownZoneoptions().size();

	}

	@QAFTestStep(description = "verify type ahead displays upto 10 results")
	public void vErifyTypeaHeadDisplaysUpto10Results() {
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getFirstNameTypeHead().get(0).waitForPresent(5000);

		int typeHeadSize = driverTP.getFirstNameTypeHead().size();

		if (typeHeadSize <= 10)
			PerfectoUtils.reportMessage("Typeahead displays upto 10 or Less results", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Typeahead displays More than 10 results", MessageTypes.Fail);
	}

	@QAFTestStep(description = "select a result from type ahead")
	public void sElectAResultFromTypehead() {
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getFirstNameTypeHead().get(0).waitForPresent(50000);
		String FirstNameTypeAh = driverTP.getFirstNameTypeHead().get(0).getText();
		putTestObject("FirstNameTypeAh", FirstNameTypeAh);
		driverTP.getFirstNameTypeHead().get(0).click();

	}

	@QAFTestStep(description = "verify type ahead results in alphabetical order")
	public void vErifyTypeaHeadResultsInAlphabeticalOrder() {
		DriverTestPage driverTP = new DriverTestPage();
		ArrayList<String> results = new ArrayList<String>();

		List<QAFWebElement> typeHeadResults = driverTP.getFirstNameTypeHead();

		for (QAFWebElement typeHeadresult : typeHeadResults) {
			results.add(typeHeadresult.getText());
		}

		for (int i = 0; i < results.size() - 1; i++) {
			for (int j = i + 1; j < results.size() - 1; j++) {

				if (results.get(i).compareToIgnoreCase(results.get(j)) < 0)
					PerfectoUtils.reportMessage("Type Head Results are diplayed in alphabetical order ",
							MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("Type Head Results are not diplayed in alphabetical order",
							MessageTypes.Fail);

			}
		}
	}

	@QAFTestStep(description = "verify the search result for type ahead FirstName")
	public void iSeeTheSearchResultForTypeaHeadFirstName() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		DriverSearchResultpage DriverResult = new DriverSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String FirstNameDisplayed = DriverResult.getDriverFirstNameresult(Rowcount).getText();

			if (FirstNameDisplayed.contains(getTestString("FirstNameTypeAh"))) {

				PerfectoUtils.reportMessage("FirstName matches with the Typeahead search result", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("FirstName Does not matches with the Typeahead search result",
						MessageTypes.Fail);
			}

			Rowcount++;
		}
	}

	public static String getCurrentDay() {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		System.out.println("Current Date: " + sdf.format(cal.getTime()));
		// Adding 1 Day to the current date
		// cal.add(Calendar.DAY_OF_MONTH, 1);
		// Date after adding one day to the current date
		String newDate = sdf.format(cal.getTime());
		// Displaying the new Date after addition of 1 Day
		System.out.println("current date: " + newDate);
		return (new String(newDate));
	}
}