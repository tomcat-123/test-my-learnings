package com.heb.automation.Pages.HD_WebApp.searchresult;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ZoneSearchResultpage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}
	
	public QAFWebElement getZoneValueresult(int count) {

		String loc = String.format(pageProps.getString("ZoneResult.lbl.zonevalue"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getCityValueresult(int count) {

		String loc = String.format(pageProps.getString("ZoneResult.lbl.cityvalue"), count);
		return new QAFExtendedWebElement(loc);
	}
}
