package com.heb.automation.Steps.HD_WebApp.store;

import java.util.ArrayList;

import com.heb.automation.Pages.HD_WebApp.CommonTestPage;
import com.heb.automation.Pages.HD_WebApp.searchresult.SearchResultPage;
import com.heb.automation.Pages.HD_WebApp.searchresult.StoreSearchResultpage;
import com.heb.automation.Pages.HD_WebApp.searchresult.ZoneSearchResultpage;
import com.heb.automation.Pages.HD_WebApp.store.StoreListingTestPage;
import com.heb.automation.Pages.HD_WebApp.zone.ZoneDisplayTestPage;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class Store_WebAppStepdef extends TestDataContainer {

	@QAFTestStep(description = "verify stroes link in display zone page")
	public void iVerifyStroesLinkInDisplayZonePage() {
		ZoneDisplayTestPage displayPage = new ZoneDisplayTestPage();

		displayPage.getzonedisplayLnkStore().verifyPresent();
	}

	@QAFTestStep(description = "navigate to store listing page")
	public void iNavigateToStoreListingPage() {
		ZoneDisplayTestPage displayPage = new ZoneDisplayTestPage();
		StoreListingTestPage stotrListing = new StoreListingTestPage();

		displayPage.getzonedisplayLnkStore().click();
		stotrListing.getLblTitle().waitForPresent(5000);
		stotrListing.getLblTitle().verifyPresent();
	}

	@QAFTestStep(description = "verify store listing page")
	public void iVerifyStoreListingPage() {
		StoreListingTestPage stotrListing = new StoreListingTestPage();
		CommonTestPage common = new CommonTestPage();
		SearchResultPage sResult = new SearchResultPage();
		ArrayList<String> data = new ArrayList<>();

		stotrListing.getLblTitle().waitForPresent(5000);
		stotrListing.getLblTitle().verifyPresent();
		stotrListing.getStorelistingbtnstorscrump().verifyPresent();
		common.getLblHomeIcon().verifyPresent();
		common.getLblHomeRightArrow().verifyPresent();
		stotrListing.getStorelistinglbldisplayrecords().verifyPresent();
		stotrListing.getStorelistinglbltotalrecords().verifyPresent();

		for (QAFWebElement rCount : sResult.getTableColumnName()) {

			data.add(rCount.getText());
		}

		if (data.contains("Status"))
			PerfectoUtils.reportMessage("Status is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Status is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Name"))
			PerfectoUtils.reportMessage("Name is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Name is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Corp Id"))
			PerfectoUtils.reportMessage("Corp Id is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Corp Id is not Avilable in Grid", MessageTypes.Fail);
	}
	
	
	@QAFTestStep(description = "verify inactive store listing page")
	public void iVerifyInActiveStoreListingPage() {
		StoreListingTestPage stotrListing = new StoreListingTestPage();
		CommonTestPage common = new CommonTestPage();
		SearchResultPage sResult = new SearchResultPage();
		ArrayList<String> data = new ArrayList<>();

		stotrListing.getLblTitle().waitForPresent(5000);
		stotrListing.getLblTitle().verifyPresent();
		stotrListing.getStorelistingbtnstorscrump().verifyPresent();
		common.getLblHomeIcon().verifyPresent();
		common.getLblHomeRightArrow().verifyPresent();
		stotrListing.getStorelistinglbldisplayrecords().verifyPresent();
		stotrListing.getStorelistinglbltotalrecords().verifyPresent();

		for (QAFWebElement rCount : sResult.getTableRowList()) {

			data.add(rCount.getText());
		}

		if (data.contains("Status"))
			PerfectoUtils.reportMessage("Status is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Status is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Name"))
			PerfectoUtils.reportMessage("Name is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Name is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Corp Id"))
			PerfectoUtils.reportMessage("Corp Id is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Corp Id is not Avilable in Grid", MessageTypes.Fail);
	}

	@QAFTestStep(description = "verify store name in ascending alphabetical order")
	public void iVerifyStoreNameInAscendingAlphabeticalOrder() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		StoreSearchResultpage DriverResult = new StoreSearchResultpage();
		ArrayList<String> name = new ArrayList<String>();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			name.add(DriverResult.getStoreNameresult(Rowcount).getText());

			Rowcount++;
		}

		for (int i = 0; i < name.size() - 2; i++) {
			for (int j = i + 1; j < name.size() - 1; j++) {

				if (name.get(i).compareToIgnoreCase(name.get(j)) < 0){

					PerfectoUtils.reportMessage("Zone Name Results are diplayed in alphabetical order ",
							MessageTypes.Pass);
				} else{
					PerfectoUtils.reportMessage("Zone Name Results are not diplayed in alphabetical order",
							MessageTypes.Fail);
				}
			}
		}
	}
	
	@QAFTestStep(description = "choose a store")
	public void iChooseAStore() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		StoreSearchResultpage StoreResult = new StoreSearchResultpage();
		

		sResult.getTableRowList().get(0).waitForPresent(5000);
		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			String selectedStore = StoreResult.getStoreNameresult(Rowcount).getText();
			putTestObject("storeselected", selectedStore);

			QAFWebElement storeSelected = StoreResult.getStoreLnkNameresult(Rowcount);
			storeSelected.click();
			break;
		}

	}

}
