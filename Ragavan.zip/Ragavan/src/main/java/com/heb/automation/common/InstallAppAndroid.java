package com.heb.automation.common;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriverCommandAdapter;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import io.appium.java_client.android.AndroidDriver;

public class InstallAppAndroid {

	public static void InstallApp_Android() {
		
	}
	
}


