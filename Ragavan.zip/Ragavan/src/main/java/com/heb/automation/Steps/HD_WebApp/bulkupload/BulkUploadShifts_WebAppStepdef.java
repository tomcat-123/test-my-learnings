package com.heb.automation.Steps.HD_WebApp.bulkupload;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.Keys;

import com.heb.automation.Pages.HD_WebApp.CommonTestPage;
import com.heb.automation.Pages.HD_WebApp.bulkupload.BulkUploadShiftsTestPage;
import com.heb.automation.common.components.PerfectoUtils;
import com.heb.automation.common.TestDataContainer;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class BulkUploadShifts_WebAppStepdef extends TestDataContainer {

	@QAFTestStep(description = "navigate to bulk upload for shifts planner page")
	public void nAvigateToBulkUploadForShiftsPlannerPage() {
		CommonTestPage common = new CommonTestPage();

		common.getNavigationBtnHamburger().click();
		common.getNavigationLblDriverSnapshot().waitForPresent(1000);
		common.getNavigationLblDriver().click();
		common.getNavigationLblDriverShiftPlanner().waitForPresent(5000);
		common.getNavigationLblDriverShiftUpload().click();
	}
	
	@QAFTestStep(description = "click on bulk upload crumb")
	public void cLickOnBulkUploadCrumb() {
		BulkUploadShiftsTestPage bulkUpload =  new BulkUploadShiftsTestPage();
		
		bulkUpload.getBtnBulkUploadCrump().click();
	}
	
	@QAFTestStep(description = "verify user navigate to bulk upload for shifts planner page")
	public void vErifyUsernAvigatedToBulkUploadForShiftsPlannerPage() {
		BulkUploadShiftsTestPage bulkUpload =  new BulkUploadShiftsTestPage();
		
		bulkUpload.getLblTitle().verifyPresent();
	}

	@QAFTestStep(description = "verify page structure for bulk upload page")
	public void vErifyPageStructureForBulkUploadPage() {
		BulkUploadShiftsTestPage bulkUpload = new BulkUploadShiftsTestPage();
		CommonTestPage common = new CommonTestPage();

		bulkUpload.getLblTitle().waitForPresent(5000);
		bulkUpload.getLblTitle().verifyPresent();
		bulkUpload.getBtnShiftsPlannerCrump().verifyPresent();
		bulkUpload.getBtnShiftsPlannerCrump().verifyPresent();
		bulkUpload.getBtnCancel().verifyPresent();
		bulkUpload.getBtnChooseFile().verifyPresent();
		bulkUpload.getBtnOpenCalendar().get(0).verifyPresent();
		bulkUpload.getBtnOpenCalendar().get(1).verifyPresent();
		bulkUpload.getBtnOpenCalendar().get(2).verifyPresent();
		bulkUpload.getbtnuploadexcel().verifyPresent();
		bulkUpload.getLblSubtitle().verifyPresent();
		bulkUpload.getLblNoteText().verifyPresent();
		bulkUpload.getLnkDownloadTemplate().verifyPresent();

		common.getLblHomeIcon().verifyPresent();
		common.getLblHomeRightArrow().verifyPresent();
	}

	@QAFTestStep(description = "Verify user is able to choose a file and upload it")
	public void vErifyUserIsAbleToChooseAFileAndUploadIt() throws AWTException {
		BulkUploadShiftsTestPage bulkUpload = new BulkUploadShiftsTestPage();

		bulkUpload.getBtnChooseFile().click();

		String usersHomeDir = System.getProperty("user.dir");
		String path = usersHomeDir + "/" + "resources/TestData/Shifts_bulkUpload.xlsx";
		File filepath = new File(path);
		String totalPath = filepath.getAbsolutePath();
		Map<String, Object> params = new HashMap<>();
		params.put("label", "File name");
		params.put("text", totalPath);
		params.put("label.direction", "left");
		params.put("timeout", "30");
		PerfectoUtils.getDriver().executeScript("mobile:edit-text:set", params);
		
		// params.clear();
		// params.put("label", "Open");
		// params.put("threshold", 70);
		// PerfectoUtils.getDriver().executeScript("mobile:button-text:click",
		// params);
		
		
		/*try {
			Runtime.getRuntime().exec( "wscript D:\\Shahul\\Tasks\\2018\\Jul\\Jul2\\demo.vbs" );




			Runtime.getRuntime().exec( "wscript D:/Shahul/Tasks/2018//Jul/Jul2/demo.vbs" );
		} catch (IOException e) {
			try {
				Runtime.getRuntime().exec( "wscript D:/Shahul/Tasks/2018//Jul/Jul2/demo.vbs" );
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		PerfectoUtils.JavaScriptConfirm();
		Robot robot = new Robot();
	    robot.mouseMove(875, 625);
	    robot.mousePress(InputEvent.BUTTON1_MASK);
	    robot.mouseRelease(InputEvent.BUTTON1_MASK);

	    robot.keyPress(KeyEvent.VK_TAB);
	    robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		
		
		PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.TAB);
		PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.TAB);
		PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.ENTER);
		robot.mousePress(InputEvent.BUTTON1_MASK);
		robot.mouseRelease(InputEvent.BUTTON1_MASK);*/
	}
}
