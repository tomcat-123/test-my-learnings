package com.heb.automation.Steps.HD_WebApp.store;

import com.heb.automation.Pages.HD_WebApp.store.StoreDisplayTestPage;
import com.heb.automation.Pages.HD_WebApp.zone.ZoneDisplayTestPage;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.heb.automation.common.TestDataContainer;

public class DisplayStore_WebAppStepdef extends TestDataContainer {
	
	@QAFTestStep(description = "verify store details page")
	public void vErifyStoreDetailsPage() {
		StoreDisplayTestPage storeDisplay = new StoreDisplayTestPage();

		storeDisplay.getStoredisplaylbltitle().verifyPresent();
		storeDisplay.getStoredisplaybtncancel().verifyPresent();
		storeDisplay.getStoredisplaylblclose().verifyPresent();
		storeDisplay.getStoredisplaylblclosetime().verifyPresent();
		storeDisplay.getStoredisplaylblday().verifyPresent();
		storeDisplay.getStoredisplaylbldisplaycrump().verifyPresent();
		storeDisplay.getStoredisplaylblmonday().verifyPresent();
		storeDisplay.getStoredisplaylblopen().verifyPresent();
		storeDisplay.getStoredisplaylblopentime().verifyPresent();
		storeDisplay.getStoredisplaytxtaddress().verifyPresent();
		storeDisplay.getStoredisplaytxtcity().verifyPresent();
		storeDisplay.getStoredisplaytxtlanguage().verifyPresent();
		storeDisplay.getStoredisplaytxtlatitude().verifyPresent();
		storeDisplay.getStoredisplaytxtphone().verifyPresent();
		storeDisplay.getStoredisplaytxtstate().verifyPresent();
		storeDisplay.getStoredisplaytxtstoreid().verifyPresent();
		storeDisplay.getStoredisplaytxtstorename().verifyPresent();
		storeDisplay.getStoredisplaytxtzip().verifyPresent();
		storeDisplay.getStoredisplaytxtzone().verifyPresent();
	}
	
	@QAFTestStep(description = "click on cancel button in store details page")
	public void iClickOnCancelButtonInStoreDetailsPage() {
		StoreDisplayTestPage storeDisplay = new StoreDisplayTestPage();
		
		storeDisplay.getStoredisplaybtncancel().verifyPresent();
		storeDisplay.getStoredisplaybtncancel().click();
	}
	@QAFTestStep(description = "verify store details page is displayed from order listing grid")
	public void vErifyStoreDetailsPageOrderListingGrid() {
		StoreDisplayTestPage storeDisplay = new StoreDisplayTestPage();

		storeDisplay.getStoredisplaylbltitle().verifyPresent();
	}
}
