package com.heb.automation.Pages.HD_WebApp.searchresult;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class OrderSearchResultpage extends WebDriverBaseTestPage<WebDriverTestPage>{

	@FindBy (locator="OrderResult.lst.nodriver")
	private List<QAFWebElement> orderResultlstNoDriver;
	
	public List<QAFWebElement> getLstNoDriver() {
		return orderResultlstNoDriver;
	}
	
	public QAFWebElement getOrderIdresult(int count) {

		String loc = String.format(pageProps.getString("OrderResult.lbl.orderid"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getCustomerresult(int count) {

		String loc = String.format(pageProps.getString("OrderResult.lbl.customer"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getStoreresult(int count) {

		String loc = String.format(pageProps.getString("OrderResult.lbl.store"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getDeliveryresult(int count) {

		String loc = String.format(pageProps.getString("OrderResult.lbl.delivery"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getOrderStatusresult(int count) {

		String loc = String.format(pageProps.getString("OrderResult.lbl.orderstatus"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getLnkOrderId(int count) {

		String loc = String.format(pageProps.getString("OrderResult.lnk.orderid"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getLblCustomerDetails(int count) {

		String loc = String.format(pageProps.getString("OrderResult.lbl.customerdetails"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getLnkStoreName(int count) {

		String loc = String.format(pageProps.getString("OrderResult.lnk.storename"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getLblDeliveryDetails(int count) {

		String loc = String.format(pageProps.getString("OrderResult.lbl.deliverydetails"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getLnkOrderStatus(int count) {

		String loc = String.format(pageProps.getString("OrderResult.lnk.orderstatus"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}

}
