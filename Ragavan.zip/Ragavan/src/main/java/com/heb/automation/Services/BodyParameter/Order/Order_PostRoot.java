package com.heb.automation.Services.BodyParameter.Order;

import java.util.ArrayList;
import java.util.List;

public class Order_PostRoot {
	
	
	private Order order = new Order();

	private Status status = new Status();

    private Delivery_schedule delivery_schedule = new Delivery_schedule();

    private Delivery_to delivery_to = new Delivery_to();

    private List<Notes_Root> notes = new ArrayList<Notes_Root>();

    private Delivery_from delivery_from = new Delivery_from();

    private Recipient recipient = new Recipient();
    
//	private List<Order_Notes> ordernotes = new ArrayList<Order_Notes>();
	
	 private String driverName;
	    
	    private String onFleetDriver;
	    
	    public String getDriverName() {
			return driverName;
		}

		public void setDriverName(String driverName) {
			this.driverName = driverName;
		}

		public String getOnFleetDriver() {
			return onFleetDriver;
		}

		public void setOnFleetDriver(String onFleetDriver) {
			this.onFleetDriver = onFleetDriver;
		}

    public Order getOrder ()
    {
        return order;
    }

    public void setOrder (Order order)
    {
        this.order = order;
    }

    public Status getStatus ()
    {
        return status;
    }

    public void setStatus (Status status)
    {
        this.status = status;
    }

    public Delivery_schedule getDelivery_schedule ()
    {
        return delivery_schedule;
    }

    public void setDelivery_schedule (Delivery_schedule delivery_schedule)
    {
        this.delivery_schedule = delivery_schedule;
    }

    public Delivery_to getDelivery_to ()
    {
        return delivery_to;
    }

    public void setDelivery_to (Delivery_to delivery_to)
    {
        this.delivery_to = delivery_to;
    }

    public List<Notes_Root> getNotes ()
    {
        return notes;
    }

    public void setNotes (List<Notes_Root> notes)
    {
        this.notes = notes;
    }

    public Delivery_from getDelivery_from ()
    {
        return delivery_from;
    }

    public void setDelivery_from (Delivery_from delivery_from)
    {
        this.delivery_from = delivery_from;
    }

    public Recipient getRecipient ()
    {
        return recipient;
    }

    public void setRecipient (Recipient recipient)
    {
        this.recipient = recipient;
    }
//    public List<Order_Notes> getOrdernotes() {
//		return ordernotes;
//	}
//
//	public void setOrdernotes(List<Order_Notes> ordernotes) {
//		this.ordernotes = ordernotes;
//	}

}
