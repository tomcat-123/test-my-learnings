package com.heb.automation.Services.HomeDelivery.Teams;

public class Teams_Post {
	
	private String apiStatus;

    private Teams_Data data = new Teams_Data();

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

    public Teams_Data getData ()
    {
        return data;
    }

    public void setData (Teams_Data data)
    {
        this.data = data;
    }

}
