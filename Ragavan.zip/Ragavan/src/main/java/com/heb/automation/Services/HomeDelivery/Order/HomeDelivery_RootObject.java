package com.heb.automation.Services.HomeDelivery.Order;

import java.util.ArrayList;
import java.util.List;


public class HomeDelivery_RootObject {
	
	private String apiStatus;


    private HomeDelivery_Data data = new HomeDelivery_Data();
    

    public HomeDelivery_Data getdata() {
		return this.data;
	}

	public void setdata(HomeDelivery_Data data) {
		this.data = data;
	}

	public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

}
