package com.heb.automation.Steps.API_Stepdef;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.heb.automation.ErrorMessages.ErrorMessage;
import com.heb.automation.Services.BodyParameter.Drivers.Driver_Post;
import com.heb.automation.Services.BodyParameter.Drivers.DriversByProfile_Body;
import com.heb.automation.Services.BodyParameter.Drivers.Drivers_Body;
import com.heb.automation.Services.BodyParameter.Drivers.Vehicles_Body;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_Success;
import com.heb.automation.Services.HomeDelivery.ServiceUtils;
import com.heb.automation.Services.HomeDelivery.Drivers.DriversByProfileID_RootObject;
import com.heb.automation.Services.HomeDelivery.Drivers.Drivers_Post;
import com.heb.automation.Services.HomeDelivery.Drivers.Drivers_RootObject;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class ShiftAssignmentStepdef extends TestDataContainer {

	@QAFTestStep(description = "Build URL for driver shift assignment")
	public void buildURLforDriverShiftAssignment() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.specificshift")+getTestString("HomeDelivery.shiftID")+getTestString("HomeDelivery.endpoint.specificdriver")+getTestString("HomeDelivery.driverprofileID");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "User PUT response call for HomeDelivery driver shift assignment")
	public void userPUTResponsecallforHomeDeliveryDriverShiftAssignment() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = "";
		try {
			rClient = ServiceUtils.PUT(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {
				Reporter.log("HomeDelivery Driver shift assignment is updated ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				DriversByProfileID_RootObject gson1 = new Gson().fromJson(RESPONSE, DriversByProfileID_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				int DriverID = gson1.getData().getId();
				Reporter.log("Created Success-HomeDelivery Driver ID: " + DriverID);
				System.out.println("Created Success-HomeDelivery Driver ID: " + DriverID);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Driver shift assignment creation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery Driver shift assignment creation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery Driver shift assignment creation failed  ");
				putTestObject("rClient", rClient);

			}

		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	@QAFTestStep(description = "User Delete the HomeDelivery driver shift assignment DELETE call")
	public void userDELETETheHomeDeliveryDrivershiftassignmentDELETECall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = "";
		try {
			rClient = ServiceUtils.DELETE(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("HomeDelivery Driver shift assignment is deleted ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				HomeDelivery_Success gson1 = new Gson().fromJson(RESPONSE,
						HomeDelivery_Success.class);
				putTestObject("rGSON", gson1);
				System.out.println(" : " + gson1.getApiStatus());
				Reporter.log("Deleted HomeDelivery Driver shift assignment : " + gson1.getApiStatus());
			}
			if (rClient.getStatus() == 207) {
				Reporter.log("HomeDelivery Driver shift assignment Deleted with Partial success  ");
				putTestObject("rClient", rClient);
				ErrorMessage gson1 = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
				putTestObject("rGSON", gson1);
			}

			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Driver shift assignment Deletion failed with 400");
				putTestObject("rClient", rClient);
			}

			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery Driver shift assignment Deletion failed with 404");
				putTestObject("rClient", rClient);
			}
			
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery Driver shift assignment Deletion failed with 401");
				putTestObject("rClient", rClient);
			}
			
			if (rClient.getStatus() == 503) {
				Reporter.log("HomeDelivery Driver shift assignment Deletion failed with 503");
				putTestObject("rClient", rClient);
			}
			
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Driver shift assignment Deletion failed with 400");
				putTestObject("rClient", rClient);
			}

		}
	}

}
