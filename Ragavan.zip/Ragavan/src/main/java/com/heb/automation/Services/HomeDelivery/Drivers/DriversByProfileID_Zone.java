package com.heb.automation.Services.HomeDelivery.Drivers;

public class DriversByProfileID_Zone
{
	private String lastModifiedTimestamp;

    private int id;

    private String externalIdOnfleet;

    private String name;

    private DriversByProfileID_City city;

    private boolean archived;

    public void setLastModifiedTimestamp(String lastModifiedTimestamp){
        this.lastModifiedTimestamp = lastModifiedTimestamp;
    }
    public String getLastModifiedTimestamp(){
        return this.lastModifiedTimestamp;
    }
    public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return this.id;
    }
    public void setExternalIdOnfleet(String externalIdOnfleet){
        this.externalIdOnfleet = externalIdOnfleet;
    }
    public String getExternalIdOnfleet(){
        return this.externalIdOnfleet;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return this.name;
    }
    public void setCity(DriversByProfileID_City city){
        this.city = city;
    }
    public DriversByProfileID_City getCity(){
        return this.city;
    }
    public void setArchived(boolean archived){
        this.archived = archived;
    }
    public boolean getArchived(){
        return this.archived;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [id = "+id+", lastModifiedTimestamp = "+lastModifiedTimestamp+", archived = "+archived+", name = "+name+", externalIdOnfleet = "+externalIdOnfleet+", city = "+city+"]";
    }
}