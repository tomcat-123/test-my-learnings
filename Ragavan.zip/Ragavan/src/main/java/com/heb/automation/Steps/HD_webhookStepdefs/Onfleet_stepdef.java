package com.heb.automation.Steps.HD_webhookStepdefs;
import com.qmetry.qaf.automation.step.NotYetImplementedException;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.heb.automation.common.TestDataContainer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.json.JSONObject;
import org.openqa.selenium.By;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.gson.Gson;
import com.heb.automation.Services.BodyParameter.Order.Order;
import com.heb.automation.Services.BodyParameter.Order.Order_PostRoot;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.ServiceUtils;
import com.heb.automation.Services.HomeDelivery.Order.HomeDelivery_Data;
import com.heb.automation.Services.HomeDelivery.Order.HomeDelivery_Tasks;
import com.heb.automation.Services.HomeDelivery.Order.Orders_Post;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;
import com.thoughtworks.selenium.webdriven.commands.GetAllButtons;
import com.thoughtworks.selenium.webdriven.commands.KeyEvent;


public class Onfleet_stepdef extends TestDataContainer {
	
	@QAFTestStep(description="Build Onfleet URL for Assigning task to the Driver")
	public void buildOnfleetURLForAssigningTaskToTheDriver(){
		
		String baseurl = getTestString("HomeDelivery.Onfleet.URL");
		String resource = getTestString("HomeDelivery.Onfleet.endpoint.AssignDriver")+getTestString("HomeDelivery.Onfleet.data.DriverID");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description="User sets the Body Parameter to Assigning Task")
	public void userSetsTheBodyParameterToAssigningTask() throws JsonProcessingException{
		JSONObject parameters = new JSONObject();
		
		parameters.put("tasks", (ArrayList<HomeDelivery_Tasks>) getTestObject("OnfleetTaskIDs"));
		
		
		System.out.println("CHoosen Name is  :" + parameters);
		System.out.println("Full body paramter is : " + parameters);

		putTestObject("BodyParameter", parameters.toString());
	
	}
	
	@QAFTestStep(description="User POST the Assign Task")
	public void userPOSTTheAssignTask(){
	
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			RESPONSE = ServiceUtils.POST(headers, bodyParam);
			if (RESPONSE.getStatus() == 200) {

				Reporter.log("Task is assigned ");
				putTestObject("rClient", RESPONSE);

				Orders_Post gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class),
						Orders_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
			}
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("Order created with failed  " + 400);
				Reporter.log(RESPONSE.toString());
				System.out.println(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	
	}
	

	@QAFTestStep(description="User Navigate to Onfleet URL")
	public void userNavigateToOnfleetURL(){
		System.out.println("Testing...");
		System.out.println(ConfigurationManager.getBundle().getString("HomeDelivery.OnFleetURL"));
		PerfectoUtils.getAppiumDriver().get(ConfigurationManager.getBundle().getString("HomeDelivery.OnFleetURL"));
		PerfectoUtils.getAppiumDriver().context("WEB");

	}
	
	
		}
