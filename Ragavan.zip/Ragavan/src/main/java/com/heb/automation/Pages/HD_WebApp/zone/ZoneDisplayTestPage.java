package com.heb.automation.Pages.HD_WebApp.zone;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ZoneDisplayTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}

	@FindBy(locator = "zonedisplay.txt.zonename")
	private QAFWebElement zonedisplaytxtzonename;

	@FindBy(locator = "zonedisplay.txt.onfleetteamid")
	private QAFWebElement zonedisplaytxtonfleetteamid;

	@FindBy(locator = "zonedisplay.txt.city")
	private QAFWebElement zonedisplaytxtcity;

	@FindBy(locator = "zonedisplay.txt.zipcode")
	private QAFWebElement zonedisplaytxtzipcode;

	@FindBy(locator = "zonedisplay.btn.cancel")
	private QAFWebElement zonedisplaybtncancel;

	@FindBy(locator = "zonedisplay.btn.edit")
	private QAFWebElement zonedisplaybtnedit;

	@FindBy(locator = "zonedisplay.btn.delete")
	private QAFWebElement zonedisplaybtndelete;

	@FindBy(locator = "zonedisplay.btn.displayzonecrumb")
	private QAFWebElement zonedisplaybtndisplayzonecrumb;

	@FindBy(locator = "zonedisplay.lbl.title")
	private QAFWebElement zonedisplaylbltitle;

	@FindBy(locator = "zonedisplay.lnk.stores")
	private QAFWebElement zonedisplaylnkstores;

	@FindBy(locator = "zonedisplay.lbl.deleteconfirmation")
	private QAFWebElement zonedisplaylbldeleteconfirmation;

	@FindBy(locator = "zonedisplay.lbl.deletewarningmessage")
	private QAFWebElement zonedisplaylbldeletewarningmessage;

	@FindBy(locator = "zonedisplay.btn.yes")
	private QAFWebElement zonedisplaybtnyes;

	@FindBy(locator = "zonedisplay.btn.no")
	private QAFWebElement zonedisplaybtnno;

	@FindBy(locator = "zonedisplay.lnk.store")
	private QAFWebElement zonedisplaylnkstore;

	@FindBy(locator = "zonedisplay.lbl.selectedzipcode")
	private List<QAFWebElement> zonedisplaylblselectedzipcode;

	public List<QAFWebElement> getLblSelectedZipcode() {
		return zonedisplaylblselectedzipcode;
	}

	public QAFWebElement getzonedisplayLnkStore() {
		return zonedisplaylnkstore;
	}

	public QAFWebElement getZonedisplaytxtzonename() {
		return zonedisplaytxtzonename;
	}

	public QAFWebElement getZonedisplaytxtonfleetteamid() {
		return zonedisplaytxtonfleetteamid;
	}

	public QAFWebElement getZonedisplaytxtcity() {
		return zonedisplaytxtcity;
	}

	public QAFWebElement getZonedisplaytxtzipcode() {
		return zonedisplaytxtzipcode;
	}

	public QAFWebElement getZonedisplaybtncancel() {
		return zonedisplaybtncancel;
	}

	public QAFWebElement getZonedisplaybtnedit() {
		return zonedisplaybtnedit;
	}

	public QAFWebElement getZonedisplaybtndelete() {
		return zonedisplaybtndelete;
	}

	public QAFWebElement getZonedisplaybtndisplayzonecrumb() {
		return zonedisplaybtndisplayzonecrumb;
	}

	public QAFWebElement getZonedisplaylbltitle() {
		return zonedisplaylbltitle;
	}

	public QAFWebElement getZonedisplaylnkstores() {
		return zonedisplaylnkstores;
	}

	public QAFWebElement getZonedisplaylbldeleteconfirmation() {
		return zonedisplaylbldeleteconfirmation;
	}

	public QAFWebElement getZonedisplaylbldeletewarningmessage() {
		return zonedisplaylbldeletewarningmessage;
	}

	public QAFWebElement getZonedisplaybtnyes() {
		return zonedisplaybtnyes;
	}

	public QAFWebElement getZonedisplaybtnno() {
		return zonedisplaybtnno;
	}

}
