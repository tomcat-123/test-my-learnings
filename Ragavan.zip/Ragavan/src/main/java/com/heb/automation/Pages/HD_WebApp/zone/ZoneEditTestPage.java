package com.heb.automation.Pages.HD_WebApp.zone;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ZoneEditTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}

	@FindBy(locator = "zoneedit.btn.save")
	private QAFWebElement zoneeditbtnsave;

	@FindBy(locator = "zoneedit.txt.zonename")
	private QAFWebElement zoneedittxtzonename;

	@FindBy(locator = "zoneedit.txt.onfleetteamid")
	private QAFWebElement zoneedittxtonfleetteamid;

	@FindBy(locator = "zoneedit.txt.city")
	private QAFWebElement zoneedittxtcity;

	@FindBy(locator = "zoneedit.lbl.citydropdown")
	private List<QAFWebElement> zoneeditlblcitydropdown;

	
	@FindBy(locator = "zoneedit.btn.cancel")
	private QAFWebElement zoneeditbtncancel;

	@FindBy(locator = "zoneedit.btn.editzonecrumb")
	private QAFWebElement zoneeditbtneditzonecrumb;

	@FindBy(locator = "zoneedit.lbl.title")
	private QAFWebElement zoneeditlbltitle;

	@FindBy(locator = "zoneedit.btn.zipcoderemove")
	private QAFWebElement zoneeditbtnzipcoderemove;

	@FindBy(locator = "zoneedit.txt.Addzipcode")
	private QAFWebElement zoneedittxtAddzipcode;
	
	@FindBy(locator = "zoneedit.lbl.selectedzipcode")
	private QAFWebElement zoneeditlblselectedzipcode;
	
	@FindBy(locator = "zoneedit.lbl.emptyspace")
	private QAFWebElement zoneeditlblEmptyspace;
	
	
	@FindBy(locator = "zoneedit.lbl.zipcodeoption")
	private List<QAFWebElement> zoneeditlblzipcodeoption;
	
	
	public List<QAFWebElement> getLblZipCodeOption() {
		return zoneeditlblzipcodeoption;
	}
	
	public QAFWebElement getLblSelectedZipcode() {
		return zoneeditlblselectedzipcode;
	}
	
	public QAFWebElement getBtnZipCodeRemove() {
		return zoneeditbtnzipcoderemove;
	}
	
	public QAFWebElement getBtnSave() {
		return zoneeditbtnsave;
	}

	public QAFWebElement getTxtZonename(boolean mode) {
		String loc = String.format(pageProps.getString("zoneedit.txt.zonename"),mode);

		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getBtnsave() {
		return zoneeditbtnsave;
	}

	public QAFWebElement getTxtZoneName() {
		return zoneedittxtzonename;
	}

	public QAFWebElement getTxtOnFleetTeamId() {
		return zoneedittxtonfleetteamid;
	}

	public QAFWebElement getTxtCity() {
		return zoneedittxtcity;
	}

	public List<QAFWebElement> getLblCityDropdown() {
		return zoneeditlblcitydropdown;
	}
	public QAFWebElement getBtnCancel() {
		return zoneeditbtncancel;
	}

	public QAFWebElement getBtnEditZoneCrumb() {
		return zoneeditbtneditzonecrumb;
	}

	public QAFWebElement getLblTitle() {
		return zoneeditlbltitle;
	}

	public QAFWebElement getTxtAddZipcode() {
		return zoneedittxtAddzipcode;
	}

	public QAFWebElement getZoneeditlblEmptyspace() {
		return zoneeditlblEmptyspace;
	}

	
	
}
