package com.heb.automation.Pages.HD_WebApp.store;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class StoreDisplayTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator="storedisplay.lbl.displaycrump")
	private QAFWebElement storedisplaylbldisplaycrump;
	
	@FindBy(locator="storedisplay.lbl.title")
	private QAFWebElement storedisplaylbltitle;
	
	@FindBy(locator="storedisplay.txt.storename")
	private QAFWebElement storedisplaytxtstorename;
	
	@FindBy(locator="storedisplay.txt.zone")
	private QAFWebElement storedisplaytxtzone;
	
	@FindBy(locator="storedisplay.txt.address")
	private QAFWebElement storedisplaytxtaddress;
	
	@FindBy(locator="storedisplay.txt.city")
	private QAFWebElement storedisplaytxtcity;
	
	@FindBy(locator="storedisplay.txt.zip")
	private QAFWebElement storedisplaytxtzip;
	
	@FindBy(locator="storedisplay.txt.storeid")
	private QAFWebElement storedisplaytxtstoreid;
	
	@FindBy(locator="storedisplay.txt.phone")
	private QAFWebElement storedisplaytxtphone;
	
	@FindBy(locator="storedisplay.txt.state")
	private QAFWebElement storedisplaytxtstate;
	
	@FindBy(locator="storedisplay.txt.latitude")
	private QAFWebElement storedisplaytxtlatitude;
	
	@FindBy(locator="storedisplay.txt.language")
	private QAFWebElement storedisplaytxtlanguage;
	
	@FindBy(locator="storedisplay.lbl.day")
	private QAFWebElement storedisplaylblday;
	
	@FindBy(locator="storedisplay.lbl.open")
	private QAFWebElement storedisplaylblopen;
	
	@FindBy(locator="storedisplay.lbl.close")
	private QAFWebElement storedisplaylblclose;
 
	@FindBy(locator="storedisplay.btn.cancel")
	private QAFWebElement storedisplaybtncancel;
	
	@FindBy(locator="storedisplay.lbl.monday")
	private QAFWebElement storedisplaylblmonday;
	 
	@FindBy(locator="storedisplay.lbl.opentime")
	private QAFWebElement storedisplaylblopentime;
	
	@FindBy(locator="storedisplay.lbl.closetime")
	private QAFWebElement storedisplaylblclosetime;
	
	
	
	public QAFWebElement getStoredisplaylbldisplaycrump() {
		return storedisplaylbldisplaycrump;
	}

	public QAFWebElement getStoredisplaylbltitle() {
		return storedisplaylbltitle;
	}
	
	public QAFWebElement getStoredisplaytxtstorename() {
		return storedisplaytxtstorename;
	}

	public QAFWebElement getStoredisplaytxtzone() {
		return storedisplaytxtzone;
	}

	public QAFWebElement getStoredisplaytxtaddress() {
		return storedisplaytxtaddress;
	}
	
	public QAFWebElement getStoredisplaytxtcity() {
		return storedisplaytxtcity;
	}

	public QAFWebElement getStoredisplaytxtzip() {
		return storedisplaytxtzip;
	}

	public QAFWebElement getStoredisplaytxtstoreid() {
		return storedisplaytxtstoreid;
	}

	public QAFWebElement getStoredisplaytxtphone() {
		return storedisplaytxtphone;
	}

	public QAFWebElement getStoredisplaytxtstate() {
		return storedisplaytxtstate;
	}

	public QAFWebElement getStoredisplaytxtlatitude() {
		return storedisplaytxtlatitude;
	}

	public QAFWebElement getStoredisplaytxtlanguage() {
		return storedisplaytxtlanguage;
	}

	public QAFWebElement getStoredisplaylblday() {
		return storedisplaylblday;
	}

	public QAFWebElement getStoredisplaylblopen() {
		return storedisplaylblopen;
	}

	public QAFWebElement getStoredisplaylblclose() {
		return storedisplaylblclose;
	}

	public QAFWebElement getStoredisplaybtncancel() {
		return storedisplaybtncancel;
	}

	public QAFWebElement getStoredisplaylblmonday() {
		return storedisplaylblmonday;
	}

	public QAFWebElement getStoredisplaylblopentime() {
		return storedisplaylblopentime;
	}

	public QAFWebElement getStoredisplaylblclosetime() {
		return storedisplaylblclosetime;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}

}
