package com.heb.automation.Services.HomeDelivery.Zones;

import java.util.ArrayList;

public class Zones_RootObject {
	
	 private String apiStatus;

	    private ArrayList<Zones_Data> data = new ArrayList<Zones_Data>();

	    public String getApiStatus ()
	    {
	        return apiStatus;
	    }

	    public void setApiStatus (String apiStatus)
	    {
	        this.apiStatus = apiStatus;
	    }

	    public ArrayList<Zones_Data> getData ()
	    {
	        return data;
	    }

	    public void setData (ArrayList<Zones_Data> data)
	    {
	        this.data = data;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [apiStatus = "+apiStatus+", data = "+data+"]";
	    }
}
