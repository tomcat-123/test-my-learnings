package com.heb.automation.Steps.HD_WebApp.zone;

import java.util.List;
import java.util.Random;

import org.jboss.netty.util.EstimatableObjectWrapper;
import org.openqa.selenium.Keys;

import com.heb.automation.Pages.HD_WebApp.zone.ZoneDisplayTestPage;
import com.heb.automation.Pages.HD_WebApp.zone.ZoneEditTestPage;
import com.heb.automation.Pages.HD_WebApp.zone.ZoneListingTestPage;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class EditZone_WebAppStepdef extends TestDataContainer {

	@QAFTestStep(description = "verify the Edit Zone Page")
	public void iVerifyTheEditZonePage() {
		ZoneEditTestPage zoneEditTP = new ZoneEditTestPage();
		ZoneDisplayTestPage zoneDisplay = new ZoneDisplayTestPage();

		zoneEditTP.getLblTitle().waitForPresent(5000);
		zoneEditTP.getBtnEditZoneCrumb().verifyPresent();
		zoneEditTP.getBtnEditZoneCrumb().click();
		zoneDisplay.getZonedisplaybtnedit().waitForPresent(5000);
		zoneDisplay.getZonedisplaybtnedit().click();
		zoneEditTP.getLblTitle().waitForPresent(5000);
		zoneEditTP.getTxtZoneName().verifyPresent();
		zoneEditTP.getTxtOnFleetTeamId().verifyPresent();
		zoneEditTP.getTxtCity().verifyPresent();
		zoneEditTP.getTxtAddZipcode().verifyPresent();
		zoneEditTP.getBtnCancel().verifyPresent();
		zoneEditTP.getBtnSave().verifyPresent();
		zoneDisplay.getZonedisplaybtnedit().verifyNotPresent();

		String Title = zoneEditTP.getLblTitle().getText();

		if (Title.contains(getTestString("zoneselected")))
			PerfectoUtils.reportMessage("Title is displayed with Zone Name", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Title is not displayed with Zone Name", MessageTypes.Fail);
	}

	@QAFTestStep(description = "click on Cancel button in EditZone Page")
	public void iClickOnCancelButtonInEditZonePage() {
		ZoneEditTestPage zoneEditTP = new ZoneEditTestPage();

		zoneEditTP.getBtnCancel().waitForPresent();
		zoneEditTP.getBtnCancel().click();
	}

	@QAFTestStep(description = "click on Save button in EditZone Page")
	public void iClickOnSaveButtonInEditZonePage() {
		ZoneEditTestPage zoneEditTP = new ZoneEditTestPage();

		zoneEditTP.getBtnSave().click();
	}

	@QAFTestStep(description = "verify user is navigated back to the Zone Display Page")
	public void iVerifyUserIsNavigatedBackToTheZoneDisplayPage() {
		ZoneDisplayTestPage zDisplay = new ZoneDisplayTestPage();
		
		zDisplay.getZonedisplaylbltitle().waitForPresent(5000);
		zDisplay.getZonedisplaylbltitle().verifyPresent();
	}

	@QAFTestStep(description = "select a zipcode by key board enter in edit zone page")
	public void iSelectAZoneByKeyBoardEnterInEditZonePage() {
		ZoneEditTestPage editZone = new ZoneEditTestPage();
		String zip;

		editZone.getTxtZoneName().waitForPresent(5000);
		if (editZone.getBtnZipCodeRemove().isPresent()) {
			do {
				editZone.getBtnZipCodeRemove().click();
			} while (editZone.getBtnZipCodeRemove().isPresent());
		}

		editZone.getTxtZoneName().click();
		editZone.getTxtAddZipcode().click();
		zip = editZone.getLblZipCodeOption().get(0).getText();
		PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.ARROW_DOWN);
		PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.ENTER);
		putTestObject("Zip", zip);
	}

	@QAFTestStep(description = "verify user is able to pick zip codes from the list in edit zone page")
	public void iVerifyUserIsAbleToPickZipCodesFromTheListInEditZonePage() {
		ZoneEditTestPage editZone = new ZoneEditTestPage();

		String SlectedZip;
		String Zipcde = getTestString("Zip");
		SlectedZip = editZone.getLblSelectedZipcode().getText();
		SlectedZip = SlectedZip.replace("X", "").trim();

		if (Zipcde.equals(SlectedZip))
			PerfectoUtils.reportMessage("The user is able to select ZipCode ", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("The user is not able to select ZipCode ", MessageTypes.Fail);
	}

	@QAFTestStep(description = "click on cancel button in zone edit page")
	public void iClickOnCancelButtonInZoneEditPage() {

		ZoneEditTestPage zoneEdit = new ZoneEditTestPage();
		zoneEdit.getBtnCancel().click();

	}

	@QAFTestStep(description = "verify fields Zone Name City Zip Code are editable")
	public void iVerifyFieldsZoneNameCityZipCodeAreEditable() {
		ZoneEditTestPage editZoneTP = new ZoneEditTestPage();
		String EnterZoneName = getTestString("HomeDelivery.EnterZoneName");
		String EnterCityName = getTestString("HomeDelivery.EnterCityName");
		String EnterZipcode = getTestString("HomeDelivery.EnterZipcode");
		String EnterOnFleet = getTestString("HomeDelivery.EnterOnfleetID");

		zoneNameasEditable();

		String GetzName = editZoneTP.getTxtZoneName().getText();
		String GetzCode = editZoneTP.getLblSelectedZipcode().getText();
		String GetzCity = editZoneTP.getTxtCity().getText();
		String GetzOnfeetID = editZoneTP.getTxtOnFleetTeamId().getText();
	}

	public static void zoneNameasEditable() {
		ZoneEditTestPage editZoneTP = new ZoneEditTestPage();

		String Ex_zName = editZoneTP.getTxtZoneName().getText();
		System.out.println(Ex_zName);
		editZoneTP.getTxtZoneName().clear();
		editZoneTP.getTxtZoneName().sendKeys("Vijaykarthik_zone");
		editZoneTP.getZoneeditlblEmptyspace().click();
		String new_zName = editZoneTP.getTxtZoneName().getText();
		System.out.println("New ZoneName = " + new_zName);

	}

	@QAFTestStep(description = "verify edit page displays the Save and Cancel button")
	public void iVerifyEditPageDisplaysTheSaveAndCancelButton() {
		ZoneEditTestPage editZoneTP = new ZoneEditTestPage();

		editZoneTP.getBtnCancel().verifyPresent();
		editZoneTP.getBtnSave().verifyPresent();
	}

	@QAFTestStep(description = "verify edit page hides the Edit and Delete buttons")
	public void iVerifyEditPageHidesTheEditAndDeleteButtons() {
		ZoneDisplayTestPage editZoneTP = new ZoneDisplayTestPage();

		editZoneTP.getZonedisplaybtnedit().verifyNotPresent();
		editZoneTP.getZonedisplaybtndelete().verifyNotPresent();
	}

	@QAFTestStep(description = "verify the Onfleet Team ID field is non-editable")
	public void iVerifyTheOnfleetTeamIDFieldIsNoneditable() {
		ZoneEditTestPage editZoneTP = new ZoneEditTestPage();

		String onfleet = generateRandomString();
		editZoneTP.getTxtOnFleetTeamId().sendKeys(onfleet);

		if (!onfleet.equals(editZoneTP.getTxtOnFleetTeamId().getAttribute("value")))
			PerfectoUtils.reportMessage("Onfleet ID is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Onfleet ID is editable", MessageTypes.Fail);

	}

	@QAFTestStep(description = "enter zone name in zone edit page")
	public void iEnterZoneNameInZoneEditPage() throws InterruptedException {
		ZoneEditTestPage zoneEditTP = new ZoneEditTestPage();

		zoneEditTP.waitForPageToLoad();
		zoneEditTP.getTxtZoneName().waitForVisible(50000);
		zoneEditTP.getTxtZoneName().waitForPresent(50000);
		Thread.sleep(5000);
		zoneEditTP.getTxtZoneName().click();
		zoneEditTP.getTxtZoneName().clear();
		String zoneName = "Automation_"+generateRandomString();
		zoneEditTP.getTxtZoneName().sendKeys(zoneName);
		putTestObject("zoneNameEdit", zoneName);
	}

	@QAFTestStep(description = "select city in zone edit page")
	public void iSelectCityInZoneEditPage() {
		ZoneEditTestPage zoneEditTP = new ZoneEditTestPage();

		String newCity = null;

		String existingCity = zoneEditTP.getTxtCity().getText();
		zoneEditTP.getTxtCity().click();

		for (int i = 0; i < zoneEditTP.getLblCityDropdown().size(); i++) {
			newCity = zoneEditTP.getLblCityDropdown().get(i).getText();
			if (!existingCity.equals(newCity)) {
				String cityEdited = zoneEditTP.getLblCityDropdown().get(i).getText();
				putTestObject("CityEdited", cityEdited);
				zoneEditTP.getLblCityDropdown().get(i).click();
				break;
			}
		}
	}

	@QAFTestStep(description = "select zipcode in zone edit page")
	public void iSelectZipcodeInZoneEditPage() {
		ZoneEditTestPage zoneEditTP = new ZoneEditTestPage();

		zoneEditTP.getTxtAddZipcode().click();
		zoneEditTP.getLblZipCodeOption().get(0).waitForPresent(1000);
		String zipCode = zoneEditTP.getLblZipCodeOption().get(0).getText();
		zoneEditTP.getLblZipCodeOption().get(0).click();
		zoneEditTP.getLblZipCodeOption().get(0).click();

		putTestObject("ZipCode", zipCode);
	}

	public static String generateRandomString() {

		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 6;
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();

		return generatedString;

	}

	@QAFTestStep(description = "verify fields are editable in edit zone page")
	public void iVerifyFieldsAreEditableInEditZonePage() {
		ZoneEditTestPage zoneEditTP = new ZoneEditTestPage();

		zoneEditTP.getTxtZoneName().click();
		zoneEditTP.getTxtZoneName().clear();
		String zoneName = "Automation_"+generateRandomString();
		zoneEditTP.getTxtZoneName().sendKeys(zoneName);
		iSelectCityInZoneEditPage();

		if (zoneEditTP.getBtnZipCodeRemove().isPresent()) {
			do {
				zoneEditTP.getBtnZipCodeRemove().click();
			} while (zoneEditTP.getBtnZipCodeRemove().isPresent());
		}

		String onfleet = generateRandomString();
		zoneEditTP.getTxtOnFleetTeamId().sendKeys(onfleet);

		if (zoneName.equals(zoneEditTP.getTxtZoneName().getAttribute("value")))
			PerfectoUtils.reportMessage("Zone Name is editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Zone Name is not editable", MessageTypes.Fail);

		if (zoneEditTP.getTxtCity().getText().equals(getTestString("CityEdited")))
			PerfectoUtils.reportMessage("City is editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("City is not editable", MessageTypes.Fail);

		if (!zoneEditTP.getBtnZipCodeRemove().isPresent())
			PerfectoUtils.reportMessage("ZipCode is editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("ZipCode is not editable", MessageTypes.Fail);

		if (!onfleet.equals(zoneEditTP.getTxtOnFleetTeamId().getAttribute("value")))
			PerfectoUtils.reportMessage("Onfleet ID is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Onfleet ID is editable", MessageTypes.Fail);
	}
}
