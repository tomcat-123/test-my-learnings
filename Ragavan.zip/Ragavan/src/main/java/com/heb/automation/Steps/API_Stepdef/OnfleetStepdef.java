package com.heb.automation.Steps.API_Stepdef;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.heb.automation.Services.BodyParameter.Drivers.Driver_Post;
import com.heb.automation.Services.BodyParameter.Drivers.Drivers_Body;
import com.heb.automation.Services.BodyParameter.Drivers.Vehicles_Body;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.ServiceUtils;
import com.heb.automation.Services.HomeDelivery.Onfleet.Onfleet_Root;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class OnfleetStepdef {
	
	@QAFTestStep(description = "User with valid APIkey for HomeDelivery Onfleet")
	public void userWithValidAPIkeyForAppInfo() {
		HomeDelivery_ReusableUtils.onFleet_headers();
	}
	
	
	
	@QAFTestStep(description = "Build URL for update Onfleet Tasks")
	public void buildURLforUpdateOnfleetTasks() {
		String baseurl = getBundle().getString("HomeDelivery.onFleet.adminPortal");
		String resource = getBundle().getString("HomeDelivery.onFleet.endpoint.getWorkers") + "/"
				+ getBundle().getProperty("onFleetID");
		
		System.out.println(resource);
		CommonUtils.buildURL(resource, baseurl);
	}
	@QAFTestStep(description = "User UPDATE HomeDelivery Onfleet Tasks body parameter")
	public void userUPDATEHomeDeliveryOnfleetTasksBodyParameter()
			throws JsonProcessingException {

		//OnfleetTask_PUT_Bodys pr = new OnfleetTask_PUT_Bodys();
		ObjectMapper objm = new ObjectMapper();
		
		List<String> task = new ArrayList<String>();
		task.add(getBundle().getString("Onfleet.Tasks1"));
		task.add(getBundle().getString("Onfleet.Tasks2"));
		task.add(getBundle().getString("Onfleet.Tasks3"));
		//pr.setTasks(task);
		
		String jsonInString = objm.writeValueAsString(task);
		System.out.println("CHoosen Tasks is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	@QAFTestStep(description = "User PUT the Update HomeDelivery Onfleet Task call")
	public void userPUTTheUpdateHomeDeliveryOnfleetTaskCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.onFleet_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			rClient = ServiceUtils.PUT(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Onfleet Task is updated ");
				getBundle().setProperty("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Onfleet_Root gson1 = new Gson().fromJson(RESPONSE, Onfleet_Root.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				List<String> Tasks = gson1.getTasks();
				Reporter.log("Updated Success-HomeDelivery Onfleet Tasks are: ");
				for(String tsk: Tasks){
					Reporter.log(tsk);
					System.out.println("Updated Success-HomeDelivery Onfleet Tasks: " + tsk);
				}
				
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Onfleet Update failed  ");
				getBundle().setProperty("rClient", rClient);

			}
			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery Onfleet Update failed  ");
				getBundle().setProperty("rClient", rClient);

			}
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery Onfleet Update failed  ");
				getBundle().setProperty("rClient", rClient);

			}

		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
}
