package com.heb.automation.Services.HomeDelivery.Search;

import java.util.ArrayList;

public class SearchResults_RootObject {
	
	 private String apiStatus;

	 private SearchResults_ZonesData data = new SearchResults_ZonesData();
	 
//	 private ArrayList<Zones_Data> content = new ArrayList<Zones_Data>();

	 public SearchResults_ZonesData getData() {
		return data;
	}

	public void setData(SearchResults_ZonesData data) {
		this.data = data;
	}

	public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

/*	    public ArrayList<Zones_Data> getData ()
	    {
	        return content;
	    }

	    public void setData (ArrayList<Zones_Data> content)
	    {
	        this.content = content;
	    }*/

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [apiStatus = "+apiStatus+", data = "+data+"]";
	    }
}
