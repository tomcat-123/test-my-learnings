package com.heb.automation.Services.HomeDelivery.Onfleet;

public class Onfleet_UserData
{
    private String deviceDescription;

    private String platform;

    private String appVersion;

    private String batteryLevel;

    public String getDeviceDescription ()
    {
        return deviceDescription;
    }

    public void setDeviceDescription (String deviceDescription)
    {
        this.deviceDescription = deviceDescription;
    }

    public String getPlatform ()
    {
        return platform;
    }

    public void setPlatform (String platform)
    {
        this.platform = platform;
    }

    public String getAppVersion ()
    {
        return appVersion;
    }

    public void setAppVersion (String appVersion)
    {
        this.appVersion = appVersion;
    }

    public String getBatteryLevel ()
    {
        return batteryLevel;
    }

    public void setBatteryLevel (String batteryLevel)
    {
        this.batteryLevel = batteryLevel;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [deviceDescription = "+deviceDescription+", platform = "+platform+", appVersion = "+appVersion+", batteryLevel = "+batteryLevel+"]";
    }
}