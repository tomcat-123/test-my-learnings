package com.heb.automation.Pages.HD_WebApp.drivershiftsplanner;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class DriverShiftsPlannerTestPage extends WebDriverBaseTestPage<WebDriverTestPage>{

	@FindBy(locator = "shiftsplannerlisting.lbl.title")
	private QAFWebElement shiftsplannerlistinglbltitle;
	
	@FindBy(locator = "shiftsplannerlisting.btn.driverCrumb")
	private QAFWebElement shiftsplannerlistingbtndriverCrumb;
	
	@FindBy(locator = "shiftsplannerlisting.txt.zonename")
	private QAFWebElement shiftsplannerlistingtxtzonename;
	
	@FindBy(locator = "shiftsplannerlisting.txt.date")
	private QAFWebElement shiftsplannerlistingtxtdate;
	
	@FindBy(locator = "shiftsplannerlisting.dropdown.publishtimepicker")
	private QAFWebElement shiftsplannerlistingdropdownpublishtimepicker;
	
	@FindBy(locator = "shiftsplannerlisting.txt.publishtimepicker")
	private QAFWebElement shiftsplannerlistingtxtpublishtimepicker;
	
	@FindBy(locator = "shiftsplannerlisting.btn.opencalendar")
	private QAFWebElement shiftsplannerlistingbtnopencalendar;
	
	@FindBy(locator = "shiftsplannerlisting.btn.previousmonth")
	private QAFWebElement shiftsplannerlistingbtnpreviousmonth;
	
	@FindBy(locator = "shiftsplannerlisting.btn.nextmonth")
	private QAFWebElement shiftsplannerlistingbtnnextmonth;
	
	@FindBy(locator = "shiftsplannerlisting.lbl.dates")
	private List<QAFWebElement> shiftsplannerlistinglbldates;
	
	@FindBy(locator = "shiftsplannerlisting.btn.addnew")
	private QAFWebElement shiftsplannerlistingbtnaddnew;
	
	@FindBy(locator = "shiftsplannerlisting.lbl.zone")
	private List<QAFWebElement>shiftsplannerlistinglblzone;
	
	@FindBy(locator = "shiftsplannerlisting.lbl.weekof")
	private List<QAFWebElement> shiftsplannerlistinglblweekof;
	
	@FindBy(locator = "shiftsplannerlisting.lbl.publishdate")
	private List<QAFWebElement> shiftsplannerlistinglblpublishdate;
	
	@FindBy(locator = "shiftsplannerlisting.lbl.daysoftheweek")
	private List<QAFWebElement> shiftsplannerlistinglbldaysoftheweek;
	
	@FindBy(locator = "shiftsplannerlisting.lbl.shift")
	private List<QAFWebElement> shiftsplannerlistinglblshift;
	
	@FindBy(locator = "shiftsplannerlisting.lbl.drivers")
	private List<QAFWebElement> shiftsplannerlistinglbldrivers;
	
	@FindBy(locator = "shiftsplannerlisting.btn.plannerlessdrivers")
	private List<QAFWebElement> shiftsplannerlistingbtnplannerlessdrivers;
	
	@FindBy(locator = "shiftsplannerlisting.btn.plannermoredrivers")
	private List<QAFWebElement> shiftsplannerlistingbtnplannermoredrivers;
	
	@FindBy(locator = "shiftsplannerlisting.btn.search")
	private QAFWebElement shiftsplannerlistingbtnsearch;
	
	@FindBy(locator = "shiftsplannerlisting.btn.reset")
	private QAFWebElement shiftsplannerlistingbtnreset;
	
	@FindBy(locator = "shiftsplannerlisting.lbl.time")
	private List<QAFWebElement> shiftsplannerlistinglbltime;
	
	public List<QAFWebElement> getLblTime() {
		return shiftsplannerlistinglbltime;
	}
	
	public QAFWebElement getBtnSearch() {
		return shiftsplannerlistingbtnsearch;
	}
	
	public QAFWebElement getBtnReset() {
		return shiftsplannerlistingbtnreset;
	}

	public QAFWebElement getLblTitle() {
		return shiftsplannerlistinglbltitle;
	}

	public QAFWebElement getBtnDriverCrumb() {
		return shiftsplannerlistingbtndriverCrumb;
	}

	public QAFWebElement getTxtZoneName() {
		return shiftsplannerlistingtxtzonename;
	}

	public QAFWebElement getTxtDate() {
		return shiftsplannerlistingtxtdate;
	}

	public QAFWebElement getDropdownPublishTimePicker() {
		return shiftsplannerlistingdropdownpublishtimepicker;
	}

	public QAFWebElement getTxtPublishTimePicker() {
		return shiftsplannerlistingtxtpublishtimepicker;
	}

	public QAFWebElement getBtnOpenCalendar() {
		return shiftsplannerlistingbtnopencalendar;
	}

	public QAFWebElement getBtnPreviousMonth() {
		return shiftsplannerlistingbtnpreviousmonth;
	}

	public QAFWebElement getBtnNextMonth() {
		return shiftsplannerlistingbtnnextmonth;
	}

	public List<QAFWebElement> getLblDates() {
		return shiftsplannerlistinglbldates;
	}

	public QAFWebElement getBtnAddNew() {
		return shiftsplannerlistingbtnaddnew;
	}

	public List<QAFWebElement> getLblZone() {
		return shiftsplannerlistinglblzone;
	}

	public List<QAFWebElement> getLblWeekOf() {
		return shiftsplannerlistinglblweekof;
	}

	public List<QAFWebElement> getLblPublishDate() {
		return shiftsplannerlistinglblpublishdate;
	}

	public List<QAFWebElement> getLblDaysOfTheWeek() {
		return shiftsplannerlistinglbldaysoftheweek;
	}

	public List<QAFWebElement> getLblShift() {
		return shiftsplannerlistinglblshift;
	}

	public List<QAFWebElement> getLblDrivers() {
		return shiftsplannerlistinglbldrivers;
	}

	public List<QAFWebElement> getBtnPlannerLessDrivers() {
		return shiftsplannerlistingbtnplannerlessdrivers;
	}

	public List<QAFWebElement> getBtnPlannerMoreDrivers() {
		return shiftsplannerlistingbtnplannermoredrivers;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}

}
