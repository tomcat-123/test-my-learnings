package com.heb.automation.Services.HomeDelivery.Zones;

public class City_Data {
	
	private boolean archived;

    private String tipsAndTricksIdOnfleet;

    private String lastModifiedTimestamp;

    private String id;

    private int driverCount;
    
    private String[] zones;

    private String name;
    
    private String parkingIdOnfleet;
    
    private String mapLink;
    
    private double hourlyRate;

    public boolean getArchived ()
    {
        return archived;
    }

    public void setArchived (boolean archived)
    {
        this.archived = archived;
    }

    public String getTipsAndTricksIdOnfleet ()
    {
        return tipsAndTricksIdOnfleet;
    }

    public void setTipsAndTricksIdOnfleet (String tipsAndTricksIdOnfleet)
    {
        this.tipsAndTricksIdOnfleet = tipsAndTricksIdOnfleet;
    }

    public String getParkingIdOnfleet ()
    {
        return parkingIdOnfleet;
    }

    public void setParkingIdOnfleet (String parkingIdOnfleet)
    {
        this.parkingIdOnfleet = parkingIdOnfleet;
    }

    public String getMapLink ()
    {
        return mapLink;
    }

    public void setMapLink (String mapLink)
    {
        this.mapLink = mapLink;
    }
    
    public String getLastModifiedTimestamp ()
    {
        return lastModifiedTimestamp;
    }

    public void setLastModifiedTimestamp (String lastModifiedTimestamp)
    {
        this.lastModifiedTimestamp = lastModifiedTimestamp;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }
    
    public void setDriverCount (int driverCount)
    {
        this.driverCount = driverCount;
    }

    public int getDriverCount ()
    {
        return driverCount;
    }

    public void setHourlyRate (double hourlyRate)
    {
        this.hourlyRate = hourlyRate;
    }

    public double getHourlyRate ()
    {
        return hourlyRate;
    }
    
    public String[] getZones ()
    {
        return zones;
    }

    public void setZones (String[] zones)
    {
        this.zones = zones;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [archived = "+archived+", parkingIdOnfleet = "+parkingIdOnfleet+", mapLink = "+mapLink+", tipsAndTricksIdOnfleet = "+tipsAndTricksIdOnfleet+", lastModifiedTimestamp = "+lastModifiedTimestamp+", id = "+id+", zones = "+zones+", name = "+name+"]";
    }
	
}
