package com.heb.automation.Services.HomeDelivery.Drivers;

public class DriversByProfileID_DriverZones
{
	private String lastModifiedTimestamp;

    private DriversByProfileID_Zone zone;

    private boolean primary;

    public void setLastModifiedTimestamp(String lastModifiedTimestamp){
        this.lastModifiedTimestamp = lastModifiedTimestamp;
    }
    public String getLastModifiedTimestamp(){
        return this.lastModifiedTimestamp;
    }
    public void setZone(DriversByProfileID_Zone zone){
        this.zone = zone;
    }
    public DriversByProfileID_Zone getZone(){
        return this.zone;
    }
    public void setPrimary(boolean primary){
        this.primary = primary;
    }
    public boolean getPrimary(){
        return this.primary;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [lastModifiedTimestamp = "+lastModifiedTimestamp+", primary = "+primary+", zone = "+zone+"]";
    }
}