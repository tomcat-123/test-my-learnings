package com.heb.automation.Services.BodyParameter.TimeSheet;

public class TimeSheetSearch_Body {
	
	private String driverLastName;

    private String driverFirstName;

	private String endOfWeek;
    
    private String startOfWeek;
    
    public String getEndOfWeek() {
		return endOfWeek;
	}

	public void setEndOfWeek(String endOfWeek) {
		this.endOfWeek = endOfWeek;
	}

    public String getDriverLastName ()
    {
        return driverLastName;
    }

    public void setDriverLastName (String driverLastName)
    {
        this.driverLastName = driverLastName;
    }

    public String getDriverFirstName ()
    {
        return driverFirstName;
    }

    public void setDriverFirstName (String driverFirstName)
    {
        this.driverFirstName = driverFirstName;
    }

    public String getStartOfWeek ()
    {
        return startOfWeek;
    }

    public void setStartOfWeek (String startOfWeek)
    {
        this.startOfWeek = startOfWeek;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [driverLastName = "+driverLastName+", driverFirstName = "+driverFirstName+", startOfWeek = "+startOfWeek+"]";
    }

}
