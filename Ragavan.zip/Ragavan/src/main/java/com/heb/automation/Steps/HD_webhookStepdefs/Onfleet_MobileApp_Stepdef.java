package com.heb.automation.Steps.HD_webhookStepdefs;

import java.util.HashMap;
import java.util.Map;

import com.heb.automation.Pages.MobileTaskTestPage;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.*;
import com.heb.automation.Pages.MobileTaskTestPage;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class Onfleet_MobileApp_Stepdef extends TestDataContainer {
	@QAFTestStep(description = "I See the task list page")
	public void iSeeTheTaskListPage() {
		MobileTaskTestPage tp = new MobileTaskTestPage();
		tp.getTaskBtnLeftNav().waitForPresent(5000);
		tp.getTaskTxtTaskList().get(0).waitForPresent(5000);
	}

	@QAFTestStep(description = "I click on Task")
	public void iClickOnTask() {
		MobileTaskTestPage tp = new MobileTaskTestPage();
		tp.getTaskTxtTaskList().get(0).click();
	}

	@QAFTestStep(description = "I see task details page")
	public void iSeeTaskDetailsPage() {
		MobileTaskTestPage tp = new MobileTaskTestPage();
		tp.getTaskTxtTaskDetails().verifyPresent();
	}

	@QAFTestStep(description = "I complete slide")
	public void iCompleteSlide() {
		MobileTaskTestPage tp = new MobileTaskTestPage();

		while (tp.getTaskBtnSlide().isPresent()) {
			
		Map<String, Object> params1 = new HashMap<>();
		params1.put("start", "147,2349");
		params1.put("end", "1322,2349");
		Object result1 = PerfectoUtils.getAppiumDriver().executeScript("mobile:touch:swipe", params1);	
		}

	}

	@QAFTestStep(description = "I see the task complete page")
	public void iSeeTheTaskCompletePage() {
		MobileTaskTestPage tp = new MobileTaskTestPage();
		tp.getTaskBtnTaskComplete().verifyPresent();
	}

	@QAFTestStep(description = "I click ok tick")
	public void iClickOkTick() {
		MobileTaskTestPage tp = new MobileTaskTestPage();
		tp.getTaskBtnTaskComplete().click();	
		tp.getTaskBtnYes().waitForPresent(5000);
		tp.getTaskBtnYes().click();
	}
	
	@QAFTestStep(description = "I uncheck delivery successful")
	public void iUncheckDeliverySuccessful() {
		MobileTaskTestPage tp = new MobileTaskTestPage();
		tp.getTaskBtnCheckBoxChecked().click();
	}
	
	@QAFTestStep(description = "I verify failure reason displayed")
	public void iVerifyFailureReasonDisplayed() {
		MobileTaskTestPage tp = new MobileTaskTestPage();
		tp.getTaskTxtFailureReason().verifyPresent();
	}
	
	@QAFTestStep(description = "I select failure radio button")
	public void iSelectFailureRadioButton() {
		MobileTaskTestPage tp = new MobileTaskTestPage();
		tp.getTaskBtnFaliureList().get(0).click();
	}
	
}
