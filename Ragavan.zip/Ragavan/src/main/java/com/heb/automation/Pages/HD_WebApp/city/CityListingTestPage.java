package com.heb.automation.Pages.HD_WebApp.city;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CityListingTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}
	
	@FindBy (locator="citylist.lbl.title")
	private QAFWebElement citylistlbltitle;
	
	@FindBy (locator="citylist.btn.cityCrumb")
	private QAFWebElement citylistbtncityCrumb;
	
	@FindBy (locator="citylist.btn.addnew")
	private QAFWebElement citylistbtnaddnew;
	
	@FindBy (locator="citylist.lbl.totalrecods")
	private QAFWebElement citylistlbltotalrecods;
	
	@FindBy (locator="citylist.lbl.displayrecords")
	private QAFWebElement citylistlbldisplayrecords;
	
	
	public QAFWebElement getLblDisplayRecords() {
		return citylistlbldisplayrecords;
	}

	public QAFWebElement getLblTitle() {
		return citylistlbltitle;
	}

	public QAFWebElement getBtnCityCrumb() {
		return citylistbtncityCrumb;
	}

	public QAFWebElement getBtnAddnew() {
		return citylistbtnaddnew;
	}

	public QAFWebElement getLblTotalRecods() {
		return citylistlbltotalrecods;
	}
		
}
