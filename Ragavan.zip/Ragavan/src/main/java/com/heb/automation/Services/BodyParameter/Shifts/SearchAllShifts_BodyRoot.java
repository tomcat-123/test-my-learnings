package com.heb.automation.Services.BodyParameter.Shifts;

import java.util.ArrayList;

public class SearchAllShifts_BodyRoot {
	private String sortBy;

    private ArrayList<SearchAllShifts_SearchCriteria> searchCriteria = new ArrayList<SearchAllShifts_SearchCriteria>();

    private String pageSize;

    private String pageNumber;

    private String sortDirection;

    public String getSortBy ()
    {
        return sortBy;
    }

    public void setSortBy (String sortBy)
    {
        this.sortBy = sortBy;
    }

    public ArrayList<SearchAllShifts_SearchCriteria> getSearchCriteria ()
    {
        return searchCriteria;
    }

    public void setSearchCriteria (ArrayList<SearchAllShifts_SearchCriteria> searchCriteria)
    {
        this.searchCriteria = searchCriteria;
    }

    public String getPageSize ()
    {
        return pageSize;
    }

    public void setPageSize (String pageSize)
    {
        this.pageSize = pageSize;
    }

    public String getPageNumber ()
    {
        return pageNumber;
    }

    public void setPageNumber (String pageNumber)
    {
        this.pageNumber = pageNumber;
    }

    public String getSortDirection ()
    {
        return sortDirection;
    }

    public void setSortDirection (String sortDirection)
    {
        this.sortDirection = sortDirection;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [sortBy = "+sortBy+", searchCriteria = "+searchCriteria+", pageSize = "+pageSize+", pageNumber = "+pageNumber+", sortDirection = "+sortDirection+"]";
    }
	

}
