package com.heb.automation.Services.HomeDelivery.Search.ShiftsSearchResult;

public class SearchAllShifts_Root {
	
	private String apiStatus;

    private SearchAllShifts_Data data;

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

    public SearchAllShifts_Data getData ()
    {
        return data;
    }

    public void setData (SearchAllShifts_Data data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [apiStatus = "+apiStatus+", data = "+data+"]";
    }
	

}
