package com.heb.automation.Pages.HD_WebApp.order;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class OrderCreateTestPage extends WebDriverBaseTestPage<WebDriverTestPage>{

	@FindBy (locator="ordercreate.lbl.title")
	private QAFWebElement ordercreatelbltitle;
	
	@FindBy (locator="ordercreate.btn.crump")
	private QAFWebElement ordercreatebtncrump;
	 
	@FindBy (locator="ordercreate.lbl.orderdetail")
	private QAFWebElement ordercreatelblorderdetail;
	
	@FindBy (locator="ordercreate.txt.orderid")
	private QAFWebElement ordercreatetxtorderid;
	
	@FindBy (locator="ordercreate.txt.tip")
	private QAFWebElement ordercreatetxttip;
	
	@FindBy (locator="ordercreate.txt.instructions")
	private QAFWebElement ordercreatetxtinstructions;
	
	@FindBy (locator="ordercreate.txt.grossbill")
	private QAFWebElement ordercreatetxtgrossbill ;
	
	@FindBy (locator="ordercreate.txt.invoice")
	private QAFWebElement ordercreatetxtinvoice;
	 
	@FindBy (locator="ordercreate.lbl.store")
	private QAFWebElement ordercreatelblstore;
	
	@FindBy (locator="ordercreate.txt.store")
	private QAFWebElement ordercreatetxtstore;
	
	@FindBy (locator="ordercreate.lbl.customer")
	private QAFWebElement ordercreatelblcustomer;
	
	@FindBy (locator="ordercreate.txt.firstName")
	private QAFWebElement ordercreatetxtfirstName;
	 
	@FindBy (locator="ordercreate.txt.phone")
	private QAFWebElement ordercreatetxtphone;
	 
	@FindBy (locator="ordercreate.txt.lastName")
	private QAFWebElement ordercreatetxtlastName;
	 
	@FindBy (locator="ordercreate.txt.email")
	private QAFWebElement ordercreatetxtemail;
	 
	@FindBy (locator="ordercreate.lbl.recipientsame")
	private QAFWebElement ordercreatelblrecipientsame;
	
	@FindBy (locator="ordercreate.radiobutton.recipientyes")
	private QAFWebElement ordercreateradiobuttonrecipientyes;
	
	@FindBy (locator="ordercreate.radiobutton.recipientno")
	private QAFWebElement ordercreateradiobuttonrecipientno;
	 
	@FindBy (locator="ordercreate.lbl.recipientyes")
	private QAFWebElement ordercreatelblrecipientyes;
	
	@FindBy (locator="ordercreate.lbl.recipientno")
	private QAFWebElement ordercreatelblrecipientno;
	
	@FindBy (locator="ordercreate.lbl.recipient")
	private QAFWebElement ordercreatelblrecipient;
	 
	@FindBy (locator="ordercreate.txt.recipientfirstname")
	private QAFWebElement ordercreatetxtrecipientfirstname;
	
	@FindBy (locator="ordercreate.txt.recipientLastName")
	private QAFWebElement ordercreatetxtrecipientLastName;
	
	@FindBy (locator="ordercreate.txt.recipientPhone")
	private QAFWebElement ordercreatetxtrecipientPhone;
	 
	@FindBy (locator="ordercreate.txt.recipientEmail")
	private QAFWebElement ordercreatetxtrecipientEmail;
	
	@FindBy (locator="ordercreate.lbl.deliveryaddress")
	private QAFWebElement ordercreatelbldeliveryaddress;
	 
	@FindBy (locator="ordercreate.txt.address1")
	private QAFWebElement ordercreatetxtaddress1;
	
	@FindBy (locator="ordercreate.txt.address2")
	private QAFWebElement ordercreatetxtaddress2;
	
	@FindBy (locator="ordercreate.txt.city")
	private QAFWebElement ordercreatetxtcity;
	
	@FindBy (locator="ordercreate.txt.state")
	private QAFWebElement ordercreatetxtstate;
	
	@FindBy (locator="ordercreate.txt.zip")
	private QAFWebElement ordercreatetxtzip;
	
	@FindBy (locator="ordercreate.txt.note")
	private QAFWebElement ordercreatetxtnote;
	 
	@FindBy (locator="ordercreate.txt.latitude")
	private QAFWebElement ordercreatetxtlatitude;
	 
	@FindBy (locator="ordercreate.txt.longitude")
	private QAFWebElement ordercreatetxtlongitude;
	 
	@FindBy (locator="ordercreate.lbl.deliveryschedule")
	private QAFWebElement ordercreatelbldeliveryschedule;
	
	@FindBy (locator="ordercreate.txt.startTime")
	private QAFWebElement ordercreatetxtstartTime;
	
	@FindBy (locator="ordercreate.li.startTimes")
	private List<QAFWebElement> liStartTimes;
	
	@FindBy (locator="ordercreate.txt.date")
	private QAFWebElement txtDate ;
	
	@FindBy (locator="ordercreate.txt.endTime")
	private QAFWebElement ordercreatetxtendTime;
	
	@FindBy (locator="ordercreate.lbl.status")
	private QAFWebElement ordercreatelblstatus;
	
	@FindBy (locator="ordercreate.lbl.containsalcohol")
	private QAFWebElement ordercreatelblcontainsalcohol;
	
	@FindBy (locator="ordercreate.radiobutton.containsalcoholyes")
	private QAFWebElement ordercreateradiobuttoncontainsalcoholyes;
	
	@FindBy (locator="ordercreate.radiobutton.containsalcoholno")
	private QAFWebElement ordercreateradiobuttoncontainsalcoholno;
	
	@FindBy (locator="ordercreate.lbl.containsalcoholyes")
	private QAFWebElement ordercreatelblcontainsalcoholyes;
	
	@FindBy (locator="ordercreate.lbl.containsalcoholno")
	private QAFWebElement ordercreatelblcontainsalcoholno;
	
	@FindBy (locator="ordercreate.lbl.containsstatus")
	private QAFWebElement ordercreatelblcontainsstatus;
	
	@FindBy (locator="ordercreate.radiobutton.statusnew")
	private QAFWebElement ordercreateradiobuttonstatusnew;
	
	@FindBy (locator="ordercreate.radiobutton.statuscanceled")
	private QAFWebElement ordercreateradiobuttonstatuscanceled;
	
	@FindBy (locator="ordercreate.lbl.statusnew")
	private QAFWebElement ordercreatelblstatusnew;
	
	@FindBy (locator="ordercreate.lbl.statuscanceled")
	private QAFWebElement ordercreatelblstatuscanceled;
	
	@FindBy (locator="ordercreate.lbl.onfleet")
	private QAFWebElement ordercreatelblonfleet;
	
	@FindBy (locator="ordercreate.lbl.createonfleetpin")
	private QAFWebElement ordercreatelblcreateonfleetpin;
	
	@FindBy (locator="ordercreate.radiobutton.createonfleetpinyes")
	private QAFWebElement ordercreateradiobuttoncreateonfleetpinyes;
	
	@FindBy (locator="ordercreate.radiobutton.createonfleetpinno")
	private QAFWebElement ordercreateradiobuttoncreateonfleetpinno;
	
	@FindBy (locator="ordercreate.lbl.createonfleetpinyes")
	private QAFWebElement ordercreatelblcreateonfleetpinyes;
	
	@FindBy (locator="ordercreate.lbl.createonfleetpinno")
	private QAFWebElement ordercreatelblcreateonfleetpinno;
	 
	@FindBy (locator="ordercreate.txt.onfleettaskid")
	private QAFWebElement ordercreatetxtonfleettaskid;
	
	@FindBy (locator="ordercreate.btn.save")
	private QAFWebElement ordercreatebtnsave;
	 
	@FindBy (locator="ordercreate.btn.cancel")
	private QAFWebElement ordercreatebtncancel; 
	
	@FindBy (locator="ordercreate.li.storenames")
	private List<QAFWebElement> liStoreNames; 
	
	public List<QAFWebElement> getliStoreNames() {
		return liStoreNames;
	}
	 
	public QAFWebElement getLblTitle() {
		return ordercreatelbltitle;
	}

	public QAFWebElement getBtnCrump() {
		return ordercreatebtncrump;
	}

	public QAFWebElement getLblOrderDetail() {
		return ordercreatelblorderdetail;
	}

	public QAFWebElement getTxtOrderId() {
		return ordercreatetxtorderid;
	}

	public QAFWebElement getTxtTip() {
		return ordercreatetxttip;
	}

	public QAFWebElement getTxtInstructions() {
		return ordercreatetxtinstructions;
	}

	public QAFWebElement getTxtGrossBill() {
		return ordercreatetxtgrossbill;
	}

	public QAFWebElement getTxtInvoice() {
		return ordercreatetxtinvoice;
	}

	public QAFWebElement getLblStore() {
		return ordercreatelblstore;
	}

	public QAFWebElement getTxtStore() {
		return ordercreatetxtstore;
	}

	public QAFWebElement getLblCustomer() {
		return ordercreatelblcustomer;
	}

	public QAFWebElement getTxtFirstName() {
		return ordercreatetxtfirstName;
	}

	public QAFWebElement getTxtPhone() {
		return ordercreatetxtphone;
	}

	public QAFWebElement getTxtLastName() {
		return ordercreatetxtlastName;
	}

	public QAFWebElement getTxtEmail() {
		return ordercreatetxtemail;
	}

	public QAFWebElement getLblRecipientSame() {
		return ordercreatelblrecipientsame;
	}

	public QAFWebElement getRadioButtonRecipientYes() {
		return ordercreateradiobuttonrecipientyes;
	}

	public QAFWebElement getRadioButtonRecipientNo() {
		return ordercreateradiobuttonrecipientno;
	}

	public QAFWebElement getLblRecipientYes() {
		return ordercreatelblrecipientyes;
	}

	public QAFWebElement getLblRecipientNo() {
		return ordercreatelblrecipientno;
	}

	public QAFWebElement getLblRecipient() {
		return ordercreatelblrecipient;
	}

	public QAFWebElement getTxtRecipientFirstname() {
		return ordercreatetxtrecipientfirstname;
	}

	public QAFWebElement getTxtRecipientLastName() {
		return ordercreatetxtrecipientLastName;
	}

	public QAFWebElement getTxtRecipientPhone() {
		return ordercreatetxtrecipientPhone;
	}

	public QAFWebElement getTxtRecipientEmail() {
		return ordercreatetxtrecipientEmail;
	}

	public QAFWebElement getLblDeliveryaddress() {
		return ordercreatelbldeliveryaddress;
	}

	public QAFWebElement getTxtAddress1() {
		return ordercreatetxtaddress1;
	}

	public QAFWebElement getTxtAddress2() {
		return ordercreatetxtaddress2;
	}

	public QAFWebElement getTxtCity() {
		return ordercreatetxtcity;
	}

	public QAFWebElement getTxtState() {
		return ordercreatetxtstate;
	}

	public QAFWebElement getTxtZip() {
		return ordercreatetxtzip;
	}

	public QAFWebElement getTxtNote() {
		return ordercreatetxtnote;
	}

	public QAFWebElement getTxtLatitude() {
		return ordercreatetxtlatitude;
	}

	public QAFWebElement getTxtLongitude() {
		return ordercreatetxtlongitude;
	}

	public QAFWebElement getLblDeliverySchedule() {
		return ordercreatelbldeliveryschedule;
	}

	public QAFWebElement getTxtStartTime() {
		return ordercreatetxtstartTime;
	}
	public List<QAFWebElement> getliStartTimes() {
		return liStartTimes;
	}
	public QAFWebElement getxtDate() {
		return txtDate;
	}

	public QAFWebElement getTxtEndTime() {
		return ordercreatetxtendTime;
	}

	public QAFWebElement getLblStatus() {
		return ordercreatelblstatus;
	}

	public QAFWebElement getLblContainsAlcohol() {
		return ordercreatelblcontainsalcohol;
	}

	public QAFWebElement getRadioButtonContainsAlcoholYes() {
		return ordercreateradiobuttoncontainsalcoholyes;
	}

	public QAFWebElement getRadioButtonContainsAlcoholNo() {
		return ordercreateradiobuttoncontainsalcoholno;
	}

	public QAFWebElement getLblContainsAlcoholYes() {
		return ordercreatelblcontainsalcoholyes;
	}

	public QAFWebElement getLblContainsAlcoholNo() {
		return ordercreatelblcontainsalcoholno;
	}

	public QAFWebElement getLblContainsStatus() {
		return ordercreatelblcontainsstatus;
	}

	public QAFWebElement getRadioButtonStatusNew() {
		return ordercreateradiobuttonstatusnew;
	}

	public QAFWebElement getRadioButtonStatusCanceled() {
		return ordercreateradiobuttonstatuscanceled;
	}

	public QAFWebElement getLblStatusNew() {
		return ordercreatelblstatusnew;
	}

	public QAFWebElement getLblStatusCanceled() {
		return ordercreatelblstatuscanceled;
	}

	public QAFWebElement getLblOnfleet() {
		return ordercreatelblonfleet;
	}

	public QAFWebElement getLblCreateOnfleetPin() {
		return ordercreatelblcreateonfleetpin;
	}

	public QAFWebElement getRadioButtonCreateOnfleetPinYes() {
		return ordercreateradiobuttoncreateonfleetpinyes;
	}

	public QAFWebElement getRadioButtOncreateOnfleetPinNo() {
		return ordercreateradiobuttoncreateonfleetpinno;
	}

	public QAFWebElement getLblCreateOnfleetpinYes() {
		return ordercreatelblcreateonfleetpinyes;
	}

	public QAFWebElement getLblCreateOnfleetpinNo() {
		return ordercreatelblcreateonfleetpinno;
	}

	public QAFWebElement getTxtOnfleetTaskId() {
		return ordercreatetxtonfleettaskid;
	}

	public QAFWebElement getBtnSave() {
		return ordercreatebtnsave;
	}

	public QAFWebElement getBtnCancel() {
		return ordercreatebtncancel;
	}


	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}

}
