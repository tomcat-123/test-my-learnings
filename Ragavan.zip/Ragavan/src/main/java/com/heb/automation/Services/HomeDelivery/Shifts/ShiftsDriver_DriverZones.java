package com.heb.automation.Services.HomeDelivery.Shifts;

public class ShiftsDriver_DriverZones {
	
	private String lastModifiedTimestamp;

    private String primary;

    private ShiftsDriver_DriverZones_Zone zone;

    public String getLastModifiedTimestamp ()
    {
        return lastModifiedTimestamp;
    }

    public void setLastModifiedTimestamp (String lastModifiedTimestamp)
    {
        this.lastModifiedTimestamp = lastModifiedTimestamp;
    }

    public String getPrimary ()
    {
        return primary;
    }

    public void setPrimary (String primary)
    {
        this.primary = primary;
    }

    public ShiftsDriver_DriverZones_Zone getZone ()
    {
        return zone;
    }

    public void setZone (ShiftsDriver_DriverZones_Zone zone)
    {
        this.zone = zone;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [lastModifiedTimestamp = "+lastModifiedTimestamp+", primary = "+primary+", zone = "+zone+"]";
    }

}
