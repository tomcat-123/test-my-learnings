package com.heb.automation.Steps.HD_WebApp.zone;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import com.heb.automation.Pages.HD_WebApp.CommonTestPage;
import com.heb.automation.Pages.HD_WebApp.zone.ZoneCreateTestPage;
import com.heb.automation.Pages.HD_WebApp.zone.ZoneDisplayTestPage;
import com.heb.automation.common.CommonDBUtils;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CreateZone_WebAppStepdef extends TestDataContainer {

	@QAFTestStep(description = "verify the Create Zone Page")
	public void iVerifyTheCreateZonePage() {
		ZoneCreateTestPage zCPage = new ZoneCreateTestPage();
		CommonTestPage common = new CommonTestPage();

		zCPage.getLblTitle().waitForPresent(5000);
		zCPage.getBtnCreateZoneCrumb().verifyPresent();
		zCPage.getBtnCreateZoneCrumb().click();
		zCPage.getLblTitle().waitForPresent(5000);
		zCPage.getTxtZoneName().verifyPresent();
		zCPage.getTxtZipcode().verifyPresent();
		//zCPage.getTxtOnfleetTeamId().verifyPresent();
		zCPage.getTxtCity().verifyPresent();
		zCPage.getBtnSave().verifyPresent();
		zCPage.getBtnCancel().verifyPresent();
		zCPage.getDropdownCity().verifyPresent();
		common.getLblHomeIcon().verifyPresent();
		common.getLblHomeRightArrow().verifyPresent();
	}

	@QAFTestStep(description = "select a Zone by mouse click in create zone page")
	public void iSelectAZoneByMouseClickInCreateZonePage() {
		ZoneCreateTestPage zCPage = new ZoneCreateTestPage();
// please add the names  and city and zone  to this secanario 
		String Zipcode;

		zCPage.getTxtZipcode().click();
		Zipcode = zCPage.getLblZipCodeOptions().get(0).getText();
		zCPage.getLblZipCodeOptions().get(0).click();
		zCPage.getLblZipCodeOptions().get(0).click();
		putTestObject("zipcode", Zipcode);

	}

	@QAFTestStep(description = "verify user is able to pick zip codes from the list in create zone page")
	public void iVerifyUserIsAbleToPickZipCodesFromTheListInCreateZonePage() {
		ZoneCreateTestPage zCPage = new ZoneCreateTestPage();

		String SlectedZipcode;
		String Zipcde = getTestString("zipcode");

		zCPage.getLblSelectedZone().get(0).waitForPresent(1000);
		SlectedZipcode = zCPage.getLblSelectedZone().get(0).getText();

		if (Zipcde.equals(SlectedZipcode))
			PerfectoUtils.reportMessage("The user is able to select ZipCode ", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("The user is not able to select ZipCode ", MessageTypes.Fail);

	}

	@QAFTestStep(description = "enter zone name in zone creation page")
	public void iEnterZoneNameInZoneCreationPage() {
		ZoneCreateTestPage zCPage = new ZoneCreateTestPage();

		zCPage.getTxtZoneName().waitForPresent(50000);
		String zoneName = "Automation_"+generateRandomString();
		zCPage.getTxtZoneName().sendKeys(zoneName);
		putTestObject("zoneNameEnterd", zoneName);

	}

	@QAFTestStep(description = "select city in zone creation page")
	public void iSelectCityInZoneCreationPage() {
		ZoneCreateTestPage zCPage = new ZoneCreateTestPage();

		zCPage.getTxtCity().click();
		zCPage.getLblCityOptions().get(0).waitForPresent(1000);
		String SelectedCity = zCPage.getLblCityOptions().get(0).getText();
		putTestObject("CitySelected", SelectedCity);
		zCPage.getLblCityOptions().get(0).click();
	}

	@QAFTestStep(description = "select zip code in zone creation page")
	public void iSelectZipCodeInZoneCreationPage() {
		ZoneCreateTestPage zCPage = new ZoneCreateTestPage();

		zCPage.getTxtZipcode().click();
		zCPage.getLblZipCodeOptions().get(0).waitForPresent(1000);
		String zipSelected = zCPage.getLblZipCodeOptions().get(0).getText();
		putTestObject("ZipSelected", zipSelected);
		zCPage.getLblZipCodeOptions().get(0).click();
		zCPage.getLblZipCodeOptions().get(0).click();
	}

	@QAFTestStep(description = "click on Save button in create Page")
	public void iClickOnSaveButtonInCreateZonePage() {
		ZoneCreateTestPage zCPage = new ZoneCreateTestPage();

		zCPage.getBtnSave().click();
	}

	public static String generateRandomString() {

		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 6;
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();

		return generatedString;

	}
	
	
	/**
	* Auto-generated code snippet by QMetry Automation Framework.
	*/
	@QAFTestStep(description="I verify Zip Code field displays zip codes from phd_allowed_zipcode table with query {SelectQuery}")
	public void iVerifyZipCodeFieldDisplaysZipCodesFromPhd_allowed_zipcodeTable(String SelectQuery ){
		
		
		
	}
	
	
	/**
	* Auto-generated code snippet by QMetry Automation Framework.
	*/
	@QAFTestStep(description="verify Zone page displays valid data for a sample zone with query {zoneidQuery}")
	public void iVerifyZonePageDisplaysValidDataForASampleZoneWithQuery(String zoneidQuery){
		System.out.println(zoneidQuery);
		Map<Integer,String> mapExpected = new HashMap<Integer,String>();
		Map<Integer,String> mapActual = new HashMap<Integer,String>();
		TreeMap<Integer,HashMap<String,String>> selectResult=null;
		ZoneDisplayTestPage zDisplay = new ZoneDisplayTestPage();
		int keyValue =1;
		
		//Get the Actual value from Zone display page
		for(QAFWebElement zip: zDisplay.getLblSelectedZipcode()){	
		mapActual.put(keyValue, zip.getText());
		keyValue++;
		}
		
		CommonDBUtils dbUtil= new CommonDBUtils();
		String str=getTestString("zoneselected"); // Please look for zone selected.
		//String str="A TestZone1"; 
		zoneidQuery=zoneidQuery.replace("{Zone_Name}", str);
		System.out.println(zoneidQuery);
		Connection con=null;
		try {
			 con=dbUtil.getConnection();
			 selectResult=	dbUtil.selectQuery(con,zoneidQuery);		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbUtil.closeConnection(con);
		}
		
		for (int i=1;i<=selectResult.size();i++) {
			mapExpected.put(i, selectResult.get(i).get("ZipCode"));			
		}
				
		if(mapActual.equals(mapExpected)) {
			PerfectoUtils.reportMessage("The user is able to verify ZipCode ", MessageTypes.Pass);
		}else {
			PerfectoUtils.reportMessage("The user is unable to verify ZipCode ", MessageTypes.Fail);
		}
		
	}
}