package com.heb.automation.Pages.HD_WebApp.zone;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ZoneCreateTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
	
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}
	
	@FindBy(locator = "zonecreate.btn.save")
	private QAFWebElement zonecreatebtnsave;

	@FindBy(locator = "zonecreate.txt.zonename")
	private QAFWebElement zonecreatetxtzonename;

	@FindBy(locator = "zonecreate.txt.onfleetteamid")
	private QAFWebElement zonecreatetxtonfleetteamid;

	@FindBy(locator = "zonecreate.txt.city")
	private QAFWebElement zonecreatetxtcity;

	@FindBy(locator = "zonecreate.txt.zipcode")
	private QAFWebElement zonecreatetxtzipcode;

	@FindBy(locator = "zonecreate.btn.cancel")
	private QAFWebElement zonecreatebtncancel;

	@FindBy(locator = "zonecreate.btn.createzonecrumb")
	private QAFWebElement zonecreatebtncreatezonecrumb;

	@FindBy(locator = "zonecreate.lbl.title")
	private QAFWebElement zonecreatelbltitle;
	
	@FindBy(locator = "zonecreate.lbl.zipcodeoptions")
	private List<QAFWebElement> zonecreatelblzipcodeoptions;
	
	@FindBy(locator = "zonecreate.lbl.selectedzipcode")
	private List<QAFWebElement> zonecreatelblselectedzipcode;
		
	@FindBy(locator = "zonecreate.lbl.cityoptions")
	private List<QAFWebElement> zonecreatelblcityoptions;
	
	@FindBy(locator = "zonecreate.dropdown.city")
	private QAFWebElement zonecreatedropdowncity;
	
	
	public QAFWebElement getDropdownCity() {
		return zonecreatedropdowncity;
	}
	
	public List<QAFWebElement> getLblCityOptions() {
		return zonecreatelblcityoptions;
	}
	
	public List<QAFWebElement> getLblZipCodeOptions() {
		return zonecreatelblzipcodeoptions;
	}
	
	public List<QAFWebElement> getLblSelectedZone() {
		return zonecreatelblselectedzipcode;
	}

	public QAFWebElement getBtnSave() {
		return zonecreatebtnsave;
	}

	public QAFWebElement getTxtZoneName() {
		return zonecreatetxtzonename;
	}

	public QAFWebElement getTxtOnfleetTeamId() {
		return zonecreatetxtonfleetteamid;
	}

	public QAFWebElement getTxtCity() {
		return zonecreatetxtcity;
	}

	public QAFWebElement getTxtZipcode() {
		return zonecreatetxtzipcode;
	}

	public QAFWebElement getBtnCancel() {
		return zonecreatebtncancel;
	}

	public QAFWebElement getBtnCreateZoneCrumb() {
		return zonecreatebtncreatezonecrumb;
	}

	public QAFWebElement getLblTitle() {
		return zonecreatelbltitle;
	}
		
}
