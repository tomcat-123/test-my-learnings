package com.heb.automation.common;

import java.util.HashMap;
import java.util.List;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.util.StringUtil;

public class TestDataContainer {
	/**
	 * This method provides a reference handle to manipulate a HashMap of
	 * test-specific data. Encapsulation is provided by TestDataContainerListener
	 * which will always reinitialize the contents of the HashMap at the start of
	 * every test in order to prevent data leakage between tests on the same thread.
	 * 
	 * Note: This class will fetch the requested value from configuration IF AND ONLY IF
	 * the value is not already present in the HashMap for this test. However, this class
	 * will never put values into configuration except as a key/value pair in the HashMap.
	 * 
	 * Note: Instead of using ConfigurationManager.getBundle().addProperty() and its
	 * siblings methods, replace those references with putTest*() or getTest*()
	 * instead.
	 * 
	 * Note: This class assumes a last-in-wins conflict management protocol. No check is
	 * made to prevent overwriting of existing values.
	 * 
	 * Note: If desired, this functionality can be incorporated directly into a test
	 * class by inheritance and simplify broad implementation.
	 * 
	 * @return HashMap<String, Object> containing test-specific data.
	 */
	private static HashMap<String, Object> _testDataContainer() {
		HashMap<String,Object> map = (HashMap<String, Object>)ConfigurationManager.getBundle().getObject("Test Data Container");
		if(map==null) {
			clear();
			map = (HashMap<String, Object>)ConfigurationManager.getBundle().getObject("Test Data Container");
		}
		return map;
	}
	
	public static void clear() {
		ConfigurationManager.getBundle().addProperty("Test Data Container", new HashMap<String,Object>());
	}

	public static void putTestObject(String key, Object value) {
		_testDataContainer().put(key, value);
	}

	public static Object getTestObject(String key) {
		Object result = _testDataContainer().get(key);
		if(result == null) {
			result = ConfigurationManager.getBundle().getObject(key);
		}
		return result; // WARNING: This value may still be null if it's undefined in configuration and not yet defined by the test.
	}

	public static String getTestString(String key) {
		return (String) getTestObject(key);
	}

	public static String getTestString(String key, String defaultValue) {
		String value = (String) getTestObject(key);
		if (StringUtil.isNullOrEmpty(value)) {
			return defaultValue;
		}
		return value;
	}

	public static String[] getTestStringArray(String key) {
		return (String[]) getTestObject(key);
	}

	public static List<String> getTestList(String key) {
		return (List<String>) getTestObject(key);
	}
}