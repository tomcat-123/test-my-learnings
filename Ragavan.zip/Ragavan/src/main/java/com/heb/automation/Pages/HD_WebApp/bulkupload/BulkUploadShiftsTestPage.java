package com.heb.automation.Pages.HD_WebApp.bulkupload;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class BulkUploadShiftsTestPage extends WebDriverBaseTestPage<WebDriverTestPage>{

	@FindBy(locator = "bulkupload.lbl.title")
	private QAFWebElement bulkuploadlbltitle;
	
	@FindBy(locator = "bulkupload.btn.shiftsplannercrump")
	private QAFWebElement bulkuploadbtnshiftsplannercrump;
	
	@FindBy(locator = "bulkupload.btn.bulkuploadcrump")
	private QAFWebElement bulkuploadbtnbulkuploadcrump;
	
	@FindBy(locator = "bulkupload.lbl.subtitle")
	private QAFWebElement bulkuploadlblsubtitle;
	
	@FindBy(locator = "bulkupload.lnk.downloadtemplate")
	private QAFWebElement bulkuploadlnkdownloadtemplate;
	
	@FindBy(locator = "bulkupload.txt.shiftstartdate")
	private QAFWebElement bulkuploadtxtshiftstartdate;
	
	@FindBy(locator = "bulkupload.txt.shiftenddate")
	private QAFWebElement bulkuploadtxtshiftenddate;
	
	@FindBy(locator = "bulkupload.txt.publishon")
	private QAFWebElement bulkuploadtxtpublishon;
	
	@FindBy(locator = "bulkupload.txt.publishtimepicker")
	private QAFWebElement bulkuploadtxtpublishtimepicker;
	
	@FindBy(locator = "bulkupload.btn.choosefile")
	private QAFWebElement bulkuploadbtnchoosefile;
	
	@FindBy(locator = "bulkupload.btn.uploadexcel")
	private QAFWebElement bulkuploadbtnuploadexcel;
	
	@FindBy(locator = "bulkupload.btn.cancel")
	private QAFWebElement bulkuploadbtncancel;
	
	@FindBy(locator = "bulkupload.lbl.notetext")
	private QAFWebElement bulkuploadlblnotetext;
	
	@FindBy(locator = "bulkupload.btn.opencalendar")
	private List<QAFWebElement> bulkuploadbtnopencalendar;
	
	
	public QAFWebElement getLblTitle() {
		return bulkuploadlbltitle;
	}

	public QAFWebElement getBtnShiftsPlannerCrump() {
		return bulkuploadbtnshiftsplannercrump;
	}

	public QAFWebElement getBtnBulkUploadCrump() {
		return bulkuploadbtnbulkuploadcrump;
	}

	public QAFWebElement getLblSubtitle() {
		return bulkuploadlblsubtitle;
	}

	public QAFWebElement getLnkDownloadTemplate() {
		return bulkuploadlnkdownloadtemplate;
	}

	public QAFWebElement getTxtShiftStartDate() {
		return bulkuploadtxtshiftstartdate;
	}

	public QAFWebElement gettxtshiftenddate() {
		return bulkuploadtxtshiftenddate;
	}

	public QAFWebElement getTxtPublishon() {
		return bulkuploadtxtpublishon;
	}

	public QAFWebElement getTxtPublishTimePicker() {
		return bulkuploadtxtpublishtimepicker;
	}

	public QAFWebElement getBtnChooseFile() {
		return bulkuploadbtnchoosefile;
	}

	public QAFWebElement getbtnuploadexcel() {
		return bulkuploadbtnuploadexcel;
	}

	public QAFWebElement getBtnCancel() {
		return bulkuploadbtncancel;
	}

	public QAFWebElement getLblNoteText() {
		return bulkuploadlblnotetext;
	}

	public List<QAFWebElement> getBtnOpenCalendar() {
		return bulkuploadbtnopencalendar;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}
	
}
