package com.heb.automation.ErrorMessages;


public class Errors
{
private Message message;

private String status;

private Object object;

public Message getMessage ()
{
return message;
}

public void setMessage (Message message)
{
this.message = message;
}

public String getStatus ()
{
return status;
}

public void setStatus (String status)
{
this.status = status;
}

public Object getObject ()
{
return object;
}

public void setObject (Object object)
{
this.object = object;
}

@Override
public String toString()
{
return "ClassPojo [message = "+message+", status = "+status+", object = "+object+"]";
}
}
