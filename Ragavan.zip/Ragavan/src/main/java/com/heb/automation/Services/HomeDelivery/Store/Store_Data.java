package com.heb.automation.Services.HomeDelivery.Store;

import java.util.ArrayList;

public class Store_Data {

	private int id;

	private String lastModifiedTimestamp;

	private String phone;
	
	private Store_Address address = new Store_Address();

	private String name;

	private String active;

	private String ecomCloseDate;

	private String ecomOpenDate;

	private int apiHubId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLastModifiedTimestamp() {
		return lastModifiedTimestamp;
	}

	public void setLastModifiedTimestamp(String lastModifiedTimestamp) {
		this.lastModifiedTimestamp = lastModifiedTimestamp;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Store_Address getAddress() {
		return address;
	}

	public void setAddress(Store_Address address) {
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getEcomCloseDate ()
    {
        return ecomCloseDate;
    }

	public void setEcomCloseDate (String ecomCloseDate)
    {
        this.ecomCloseDate = ecomCloseDate;
    }

	public String getEcomOpenDate() {
		return ecomOpenDate;
	}

	public void setEcomOpenDate(String ecomOpenDate) {
		this.ecomOpenDate = ecomOpenDate;
	}

	public int getApiHubId() {
		return apiHubId;
	}

	public void setApiHubId(int apiHubId) {
		this.apiHubId = apiHubId;
	}

}
