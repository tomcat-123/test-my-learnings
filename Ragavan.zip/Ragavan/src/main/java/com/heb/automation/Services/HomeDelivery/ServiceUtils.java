package com.heb.automation.Services.HomeDelivery;

import com.heb.automation.common.TestDataContainer;

import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;
import com.qmetry.qaf.automation.ws.rest.RestWSTestCase;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

import gherkin.JSONParser;


public class ServiceUtils extends RestWSTestCase  {

	@SuppressWarnings("unused")
	private static Builder createWebResourceBuilder(Map<String, String> headers,MultivaluedMap<String, String> queryPar) {

	Client client = Client.create(ClientHelper.configureClient());

	String url = TestDataContainer.getTestString("env.baseurl")+TestDataContainer.getTestString("resource") ;
	Reporter.log(url);
	System.out.println(url);
	
	WebResource webResource = client.resource(url);
	if (queryPar != null) {
		webResource = webResource.queryParams(queryPar);
	}

	Builder builder = webResource.type("application/json").accept("application/json");
	
	if (headers != null && !headers.isEmpty()) {
		for (String key : headers.keySet()) {
			builder = builder.header(key, headers.get(key));
		}
	}
	
	return builder;
		
	}
	
	public static ClientResponse GET(Map<String, String> headers,MultivaluedMap<String, String> queryPar) throws UniformInterfaceException, ClientHandlerException, Exception {
		ClientResponse rClient = null ;
		
		rClient = createWebResourceBuilder(headers,queryPar).get(ClientResponse.class);
		System.out.println(rClient);
		return rClient;
	}
	
	public static ClientResponse GET(Map<String, String> headers) throws UniformInterfaceException, ClientHandlerException, Exception {
		ClientResponse rClient = null ;
		
		MultivaluedMap<String, String> queryPar = null ;
		rClient = createWebResourceBuilder(headers, queryPar).get(ClientResponse.class);
		System.out.println(rClient);
		return rClient;
	}
	
	
	public static ClientResponse POST(Map<String, String> headers, String bodyParam) {
		ClientResponse rClient = null ;
		MultivaluedMap<String, String> queryPar = null ;
		System.out.println("Body parameter value : "+bodyParam );
		 try {
				rClient = createWebResourceBuilder(headers,queryPar).post(ClientResponse.class, bodyParam);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		 System.out.println(rClient);
			return rClient;
	}
	

	public static ClientResponse PUT(Map<String, String> headers, String bodyParam) {
		ClientResponse rClient = null ;
		MultivaluedMap<String, String> queryPar = null ;
		System.out.println("Body paramter value : "+bodyParam );
		 try {
				rClient=createWebResourceBuilder(headers,queryPar).put(ClientResponse.class, bodyParam);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		 System.out.println(rClient);
			return rClient;
	}
	
	public static ClientResponse DELETE(Map<String, String> headers, String bodyParam) {
		ClientResponse rClient = null ;
		MultivaluedMap<String, String> queryPar = null ;
		System.out.println("Body paramter value : "+bodyParam );
		 try {
				rClient = createWebResourceBuilder(headers,queryPar).delete(ClientResponse.class, bodyParam);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		 System.out.println(rClient);
			return rClient;
	}

}
