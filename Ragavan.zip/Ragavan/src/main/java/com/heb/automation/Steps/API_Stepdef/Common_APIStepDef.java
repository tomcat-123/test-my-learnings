/*List of Steps in Common_APIStepDef Step definition

		User uses invalid JSON Array Body Parameter
		User uses invalid JSON Object Body Parameter
		User uses empty Array Body Parameter
		User uses empty Json Body Parameter*/

package com.heb.automation.Steps.API_Stepdef;

import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class Common_APIStepDef {

	@QAFTestStep(description = "User with Invalid APIkey for HomeDelivery")
	public static void userWithInvalidAPIkeyForAppInfo() {
		HomeDelivery_ReusableUtils.InvalidApi_Common_headers();
	}

	@QAFTestStep(description = "User with Blank APIkey for HomeDelivery")
	public static void userWithBlankAPIkeyForAppInfo() {
		HomeDelivery_ReusableUtils.BlankApi_Common_headers();
	}

	
	@QAFTestStep(description="User with valid APIkey for HomeDelivery")
	public static void userWithValidAPIkeyForHomeDelivery(){
		HomeDelivery_ReusableUtils.Common_headers();
	}
	
	
	@QAFTestStep(description="User uses invalid JSON Array Body Parameter")
	public void userUsesInvalidJSONArrayBodyParameter(){
	
	CommonUtils.invalidArrayBodyParameter();
	}
	
	@QAFTestStep(description="User uses invalid JSON Object Body Parameter")
	public void userUsesInvalidJSONObjectBodyParameter(){
	
	CommonUtils.invalidJsonBodyParameter();
	}
	
	@QAFTestStep(description="User uses empty Array Body Parameter")
	public void userUsesEmptyArrayBodyParameter(){
	
	CommonUtils.emptyArrayBodyParameter();
	}
	
	@QAFTestStep(description="User uses empty Json Body Parameter")
	public void userUsesEmptyJsonBodyParameter(){
	
	CommonUtils.emptyJsonBodyParameter();
	}
	
	
	
}
