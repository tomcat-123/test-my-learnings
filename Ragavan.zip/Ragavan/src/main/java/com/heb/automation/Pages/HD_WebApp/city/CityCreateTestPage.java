package com.heb.automation.Pages.HD_WebApp.city;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CityCreateTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy (locator="citycreate.lbl.title")
	private QAFWebElement citycreatelbltitle;
	
	@FindBy (locator="citycreate.btn.createcityCrumb")
	private QAFWebElement citycreatebtncreatecityCrumb;
	
	@FindBy (locator="citycreate.txt.cityname")
	private QAFWebElement citycreatetxtcityname;
	
	@FindBy (locator="citycreate.txt.fountainSessionId")
	private QAFWebElement citycreatetxtfountainSessionId;
	
	@FindBy (locator="citycreate.txt.fountainRejectedId")
	private QAFWebElement citycreatetxtfountainRejectedId;
	
	@FindBy (locator="citycreate.txt.hourlyRate")
	private QAFWebElement citycreatetxthourlyRate;
	
	@FindBy (locator="citycreate.txt.fountainFunnelId")
	private QAFWebElement citycreatetxtfountainFunnelId;
	
	@FindBy (locator="citycreate.txt.fountainApprovedId")
	private QAFWebElement citycreatetxtfountainApprovedId;
	
	@FindBy (locator="citycreate.txt.mapLink")
	private QAFWebElement citycreatetxtmapLink;
	 
	@FindBy (locator="citycreate.btn.save")
	private QAFWebElement citycreatebtnsave;
	
	@FindBy (locator="citycreate.btn.cancel")
	private QAFWebElement citycreatebtncancel;
	 
	public QAFWebElement getCitycreatelbltitle() {
		return citycreatelbltitle;
	}

	public QAFWebElement getCitycreatebtncreatecityCrumb() {
		return citycreatebtncreatecityCrumb;
	}
	
	public QAFWebElement getCitycreatetxtcityname() {
		return citycreatetxtcityname;
	}

	public QAFWebElement getCitycreatetxtfountainSessionId() {
		return citycreatetxtfountainSessionId;
	}

	public QAFWebElement getCitycreatetxtfountainRejectedId() {
		return citycreatetxtfountainRejectedId;
	}

	public QAFWebElement getCitycreatetxthourlyRate() {
		return citycreatetxthourlyRate;
	}

	public QAFWebElement getCitycreatetxtfountainFunnelId() {
		return citycreatetxtfountainFunnelId;
	}

	public QAFWebElement getCitycreatetxtfountainApprovedId() {
		return citycreatetxtfountainApprovedId;
	}

	public QAFWebElement getCitycreatetxtmapLink() {
		return citycreatetxtmapLink;
	}

	public QAFWebElement getCitycreatebtncancel() {
		return citycreatebtncancel;
	}

	public QAFWebElement getCityCreateBtnSave() {
		return citycreatebtnsave;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}

}
