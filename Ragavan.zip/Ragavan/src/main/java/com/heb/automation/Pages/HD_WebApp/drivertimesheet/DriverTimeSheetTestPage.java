package com.heb.automation.Pages.HD_WebApp.drivertimesheet;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class DriverTimeSheetTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "timesheet.lbl.title")
	private QAFWebElement timesheetlbltitle;

	@FindBy(locator = "timesheet.btn.drivertimesheetcrump")
	private QAFWebElement timesheetbtndrivertimesheetcrump;

	@FindBy(locator = "timesheet.btn.drivercrump")
	private QAFWebElement timesheetbtndrivercrump;

	@FindBy(locator = "timesheet.lbl.firstname")
	private QAFWebElement timesheetlblfirstname;

	@FindBy(locator = "timesheet.lbl.lastname")
	private QAFWebElement timesheetlbllastname;

	@FindBy(locator = "timesheet.lbl.selectadate")
	private QAFWebElement timesheetlblselectadate;

	@FindBy(locator = "timesheet.txt.firstname")
	private QAFWebElement timesheettxtfirstname;

	@FindBy(locator = "timesheet.txt.lastname")
	private QAFWebElement timesheettxtlastname;

	@FindBy(locator = "timesheet.txt.selectadate")
	private QAFWebElement timesheettxtselectadate;

	@FindBy(locator = "timesheet.btn.calendaricon")
	private QAFWebElement timesheetbtncalendaricon;

	@FindBy(locator = "timesheet.btn.addnew")
	private QAFWebElement timesheetbtnaddnew;

	@FindBy(locator = "timesheet.btn.search")
	private QAFWebElement timesheetbtnsearch;

	@FindBy(locator = "timesheet.txt.selectedWeek")
	private QAFWebElement timesheettxtselectedWeek;
	
	@FindBy(locator = "timesheet.btn.previousmonth")
	private QAFWebElement timesheetbtnpreviousmonth;
	
	@FindBy(locator = "timesheet.btn.nextmonth")
	private QAFWebElement timesheetbtnnextmonth;
	
	@FindBy(locator = "timesheet.lbl.dates")
	private List<QAFWebElement> timesheetlbldates;
	
	@FindBy(locator = "timesheet.txt.shiftstartdate")
	private QAFWebElement timesheettxtshiftstartdate;
	
	@FindBy(locator = "timesheet.txt.shiftenddate")
	private QAFWebElement timesheettxtshiftenddate;

	public QAFWebElement getTxtShiftStartDate() {
		return timesheettxtshiftstartdate;
	}
	
	public QAFWebElement getTxtShiftEndDate() {
		return timesheettxtshiftenddate;
	}
		
	public QAFWebElement getBtnPreviousMonth() {
		return timesheetbtnpreviousmonth;
	}
	
	public QAFWebElement getBtnNextMonth() {
		return timesheetbtnnextmonth;
	}
	
	public List<QAFWebElement> getLblDates() {
		return timesheetlbldates;
	}
	
	public QAFWebElement getLblTitle() {
		return timesheetlbltitle;
	}

	public QAFWebElement getBtnDriverTimeSheetCrump() {
		return timesheetbtndrivertimesheetcrump;
	}

	public QAFWebElement getBtnDriverCrump() {
		return timesheetbtndrivercrump;
	}

	public QAFWebElement getLblFirstName() {
		return timesheetlblfirstname;
	}

	public QAFWebElement getLblLastName() {
		return timesheetlbllastname;
	}

	public QAFWebElement getLblSelectADate() {
		return timesheetlblselectadate;
	}

	public QAFWebElement getTxtFirstName() {
		return timesheettxtfirstname;
	}

	public QAFWebElement getTxtLastName() {
		return timesheettxtlastname;
	}

	public QAFWebElement getTxtSelectADate() {
		return timesheettxtselectadate;
	}

	public QAFWebElement getBtnCalendarIcon() {
		return timesheetbtncalendaricon;
	}

	public QAFWebElement getBtnAddNew() {
		return timesheetbtnaddnew;
	}

	public QAFWebElement getBtnSearch() {
		return timesheetbtnsearch;
	}

	public QAFWebElement getTxtSelectedWeek() {
		return timesheettxtselectedWeek;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}

}
