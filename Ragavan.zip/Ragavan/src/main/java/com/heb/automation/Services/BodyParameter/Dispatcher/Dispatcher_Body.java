package com.heb.automation.Services.BodyParameter.Dispatcher;

public class Dispatcher_Body {
	
	private boolean isActive;

    private String id;

    private String organization;

    private String email;

    private String name;

    private String timeCreated;

    private String timeLastModified;

    public boolean getIsActive ()
    {
        return isActive;
    }

    public void setIsActive (boolean b)
    {
        this.isActive = b;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getOrganization ()
    {
        return organization;
    }

    public void setOrganization (String organization)
    {
        this.organization = organization;
    }

    public String getEmail ()
    {
        return email;
    }

    public void setEmail (String email)
    {
        this.email = email;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getTimeCreated ()
    {
        return timeCreated;
    }

    public void setTimeCreated (String timeCreated)
    {
        this.timeCreated = timeCreated;
    }

    public String getTimeLastModified ()
    {
        return timeLastModified;
    }

    public void setTimeLastModified (String timeLastModified)
    {
        this.timeLastModified = timeLastModified;
    }

}
