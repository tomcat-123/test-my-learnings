package com.heb.automation.Services.HomeDelivery.Order;

public class HomeDelivery_Notes {
	
	private String noteId;

    private String type;

    private String note;

    public String getNoteId ()
    {
        return noteId;
    }

    public void setNoteId (String noteId)
    {
        this.noteId = noteId;
    }

    public String getType ()
    {
        return type;
    }

    public void setType (String type)
    {
        this.type = type;
    }

    public String getNote ()
    {
        return note;
    }

    public void setNote (String note)
    {
        this.note = note;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [noteId = "+noteId+", type = "+type+", note = "+note+"]";
    }

}
