package com.heb.automation.common.components;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.TreeMap;

public class sampledb {

	public static void main(String args[]) throws SQLException {

		String databaseName = "prontosql";
		String username = "pronto_qa_test";
		String password = "l|Kk@TkwM|m89#mY!sZP";
		String jdbcUrl = "jdbc:mysql://35.224.198.126:3306/" + databaseName;
		String query = "select a.zone_group_id, a.name as 'City Name', a.hourly_rate as 'Hourly Rate', a.map_link as 'Map Link' from prontosql.phd_zone_group as a where a.name='Waco'";

		Connection connection = DriverManager.getConnection(jdbcUrl, username, password);

		PreparedStatement st = connection.prepareStatement(query);
		ResultSet rs = st.executeQuery();
		ResultSetMetaData rsmd = rs.getMetaData();

		int rownum = 1;
		while (rs.next()) {
			HashMap<String, String> eachResult = new HashMap<String, String>();
			for (int i = 1; i < rsmd.getColumnCount() + 1; i++) {
				eachResult.put(rsmd.getColumnLabel(i), rs.getString(i));
				System.out.println(rsmd.getColumnLabel(i));
				System.out.println(rs.getString(i));
				System.out.println(eachResult);
			}
			
			 TreeMap<Integer,HashMap<String,String>> selectResult = 
                     new TreeMap<Integer,HashMap<String,String>>();
			selectResult.put(rownum,eachResult);
			rownum=rownum+1;
			
			System.out.println(selectResult);
			System.out.println(selectResult.get(1).get("hourly_rate"));
			break;
		}

	}
}
