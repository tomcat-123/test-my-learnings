package com.heb.automation.Steps.API_Stepdef;

import java.io.IOException;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.ErrorMessages.ErrorMessage;
import com.heb.automation.Services.BodyParameter.Dispatcher.Dispatcher_Body;
import com.heb.automation.Services.BodyParameter.Teams.Teams_Body;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_Success;
import com.heb.automation.Services.HomeDelivery.ServiceUtils;
import com.heb.automation.Services.HomeDelivery.Dispatchers.Dispatchers_Post;
import com.heb.automation.Services.HomeDelivery.Dispatchers.Dispatchers_RootObject;
import com.heb.automation.Services.HomeDelivery.Teams.Teams_Post;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class DispatchersStepdef extends TestDataContainer {

	@QAFTestStep(description = "Build URL for read all the HomeDelivery dispatchers")
	public void buildURLForReadAllTheHomeDeliverDispatchers() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getDispatchers");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for Delete the HomeDelivery dispatchers")
	public void buildURLForDeleteHomeDeliverDispatchers() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getDispatchers")+"/"+getTestString("DispatcherID");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for Delete the HomeDelivery dispatchers with invaldID")
	public void buildURLForDeleteHomeDeliverDispatchersWithInvaldID() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getDispatchers")+"/15465";
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for creating HomeDelivery Dispatcher")
	public void userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryDispatcher() throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getDispaterName());
		pr.setEmail(geteMail());
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter with all mandatory and optional fields for creating HomeDelivery Dispatcher")
	public void userUsesAnArrayOfBodyParameterWithAllMandatoryAndOptionalFieldsForCreatingHomeDeliveryDispatcher() throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getDispaterName());
		pr.setEmail(geteMail());
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Missing eMail Body Parameter for creating HomeDelivery Dispatcher")
	public void userUsesAnArrayOfMissingeMailBodyParameterForCreatingHomeDeliveryDispatcher()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getName());
		pr.setEmail(null);
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Missing Body Parameter for creating HomeDelivery Dispatcher")
	public void userUsesAnArrayOfMissingBodyParameterForCreatingHomeDeliveryDispatcher()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(null);
		pr.setEmail(null);
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of existing eMail Body Parameter for creating HomeDelivery Dispatcher")
	public void userUsesAnArrayOfExistingeMailBodyParameterForCreatingHomeDeliveryDispatcher()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getDispaterName());
		pr.setEmail(getTestString("DispatchereMail"));
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Dispatcher body parameter contains all valid editable fields")
	public void userUPDATEHomeDeliveryDispatcherBodyParameterContainsAllValidEditableFields()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getDispaterName());
		pr.setEmail(getTestString("DispatchereMail"));
		pr.setId(getTestString("DispatcherID"));
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User UPDATE HomeDelivery Dispatcher body parameter contains only optional fields")
	public void userUPDATEHomeDeliveryDispatcherBodyParameterContainsOnlyOptionalFields()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getDispaterName());
		pr.setEmail("");
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User UPDATE HomeDelivery Dispatcher Missing Name body parameter")
	public void userUPDATEHomeDeliveryDispatcherMissingNameBodyParameter()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName("");
		pr.setEmail(getTestString("DispatchereMail"));
		pr.setId(getTestString("DispatcherID"));
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User UPDATE HomeDelivery Dispatcher body parameter contains duplicate email id")
	public void userUPDATEHomeDeliveryDispatcherBodyParameterDuplicateEmailId()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getTestString("DispatchereName"));
		pr.setEmail(getTestString("DispatchereMail"));
		pr.setId(getTestString("DispatcherID"));
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User GET response call for HomeDelivery dispatchers")
	public static void userGETResponseCallForHomeDeliverDispatchers() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Dispatchers");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");
				
				Dispatchers_RootObject gson1 = new Gson().fromJson(RESPONSE,
						Dispatchers_RootObject.class);
				System.out.println("RESPONSE is "+ RESPONSE);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DispatcherID = gson1.getData().get(0).getId();
				putTestObject("DispatcherID", DispatcherID);
				Reporter.log("Read Success-HomeDelivery Dispatchers ID: " + DispatcherID);
				System.out.println("Read Success-HomeDelivery Dispatchers ID: " + DispatcherID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "User POST the Create HomeDelivery Dispatcher call")
	public void userPOSTTheCreateHomeDeliveryDispatcherCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Dispatcher is created ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Dispatchers_Post gson1 = new Gson().fromJson(RESPONSE, Dispatchers_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DispatcherID = gson1.getData().getId();
				String DispatchereMail = gson1.getData().getEmail();
				putTestObject("DispatcherID", DispatcherID);
				putTestObject("DispatchereMail", DispatchereMail);				
				Reporter.log("Created Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				Reporter.log("Created Success-HomeDelivery Dispatcher eMail: " + DispatchereMail);
				System.out.println("Created Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				System.out.println("Created Success-HomeDelivery Dispatcher eMail: " + DispatchereMail);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Dispatcher creation failed  " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("Dispatcher creation failed  " + 503);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			System.out.println(e);
		}
	}
	
	@QAFTestStep(description = "User POST the Create HomeDelivery Dispatcher calls")
	public void userPOSTTheCreateHomeDeliveryDispatcherCalls() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Dispatcher is created ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Dispatchers_Post gson1 = new Gson().fromJson(RESPONSE, Dispatchers_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DispatcherID = gson1.getData().getId();
				String DispatchereName = gson1.getData().getName();
				putTestObject("DispatcherID", DispatcherID);
				putTestObject("DispatchereName", DispatchereName);
				Reporter.log("Created Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				Reporter.log("Created Success-HomeDelivery Dispatcher Name: " + DispatchereName);
				System.out.println("Created Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				System.out.println("Created Success-HomeDelivery Dispatcher Name: " + DispatchereName);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Team created with failed  " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			System.out.println(e);
		}
	}
	
	@QAFTestStep(description="User uses batch POST to Create Multiple HomeDelivery Dispatcher calls {0}")
	public void userUsesBatchPOSTToCreateMultipleHomeDeliveryDispatcherCalls(int batchCount){
		int batchPostCount = batchCount;
		//String[] dispatcherID = new String[batchPostCount];
		List<String> dispatcherID = new ArrayList<>();
		
		for (int i=1; i<=batchPostCount; i++) {
			
			try {
				
				userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryDispatcher();
				userPOSTTheCreateHomeDeliveryDispatcherCall();
				
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			
			//dispatcherID[i] = getTestString("DispatcherID");
			dispatcherID.add(getTestString("DispatcherID"));
			System.out.println("Dispatcher is :" + dispatcherID);
			
		}
		
		putTestObject("DispatcherIDList", dispatcherID);
		System.out.println("Final Dispatcher is :" + getTestObject("DispatcherIDList"));
	}
	
	@QAFTestStep(description="Get the List of Dispatchers")
	public void getTheListOfDispatchers(){
	
	HomeDelivery_ReusableUtils.GetAllDispatcherID();
	
	}

	public static String getName() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "Automation_" + name.substring(3, name.length());
	}

	public static String getNameMoreThan101Characters() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "Automation dispatcher name more than 101 characters in length should return an exception " + name.substring(3, name.length());
	}
	
	public static String geteMail() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "automation_" + name.substring(3, name.length()) + "@heb.com";
	}

	public static String geteMailInvalidFormatMoreThan50Characters() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "automation_morethan50_characters_" + name.substring(3, name.length()) + "@heb.com";
	}	
	
	public static String getDispaterName() {

		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 10;
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();

		return "automation" + generatedString;

	}

	@QAFTestStep(description = "User PUT the Update HomeDelivery Dispatcher call")
	public void userPUTTheUpdateHomeDeliveryDispatcherCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			rClient = ServiceUtils.PUT(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Dispatcher is updated ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				Dispatchers_Post gson1 = new Gson().fromJson(RESPONSE, Dispatchers_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DispatcherID = gson1.getData().getId();
				String DispatchereMail = gson1.getData().getEmail();
				String DispatchereName = gson1.getData().getName();
				putTestObject("DispatcherID", DispatcherID);
				putTestObject("DispatchereMail", DispatchereMail);
				putTestObject("Updated_DispatchereName", DispatchereName);
				Reporter.log("Update Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				Reporter.log("Update Success-HomeDelivery Dispatcher Name: " + DispatchereName);
				Reporter.log("Update Success-HomeDelivery Dispatcher eMail: " + DispatchereMail);
				System.out.println("Update Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				System.out.println("Update Success-HomeDelivery Dispatcher Name: " + DispatchereName);
				System.out.println("Update Success-HomeDelivery Dispatcher eMail: " + DispatchereMail);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery dispatcher update failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery dispatcher update failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery dispatcher update failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("HomeDelivery dispatcher update failed  ");
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	@QAFTestStep(description = "User DELETE the HomeDelivery Dispatcher DELETE call")
	public void userDELETETheHomeDeliveryDispatcherDELETECall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.DELETE(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("HomeDelivery Dispatcher is deleted ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				HomeDelivery_Success gson1 = new Gson().fromJson(RESPONSE,
						HomeDelivery_Success.class);
				putTestObject("rGSON", gson1);
				System.out.println(" : " + gson1.getApiStatus());
				Reporter.log("Deleted HomeDelivery Dispatcher : " + gson1.getApiStatus());
			}
			if (rClient.getStatus() == 207) {
				Reporter.log("HomeDelivery Dispatcher Deleted with Partial success  ");
				putTestObject("rClient", rClient);
				ErrorMessage gson1 = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
				putTestObject("rGSON", gson1);
			}

			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Dispatcher Delete failed with 400");
				putTestObject("rClient", rClient);
			}

			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery Dispatcher Delete failed with 404");
				putTestObject("rClient", rClient);
			}
			
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery Dispatcher Delete failed with 401");
				putTestObject("rClient", rClient);
			}

			if (rClient.getStatus() == 503) {
				Reporter.log("HomeDelivery Dispatcher Delete failed with 503");
				putTestObject("rClient", rClient);
			}
			
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Dispatcher Deleted failed with 400");
				putTestObject("rClient", rClient);
			}

		}
	}

	@QAFTestStep(description = "User uses an array of More than 50character invalid format eMail Body Parameter for creating HomeDelivery Dispatcher")
	public void userUsesAnArrayOfMoreThan50CharacterInvalidFormateMailBodyParameterForCreatingHomeDeliveryDispatcher()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getName());
		pr.setEmail(geteMailInvalidFormatMoreThan50Characters());
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("Full body parameter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);	
	}

	@QAFTestStep(description = "User uses Body Parameter with More than 101character name for creating HomeDelivery Dispatcher")
	public void userUsesBodyParameterWithMoreThan101CharacterNameForCreatingHomeDeliveryDispatcher()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getNameMoreThan101Characters());
		pr.setEmail(geteMail());
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("Full body parameter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);	
	}

	
	@QAFTestStep(description = "validate the response schema with GET Dispatcher")
	public static void validateTheResponseSchemaWithGETDispatcher() {

		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			RESPONSE = ServiceUtils.GET(headers);
			Reporter.log("Status :" + RESPONSE.getStatus());
			Reporter.log("rClient list is : " + RESPONSE.getStatusInfo());
			putTestObject("rClient", RESPONSE);

			if (RESPONSE.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Dispatchers");
				putTestObject("rClient", RESPONSE);
				String StringResponse = RESPONSE.getEntity(String.class);
				putTestObject(StringResponse, "STRINGRESPONSE");
				
				
				Dispatchers_RootObject gson1 = new Gson().fromJson(StringResponse,
						Dispatchers_RootObject.class);
				System.out.println("RESPONSE is "+ RESPONSE);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DispatcherID = gson1.getData().get(0).getId();
				putTestObject("DispatcherID", DispatcherID);
				Reporter.log("Read Success-HomeDelivery Dispatchers ID: " + DispatcherID);
				System.out.println("Read Success-HomeDelivery Dispatchers ID: " + DispatcherID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(StringResponse, "GET_DISPATCHER");
				HomeDelivery_ReusableUtils.validateJSONschema("Dispatcher_GET", "GET_DISPATCHER");
			}  if (RESPONSE.getStatus() != 200) {
				Reporter.log("Dispatcher created with failed", MessageTypes.Fail);
				System.out.println("Dispatcher created with failed");
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = RESPONSE.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(RESPONSE.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}
	
	@QAFTestStep(description = "validate the response schema with POST Dispatcher")
	public void validateTheResponseSchemaWithPOSTDispatcher() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			RESPONSE = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + RESPONSE.getStatus());
			if (RESPONSE.getStatus() == 200) {

				Reporter.log("Dispatcher is created ");
				putTestObject("rClient", RESPONSE);
				
				String StringResponse = RESPONSE.getEntity(String.class);
				putTestObject(StringResponse, "STRINGRESPONSE");

				Dispatchers_Post gson1 = new Gson().fromJson(StringResponse, Dispatchers_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DispatcherID = gson1.getData().getId();		
				Reporter.log("Created Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				System.out.println("Created Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(StringResponse, "POST_DISPATCHER");
				HomeDelivery_ReusableUtils.validateJSONschema("Dispatcher_POST", "POST_DISPATCHER");
			}
			if (RESPONSE.getStatus() != 200) {
				Reporter.log("Dispatcher created with failed", MessageTypes.Fail);
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e,MessageTypes.Fail);
			System.out.println(e);
		}
	}
	
	@QAFTestStep(description = "validate the response schema with PUT Dispatche")
	public void validateTheResponseSchemaWithPUTDispatche() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			RESPONSE = ServiceUtils.PUT(headers, bodyParam);
			Reporter.log("Status :" + RESPONSE.getStatus());
			if (RESPONSE.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Dispatcher is updated ");
				putTestObject("rClient", RESPONSE);
				
				String StringResponse = RESPONSE.getEntity(String.class);
				putTestObject(StringResponse, "RESPONSE");

				Dispatchers_Post gson1 = new Gson().fromJson(StringResponse, Dispatchers_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String DispatcherID = gson1.getData().getId();
				putTestObject("DispatcherID", DispatcherID);
				Reporter.log("Update Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				System.out.println("Update Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(StringResponse, "PUT_DISPATCHER");
				HomeDelivery_ReusableUtils.validateJSONschema("Dispatcher_PUT", "PUT_DISPATCHER");
				
			}
			
			if (RESPONSE.getStatus() != 200) {
				Reporter.log("Dispatcher created with failed", MessageTypes.Fail);
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}
			
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e, MessageTypes.Fail);
			System.out.println(e);
		}
	}
		
}
