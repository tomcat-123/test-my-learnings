package com.heb.automation.Services.HomeDelivery.Drivers;

import java.util.List;

public class DriversByProfileID_Data
{
	private String lastModifiedTimestamp;

    private int id;

    private String firstName;

    private String lastName;

    private String email;

    private String role;

    private String phone;

    private String externalOnfleetId;

    private List<DriversByProfileID_DriverZones> driverZones;

    private List<DriversByProfileID_Timesheet> timesheets;

    private String fountainStage;

    private boolean alcoholEligible;

    private int averageCustomerRating;

    private int completedOrderCount;

    private int onTimeOrderCount;

    private int rejectedOrderCount;

    private String vehicleType;

    private String lastLoginTimestamp;

    private boolean allowSms;

    private boolean allowEmail;

    private String profilePicture;

    private boolean driversLicenseActive;

    private String licenseExpirationDate;

    private String hearingStatus;

    private String rapidPayAccountNumber;

    private String status;

    private String fullName;

    public void setLastModifiedTimestamp(String lastModifiedTimestamp){
        this.lastModifiedTimestamp = lastModifiedTimestamp;
    }
    public String getLastModifiedTimestamp(){
        return this.lastModifiedTimestamp;
    }
    public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return this.id;
    }
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
    public String getFirstName(){
        return this.firstName;
    }
    public void setLastName(String lastName){
        this.lastName = lastName;
    }
    public String getLastName(){
        return this.lastName;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public String getEmail(){
        return this.email;
    }
    public void setRole(String role){
        this.role = role;
    }
    public String getRole(){
        return this.role;
    }
    public void setPhone(String phone){
        this.phone = phone;
    }
    public String getPhone(){
        return this.phone;
    }
    public void setExternalOnfleetId(String externalOnfleetId){
        this.externalOnfleetId = externalOnfleetId;
    }
    public String getExternalOnfleetId(){
        return this.externalOnfleetId;
    }
    public void setDriverZones(List<DriversByProfileID_DriverZones> driverZones){
        this.driverZones = driverZones;
    }
    public List<DriversByProfileID_DriverZones> getDriverZones(){
        return this.driverZones;
    }
    public void setTimesheets(List<DriversByProfileID_Timesheet> timesheets){
        this.timesheets = timesheets;
    }
    public List<DriversByProfileID_Timesheet> getTimesheets(){
        return this.timesheets;
    }
    public void setFountainStage(String fountainStage){
        this.fountainStage = fountainStage;
    }
    public String getFountainStage(){
        return this.fountainStage;
    }
    public void setAlcoholEligible(boolean alcoholEligible){
        this.alcoholEligible = alcoholEligible;
    }
    public boolean getAlcoholEligible(){
        return this.alcoholEligible;
    }
    public void setAverageCustomerRating(int averageCustomerRating){
        this.averageCustomerRating = averageCustomerRating;
    }
    public int getAverageCustomerRating(){
        return this.averageCustomerRating;
    }
    public void setCompletedOrderCount(int completedOrderCount){
        this.completedOrderCount = completedOrderCount;
    }
    public int getCompletedOrderCount(){
        return this.completedOrderCount;
    }
    public void setOnTimeOrderCount(int onTimeOrderCount){
        this.onTimeOrderCount = onTimeOrderCount;
    }
    public int getOnTimeOrderCount(){
        return this.onTimeOrderCount;
    }
    public void setRejectedOrderCount(int rejectedOrderCount){
        this.rejectedOrderCount = rejectedOrderCount;
    }
    public int getRejectedOrderCount(){
        return this.rejectedOrderCount;
    }
    public void setVehicleType(String vehicleType){
        this.vehicleType = vehicleType;
    }
    public String getVehicleType(){
        return this.vehicleType;
    }
    public void setLastLoginTimestamp(String lastLoginTimestamp){
        this.lastLoginTimestamp = lastLoginTimestamp;
    }
    public String getLastLoginTimestamp(){
        return this.lastLoginTimestamp;
    }
    public void setAllowSms(boolean allowSms){
        this.allowSms = allowSms;
    }
    public boolean getAllowSms(){
        return this.allowSms;
    }
    public void setAllowEmail(boolean allowEmail){
        this.allowEmail = allowEmail;
    }
    public boolean getAllowEmail(){
        return this.allowEmail;
    }
    public void setProfilePicture(String profilePicture){
        this.profilePicture = profilePicture;
    }
    public String getProfilePicture(){
        return this.profilePicture;
    }
    public void setDriversLicenseActive(boolean driversLicenseActive){
        this.driversLicenseActive = driversLicenseActive;
    }
    public boolean getDriversLicenseActive(){
        return this.driversLicenseActive;
    }
    public void setLicenseExpirationDate(String licenseExpirationDate){
        this.licenseExpirationDate = licenseExpirationDate;
    }
    public String getLicenseExpirationDate(){
        return this.licenseExpirationDate;
    }
    public void setHearingStatus(String hearingStatus){
        this.hearingStatus = hearingStatus;
    }
    public String getHearingStatus(){
        return this.hearingStatus;
    }
    public void setRapidPayAccountNumber(String rapidPayAccountNumber){
        this.rapidPayAccountNumber = rapidPayAccountNumber;
    }
    public String getRapidPayAccountNumber(){
        return this.rapidPayAccountNumber;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
    public void setFullName(String fullName){
        this.fullName = fullName;
    }
    public String getFullName(){
        return this.fullName;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [licenseExpirationDate = "+licenseExpirationDate+", lastModifiedTimestamp = "+lastModifiedTimestamp+", phone = "+phone+", timesheets = "+timesheets+", allowSms = "+allowSms+", id = "+id+", hearingStatus = "+hearingStatus+", lastLoginTimestamp = "+lastLoginTimestamp+", role = "+role+", driverZones = "+driverZones+", firstName = "+firstName+", lastName = "+lastName+", rapidPayAccountNumber = "+rapidPayAccountNumber+", completedOrderCount = "+completedOrderCount+", rejectedOrderCount = "+rejectedOrderCount+", status = "+status+", averageCustomerRating = "+averageCustomerRating+", profilePicture = "+profilePicture+", driversLicenseActive = "+driversLicenseActive+", externalOnfleetId = "+externalOnfleetId+", email = "+email+", allowEmail = "+allowEmail+", alcoholEligible = "+alcoholEligible+", vehicleType = "+vehicleType+", fountainStage = "+fountainStage+", fullName = "+fullName+", onTimeOrderCount = "+onTimeOrderCount+"]";
    }
}