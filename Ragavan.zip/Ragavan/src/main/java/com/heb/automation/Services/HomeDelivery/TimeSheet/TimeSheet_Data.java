package com.heb.automation.Services.HomeDelivery.TimeSheet;

public class TimeSheet_Data {
	
	private String startTime;

    private String id;

    private String lastModifiedTimestamp;

    private String archived;

    private String workWeekEnd;

    private String driverId;

    private String endTime;

    private String date;

    private String driverName;

    private String workWeekStart;

    public String getStartTime ()
    {
        return startTime;
    }

    public void setStartTime (String startTime)
    {
        this.startTime = startTime;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getLastModifiedTimestamp ()
    {
        return lastModifiedTimestamp;
    }

    public void setLastModifiedTimestamp (String lastModifiedTimestamp)
    {
        this.lastModifiedTimestamp = lastModifiedTimestamp;
    }

    public String getArchived ()
    {
        return archived;
    }

    public void setArchived (String archived)
    {
        this.archived = archived;
    }

    public String getWorkWeekEnd ()
    {
        return workWeekEnd;
    }

    public void setWorkWeekEnd (String workWeekEnd)
    {
        this.workWeekEnd = workWeekEnd;
    }

    public String getDriverId ()
    {
        return driverId;
    }

    public void setDriverId (String driverId)
    {
        this.driverId = driverId;
    }

    public String getEndTime ()
    {
        return endTime;
    }

    public void setEndTime (String endTime)
    {
        this.endTime = endTime;
    }

    public String getDate ()
    {
        return date;
    }

    public void setDate (String date)
    {
        this.date = date;
    }

    public String getDriverName ()
    {
        return driverName;
    }

    public void setDriverName (String driverName)
    {
        this.driverName = driverName;
    }

    public String getWorkWeekStart ()
    {
        return workWeekStart;
    }

    public void setWorkWeekStart (String workWeekStart)
    {
        this.workWeekStart = workWeekStart;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [startTime = "+startTime+", id = "+id+", lastModifiedTimestamp = "+lastModifiedTimestamp+", archived = "+archived+", workWeekEnd = "+workWeekEnd+", driverId = "+driverId+", endTime = "+endTime+", date = "+date+", driverName = "+driverName+", workWeekStart = "+workWeekStart+"]";
    }

}
