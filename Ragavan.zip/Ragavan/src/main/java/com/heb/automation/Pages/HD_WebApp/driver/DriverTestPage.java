package com.heb.automation.Pages.HD_WebApp.driver;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class DriverTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}

	@FindBy(locator = "driver.txt.firstname")
	private QAFWebElement driverTxtFirstname;

	@FindBy(locator = "driver.txt.lastname")
	private QAFWebElement driverTxtLastname;

	@FindBy(locator = "driver.btn.driverCrumb")
	private QAFWebElement driverBtnDriverCrumb;

	@FindBy(locator = "driver.lbl.pagetitle")
	private QAFWebElement driverLblPagetitle;

	@FindBy(locator = "driver.dropdown.zone")
	private QAFWebElement driverDropdownZone;

	@FindBy(locator = "driver.dropdown.zoneoptions")
	private List<QAFWebElement> driverDropdownZoneoptions;

	@FindBy(locator = "driver.txt.zone")
	private QAFWebElement driverTxtZone;

	@FindBy(locator = "driver.txt.zoneempty")
	private QAFWebElement driverTxtZoneempty;

	@FindBy(locator = "driver.lbl.pastdate")
	private List<QAFWebElement> driverLblPastDate;

	@FindBy(locator = "driver.lbl.futuredate")
	private List<QAFWebElement> driverlblfuturedate;

	@FindBy(locator = "driver.txt.currentdate")
	private QAFWebElement driverTxtCurrentDate;

	@FindBy(locator = "driver.btn.opencalendar")
	private QAFWebElement driverBtnOpencalendar;

	@FindBy(locator = "driver.btn.previousmonth")
	private QAFWebElement driverbtnpreviousmonth;

	@FindBy(locator = "driver.lnk.paginationnum")
	private QAFWebElement driverlnkpaginationnum;

	@FindBy(locator = "driver.lnk.backwardlastpage")
	private QAFWebElement driverlnkbackward;

	@FindBy(locator = "driver.lnk.forwardlast")
	private QAFWebElement driverlnkforward;

	@FindBy(locator = "driver.lnk.backwardnext")
	private QAFWebElement driverlnkbackwardnext;

	@FindBy(locator = "driver.lnk.forwardnext")
	private QAFWebElement driverlnkforwardnext;
	
	@FindBy(locator = "driver.lbl.firstnametypehed")
	private List<QAFWebElement> driverlblfirstnametypehed;
	
	@FindBy(locator = "driver.lbl.firstname")
	private QAFWebElement driverlblfirstname;
	
	@FindBy(locator = "driver.lbl.lastname")
	private QAFWebElement driverlbllastname;
	
	@FindBy(locator = "driver.lbl.date")
	private QAFWebElement driverlbldate;
	
	@FindBy(locator = "driver.lbl.zone")
	private QAFWebElement driverlblzone;
	
	public QAFWebElement getLblFirstName() {
		return driverlblfirstname;
	}
	
	public QAFWebElement getLblLastname() {
		return driverlbllastname;
	}
	
	public QAFWebElement getLblDate() {
		return driverlbldate;
	}
	
	public QAFWebElement getLblZone() {
		return driverlblzone;
	}
	
	public QAFWebElement getZoneValue(String linkno) {
		String loc = String.format(pageProps.getString("driver.dropdown.zonevalue"), linkno);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getNewZoneValue(String linkno) {
		String loc = String.format(pageProps.getString("driver.dropdown.zonenewvalue"), linkno);
		return new QAFExtendedWebElement(loc);
	}
	
	public List<QAFWebElement> getFirstNameTypeHead() {
		return driverlblfirstnametypehed;
	}
	
	public QAFWebElement getTxtFirstname() {
		return driverTxtFirstname;
	}

	public QAFWebElement getTxtLastname() {
		return driverTxtLastname;
	}

	public QAFWebElement getBtnDriverCrumb() {
		return driverBtnDriverCrumb;
	}

	public QAFWebElement getLblPagetitle() {
		return driverLblPagetitle;
	}

	public QAFWebElement getDropdownZone() {
		return driverDropdownZone;
	}

	public List<QAFWebElement> getDropdownZoneoptions() {
		return driverDropdownZoneoptions;
	}

	public QAFWebElement getTxtZone() {
		return driverTxtZone;
	}

	public QAFWebElement getTxtZoneempty() {
		return driverTxtZoneempty;
	}

	public List<QAFWebElement> getLblPastDate() {
		return driverLblPastDate;
	}

	public List<QAFWebElement> getLblFutureDate() {
		return driverlblfuturedate;
	}

	public QAFWebElement getTxtCurrentDate() {
		return driverTxtCurrentDate;
	}

	public QAFWebElement getBtnOpencalendar() {
		return driverBtnOpencalendar;
	}

	public QAFWebElement getBtnPreviousMonth() {
		return driverbtnpreviousmonth;
	}

	public QAFWebElement getLnkPaginationNum() {
		return driverlnkpaginationnum;
	}

	public QAFWebElement getLnkBackward() {
		return driverlnkbackward;
	}

	public QAFWebElement getLnkForward() {
		return driverlnkforward;
	}

	public QAFWebElement getLnkBackwardNext() {
		return driverlnkbackwardnext;
	}

	public QAFWebElement getLnkForwardNext() {
		return driverlnkforwardnext;
	}

}
