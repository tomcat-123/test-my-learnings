package com.heb.automation.Services.HomeDelivery.Cities;

import com.heb.automation.Services.HomeDelivery.Zones.City_Data;

public class Cities_Put {
	
	private String apiStatus;

    private City_Data data = new City_Data();

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

    public City_Data getData ()
    {
        return data;
    }

    public void setData (City_Data data)
    {
        this.data = data;
    }

}
