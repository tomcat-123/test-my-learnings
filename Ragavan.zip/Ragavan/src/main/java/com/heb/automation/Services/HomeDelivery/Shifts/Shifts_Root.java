package com.heb.automation.Services.HomeDelivery.Shifts;

public class Shifts_Root {
	
	private String apiStatus;

    private Shifts_Data data;

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

    public Shifts_Data getData ()
    {
        return data;
    }

    public void setData (Shifts_Data data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [apiStatus = "+apiStatus+", data = "+data+"]";
    }

}
