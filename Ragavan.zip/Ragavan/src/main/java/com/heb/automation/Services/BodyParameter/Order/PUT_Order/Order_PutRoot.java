package com.heb.automation.Services.BodyParameter.Order.PUT_Order;

import java.util.ArrayList;

public class Order_PutRoot {
	
	private String alcoholOrder;

    private String status;

    private String deliveryEndDateTime;

    private String signatureRequired;

    private String deliveryStartDateTime;

    private ArrayList<Order_PUT_Notes> notes = new ArrayList<Order_PUT_Notes>();

    public String getAlcoholOrder ()
    {
        return alcoholOrder;
    }

    public void setAlcoholOrder (String alcoholOrder)
    {
        this.alcoholOrder = alcoholOrder;
    }

    public String getStatus ()
    {
        return status;
    }

    public void setStatus (String status)
    {
        this.status = status;
    }

    public String getDeliveryEndDateTime ()
    {
        return deliveryEndDateTime;
    }

    public void setDeliveryEndDateTime (String deliveryEndDateTime)
    {
        this.deliveryEndDateTime = deliveryEndDateTime;
    }

    public String getSignatureRequired ()
    {
        return signatureRequired;
    }

    public void setSignatureRequired (String signatureRequired)
    {
        this.signatureRequired = signatureRequired;
    }

    public String getDeliveryStartDateTime ()
    {
        return deliveryStartDateTime;
    }

    public void setDeliveryStartDateTime (String deliveryStartDateTime)
    {
        this.deliveryStartDateTime = deliveryStartDateTime;
    }

    public ArrayList<Order_PUT_Notes> getNotes ()
    {
        return notes;
    }

    public void setNotes (ArrayList<Order_PUT_Notes> notes)
    {
        this.notes = notes;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [alcoholOrder = "+alcoholOrder+", status = "+status+", deliveryEndDateTime = "+deliveryEndDateTime+", signatureRequired = "+signatureRequired+", deliveryStartDateTime = "+deliveryStartDateTime+", notes = "+notes+"]";
    }
}
