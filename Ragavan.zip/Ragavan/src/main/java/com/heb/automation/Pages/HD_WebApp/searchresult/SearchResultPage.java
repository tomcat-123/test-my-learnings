package com.heb.automation.Pages.HD_WebApp.searchresult;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SearchResultPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "table.lbl.tablebody")
	private QAFWebElement TableBodyList;
	
	@FindBy(locator = "table.lbl.ColumnName")
	List<QAFWebElement> TableColumnName;

	@FindBy(locator = "table.lbl.ColumnNameList")
	private QAFWebElement TableColumnNameList;
	
	@FindBy(locator = "table.lbl.RowList")
	List<QAFWebElement> TableRowList;
	
	@FindBy(locator = "table.lbl.pagedropdownList")
	private QAFWebElement PageDropdownList;
	
	@FindBy(locator = "table.lbl.dynamicpagedropdown")
	private QAFWebElement dynamicPageDropdown;
	
	@Override
	protected void openPage(PageLocator locator, Object... args) {

	}

	public QAFWebElement getTableBodyList() {
		return TableBodyList;
	}

	public List<QAFWebElement> getTableColumnName() {
		return TableColumnName;
	}

	public QAFWebElement getTableColumnNameList() {
		return TableColumnNameList;
	}

	public List<QAFWebElement> getTableRowList() {
		return TableRowList;
	}
	
	public QAFWebElement getPageDropdownlist() {
		return PageDropdownList;
	}
	
	public QAFWebElement getdynamicPageDropdown(int count) {

		String loc = String.format(pageProps.getString("table.lbl.dynamicpagedropdown"), count);
		return new QAFExtendedWebElement(loc);
	}
	
	
	
}
