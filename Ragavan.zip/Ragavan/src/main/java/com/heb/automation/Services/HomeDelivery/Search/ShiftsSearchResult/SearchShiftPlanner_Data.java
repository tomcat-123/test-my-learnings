package com.heb.automation.Services.HomeDelivery.Search.ShiftsSearchResult;

import java.util.ArrayList;

public class SearchShiftPlanner_Data {

	private ArrayList<SearchShiftPlanner_Days> days;

    private String weekOf;

    private String publishDate;

    private String zone;

    public ArrayList<SearchShiftPlanner_Days> getDays ()
    {
        return days;
    }

    public void setDays (ArrayList<SearchShiftPlanner_Days> days)
    {
        this.days = days;
    }

    public String getWeekOf ()
    {
        return weekOf;
    }

    public void setWeekOf (String weekOf)
    {
        this.weekOf = weekOf;
    }

    public String getPublishDate ()
    {
        return publishDate;
    }

    public void setPublishDate (String publishDate)
    {
        this.publishDate = publishDate;
    }

    public String getZone ()
    {
        return zone;
    }

    public void setZone (String zone)
    {
        this.zone = zone;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [days = "+days+", weekOf = "+weekOf+", publishDate = "+publishDate+", zone = "+zone+"]";
    }
}
