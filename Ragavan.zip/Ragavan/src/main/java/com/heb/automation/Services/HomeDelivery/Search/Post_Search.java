package com.heb.automation.Services.HomeDelivery.Search;

import java.util.ArrayList;

public class Post_Search {
	
	private Object pageNumber;

    private ArrayList<Post_SearchCriteria> searchCriteria = new ArrayList<Post_SearchCriteria>();

    private String sortDirection;

    private String sortBy;

    private Object pageSize;

    public Object getPageNumber ()
    {
        return pageNumber;
    }

    public void setPageNumber (Object pageNumber)
    {
        this.pageNumber = pageNumber;
    }

    public ArrayList<Post_SearchCriteria> getSearchCriteria ()
    {
        return searchCriteria;
    }

    public void setSearchCriteria (ArrayList<Post_SearchCriteria> searchCriteria)
    {
        this.searchCriteria = searchCriteria;
    }

    public String getSortDirection ()
    {
        return sortDirection;
    }

    public void setsortDirection (String sortDirection)
    {
        this.sortDirection = sortDirection;
    }

    public String getSortBy ()
    {
        return sortBy;
    }

    public void setSortBy (String sortBy)
    {
        this.sortBy = sortBy;
    }

    public Object getPageSize ()
    {
        return pageSize;
    }

    public void setPageSize (Object pageSize)
    {
        this.pageSize = pageSize;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [pageNumber = "+pageNumber+", pageSize = "+pageSize+", searchCriteria = "+searchCriteria+", sortDirection = "+sortDirection+", sortBy = "+sortBy+"]";
    }

}
