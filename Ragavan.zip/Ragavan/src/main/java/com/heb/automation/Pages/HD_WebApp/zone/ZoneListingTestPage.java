package com.heb.automation.Pages.HD_WebApp.zone;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ZoneListingTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}

	@FindBy(locator = "zonelist.btn.zoneCrumb")
	private QAFWebElement zonelistbtnzoneCrumb;

	@FindBy(locator = "zonelist.btn.addnew")
	private QAFWebElement zonelistbtnaddnew;

	@FindBy(locator = "zonelist.txt.zonename")
	private QAFWebElement zonelisttxtzonename;

	@FindBy(locator = "zonelist.dropdown.city")
	private QAFWebElement zonelistdropdowncity;

	@FindBy(locator = "zonelist.lbl.title")
	private QAFWebElement zonelistLblTitle;

	@FindBy(locator = "zonelist.lbl.totalrecods")
	private QAFWebElement zonelistlbltotalrecods;

	@FindBy(locator = "zonelist.lnk.zoneresult")
	private QAFWebElement zonelistlnkzoneresult;

	@FindBy(locator = "zonelist.dropdown.pagination")
	private QAFWebElement zonelistdropdownpagination;

	@FindBy(locator = "zonelist.lbl.pagevalue")
	private List<QAFWebElement> zonelistlblpagevalue;

	@FindBy(locator = "zonelist.lnk.paginationnum")
	private List<QAFWebElement> zonelistlnkpaginationnum;

	@FindBy(locator = "zonelist.lbl.city")
	private QAFWebElement zonelistlblcity;

	@FindBy(locator = "zonelist.lbl.zone")
	private QAFWebElement zonelistlblzone;
	
	@FindBy(locator = "zonelist.txt.city")
	private QAFWebElement zonelisttxtcity;
	
	@FindBy(locator = "zonelist.lbl.zonenametypehed")
	private List<QAFWebElement> zonelistlblzonenametypehed;
	
	@FindBy(locator = "zonelist.btn.search")
	private QAFWebElement zonelistbtnsearch;
	
	@FindBy(locator = "zonelist.btn.reset")
	private QAFWebElement zonelistbtnreset;
	
	public QAFWebElement getBtnSearch() {
		return zonelistbtnsearch;
	}

	public QAFWebElement getBtnReset() {
		return zonelistbtnreset;
	}

	public void setZonelistbtnsearch(QAFWebElement zonelistbtnsearch) {
		this.zonelistbtnsearch = zonelistbtnsearch;
	}

	public List<QAFWebElement> getLblZoneNameTypeHed() {
		return zonelistlblzonenametypehed;
	}
	
	public QAFWebElement getTxtCity() {
		return zonelisttxtcity;
	}
	
	public QAFWebElement getLblCity() {
		return zonelistlblcity;
	}

	public QAFWebElement getLblZone() {
		return zonelistlblzone;
	}

	public List<QAFWebElement> getLnkPaginationnum() {
		return zonelistlnkpaginationnum;
	}

	public QAFWebElement getBtnZoneCrumb() {
		return zonelistbtnzoneCrumb;
	}

	public QAFWebElement getBtnAddNew() {
		return zonelistbtnaddnew;
	}

	public QAFWebElement getTxtZoneName() {
		return zonelisttxtzonename;
	}

	public QAFWebElement getDropdownCity() {
		return zonelistdropdowncity;
	}

	public QAFWebElement getLblTitle() {
		return zonelistLblTitle;
	}

	public QAFWebElement getLblTotalRecods() {
		return zonelistlbltotalrecods;
	}

	public QAFWebElement getLnkZoneResult() {
		return zonelistlnkzoneresult;
	}

	public QAFWebElement getDropdownPagiNation() {
		return zonelistdropdownpagination;
	}

	public List<QAFWebElement> getLblPageValue() {
		return zonelistlblpagevalue;
	}
	
	public QAFWebElement getCityValue(String linkno) {
		String loc = String.format(pageProps.getString("zonelist.dropdown.cityvalue"), linkno);
		return new QAFExtendedWebElement(loc);
	}

}
