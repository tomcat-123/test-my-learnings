package com.heb.automation.Steps.HD_WebApp.order;

import java.sql.Date;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.Keys;
import static com.heb.automation.common.components.PerfectoUtils.MAX_WAIT_TIME;

import com.heb.automation.Pages.HD_WebApp.CommonTestPage;
import com.heb.automation.Pages.HD_WebApp.order.OrderDisplayTestPage;
import com.heb.automation.Pages.HD_WebApp.order.OrderListingTestPage;
import com.heb.automation.Pages.HD_WebApp.searchresult.DriverSearchResultpage;
import com.heb.automation.Pages.HD_WebApp.searchresult.OrderSearchResultpage;
import com.heb.automation.Pages.HD_WebApp.searchresult.SearchResultPage;
import com.heb.automation.Steps.HD_WebApp.HD_WebAppCommonStepdef;
import com.heb.automation.Steps.HD_WebApp.db_validations.DB_validations;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class Order_WebAppStepdef extends TestDataContainer {

	@QAFTestStep(description = "Navigate to Order listing Page")
	public void nAvigateToOrderListingPage() {
		CommonTestPage common = new CommonTestPage();

		common.getNavigationBtnHamburger().click();
		common.getNavigationLblDriverSnapshot().waitForPresent(1000);
		common.getNavigationLblOrder().click();

	}

	@QAFTestStep(description = "navigate to Create Order Page")
	public void nAvigateToCreateOrderPage() {
		OrderListingTestPage order = new OrderListingTestPage();
		order.getBtnCreateOrderDelivery().waitForVisible(5000);
		;
		order.getBtnCreateOrderDelivery().click();
	}

	@QAFTestStep(description = "Verify the order listing page search section")
	public void vErifyTheOrderListingPageSearchSection() {
		CommonTestPage common = new CommonTestPage();
		OrderListingTestPage order = new OrderListingTestPage();

		order.getBtnCreateOrderDelivery().waitForPresent(1000);
		order.getBtnCreateOrderDelivery().verifyPresent();
		order.getBtnorderlistingcrump().verifyPresent();
		order.getBtnorderlistingcrump().click();
		order.getBtnReset().verifyPresent();
		order.getBtnSearch().verifyPresent();
		order.getLblCustomerFirstName().verifyPresent();
		order.getLblCustomerLastName().verifyPresent();
		order.getLblDeliveryDate().verifyPresent();
		order.getLblDisplayingRecords().verifyPresent();
		order.getLblFieldsRequired().verifyPresent();
		order.getLblOrderId().verifyPresent();
		order.getLblOrderStatus().verifyPresent();
		order.getLblStoreName().verifyPresent();
		order.getLblTitle().verifyPresent();
		order.getLblTotalRecords().verifyPresent();
		order.getTxtCustomerFirstName().verifyPresent();
		order.getTxtCustomerLastName().verifyPresent();
		order.getTxtDeliveryDate().verifyPresent();
		order.getTxtOrderid().verifyPresent();
		order.getTxtOrderStatus().verifyPresent();
		order.getTxtStoreName().verifyPresent();
		order.getBtnCalendar().click();
		order.getLblCalendarTable().verifyPresent();
		PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.ESCAPE);
		order.getDropDownOrderStatus().click();
		order.getLblOrderStausDropdownList().get(0).verifyPresent();

		common.getLblHomeRightArrow().verifyPresent();
		common.getLblHomeIcon().verifyPresent();
		common.getLblHomeRightArrow().verifyPresent();
		common.getCommonLblDisplayingRecords().verifyPresent();
		common.getCommonBtnPageNum().get(0).verifyPresent();
	}

	@QAFTestStep(description = "Verify the order listing page grid section")
	public void vErifyTheOrderListingPageGridSection() {
		SearchResultPage sResult = new SearchResultPage();
		ArrayList<String> data = new ArrayList<>();

		for (QAFWebElement rCount : sResult.getTableColumnName()) {

			data.add(rCount.getText());
		}

		if (data.contains("Order ID"))
			PerfectoUtils.reportMessage("Order ID is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Order ID is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Customer"))
			PerfectoUtils.reportMessage("Customer is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Customer is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Store"))
			PerfectoUtils.reportMessage("Store is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Store is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Delivery"))
			PerfectoUtils.reportMessage("Delivery is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Delivery is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Order Status"))
			PerfectoUtils.reportMessage("Order Status is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Order Status is not Avilable in Grid", MessageTypes.Fail);
	}

	@QAFTestStep(description = "click on order listing crump")
	public void cLickOnOrderListingCrump() {
		OrderListingTestPage order = new OrderListingTestPage();

		order.getBtnorderlistingcrump().waitForPresent(5000);
		order.getBtnorderlistingcrump().click();
	}

	@QAFTestStep(description = "verify user navigated to order listing page")
	public void vErifyusernAvigatedToOrderListingPage() {
		OrderListingTestPage order = new OrderListingTestPage();

		order.getLblTitle().waitForPresent(5000);
		order.getLblTitle().verifyPresent();
	}

	@QAFTestStep(description = "verify the details of unassigned drivers")
	public void vErifyTheDetailsOfUnassigneDrivers() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String OrderIdDisplayed = orderSearch.getOrderIdresult(Rowcount).getText();

			String[] Customer = OrderIdDisplayed.split("\n");
			int addressLine = Customer.length;

			if (addressLine == 2) {

				PerfectoUtils.reportMessage("Order ID & Driver status is getting displayed", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Order ID & Driver status is not getting displayed", MessageTypes.Fail);
			}

			if (OrderIdDisplayed.contains("NO DRIVER")) {

				PerfectoUtils.reportMessage("NO DRIVER ASSIGNED text is displayed for Unassigned Drivers",
						MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("NO DRIVER ASSIGNED text is not displayed for Unassigned Drivers",
						MessageTypes.Fail);
			}

			break;
		}
		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("Driver Listing Grid is empty", MessageTypes.Fail);

	}

	@QAFTestStep(description = "verify the details of customer")
	public void vErifyTheDetilsOfCustomer() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String CustomerDisplayed = orderSearch.getCustomerresult(Rowcount).getText();

			String[] Customer = CustomerDisplayed.split("\n");
			int addressLine = Customer.length;

			if (addressLine >= 5) {

				PerfectoUtils.reportMessage("Valid Customer address is displayed", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Valid Customer address is not displayed", MessageTypes.Fail);
			}

			break;
		}
		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("Driver Listing Grid is empty", MessageTypes.Fail);

	}

	@QAFTestStep(description = "verify the details of store")
	public void vErifyTheDetailsOfStore() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String StoreDisplayed = orderSearch.getStoreresult(Rowcount).getText();

			String[] Customer = StoreDisplayed.split("\n");
			int addressLine = Customer.length;

			if (addressLine == 2) {

				PerfectoUtils.reportMessage("Valid Store detail is displayed", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Valid Store detail is not displayed", MessageTypes.Fail);
			}

			Pattern p = Pattern.compile("\\d{3}-\\d{3}-\\d{4}");
			Matcher m = p.matcher(Customer[1]);
			if (m.matches()) {

				PerfectoUtils.reportMessage("Valid Phone Number is displayed for Stores", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Valid Phone Number is not displayed for Stores", MessageTypes.Fail);
			}

			break;
		}
		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("Driver Listing Grid is empty", MessageTypes.Fail);

	}

	@QAFTestStep(description = "click on the store name")
	public void cLickOnTheStoreName() {
		OrderListingTestPage order = new OrderListingTestPage();
		order.getLnkStore().click();
	}

	@QAFTestStep(description = "verify the details of delivery")
	public void vErifyTheDetailsOfDelivery() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String DeliveryDisplayed = orderSearch.getDeliveryresult(Rowcount).getText();

			String[] Customer = DeliveryDisplayed.split("\n");

			if (Customer[0].matches("[A-Z]{1}[a-z]{2,}[\\s][0-9]{1,},[\\s][0-9]{4}")) {

				PerfectoUtils.reportMessage("Valid Delivery date is displayed", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Valid Delivery date is not displayed", MessageTypes.Fail);
			}

			if (Customer[1]
					.matches("[0-9]{1,}:[0-9]{2}[\\s][A-Z]{2}[\\s][a-z]{2}[\\s][0-9]{1,}:[0-9]{2}[\\s][A-Z]{2}")) {

				PerfectoUtils.reportMessage("Valid Delivery time is displayed", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Valid Delivery time is not displayed", MessageTypes.Fail);
			}

			break;
		}
		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("Driver Listing Grid is empty", MessageTypes.Fail);

	}

	@QAFTestStep(description = "verify the details of assigned drivers")
	public void vErifyTheDetailsOfAssignedDrivers() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String OrderIdDisplayed = orderSearch.getOrderIdresult(Rowcount).getText();

			String[] Customer = OrderIdDisplayed.split("\n");
			int addressLine = Customer.length;

			if (addressLine == 3) {

				PerfectoUtils.reportMessage("Order ID & Driver Name & HasNotes  is getting displayed",
						MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Order ID & Driver Name & HasNotes is not getting displayed",
						MessageTypes.Fail);
			}

			if (!OrderIdDisplayed.contains("NO DRIVER")) {

				PerfectoUtils.reportMessage("NO DRIVER text is not displayed for assigned Drivers", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("NO DRIVER text is displayed for assigned Drivers", MessageTypes.Fail);
			}

			if (OrderIdDisplayed.contains("(Has Notes)")) {

				PerfectoUtils.reportMessage("Has Notes is avilable for assigned Drivers", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Has Notes is not avilable for assigned Drivers", MessageTypes.Fail);
			}

			if (OrderIdDisplayed.contains(getTestString("SelectedOrderID"))) {

				PerfectoUtils.reportMessage("Order Id is avilable for assigned Drivers", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Order Id is not avilable for assigned Drivers", MessageTypes.Fail);
			}

			break;
		}
		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("Driver Listing Grid is empty", MessageTypes.Fail);

	}

	@QAFTestStep(description = "verify the details of order status")
	public void vErifyTheDetailsOfOrderStatus() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String StoreDisplayed = orderSearch.getOrderStatusresult(Rowcount).getText();

			if (!StoreDisplayed.isEmpty()) {

				PerfectoUtils.reportMessage("Order Status column displays order status", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Order Status column not displays order status", MessageTypes.Fail);
			}

			break;
		}
		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("Driver Listing Grid is empty", MessageTypes.Fail);

	}

	@QAFTestStep(description = "enter order id")
	public void eEterOrderId() {
		OrderListingTestPage order = new OrderListingTestPage();

		order.getTxtOrderid().sendKeys(getTestString("SelectedOrderID"));
	}

	@QAFTestStep(description = "Verify the Order is Created in Order List Page")
	public void verifyTheOrderIsCreatedInOrderListPage() throws InterruptedException {
		OrderListingTestPage order = new OrderListingTestPage();
		HD_WebAppCommonStepdef searchorderid = new HD_WebAppCommonStepdef();
		order.waitForPageToLoad();
		order.getLblOrderId().waitForVisible(MAX_WAIT_TIME * 2);
		eEterOrderId();
		searchorderid.iClickSearchButton();
		String OrderIdCreated = getTestString("SelectedOrderID");
		String OrderIdListPage = verifytheNewOrderIdOrderListPage();
		if (OrderIdCreated.equals(OrderIdListPage)) {
			PerfectoUtils.reportMessage("Order ID: " + OrderIdListPage, MessageTypes.Info);
			PerfectoUtils.reportMessage("OrderId is Matching", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("OrderId is not Matched-OrderId in Order List Page: " + OrderIdListPage
					+ ", Newly Created OrderId: " + OrderIdCreated, MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Order is not Created in Order List Page")
	public void verifyTheOrderIsNotCreatedInOrderListPage() throws InterruptedException {
		OrderListingTestPage order = new OrderListingTestPage();
		HD_WebAppCommonStepdef searchorderid = new HD_WebAppCommonStepdef();
		SearchResultPage sResult = new SearchResultPage();

		order.getLblOrderId().waitForPresent(1000);
		eEterOrderId();
		searchorderid.iClickSearchButton();
		try {
			sResult.getTableRowList().get(0).waitForNotPresent(1000);
		} catch (Exception e) {
			// ignore
		}
		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		if (sResult.getTableRowList().size() == 0) {
			PerfectoUtils.reportMessage("Order Listing Grid is empty", MessageTypes.Info);
			PerfectoUtils.reportMessage("Order is not Created in Order List Page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Order Listing Grid is not empty", MessageTypes.Info);
			PerfectoUtils.reportMessage("Order is  Created in Order List Page", MessageTypes.Fail);
		}

	}

	public int verifyTheOrderIsNotAlreadyCreatedInOrderListPage(String OrderId) throws InterruptedException {
		OrderListingTestPage order = new OrderListingTestPage();
		HD_WebAppCommonStepdef searchorderid = new HD_WebAppCommonStepdef();
		SearchResultPage sResult = new SearchResultPage();

		int flag = 0;
		order.getLblOrderId().waitForPresent(1000);
		order.getTxtOrderid().clear();
		order.getTxtOrderid().sendKeys(OrderId);
		searchorderid.iClickSearchButton();
		try {
			sResult.getTableRowList().get(0).waitForNotPresent(1000);
		} catch (Exception e) {
			// ignore
		}
		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		if (sResult.getTableRowList().size() == 0) {
			PerfectoUtils.reportMessage("Order is not Already Created in Order List Page", MessageTypes.Info);
			flag = 1;
		} else {
			PerfectoUtils.reportMessage("Order is Already Created in Order List Page", MessageTypes.Info);
			flag = 0;
		}

		return flag;

	}

	@QAFTestStep(description = "verify the new orderId in order list page")
	public String verifytheNewOrderIdOrderListPage() {
		String data = null;
		int Rowcount = 1;
		String OrderIdDisplayed = null;
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);
			OrderIdDisplayed = orderSearch.getOrderIdresult(Rowcount).getText();
		}
		if (sResult.getTableRowList().size() == 0) {
			PerfectoUtils.reportMessage("Driver Listing Grid is empty", MessageTypes.Fail);
		}
		return OrderIdDisplayed.split("\n")[0];

	}

	@QAFTestStep(description = "verify driver name in First Name Last Name format")
	public void vErifyDriverNameInFirstNameLastNameFormat() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String OrderIdDisplayed = orderSearch.getOrderIdresult(Rowcount).getText();

			String[] Customer = OrderIdDisplayed.split("\n");
			int addressLine = Customer.length;

			String fName = getTestString("FirstName");
			String lName = getTestString("LastName");

			if (OrderIdDisplayed.contains(fName + " " + lName)) {

				PerfectoUtils.reportMessage("Driver name is in First Name Last Name format", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Driver name is not in First Name Last Name format", MessageTypes.Fail);
			}
			break;
		}
		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("Driver Listing Grid is empty", MessageTypes.Fail);

	}

	@QAFTestStep(description = "verify the customer column in the grid")
	public void vErifyTheCustomerColumnInTheGrid() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String CustomerDisplayed = orderSearch.getCustomerresult(Rowcount).getText();

			String AddressLine1 = getTestString("addressLine1");
			String AddressLine2 = getTestString("addressLine2");
			String City = getTestString("City");
			String LastName = getTestString("LastName");
			String State = getTestString("State");
			String FirstName = getTestString("FirstName");
			String ZipCode = getTestString("ZipCode");
			String Email = getTestString("Email");
			String Phone = getTestString("Phone");

			if (CustomerDisplayed.contains(FirstName + " " + LastName)) {

				PerfectoUtils.reportMessage("First & Last Name present in Customer Column", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("First & Last Name not present in Customer Column", MessageTypes.Fail);
			}

			if (CustomerDisplayed.contains(AddressLine1)) {
				PerfectoUtils.reportMessage("AddressLine1 present in Customer Column", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("AddressLine1is not present in Customer Column", MessageTypes.Fail);
			}

			if (CustomerDisplayed.contains(AddressLine2)) {
				PerfectoUtils.reportMessage("AddressLine2 present in Customer Column", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("AddressLine2 not present in Customer Column", MessageTypes.Fail);
			}

			if (CustomerDisplayed.contains(City)) {
				PerfectoUtils.reportMessage("City present in Customer Column", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("City not present in Customer Column", MessageTypes.Fail);
			}

			if (CustomerDisplayed.contains(State)) {
				PerfectoUtils.reportMessage("State present in Customer Column", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("State not present in Customer Column", MessageTypes.Fail);
			}

			if (CustomerDisplayed.contains(ZipCode)) {
				PerfectoUtils.reportMessage("ZipCode present in Customer Column", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("ZipCode not present in Customer Column", MessageTypes.Fail);
			}

			if (CustomerDisplayed.contains(Email)) {
				PerfectoUtils.reportMessage("Email present in Customer Column", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Email not present in Customer Column", MessageTypes.Fail);
			}

			if (CustomerDisplayed.contains(Phone)) {
				PerfectoUtils.reportMessage("Phon present in Customer Column", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Phone not present in Customer Column", MessageTypes.Fail);
			}

			break;
		}
		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("Driver Listing Grid is empty", MessageTypes.Fail);

	}

	@QAFTestStep(description = "verify the store column in the grid")
	public void vErifyTheStoreColumnInTheGrid() {
		String data = null;
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String StoreDisplayed = orderSearch.getStoreresult(Rowcount).getText();

			String pHone = getTestString("Phone");
			String nAme = getTestString("Name");

			if (StoreDisplayed.contains(pHone)) {

				PerfectoUtils.reportMessage("Phone present in Customer Column", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Phone not present in Customer Column", MessageTypes.Fail);
			}

			if (StoreDisplayed.contains(nAme)) {
				PerfectoUtils.reportMessage("Name present in Customer Column", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Name not present in Customer Column", MessageTypes.Fail);
			}
			break;
		}
		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("Driver Listing Grid is empty", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Verify Page does not display orders in Delivered status")
	public void verifyPagedoesnotdisplayordersinDeliveredstatus() {
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		int Rowcount = 1;
		orderSearch.getOrderIdresult(Rowcount).waitForPresent(MAX_WAIT_TIME);
		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String OrderStatusDisplayed = orderSearch.getOrderStatusresult(Rowcount).getText().trim();

			if (OrderStatusDisplayed.equals("Delivered")) {

				PerfectoUtils.reportMessage("Delivered status is displayed in Order Status", MessageTypes.Fail);

			} else {
				PerfectoUtils.reportMessage("Delivered status is not displayed in Order Status", MessageTypes.Pass);
			}

			Rowcount++;
		}
		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("Order List is empty", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Verify Page only displays current day orders")
	public void verifyPageonlydisplayscurrentdayorders() throws SQLException {
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();
		DB_validations db = new DB_validations();
		OrderDisplayTestPage orderdisplay = new OrderDisplayTestPage();

		int Rowcount = 1;
		orderSearch.getOrderIdresult(Rowcount).waitForPresent(MAX_WAIT_TIME);

		Calendar cal = Calendar.getInstance();
		String dateFormated = new SimpleDateFormat("MMMM dd, yyyy").format(cal.getTime());
		String dateFormatedforSQL = new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime());
		cal.add(Calendar.DATE, 1);
		String dateFormatedforplusonedate = new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime());

		putTestObject("CurrentDateSQL", dateFormatedforSQL);
		putTestObject("CurrentDatePlusOneSQL", dateFormatedforplusonedate);

		db.selectAllCurrentDayOrders(getTestString("SQL.Select_current_day_orders"));
		String totalOrdersfromSQL = getTestString("currentDayTotalOrdersSQL");
		String[] totalOrdersfromPage = orderdisplay.getLblTotalrecords().getText().split(":");
		if (totalOrdersfromSQL.equals(totalOrdersfromPage[1].trim())) {
			PerfectoUtils.reportMessage("Page current day orders matches with Database", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Page current day orders " + totalOrdersfromPage[1].trim()
					+ " does not matched with Database count " + totalOrdersfromSQL, MessageTypes.Fail);
		}

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String OrderDeliveryDisplayed = orderSearch.getDeliveryresult(Rowcount).getText().trim();

			if (OrderDeliveryDisplayed.contains(dateFormated)) {

				PerfectoUtils.reportMessage("Page only displays current day orders", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Page is not displayed with current day orders", MessageTypes.Fail);
			}

			Rowcount++;
		}
		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("Order List is empty", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Verify Orders has mentioned status")
	public void verifyOrdershasStatus() {
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		int Rowcount = 1;
		orderSearch.getOrderIdresult(Rowcount).waitForPresent(MAX_WAIT_TIME);
		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String OrderStatusDisplayed = orderSearch.getOrderStatusresult(Rowcount).getText().trim();

			if (OrderStatusDisplayed.equals(getTestString("HomeDelivery.orderstatus.new"))
					|| OrderStatusDisplayed
							.equals(getTestString("HomeDelivery.orderstatus.inprocess"))
					|| OrderStatusDisplayed.equals(
							getTestString("HomeDelivery.orderstatus.driverassigned"))
					|| OrderStatusDisplayed
							.equals(getTestString("HomeDelivery.orderstatus.delivered"))
					|| OrderStatusDisplayed
							.equals(getTestString("HomeDelivery.orderstatus.cancelled"))
					|| OrderStatusDisplayed
							.equals(getTestString("HomeDelivery.orderstatus.notdelivered"))
					|| OrderStatusDisplayed
							.equals(getTestString("HomeDelivery.orderstatus.delayed"))
					|| OrderStatusDisplayed
							.equals(getTestString("HomeDelivery.orderstatus.failed"))) {

				PerfectoUtils.reportMessage("Orders has mentioned status", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Orders is not having mentioned status", MessageTypes.Fail);
			}

			Rowcount++;
		}
		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("Order List is empty", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Search and verify click of reset button clears search criteria entered")
	public void searchFirstOrderintheSearchResultsandVerifyResetButton() {
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();
		OrderListingTestPage order = new OrderListingTestPage();

		int Rowcount = 1;
		int rowcount = sResult.getTableRowList().size();
		PerfectoUtils.reportMessage("Before Reset-Order List Data Count : "+rowcount, MessageTypes.Info);
		System.out.println(rowcount);

		if (rowcount > 0) {
			orderSearch.getOrderIdresult(Rowcount).waitForPresent(MAX_WAIT_TIME);
			String OrderIDDisplayed = orderSearch.getOrderIdresult(Rowcount).getText().trim();
			String numberOnly = OrderIDDisplayed.replaceAll("[^0-9]", "");
			order.getTxtOrderid().sendKeys(numberOnly);
			order.getBtnSearch().click();
			PerfectoUtils.reportMessage("Clicked Search Button", MessageTypes.Pass);

			if (orderSearch.getOrderIdresult(Rowcount).getText().contains(numberOnly)) {
				PerfectoUtils.reportMessage("Search Results are appropriate to the search criteria", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Search Results are not appropriate to the search criteria",
						MessageTypes.Fail);
			}
			order.getBtnReset().click();
			
			order.getBtnReset().verifyPresent();
			
			if(order.getTxtOrderid().getText().equals("") || order.getTxtOrderid().getText().isEmpty()){
				PerfectoUtils.reportMessage("Reset button clears search criteria entered", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Reset button not clears search criteria entered", MessageTypes.Fail);
			}
			int updatedRowcount = sResult.getTableRowList().size();
			if (updatedRowcount == rowcount) {
				PerfectoUtils.reportMessage("After Reset-Order List Data Count : "+rowcount, MessageTypes.Info);
			if(updatedRowcount == rowcount){
				PerfectoUtils.reportMessage("Reset button reloads page with original results", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Reset button not reloads page with original results", MessageTypes.Fail);
			}}
		} else {
			PerfectoUtils.reportMessage("Order List is empty", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify NO DRIVER has red text")
	public void verifyNODRIVERhasredtext() {
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		int Rowcount = 0;
		orderSearch.getOrderIdresult(1).waitForPresent(MAX_WAIT_TIME);
		int nodriverrowcount = orderSearch.getLstNoDriver().size();
		System.out.println(nodriverrowcount);

		for (; Rowcount < nodriverrowcount;) {
			System.out.println(Rowcount);

			if (orderSearch.getLstNoDriver().get(Rowcount).getCssValue("color")
					.equals(getTestString("HomeDelivery.color.red"))) {
				PerfectoUtils.reportMessage("NO DRIVER is displayed in red text", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("NO DRIVER is not displayed in red text", MessageTypes.Fail);
			}

			Rowcount++;
		}
		if (sResult.getTableRowList().size() == 0)
			PerfectoUtils.reportMessage("Order List is empty", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Search Order by Customer First name")
	public void verifySearchOrderByCustomerFirstName() throws InterruptedException {
		OrderListingTestPage order = new OrderListingTestPage();
		HD_WebAppCommonStepdef searchorderid = new HD_WebAppCommonStepdef();
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		order.waitForPageToLoad();
		order.getTxtOrderid().waitForVisible(MAX_WAIT_TIME * 2);
		String actualCustomerDetails = null;
		String customerFirstName = getTestString("HomeDelivery.customerfirstname");
		order.getTxtCustomerFirstName().sendKeys(customerFirstName);
		searchorderid.iClickSearchButton();
		PerfectoUtils.reportMessage(
				"Entered Customer First name: " + customerFirstName + " and clicked on search button",
				MessageTypes.Pass);
		int rowcount = sResult.getTableRowList().size();
		if (rowcount > 0) {
			actualCustomerDetails = orderSearch.getLblCustomerDetails(1).getText();
		} else {
			PerfectoUtils.reportMessage("No result is displayed for the Customer First name " + customerFirstName,
					MessageTypes.Fail);
		}
		if (actualCustomerDetails.contains(customerFirstName)) {
			PerfectoUtils.reportMessage("Customer Details: " + actualCustomerDetails, MessageTypes.Info);
			PerfectoUtils.reportMessage("Customer First name is Matching", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Customer First name is not Matched Actual: " + actualCustomerDetails
					+ ", Expected: " + customerFirstName, MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Search Order by Customer Last name")
	public void verifySearchOrderByCustomerLastName() throws InterruptedException {
		OrderListingTestPage order = new OrderListingTestPage();
		HD_WebAppCommonStepdef searchorderid = new HD_WebAppCommonStepdef();
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		order.waitForPageToLoad();
		order.getTxtOrderid().waitForVisible(MAX_WAIT_TIME * 2);
		String actualCustomerDetails = null;
		String customerLastName = getTestString("HomeDelivery.customerlastname");
		order.getTxtCustomerLastName().sendKeys(customerLastName);
		searchorderid.iClickSearchButton();
		PerfectoUtils.reportMessage("Entered Customer Last name: " + customerLastName + " and clicked on search button",
				MessageTypes.Pass);
		int rowcount = sResult.getTableRowList().size();
		if (rowcount > 0) {
			actualCustomerDetails = orderSearch.getLblCustomerDetails(1).getText();
		} else {
			PerfectoUtils.reportMessage("No result is displayed for the Customer Last name " + customerLastName,
					MessageTypes.Fail);
		}
		if (actualCustomerDetails.contains(customerLastName)) {
			PerfectoUtils.reportMessage("Customer Details: " + actualCustomerDetails, MessageTypes.Info);
			PerfectoUtils.reportMessage("Customer Last name is Matching", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Customer Last name is not Matched Actual: " + actualCustomerDetails
					+ ", Expected: " + customerLastName, MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Search Order by Store name")
	public void verifySearchOrderByStoreName() throws InterruptedException {
		OrderListingTestPage order = new OrderListingTestPage();
		HD_WebAppCommonStepdef searchorderid = new HD_WebAppCommonStepdef();
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		order.waitForPageToLoad();
		order.getTxtOrderid().waitForVisible(MAX_WAIT_TIME * 2);
		String actualStoreName = null;
		String storeName = getTestString("HomeDelivery.storename");
		order.getTxtStoreName().sendKeys(storeName);
		searchorderid.iClickSearchButton();
		PerfectoUtils.reportMessage("Entered Store name: " + storeName + " and clicked on search button",
				MessageTypes.Pass);
		int rowcount = sResult.getTableRowList().size();
		if (rowcount > 0) {
			actualStoreName = orderSearch.getLnkStoreName(1).getText();
		} else {
			PerfectoUtils.reportMessage("No result is displayed for the Store name " + storeName, MessageTypes.Fail);
		}
		if (actualStoreName.equals(storeName)) {
			PerfectoUtils.reportMessage("Store Name: " + actualStoreName, MessageTypes.Info);
			PerfectoUtils.reportMessage("Store name is Matching", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Store name is not Matched Actual: " + actualStoreName + ", Expected: " + storeName,
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Search Order by Delivery Date")
	public void verifySearchOrderByDeliveryDate() throws InterruptedException {
		OrderListingTestPage order = new OrderListingTestPage();
		HD_WebAppCommonStepdef searchorderid = new HD_WebAppCommonStepdef();
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		order.waitForPageToLoad();
		order.getTxtOrderid().waitForVisible(MAX_WAIT_TIME * 2);
		String actualDeliveryDate = null;
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1);
		String dateFormated = new SimpleDateFormat("M/d/yyyy").format(cal.getTime());
		String dateFormatedforResult = new SimpleDateFormat("MMMM d, yyyy").format(cal.getTime());
		String deliveryDate = dateFormated;
		order.getTxtDeliveryDate().sendKeys(deliveryDate);
		searchorderid.iClickSearchButton();
		PerfectoUtils.reportMessage("Entered Delivery Date: " + deliveryDate + " and clicked on search button",
				MessageTypes.Pass);
		int rowcount = sResult.getTableRowList().size();
		if (rowcount > 0) {
			actualDeliveryDate = orderSearch.getLblDeliveryDetails(1).getText();
		} else {
			PerfectoUtils.reportMessage("No result is displayed for the delivery date " + deliveryDate,
					MessageTypes.Fail);
		}

		if (actualDeliveryDate.contains(dateFormatedforResult)) {
			PerfectoUtils.reportMessage("Delivery date: " + actualDeliveryDate, MessageTypes.Info);
			PerfectoUtils.reportMessage("Delivery date is Matching", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Delivery date is not Matched Actual: " + actualDeliveryDate + ", Expected: " + deliveryDate,
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Search Order by Order Status")
	public void verifySearchOrderByOrderStatus() {
		OrderListingTestPage order = new OrderListingTestPage();

		order.waitForPageToLoad();
		verifyOrderSearchResultsByOrderStatus(
				getTestString("HomeDelivery.orderstatus.new"));
		verifyOrderSearchResultsByOrderStatus(
				getTestString("HomeDelivery.orderstatus.processed"));
		verifyOrderSearchResultsByOrderStatus(
				getTestString("HomeDelivery.orderstatus.outfordelivery"));
		verifyOrderSearchResultsByOrderStatus(
				getTestString("HomeDelivery.orderstatus.delivered"));
		verifyOrderSearchResultsByOrderStatus(
				getTestString("HomeDelivery.orderstatus.cancelled"));
		verifyOrderSearchResultsByOrderStatus(
				getTestString("HomeDelivery.orderstatus.returned"));
		verifyOrderSearchResultsByOrderStatus(
				getTestString("HomeDelivery.orderstatus.undeliverable"));
		verifyOrderSearchResultsByOrderStatus(
				getTestString("HomeDelivery.orderstatus.onhold"));
		verifyOrderSearchResultsByOrderStatus(
				getTestString("HomeDelivery.orderstatus.deliveryincident"));
		verifyOrderSearchResultsByOrderStatus(
				getTestString("HomeDelivery.orderstatus.unavailable"));
		verifyOrderSearchResultsByOrderStatus(
				getTestString("HomeDelivery.orderstatus.destinationincorrect"));
		verifyOrderSearchResultsByOrderStatus(
				getTestString("HomeDelivery.orderstatus.itemdamaged"));
		verifyOrderSearchResultsByOrderStatus(
				getTestString("HomeDelivery.orderstatus.other"));
		verifyOrderSearchResultsByOrderStatus(
				getTestString("HomeDelivery.orderstatus.itemincorrect"));
	}

	@QAFTestStep(description = "Search Order by Combination of Customer name,Store name,Delivery Date,Order Status")
	public void verifySearchOrderByCombination() throws InterruptedException {
		OrderListingTestPage order = new OrderListingTestPage();
		HD_WebAppCommonStepdef searchorderid = new HD_WebAppCommonStepdef();
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		order.waitForPageToLoad();
		order.getTxtOrderid().waitForVisible(MAX_WAIT_TIME * 2);
		String actualCustomerDetails = null;
		String actualStoreName = null;
		String actualDeliveryDate = null;
		String actualOrderStatus = null;

		String customerFirstName = getTestString("HomeDelivery.customerfirstname");
		String customerLastName = getTestString("HomeDelivery.customerlastname");
		String storeName = getTestString("HomeDelivery.storename");
		String deliveryDate = getTestString("HomeDelivery.deliverydate");
		String deliveryDateExpected = new SimpleDateFormat("MMMM d, yyyy").format(Date.valueOf(getTestString("HomeDelivery.deliverydateFormat")));
		String orderStatus = getTestString("HomeDelivery.orderstatus.new");

		order.getDropDownOrderStatus().click();
		order.getLnkOrderStatus(orderStatus).click();
		order.getTxtDeliveryDate().sendKeys(deliveryDate);
		order.getTxtCustomerFirstName().sendKeys(customerFirstName);
		order.getTxtCustomerLastName().sendKeys(customerLastName);
		order.getTxtStoreName().sendKeys(storeName);
		searchorderid.iClickSearchButton();

		PerfectoUtils.reportMessage("Entered Customer First name: " + customerFirstName, MessageTypes.Info);
		PerfectoUtils.reportMessage("Entered Customer Last name: " + customerLastName, MessageTypes.Info);
		PerfectoUtils.reportMessage("Entered Store name: " + storeName, MessageTypes.Info);
		PerfectoUtils.reportMessage("Entered Delivery Date: " + deliveryDate, MessageTypes.Info);
		PerfectoUtils.reportMessage("Selected Order Status: " + orderStatus, MessageTypes.Info);

		int rowcount = sResult.getTableRowList().size();
		if (rowcount > 0) {
			actualCustomerDetails = orderSearch.getLblCustomerDetails(1).getText();
			actualStoreName = orderSearch.getLnkStoreName(1).getText();
			actualDeliveryDate = orderSearch.getLblDeliveryDetails(1).getText();
			actualOrderStatus = orderSearch.getLnkOrderStatus(1).getText();
		} else {
			PerfectoUtils.reportMessage("No result is displayed for the combinational search", MessageTypes.Fail);
		}
		if (actualCustomerDetails.contains(customerFirstName) && actualCustomerDetails.contains(customerLastName)
				&& actualStoreName.equals(storeName) && actualOrderStatus.equals(orderStatus)
				&& actualDeliveryDate.contains(deliveryDateExpected)) {
			PerfectoUtils.reportMessage("Customer Details: " + actualCustomerDetails, MessageTypes.Info);
			PerfectoUtils.reportMessage("Store Name: " + actualStoreName, MessageTypes.Info);
			PerfectoUtils.reportMessage("Delivery date: " + actualDeliveryDate, MessageTypes.Info);
			PerfectoUtils.reportMessage("Order Status: " + actualOrderStatus, MessageTypes.Info);
			PerfectoUtils.reportMessage("Combination Search is Matching", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Customer Details: " + actualCustomerDetails, MessageTypes.Info);
			PerfectoUtils.reportMessage("Store Name: " + actualStoreName, MessageTypes.Info);
			PerfectoUtils.reportMessage("Delivery date: " + actualDeliveryDate, MessageTypes.Info);
			PerfectoUtils.reportMessage("Order Status: " + actualOrderStatus, MessageTypes.Info);
			PerfectoUtils.reportMessage("Combinational search is not Matched", MessageTypes.Fail);
		}
	}

	private void verifyOrderSearchResultsByOrderStatus(String orderStatus) {
		OrderListingTestPage order = new OrderListingTestPage();
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		String actualOrderStatus = null;
		order.getTxtOrderid().waitForVisible(MAX_WAIT_TIME * 2);
		order.getDropDownOrderStatus().click();
		order.getLnkOrderStatus(orderStatus).click();
		PerfectoUtils.reportMessage("Clicked on Order Status: " + orderStatus, MessageTypes.Pass);
		int rowcount = sResult.getTableRowList().size();
		if (rowcount > 0) {
			actualOrderStatus = orderSearch.getLnkOrderStatus(1).getText();
		} else {
			PerfectoUtils.reportMessage("No result is displayed for the Order Status - " + orderStatus,
					MessageTypes.Fail);
		}
		if (actualOrderStatus.equals(orderStatus)) {
			PerfectoUtils.reportMessage("Order Status: " + actualOrderStatus, MessageTypes.Info);
			PerfectoUtils.reportMessage("Order Status is Matching", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Order Status is not Matched Actual: " + actualOrderStatus + ", Expected: " + orderStatus,
					MessageTypes.Fail);
		}
	}

}
