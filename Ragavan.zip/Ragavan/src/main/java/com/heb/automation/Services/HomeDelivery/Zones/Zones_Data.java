package com.heb.automation.Services.HomeDelivery.Zones;

import java.util.ArrayList;

public class Zones_Data {
	
	private boolean archived;

    private City_Data city = new City_Data();

    private String externalIdOnfleet;

    private String lastModifiedTimestamp;

    private String id;

    private String[] zipCodes;

    private String name;

    public boolean getArchived ()
    {
        return archived;
    }

    public void setArchived (boolean archived)
    {
        this.archived = archived;
    }

    public City_Data getCity ()
    {
        return city;
    }

    public void setCity (City_Data city)
    {
        this.city = city;
    }

    public String getexternalIdOnfleet ()
    {
        return externalIdOnfleet;
    }

    public void setexternalIdOnfleet (String externalIdOnfleet)
    {
        this.externalIdOnfleet = externalIdOnfleet;
    }

    public String getLastModifiedTimestamp ()
    {
        return lastModifiedTimestamp;
    }

    public void setLastModifiedTimestamp (String lastModifiedTimestamp)
    {
        this.lastModifiedTimestamp = lastModifiedTimestamp;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String[] getZipCodes ()
    {
        return zipCodes;
    }

    public void setZipCodes (String[] zipCodes)
    {
        this.zipCodes = zipCodes;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [archived = "+archived+", city = "+city+", externalIdOnfleet = "+externalIdOnfleet+", lastModifiedTimestamp = "+lastModifiedTimestamp+", id = "+id+", zipCodes = "+zipCodes+", name = "+name+"]";
    }

}
