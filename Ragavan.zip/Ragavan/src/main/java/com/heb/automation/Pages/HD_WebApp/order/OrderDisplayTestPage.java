package com.heb.automation.Pages.HD_WebApp.order;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class OrderDisplayTestPage extends WebDriverBaseTestPage<WebDriverTestPage>{

	@FindBy (locator="orderdisplay.lbl.title")
	private QAFWebElement orderdisplaylbltitle;
	
	@FindBy (locator="orderdisplay.btn.ordercrump")
	private QAFWebElement orderdisplaybtnordercrump;
	
	@FindBy (locator="orderdisplay.btn.ordernumcrump")
	private QAFWebElement orderdisplaybtnordernumcrump;
	
	@FindBy (locator="orderdisplay.lbl.orderdetails")
	private QAFWebElement orderdisplaylblorderdetails;
	
	@FindBy (locator="orderdisplay.txt.orderid")
	private QAFWebElement orderdisplaytxtorderid;
	 
	@FindBy (locator="orderdisplay.txt.customeraddress")
	private QAFWebElement orderdisplaytxtcustomeraddress;
	
	@FindBy (locator="orderdisplay.txt.zonename")
	private QAFWebElement orderdisplaytxtzonename;
	 
	@FindBy (locator="orderdisplay.txt.deliverystart")
	private QAFWebElement orderdisplaytxtdeliverystart;
	
	@FindBy (locator="orderdisplay.txt.recipient")
	private QAFWebElement orderdisplaytxtrecipient;
	
	@FindBy (locator="orderdisplay.txt.tips")
	private QAFWebElement orderdisplaytxttips;
	
	@FindBy (locator="orderdisplay.txt.createdat")
	private QAFWebElement orderdisplaytxtcreatedat;
	
	@FindBy (locator="orderdisplay.txt.customer")
	private QAFWebElement orderdisplaytxtcustomer;
	
	@FindBy (locator="orderdisplay.txt.storename")
	private QAFWebElement orderdisplaytxtstorename;
	 
	@FindBy (locator="orderdisplay.txt.cityname")
	private QAFWebElement orderdisplaytxtcityname;
	
	@FindBy (locator="orderdisplay.txt.deliveryend")
	private QAFWebElement orderdisplaytxtdeliveryend;
	
	@FindBy (locator="orderdisplay.txt.grossbill")
	private QAFWebElement orderdisplaytxtgrossbill;
	
	@FindBy (locator="orderdisplay.txt.orderstatus")
	private QAFWebElement orderdisplaytxtorderstatus;
	
	@FindBy (locator="orderdisplay.txt.updatedat")
	private QAFWebElement orderdisplaytxtupdatedat;
	 
	@FindBy (locator="orderdisplay.lbl.notes")
	private QAFWebElement orderdisplaylblnotes;
	
	@FindBy (locator="orderdisplay.txt.adminnotes")
	private QAFWebElement orderdisplaytxtadminnotes;
	
	@FindBy (locator="orderdisplay.txt.ordernotes")
	private QAFWebElement orderdisplaytxtordernotes;
	 
	@FindBy (locator="orderdisplay.lbl.signaturerequired")
	private QAFWebElement orderdisplaylblsignaturerequired;
	
	@FindBy (locator="orderdisplay.btn.yessignaturerequired")
	private QAFWebElement orderdisplaybtnyessignaturerequired;
	
	@FindBy (locator="orderdisplay.btn.nosignaturerequired")
	private QAFWebElement orderdisplaybtnnosignaturerequired;
	
	@FindBy (locator="orderdisplay.lbl.yessignaturerequired")
	private QAFWebElement orderdisplaylblyessignaturerequired;
	 
	@FindBy (locator="orderdisplay.lbl.nosignaturerequired")
	private QAFWebElement orderdisplaylblnosignaturerequired;
	
	@FindBy (locator="orderdisplay.lbl.hasalcohol")
	private QAFWebElement orderdisplaylblhasalcohol;
	
	@FindBy (locator="orderdisplay.btn.yeshasalcohol")
	private QAFWebElement orderdisplaybtnyeshasalcohol;
	 
	@FindBy (locator="orderdisplay.btn.nohasalcohol")
	private QAFWebElement orderdisplaybtnnohasalcohol;
	
	@FindBy (locator="orderdisplay.lbl.yeshasalcohol")
	private QAFWebElement orderdisplaylblyeshasalcohol;
	
	@FindBy (locator="orderdisplay.lbl.nohasalcohol")
	private QAFWebElement orderdisplaylblnohasalcohol;
	
	@FindBy (locator="orderdisplay.lbl.driver")
	private QAFWebElement orderdisplaylbldriver;
	 
	@FindBy (locator="orderdisplay.txt.drivername")
	private QAFWebElement orderdisplaytxtdrivername;
	
	@FindBy (locator="orderdisplay.txt.pickUpEndTime")
	private QAFWebElement orderdisplaytxtpickUpEndTime;
	
	@FindBy (locator="orderdisplay.txt.orderEndTime")
	private QAFWebElement orderdisplaytxtorderEndTime;
	
	@FindBy (locator="orderdisplay.txt.onfleetDropoffTask")
	private QAFWebElement orderdisplaytxtonfleetDropoffTask;
	 
	@FindBy (locator="orderdisplay.txt.pickUpStartTime")
	private QAFWebElement orderdisplaytxtpickUpStartTime;
	
	@FindBy (locator="orderdisplay.txt.orderStartTime")
	private QAFWebElement orderdisplaytxtorderStartTime;
	
	@FindBy (locator="orderdisplay.txt.onfleetPickupTask")
	private QAFWebElement orderdisplaytxtonfleetPickupTask;
	
	@FindBy (locator="orderdisplay.btn.edit")
	private QAFWebElement orderdisplaybtnedit;
	
	@FindBy (locator="orderdisplay.btn.cancel")
	private QAFWebElement orderdisplaybtncancel;
	
	@FindBy (locator="orderdisplay.btn.delete")
	private QAFWebElement orderdisplaybtndelete;
	
	@FindBy (locator="orderdisplay.lbl.totalrecords")
	private QAFWebElement orderdisplaylbltotalrecords;
	
	public QAFWebElement getLblTotalrecords() {
		return orderdisplaylbltotalrecords;
	}
	
	public QAFWebElement getLblTitle() {
		return orderdisplaylbltitle;
	}

	public QAFWebElement getBtnOrderCrump() {
		return orderdisplaybtnordercrump;
	}

	public QAFWebElement getBtnOrderNummberCrump() {
		return orderdisplaybtnordernumcrump;
	}

	public QAFWebElement getLblOrderDetails() {
		return orderdisplaylblorderdetails;
	}

	public QAFWebElement getTxtOrderId() {
		return orderdisplaytxtorderid;
	}

	public QAFWebElement getTxtCustomerAddress() {
		return orderdisplaytxtcustomeraddress;
	}

	public QAFWebElement getTxtZoneName() {
		return orderdisplaytxtzonename;
	}

	public QAFWebElement getTxtDeliveryStart() {
		return orderdisplaytxtdeliverystart;
	}

	public QAFWebElement getTxtRecipient() {
		return orderdisplaytxtrecipient;
	}

	public QAFWebElement getTxtTips() {
		return orderdisplaytxttips;
	}

	public QAFWebElement getTxtCreatedAt() {
		return orderdisplaytxtcreatedat;
	}

	public QAFWebElement getTxtCustomer() {
		return orderdisplaytxtcustomer;
	}

	public QAFWebElement getTxtStoreName() {
		return orderdisplaytxtstorename;
	}

	public QAFWebElement getTxtCityName() {
		return orderdisplaytxtcityname;
	}

	public QAFWebElement getTxtDeliveryEnd() {
		return orderdisplaytxtdeliveryend;
	}

	public QAFWebElement getTxtGrossBill() {
		return orderdisplaytxtgrossbill;
	}

	public QAFWebElement getTxtOrderStatus() {
		return orderdisplaytxtorderstatus;
	}

	public QAFWebElement getTxtUpdatedAt() {
		return orderdisplaytxtupdatedat;
	}

	public QAFWebElement getLblNotes() {
		return orderdisplaylblnotes;
	}

	public QAFWebElement getTxtAdminNotes() {
		return orderdisplaytxtadminnotes;
	}

	public QAFWebElement getTxtOrderNotes() {
		return orderdisplaytxtordernotes;
	}

	public QAFWebElement getLblSignatureRequired() {
		return orderdisplaylblsignaturerequired;
	}

	public QAFWebElement getbtnyessignaturerequired() {
		return orderdisplaybtnyessignaturerequired;
	}

	public QAFWebElement getBtnNoSignatureRequired() {
		return orderdisplaybtnnosignaturerequired;
	}

	public QAFWebElement getLblYesSignatureRequired() {
		return orderdisplaylblyessignaturerequired;
	}

	public QAFWebElement getLblNoSignatureRequired() {
		return orderdisplaylblnosignaturerequired;
	}

	public QAFWebElement getLblHasAlcohol() {
		return orderdisplaylblhasalcohol;
	}

	public QAFWebElement getBtnYesHasAlcohol() {
		return orderdisplaybtnyeshasalcohol;
	}

	public QAFWebElement getBtnNoHasAlcohol() {
		return orderdisplaybtnnohasalcohol;
	}

	public QAFWebElement getLblYesHasAlcohol() {
		return orderdisplaylblyeshasalcohol;
	}

	public QAFWebElement getLblNoHasAlcohol() {
		return orderdisplaylblnohasalcohol;
	}

	public QAFWebElement getLblDriver() {
		return orderdisplaylbldriver;
	}

	public QAFWebElement getTxtDriverName() {
		return orderdisplaytxtdrivername;
	}

	public QAFWebElement getTxtPickUpEndTime() {
		return orderdisplaytxtpickUpEndTime;
	}

	public QAFWebElement getTxtOrderEndTime() {
		return orderdisplaytxtorderEndTime;
	}

	public QAFWebElement getTxtOnfleetDropoffTask() {
		return orderdisplaytxtonfleetDropoffTask;
	}

	public QAFWebElement getTxtPickUpStartTime() {
		return orderdisplaytxtpickUpStartTime;
	}

	public QAFWebElement getTxtOrderStartTime() {
		return orderdisplaytxtorderStartTime;
	}

	public QAFWebElement getTxtOnFleetPickupTask() {
		return orderdisplaytxtonfleetPickupTask;
	}

	public QAFWebElement getBtnEdit() {
		return orderdisplaybtnedit;
	}

	public QAFWebElement getBtnCancel() {
		return orderdisplaybtncancel;
	}

	public QAFWebElement getBtnDelete() {
		return orderdisplaybtndelete;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}

}
