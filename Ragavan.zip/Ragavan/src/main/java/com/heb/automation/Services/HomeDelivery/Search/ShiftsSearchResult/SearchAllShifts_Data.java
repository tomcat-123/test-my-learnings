package com.heb.automation.Services.HomeDelivery.Search.ShiftsSearchResult;

import java.util.ArrayList;

public class SearchAllShifts_Data {

	private ArrayList<SearchAllShifts_Data_Content> content;

    private ArrayList<SearchAllShifts_Data_Sort> sort;

    private String numberOfElements;

    private String last;

    private String totalElements;

    private String number;

    private String first;

    private String totalPages;

    private String size;

    public ArrayList<SearchAllShifts_Data_Content> getContent ()
    {
        return content;
    }

    public void setContent (ArrayList<SearchAllShifts_Data_Content> content)
    {
        this.content = content;
    }

    public ArrayList<SearchAllShifts_Data_Sort> getSort ()
    {
        return sort;
    }

    public void setSort (ArrayList<SearchAllShifts_Data_Sort> sort)
    {
        this.sort = sort;
    }

    public String getNumberOfElements ()
    {
        return numberOfElements;
    }

    public void setNumberOfElements (String numberOfElements)
    {
        this.numberOfElements = numberOfElements;
    }

    public String getLast ()
    {
        return last;
    }

    public void setLast (String last)
    {
        this.last = last;
    }

    public String getTotalElements ()
    {
        return totalElements;
    }

    public void setTotalElements (String totalElements)
    {
        this.totalElements = totalElements;
    }

    public String getNumber ()
    {
        return number;
    }

    public void setNumber (String number)
    {
        this.number = number;
    }

    public String getFirst ()
    {
        return first;
    }

    public void setFirst (String first)
    {
        this.first = first;
    }

    public String getTotalPages ()
    {
        return totalPages;
    }

    public void setTotalPages (String totalPages)
    {
        this.totalPages = totalPages;
    }

    public String getSize ()
    {
        return size;
    }

    public void setSize (String size)
    {
        this.size = size;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [content = "+content+", sort = "+sort+", numberOfElements = "+numberOfElements+", last = "+last+", totalElements = "+totalElements+", number = "+number+", first = "+first+", totalPages = "+totalPages+", size = "+size+"]";
    }
}
