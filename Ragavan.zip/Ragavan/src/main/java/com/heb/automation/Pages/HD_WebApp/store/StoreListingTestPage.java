package com.heb.automation.Pages.HD_WebApp.store;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class StoreListingTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator="storelisting.lbl.title")
	private QAFWebElement storelistinglbltitle;
	
	@FindBy(locator="storelisting.btn.storscrump")
	private QAFWebElement storelistingbtnstorscrump;
	
	@FindBy(locator="storelisting.lbl.totalrecords")
	private QAFWebElement storelistinglbltotalrecords;
	
	@FindBy(locator="storelisting.lbl.displayrecords")
	private QAFWebElement storelistinglbldisplayrecords;
		
	public QAFWebElement getStorelistingbtnstorscrump() {
		return storelistingbtnstorscrump;
	}

	public QAFWebElement getStorelistinglbltotalrecords() {
		return storelistinglbltotalrecords;
	}

	public QAFWebElement getStorelistinglbldisplayrecords() {
		return storelistinglbldisplayrecords;
	}

	public QAFWebElement getLblTitle(){
		return storelistinglbltitle;
	}
	
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}

}
