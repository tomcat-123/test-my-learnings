package com.heb.automation.Services.HomeDelivery.Drivers;

public class DriversByProfileID_RootObject
{
    private String apiStatus;

    private DriversByProfileID_Data data;

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

    public DriversByProfileID_Data getData ()
    {
        return data;
    }

    public void setData (DriversByProfileID_Data data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [apiStatus = "+apiStatus+", data = "+data+"]";
    }

}
