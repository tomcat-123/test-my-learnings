package com.heb.automation.common.components;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static org.testng.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.perfecto.reportium.client.ReportiumClient;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

import io.appium.java_client.AppiumDriver;

public class PerfectoUtils implements JavascriptExecutor {

	public static QAFExtendedWebDriver getDriver() {
		return new WebDriverTestBase().getDriver();
	}

/*	///////////////////////////////////////////////////////////*
	Need to add code for 
	- mouseover
	- Action related functionalities 
	*//////////////////
	
	public static final String PERFECTO_REPORT_CLIENT = "perfecto.report.client";
	private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	private static final String ALPHA_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

	// Constants for timing in Mili seconds
	public static final int MAX_WAIT_TIME = 10000;
	private static final int SLEEP_TIME = 3000;
	private int headerOffset = 0;

	//Actions action = new Actions(getDriver());

	public static void ReportMessage(String msg, MessageTypes result) {

		ReportiumClient reportClient = (ReportiumClient) getBundle().getObject(PERFECTO_REPORT_CLIENT);
		boolean asrtResult = false;

		if (result.equals(MessageTypes.Pass) || result.equals(MessageTypes.TestStepPass)) {
			asrtResult = true;
		} else if (result.equals(MessageTypes.Fail) || result.equals(MessageTypes.TestStepFail)) {
			asrtResult = false;
		} else if (result.equals(MessageTypes.Info) || result.equals(MessageTypes.TestStep)
				|| result.equals(MessageTypes.Warn)) {
			asrtResult = true;
		}

		//reportClient.reportiumAssert(msg, asrtResult);
		Reporter.log(msg, result);
		assertTrue(asrtResult, msg);

	}
	
	public static void ReportMessage(String msg) {
		ReportMessage(msg, MessageTypes.Info);
	}

	/**
	 * Perfecto- Scrolls to specified element.
	 * 
	 * @param element
	 *            Element to scroll to
	 */
	public static void scrolltoelement(QAFWebElement qafelement) {

		try {
			qafelement.waitForPresent(MAX_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor) PerfectoUtils.getDriver();
			js.executeScript("arguments[0].scrollIntoView(true);", qafelement);

		} catch (Exception e) {
			PerfectoUtils.ReportMessage("Error occured while scrolling to the elemenet.");
			e.printStackTrace();
		}

	}

	public static void mouseover(QAFWebElement moveToElement) {
		// Java Script
		try {
			String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
			JavascriptExecutor js = (JavascriptExecutor) getDriver();
			WebElement element = (WebElement) moveToElement;
			js.executeScript(mouseOverScript, element);
		} catch (Exception e) {
		
			// #### Actions need to be relooked 
			
		/*	Actions action = new Actions(PerfectoUtils.getDriver());
			action.moveToElement(moveToElement).build().perform();
		*/
			}

	}

	
	public static void pressKeyboardSearch() {

		Map<String, Object> param1 = new HashMap<>();
		param1.put("keySequence", "KEYBOARD_SEARCH");
		PerfectoUtils.getAppiumDriver().executeScript("mobile:presskey", param1);
	}
	
	public static void pressKeyboardGo() {

		Map<String, Object> param1 = new HashMap<>();
		param1.put("keySequence", "KEYBOARD_GO");
		PerfectoUtils.getAppiumDriver().executeScript("mobile:presskey", param1);
	}
	
	public static void pressKeyboardDone() {

		Map<String, Object> param1 = new HashMap<>();
		param1.put("keySequence", "KEYBOARD_DONE");
		PerfectoUtils.getAppiumDriver().executeScript("mobile:presskey", param1);
	}


	public static void keyboad_backbutton_delete() {
		Map<String, Object> params1 = new HashMap<>();
		params1.put("label", "DEL");
		Object result1 = getDriver().executeScript("mobile:button-text:click", params1);
	}
	
	public static void zoomIn() {

		Map<String, Object> params = new HashMap<>();
		params.put("start", "20%,40%");
		params.put("end", "15%,60%");
		params.put("operation", "zoom");
		params.put("duration", "3");
		getDriver().executeScript("mobile:touch:gesture", params);
	}

	public static void zoomOut() {

		Map<String, Object> params = new HashMap<>();
		params.put("start", "15%,60%");
		params.put("end", "20%,40%");
		params.put("operation", "Pinch");
		params.put("duration", "3");
		getDriver().executeScript("mobile:touch:gesture", params);
	}
	
	public static void mousehoverusingActions(WebElement moveElement) {
		/*Actions action = new Actions(PerfectoUtils.getDriver());
		action.moveToElement(moveElement).build().perform();*/
	}

	public static void mouseoverandclick(QAFWebElement moveAndClickElement) {
		// Java Script
		String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		WebElement element = (WebElement) moveAndClickElement;
		js.executeScript(mouseOverScript, element);
		moveAndClickElement.click();

	}

	public static void mouseoverandclick(QAFWebElement moveElement, QAFWebElement clickElement) {

	}

	public static String removeSpecialCharacters(String value) {

		StringBuilder myNumbers = new StringBuilder();
		for (int i = 0; i < value.length(); i++) {
			if (Character.isDigit(value.charAt(i))) {
				myNumbers.append(value.charAt(i));
			} else if (Character.isLetter(value.charAt(i))) {
				myNumbers.append(value.charAt(i));
			} else {
				System.out.println(value.charAt(i) + " not a digit or Character.");
			}
		}
		return myNumbers.toString();

	}

	public static String getIntCharacters(String value) {

		StringBuilder myNumbers = new StringBuilder();
		for (int i = 0; i < value.length(); i++) {
			if (Character.isDigit(value.charAt(i))) {
				myNumbers.append(value.charAt(i));
			}
		}
		return myNumbers.toString();

	}

	public static String getOnlyChars(String value) {

		StringBuilder myNumbers = new StringBuilder();
		for (int i = 0; i < value.length(); i++) {
			if (Character.isLetter(value.charAt(i))) {
				myNumbers.append(value.charAt(i));
			} else {
				System.out.println(value.charAt(i) + " not a digit or Character.");
			}
		}
		return myNumbers.toString();
	}

	@Override
	public Object executeScript(String script, Object... args) {
		JavascriptExecutor js = (JavascriptExecutor) PerfectoUtils.getDriver();
		js.executeScript(script, args);
		return null;
	}

	@Override
	public Object executeAsyncScript(String script, Object... args) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void setMockLocation(String latitude, String longitude) {
		getDriver().executeScript(
				"window.navigator.geolocation.getCurrentPosition = function(success){var position = {'coords' : {'latitude': '"
						+ latitude + "','longitude': '" + longitude + "'}};success(position);}");
	}

	/**
	 * Sends specified credentials to web element given. Clears out any old
	 * values before sending new values to the area
	 * 
	 * @param elementName
	 *            Web element (button, label) to be entered into field
	 * @param elementValue
	 *            Value to enter
	 */
	public void enterValues(QAFWebElement elementName, String elementValue) {

		elementName.waitForPresent(MAX_WAIT_TIME);
		elementName.sendKeys(elementValue);
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Sends specified credentials to web element given. Clears out any old
	 * values before sending new values to the area, and then sends the enter
	 * key
	 * 
	 * @param elementName
	 *            Web element (button, label) to be entered into field
	 * @param elementValue
	 *            Value to enter
	 */
	public void enterValueAndSendEnter(QAFWebElement elementName, String elementValue) {
		elementName.click();
		elementName.sendKeys(elementValue);

		getDriver().getKeyboard().pressKey(Keys.ENTER);
	}

	public void moveToElement(QAFWebElement element) {
	
	}

	/**
	 * Scrolls to specified element and clicks on it. Will sleep for half the
	 * time of SLEEP_TIME.
	 * 
	 * @param element
	 *            Element to scroll to
	 */
	public void scrollAndClick(QAFWebElement element) {

		element.waitForPresent(MAX_WAIT_TIME);
		PerfectoUtils.scrolltoelement(element);
		element.waitForVisible(MAX_WAIT_TIME);
		element.click();
	}

	/**
	 * Scrolls to specified element and clicks on it. Will sleep for half the
	 * time of SLEEP_TIME.
	 * 
	 * @param element
	 *            Element to scroll to
	 */
	public static void doubleClick(QAFWebElement element) {

		element.waitForPresent(MAX_WAIT_TIME);
		element.click();
		element.waitForPresent(MAX_WAIT_TIME);
		element.click();
	}

	/**
	 * Adds items to the cart
	 * 
	 * @param elementTo
	 *            Button for the elementTo.click()
	 * @param clickAmount
	 *            Amount of clicks requested
	 */
	public int multiClick(QAFWebElement elementTo, int clickAmount) {
		int totalAdded = 0;
		for (int i = 0; i < clickAmount; i++) {
			elementTo.click();
			totalAdded += 1;
		}
		return totalAdded;
	}

	/**
	 * If passed a select box web element, can scroll through and select the
	 * given item based on the string. So, if given a State selection box with
	 * the String "Texas," it will go through the options until the greatest
	 * state in the union is selected
	 * 
	 * @param menu
	 *            Menu box to scroll through
	 * @param clickMe
	 *            Item to select
	 */
	public static void selectBoxSelection(QAFWebElement menu, String clickMe) {
		PerfectoUtils.mouseover(menu);

		menu.click();
		Select clickThis = new Select(menu);
		clickThis.selectByVisibleText(clickMe);
	}

	public static void waitAngularHasFinishedProcessing() {
		WebDriverWait wait = new WebDriverWait(getDriver(), 35, 100);
		wait.until(angularHasFinishedProcessing());

	}
	
	public static AppiumDriver<?> getAppiumDriver() {
		return (AppiumDriver<?>) new WebDriverTestBase().getDriver().getUnderLayingDriver();
	}

	public static ExpectedCondition<Boolean> angularHasFinishedProcessing() {
		return new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				return Boolean.valueOf(((JavascriptExecutor) driver)
						.executeScript(
								"return (window.angular !== undefined) && (angular.element(document).injector() !== undefined) && (angular.element(document).injector().get('$http').pendingRequests.length === 0)")
						.toString());
			}
		};
	}
	
	public static void reportMessage(String msg, MessageTypes result) {

		ReportiumClient reportClient = (ReportiumClient) getBundle().getObject(PERFECTO_REPORT_CLIENT);
		boolean asrtResult = false;

		if (result.equals(MessageTypes.Pass) || result.equals(MessageTypes.TestStepPass)) {
			asrtResult = true;
		} else if (result.equals(MessageTypes.Fail) || result.equals(MessageTypes.TestStepFail)) {
			asrtResult = false;
		} else if (result.equals(MessageTypes.Info) || result.equals(MessageTypes.TestStep)
				|| result.equals(MessageTypes.Warn)) {
			asrtResult = true;
		}

		System.out.println(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        System.out.println(msg +" Result :   "+result);
        System.out.println(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
		
		reportClient.reportiumAssert(msg, asrtResult);
		Reporter.log(msg, result);
		assertTrue(asrtResult, msg);

	}

	public static void reportMessage(String msg) {
		reportMessage(msg, MessageTypes.Info);

	}
	
	public static String getTxt(String id){
		JavascriptExecutor javascriptExecutor = (JavascriptExecutor) PerfectoUtils.getDriver();
		String value =javascriptExecutor.executeScript("return documenet.getElementById('" + id +"').value;").toString();
		return value;
	}
	
	public static String randomAlphaNumeric(int count) {
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int)(Math.random()*ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}
	
	public static String randomAlphabets(int count) {
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int)(Math.random()*ALPHA_STRING.length());
			builder.append(ALPHA_STRING.charAt(character));
		}
		return builder.toString();
	}
	
	public static void JavaScriptClick(QAFWebElement Element) {
        JavascriptExecutor javascriptexe = (JavascriptExecutor)PerfectoUtils.getDriver();
        javascriptexe.executeScript("arguments[0].click()", Element);
 }
	
	public static void JavaScriptConfirm() {
        JavascriptExecutor javascriptexe = (JavascriptExecutor)PerfectoUtils.getDriver();
        javascriptexe.executeScript("window.confirm = function(msg){return true;};");
 }
}
