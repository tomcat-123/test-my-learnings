package com.heb.automation.common;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.TreeMap;



public class CommonDBUtils


{/** This class contains a generic code for data manipulation */

    public TreeMap<Integer,HashMap<String,String>> 
    selectQuery(Connection conn, String selectQuery) 
    { /** This is a generic method for the select operation */

        TreeMap<Integer,HashMap<String,String>> selectResult = 
                                    new TreeMap<Integer,HashMap<String,String>>();
               try {
            PreparedStatement stmt = conn.prepareStatement(selectQuery);
            ResultSet rs = stmt.executeQuery();
            ResultSetMetaData rsmd=rs.getMetaData();
            int rownum=1;
            while (rs.next()) {
                HashMap<String,String> eachResult = new HashMap<String,String>();
                for (int i=1; i<rsmd.getColumnCount()+1; i++) { 
                    eachResult.put(rsmd.getColumnLabel(i),rs.getString(i));              
                } // for
                selectResult.put(rownum,eachResult);
                rownum=rownum+1;
            } // while

        } catch(SQLException sqlExc) {
            System.out.println(sqlExc.getMessage());
        } // try-catch

        return selectResult;
    } // select()
    
    
    public int updateQuery(Connection conn, String updateQuery)
    { /** This is a generic method that will return the count of modified rows for the update or insert operation */

    		int updateResult = 0;
               try {
            PreparedStatement stmt = conn.prepareStatement(updateQuery);
            updateResult = stmt.executeUpdate();

        } catch(SQLException sqlExc) {
            System.out.println(sqlExc.getMessage());
        } // try-catch

        return updateResult;
    } // update()
    
    
    public Connection getConnection() throws SQLException {    
    /* TODO: fill this in
     The instance connection name can be obtained from the instance overview page in Cloud Console
     or by running "gcloud sql instances describe <instance> | grep connectionName".  
	 String instanceConnectionName = "heb-mls-qa1:us-central1:homedeliveryqadb";
     TODO: fill this in
     The database from which to list tables.
    */
    	
    String databaseName = "prontosql";
    String username = "pronto_qa_test";
    // TODO: fill this in
    // This is the password that was set via the Cloud Console or empty if never set
    // (not recommended).
    String password = "l|Kk@TkwM|m89#mY!sZP";  
    String jdbcUrl = "jdbc:mysql://35.224.198.126:3306/"+databaseName;
    Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
    return connection;
    }
    
    public void closeConnection(Connection con)
    {
    try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
    }

} // class CommonDBConnection