package com.heb.automation.Services.HomeDelivery.Teams;

public class Teams_Data {
	
	private String id;

    private String[] managers;

    private String name;

    private String timeCreated;

    private String[] tasks;

    private String hub;

    private String[] workers;

    private String timeLastModified;

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String[] getManagers ()
    {
        return managers;
    }

    public void setManagers (String[] managers)
    {
        this.managers = managers;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getTimeCreated ()
    {
        return timeCreated;
    }

    public void setTimeCreated (String timeCreated)
    {
        this.timeCreated = timeCreated;
    }

    public String[] getTasks ()
    {
        return tasks;
    }

    public void setTasks (String[] tasks)
    {
        this.tasks = tasks;
    }

    public String getHub ()
    {
        return hub;
    }

    public void setHub (String hub)
    {
        this.hub = hub;
    }

    public String[] getWorkers ()
    {
        return workers;
    }

    public void setWorkers (String[] workers)
    {
        this.workers = workers;
    }

    public String getTimeLastModified ()
    {
        return timeLastModified;
    }

    public void setTimeLastModified (String timeLastModified)
    {
        this.timeLastModified = timeLastModified;
    }

}
