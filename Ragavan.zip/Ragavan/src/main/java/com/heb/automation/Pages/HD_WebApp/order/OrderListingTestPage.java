package com.heb.automation.Pages.HD_WebApp.order;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;

public class OrderListingTestPage extends WebDriverBaseTestPage<WebDriverTestPage>{

	@FindBy (locator="orderlisting.lbl.title")
	private QAFWebElement orderlistinglbltitle;
	
	@FindBy (locator="orderlisting.btn.orderlistingcrump")
	private QAFWebElement orderlistingbtnorderlistingcrump;
	
	@FindBy (locator="orderlisting.lbl.orderid")
	private QAFWebElement orderlistinglblorderid;
	
	@FindBy (locator="orderlisting.lbl.customerfirstname")
	private QAFWebElement orderlistinglblcustomerfirstname;
	
	@FindBy (locator="orderlisting.lbl.customerlastname")
	private QAFWebElement orderlistinglblcustomerlastname;
	
	@FindBy (locator="orderlisting.lbl.storename")
	private QAFWebElement orderlistinglblstorename;
	
	@FindBy (locator="orderlisting.lbl.deliverydate")
	private QAFWebElement orderlistinglbldeliverydate;
	
	@FindBy (locator="orderlisting.lbl.orderstatus")
	private QAFWebElement orderlistinglblorderstatus;
	
	@FindBy (locator="orderlisting.txt.orderid")
	private QAFWebElement orderlistingtxtorderid;
	
	@FindBy (locator="orderlisting.txt.customerfirstname")
	private QAFWebElement orderlistingtxtcustomerfirstname;
	
	@FindBy (locator="orderlisting.txt.customerlastname")
	private QAFWebElement orderlistingtxtcustomerlastname;
	
	@FindBy (locator="orderlisting.txt.storename")
	private QAFWebElement orderlistingtxtstorename;
	
	@FindBy (locator="orderlisting.txt.deliverydate")
	private QAFWebElement orderlistingtxtdeliverydate;
	
	@FindBy (locator="orderlisting.txt.OrderStatus")
	private QAFWebElement orderlistingtxtOrderStatus;
	
	@FindBy (locator="orderlisting.btn.createorderdelivery")
	private QAFWebElement orderlistingbtncreateorderdelivery;
	
	@FindBy (locator="orderlisting.btn.search")
	private QAFWebElement orderlistingbtnsearch;
	
	@FindBy (locator="orderlisting.btn.reset")
	private QAFWebElement orderlistingbtnreset;
	
	@FindBy (locator="orderlisting.lbl.fieldsrequired")
	private QAFWebElement orderlistinglblfieldsrequired;
	
	@FindBy (locator="orderlisting.lbl.totalrecords")
	private QAFWebElement orderlistinglbltotalrecords;
	
	@FindBy (locator="orderlisting.lbl.displayingrecords")
	private QAFWebElement orderlistinglbldisplayingrecords;
	
	@FindBy (locator="orderlisting.dropdown.orderstatus")
	private QAFWebElement orderlistingdropdownorderstatus;
	
	@FindBy (locator="orderlisting.lbl.orderstausdropdownlist")
	private List<QAFWebElement> orderlistinglblorderstausdropdownlist;
	
	@FindBy (locator="orderlisting.btn.calendar")
	private QAFWebElement orderlistingbtncalendar;
	
	@FindBy (locator="orderlisting.lbl.calendartable")
	private QAFWebElement orderlistinglblcalendartable;
	
	@FindBy (locator="orderlisting.lnk.store")
	private QAFWebElement orderlistinglnlstore;

	
	public QAFWebElement getLnkStore() {
		return orderlistinglnlstore;
	}
	
	public QAFWebElement getLblCalendarTable() {
		return orderlistinglblcalendartable;
	}
	
	public QAFWebElement getBtnCalendar() {
		return orderlistingbtncalendar;
	}
	
	public List<QAFWebElement> getLblOrderStausDropdownList() {
		return orderlistinglblorderstausdropdownlist;
	}
	
	public QAFWebElement getDropDownOrderStatus() {
		return orderlistingdropdownorderstatus;
	}
	
	public QAFWebElement getLblTitle() {
		return orderlistinglbltitle;
	}

	public QAFWebElement getBtnorderlistingcrump() {
		return orderlistingbtnorderlistingcrump;
	}

	public QAFWebElement getLblOrderId() {
		return orderlistinglblorderid;
	}

	public QAFWebElement getLblCustomerFirstName() {
		return orderlistinglblcustomerfirstname;
	}

	public QAFWebElement getLblCustomerLastName() {
		return orderlistinglblcustomerlastname;
	}

	public QAFWebElement getLblStoreName() {
		return orderlistinglblstorename;
	}

	public QAFWebElement getLblDeliveryDate() {
		return orderlistinglbldeliverydate;
	}

	public QAFWebElement getLblOrderStatus() {
		return orderlistinglblorderstatus;
	}

	public QAFWebElement getTxtOrderid() {
		return orderlistingtxtorderid;
	}

	public QAFWebElement getTxtCustomerFirstName() {
		return orderlistingtxtcustomerfirstname;
	}

	public QAFWebElement getTxtCustomerLastName() {
		return orderlistingtxtcustomerlastname;
	}

	public QAFWebElement getTxtStoreName() {
		return orderlistingtxtstorename;
	}

	public QAFWebElement getTxtDeliveryDate() {
		return orderlistingtxtdeliverydate;
	}

	public QAFWebElement getTxtOrderStatus() {
		return orderlistingtxtOrderStatus;
	}

	public QAFWebElement getBtnCreateOrderDelivery() {
		return orderlistingbtncreateorderdelivery;
	}

	public QAFWebElement getBtnSearch() {
		return orderlistingbtnsearch;
	}

	public QAFWebElement getBtnReset() {
		return orderlistingbtnreset;
	}

	public QAFWebElement getLblFieldsRequired() {
		return orderlistinglblfieldsrequired;
	}

	public QAFWebElement getLblTotalRecords() {
		return orderlistinglbltotalrecords;
	}

	public QAFWebElement getLblDisplayingRecords() {
		return orderlistinglbldisplayingrecords;
	}
	
	public QAFWebElement getLnkOrderStatus(String orderStatus) {

		String loc = String.format(pageProps.getString("orderlisting.lnk.OrderStatus"), orderStatus);
		return new QAFExtendedWebElement(loc);
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void waitForPageToLoad() {
		// TODO Auto-generated method stub
		
		super.waitForPageToLoad();
	}

}
