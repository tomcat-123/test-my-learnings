package com.heb.automation.Steps.HD_WebApp.order;

import static com.heb.automation.common.components.PerfectoUtils.MAX_WAIT_TIME;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.heb.automation.Pages.HD_WebApp.order.OrderDisplayTestPage;
import com.heb.automation.Pages.HD_WebApp.order.OrderEditTestPage;
import com.heb.automation.Pages.HD_WebApp.order.OrderListingTestPage;
import com.heb.automation.Pages.HD_WebApp.searchresult.OrderSearchResultpage;
import com.heb.automation.Pages.HD_WebApp.searchresult.SearchResultPage;
import com.heb.automation.Steps.HD_WebApp.HD_WebAppCommonStepdef;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class OrderEdit_WebAppStepdef extends TestDataContainer {

	@QAFTestStep(description = "User clicks on first order in the list")
	public void userClicksOnFirstOrderinthelist() {
		SearchResultPage sResult = new SearchResultPage();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();

		int Rowcount = 1;
		orderSearch.getOrderIdresult(Rowcount).waitForPresent(MAX_WAIT_TIME);
		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		if (rowcount > 0) {
			String selectedOrderID = orderSearch.getLnkOrderId(Rowcount).getText();
			orderSearch.getLnkOrderId(Rowcount).click();
			putTestObject("SelectedOrderID", selectedOrderID);
			PerfectoUtils.reportMessage("User clicked first order " + selectedOrderID + " in the list",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Order List is empty", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "User Edit all the editable fields")
	public void userEditalltheeditablefields() {
		OrderEditTestPage edit = new OrderEditTestPage();
		OrderDisplayTestPage order = new OrderDisplayTestPage();

		PerfectoUtils.scrolltoelement(order.getBtnEdit());
		order.getBtnEdit().click();
		PerfectoUtils.reportMessage("User clicked Edit button", MessageTypes.Info);
		PerfectoUtils.reportMessage("Before Edit", MessageTypes.Pass);
		edit.getTxtDeliveryStart().waitForPresent(MAX_WAIT_TIME);
		Calendar cal = Calendar.getInstance();
		String dateFormated = new SimpleDateFormat("M/dd/yyyy").format(cal.getTime()) + " 12:00 AM";
		String dateFormatedEnd = new SimpleDateFormat("M/dd/yyyy").format(cal.getTime()) + " 11:59 PM";
		putTestObject("DeliveryStartBeforeEdit",edit.getTxtDeliveryStart().getText());
		
		edit.getTxtDeliveryStart().sendKeys(dateFormated);
		System.out.println(dateFormated);
		putTestObject("DeliveryStart", dateFormated);
		putTestObject("DeliveryEndBeforeEdit",edit.getTxtDeliveryEnd().getText());
		edit.getTxtDeliveryEnd().sendKeys(dateFormatedEnd);
		putTestObject("DeliveryEnd", dateFormatedEnd);
		System.out.println(dateFormatedEnd);
		putTestObject("OrderStatusBeforeEdit",edit.getTxtOrderStatus().getText());
		edit.getTxtOrderStatus()
				.sendKeys(getTestString("HomeDelivery.orderstatus.inprocess"));
		System.out.println(getTestString("HomeDelivery.orderstatus.inprocess"));
		putTestObject("AdminNotesBeforeEdit",edit.getTxtAdminNotes().getText());
		String adminNotes = PerfectoUtils.randomAlphaNumeric(20);
		edit.getTxtAdminNotes().sendKeys(adminNotes);
		System.out.println(adminNotes);
		putTestObject("AdminNotes", adminNotes);
		putTestObject("OrderNotesBeforeEdit",edit.getTxtOrderNotes().getText());
		String orderNotes = PerfectoUtils.randomAlphaNumeric(20);
		edit.getTxtOrderNotes().sendKeys(orderNotes);
		putTestObject("OrderNotes", orderNotes);
		System.out.println(orderNotes);
		if (edit.getLblSignatureRequiredCurrentValue().getAttribute("value").equals("Yes")) {
			edit.getBtnNoSignatureRequired().click();
			putTestObject("SignatureRequired", "No");
		} else {
			edit.getbtnyessignaturerequired().click();
			putTestObject("SignatureRequired", "Yes");
		}

		if (edit.getLblHasAlcoholCurrentValue().getAttribute("value").equals("Yes")) {
			edit.getBtnNoHasAlcohol().click();
			putTestObject("HasAlcohol", "No");
		} else {
			edit.getBtnYesHasAlcohol().click();
			putTestObject("HasAlcohol", "Yes");
		}
		PerfectoUtils.reportMessage("After Edit", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify Edit and Delete buttons are not available")
	public void verifyEditandDeletebuttonsarenotavailable() {
		OrderDisplayTestPage order = new OrderDisplayTestPage();

		order.getBtnEdit().verifyNotPresent();
		order.getBtnDelete().verifyNotPresent();
	}

	@QAFTestStep(description = "Verify user is able to update order details successfully and order displays updated details")
	public void verifyUserisabletoupdateorderdetailssuccessfullyandorderdisplaysupdateddetails()
			throws InterruptedException {
		OrderEditTestPage edit = new OrderEditTestPage();
		OrderListingTestPage order = new OrderListingTestPage();
		HD_WebAppCommonStepdef searchorderid = new HD_WebAppCommonStepdef();
		OrderSearchResultpage orderSearch = new OrderSearchResultpage();
		Order_WebAppStepdef orderstep = new Order_WebAppStepdef();

		PerfectoUtils.scrolltoelement(edit.getBtnSave());
		edit.getBtnSave().click();
		PerfectoUtils.reportMessage("Save Button Clicked", MessageTypes.Info);
		order.waitForPageToLoad();
		order.getTxtOrderid().waitForVisible(MAX_WAIT_TIME * 2);
		String OrderIdCreated = getTestString("SelectedOrderID");
		String orderStatusUpdated = getTestString("HomeDelivery.orderstatus.inprocess");
		String deliveryStartUpdated = getTestString("DeliveryStart");
		String deliveryEndUpdated = getTestString("DeliveryEnd");
		String adminNotesUpdated = getTestString("AdminNotes");
		String orderNotesUpdated = getTestString("OrderNotes");
		String signatureRequiredUpdated = getTestString("SignatureRequired");
		String hasAlcoholUpdated = getTestString("HasAlcohol");
		order.getTxtOrderid().sendKeys(OrderIdCreated);
		searchorderid.iClickSearchButton();
		PerfectoUtils.reportMessage("Navigated to Order Listing page after Save. Searched with edited Order ID",
				MessageTypes.Pass);
		String OrderIdListPage = orderstep.verifytheNewOrderIdOrderListPage();
		if (OrderIdCreated.equals(OrderIdListPage)) {
			String actualOrderStatus = orderSearch.getLnkOrderStatus(1).getText();
			if (actualOrderStatus.equals(orderStatusUpdated)) {
				PerfectoUtils.reportMessage("Order Status updated successfully", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage(
						"Order Status not updated. Actual: " + actualOrderStatus + " Expected: " + orderStatusUpdated,
						MessageTypes.Fail);
			}
			orderSearch.getLnkOrderId(1).click();
			String updatedDeliveryStartDate = edit.getTxtDeliveryStart().getText();
			String updatedDeliveryEndDate = edit.getTxtDeliveryEnd().getText();
			String updatedOrderStatus = edit.getTxtOrderStatus().getText();
			String updatedAdminNotes = edit.getTxtAdminNotes().getText();
			String updatedOrderNotes = edit.getTxtOrderNotes().getText();
			String updatedSignatureRequired = edit.getLblSignatureRequiredCurrentValue().getAttribute("value");
			String updatedHasAlcohol = edit.getLblHasAlcoholCurrentValue().getAttribute("value");

			if (deliveryStartUpdated.equals(updatedDeliveryStartDate)
					&& deliveryEndUpdated.equals(updatedDeliveryEndDate) && adminNotesUpdated.equals(updatedAdminNotes)
					&& orderNotesUpdated.equals(updatedOrderNotes) && orderStatusUpdated.equals(updatedOrderStatus)
					&& signatureRequiredUpdated.equals(updatedSignatureRequired) && hasAlcoholUpdated.equals(updatedHasAlcohol)) {
				PerfectoUtils.reportMessage("Order details updated successfully", MessageTypes.Pass);
			}else{
				PerfectoUtils.reportMessage("Order details not updated correctly", MessageTypes.Fail);
			}

		} else {
			PerfectoUtils.reportMessage("OrderId is not Matched-OrderId in Order List Page: " + OrderIdListPage
					+ ", Edited OrderId: " + OrderIdCreated, MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify Cancel doesn't save changes performed in edit mode")
	public void verifyCanceldoesntsavechangesperformedineditmode() {
		OrderEditTestPage edit = new OrderEditTestPage();

		PerfectoUtils.scrolltoelement(edit.getBtnCancel());
		edit.getBtnCancel().click();
		PerfectoUtils.reportMessage("Clicked Cancel Button", MessageTypes.Info);
		edit.getTxtDeliveryStart().getAttribute("value");
		if (edit.getTxtDeliveryStart().getText()
				.equals(getTestString("DeliveryStartBeforeEdit"))) {
			PerfectoUtils.reportMessage("Delivery Start is not updated", MessageTypes.Pass);
		} 
		else if(checkIfEmptyOrNull(edit.getTxtDeliveryStart().getText(), getTestString("DeliveryStartBeforeEdit"))){
			PerfectoUtils.reportMessage("Delivery Start is not updated", MessageTypes.Pass);
		}
		else {
			PerfectoUtils.reportMessage("Delivery Start is updated", MessageTypes.Fail);
		}

		if (edit.getTxtDeliveryEnd().getText()
				.equals(getTestString("DeliveryEndBeforeEdit"))) {
			PerfectoUtils.reportMessage("Delivery End is not updated", MessageTypes.Pass);
		} 
		else if(checkIfEmptyOrNull(edit.getTxtDeliveryEnd().getText(), getTestString("DeliveryEndBeforeEdit"))){
			PerfectoUtils.reportMessage("Delivery Start is not updated", MessageTypes.Pass);
		}
		
		else {
			PerfectoUtils.reportMessage("Delivery End is updated", MessageTypes.Fail);
		}

		if (edit.getTxtOrderStatus().getText()
				.equals(getTestString("OrderStatusBeforeEdit"))) {
			PerfectoUtils.reportMessage("Order Status is not updated", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Order Status is updated", MessageTypes.Fail);
		}

		if (edit.getTxtAdminNotes().getText()
				.equals(getTestString("AdminNotesBeforeEdit"))) {
			PerfectoUtils.reportMessage("Admin Notes is not updated", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Admin Notes is updated", MessageTypes.Fail);
		}

		if (edit.getTxtOrderNotes().getText()
				.equals(getTestString("OrderNotesBeforeEdit"))) {
			PerfectoUtils.reportMessage("Order Notes is not updated", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Order Notes is updated", MessageTypes.Fail);
		}

		if (getTestString("SignatureRequired").equals("Yes")) {
			if (edit.getLblSignatureRequiredCurrentValue().getAttribute("value").equals("No")) {
				PerfectoUtils.reportMessage("SignatureRequired is not updated", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("SignatureRequired is updated", MessageTypes.Fail);
			}
		} else {
			if (edit.getLblSignatureRequiredCurrentValue().getAttribute("value").equals("Yes")) {
				PerfectoUtils.reportMessage("SignatureRequired is not updated", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("SignatureRequired is updated", MessageTypes.Fail);
			}
		}

		if (getTestString("HasAlcohol").equals("Yes")) {
			if (edit.getLblHasAlcoholCurrentValue().getAttribute("value").equals("No")) {
				PerfectoUtils.reportMessage("HasAlcohol is not updated", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("HasAlcohol is updated", MessageTypes.Fail);
			}
		} else {
			if (edit.getLblHasAlcoholCurrentValue().getAttribute("value").equals("Yes")) {
				PerfectoUtils.reportMessage("HasAlcohol is not updated", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("HasAlcohol is updated", MessageTypes.Fail);
			}
		}

	}
	
	static boolean checkIfEmptyOrNull(String s1, String s2) {
	     //check for empty and null
		boolean flag=false;
		if((s1.equals(null) && s2.equals(null)||s2.toString().equals("")) || (s2.equals(null) || s1.equals(""))){
			flag=true;
		}
		return flag;
	
	}
}
