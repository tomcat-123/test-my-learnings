package com.heb.automation.Services.HomeDelivery.Search.ShiftsSearchResult;

import java.util.ArrayList;

public class SearchShiftPlanner_Root {
	
	private String apiStatus;

    private ArrayList<SearchShiftPlanner_Data> data;

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

    public ArrayList<SearchShiftPlanner_Data> getData ()
    {
        return data;
    }

    public void setData (ArrayList<SearchShiftPlanner_Data> data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [apiStatus = "+apiStatus+", data = "+data+"]";
    }

}
