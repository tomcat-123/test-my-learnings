package com.heb.automation.Services.BodyParameter.Order.PUT_Order;

public class Order_PUT_Notes {
	 private ProntoOrder prontoOrder = new ProntoOrder();

	    private String noteId;

	    private String type;

	    private String note;

	    public ProntoOrder getProntoOrder ()
	    {
	        return prontoOrder;
	    }

	    public void setProntoOrder (ProntoOrder prontoOrder)
	    {
	        this.prontoOrder = prontoOrder;
	    }

	    public String getNoteId ()
	    {
	        return noteId;
	    }

	    public void setNoteId (String noteId)
	    {
	        this.noteId = noteId;
	    }

	    public String getType ()
	    {
	        return type;
	    }

	    public void setType (String type)
	    {
	        this.type = type;
	    }

	    public String getNote ()
	    {
	        return note;
	    }

	    public void setNote (String note)
	    {
	        this.note = note;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [prontoOrder = "+prontoOrder+", noteId = "+noteId+", type = "+type+", note = "+note+"]";
	    }
}
