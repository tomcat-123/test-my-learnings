package com.heb.automation.Services.HomeDelivery.Shifts;

import java.util.ArrayList;

public class Shifts_Data {
	
	private String shiftCapacity;

    private String id;

    private String lastModifiedTimestamp;

    private String archived;

    private String endWindowDateTime;

    private ArrayList<ShiftAssignments> shiftAssignments;

    private ArrayList<AssignedDrivers> assignedDrivers;

    private String publishDateTime;

    private String published;

    private DataZone zone;

    private String startWindowDateTime;

    private String startOfWeek;

    public String getShiftCapacity ()
    {
        return shiftCapacity;
    }

    public void setShiftCapacity (String shiftCapacity)
    {
        this.shiftCapacity = shiftCapacity;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getLastModifiedTimestamp ()
    {
        return lastModifiedTimestamp;
    }

    public void setLastModifiedTimestamp (String lastModifiedTimestamp)
    {
        this.lastModifiedTimestamp = lastModifiedTimestamp;
    }

    public String getArchived ()
    {
        return archived;
    }

    public void setArchived (String archived)
    {
        this.archived = archived;
    }

    public String getEndWindowDateTime ()
    {
        return endWindowDateTime;
    }

    public void setEndWindowDateTime (String endWindowDateTime)
    {
        this.endWindowDateTime = endWindowDateTime;
    }

    public ArrayList<ShiftAssignments> getShiftAssignments ()
    {
        return shiftAssignments;
    }

    public void setShiftAssignments (ArrayList<ShiftAssignments> shiftAssignments)
    {
        this.shiftAssignments = shiftAssignments;
    }

    public ArrayList<AssignedDrivers> getAssignedDrivers ()
    {
        return assignedDrivers;
    }

    public void setAssignedDrivers (ArrayList<AssignedDrivers> assignedDrivers)
    {
        this.assignedDrivers = assignedDrivers;
    }

    public String getPublishDateTime ()
    {
        return publishDateTime;
    }

    public void setPublishDateTime (String publishDateTime)
    {
        this.publishDateTime = publishDateTime;
    }

    public String getPublished ()
    {
        return published;
    }

    public void setPublished (String published)
    {
        this.published = published;
    }

    public DataZone getZone ()
    {
        return zone;
    }

    public void setZone (DataZone zone)
    {
        this.zone = zone;
    }

    public String getStartWindowDateTime ()
    {
        return startWindowDateTime;
    }

    public void setStartWindowDateTime (String startWindowDateTime)
    {
        this.startWindowDateTime = startWindowDateTime;
    }

    public String getStartOfWeek ()
    {
        return startOfWeek;
    }

    public void setStartOfWeek (String startOfWeek)
    {
        this.startOfWeek = startOfWeek;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [shiftCapacity = "+shiftCapacity+", id = "+id+", lastModifiedTimestamp = "+lastModifiedTimestamp+", archived = "+archived+", endWindowDateTime = "+endWindowDateTime+", shiftAssignments = "+shiftAssignments+", assignedDrivers = "+assignedDrivers+", publishDateTime = "+publishDateTime+", published = "+published+", zone = "+zone+", startWindowDateTime = "+startWindowDateTime+", startOfWeek = "+startOfWeek+"]";
    }

}
