package com.heb.automation.Services.BodyParameter.Drivers;

import java.util.List;

public class Drivers_Body {
	
	private String delayTime;

    private String phone;

    private Vehicles_Body vehicle = new Vehicles_Body();

    private String onDuty;

    private String timeCreated;

    private List<String> tasks;

    private String timeLastSeen;

    private String timeLastModified;

    private String id;

    private List<String> teams;

    private String organization;

    private String name;

    private String activeTask;

    private List<String> metadata;

    public String getDelayTime ()
    {
        return delayTime;
    }

    public void setDelayTime (String delayTime)
    {
        this.delayTime = delayTime;
    }

    public String getPhone ()
    {
        return phone;
    }

    public void setPhone (String phone)
    {
        this.phone = phone;
    }

    public Vehicles_Body getVehicle ()
    {
        return vehicle;
    }

    public void setVehicle (Vehicles_Body vehicle)
    {
        this.vehicle = vehicle;
    }

    public String getOnDuty ()
    {
        return onDuty;
    }

    public void setOnDuty (String onDuty)
    {
        this.onDuty = onDuty;
    }

    public String getTimeCreated ()
    {
        return timeCreated;
    }

    public void setTimeCreated (String timeCreated)
    {
        this.timeCreated = timeCreated;
    }

    public List<String> getTasks ()
    {
        return tasks;
    }

    public void setTasks (List<String> tsk)
    {
        this.tasks = tsk;
    }

    public String getTimeLastSeen ()
    {
        return timeLastSeen;
    }

    public void setTimeLastSeen (String timeLastSeen)
    {
        this.timeLastSeen = timeLastSeen;
    }

    public String getTimeLastModified ()
    {
        return timeLastModified;
    }

    public void setTimeLastModified (String timeLastModified)
    {
        this.timeLastModified = timeLastModified;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public List<String> getTeams ()
    {
        return teams;
    }

    public void setTeams (List<String> team)
    {
        this.teams = team;
    }

    public String getOrganization ()
    {
        return organization;
    }

    public void setOrganization (String organization)
    {
        this.organization = organization;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getActiveTask ()
    {
        return activeTask;
    }

    public void setActiveTask (String activeTask)
    {
        this.activeTask = activeTask;
    }

    public List<String> getMetadata ()
    {
        return metadata;
    }

    public void setMetadata (List<String> mData)
    {
        this.metadata = mData;
    }

}
