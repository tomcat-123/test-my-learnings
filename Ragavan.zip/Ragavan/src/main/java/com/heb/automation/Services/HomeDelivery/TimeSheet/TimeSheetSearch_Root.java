package com.heb.automation.Services.HomeDelivery.TimeSheet;

import java.util.ArrayList;

public class TimeSheetSearch_Root {
	
	private String apiStatus;

    private ArrayList<TimeSheetSearchData> data;

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

    public ArrayList<TimeSheetSearchData> getData ()
    {
        return data;
    }

    public void setData (ArrayList<TimeSheetSearchData> data)
    {
        this.data = data;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [apiStatus = "+apiStatus+", data = "+data+"]";
    }

}
