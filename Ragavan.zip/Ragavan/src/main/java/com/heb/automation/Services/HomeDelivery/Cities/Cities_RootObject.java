package com.heb.automation.Services.HomeDelivery.Cities;

import java.util.ArrayList;

import com.heb.automation.Services.HomeDelivery.Zones.City_Data;

public class Cities_RootObject {
	
	 private String apiStatus;

	    private ArrayList<City_Data> data = new ArrayList<City_Data>();

	    public String getApiStatus ()
	    {
	        return apiStatus;
	    }

	    public void setApiStatus (String apiStatus)
	    {
	        this.apiStatus = apiStatus;
	    }

	    public ArrayList<City_Data> getData ()
	    {
	        return data;
	    }

	    public void setData (ArrayList<City_Data> data)
	    {
	        this.data = data;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [apiStatus = "+apiStatus+", data = "+data+"]";
	    }
}
