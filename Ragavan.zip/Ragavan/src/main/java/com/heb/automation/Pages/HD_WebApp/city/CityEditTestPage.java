package com.heb.automation.Pages.HD_WebApp.city;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CityEditTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	
	@FindBy (locator="cityedit.lbl.title")
	private QAFWebElement cityeditlbltitle;
	
	@FindBy (locator="cityedit.btn.editcitycrumb")
	private QAFWebElement cityeditbtneditcitycrumb;
	
	@FindBy (locator="cityedit.txt.cityname")
	private QAFWebElement cityedittxtcityname;
	
	@FindBy (locator="cityedit.txt.fountainfunnel")
	private QAFWebElement cityedittxtfountainfunnel;
	
	@FindBy (locator="cityedit.txt.fountaintips")
	private QAFWebElement cityedittxtfountaintips;
	
	@FindBy (locator="cityedit.txt.fountainrejected")
	private QAFWebElement cityedittxtfountainrejected;
		
	@FindBy (locator="cityedit.txt.onfleettips")
	private QAFWebElement cityedittxtonfleettips;
	
	@FindBy (locator="cityedit.txt.onfleetparking")
	private QAFWebElement cityedittxtonfleetparking;
	
	@FindBy (locator="cityedit.txt.hourlyrate")
	private QAFWebElement cityedittxthourlyrate;
	
	@FindBy (locator="cityedit.txt.maplink")
	private QAFWebElement cityedittxtmaplink;
	
	@FindBy (locator="cityedit.txt.fountainapproved")
	private QAFWebElement cityedittxtfountainapproved;
	
	@FindBy (locator="cityedit.btn.save")
	private QAFWebElement cityeditbtnsave;
	
	@FindBy (locator="cityedit.btn.cancel")
	private QAFWebElement cityeditbtncancel;
	
	
	public QAFWebElement getLblTitle() {
		return cityeditlbltitle;
	}

	public QAFWebElement getBtnEditCityCrumb() {
		return cityeditbtneditcitycrumb;
	}

	public QAFWebElement getTxtCityName() {
		return cityedittxtcityname;
	}

	public QAFWebElement getTxtFountainfunnel() {
		return cityedittxtfountainfunnel;
	}

	public QAFWebElement gettxtFountaintips() {
		return cityedittxtfountaintips;
	}

	public QAFWebElement getTxtfountainrejected() {
		return cityedittxtfountainrejected;
	}

	public QAFWebElement getTxtOnfleettips() {
		return cityedittxtonfleettips;
	}

	public QAFWebElement getTxtOnfleetparking() {
		return cityedittxtonfleetparking;
	}

	public QAFWebElement getTxtHourlyRate() {
		return cityedittxthourlyrate;
	}

	public QAFWebElement getTxtMapLink() {
		return cityedittxtmaplink;
	}

	public QAFWebElement getTxtFountainApproved() {
		return cityedittxtfountainapproved;
	}

	public QAFWebElement getBtnSave() {
		return cityeditbtnsave;
	}

	public QAFWebElement getBtnCancel() {
		return cityeditbtncancel;
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}
	
	

}
