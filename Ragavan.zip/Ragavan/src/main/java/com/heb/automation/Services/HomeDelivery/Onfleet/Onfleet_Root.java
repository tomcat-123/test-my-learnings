package com.heb.automation.Services.HomeDelivery.Onfleet;

import java.util.List;

public class Onfleet_Root
{
    private String eta;

    private String delayTime;

    private String phone;

    private String imageUrl;

    private Onfleet_Vehicles vehicle = new Onfleet_Vehicles();

    private String onDuty;

    private String timeCreated;

    private List<String> tasks;

    private String timeLastSeen;

    private Onfleet_UserData userData =new Onfleet_UserData();

    private String timeLastModified;

    private String id;

    private String[] teams;

    private String organization;

    private String accountStatus;

    private String name;

    private String capacity;

    private String activeTask;

    private String[] metadata;

    public String getEta ()
    {
        return eta;
    }

    public void setEta (String eta)
    {
        this.eta = eta;
    }

    public String getDelayTime ()
    {
        return delayTime;
    }

    public void setDelayTime (String delayTime)
    {
        this.delayTime = delayTime;
    }

    public String getPhone ()
    {
        return phone;
    }

    public void setPhone (String phone)
    {
        this.phone = phone;
    }

    public String getImageUrl ()
    {
        return imageUrl;
    }

    public void setImageUrl (String imageUrl)
    {
        this.imageUrl = imageUrl;
    }

    public Onfleet_Vehicles getVehicle ()
    {
        return vehicle;
    }

    public void setVehicle (Onfleet_Vehicles vehicle)
    {
        this.vehicle = vehicle;
    }

    public String getOnDuty ()
    {
        return onDuty;
    }

    public void setOnDuty (String onDuty)
    {
        this.onDuty = onDuty;
    }

    public String getTimeCreated ()
    {
        return timeCreated;
    }

    public void setTimeCreated (String timeCreated)
    {
        this.timeCreated = timeCreated;
    }

    public List<String> getTasks ()
    {
        return tasks;
    }

    public void setTasks (List<String> tasks)
    {
        this.tasks = tasks;
    }

    public String getTimeLastSeen ()
    {
        return timeLastSeen;
    }

    public void setTimeLastSeen (String timeLastSeen)
    {
        this.timeLastSeen = timeLastSeen;
    }

    public Onfleet_UserData getUserData ()
    {
        return userData;
    }

    public void setUserData (Onfleet_UserData userData)
    {
        this.userData = userData;
    }

    public String getTimeLastModified ()
    {
        return timeLastModified;
    }

    public void setTimeLastModified (String timeLastModified)
    {
        this.timeLastModified = timeLastModified;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String[] getTeams ()
    {
        return teams;
    }

    public void setTeams (String[] teams)
    {
        this.teams = teams;
    }

    public String getOrganization ()
    {
        return organization;
    }

    public void setOrganization (String organization)
    {
        this.organization = organization;
    }

    public String getAccountStatus ()
    {
        return accountStatus;
    }

    public void setAccountStatus (String accountStatus)
    {
        this.accountStatus = accountStatus;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getCapacity ()
    {
        return capacity;
    }

    public void setCapacity (String capacity)
    {
        this.capacity = capacity;
    }

    public String getActiveTask ()
    {
        return activeTask;
    }

    public void setActiveTask (String activeTask)
    {
        this.activeTask = activeTask;
    }

    public String[] getMetadata ()
    {
        return metadata;
    }

    public void setMetadata (String[] metadata)
    {
        this.metadata = metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [eta = "+eta+", delayTime = "+delayTime+", phone = "+phone+", imageUrl = "+imageUrl+", vehicle = "+vehicle+", onDuty = "+onDuty+", timeCreated = "+timeCreated+", tasks = "+tasks+", timeLastSeen = "+timeLastSeen+", userData = "+userData+", timeLastModified = "+timeLastModified+", id = "+id+", teams = "+teams+", organization = "+organization+", accountStatus = "+accountStatus+", name = "+name+", capacity = "+capacity+", activeTask = "+activeTask+", metadata = "+metadata+"]";
    }
}