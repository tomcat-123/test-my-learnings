/**
 * 
 */
package com.heb.automation.Listeners;

import com.heb.automation.common.TestDataContainer;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.DriverCommand;
import org.openqa.selenium.remote.RemoteExecuteMethod;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.google.common.collect.ImmutableMap;
import com.perfectomobile.selenium.util.EclipseConnector;
import com.qmetry.qaf.automation.ui.webdriver.CommandTracker;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriverCommandAdapter;
import com.qmetry.qaf.automation.util.StringUtil;

public class AndroidPerfectoDriverListener extends QAFWebDriverCommandAdapter {

	@Override
	public void beforeCommand(QAFExtendedWebDriver driver, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.QUIT)) {
			try {
				closeApp();
				driver.executeScript("mobile:logs:stop", TestDataContainer.getTestObject("deviceLogMapObject"));
				stopVitals(driver);
				driver.close();
			} catch (Exception e) {

			}
		}
	}

	@Override
	public void afterCommand(QAFExtendedWebDriver driver, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.CLOSE)) {
			try {
				// Download report and other activities
			} catch (Exception e) {
				// ignore
			}
		}
	}

	private String getExecutionId() {
		try {
			Class<?> cls = Class.forName("com.perfectomobile.selenium.util.EclipseConnector");

			Object connector = cls.newInstance();
			Method getExecutionId = cls.getMethod("getExecutionId");
			getExecutionId.setAccessible(true);

			return (String) getExecutionId.invoke(connector);

		} catch (Exception e) {
			// ignore it.....
		}
		return "";
	}

	@Override
	public void beforeInitialize(Capabilities desiredCapabilities) {
		try {/*
			EclipseConnector connector = new EclipseConnector();
			String executionId = connector.getExecutionId();
			if (TestDataContainer.getTestString("remote.server", "").contains("perfecto")) {
				if (StringUtil.isNotBlank(executionId)) {
					((DesiredCapabilities) desiredCapabilities).setCapability(EclipseConnector.ECLIPSE_EXECUTION_ID,
							executionId);
				}
			}
		*/} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void onFailure(QAFExtendedWebDriver driver, CommandTracker commandTracker) {

	}

	@Override
	public void onInitialize(QAFExtendedWebDriver driver) {

		System.out.println("------------Opening application -----------");

		startAppVitals(driver, TestDataContainer.getTestString("app.name"), true);

		/* Starting the device log */
		java.util.Map<String, Object> deviceLog = new HashMap<String, Object>();
		driver.executeScript("mobile:logs:start", deviceLog);
		TestDataContainer.putTestObject("deviceLogMapObject", deviceLog);

		/* Open Application */
		openApplication(driver, TestDataContainer.getTestString("app.name"));
		closeApplication(driver, TestDataContainer.getTestString("app.name"));
		openApplication(driver, TestDataContainer.getTestString("app.name"));

		/* Set location */
		
		java.util.Map<String, Object> params1 = new HashMap<String, Object>();
		params1.put("address", "San Antonio, TX");
		driver.executeScript("mobile:location:set", params1);
		
	}

	public static String startAppVitals(QAFExtendedWebDriver driver, String app, boolean startDeviceVitals) {
		Map<String, Object> params = new HashMap<>();
		List<String> vitals = new ArrayList<>();
		vitals.add("all");
		params.put("vitals", vitals);
		params.put("interval", Long.toString(1));
		List<String> sources = new ArrayList<>();
		sources.add(TestDataContainer.getTestString("app.name"));
		if (startDeviceVitals)
			sources.add("device");
		params.put("sources", sources);
		return (String) driver.executeScript("mobile:monitor:start", params);
	}

	/* Stop vitals */
	public static String stopVitals(QAFExtendedWebDriver driver) {
		Map<String, Object> params = new HashMap<>();
		List<String> vitals = new ArrayList<>();
		vitals.add("all");
		params.put("vitals", vitals);
		return (String) driver.executeScript("mobile:monitor:stop", params);
	}

	private void closeApp() {
		try {
			// Close application
		} catch (Exception e) {

		}
	}
	
	public static void openApplication(RemoteWebDriver driver, String appName) {

		String command = "mobile:application:open";

		/* Open application */
		driver.executeScript(command, ImmutableMap.of("name", appName));

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		switchToContext(driver, "NATIVE_APP");
	}

	public static void closeApplication(RemoteWebDriver driver, String appName) {
		String command = "mobile:application:close";

		/* Close Application if already its opened */
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("name", appName);
		try {
			driver.executeScript(command, params);
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		} catch (Exception e) {
			System.err.println("Unable to close app: " + appName);
		}
	}
	
	public static void switchToContext(RemoteWebDriver driver, String context) {

		RemoteExecuteMethod executeMethod = new RemoteExecuteMethod(driver);
		Map<String, String> params = new HashMap<String, String>();
		params.put("name", context);
		executeMethod.execute(DriverCommand.SWITCH_TO_CONTEXT, params);
	}
	

}
