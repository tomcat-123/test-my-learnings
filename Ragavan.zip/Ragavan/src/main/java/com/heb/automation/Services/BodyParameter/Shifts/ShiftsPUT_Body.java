package com.heb.automation.Services.BodyParameter.Shifts;

public class ShiftsPUT_Body {
	
	 private String shiftCapacity;

	    private String id;

	    private String lastModifiedTimestamp;

	    private String archived;

	    private String endWindowDateTime;

	    private String publishDateTime;

	    private String published;

	    private ShiftsPUT_Zone zone = new ShiftsPUT_Zone();

	    private String startWindowDateTime;

	    private String startOfWeek;

	    public String getShiftCapacity ()
	    {
	        return shiftCapacity;
	    }

	    public void setShiftCapacity (String shiftCapacity)
	    {
	        this.shiftCapacity = shiftCapacity;
	    }

	    public String getId ()
	    {
	        return id;
	    }

	    public void setId (String id)
	    {
	        this.id = id;
	    }

	    public String getLastModifiedTimestamp ()
	    {
	        return lastModifiedTimestamp;
	    }

	    public void setLastModifiedTimestamp (String lastModifiedTimestamp)
	    {
	        this.lastModifiedTimestamp = lastModifiedTimestamp;
	    }

	    public String getArchived ()
	    {
	        return archived;
	    }

	    public void setArchived (String archived)
	    {
	        this.archived = archived;
	    }

	    public String getEndWindowDateTime ()
	    {
	        return endWindowDateTime;
	    }

	    public void setEndWindowDateTime (String endWindowDateTime)
	    {
	        this.endWindowDateTime = endWindowDateTime;
	    }

	    public String getPublishDateTime ()
	    {
	        return publishDateTime;
	    }

	    public void setPublishDateTime (String publishDateTime)
	    {
	        this.publishDateTime = publishDateTime;
	    }

	    public String getPublished ()
	    {
	        return published;
	    }

	    public void setPublished (String published)
	    {
	        this.published = published;
	    }

	    public ShiftsPUT_Zone getZone ()
	    {
	        return zone;
	    }

	    public void setZone (ShiftsPUT_Zone zone)
	    {
	        this.zone = zone;
	    }

	    public String getStartWindowDateTime ()
	    {
	        return startWindowDateTime;
	    }

	    public void setStartWindowDateTime (String startWindowDateTime)
	    {
	        this.startWindowDateTime = startWindowDateTime;
	    }

	    public String getStartOfWeek ()
	    {
	        return startOfWeek;
	    }

	    public void setStartOfWeek (String startOfWeek)
	    {
	        this.startOfWeek = startOfWeek;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [shiftCapacity = "+shiftCapacity+", id = "+id+", lastModifiedTimestamp = "+lastModifiedTimestamp+", archived = "+archived+", endWindowDateTime = "+endWindowDateTime+", publishDateTime = "+publishDateTime+", published = "+published+", zone = "+zone+", startWindowDateTime = "+startWindowDateTime+", startOfWeek = "+startOfWeek+"]";
	    }

}
