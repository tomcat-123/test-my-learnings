package com.heb.automation.Steps.HD_WebApp.zone;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;

import com.heb.automation.Pages.HD_WebApp.CommonTestPage;
import com.heb.automation.Pages.HD_WebApp.searchresult.SearchResultPage;
import com.heb.automation.Pages.HD_WebApp.searchresult.ZoneSearchResultpage;
import com.heb.automation.Pages.HD_WebApp.zone.ZoneDisplayTestPage;
import com.heb.automation.Pages.HD_WebApp.zone.ZoneEditTestPage;
import com.heb.automation.Pages.HD_WebApp.zone.ZoneListingTestPage;
import com.heb.automation.Steps.HD_WebApp.HD_WebAppCommonStepdef;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class Zone_WebAppStepdef extends TestDataContainer {

	@QAFTestStep(description = "navigate to Zone listing Page")
	public void iNavigateToZonePage() {
		CommonTestPage common = new CommonTestPage();
		common.getNavigationBtnHamburger().waitForVisible(50000);
		common.getNavigationBtnHamburger().click();
		common.getNavigationLblDriverSnapshot().waitForPresent(1000);
		common.getNavigationLblZoneConfiguration().click();
		common.getNavigationLblZone().waitForPresent(1000);
		common.getNavigationLblZone().verifyPresent();
		common.getNavigationLblZone().click();
	}

	@QAFTestStep(description = "Choose an Zone from the result")
	public void chooseAnZoneFromTheResult() {

		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage ZoneResult = new ZoneSearchResultpage();
		ZoneDisplayTestPage zoneDisplay = new ZoneDisplayTestPage();

		sResult.getTableRowList().get(0).waitForPresent(5000);
		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);
		ArrayList<String> citylistActual = new ArrayList<String>();
		for (QAFWebElement rCount : sResult.getTableRowList()) {
			String selectedZone = ZoneResult.getZoneValueresult(Rowcount).getText();
			if(selectedZone.equals(getTestString("HomeDelivery.ZoneName"))){
				//Do not Update
				Rowcount = Rowcount + 1;
				String selectedNextZone = ZoneResult.getZoneValueresult(Rowcount).getText();
				putTestObject("zoneselected", selectedNextZone);
			}else{
				putTestObject("zoneselected", selectedZone);
			}

			
			// Below commented code not by me(SreeRam) please remove it if is not required as i couod be done with cobe as below thjis comment.
			/*QAFWebElement zoneSelected = ZoneResult.getZoneValueresult(Rowcount);
			zoneSelected.click();

			zoneDisplay.getZonedisplaybtnedit().waitForVisible(5000);
			String zCity = zoneDisplay.getTestBase().getDriver().findElement(By.xpath("//*[@class='mat-select-value']"))
					.getText();
			System.out.println("Zone City is " + zCity);*/
			
			String actualcity = ZoneResult.getCityValueresult(Rowcount).getText();
			putTestObject("actualcity", actualcity);
			break;
		}
		
		QAFWebElement zoneSelected = ZoneResult.getZoneValueresult(Rowcount);
		zoneSelected.click();
		
		

	}
	
	@QAFTestStep(description = "choose an valid zone from the result")
	public void chooseAnValidZoneFromTheResult() throws InterruptedException {
		HD_WebAppCommonStepdef search = new HD_WebAppCommonStepdef();
		
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage ZoneResult = new ZoneSearchResultpage();

		sResult.getTableRowList().get(0).waitForPresent(5000);
		
		eNterValidZoneName();
		search.iClickSearchButton();
		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);
		ArrayList<String> citylistActual = new ArrayList<String>();
		for (QAFWebElement rCount : sResult.getTableRowList()) {
			
			String selectedZone = ZoneResult.getZoneValueresult(Rowcount).getText();
			putTestObject("zoneselected", selectedZone);

			String actualcity = ZoneResult.getCityValueresult(Rowcount).getText();
			putTestObject("actualcity", actualcity);
			break;
		}
		
		QAFWebElement zoneSelected = ZoneResult.getZoneValueresult(Rowcount);
		zoneSelected.click();

	}

	@QAFTestStep(description = "choose a particular zone from of the DB result")
	public void chooseaParticularZoneFromTheDBResult() {

		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage ZoneResult = new ZoneSearchResultpage();
		ArrayList<String> citylistActual = new ArrayList<String>();
		HashMap<String,String>  inavtivestores= (HashMap<String, String>) getTestObject("inactiveStores");	
		ZoneListingTestPage zoneListing = new ZoneListingTestPage();
		zoneListing.getTxtZoneName().waitForPresent(5000);
		zoneListing.getTxtZoneName().sendKeys(inavtivestores.get("ZoneName"));
		zoneListing.getBtnSearch().click();
		sResult.getTableRowList().get(0).waitForPresent(5000);
		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);
	
		for (QAFWebElement rCount : sResult.getTableRowList()) {
			String selectedZone = ZoneResult.getZoneValueresult(Rowcount).getText();
			if (selectedZone.equals(inavtivestores.get("ZoneName"))) {
				QAFWebElement zoneSelected = ZoneResult.getZoneValueresult(Rowcount);
				zoneSelected.click();
				break;
			}
			Rowcount++;
		}
		putTestObject("zonecities", citylistActual);

	}

	@QAFTestStep(description = "Get the zone details")
	public void getTheZoneDetails() {
		ZoneDisplayTestPage zoneDisplay = new ZoneDisplayTestPage();

		String zoneName = zoneDisplay.getZonedisplaytxtzonename().getText();
		System.out.println("ZoneName = " + zoneName);

		String zName = zoneDisplay.getTestBase().getDriver().findElement(By.xpath("//*[@ng-reflect-name='zoneName']"))
				.getText();
		System.out.println("Zone Name is " + zName);

		String zCode = zoneDisplay.getTestBase().getDriver()
				.findElement(By.xpath("//*[@class='mat-chip-list-wrapper']")).getText();
		System.out.println("Zone Code is " + zCode);

		String zCity = zoneDisplay.getTestBase().getDriver().findElement(By.xpath("//*[@class='mat-select-value']"))
				.getText();
		System.out.println("Zone City is " + zCity);

		String zOnFleetID = zoneDisplay.getTestBase().getDriver().findElement(By.xpath("//*[@id='onfleetTeamId']"))
				.getText();
		System.out.println("Zone OnFleetID is " + zOnFleetID);

		/*
		 * System.out.println(zoneDisplay.getZonedisplaytxtzonename().
		 * getAttribute("ng-reflect-readonly"));
		 * 
		 * System.out.println(zoneDisplay.getZonedisplaytxtzipcode().
		 * getAttribute("ng-reflect-readonly"));
		 * 
		 * System.out.println(zoneDisplay.getZonedisplaytxtcity().getAttribute(
		 * "ng-reflect-is-disabled"));
		 * 
		 * System.out.println(zoneDisplay.getZonedisplaytxtcity().getText());
		 * 
		 * System.out.println(zoneDisplay.getZonedisplaytxtonfleetteamid().
		 * getAttribute("ng-reflect-readonly"));
		 */
	}

	@QAFTestStep(description = "verify the Zone listing Page")
	public void iVerifyTheZonePage() {
		ZoneListingTestPage zPage = new ZoneListingTestPage();
		CommonTestPage common = new CommonTestPage();
		SearchResultPage sResult = new SearchResultPage();
		ArrayList<String> data = new ArrayList<>();

		zPage.getLblTitle().waitForPresent(5000);
		zPage.getLblTitle().verifyPresent();
		zPage.getBtnAddNew().verifyPresent();
		zPage.getBtnZoneCrumb().verifyPresent();
		zPage.getBtnZoneCrumb().click();
		zPage.getLblTitle().waitForPresent(5000);
		zPage.getLblCity().verifyPresent();
		zPage.getLblZone().verifyPresent();
		zPage.getBtnReset().verifyPresent();
		zPage.getBtnSearch().verifyPresent();
		
		common.getLblHomeRightArrow().verifyPresent();
		common.getLblHomeIcon().verifyPresent();
		common.getLblHomeRightArrow().verifyPresent();		
		common.getCommonLblDisplayingRecords().verifyPresent();
		common.getCommonBtnPageNum().get(0).verifyPresent();
		zPage.getTxtZoneName().verifyPresent();
		zPage.getTxtCity().verifyPresent();
		zPage.getDropdownCity().verifyPresent();
		zPage.getLblTotalRecods().verifyPresent();

		for (QAFWebElement rCount : sResult.getTableColumnName()) {

			data.add(rCount.getText());
		}

		if (data.contains("Zone"))
			PerfectoUtils.reportMessage("Zone Name is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Zone Name is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("City"))
			PerfectoUtils.reportMessage("City is Avilable in Grid", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("City is not Avilable in Grid", MessageTypes.Fail);
	}

	@QAFTestStep(description = "click Add new button")
	public void iClickAddNewButton() {
		ZoneListingTestPage zPage = new ZoneListingTestPage();

		zPage.waitForPageToLoad();
		zPage.getBtnAddNew().waitForVisible(50000);
		if (zPage.getBtnAddNew().isDisplayed())
			zPage.getBtnAddNew().click();
	}

	@QAFTestStep(description = "verify zone details sorted by Name in ascending alphabetical order")
	public void iVerifyZoneDetailsSortedByNameInAscendingAlphabeticalOrder() {
		int Rowcount = 1;
		String data = null;
		ArrayList<String> assending = new ArrayList<String>();
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage zResult = new ZoneSearchResultpage();

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			data = zResult.getZoneValueresult(Rowcount).getText();
			assending.add(data);
			Rowcount++;
		}

		for (int i = 0; i < assending.size() - 1; i++) {
			for (int j = i + 1; j < assending.size() - 1; j++) {

				if (assending.get(i).compareToIgnoreCase(assending.get(j)) < 0)
					PerfectoUtils.reportMessage("Zone details are sorted by Name in ascending alphabetical order ",
							MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("Zone details are not sorted by Name in ascending alphabetical order ",
							MessageTypes.Fail);

			}

		}

	}

	@QAFTestStep(description = "verify zone details sorted by Name in descending alphabetical order")
	public void iVerifyZoneDetailsSortedByNameInDescendingAlphabeticalOrder() {
		int Rowcount = 1;
		String data = null;
		ArrayList<String> assending = new ArrayList<String>();
		CommonTestPage common = new CommonTestPage();
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage zResult = new ZoneSearchResultpage();

		for (QAFWebElement rCount : sResult.getTableColumnName()) {
			if (rCount.getText().equals("Zone")) {
				rCount.click();
				rCount.click();
			}
		}

		for (QAFWebElement rCount1 : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			data = zResult.getZoneValueresult(Rowcount).getText();
			assending.add(data);
			Rowcount++;
		}

		for (int i = 0; i < assending.size() - 1; i++) {
			for (int j = i + 1; j < assending.size() - 1; j++) {

				if (assending.get(i).compareToIgnoreCase(assending.get(j)) >= 0)
					PerfectoUtils.reportMessage("Zone details are sorted by Name in descending alphabetical order ",
							MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("Zone details are not sorted by Name in descending alphabetical order ",
							MessageTypes.Fail);

			}

		}

	}

	@QAFTestStep(description = "verify zone details sorted by City in ascending alphabetical order")
	public void iVerifyZoneDetailsSortedByCityInAscendingAlphabeticalOrder() {
		int Rowcount = 1;
		String data = null;
		ArrayList<String> assending = new ArrayList<String>();
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage zResult = new ZoneSearchResultpage();

		for (QAFWebElement rCount : sResult.getTableColumnName()) {
			if (rCount.getText().equals("City")) {
				rCount.click();
			}
		}

		for (QAFWebElement rCount1 : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			data = zResult.getCityValueresult(Rowcount).getText();
			if (!data.isEmpty())
				assending.add(data);
			Rowcount++;
		}

		for (int i = 0; i < assending.size() - 1; i++) {
			for (int j = i + 1; j < assending.size() - 1; j++) {

				if (assending.get(i).compareToIgnoreCase(assending.get(j)) <= 0)
					PerfectoUtils.reportMessage("City details are sorted by Name in ascending alphabetical order ",
							MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("City details are not sorted by Name in ascending alphabetical order ",
							MessageTypes.Fail);

			}

		}

	}

	@QAFTestStep(description = "verify zone details sorted by City in descending alphabetical order")
	public void iVerifyZoneDetailsSortedByCityInDescendingAlphabeticalOrder() {
		int Rowcount = 1;
		String data = null;
		ArrayList<String> assending = new ArrayList<String>();
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage zResult = new ZoneSearchResultpage();

		for (QAFWebElement rCount : sResult.getTableColumnName()) {
			if (rCount.getText().equals("City")) {
				rCount.click();
				rCount.click();
			}
		}

		for (QAFWebElement rCount1 : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			data = zResult.getCityValueresult(Rowcount).getText();
			if (!data.isEmpty())
				assending.add(data);
			Rowcount++;
		}

		for (int i = 0; i < assending.size() - 1; i++) {
			for (int j = i + 1; j < assending.size() - 1; j++) {

				if (assending.get(i).compareToIgnoreCase(assending.get(j)) >= 0)
					PerfectoUtils.reportMessage("Zone details are sorted by Name in descending alphabetical order ",
							MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("Zone details are not sorted by Name in descending alphabetical order ",
							MessageTypes.Fail);

			}

		}

	}

	@QAFTestStep(description = "User retrive all the zone details")
	public void userRetriveAllTheZoneDetails() throws InterruptedException {

		ZoneDisplayTestPage zdp = new ZoneDisplayTestPage();
		String zname = zdp.getZonedisplaytxtzonename().getAttribute("value");
		System.out.println("Zone Name " + zname);

		int zcodelist = zdp.getLblSelectedZipcode().size();

		System.out.println("Total zcode available : " + zcodelist);
		for (QAFWebElement zcode : zdp.getLblSelectedZipcode()) {

			String zipcode = zcode.getText();

			System.out.println("zipcode :" + zipcode);
		}

		String zcity = zdp.getZonedisplaytxtcity().getText();
		System.out.println("Zone city " + zcity);

		String zfeetID = zdp.getZonedisplaytxtonfleetteamid().getAttribute("value");
		System.out.println("FeetID " + zfeetID);

	}

	@QAFTestStep(description = "navigate to Edit Zone Page")
	public void iNavigateToEditZonePage() throws InterruptedException {
		ZoneDisplayTestPage zdp = new ZoneDisplayTestPage();

		zdp.getZonedisplaybtnedit().waitForVisible(8000);
		zdp.getZonedisplaybtnedit().waitForPresent(5000);
		// Thread.sleep(5000);
		zdp.getZonedisplaybtnedit().click();
	}

	@QAFTestStep(description = "navigate to Display Zone Page")
	public void iNavigateToDisplayZonePage() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage ZoneResult = new ZoneSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			String ZoneName = ZoneResult.getZoneValueresult(Rowcount).getText();
			putTestObject("ZoneName", ZoneName);
			ZoneResult.getZoneValueresult(Rowcount).click();
			break;
		}

		// if (!editZoneTP.getBtnEdit().isPresent())
		// zoneTP.getLnkZoneResult().click();
	}

	@QAFTestStep(description = "verify zone is not deleted")
	public void iVerifyZoneIsNotDeleted() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage ZoneResult = new ZoneSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			String Zone = ZoneResult.getZoneValueresult(Rowcount).getText();

			if (Zone.equals(getTestString("ZoneName"))) {
				PerfectoUtils.reportMessage("Selected Zone is not Deleted", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Selected Zone is Deleted", MessageTypes.Fail);
			}
			break;
		}
	}

	@QAFTestStep(description = "verify zone is deleted")
	public void iVerifyZoneIsDeleted() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage ZoneResult = new ZoneSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			String Zone = ZoneResult.getZoneValueresult(Rowcount).getText();

			if (!Zone.equals(getTestString("zoneselcted"))) {
				PerfectoUtils.reportMessage("Selected Zone is Deleted", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Selected Zone is not Deleted", MessageTypes.Fail);
			}
			break;
		}
	}

	@QAFTestStep(description = "verify Zone List Page displays all non-archived zones")
	public void iVerifyZoneListPageDisplaysAllNonArchivedZones() {
		ZoneListingTestPage zPage = new ZoneListingTestPage();

		zPage.getLblTotalRecods().verifyPresent();
		String totalRecords = zPage.getLblTotalRecods().getText();
		totalRecords = totalRecords.substring(15);

		putTestObject("zonecount", totalRecords);
	}

	@QAFTestStep(description = "verify city associated with the zone db validation")
	public void iVerifyCityAssociatedWithTheZoneDBValidation() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage ZoneResult = new ZoneSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			String Zone = ZoneResult.getCityValueresult(Rowcount).getText();
		}
	}

	@QAFTestStep(description = "verify the Display Zone Page")
	public void iVerifyTheDisplayZonePage() {
		ZoneDisplayTestPage zoneDP = new ZoneDisplayTestPage();
		CommonTestPage common = new CommonTestPage();

		zoneDP.getZonedisplaylbltitle().waitForPresent(5000);
		common.getLblHomeIcon().verifyPresent();
		common.getLblHomeRightArrow().verifyPresent();
		zoneDP.getZonedisplaybtndisplayzonecrumb().verifyPresent();
		zoneDP.getZonedisplaybtndisplayzonecrumb().click();
		zoneDP.getZonedisplaytxtzonename().verifyPresent();
		zoneDP.getZonedisplaytxtonfleetteamid().verifyPresent();
		zoneDP.getZonedisplaytxtcity().verifyPresent();
		zoneDP.getZonedisplaytxtzipcode().verifyPresent();
		zoneDP.getZonedisplaybtncancel().verifyPresent();
		zoneDP.getZonedisplaybtndelete().verifyPresent();
		zoneDP.getZonedisplaybtnedit().verifyPresent();

		String Title = zoneDP.getZonedisplaylbltitle().getText();

		if (Title.contains(getTestString("zoneselected")))
			PerfectoUtils.reportMessage("Title is displayed with Zone Name", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Title is not displayed with Zone Name", MessageTypes.Fail);

	}

	@QAFTestStep(description = "click on cancel button in zone display page")
	public void iClickOnCancelButtonInZoneDisplayPage() {
		ZoneDisplayTestPage zoneDisplay = new ZoneDisplayTestPage();

		zoneDisplay.getZonedisplaybtncancel().waitForPresent(5000);
		zoneDisplay.getZonedisplaybtncancel().click();
	}

	@QAFTestStep(description = "click on delete button in Display zone page")
	public void iClickOnDeleteButtonInDisplayZonePage() {
		ZoneDisplayTestPage zoneDisplay = new ZoneDisplayTestPage();

		zoneDisplay.getZonedisplaybtncancel().waitForPresent(5000);
		zoneDisplay.getZonedisplaybtndelete().click();
	}

	@QAFTestStep(description = "click No on the Delete Confirmation pop-up modal")
	public void iClickNoOnTheDeleteConfirmationPopupModal() {
		ZoneDisplayTestPage editZoneTP = new ZoneDisplayTestPage();

		editZoneTP.getZonedisplaybtnno().waitForPresent(5000);
		editZoneTP.getZonedisplaybtnno().click();
	}

	@QAFTestStep(description = "click Yes on the Delete Confirmation pop-up modal")
	public void iClickYesOnTheDeleteConfirmationPopupModal() {
		ZoneDisplayTestPage editZoneTP = new ZoneDisplayTestPage();

		editZoneTP.getZonedisplaybtnyes().waitForPresent();
		editZoneTP.getZonedisplaybtnyes().click();
	}

	@QAFTestStep(description = "enter zone name in zone listing page")
	public void iEnterZoneNameInZoneListingPage() {
		ZoneListingTestPage zoneListing = new ZoneListingTestPage();

		zoneListing.getTxtZoneName().waitForPresent(5000);
		zoneListing.getTxtZoneName().sendKeys(getTestStringArray("zoneNameEnterd"));
	}

	@QAFTestStep(description = "enter edited zone name in zone listing page")
	public void iEnterEditedZoneNameInZoneListingPage() {
		ZoneListingTestPage zoneListing = new ZoneListingTestPage();

		zoneListing.getTxtZoneName().waitForPresent(5000);
		zoneListing.getTxtZoneName().sendKeys(getTestStringArray("zoneNameEdit"));
	}

	@QAFTestStep(description = "enter selected zone name in zone listing page")
	public void iEnterSelectedZoneNameInZoneListingPage() {
		ZoneListingTestPage zoneListing = new ZoneListingTestPage();

		zoneListing.getTxtZoneName().waitForPresent(5000);
		zoneListing.getTxtZoneName().sendKeys(getTestStringArray("zoneselected"));
	}

	@QAFTestStep(description = "verify created zone displays on the Zone Listing page")
	public void iVerifyCreatedZoneDisplaysOnTheZoneListingPage() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage ZoneResult = new ZoneSearchResultpage();

		sResult.getTableRowList().get(0).waitForPresent(5000);
		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			String selectedZone = ZoneResult.getZoneValueresult(Rowcount).getText();

			if (selectedZone.equals(getTestString("zoneNameEnterd")))
				PerfectoUtils.reportMessage("Created Zone is Avilable in Zone Listing Page", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Created Zone is Not Avilable in Zone Listing Page", MessageTypes.Fail);
			break;
		}
	}

	@QAFTestStep(description = "verify edited zone displays on the Zone Listing page")
	public void iVerifyEditedZoneDisplaysOnTheZoneListingPage() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage ZoneResult = new ZoneSearchResultpage();

		sResult.getTableRowList().get(0).waitForPresent(5000);
		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			String selectedZone = ZoneResult.getZoneValueresult(Rowcount).getText();

			if (selectedZone.equals(getTestString("zoneNameEdit")))
				PerfectoUtils.reportMessage("Edited Zone is Avilable in Zone Listing Page", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Edited Zone is Not Avilable in Zone Listing Page", MessageTypes.Fail);
			break;
		}
	}

	@QAFTestStep(description = "verify edited zone not display on the Zone Listing page")
	public void iVerifyEditedZoneNotDisplayOnTheZoneListingPage() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage ZoneResult = new ZoneSearchResultpage();

		sResult.getTableRowList().get(0).waitForPresent(5000);
		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			String selectedZone = ZoneResult.getZoneValueresult(Rowcount).getText();

			if (selectedZone.equals(getTestString("zoneselected")))
				PerfectoUtils.reportMessage("Edited Zone is Avilable in Zone Listing Page", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Edited Zone is Not Avilable in Zone Listing Page", MessageTypes.Fail);
			break;
		}
	}

	@QAFTestStep(description = "enter valid ZoneName with 3 Characters")
	public void iEnterValidZoneNameWith3Characters() {
		ZoneListingTestPage zoneListing = new ZoneListingTestPage();

		zoneListing.getTxtZoneName()
				.sendKeys(getTestString("HomeDelivery.ZoneName3Characters"));
	}

	@QAFTestStep(description = "enter valid zonename")
	public void eNterValidZoneName() {
		ZoneListingTestPage zoneListing = new ZoneListingTestPage();

		zoneListing.getTxtZoneName().sendKeys(getTestString("HomeDelivery.ZoneName"));
	}

	@QAFTestStep(description = "enter valid city")
	public void eNterValidCity() {
		ZoneListingTestPage zoneListing = new ZoneListingTestPage();

		zoneListing.getTxtCity().click();
		zoneListing.getCityValue(getTestString("HomeDelivery.ZoneCity"))
				.waitForPresent(5000);
		zoneListing.getCityValue(getTestString("HomeDelivery.ZoneCity")).click();
	}

	@QAFTestStep(description = "verify reset button clears search criteria entered")
	public void vErifyResetButtonClearsSearchCriteriaEntered() {
		ZoneListingTestPage zoneListing = new ZoneListingTestPage();
		
		zoneListing.getBtnReset().click();
		zoneListing.waitForPageToLoad();

		String zoneName = zoneListing.getTxtZoneName().getAttribute("value");

		if (zoneName.isEmpty())
			PerfectoUtils.reportMessage("Reset button clears Zone name", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Reset button clears Zone name", MessageTypes.Fail);
	}

	@QAFTestStep(description = "verify page reloads with original results")
	public void vErifyPageReloadsWithOriginalResults() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage ZoneResult = new ZoneSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String FirstNameDisplayed = ZoneResult.getZoneValueresult(Rowcount).getText();

			if (!FirstNameDisplayed.equals(getTestString("DefaultZoneName"))) {

				PerfectoUtils.reportMessage("page reloads with original results", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("page not reloads with original results", MessageTypes.Fail);
			}

			break;
		}

	}

	@QAFTestStep(description = "verify zone type ahead displays upto 10 results")
	public void iVerifyZoneTypeaheadDisplaysUpto10Results() {
		ZoneListingTestPage zoneListing = new ZoneListingTestPage();

		zoneListing.getLblZoneNameTypeHed().get(0).waitForPresent(5000);

		int typeHeadSize = zoneListing.getLblZoneNameTypeHed().size();

		if (typeHeadSize <= 10)
			PerfectoUtils.reportMessage("Typeahead displays upto 10 or Less results", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Typeahead displays More than 10 results", MessageTypes.Fail);
	}

	@QAFTestStep(description = "verify zone type ahead results in alphabetical order")
	public void iVerifyZoneTypeaheadResultsInAlphabeticalOrder() {
		ZoneListingTestPage zoneListing = new ZoneListingTestPage();
		ArrayList<String> results = new ArrayList<String>();

		List<QAFWebElement> typeHeadResults = zoneListing.getLblZoneNameTypeHed();

		for (QAFWebElement typeHeadresult : typeHeadResults) {
			results.add(typeHeadresult.getText());
		}

		for (int i = 0; i < results.size() - 1; i++) {
			for (int j = i + 1; j < results.size() - 1; j++) {

				if (results.get(i).compareToIgnoreCase(results.get(j)) < 0)
					PerfectoUtils.reportMessage("Type Head Results are diplayed in alphabetical order ",
							MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("Type Head Results are not diplayed in alphabetical order",
							MessageTypes.Fail);

			}
		}
	}

	@QAFTestStep(description = "select ZoneName from typehead result")
	public void iSelectZoneNameFromTypeheadResult() {
		ZoneListingTestPage zoneListing = new ZoneListingTestPage();

		zoneListing.getLblZoneNameTypeHed().get(0).waitForPresent(5000);
		String FirstNameTypeAh = zoneListing.getLblZoneNameTypeHed().get(0).getText();
		putTestObject("ZoneNameTypeAh", FirstNameTypeAh);
		zoneListing.getLblZoneNameTypeHed().get(0).click();
	}

	@QAFTestStep(description = "verify zone displays created information")
	public void iVerifyZoneDisplaysCreatedInformation() {
		ZoneDisplayTestPage zdp = new ZoneDisplayTestPage();

		String zname = zdp.getZonedisplaytxtzonename().getAttribute("value");
		String zipcode = zdp.getLblSelectedZipcode().get(0).getText();
		String zcity = zdp.getZonedisplaytxtcity().getText();

		if (zname.equals(getTestString("zoneNameEnterd")))
			PerfectoUtils.reportMessage("Created ZoneName is getting displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Created ZoneName is not getting displayed", MessageTypes.Fail);

		if (zipcode.equals(getTestString("ZipSelected")))
			PerfectoUtils.reportMessage("Created Zipcode is getting displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Created Zipcode is not getting displayed", MessageTypes.Fail);

		if (zcity.equals(getTestString("CitySelected")))
			PerfectoUtils.reportMessage("Created City is getting displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Created City is not getting displayed", MessageTypes.Fail);
	}

	@QAFTestStep(description = "verify zone displays Edited information")
	public void iVerifyZoneDisplaysEditedInformation() {
		ZoneDisplayTestPage zdp = new ZoneDisplayTestPage();
		List<String> zipCode = new ArrayList<String>();

		String zname = zdp.getZonedisplaytxtzonename().getAttribute("value");

		for (QAFWebElement zCode : zdp.getLblSelectedZipcode()) {
			zipCode.add(zCode.getText());
		}

		String zcity = zdp.getZonedisplaytxtcity().getText();

		if (zname.equals(getTestString("zoneNameEdit")))
			PerfectoUtils.reportMessage("Edited ZoneName is getting displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Edited ZoneName is not getting displayed", MessageTypes.Fail);

		if (zipCode.contains((getTestString("ZipCode"))))
			PerfectoUtils.reportMessage("Edited Zipcode is getting displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Edited Zipcode is not getting displayed", MessageTypes.Fail);

		if (zcity.equals(getTestString("CityEdited")))
			PerfectoUtils.reportMessage("Edited City is getting displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Edited City is not getting displayed", MessageTypes.Fail);
	}

	@QAFTestStep(description = "verify the search result for type ahead ZoneName")
	public void iSeeTheSearchResultForTypeaheadZoneName() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage ZoneResult = new ZoneSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String FirstNameDisplayed = ZoneResult.getZoneValueresult(Rowcount).getText();
			FirstNameDisplayed = FirstNameDisplayed.toLowerCase();

			if (FirstNameDisplayed.contains(getTestString("ZoneNameTypeAh").toLowerCase())) {

				PerfectoUtils.reportMessage("FirstName matches with the Typeahead search result", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("FirstName Does not matches with the Typeahead search result",
						MessageTypes.Fail);
			}

			Rowcount++;
		}
	}

	@QAFTestStep(description = "verify the search result for zonename")
	public void vErifyTheSearchResultForZoneName() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage ZoneResult = new ZoneSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String FirstNameDisplayed = ZoneResult.getZoneValueresult(Rowcount).getText();
			putTestObject("DefaultZoneName", FirstNameDisplayed);

			if (FirstNameDisplayed.contains(getTestString("HomeDelivery.ZoneName"))) {

				PerfectoUtils.reportMessage("zonenameName matches with the search result", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("zonenameName Does not matches with the search result", MessageTypes.Fail);
			}

			Rowcount++;
		}
	}

	@QAFTestStep(description = "verify the search result for city")
	public void vErifyTheSearchResultForCity() {
		int Rowcount = 1;
		SearchResultPage sResult = new SearchResultPage();
		ZoneSearchResultpage ZoneResult = new ZoneSearchResultpage();

		int rowcount = sResult.getTableRowList().size();
		System.out.println(rowcount);

		for (QAFWebElement rCount : sResult.getTableRowList()) {
			System.out.println(Rowcount);

			String FirstNameDisplayed = ZoneResult.getCityValueresult(Rowcount).getText();

			if (FirstNameDisplayed.contains(getTestString("HomeDelivery.ZoneCity"))) {

				PerfectoUtils.reportMessage("CityName matches with the search result", MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("CityName Does not matches with the search result", MessageTypes.Fail);
			}

			Rowcount++;
		}
	}

	@QAFTestStep(description = "verify fields are not editable in zone display page")
	public void iVerifyFieldsAreNotEditableInZoneDisplayPage() {
		ZoneDisplayTestPage zdp = new ZoneDisplayTestPage();
		ZoneEditTestPage zep = new ZoneEditTestPage();

		zdp.getZonedisplaytxtzonename().click();
		String zoneName = "Automation"+generateRandomString();
		zdp.getZonedisplaytxtzonename().sendKeys(zoneName);

		String onfleet = generateRandomString();
		zdp.getZonedisplaytxtonfleetteamid().sendKeys(onfleet);

		if (!zoneName.equals(zdp.getZonedisplaytxtzonename().getAttribute("value")))
			PerfectoUtils.reportMessage("Zone Name is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Zone Name is editable", MessageTypes.Fail);

		zdp.getZonedisplaytxtcity().click();
		zdp.getZonedisplaytxtzipcode().click();

		if (!onfleet.equals(zdp.getZonedisplaytxtonfleetteamid().getAttribute("value")))
			PerfectoUtils.reportMessage("Onfleet ID is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Onfleet ID is editable", MessageTypes.Fail);
	}

	public static String generateRandomString() {

		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 6;
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();

		return generatedString;

	}

	@QAFTestStep(description = "verify user is navigated back to the Zone Display Page")
	public void vErifyUserIsNavigatedBackToTheZoneDisplayPage() {
		ZoneDisplayTestPage zoneDisplay = new ZoneDisplayTestPage();
		
		zoneDisplay.getZonedisplaylbltitle().verifyPresent();
	}
}
