package com.heb.automation.Steps.HD_WebApp.city;

import java.util.Random;

import com.heb.automation.Pages.HD_WebApp.CommonTestPage;
import com.heb.automation.Pages.HD_WebApp.city.CityCreateTestPage;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class CityCreate_WebAppStepdef extends TestDataContainer {

	@QAFTestStep(description = "verify create city page")
	public void iVerifyCreateCityPage() {
		CityCreateTestPage cityCTP = new CityCreateTestPage();
		CommonTestPage common = new CommonTestPage();

		common.getLblHomeRightArrow().verifyPresent();
		common.getLblHomeIcon().verifyPresent();
		cityCTP.getCitycreatelbltitle().verifyPresent();
		cityCTP.getCitycreatebtncreatecityCrumb().verifyPresent();
		cityCTP.getCitycreatebtncreatecityCrumb().click();
		cityCTP.getCitycreatelbltitle().waitForPresent(1000);
		cityCTP.getCitycreatetxtcityname().verifyPresent();
		cityCTP.getCitycreatetxtfountainApprovedId().verifyPresent();
		cityCTP.getCitycreatetxtfountainFunnelId().verifyPresent();
		cityCTP.getCitycreatetxtfountainRejectedId().verifyPresent();
		cityCTP.getCitycreatetxtfountainSessionId().verifyPresent();
		cityCTP.getCitycreatetxthourlyRate().verifyPresent();
		cityCTP.getCitycreatetxtmapLink().verifyPresent();
		cityCTP.getCitycreatebtncancel().verifyPresent();
		cityCTP.getCityCreateBtnSave().verifyPresent();
	}

	@QAFTestStep(description = "verify fields are editable or not editable in create city page")
	public void iVerifyFieldsAreEditableOrNotEditableInCreateCityPage() {
		CityCreateTestPage cityCTP = new CityCreateTestPage();
		
		String cityName = "Automation"+generateRandomString();
		cityCTP.getCitycreatetxtcityname().sendKeys(cityName);	
		String founApprove = generateRandomString();
		cityCTP.getCitycreatetxtfountainApprovedId().sendKeys(founApprove);	
		String founFunnel = generateRandomString();
		cityCTP.getCitycreatetxtfountainFunnelId().sendKeys(founFunnel);	
		String founReject = generateRandomString();
		cityCTP.getCitycreatetxtfountainRejectedId().sendKeys(founReject);	
		String founSession = generateRandomString();
		cityCTP.getCitycreatetxtfountainSessionId().sendKeys(founSession);	
		String horlyRate = generateRandomString();
		cityCTP.getCitycreatetxthourlyRate().sendKeys(horlyRate);	
		String map = generateRandomString();
		cityCTP.getCitycreatetxtmapLink().sendKeys(map);
		
		if(cityName.equals(cityCTP.getCitycreatetxtcityname().getAttribute("value")))
			PerfectoUtils.reportMessage("City Name is editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("City Name is not editable", MessageTypes.Fail);
		
		if(!founApprove.equals(cityCTP.getCitycreatetxtfountainApprovedId().getAttribute("value")))
			PerfectoUtils.reportMessage("Fountain Approve is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Fountain Approve is editable", MessageTypes.Fail);
		
		if(!founFunnel.equals(cityCTP.getCitycreatetxtfountainFunnelId().getAttribute("value")))
			PerfectoUtils.reportMessage("Fountain Funnel is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Fountain Funnel is editable", MessageTypes.Fail);
		
		if(!founReject.equals(cityCTP.getCitycreatetxtfountainRejectedId().getAttribute("value")))
			PerfectoUtils.reportMessage("Fountain Regect is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Fountain Regect is editable", MessageTypes.Fail);
		
		if(!founSession.equals(cityCTP.getCitycreatetxtfountainSessionId().getAttribute("value")))
			PerfectoUtils.reportMessage("Fountain Session is not editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Fountain Regect is editable", MessageTypes.Fail);
		
		if(horlyRate.equals(cityCTP.getCitycreatetxthourlyRate().getAttribute("value")))
			PerfectoUtils.reportMessage("HorlyRate  is editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("HorlyRate is not editable", MessageTypes.Fail);
		
		if(map.equals(cityCTP.getCitycreatetxtmapLink().getAttribute("value")))
			PerfectoUtils.reportMessage("Map Link  is editable", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Map Link  is not editable", MessageTypes.Fail);	
	}
	
	@QAFTestStep(description = "enter city name in create city page")
	public void iEnterCityNameInCreateCityPage() {
		CityCreateTestPage cityCTP = new CityCreateTestPage();
		
		cityCTP.getCitycreatetxtcityname().click();
		cityCTP.getCitycreatetxtcityname().clear();
		String cityName = "Automation"+generateRandomString();
		cityCTP.getCitycreatetxtcityname().sendKeys(cityName);
		putTestObject("CityName", cityName);	
	}
	
	@QAFTestStep(description = "enter hourly rate in create city page")
	public void iEnterHourlyRateInCreateCityPage() {
		CityCreateTestPage cityCTP = new CityCreateTestPage();
		
		int hourlyRate = generateRandomHourlrRate();
		String houRate = Integer.toString(hourlyRate);
		cityCTP.getCitycreatetxthourlyRate().sendKeys(houRate);
		putTestObject("CreatedHourlyRate", houRate);	
	}
	
	@QAFTestStep(description = "enter map link in create city page")
	public void iEnterMapLinkInCreateCityPage() {
		CityCreateTestPage cityCTP = new CityCreateTestPage();
		
		cityCTP.getCitycreatetxtmapLink().click();
		cityCTP.getCitycreatetxtmapLink().clear();
		String mapLink = generaterandomMapLink();
		putTestObject("CreatedMapLink", mapLink);
		cityCTP.getCitycreatetxtmapLink().sendKeys(mapLink);
	}
	
	@QAFTestStep(description = "click on save button in create city page")
	public void iClickOnSaveButtonInCreateCityPage() {
		CityCreateTestPage cityCTP = new CityCreateTestPage();
		
		cityCTP.getCityCreateBtnSave().waitForPresent(1000);
		cityCTP.getCityCreateBtnSave().click();
			
	}

	public static String generateRandomString() {

		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 6;
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();

		return "Automation_"+generatedString;

	}
	
	private int generateRandomHourlrRate() {
		Random random = new Random();
		int hRate = random.nextInt(100);
		return hRate;
	}
	
	private String generaterandomMapLink() {
		
		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 6;
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();

		return "https://www.google.com/AutomationMapLink&"+generatedString;
	}

}
