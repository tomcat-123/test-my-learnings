package com.heb.automation.Services.HomeDelivery.Search.ShiftsSearchResult;

import java.util.ArrayList;

public class SearchShiftPlanner_Days {
	
	private ArrayList<SearchShiftPlanner_Days_Shifts> shifts;

    private String dayOfWeek;

    public ArrayList<SearchShiftPlanner_Days_Shifts> getShifts ()
    {
        return shifts;
    }

    public void setShifts (ArrayList<SearchShiftPlanner_Days_Shifts> shifts)
    {
        this.shifts = shifts;
    }

    public String getDayOfWeek ()
    {
        return dayOfWeek;
    }

    public void setDayOfWeek (String dayOfWeek)
    {
        this.dayOfWeek = dayOfWeek;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [shifts = "+shifts+", dayOfWeek = "+dayOfWeek+"]";
    }

}
