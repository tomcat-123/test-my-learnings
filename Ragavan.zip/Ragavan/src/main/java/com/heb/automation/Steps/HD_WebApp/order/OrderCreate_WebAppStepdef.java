package com.heb.automation.Steps.HD_WebApp.order;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import com.heb.automation.Pages.HD_WebApp.order.OrderCreateTestPage;
import com.heb.automation.Pages.HD_WebApp.order.OrderListingTestPage;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

import bsh.ParseException;

public class OrderCreate_WebAppStepdef extends TestDataContainer {
	
	@QAFTestStep(description = "verify the create order Order Detail section")
	public void vErifyTheCreateOrderOrderDetailSection() {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		
		orderCreate.getLblTitle().waitForPresent(5000);		
		orderCreate.getLblOrderDetail().verifyPresent();
		orderCreate.getTxtOrderId().verifyPresent();
		orderCreate.getTxtTip().verifyPresent();
		orderCreate.getTxtInstructions().verifyPresent();
		orderCreate.getTxtGrossBill().verifyPresent();
		orderCreate.getTxtInvoice().verifyPresent();
	}
	
	@QAFTestStep(description = "verify the create order Order Store section")
	public void vErifyTheCreateOrderOrderStoreSection() {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		
		orderCreate.getLblStore().verifyPresent();
		orderCreate.getTxtStore().verifyPresent();
	}
	
	@QAFTestStep(description = "verify the create order Order Customer section")
	public void vErifyTheCreateOrderOrderCustomerSection() {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		
		orderCreate.getLblCustomer().verifyPresent();
		orderCreate.getTxtFirstName().verifyPresent();
		orderCreate.getTxtLastName().verifyPresent();
		orderCreate.getTxtPhone().verifyPresent();
		orderCreate.getTxtEmail().verifyPresent();
		orderCreate.getLblRecipientSame().verifyPresent();
		orderCreate.getRadioButtonRecipientYes().verifyPresent();
		orderCreate.getRadioButtonRecipientNo().verifyPresent();
		orderCreate.getLblRecipientYes().verifyPresent();
		orderCreate.getLblRecipientNo().verifyPresent();
	}
	
	@QAFTestStep(description = "verify the create order Order Recipient section")
	public void vErifyTheCreateOrderOrderRecipientSection() {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		
		orderCreate.getRadioButtonRecipientNo().click();
		orderCreate.getLblRecipient().waitForPresent(1000);
		orderCreate.getLblRecipient().verifyPresent();
		orderCreate.getTxtRecipientEmail().verifyPresent();
		orderCreate.getTxtRecipientFirstname().verifyPresent();
		orderCreate.getTxtRecipientLastName().verifyPresent();
		orderCreate.getTxtRecipientPhone().verifyPresent();	
	}
	
	@QAFTestStep(description = "verify the create order Order Delivery Address section")
	public void vErifyTheCreateOrderOrderDeliveryAddressSection() {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		
		orderCreate.getLblDeliveryaddress().verifyPresent();
		orderCreate.getTxtAddress1().verifyPresent();
		orderCreate.getTxtAddress2().verifyPresent();
		orderCreate.getTxtCity().verifyPresent();
		orderCreate.getTxtState().verifyPresent();
		orderCreate.getTxtZip().verifyPresent();
		orderCreate.getTxtNote().verifyPresent();
		orderCreate.getTxtLatitude().verifyPresent();
		orderCreate.getTxtLongitude().verifyPresent();		
	}
	
	@QAFTestStep(description = "verify the create order Order Delivery Schedule section")
	public void vErifyTheCreateOrderOrderDeliveryScheduleSection() {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		
		orderCreate.getLblDeliverySchedule().verifyPresent();
		orderCreate.getTxtStartTime().verifyPresent();
		orderCreate.getTxtEndTime().verifyPresent();
	}
	
	@QAFTestStep(description = "verify the create order Order Status section")
	public void vErifyTheCreateOrderOrderStatusSection() {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		
		orderCreate.getLblStatus().verifyPresent();
		orderCreate.getLblContainsAlcohol().verifyPresent();
		orderCreate.getRadioButtonContainsAlcoholYes().verifyPresent();
		orderCreate.getRadioButtonContainsAlcoholNo().verifyPresent();
		orderCreate.getLblContainsAlcoholYes().verifyPresent();
		orderCreate.getLblContainsAlcoholNo().verifyPresent();
		orderCreate.getLblContainsStatus().verifyPresent();
		orderCreate.getRadioButtonStatusNew().verifyPresent();
		orderCreate.getRadioButtonStatusCanceled().verifyPresent();
		orderCreate.getLblStatusNew().verifyPresent();
		orderCreate.getLblStatusCanceled().verifyPresent();
	}
	
	@QAFTestStep(description = "verify the create order Order Onfleet section")
	public void vErifyTheCreateOrderOrderOnfleetSection() {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		
		orderCreate.getLblOnfleet().verifyPresent();
		orderCreate.getLblCreateOnfleetPin().verifyPresent();
		orderCreate.getRadioButtonCreateOnfleetPinYes().verifyPresent();
		orderCreate.getRadioButtOncreateOnfleetPinNo().verifyPresent();
		orderCreate.getLblCreateOnfleetpinYes().verifyPresent();
		orderCreate.getLblCreateOnfleetpinNo().verifyPresent();
		orderCreate.getTxtOnfleetTaskId().verifyPresent();
		
		PerfectoUtils.scrolltoelement(orderCreate.getBtnCancel());
		
		orderCreate.getBtnCancel().verifyPresent();
		orderCreate.getBtnSave().verifyPresent();
	}
	
	@QAFTestStep(description = "click on create order crump")
	public void cLickOnCreateOrderCrump() {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		
		orderCreate.getBtnCrump().waitForPresent(5000);
		orderCreate.getBtnCrump().click();
	}
	
	@QAFTestStep(description = "verify user navigate to create order page")
	public void vErifyUsernAvigatedToCreateOrderPage() {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		
		orderCreate.getLblTitle().waitForPresent(5000);
		orderCreate.getLblTitle().verifyPresent();
	}
	@QAFTestStep(description = "Enter the All Details in Create Order Page with {0} Status and Alcohol = {1} and Onfleet = {2}")
	public void enterTheOrderAlltoCreateANewOrder(String Status,String Alcohol, String Onfleet) {
		try{
		enterTheOrderOrdertoCreateANewOrder();
		enterTheStoreandCustomertoCreateANewOrder();
		enterTheDeliveryAddressandDeliveryScheduletoCreateANewOrder();
		selectStatusandAlcoholOnFleetPininCreateOrderPage(Status,Alcohol,Onfleet);
		}catch(Exception e){
		PerfectoUtils.ReportMessage("Fail to Create Order ",MessageTypes.Fail);
		}
	}
	@QAFTestStep(description = "Select Status Alcohol and OnFleetPin in Create Order Page")
	public void selectStatusandAlcoholOnFleetPininCreateOrderPage(String Status,String Alcohol,String Onfleet) {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		
		if(Status.equals("Cancel")){
		PerfectoUtils.scrolltoelement(orderCreate.getRadioButtonStatusCanceled());
		orderCreate.getRadioButtonStatusCanceled().click();
		PerfectoUtils.ReportMessage("Selected Cancel Status",MessageTypes.Info);
		}
		if(Alcohol.equals("Yes")){
		orderCreate.getRadioButtonContainsAlcoholYes().click();
		PerfectoUtils.ReportMessage("Contains Alcohol: Yes",MessageTypes.Info);
		}
		if(Onfleet.equals("Yes")){
			orderCreate.getRadioButtonCreateOnfleetPinYes().click();
			PerfectoUtils.ReportMessage("Onfleet Pin: Yes",MessageTypes.Info);
		}
	}
	@QAFTestStep(description = "Enter the Order Details in Create Order Page")
	public void enterTheOrderOrdertoCreateANewOrder() throws InterruptedException {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		Order_WebAppStepdef order = new Order_WebAppStepdef();
		int flag = 0;
		//PerfectoUtils.scrolltoelement(orderCreate.getTxtOrderId());
		String OrderId = getexternalID();
		int orderAlreadyNotCreated = order.verifyTheOrderIsNotAlreadyCreatedInOrderListPage(OrderId);
		if(orderAlreadyNotCreated == 1){
			order.nAvigateToCreateOrderPage();
			putTestObject("SelectedOrderID", OrderId);
			orderCreate.getTxtOrderId().sendKeys(OrderId);
		}else{
			enterTheOrderOrdertoCreateANewOrder();
			flag = 1;
		}
		if(flag == 0){
			orderCreate.getTxtGrossBill().sendKeys(getTestString("HomeDelivery.GrossBill"));
			orderCreate.getTxtTip().sendKeys(getTestString("HomeDelivery.Tip"));
			orderCreate.getTxtInvoice().sendKeys(getTestString("HomeDelivery.Invoice"));
			orderCreate.getTxtInstructions().sendKeys(getTestString("HomeDelivery.Instruction"));
			PerfectoUtils.ReportMessage("Entered the Order Details",MessageTypes.Pass);
		}
	}
	@QAFTestStep(description = "Enter the Store and Customer Details in Create Order Page")
	public void enterTheStoreandCustomertoCreateANewOrder() {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		
		orderCreate.getTxtStore().click();
		PerfectoUtils.getDriver().getKeyboard().sendKeys(getTestString("HomeDelivery.Store1"));
		PerfectoUtils.scrolltoelement(orderCreate.getTxtFirstName());
		orderCreate.getTxtFirstName().sendKeys(getTestString("HomeDelivery.FirstName"));
		orderCreate.getTxtLastName().sendKeys(getTestString("HomeDelivery.LastName"));
		orderCreate.getTxtPhone().sendKeys(getTestString("HomeDelivery.Phone"));
		orderCreate.getTxtEmail().sendKeys(getTestString("HomeDelivery.Email"));
		PerfectoUtils.ReportMessage("Entered the Store and Customer Details",MessageTypes.Pass);
	}
	
	@QAFTestStep(description = "Enter the Delivery Address and Delivery Schedule Details in Create Order Page")
	public void enterTheDeliveryAddressandDeliveryScheduletoCreateANewOrder() {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		
		PerfectoUtils.scrolltoelement(orderCreate.getTxtStore());
		orderCreate.getTxtAddress1().sendKeys(getTestString("HomeDelivery.Address1"));
		orderCreate.getTxtAddress2().sendKeys(getTestString("HomeDelivery.Address2"));
		orderCreate.getTxtCity().sendKeys(getTestString("HomeDelivery.City"));
		orderCreate.getTxtState().sendKeys(getTestString("HomeDelivery.State"));
		orderCreate.getTxtZip().sendKeys(getTestString("HomeDelivery.Zipcode"));
		orderCreate.getTxtNote().sendKeys(getTestString("HomeDelivery.Note"));
		
		String nextDay=getNextDay();
		//String nextDay=getCurrentDay();
		
		orderCreate.getxtDate().clear();
		orderCreate.getxtDate().sendKeys(nextDay);
		orderCreate.getTxtStartTime().click();
		orderCreate.getliStartTimes().get(0).waitForPresent(1000);
		orderCreate.getliStartTimes().get(0).click();
		//PerfectoUtils.selectBoxSelection(orderCreate.getTxtStartTime(),getTestString("HomeDelivery.StartTime"));
		PerfectoUtils.ReportMessage("Entered the Delivery Address Details and Selected Start Time",MessageTypes.Pass);
	}
	
	@QAFTestStep(description = "Click Save Button from Order Create Page")
	public void ClickSaveButtonfromOrderCreatePage() {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		PerfectoUtils.scrolltoelement(orderCreate.getBtnSave());
		orderCreate.getBtnSave().click();
			
		PerfectoUtils.ReportMessage("Clicked the Save Button From Order Create Page",MessageTypes.Pass);
		
		
		//Success message is not validated
	}
	@QAFTestStep(description = "Click Cancel Button from Order Create Page")
	public void ClickCancelButtonfromOrderCreatePage() {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		PerfectoUtils.scrolltoelement(orderCreate.getBtnCancel());
		
		orderCreate.getBtnCancel().click();
		PerfectoUtils.ReportMessage("Clicked the Cancel Button From Order Create Page",MessageTypes.Pass);
		//Success message is not validated
	}
	
	@QAFTestStep(description = "Verify User Selects Store From type ahead")
	public void verifyUserSelectsStoreFromtypeahead() {
		OrderCreateTestPage orderCreate = new OrderCreateTestPage();
		PerfectoUtils.scrolltoelement(orderCreate.getTxtStore());
		orderCreate.getTxtStore().clear();
		orderCreate.getTxtStore().click();
		PerfectoUtils.getDriver().getKeyboard().sendKeys(getTestString("HomeDelivery.StoreNameThreeOrMoreCharac"));
		int storesCount=orderCreate.getliStoreNames().size();
		if(storesCount<=10){
			PerfectoUtils.ReportMessage("Store Suggested from typehead: ",MessageTypes.Info);
			for(QAFWebElement stores : orderCreate.getliStoreNames()){
				PerfectoUtils.ReportMessage(stores.getText());	
			}
			PerfectoUtils.ReportMessage(orderCreate.getliStoreNames().get(0).getText());
			orderCreate.getliStoreNames().get(0).click();
			PerfectoUtils.ReportMessage("User Selected the Store From typeahead in order create page ",MessageTypes.Pass);
		}
		else{
			PerfectoUtils.ReportMessage("Store typehead displayed more than 10 results in order create page ",MessageTypes.Fail);
		}
		
	}
	public static String getexternalID() {
		Random random = new Random();
		char[] digits = new char[6];
		digits[0] = (char) (random.nextInt(4) + '1');
		for (int i = 1; i < 6; i++) {
			digits[i] = (char) (random.nextInt(5) + '0');
		}
		return (new String(digits));
	} 
	
	public static String getNextDay() {
		 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			Calendar cal = Calendar.getInstance();
			System.out.println("Current Date: "+sdf.format(cal.getTime()));
			//Adding 1 Day to the current date
			cal.add(Calendar.DAY_OF_MONTH, 1);  
			//Date after adding one day to the current date
			String newDate = sdf.format(cal.getTime());  
			//Displaying the new Date after addition of 1 Day
			System.out.println("Incremnted current date by one: "+newDate);
		return (new String(newDate));
	} 
	
	public static String getCurrentDay() {
		 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			Calendar cal = Calendar.getInstance();
			System.out.println("Current Date: "+sdf.format(cal.getTime()));
			//Adding 1 Day to the current date
			//cal.add(Calendar.DAY_OF_MONTH, 1);  
			//Date after adding one day to the current date
			String newDate = sdf.format(cal.getTime());  
			//Displaying the new Date after addition of 1 Day
			System.out.println("current date: "+newDate);
		return (new String(newDate));
	} 
	

}

