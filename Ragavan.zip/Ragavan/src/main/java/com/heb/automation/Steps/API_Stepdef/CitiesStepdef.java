package com.heb.automation.Steps.API_Stepdef;
//package com.heb.automation.Services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.aspectj.org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo.AssertionFailedException;
import org.testng.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.ErrorMessages.ErrorMessage;
//import com.heb.automation.Services.BodyParameter.Drivers.Driver_Post;
//import com.heb.automation.Services.BodyParameter.Drivers.Drivers_Body;
//import com.heb.automation.Services.BodyParameter.Drivers.Vehicles_Body;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_Success;
import com.heb.automation.Services.HomeDelivery.ServiceUtils;
//import com.heb.automation.Services.HomeDelivery.Drivers.Drivers_Post;
//import com.heb.automation.Services.HomeDelivery.Drivers.Drivers_RootObject;
import com.heb.automation.Services.HomeDelivery.Zones.City_Data;
import com.heb.automation.Services.HomeDelivery.Search.Post_Search;
import com.heb.automation.Services.HomeDelivery.Search.Post_SearchCriteria;
import com.heb.automation.Services.HomeDelivery.Search.SearchResults_RootObject;
import com.heb.automation.Services.HomeDelivery.Search.SearchResults_ZonesData;
import com.heb.automation.Services.HomeDelivery.Search.SearchResults_SortParameters;
import com.heb.automation.Services.HomeDelivery.Zones.Zones_Data;
import com.heb.automation.Services.HomeDelivery.Zones.Zones_Post;
import com.heb.automation.Services.HomeDelivery.Zones.Zones_RootObject;
import com.heb.automation.Services.HomeDelivery.Cities.Cities_Post;
import com.heb.automation.Services.HomeDelivery.Cities.Cities_Put;
import com.heb.automation.Services.HomeDelivery.Cities.Cities_RootObject;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class CitiesStepdef extends TestDataContainer {

	@QAFTestStep(description = "Build URL for reading HomeDelivery city using cityID")
	public void buildURLForReadHomeDeliveryCityUsingCityID() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getCity") + "/"
				+ getTestString("CityID");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for Creating HomeDelivery City")
	public void buildURLForCreatingHomeDeliveryCity() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getCity");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for Searching HomeDelivery Cities")
	public void buildURLForSearchingHomeDeliveryCities() {
		String baseurl = getTestString("HomeDelivery.adminPortal");		
		String resource = getTestString("HomeDelivery.endpoint.searchCities");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for Delete HomeDelivery City")
	public void buildURLForDeleteHomeDeliveryCity() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getCity") + "/"
				+ getTestString("CityID");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for Delete HomeDelivery City With invalidID")
	public void buildURLForDeletHomeDeliveryCityWithInvalidID() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.getCity") + "/"
				+ getTestString("CityID") + "999";
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for creating HomeDelivery City")
	public void userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryCity() throws JsonProcessingException {

		City_Data city = new City_Data();
		ObjectMapper objm = new ObjectMapper();
		
		city.setArchived(false);
		city.setDriverCount(0);
		city.setHourlyRate(29.29);
		city.setId(null);
		city.setLastModifiedTimestamp(null);
		city.setMapLink("https://www.google.com/maps/place/Aa+Buna+Grill/");
		city.setName(getCityName());
		city.setParkingIdOnfleet("Test-tipsAndTricksIdOnfleet");
		city.setTipsAndTricksIdOnfleet("Test-parkingIdOnfleet");
		String jsonInString = objm.writeValueAsString(city);
		System.out.println("CHoosen Name is  :" + city.getName());
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for searching HomeDelivery City with {0} {1} {2} {3} {4} {5} {6}")
	public void SearchCity(String searchKey, String searchOp, String searchVal, String PgNo, String PgSize, String sortDir, String srtBy) 
			throws JsonProcessingException {

		Post_Search pr = new Post_Search();
		Post_SearchCriteria sc = new Post_SearchCriteria();
		ArrayList<Post_SearchCriteria> bodySc = new ArrayList<Post_SearchCriteria>();
		ObjectMapper objm = new ObjectMapper();
		
		String key = searchKey;
		String operation = searchOp;
		String value = searchVal;
		String pageNumber = PgNo;
		String pageSize = PgSize;
		String sortDirection = sortDir;
		String sortBy = srtBy;
		
		sc.setKey(key);
		sc.setOperation(operation);
		sc.setValue(value);
		bodySc.add(sc);
		
		pr.setPageNumber(pageNumber);
		pr.setPageSize(pageSize);		
		pr.setsortDirection(sortDirection);
		pr.setSortBy(sortBy);		
		pr.setSearchCriteria(bodySc);
		
		String jsonInString = objm.writeValueAsString(pr);
		
		//System.out.println("CHoosen Name is  :" + pr.toString());
		System.out.println("Full search body is : " + jsonInString);
		
		putTestObject("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Some Missing Mandatory Body Parameter for creating HomeDelivery City")
	public void userUsesAnArrayOfSomeMissingMandatoryBodyParameterForCreatingHomeDeliveryCity()
			throws JsonProcessingException {

		
		City_Data city = new City_Data();
		ObjectMapper objm = new ObjectMapper();
		
		city.setArchived(false);
		city.setDriverCount(0);
		city.setHourlyRate(29.29);
		city.setId(null);
		city.setLastModifiedTimestamp(null);
		city.setMapLink("https://www.google.com/maps/place/Aa+Buna+Grill/");
		city.setName(null);
		city.setParkingIdOnfleet("Test-tipsAndTricksIdOnfleet");
		city.setTipsAndTricksIdOnfleet("Test-parkingIdOnfleet");
		//city.setZones(null);

		String jsonInString = objm.writeValueAsString(city);
		System.out.println("CHoosen Name is  :" + city.getName());
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of existing Body Parameter for creating HomeDelivery City")
	public void userUsesAnArrayOfExistingBodyParameterForCreatingHomeDeliveryCity() throws JsonProcessingException {


		City_Data city = new City_Data();
		ObjectMapper objm = new ObjectMapper();
		
		city.setArchived(false);
		city.setDriverCount(0);
		city.setHourlyRate(29.29);
		city.setId(null);
		city.setLastModifiedTimestamp(null);
		city.setMapLink("https://www.google.com/maps/place/Aa+Buna+Grill/");
		city.setName(getTestString("CityName"));
		city.setParkingIdOnfleet("Test-tipsAndTricksIdOnfleet");
		city.setTipsAndTricksIdOnfleet("Test-parkingIdOnfleet");
		//city.setZones(null);
		
		String jsonInString = objm.writeValueAsString(city);
		System.out.println("CHoosen Name is  :" + city.getName());
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery City body parameter contains all valid editable fields")
	public void userUPDATEHomeDeliveryCityBodyParameterContainsAllValidEditableFields()
			throws JsonProcessingException {

		
		City_Data city = new City_Data();
		ObjectMapper objm = new ObjectMapper();
		
		city.setArchived(false);
		city.setDriverCount(0);
		city.setHourlyRate(29.29+1.01);
		city.setId(getTestString("CityID"));
		city.setLastModifiedTimestamp(null);
		city.setMapLink("https://www.google.com/maps/place/Aa+Buna+Grill/");
		city.setName(getTestString("CityName")+"-updated");
		city.setParkingIdOnfleet(getTestString("CityID_ParkingId")+"-put");
		city.setTipsAndTricksIdOnfleet(getTestString("City_TipsAndTricksId")+"-put");

		String jsonInString = objm.writeValueAsString(city);
		System.out.println("CHoosen Name is  :" + city.getName());
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);

	}

	@QAFTestStep(description = "User UPDATE HomeDelivery City body parameter containing all valid editable fields to archived")
	public void userUPDATEHomeDeliveryCityBodyParameterContainingAllValidEditableFieldsToArchived()
			throws JsonProcessingException {

 		City_Data city = new City_Data();
		ObjectMapper objm = new ObjectMapper();
		
		city.setArchived(true);
		city.setDriverCount(0);
		city.setHourlyRate(29.29);
		city.setId(getTestString("CityID"));
		city.setLastModifiedTimestamp(null);
		city.setMapLink("https://www.google.com/maps/place/Aa+Buna+Grill/");
		city.setName(getTestString("CityName")+" archived");
		city.setParkingIdOnfleet(null);
		city.setTipsAndTricksIdOnfleet(null);
		//city.setZones(null);
		
		String jsonInString = objm.writeValueAsString(city);
		System.out.println("CHoosen Name is  :" + city.getName());
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);

	}

	@QAFTestStep(description = "User UPDATE HomeDelivery City body parameter with existing name")
	public void userUPDATEHomeDeliveryCityBodyParameterWithExistingOnfleetID() throws JsonProcessingException {
		City_Data city = new City_Data();
		ObjectMapper objm = new ObjectMapper();
		
		city.setArchived(false);
		city.setDriverCount(0);
		city.setHourlyRate(29.29+1.01);
		city.setId(getTestString("CityID"));
		city.setLastModifiedTimestamp(null);
		city.setMapLink("https://www.google.com/maps/place/Aa+Buna+Grill/");
		city.setName(getTestString("CityName"));
		city.setParkingIdOnfleet(getTestString("CityID_ParkingId")+"-put");
		city.setTipsAndTricksIdOnfleet(getTestString("City_TipsAndTricksId")+"-put");
		//city.setZones(null);
		
		String jsonInString = objm.writeValueAsString(city);
		System.out.println("CHoosen Name is  :" + city.getName());
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}

	//Not Used
	@QAFTestStep(description = "User GET response call for HomeDelivery Cities")
	public static void userGETResponseCallForHomeDeliveryCities() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery cities");
				putTestObject("rClient", rClient);

				Cities_Put gson1 = new Gson().fromJson(rClient.getEntity(String.class),
						Cities_Put.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String cityID = gson1.getData().getId();
				putTestObject("CityID", cityID);
				Reporter.log("Read Success-HomeDelivery City ID: " + cityID);
				System.out.println("Read Success-HomeDelivery City ID: " + cityID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "User POST the Create HomeDelivery City calls")
	public void userPOSTTheCreateHomeDeliveryCityCalls() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			RESPONSE = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + RESPONSE.getStatus());
			if (RESPONSE.getStatus() == 200) {

				Reporter.log("Zone is created ");
				putTestObject("rClient", RESPONSE);

				Zones_Post gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class), Zones_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String ZoneID = gson1.getData().getId();
				//String ZoneName = gson1.getData().getName();
				String ZoneOnfleetID2 = gson1.getData().getexternalIdOnfleet();
				putTestObject("ZoneID", ZoneID);
				//putTestObject("ZoneName", ZoneName);
				putTestObject("ZoneOnfleetID2", ZoneOnfleetID2);
				Reporter.log("Created Success-HomeDelivery Zone ID: " + ZoneID);
				//Reporter.log("Created Success-HomeDelivery Zone Name: " + ZoneName);
				Reporter.log("Created Success-HomeDelivery Zone OnfleetID: " + ZoneOnfleetID2);
				System.out.println("Created Success-HomeDelivery Zone ID: " + ZoneID);
				//System.out.println("Created Success-HomeDelivery Zone Name: " + ZoneName);
				System.out.println("Created Success-HomeDelivery Zone OnfleetID: " + ZoneOnfleetID2);
			}
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("Zone creation failed with " + 400);
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 503) {
				Reporter.log("Zone creation failed with " + 503);
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User POST the Create HomeDelivery City call")
	public void userPOSTTheCreateHomeDeliveryCityCall() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			RESPONSE = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + RESPONSE.getStatus());
			if (RESPONSE.getStatus() == 200) {

				Reporter.log("City is created ");
				putTestObject("rClient", RESPONSE);

				//Cities_Post gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class), Cities_Post.class);
				HomeDelivery_Success gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class), HomeDelivery_Success.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				//String CityID = gson1.getData().getId();
				String CityID = gson1.getData();
				//String CityName = gson1.getData().getName();
				//String CityOnfleetID = gson1.getData().getexternalIdOnfleet();
				putTestObject("CityID", CityID);
				//putTestObject("CityName", CityName);
				//putTestObject("CityOnfleetID", CityOnfleetID);
				Reporter.log("Created Success-HomeDelivery City ID: " + CityID);
				//Reporter.log("Created Success-HomeDelivery City Name: " + CityName);
				//Reporter.log("Created Success-HomeDelivery City OnfleetID: " + CityOnfleetID);
				System.out.println("Created Success-HomeDelivery City ID: " + CityID);
				//System.out.println("Created Success-HomeDelivery City Name: " + CityName);
				//System.out.println("Created Success-HomeDelivery City OnfleetID: " + CityOnfleetID);
			}
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("City created with failed  " + 400);
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 503) {
				Reporter.log("City creation failed with " + 503);
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 500) {
				Reporter.log("City creation failed with " + 500);
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User POST the Search HomeDelivery City call")
	public void userPOSTTheSearchHomeDeliveryCityCall() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			RESPONSE = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + RESPONSE.getStatus());
			if (RESPONSE.getStatus() == 200) {

				Reporter.log("City is created "); 
				putTestObject("rClient", RESPONSE);

				SearchResults_RootObject gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class), SearchResults_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String searchResultsCount = gson1.getData().getTotalElements();
					//String ZoneName = gson1.getData().getName();
					//String ZoneOnfleetID = gson1.getData().getexternalIdOnfleet();
				putTestObject("searchResultsCount", searchResultsCount);
					//putTestObject("ZoneName", ZoneName);
					//putTestObject("ZoneOnfleetID", ZoneOnfleetID);
				Reporter.log("Search Success- Search Results Count : " + searchResultsCount);
					//Reporter.log("Created Success-HomeDelivery Zone Name: " + ZoneName);
					//Reporter.log("Created Success-HomeDelivery Zone OnfleetID: " + ZoneOnfleetID);
				System.out.println("Search Success- Search Results Count : " + searchResultsCount);
					//System.out.println("Created Success-HomeDelivery Zone Name: " + ZoneName);
					//System.out.println("Created Success-HomeDelivery Zone OnfleetID: " + ZoneOnfleetID);
			}
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("City creation failed with " + 400);
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 503) {
				Reporter.log("City creation failed with " + 503);
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	//Not Used
	@QAFTestStep(description="User uses batch POST to Create Multiple HomeDelivery Cities {0}")
	public void userUsesBatchPOSTToCreateMultipleHomeDeliveryCities(int batchCount){
		int batchPostCount = batchCount;
		//String[] dispatcherID = new String[batchPostCount];
		List<String> zoneID = new ArrayList<>();
		
		for (int i=1; i<=batchPostCount; i++) {
			
			try {
				
				userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryCity();  	//Zone
				userPOSTTheCreateHomeDeliveryCityCall();						//Zone
				
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			
			//dispatcherID[i] = getTestString("DispatcherID");
			zoneID.add(getTestString("ZoneID"));
			System.out.println("Zone is :" + zoneID);
			
		}
		
		putTestObject("ZoneIDList", zoneID);		
		System.out.println("Final Zone is :" + getTestObject("ZoneIDList"));
	}
	
	
	@QAFTestStep(description = "User GET response call for Specific HomeDelivery city")
	public static void userGETResponseCallForSpecificHomeDeliveryCity() {

		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			RESPONSE = ServiceUtils.GET(headers);
			Reporter.log("Status :" + RESPONSE.getStatus());
			Reporter.log("rClient list is : " + RESPONSE.getStatusInfo());
			putTestObject("rClient", RESPONSE);

			if (RESPONSE.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery cuties");
				putTestObject("rClient", RESPONSE);

				Cities_Put gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class), Cities_Put.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String CityID = gson1.getData().getId();
				String CityName = gson1.getData().getName();
				String CityTipsAndTricksId = gson1.getData().getTipsAndTricksIdOnfleet();
				String CityParkingId = gson1.getData().getTipsAndTricksIdOnfleet();
				boolean archived = gson1.getData().getArchived();
				putTestObject("CityID", CityID);
				putTestObject("CityName", CityName);
				putTestObject("CityID_isArchived", archived);
				putTestObject("City_TipsAndTricksId", CityTipsAndTricksId);
				putTestObject("CityID_ParkingId", CityParkingId);
				Reporter.log("Read Success-HomeDelivery City ID: " + CityID);
				Reporter.log("Read Success-HomeDelivery City Name: " + CityName);
				System.out.println("Read Success-HomeDelivery City ID: " + CityID);
				System.out.println("Read Success-HomeDelivery City Name: " + CityName);
				System.out.println("Read Success-HomeDelivery City ID archived: " + archived);
				System.out.println("Read Success-HomeDelivery City TipsAndTricks ID: " + CityTipsAndTricksId);
				System.out.println("Read Success-HomeDelivery City Parking ID: " + CityParkingId);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = RESPONSE.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(RESPONSE.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}
	

	@QAFTestStep(description = "User PUT the Update HomeDelivery City call")
	public void userPUTTheUpdateHomeDeliveryCityCall() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			RESPONSE = ServiceUtils.PUT(headers, bodyParam);
			Reporter.log("Status :" + RESPONSE.getStatus());
			if (RESPONSE.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery City is updated ");
				putTestObject("rClient", RESPONSE);

				Cities_Put gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class), Cities_Put.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String cityID = gson1.getData().getId();
				String updatedCityName = gson1.getData().getName();
					//String[] updatedZipCodes = gson1.getData().getZipCodes();
				putTestObject("CityID", cityID);
				putTestObject("Updated_CityName",updatedCityName);
					//putTestObject("Updated_CityZipCodes", updatedZipCodes.toString());
				Reporter.log("Update Success-HomeDelivery City ID: " + cityID);
				Reporter.log("Update Success-HomeDelivery City Name: " + updatedCityName);
					//Reporter.log("Update Success-HomeDelivery City ZipCodes: " + updatedZipCodes.toString());
				System.out.println("Update Success-HomeDelivery City ID: " + cityID);
				System.out.println("Update Success-HomeDelivery City Name: " + updatedCityName);
					//System.out.println("Update Success-HomeDelivery City ZipCodes: " + updatedZipCodes.toString());
			}
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("HomeDelivery City updation failed  ");
				putTestObject("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 404) {
				Reporter.log("HomeDelivery City updation failed  ");
				putTestObject("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 401) {
				Reporter.log("HomeDelivery City updation failed  ");
				putTestObject("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 500) {
				Reporter.log("HomeDelivery City updation failed  ");
				Reporter.log(RESPONSE.toString());
				putTestObject("rClient", RESPONSE);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User DELETE the HomeDelivery City")
	public void userDELETETheHomeDeliveryCity() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			RESPONSE = ServiceUtils.DELETE(headers, bodyParam);
			Reporter.log("Status :" + RESPONSE.getStatus());
			if (RESPONSE.getStatus() == 200) {

				Reporter.log("HomeDelivery City is deleted ");
				putTestObject("rClient", RESPONSE);

				HomeDelivery_Success gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class),
						HomeDelivery_Success.class);
				putTestObject("rGSON", gson1);
				System.out.println(" : " + gson1.getApiStatus());
				Reporter.log("Deleted HomeDelivery City : " + gson1.getApiStatus());
			}
			if (RESPONSE.getStatus() == 207) {
				Reporter.log("HomeDelivery City Deleted with Partial success  ");
				putTestObject("rClient", RESPONSE);
				ErrorMessage gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class), ErrorMessage.class);
				putTestObject("rGSON", gson1);
			}

			if (RESPONSE.getStatus() == 400) {
				Reporter.log("HomeDelivery City Deletion failed with 400");
				putTestObject("rClient", RESPONSE);
			}

			if (RESPONSE.getStatus() == 404) {
				Reporter.log("HomeDelivery City Deletion failed with 404");
				putTestObject("rClient", RESPONSE);
			}
			
			if (RESPONSE.getStatus() == 401) {
				Reporter.log("HomeDelivery City Deletion failed with 401");
				putTestObject("rClient", RESPONSE);
			}
			
			if (RESPONSE.getStatus() == 503) {
				Reporter.log("HomeDelivery City Deletion failed with 503");
				putTestObject("rClient", RESPONSE);
			}
			
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("HomeDelivery City Deletion failed with 400");
				putTestObject("rClient", RESPONSE);
			}

		}
	}

	public static String getName() {
		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 10;
		
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();

		return "automation" + generatedString;
	}

	public static String getCityName() {
		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 10;
		
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();

		return "Test City Atmn" + generatedString;
	}
	
	public static String getNameMoreThan101Characters() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "Automation zone name more than 101 characters in length should return an exception "
				+ name.substring(3, name.length());

	}

	public static String generateRandom() {
		Random random = new Random();
		char[] digits = new char[5];
		digits[0] = (char) (random.nextInt(4) + '1');
		for (int i = 1; i < 5; i++) {
			digits[i] = (char) (random.nextInt(5) + '0');
		}
		return "83075" + (new String(digits));
	}

	public static String generateRandomInvalidFormat() {
		Random random = new Random();
		char[] digits = new char[5];
		digits[0] = (char) (random.nextInt(4) + '1');
		for (int i = 1; i < 5; i++) {
			digits[i] = (char) (random.nextInt(5) + '0');
		}
		return "+1-830-75" + (new String(digits));
	}
	
	@QAFTestStep(description = "Validate success of the HomeDelivery City deletion")
	public void validateSuccessOfTheHomeDeliveryCityDeletion() throws Exception {

/*		ClientResponse rClient = (ClientResponse) getTestObject("rClient");
		CommonUtils.getAllStatusupdates(rClient);
		HomeDelivery_ReusableUtils.compareHomeDeliveryZoneActualandExpected();*/
		
		boolean validateArchived = (boolean) getTestObject("CityID_isArchived");
	
		try {
			
			Assert.assertEquals(validateArchived, true);
			Reporter.log("City deleted successfully!", MessageTypes.Pass);
			
		} catch (AssertionFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
	
	}

	@QAFTestStep(description = "Validate failure of the HomeDelivery City deletion")
	public void validateFailureOfTheHomeDeliveryCityDeletion() throws Exception {

		/*		ClientResponse rClient = (ClientResponse) getTestObject("rClient");
		CommonUtils.getAllStatusupdates(rClient);
		HomeDelivery_ReusableUtils.compareHomeDeliveryZoneActualandExpected();*/
		
		boolean validateArchived = (boolean) getTestObject("ZoneID_isArchived");
	
		try {
			
			Assert.assertEquals(validateArchived, false);
			Reporter.log("Zone not deleted successfully!", MessageTypes.Pass);
			
		} catch (AssertionFailedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}

	}

	//Not Used
	@QAFTestStep(description = "validate the response schema with GET Cities")
	public static void validateTheResponseSchemaWithGETCities() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery zones");
				putTestObject("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");

				Zones_RootObject gson1 = new Gson().fromJson(RESPONSE,
						Zones_RootObject.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String zoneID = gson1.getData().get(0).getId();
				putTestObject("ZoneID", zoneID);
				Reporter.log("Read Success-HomeDelivery Zone ID: " + zoneID);
				System.out.println("Read Success-HomeDelivery Zone ID: " + zoneID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "GET_ZONES");
				HomeDelivery_ReusableUtils.validateJSONschema("Zones_GET", "GET_ZONES");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);
		}
	}
	
	//Not Used
	@QAFTestStep(description = "validate the response schema with POST City")
	public void validateTheResponseSchemaWithPOSTCity() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {

				Reporter.log("Zones is created ");
				putTestObject("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");

				Zones_Post gson1 = new Gson().fromJson(RESPONSE, Zones_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String zoneID = gson1.getData().getId();
				putTestObject("ZoneID", zoneID);
				Reporter.log("Created Success-HomeDelivery Zone ID: " + zoneID);
				System.out.println("Created Success-HomeDelivery Zone ID: " + zoneID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "POST_ZONE");
				HomeDelivery_ReusableUtils.validateJSONschema("Zone_POST", "POST_ZONE");
				
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Zone created with failed  " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	//Not Used
	@QAFTestStep(description = "validate the response schema with PUT City")
	public void validateTheResponseSchemaWithPUTCity() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			rClient = ServiceUtils.PUT(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Zone is updated ");
				putTestObject("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");

				Zones_Post gson1 = new Gson().fromJson(RESPONSE, Zones_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String zoneID = gson1.getData().getId();
				//String PhoneNum = gson1.getData().getPhone();
				putTestObject("ZoneID", zoneID);
				//putTestObject("PhoneNum", PhoneNum);
				Reporter.log("Created Success-HomeDelivery Zone ID: " + zoneID);
				System.out.println("Created Success-HomeDelivery Zone ID: " + zoneID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "PUT_ZONE");
				HomeDelivery_ReusableUtils.validateJSONschema("Zone_PUT", "PUT_ZONE");
				
			}
			if (rClient.getStatus() != 200) {
				Reporter.log("HomeDelivery Zone created with failed  ",MessageTypes.Fail);
				putTestObject("rClient", rClient);

			}

		} catch (Exception e) {

			Reporter.log("Exceptions :" + e,MessageTypes.Fail);
		}
	}
	
	//Not Used
	@QAFTestStep(description = "validate the response schema with GET City")
	public static void validateTheResponseSchemaWithGETCity() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("Status :" + rClient.getStatus());
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);
			
			String RESPONSE = rClient.getEntity(String.class);
			putTestObject(RESPONSE, "RESPONSE");

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery zones");
				putTestObject("rClient", rClient);

				Zones_Post gson1 = new Gson().fromJson(RESPONSE, Zones_Post.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String zoneID = gson1.getData().getId();
				putTestObject("ZoneID", zoneID);
				Reporter.log("Read Success-HomeDelivery Zone ID: " + zoneID);
				System.out.println("Read Success-HomeDelivery Zone ID: " + zoneID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "GET_ZONE");
				HomeDelivery_ReusableUtils.validateJSONschema("Zone_GET", "GET_ZONE");
			}
			if (rClient.getStatus() != 200) {
				Reporter.log("HomeDelivery Zone created with failed  ",MessageTypes.Fail);
				putTestObject("rClient", rClient);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}

}
