package com.heb.automation.Services.HomeDelivery.Search;

import java.util.ArrayList;

import com.heb.automation.Services.HomeDelivery.Zones.Zones_Data;

public class SearchResults_ZonesData {

	    private ArrayList<Zones_Data> content = new ArrayList<Zones_Data>();
	    
	    private String totalPages;
	    
	    private String totalElements;
	    
	    private String last;
	    
	    private String numberOfElements;
	    
	    private ArrayList<SearchResults_SortParameters> sort = new ArrayList<SearchResults_SortParameters>();
	    
	    private String size;
	    
	    private String number;
	    
	    private String first;
	    	    

	    public ArrayList<Zones_Data> getData ()
	    {
	        return content;
	    }

	    public void setData (ArrayList<Zones_Data> content)
	    {
	        this.content = content;
	    }
	    
	    public String getTotalPages() {
			return totalPages;
		}

		public void setTotalPages(String totalPages) {
			this.totalPages = totalPages;
		}

		public String getTotalElements() {
			return totalElements;
		}

		public void setTotalElements(String totalElements) {
			this.totalElements = totalElements;
		}

		public String getLast() {
			return last;
		}

		public void setLast(String last) {
			this.last = last;
		}

		public String getNumberOfElements() {
			return numberOfElements;
		}

		public void setNumberOfElements(String numberOfElements) {
			this.numberOfElements = numberOfElements;
		}

		public ArrayList<SearchResults_SortParameters> getSort() {
			return sort;
		}

		public void setSort(ArrayList<SearchResults_SortParameters> sort) {
			this.sort = sort;
		}

		public String getSize() {
			return size;
		}

		public void setSize(String size) {
			this.size = size;
		}

		public String getNumber() {
			return number;
		}

		public void setNumber(String number) {
			this.number = number;
		}

		public String getFirst() {
			return first;
		}

		public void setFirst(String first) {
			this.first = first;
		}

		@Override
	    public String toString()
	    {
	        return "ClassPojo [content = "+content+", totalPages = "+totalPages+", totalElements = "+totalElements+", last = "+last+", numberOfElements = "+numberOfElements+", sort = "+sort+", size = "+size+", number = "+number+", first = "+first+"]";
	    }
}
