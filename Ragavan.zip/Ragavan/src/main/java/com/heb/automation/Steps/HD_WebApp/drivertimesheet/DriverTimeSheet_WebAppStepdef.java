package com.heb.automation.Steps.HD_WebApp.drivertimesheet;

import java.nio.file.ProviderNotFoundException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Date;

import com.heb.automation.Pages.HD_WebApp.CommonTestPage;
import com.heb.automation.Pages.HD_WebApp.driver.DriverTestPage;
import com.heb.automation.Pages.HD_WebApp.drivertimesheet.DriverTimeSheetTestPage;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class DriverTimeSheet_WebAppStepdef extends TestDataContainer {
	
	@QAFTestStep(description = "navigate to drivers timesheet page")
	public void nAvigateToDriversTimesheetPage() {
		CommonTestPage common = new CommonTestPage();
		
		common.getNavigationBtnHamburger().click();
		common.getNavigationLblDriverSnapshot().waitForPresent(1000);
		common.getNavigationLblDriver().click();
		common.getNavigationLblDriverTimeSheet().waitForPresent();
		common.getNavigationLblDriverTimeSheet().click();
	}
	
	@QAFTestStep(description = "verify the drivers timesheet page search section")
	public void vErifyTheDriversTimesheetPageSearchSection() {
		DriverTimeSheetTestPage driverTimeSheet = new DriverTimeSheetTestPage();
		CommonTestPage common = new CommonTestPage();
		
		driverTimeSheet.getLblTitle().waitForPresent(5000);
		driverTimeSheet.getLblTitle().verifyPresent();
		driverTimeSheet.getBtnDriverCrump().verifyPresent();
		driverTimeSheet.getBtnDriverTimeSheetCrump().verifyPresent();
		driverTimeSheet.getLblFirstName().verifyPresent();
		driverTimeSheet.getLblLastName().verifyPresent();
//		driverTimeSheet.getLblSelectADate().verifyPresent();
		driverTimeSheet.getTxtFirstName().verifyPresent();
		driverTimeSheet.getTxtLastName().verifyPresent();
        driverTimeSheet.getTxtShiftStartDate().verifyPresent();
        driverTimeSheet.getTxtShiftEndDate().verifyPresent();

		driverTimeSheet.getBtnCalendarIcon().verifyPresent();
		driverTimeSheet.getBtnAddNew().verifyPresent();
		driverTimeSheet.getBtnSearch().verifyPresent();
		
		common.getLblHomeIcon().verifyPresent();
		common.getLblHomeRightArrow().verifyPresent();
		
	}
	
	@QAFTestStep(description = "verify date field defaults to current date in driver timesheet page")
	public void vErifyDateFieldDefaultsToCurrentDateInDriverTimeSheetPage() throws ParseException {
		String Currentdate = null;
		DriverTimeSheetTestPage driverTimeSheet = new DriverTimeSheetTestPage();

		Currentdate = driverTimeSheet.getTxtShiftStartDate().getAttribute("value");	
		String displayedDate = beginDisplayDate(Currentdate);
	
		SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy");
		Date date = new Date();
		LocalDate WeekStartDate = beginDayTheWeek(formatter.format(date));

		if (displayedDate.equals(WeekStartDate.toString()))
			PerfectoUtils.reportMessage("The date field is default To CurrentWeek", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("The date field is not default To CurrentWeek", MessageTypes.Fail);
	}
	
	@QAFTestStep(description = "verify selected week displays the begin and end date of the week for selected date")
	public void vErifySelectedWeekDisplaysTheBeginAndEndDateOfTheWeekForSelectedDate() throws ParseException {
		DriverTimeSheetTestPage driverTimeSheet = new DriverTimeSheetTestPage();
		
		String selectedDate = getTestString("SelectedDate");
		
		String beginDay = beginDayTheWeek(selectedDate).toString();
		String endDay = endDayTheWeek(selectedDate).toString();
				
        String shiftStart = driverTimeSheet.getTxtShiftStartDate().getAttribute("value");
        String shiftEnd = driverTimeSheet.getTxtShiftEndDate().getAttribute("value");
        String beginDisplay = beginDisplayDate(shiftStart);
        String endDisplay = endDisplayDate(shiftEnd);

		
		if (beginDay.equals(beginDisplay)){
			PerfectoUtils.reportMessage("Selected week displays the begin of the week for selected date", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected week displays the begin of the week for selected date", MessageTypes.Fail);
		}
		
		if (endDay.equals(endDisplay)){
			PerfectoUtils.reportMessage("Selected week displays the end of the week for selected date", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected week displays the end of the week for selected date", MessageTypes.Fail);
		}
	}
	
	public LocalDate beginDayTheWeek(String selectedDate) throws ParseException{
		
		DateFormat srcDf = new SimpleDateFormat("M/d/yyyy");	
		Date date = srcDf.parse(selectedDate);	
		DateFormat destDf = new SimpleDateFormat("yyyy-MM-dd");
		String dateStr1 = destDf.format(date);
		
		LocalDate today = LocalDate.parse(dateStr1);
	    LocalDate monday = today;
	    while (monday.getDayOfWeek() != DayOfWeek.MONDAY)
	    {
	      monday = monday.minusDays(1);
	    }
		
	return monday;
		
	}
	
	public LocalDate endDayTheWeek(String selectedDate) throws ParseException{
		
		DateFormat srcDf = new SimpleDateFormat("M/d/yyyy");	
		Date date = srcDf.parse(selectedDate);	
		DateFormat destDf = new SimpleDateFormat("yyyy-MM-dd");
		String dateStr1 = destDf.format(date);
		
		 LocalDate today = LocalDate.parse(dateStr1);
		 LocalDate sunday = today;
		    while (sunday.getDayOfWeek() != DayOfWeek.SUNDAY)
		    {
		      sunday = sunday.plusDays(1);
		    }
		    
		return sunday;		
		}
	
	public String beginDisplayDate(String selectedDate) throws ParseException{
	
		DateFormat srcDf = new SimpleDateFormat("M/d/yyyy");	
		Date date = srcDf.parse(selectedDate);
		DateFormat destDf = new SimpleDateFormat("yyyy-MM-dd");

		String dateStr1 = destDf.format(date);	
		return dateStr1;	
	}
	
	public String endDisplayDate(String selectedDate) throws ParseException{
		
		DateFormat srcDf = new SimpleDateFormat("M/d/yyyy");	
		Date date = srcDf.parse(selectedDate);	
		DateFormat destDf = new SimpleDateFormat("yyyy-MM-dd");

		String dateStr1 = destDf.format(date);	
		return dateStr1;	
	}
	
	@QAFTestStep(description = "click on calendar icon in driver timesheet page")
	public void cLickOnCalendarIconInDriverTimesheetPage() {		
		DriverTimeSheetTestPage driverTimeSheet = new DriverTimeSheetTestPage();
		
		String defaultDate = driverTimeSheet.getTxtShiftStartDate().getAttribute("value");
		putTestObject("DEFAULTDate", defaultDate);
		
		driverTimeSheet.getBtnCalendarIcon().click();
		driverTimeSheet.getBtnPreviousMonth().waitForPresent(1000);
	}
	
	@QAFTestStep(description = "select past date in calendar")
	public void sElectPastDateInCalendar() {
		String Currentdate = null;
		DriverTimeSheetTestPage driverTimeSheet = new DriverTimeSheetTestPage();
		
		driverTimeSheet.getBtnPreviousMonth().click();
		driverTimeSheet.getLblDates().get(0).waitForPresent(1000);
		driverTimeSheet.getLblDates().get(0).click();
		Currentdate = driverTimeSheet.getTxtShiftStartDate().getAttribute("value");
		putTestObject("SelectedDate", Currentdate);	
	}
	
	@QAFTestStep(description = "verify able to enter past date in date field")
	public void vErifyAbleToEnterPastDateInDateField() {
		
		String beforeChagedate = getTestString("DEFAULTDate");
		String afterChagedate = getTestString("SelectedDate");
		
		if (!beforeChagedate.equals(afterChagedate))
			PerfectoUtils.reportMessage("Able to enter past date in date field", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not able to enter past date in date field", MessageTypes.Fail);
	}
	
	@QAFTestStep(description = "select future date in calendar")
	public void sElectFutureDateInCalendar() {
		String Currentdate = null;
		DriverTimeSheetTestPage driverTimeSheet = new DriverTimeSheetTestPage();
		
		driverTimeSheet.getBtnNextMonth().waitForPresent(1000);
		driverTimeSheet.getBtnNextMonth().click();
		driverTimeSheet.getLblDates().get(0).waitForPresent(1000);
		driverTimeSheet.getLblDates().get(0).click();
		driverTimeSheet.getBtnCalendarIcon().click();
		driverTimeSheet.getBtnNextMonth().waitForPresent(1000);
		driverTimeSheet.getBtnNextMonth().click();
		driverTimeSheet.getLblDates().get(0).waitForPresent(1000);
		driverTimeSheet.getLblDates().get(0).click();
		Currentdate = driverTimeSheet.getTxtShiftStartDate().getAttribute("value");
		putTestObject("SelectedDate", Currentdate);	
	}
	
	@QAFTestStep(description = "verify able to enter future date in Date field")
	public void vErifyAbleToEnterFutureDateInDateField() {
		
		String beforeChagedate = getTestString("DEFAULTDate");
		String afterChagedate = getTestString("SelectedDate");
		
		if (!beforeChagedate.equals(afterChagedate))
			PerfectoUtils.reportMessage("Able to enter future date in Date field", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not able to enter future date in Date field", MessageTypes.Fail);
	}
	
	@QAFTestStep(description = "enter valid FirstName with 3 Characters in driver timesheet page")
	public void eNterValidFirstNameWith3CharactersInDriverTimeSheetPage() {
		DriverTimeSheetTestPage driverTimeSheet = new DriverTimeSheetTestPage();
		
		driverTimeSheet.getTxtFirstName().waitForPresent(5000);
		driverTimeSheet.getTxtFirstName().click();
		driverTimeSheet.getTxtFirstName().sendKeys(getTestString("HomeDelivery.FirstName3Characters"));
	}
	
	
	@QAFTestStep(description = "enter valid LastName with 3 Characters in driver timesheet page")
	public void eNterValidLastNameWith3CharactersInDriverTimesheetPage() {
		DriverTimeSheetTestPage driverTimeSheet = new DriverTimeSheetTestPage();
		
		driverTimeSheet.getTxtLastName().waitForPresent(5000);
		driverTimeSheet.getTxtLastName().click();
		driverTimeSheet.getTxtLastName().sendKeys(getTestString("HomeDelivery.FirstName3Characters"));
	}
	
	@QAFTestStep(description = "verify user is able to make a selection from typeahead for First Name")
	public void vErifyUserIsAbleToMakeASelectionFromTypeaheadForFirstName() {
		DriverTimeSheetTestPage driverTimeSheet = new DriverTimeSheetTestPage();
		
		String fName = driverTimeSheet.getTxtFirstName().getAttribute("value");
		
		if(fName.equals(getTestString("FirstNameTypeAh")))
			PerfectoUtils.reportMessage("User is able to make a selection from typeahead for First Name", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("User is not able to make a selection from typeahead for First Name", MessageTypes.Fail);
	}
	
	@QAFTestStep(description = "verify user is able to make a selection from typeahead for Last Name")
	public void vErifyUserIsAbleToMakeASelectionFromTypeaheadForLastName() {
		DriverTimeSheetTestPage driverTimeSheet = new DriverTimeSheetTestPage();
		
		String lName = driverTimeSheet.getTxtLastName().getAttribute("value");
		
		if(lName.equals(getTestString("FirstNameTypeAh")))
			PerfectoUtils.reportMessage("User is able to make a selection from typeahead for Last Name", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("User is not able to make a selection from typeahead for Last Name", MessageTypes.Fail);
	}
	
	@QAFTestStep(description = "click on driver crumb in driver timesheet page")
	public void cLickOnDriverCrumbInDriverTimeSheetPage() {
		DriverTimeSheetTestPage driverTimeSheet = new DriverTimeSheetTestPage();	
		driverTimeSheet.getBtnDriverCrump().click();
	}
	
	@QAFTestStep(description = "click on driver timesheet crumb")
	public void cLickOnDriverTimesheetCrumb() {
		DriverTimeSheetTestPage driverTimeSheet = new DriverTimeSheetTestPage();	
		driverTimeSheet.getBtnDriverTimeSheetCrump().click();
	}
	
	@QAFTestStep(description = "verify user navigate to driver timesheet page")
	public void vErifyUserNavigateToDriverTimesheetPage() {
		DriverTimeSheetTestPage driverTimeSheet = new DriverTimeSheetTestPage();	
		
		driverTimeSheet.getLblTitle().waitForPresent(5000);
		driverTimeSheet.getLblTitle().verifyPresent();
	}
	
    @QAFTestStep(description = "select default display date")
    public void sElectDefaultDisplayDate() {
        String Currentdate = null;
        DriverTimeSheetTestPage driverTimeSheet = new DriverTimeSheetTestPage();

        Currentdate = driverTimeSheet.getTxtShiftStartDate().getAttribute("value");    
        ConfigurationManager.getBundle().setProperty("SelectedDate", Currentdate);
    }

}
