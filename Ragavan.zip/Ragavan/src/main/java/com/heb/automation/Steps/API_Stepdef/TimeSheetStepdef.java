package com.heb.automation.Steps.API_Stepdef;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.ErrorMessages.ErrorMessage;
import com.heb.automation.Services.BodyParameter.Teams.Teams_Body;
import com.heb.automation.Services.BodyParameter.TimeSheet.TimeSheetSearch_Body;
import com.heb.automation.Services.BodyParameter.TimeSheet.TimeSheet_Body;
import com.heb.automation.Services.BodyParameter.TimeSheet.TimeSheet_BodyDriver;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_Success;
import com.heb.automation.Services.HomeDelivery.ServiceUtils;
import com.heb.automation.Services.HomeDelivery.Teams.Teams_Post;
import com.heb.automation.Services.HomeDelivery.Teams.Teams_RootObject;
import com.heb.automation.Services.HomeDelivery.TimeSheet.TimeSheetSearch_Root;
import com.heb.automation.Services.HomeDelivery.TimeSheet.TimeSheet_Root;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class TimeSheetStepdef extends TestDataContainer {

	@QAFTestStep(description = "Build URL for Creating HomeDelivery TimeSheets")
	public void bUildURLForCreatingHomeDeliveryTimeSheets() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.timeSheets");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for read specific HomeDelivery TimeSheet")
	public void bUildURLForReadSpecificHomeDeliveryTimeSheet() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.timeSheets")+"/"+getTestString("TimeSheetID");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for read invalid HomeDelivery TimeSheet")
	public void bUildURLForReadInvalidHomeDeliveryTimeSheet() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.timeSheets")+"/"+getTestString("timeSheet.InvalidTimeSheetId");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for Searching HomeDelivery TimeSheets")
	public void bUildURLForSearchingHomeDeliveryTimeSheets() {
		String baseurl = getTestString("HomeDelivery.adminPortal");
		String resource = getTestString("HomeDelivery.endpoint.SearchTimeSheet");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter for searching HomeDelivery TimeSheets with multiple search criteria")
	public void userUsesAnArrayOfBodyParameterForSearchingHomeDeliveryTimeSheetsWithMultipleSearchCriteria() throws JsonProcessingException {

		TimeSheetSearch_Body pr = new TimeSheetSearch_Body();
		ObjectMapper objm = new ObjectMapper();


		pr.setStartOfWeek(getTestString("timeSheet.SearchStartOfWeek"));
		pr.setDriverFirstName(getTestString("timeSheet.SearchFirstName"));
		pr.setDriverLastName(getTestString("timeSheet.SearchLastName"));

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);
		putTestObject("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter for creating HomeDelivery TimeSheets")
	public void uSerUsesAnArrayOfBodyParameterForCreatingHomeDeliveryTimeSheets() throws JsonProcessingException {

		TimeSheet_Body pr = new TimeSheet_Body();
		TimeSheet_BodyDriver dr = new TimeSheet_BodyDriver();
		ObjectMapper objm = new ObjectMapper();

		pr.setDate(getFutureDate());
		dr.setId(getTestString("timeSheet.DriverId"));
		pr.setDriver(dr);
		pr.setEndTime(getIncreaseTimeStamp());
		pr.setStartTime(getTimeStamp());

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);
		putTestObject("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter with invalid driver ID for creating HomeDelivery TimeSheets")
	public void uSerUsesAnArrayOfBodyParameterWithInvalidDriverIDForCreatingHomeDeliveryTimeSheets() throws JsonProcessingException {

		TimeSheet_Body pr = new TimeSheet_Body();
		TimeSheet_BodyDriver dr = new TimeSheet_BodyDriver();
		ObjectMapper objm = new ObjectMapper();

		pr.setDate(getFutureDate());
		dr.setId(getTestString("timeSheet.InvalidDriverId"));
		pr.setDriver(dr);
		pr.setEndTime(getTestString("timeSheet.EndTime"));
		pr.setStartTime(getTestString("timeSheet.StartTime"));

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);
		putTestObject("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User UPDATE HomeDelivery TimeSheet body parameter")
	public void userUPDATEHomeDeliveryTimeSheetBodyParameter() throws JsonProcessingException {

		TimeSheet_Body pr = new TimeSheet_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setEndTime(getTestString("timeSheet.UpdateEndTime"));
		pr.setStartTime(getTestString("timeSheet.UpdateStartTime"));

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User UPDATE HomeDelivery TimeSheet body parameter with out Start and End Time")
	public void userUPDATEHomeDeliveryTimeSheetBodyParameterWithOutStartAndEndTime() throws JsonProcessingException {

		TimeSheet_Body pr = new TimeSheet_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setEndTime("");
		pr.setStartTime("");

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		putTestObject("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User POST the Create HomeDelivery TimeSheet call")
	public void userPOSTTheCreateHomeDeliveryTimeSheetCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			if (rClient.getStatus() == 200) {

				Reporter.log("TimeSheet is created ");
				putTestObject("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				TimeSheet_Root gson = new Gson().fromJson(RESPONSE, TimeSheet_Root.class);
				Arrays.asList(gson);
				putTestObject("rGSON", gson);
				String TimeSheetID = gson.getData().getId();
				putTestObject("TimeSheetID", TimeSheetID);
				Reporter.log("Created Success-HomeDelivery TimeSheetID: " + TimeSheetID);
				System.out.println("Created Success-HomeDelivery TimeSheetID: " + TimeSheetID);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("TimeSheet created with failed  " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("TimeSheet created with failed  " + 503);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	@QAFTestStep(description = "User POST the Search HomeDelivery TimeSheet call")
	public void userPOSTTheSearchHomeDeliveryTimeSheetCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			if (rClient.getStatus() == 200) {

				Reporter.log("TimeSheet is created ");
				putTestObject("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				TimeSheetSearch_Root gson = new Gson().fromJson(RESPONSE, TimeSheetSearch_Root.class);
				Arrays.asList(gson);
				putTestObject("rGSON", gson);
				String driverFirstName = gson.getData().get(0).getDriverFirstName();
				String driverLasttName = gson.getData().get(0).getDriverLastName();
				String TimeSheetID = gson.getData().get(0).getTimesheets().get(0).getId();	
				putTestObject("DriverFirstName", driverFirstName);
				putTestObject("DriverFirstName", driverLasttName);
				putTestObject("TimeSheetID", TimeSheetID);
				Reporter.log("Searched Success-HomeDelivery TimeSheetID: " + TimeSheetID);
				System.out.println("Searched Success-HomeDelivery TimeSheetID: " + TimeSheetID);				
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("TimeSheet Search failed  " + 400);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("TimeSheet Search failed  " + 503);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	@QAFTestStep(description = "Validate the response schema with POST Timesheet Call")
	public void validateTheResponseSchemaWithPOSTTimesheetCall() {
		ClientResponse rClient = null;
		
		Map<String, String> headers = (Map<String, String>)getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			Reporter.log("Status :" + rClient.getStatus());
			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("POST the HomeDelivery Timesheet Search");
				putTestObject("rClient", rClient);

				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "POST_TIMESHEET_SEARCH");
				HomeDelivery_ReusableUtils.validateJSONschema("TimesheetSearch_POST", "POST_TIMESHEET_SEARCH");
			}
			if (rClient.getStatus() != 200) {
				Reporter.log("Timesheet Search POST is failed", MessageTypes.Fail);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	@QAFTestStep(description = "User GET response call for HomeDelivery TimeSheet")
	public static void userGETResponseCallForHomeDeliverTimeSheet() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery TimeSheet");
				putTestObject("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				TimeSheet_Root gson = new Gson().fromJson(RESPONSE, TimeSheet_Root.class);
				Arrays.asList(gson);
				putTestObject("rGSON", gson);
				String TimeSheetID = gson.getData().getId();
				
				putTestObject("TimeSheetID_GET", TimeSheetID);
				Reporter.log("Read Success-HomeDelivery TimeSheet ID: " + TimeSheetID);
				System.out.println("Read Success-HomeDelivery TimeSheet ID: " + TimeSheetID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}
	
	@QAFTestStep(description = "User PUT the Update HomeDelivery TimeSheet call")
	public void userPUTTheUpdateHomeDeliveryTimeSheetCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			rClient = ServiceUtils.PUT(headers, bodyParam);
			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery TimeSheet is updated ");
				putTestObject("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				TimeSheet_Root gson1 = new Gson().fromJson(RESPONSE, TimeSheet_Root.class);
				Arrays.asList(gson1);
				putTestObject("rGSON", gson1);
				String startTime = gson1.getData().getStartTime();
				String endTime = gson1.getData().getEndTime();
				putTestObject("Updated_StartTime", startTime);
				putTestObject("Updated_EndTime", endTime);
				Reporter.log("Update Success-HomeDelivery TimeSheet StartTime: " + startTime);
				Reporter.log("Update Success-HomeDelivery TimeSheet StartTime: " + endTime);
				System.out.println("Update Success-HomeDelivery TimeSheet StartTime: " + startTime);
				System.out.println("Update Success-HomeDelivery TimeSheet StartTime: " + endTime);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery TimeSheet creation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery TimeSheet creation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery TimeSheet creation failed  ");
				putTestObject("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("HomeDelivery TimeSheet creation failed  ");
				putTestObject("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	@QAFTestStep(description = "User DELETE the HomeDelivery TimeSheet DELETE call")
	public void UserDELETETheHomeDeliveryTimeSheetDELETECall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getTestObject("BodyParameter");
		try {
			rClient = ServiceUtils.DELETE(headers, bodyParam);
			if (rClient.getStatus() == 200) {

				Reporter.log("HomeDelivery TimeSheet is deleted ");
				putTestObject("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				HomeDelivery_Success gson1 = new Gson().fromJson(RESPONSE,
						HomeDelivery_Success.class);
				putTestObject("rGSON", gson1);
				System.out.println(" : " + gson1.getApiStatus());
				Reporter.log("Deleted HomeDelivery TimeSheet : " + gson1.getApiStatus());
			}
			if (rClient.getStatus() == 207) {
				Reporter.log("HomeDelivery TimeSheet Deletion with Partial success  ");
				putTestObject("rClient", rClient);
				ErrorMessage gson1 = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
				putTestObject("rGSON", gson1);
			}

			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery TimeSheet Deletion failed with 400");
				putTestObject("rClient", rClient);
			}

			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery TimeSheet Deletion failed with 404");
				putTestObject("rClient", rClient);
			}
			if (rClient.getStatus() == 401) {
				Reporter.log("HomeDelivery TimeSheet Deletion failed with 401");
				putTestObject("rClient", rClient);
			}
			if (rClient.getStatus() == 503) {
				Reporter.log("HomeDelivery TimeSheet Deletion failed with 503");
				putTestObject("rClient", rClient);
			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery TimeSheet Deletion failed with 400");
				putTestObject("rClient", rClient);
			}

		}
	}
	@QAFTestStep(description = "Validate the response schema with GET Timesheet Call")
	public static void validateTheResponseSchemaWithGETTimesheetCall() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getTestObject("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			putTestObject("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Timesheet");
				putTestObject("rClient", rClient);

				String RESPONSE = rClient.getEntity(String.class);
				putTestObject(RESPONSE, "RESPONSE");
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "GET_TIMESHEET");
				HomeDelivery_ReusableUtils.validateJSONschema("Timesheet_GET", "GET_TIMESHEET");
			}
			
			if (rClient.getStatus() != 200) {
				Reporter.log("Timesheet Read with failed", MessageTypes.Fail);
				Reporter.log(rClient.toString());
				putTestObject("rClient", rClient);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			putTestObject("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			putTestObject("errorStatusCode", errorStatusCode);

		}
	}

	public String getFutureDate() {
		LocalDate date = LocalDate.now();
		date = date.plusDays(1);
		String Nextdate = date.toString();
		return Nextdate;
	}
	public static String getTimeStamp() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'-05:00:00'");
		Calendar cal = Calendar.getInstance();
		System.out.println("Current Date: "+sdf.format(cal.getTime()));
		//Adding 1 Day to the current date
		cal.add(Calendar.DAY_OF_MONTH, 1);  
		//Date after adding one day to the current date
		String newDate = sdf.format(cal.getTime());  
		//Displaying the new Date after addition of 1 Day
		System.out.println("Incremnted current date by one: "+newDate);
		return (new String(newDate));
	} 
	public static String getIncreaseTimeStamp() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'-05:00:00'");
		Calendar cal = Calendar.getInstance();
		System.out.println("Current Date: "+sdf.format(cal.getTime()));
		//Adding 1 Day to the current date
		cal.add(Calendar.DAY_OF_MONTH, 1);  
		cal.add(Calendar.MINUTE, 10);
		//Date after adding one day to the current date
		String newDate = sdf.format(cal.getTime());  
		//Displaying the new Date after addition of 1 Day
		System.out.println("Incremnted current date by one: "+newDate);
		return (new String(newDate));
	} 
}
