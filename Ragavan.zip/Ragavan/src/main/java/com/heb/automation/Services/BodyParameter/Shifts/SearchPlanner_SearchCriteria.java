package com.heb.automation.Services.BodyParameter.Shifts;

public class SearchPlanner_SearchCriteria {
	
	private String operation;

    private String value;

    private String key;

    public String getOperation ()
    {
        return operation;
    }

    public void setOperation (String operation)
    {
        this.operation = operation;
    }

    public String getValue ()
    {
        return value;
    }

    public void setValue (String id)
    {
        this.value = id;
    }

    public String getKey ()
    {
        return key;
    }

    public void setKey (String id)
    {
        this.key = id;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [operation = "+operation+", value = "+value+", key = "+key+"]";
    }


}
