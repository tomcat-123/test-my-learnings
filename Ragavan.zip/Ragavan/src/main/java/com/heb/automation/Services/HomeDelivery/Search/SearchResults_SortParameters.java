package com.heb.automation.Services.HomeDelivery.Search;

import java.util.ArrayList;

public class SearchResults_SortParameters {
		      
	    private String direction;
	    
	    private String property;
	    
	    private String ignoreCase;
	    
	    private String nullHandling;
	    
	    private String ascending;
	    
	    private String descending;
	    	    
	    
	    public String getDirection() {
			return direction;
		}

		public void setDirection(String direction) {
			this.direction = direction;
		}

		public String getProperty() {
			return property;
		}

		public void setProperty(String property) {
			this.property = property;
		}

		public String getIgnoreCase() {
			return ignoreCase;
		}

		public void setIgnoreCase(String ignoreCase) {
			this.ignoreCase = ignoreCase;
		}

		public String getNullHandling() {
			return nullHandling;
		}

		public void setNullHandling(String nullHandling) {
			this.nullHandling = nullHandling;
		}

		public String getAscending() {
			return ascending;
		}

		public void setAscending(String ascending) {
			this.ascending = ascending;
		}

		public String getDescending() {
			return descending;
		}

		public void setDescending(String descending) {
			this.descending = descending;
		}

		@Override
	    public String toString()
	    {
	        return "ClassPojo [direction = "+direction+", property = "+property+", ignoreCase = "+ignoreCase+", nullHandling = "+nullHandling+", ascending = "+ascending+", descending = "+descending+"]";
	    }
}
