package com.heb.automation.Steps.HD_WebApp;

import static com.heb.automation.common.components.PerfectoUtils.MAX_WAIT_TIME;

import java.util.ArrayList;
import java.util.List;

import com.heb.automation.Pages.HD_WebApp.CommonTestPage;
import com.heb.automation.Pages.HD_WebApp.searchresult.DriverSearchResultpage;
import com.heb.automation.Pages.HD_WebApp.searchresult.SearchResultPage;
import com.heb.automation.common.TestDataContainer;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class HD_WebAppCommonStepdef extends TestDataContainer {

	@QAFTestStep(description = "click search button")
	public void iClickSearchButton() throws InterruptedException {

		CommonTestPage commonPage = new CommonTestPage();
		// Thread.sleep(50000);
		commonPage.getBtnSearch().click();
	}

	@QAFTestStep(description = "verify pagination defaults to page 1 and is highlighted")
	public void iVerifyPaginationDefaultsToPage1AndIsHighlighted() {
		CommonTestPage commonTP = new CommonTestPage();

		commonTP.getCommonBtnPageNum().get(0).waitForPresent(MAX_WAIT_TIME);
		String pageNum = commonTP.getCommonBtnPageNum().get(0).getText();
		int pNum = Integer.parseInt(pageNum);
		if (pNum == 1)
			PerfectoUtils.reportMessage("pagination defaults to page 1", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("pagination not defaults to page 1", MessageTypes.Fail);

		String backColor = commonTP.getCommonBtnPageNum().get(0).getCssValue("color");
		String buttonColor = commonTP.getCommonBtnPageNum().get(0).getCssValue("border-color");

		if (backColor.equalsIgnoreCase(buttonColor))
			PerfectoUtils.reportMessage("Page Num is not highlighted", MessageTypes.Fail);
		else
			PerfectoUtils.reportMessage("Page Num is highlighted", MessageTypes.Pass);
	}

	@QAFTestStep(description = "verify pagination has page forward and backward")
	public void iVerifyPaginationHasPageForwardAndBackward() {
		CommonTestPage commonTP = new CommonTestPage();

		commonTP.getCommonLnkBackwardLastpage().verifyPresent();
		commonTP.getCommonLnkBackwardNext().verifyPresent();
		commonTP.getCommonLnkForwardLast().verifyPresent();
		commonTP.getCommonLnkBackwardNext().verifyPresent();
	}

	@QAFTestStep(description = "verify pagination defaults to display the first 50 records per page")
	public void iVerifyPaginationDefaultsToDisplayTheFirst50RecordsPerPage() {
		SearchResultPage searchResut = new SearchResultPage();

		int recordSize = searchResut.getTableRowList().size();

		if (recordSize <= 50)
			PerfectoUtils.reportMessage("Pagination Defaults To Display The First 50 Records Per Page",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Pagination Not Defaults To Display The First 50 Records Per Page",
					MessageTypes.Fail);

	}

	@QAFTestStep(description = "verify Pagination dropdown values")
	public void iVerifyPaginationDropdownValues() {
		CommonTestPage commonTP = new CommonTestPage();

		commonTP.getCommonDropdownPagination().get(0).waitForPresent();
		commonTP.getCommonDropdownPagination().get(0).click();

		List<QAFWebElement> lists = commonTP.getCommonLblPageValue();
		ArrayList<String> value = new ArrayList<>();

		for (QAFWebElement list : lists)
			value.add(list.getText());

		if (value.contains("50"))
			PerfectoUtils.reportMessage("The Value of 50 is avilable in Pagination dropdown", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("The Value of 50 is not avilable in Pagination dropdown", MessageTypes.Fail);

		if (value.contains("100"))
			PerfectoUtils.reportMessage("The Value of 100 is avilable in Pagination dropdown", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("The Value of 100 is not avilable in Pagination dropdown", MessageTypes.Fail);

		if (value.contains("150"))
			PerfectoUtils.reportMessage("The Value of 150 is avilable in Pagination dropdown", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("The Value of 150 is not avilable in Pagination dropdown", MessageTypes.Fail);

		if (value.contains("200"))
			PerfectoUtils.reportMessage("The Value of 200 is avilable in Pagination dropdown", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("The Value of 200 is not avilable in Pagination dropdown", MessageTypes.Fail);
		
		if (value.contains("500"))
			PerfectoUtils.reportMessage("The Value of 500 is avilable in Pagination dropdown", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("The Value of 500 is not avilable in Pagination dropdown", MessageTypes.Fail);
	}

	@QAFTestStep(description = "verify pagination displays both at the top and bottom of the grid results")
	public void iVerifyPaginationDisplaysBothAtTheToAndPottomOfTheGridResults() {
		CommonTestPage commonTP = new CommonTestPage();

		int pageNationCount = commonTP.getCommonDropdownPagination().size();

		if (pageNationCount == 2)
			PerfectoUtils.reportMessage("The Pagination is getting Displayed in Top and Bottonm", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("The Pagination is getting Displayed in Top and Bottonm", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify Pagination displays 1 to x of y entries")
	public void iVerifyPaginationDisplays1ToXOfYEntries() {
		CommonTestPage commonTP = new CommonTestPage();

		commonTP.getCommonLblDisplayingRecords().waitForPresent();		
		commonTP.getCommonLblDisplayingRecords().verifyPresent();
	}

	@QAFTestStep(description = "select a Result before change")
	public void iSelectAResultBeforeChange() {
		SearchResultPage searchResut = new SearchResultPage();
		searchResut.getTableRowList().get(0).waitForVisible(5000);
		String FirstResult = searchResut.getTableRowList().get(0).getText();
		putTestObject("FirstSearchResut", FirstResult);
	}

	@QAFTestStep(description = "select a Result after change")
	public void iSelectAResultAfterChange() {
		SearchResultPage searchResut = new SearchResultPage();
		searchResut.getTableRowList().get(0).waitForVisible(5000);
		String SecontResult = searchResut.getTableRowList().get(0).getText();
		putTestObject("SecondSearchResut", SecontResult);
	}

	@QAFTestStep(description = "select a new page")
	public void iSelectANewPage() throws InterruptedException {
		CommonTestPage commonTP = new CommonTestPage();

		int pageNumSize = commonTP.getCommonBtnPageNum().size();

		if (pageNumSize == 2)
			PerfectoUtils.reportMessage("The Page has only 1 PageNum", MessageTypes.Pass);
		if (pageNumSize > 2)
			commonTP.getCommonBtnPageNum().get(1).click();
			Thread.sleep(5000);
		PerfectoUtils.reportMessage("The Page Num 2 is clcked", MessageTypes.Pass);
	}

	@QAFTestStep(description = "verify new results in grid")
	public void iVerifyNewResultsInGrid() {

		if (!(getTestString("SecondSearchResut"))
				.equals(getTestString("FirstSearchResut")))
			PerfectoUtils.reportMessage("New Search Result is getting Displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("New Search Result is not getting Displayed", MessageTypes.Fail);

	}

	@QAFTestStep(description = "click on forward scroll button in pagination")
	public void iClickOnForwardScrollButtonInPagination() {
		CommonTestPage commonTP = new CommonTestPage();

		commonTP.getCommonLnkForwardNext().waitForPresent();
		commonTP.getCommonLnkForwardNext().click();
	}

	@QAFTestStep(description = "click on backward scroll button in pagination")
	public void iClickOnBackwardScrollButtonInPagination() {
		CommonTestPage commonTP = new CommonTestPage();

		commonTP.getCommonLnkBackwardNext().waitForPresent();
		commonTP.getCommonLnkBackwardNext().click();
	}

	@QAFTestStep(description = "click on first page button in pagination")
	public void iClickOnFirstPageButtonInPagination() {
		CommonTestPage commonTP = new CommonTestPage();

		commonTP.getCommonLnkForwardLast().waitForPresent();
		commonTP.getCommonLnkForwardLast().click();
	}

	@QAFTestStep(description = "click on last page button in pagination")
	public void iClickOnLastPageButtonInPagination() {
		CommonTestPage commonTP = new CommonTestPage();

		commonTP.getCommonLnkBackwardLastpage().waitForPresent();
		commonTP.getCommonLnkBackwardLastpage().click();
	}

	@QAFTestStep(description = "verify records displaying in grid matches correctly as per the dropdown selection")
	public void iVerifyRecordsDisplayingInGridMatchesCorrectlyAsPerTheDropdownSelection() {
		CommonTestPage commonTP = new CommonTestPage();
		SearchResultPage searchResut = new SearchResultPage();

		commonTP.getCommonDropdownPagination().get(0).waitForPresent();
		// commonTP.getCommonDropdownPagination().get(0).click();
		commonTP.getCommonLblPageValue().get(0).waitForPresent(1000);
		String dropdownSelection = commonTP.getCommonLblPageValue().get(1).getText();
		int selection = Integer.parseInt(dropdownSelection);
		int selectioResult = searchResut.getTableRowList().size();

		if (selectioResult <= selection)
			PerfectoUtils.reportMessage("Records displaying in grid matches correctly as per the dropdown selection",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage(
					"Records displaying in grid not matches correctly as per the dropdown selection",
					MessageTypes.Fail);
	}

	@QAFTestStep(description = "verify grid displays new results when selecting a page number")
	public void iVerifyGridDisplaysNewResultsWhenSelectingAPageNumber() throws InterruptedException {
		CommonTestPage commonTP = new CommonTestPage();

		int pageNumSize = commonTP.getCommonBtnPageNum().size();
		if (pageNumSize > 2) {

			iSelectAResultBeforeChange();
			iSelectANewPage();
			iSelectAResultAfterChange();
			iVerifyNewResultsInGrid();
		} else {
			PerfectoUtils.reportMessage("Grid is having 1 page records", MessageTypes.Info);
		}
	}

	@QAFTestStep(description = "verify grid displays new results when selecting the forward scroll button")
	public void iVerifyGridDisplaysNewResultsWhenSelectingTheForwardScrollButton() {
		CommonTestPage commonTP = new CommonTestPage();

		int pageNumSize = commonTP.getCommonBtnPageNum().size();
		if (pageNumSize > 2) {

			iSelectAResultBeforeChange();
			iClickOnForwardScrollButtonInPagination();
			iSelectAResultAfterChange();
			iVerifyNewResultsInGrid();
		} else {
			PerfectoUtils.reportMessage("Grid is having 1 page records", MessageTypes.Info);
		}
	}

	@QAFTestStep(description = "verify grid displays new results when selecting the backward scroll button")
	public void iVerifyGridDisplaysNewResultsWhenSelectingTheBackWardScrollButton() {
		CommonTestPage commonTP = new CommonTestPage();

		int pageNumSize = commonTP.getCommonBtnPageNum().size();
		if (pageNumSize > 2) {

			iSelectAResultBeforeChange();
			iClickOnBackwardScrollButtonInPagination();
			iSelectAResultAfterChange();
			iVerifyNewResultsInGrid();
		} else {
			PerfectoUtils.reportMessage("Grid is having 1 page records", MessageTypes.Info);
		}
	}

	@QAFTestStep(description = "verify grid displays last page results when selecting the last page button")
	public void iVerifyGridDisplaysLastPageResultsWhenSelectingTheLastPageButton() {
		CommonTestPage commonTP = new CommonTestPage();

		int pageNumSize = commonTP.getCommonBtnPageNum().size();
		if (pageNumSize > 2) {

			iSelectAResultBeforeChange();
			iClickOnLastPageButtonInPagination();
			iSelectAResultAfterChange();
			iVerifyNewResultsInGrid();
		} else {
			PerfectoUtils.reportMessage("Grid is having 1 page records", MessageTypes.Info);
		}
	}

	@QAFTestStep(description = "verify grid displays first page results when selecting the first page button")
	public void iVerifyGridDisplaysFirstPageResultsWhenSelectingTheFirstPageButton() {
		CommonTestPage commonTP = new CommonTestPage();

		int pageNumSize = commonTP.getCommonBtnPageNum().size();
		if (pageNumSize > 2) {

			iSelectAResultBeforeChange();
			iClickOnFirstPageButtonInPagination();
			iSelectAResultAfterChange();
			iVerifyNewResultsInGrid();
		} else {
			PerfectoUtils.reportMessage("Grid is having 1 page records", MessageTypes.Info);
		}
	}

	@QAFTestStep(description = "verify pagination for driver snapshot page")
	public void iVerifyPaginationForDriverSnapshotPage() throws InterruptedException {

		iVerifyPaginationDefaultsToPage1AndIsHighlighted();
		iVerifyPaginationHasPageForwardAndBackward();
		iVerifyPaginationDefaultsToDisplayTheFirst50RecordsPerPage();
		iVerifyPaginationDropdownValues();
		iVerifyPaginationDisplaysBothAtTheToAndPottomOfTheGridResults();
		iVerifyPaginationDisplays1ToXOfYEntries();
		iVerifyRecordsDisplayingInGridMatchesCorrectlyAsPerTheDropdownSelection();
		iVerifyGridDisplaysNewResultsWhenSelectingAPageNumber();
		iVerifyGridDisplaysNewResultsWhenSelectingTheForwardScrollButton();
		iVerifyGridDisplaysNewResultsWhenSelectingTheBackWardScrollButton();
		iVerifyGridDisplaysLastPageResultsWhenSelectingTheLastPageButton();
		iVerifyGridDisplaysFirstPageResultsWhenSelectingTheFirstPageButton();
	}

	@QAFTestStep(description = "verify pagination for zone page")
	public void iVerifyPaginationForZonePage() throws InterruptedException {

		iVerifyPaginationDefaultsToPage1AndIsHighlighted();
		iVerifyPaginationHasPageForwardAndBackward();
		iVerifyPaginationDefaultsToDisplayTheFirst50RecordsPerPage();
		iVerifyPaginationDropdownValues();
		iVerifyPaginationDisplaysBothAtTheToAndPottomOfTheGridResults();
		iVerifyPaginationDisplays1ToXOfYEntries();
		iVerifyRecordsDisplayingInGridMatchesCorrectlyAsPerTheDropdownSelection();
		iVerifyGridDisplaysNewResultsWhenSelectingAPageNumber();
		iVerifyGridDisplaysNewResultsWhenSelectingTheForwardScrollButton();
		iVerifyGridDisplaysNewResultsWhenSelectingTheBackWardScrollButton();
		iVerifyGridDisplaysLastPageResultsWhenSelectingTheLastPageButton();
		iVerifyGridDisplaysFirstPageResultsWhenSelectingTheFirstPageButton();
	}

	

	@QAFTestStep(description = "verify pagination for Store Listing page")
	public void iVerifyPaginationForStoreListingPage() throws InterruptedException {

		iVerifyPaginationDefaultsToPage1AndIsHighlighted();
		iVerifyPaginationHasPageForwardAndBackward();
		iVerifyPaginationDefaultsToDisplayTheFirst50RecordsPerPage();
		iVerifyPaginationDropdownValues();
		iVerifyPaginationDisplaysBothAtTheToAndPottomOfTheGridResults();
		iVerifyPaginationDisplays1ToXOfYEntries();
		iVerifyRecordsDisplayingInGridMatchesCorrectlyAsPerTheDropdownSelection();
		iVerifyGridDisplaysNewResultsWhenSelectingAPageNumber();
		iVerifyGridDisplaysNewResultsWhenSelectingTheForwardScrollButton();
		iVerifyGridDisplaysNewResultsWhenSelectingTheBackWardScrollButton();
		iVerifyGridDisplaysLastPageResultsWhenSelectingTheLastPageButton();
		iVerifyGridDisplaysFirstPageResultsWhenSelectingTheFirstPageButton();
	}
	
	@QAFTestStep(description = "verify pagination for Order Listing page")
	public void vErifyPaginationForOrderListingPage() throws InterruptedException {

		iVerifyPaginationDefaultsToPage1AndIsHighlighted();
		iVerifyPaginationHasPageForwardAndBackward();
		iVerifyPaginationDefaultsToDisplayTheFirst50RecordsPerPage();
		iVerifyPaginationDropdownValues();
		iVerifyPaginationDisplaysBothAtTheToAndPottomOfTheGridResults();
		iVerifyPaginationDisplays1ToXOfYEntries();
		iVerifyRecordsDisplayingInGridMatchesCorrectlyAsPerTheDropdownSelection();
		iVerifyGridDisplaysNewResultsWhenSelectingAPageNumber();
		iVerifyGridDisplaysNewResultsWhenSelectingTheForwardScrollButton();
		iVerifyGridDisplaysNewResultsWhenSelectingTheBackWardScrollButton();
		iVerifyGridDisplaysLastPageResultsWhenSelectingTheLastPageButton();
		iVerifyGridDisplaysFirstPageResultsWhenSelectingTheFirstPageButton();
	}
	
	@QAFTestStep(description = "click on Home icon")
	public void cLickOnHomeIcon() {
		CommonTestPage commonTP = new CommonTestPage();
		
		commonTP.getLblHomeIcon().waitForVisible(5000);
		commonTP.getLblHomeIcon().click();
		
	}

}
