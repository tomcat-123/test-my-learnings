package com.heb.automation.Services.BodyParameter.Order;

import java.util.ArrayList;
import java.util.List;

public class Order {
	
	private String external_id;

    private Store store = new Store();

    private String invoice;

    private Customer customer = new Customer();

    private List<Notes> notes = new ArrayList<Notes>();

    private float gross_bill;

    
    private float tip;

    public String getExternal_id ()
    {
        return external_id;
    }

    public void setExternal_id (String external_id)
    {
        this.external_id = external_id;
    }

    public Store getStore ()
    {
        return store;
    }

    public void setStore (Store store)
    {
        this.store = store;
    }

    public String getInvoice ()
    {
        return invoice;
    }

    public void setInvoice (String invoice)
    {
        this.invoice = invoice;
    }

    public Customer getCustomer ()
    {
        return customer;
    }

    public void setCustomer (Customer customer)
    {
        this.customer = customer;
    }

    public List<Notes> getNotes ()
    {
        return notes;
    }

    public void setNotes (List<Notes> notes)
    {
        this.notes = notes;
    }

    public float getGross_bill ()
    {
        return gross_bill;
    }

    public void setGross_bill (Float gross_Bill)
    {
        this.gross_bill = gross_Bill;
    }

    public float getTip ()
    {
        return tip;
    }

    public void setTip(float tip) {
		this.tip = tip;
	}

	public void setGross_bill(float gross_bill) {
		this.gross_bill = gross_bill;
	}


}
