# Project notes
	This sheet contains the list of instances which has not been automated.


- Search results- validate only non-curbside stores are getting listed
- Validation of toast messages


