JSON to Java object online conversion :

http://pojo.sodhanalibrary.com/Convert


# 1) Dynamic Storing an integer 

Object SD_ID = getBundle().getProperty("updateSD_ID");
			
Integer SD = Integer.valueOf(SD_ID.toString());

#2 ) Data from EXCEL sheet :
- TO get list of sheet from an excel 

Workbook workbook = WorkbookFactory.create(new File(FilePath));	
	Iterator<Sheet> sheetIterator = workbook.sheetIterator();
    System.out.println("Retrieving Sheets using Iterator");
    while (sheetIterator.hasNext()) {
        Sheet sheet = sheetIterator.next();
        System.out.println("=> " + sheet.getSheetName());
    }
    
   For Each loop 
   
   System.out.println("Retrieving Sheets using for-each loop");
    for(Sheet sheet: workbook) {
        System.out.println("=> " + sheet.getSheetName());
    }
    
    
   }