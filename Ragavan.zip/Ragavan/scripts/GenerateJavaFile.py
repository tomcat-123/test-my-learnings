'''
GenerateJavaFile.py written by Garrett Griffin

Usage:
        > python3 GenerateJavaFile.py inputFile.txt JavaFileName JavaPkgName
Purpose:
        Generates a java file in the format needed to be used with the
        QAF framework. The big issue has been that once you've created the location
        file, that now you've got to create an @FindBy override as well as a new value
        in Java. Too much back and forth.
Input:
        Expected input is as follows:
        footer.txt.emailbox, id=signup-email-address,EditTextView for email address
        Note: Spaces will be okay around all items as they will be trimmed before being
        entered into the Excel table
Output:
        Output will be as follows. Note: If the old java file exists, it will be overwritten.

package JavaPkgName;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;


public class JavaFileName extends WebDriverBaseTestPage<WebDriverTestPage>  {

    @Override
    protected void openPage(PageLocator arg0, Object... arg1) {}

    @FindBy(locator = "footer.txt.emailbox")
    private QAFWebElement footerTxtEmailbox;

    /**
     * EditTextView for email address
     */
     public QAFWebElement getFooterTxtEmail(){ return footerTxtEmailbox; }
    .
    .
    .
}

Notes:
        1) IMPORTANT: If you are generating a list element, you NEED to include '.li.'
        somewhere inside of the java value name of the text file. For example:
            home.btn.li.someName,id=xpathID,Meaningful Description
        will yield:
            @FindBy(locator = "home.btn.li.someName")
        	private List<QAFWebElement> home.btn.li.someName;
        2) If an old java file exists, it will be overwritten
        3) JavaDoc is generated from the description field of the input file
        4) For the getter items, if it is a dynamic search then it will plug in values by Strings
        given from the user. Has been tested that ints can be converted to a string to be used
'''

import re
import sys

if(len(sys.argv) != 4):
    print("Incorrect number of arguements.")
    print("Usage: <inputFile.txt> <JavaFileName> <JavaPkgName>")
    sys.exit(1)

# Create and open new files
inputFileName = sys.argv[1]
inputF = open(inputFileName, 'r')
javaFileName = sys.argv[2]
javaOutF = open(javaFileName + '.java', 'w')
javaPkg = 'package '
javaPkg += sys.argv[3] + ';\n\n'
pageName = sys.argv[3]

def createHeading(javaOutF, javaFileName, pageName):
    print('Creating package and import heading...')

    javaOutF.writelines([javaPkg
                         , 'import java.util.List;\n\n'
                         , 'import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;\n'
                         , 'import com.qmetry.qaf.automation.ui.annotations.FindBy;\n'
                         , 'import com.qmetry.qaf.automation.ui.api.PageLocator;\n'
                         , 'import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;\n'
                         , 'import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;\n'
                         , 'import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;\n\n'])
    pathRemoved = re.search(r'^.*\\(.*)$', javaFileName)
    classDefStr = 'public class ' + pathRemoved.group(1) + ' extends WebDriverBaseTestPage<WebDriverTestPage>  {\n'

    javaOutF.writelines([classDefStr
                         ,'\n\t@Override\n'
                         ,'\tprotected void openPage(PageLocator arg0, Object... arg1){}\n\n'])

    # HomePage contains a special method used for waiting for things to load.
    if(pageName == 'pages.homepage'):
        hpWaitMethod = '\n\tpublic synchronized void WaitForPageToLoad() {\n \
		homeImgHeblogo.waitForPresent(5000);\n \
		super.waitForPageToLoad();\n\t}\n\n'
        javaOutF.writelines(hpWaitMethod)

def createDynamicGetter(variableName, locationName):
    returnString = '\n\t\tString retElm = String.format(pageProps.getString("' +locationName+'"), item);\n\t\
    return new QAFExtendedWebElement(retElm);\n\t}\n\n'
    return returnString

def generateJava(inputLine, javaOutF):
    # Regex to capture the three groups.
    # .split() has a chance to make it nasty
    outline = re.search(r'^(.*);(.*);(.*)$', inputLine)
    if outline is None:
        return
    valueName = outline.group(1)
    isDynamic = re.search(r'^.*(\.get\.).*$', inputLine)

    # Locator for QAF
    firstLine = '\t@FindBy(locator = "' + valueName + '")\n'
    name = valueName.split('.')
    result = ''
    # Upper case each letter
    for item in name:
        result += item[0].upper() + item[1:]
    # Convert to a camelcase
    jName = result[:1].lower() + result[1:]
    # Add JavaDoc
    commentLine = '\t/**\n\t * ' + outline.group(3) + '\n\t */\n'
    # Check for lists
    if isList is None:
        secondLine = '\tprivate QAFWebElement ' + jName + ';\n\n'
        if isDynamic is None:
            getterLine = '\tpublic QAFWebElement get' + result + '(){ '
        else:
            getterLine = '\tpublic QAFWebElement get' + result + '(String item){ '
    else:
        secondLine = '\tprivate List<QAFWebElement> ' + jName + ';\n\n'
        getterLine = '\tpublic List<QAFWebElement> get' + result + '(){ '
    if isDynamic is None:
        returnLine = 'return ' + jName + '; }\n\n'
    else:
        returnLine = createDynamicGetter(jName, valueName)

    javaOutF.writelines([firstLine, secondLine, commentLine, getterLine, returnLine])

createHeading()
print('Creating setters and getters...')
# Iterate through the given file, parse the line, and add
# it to the worksheet
for line in inputF:
    generateJava(line)

# Fencepost for end of file
javaOutF.write('\n}')

print('File written!')

# Close the files
inputF.close()
javaOutF.close()
