package com.automation.web.pages.myAccount;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CommunicationPrefsTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}
	@FindBy(locator = "commpref.txt.commprefheader")
	private QAFWebElement commprefTxtCommprefheader;	
	@FindBy(locator = "commpref.chk.monthlynewsletter")
	private QAFWebElement commprefChkMonthlynewsletter;
	@FindBy(locator = "commpref.chkbox.monthlynewsletter")
	private QAFWebElement commprefChkBoxMonthlynewsletter;
	@FindBy(locator = "commpref.chkbox.promotions")
	private QAFWebElement commprefChkBoxPromotions;
	@FindBy(locator = "commpref.chkbox.weeklyads")
	private QAFWebElement commprefChkBoxWeeklyads;
	@FindBy(locator = "commpref.chk.weeklyads")
	private QAFWebElement commprefChkWeeklyads;
	@FindBy(locator = "commpref.btn.save")
	private QAFWebElement commprefBtnSave;
	@FindBy(locator = "commpref.chkbox.verifycheckedweeklyads")
	private QAFWebElement commprefChkBoxVerifyCheckedWeeklyads;
	
	public QAFWebElement getCommprefChkMonthlynewsletter() {
		return commprefChkMonthlynewsletter;
	}
	
	public QAFWebElement getCommprefChkBoxVerifyCheckedWeeklyads() {
		return commprefChkBoxVerifyCheckedWeeklyads;
	}
	
	public QAFWebElement getCommprefChkBoxPromotions() {
		return commprefChkBoxPromotions;
	}
	
	public QAFWebElement getCommprefChkBoxWeeklyads() {
		return commprefChkBoxWeeklyads;
	}


	public QAFWebElement getCommprefChkBoxMonthlynewsletter() {
		return commprefChkBoxMonthlynewsletter;
	}


	public QAFWebElement getCommprefChkWeeklyads() {
		return commprefChkWeeklyads;
	}


	public QAFWebElement getCommprefBtnSave() {
		return commprefBtnSave;
	}


	public QAFWebElement getCommPrefLblCommPrefheader() {
		return commprefTxtCommprefheader;
	}

}