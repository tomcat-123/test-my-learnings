package com.automation.web.pages.pharmacy;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class PharmacyLandingTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "pharmacy.lbl.header")
	private QAFWebElement pharmacyLblHeader;

	@FindBy(locator = "pharmacy.btn.getstarted")
	private QAFWebElement pharmacyBtnGetstarted;

	@FindBy(locator = "pharmacy.lbl.transferprescription")
	private QAFWebElement pharmacyLblTransferprescription;
	
	@FindBy(locator = "pharmacy.block.delivery")
	private QAFWebElement pharmacyBockDelivery;
	
	@FindBy(locator = "pharmacy.img.delivery")
	private QAFWebElement pharmacyImgDelivery;
	
	@FindBy(locator = "pharmacy.txt.delivery")
	private QAFWebElement pharmacyTxtDelivery;
	
	@FindBy(locator = "pharmacy.block.refillexpress")
	private QAFWebElement pharmacyBlockRefillexpress;
	
	@FindBy(locator = "pharmacy.lbl.signupforautorefill")
	private QAFWebElement pharmacyLblSignupforautorefill;
	
	@FindBy(locator = "pharmacy.btn.googleplay")
	private QAFWebElement pharmacyBtnGoogleplay;

	/**
	 * Textview of pharmacy page header
	 */
	public QAFWebElement getPharmacyLblHeader() {
		return pharmacyLblHeader;
	}

	/**
	 * Buttonview of Get Started
	 */
	public QAFWebElement getPharmacyBtnGetstarted() {
		return pharmacyBtnGetstarted;
	}

	public QAFWebElement getPharmacyLblTransferprescription() {
		return pharmacyLblTransferprescription;
	}
	
	public QAFWebElement getPharmacyBockDelivery() {
		return pharmacyBockDelivery;
	}

	public QAFWebElement getPharmacyImgDelivery() {
		return pharmacyImgDelivery;
	}

	public QAFWebElement getPharmacyTxtDelivery() {
		return pharmacyTxtDelivery;
	}

	public QAFWebElement getPharmacyBlockRefillexpress() {
		return pharmacyBlockRefillexpress;
	}

	public QAFWebElement getPharmacyLblSignupforautorefill() {
		return pharmacyLblSignupforautorefill;
	}
	
	public QAFWebElement getPharmacyBtnGoogleplay() {
		return pharmacyBtnGoogleplay;
	}
	

}