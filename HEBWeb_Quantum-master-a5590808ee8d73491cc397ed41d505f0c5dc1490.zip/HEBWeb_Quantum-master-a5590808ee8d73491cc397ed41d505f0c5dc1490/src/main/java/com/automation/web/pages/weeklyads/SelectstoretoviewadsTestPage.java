package com.automation.web.pages.weeklyads;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SelectstoretoviewadsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "ss.lbl.storenamelist")
	private List<QAFWebElement> lblStorenamelist;
	@FindBy(locator = "ss.btn.viewadslist")
	private List<QAFWebElement> btnViewadslist;
	@FindBy(locator = "ss.txt.zipcode")
	private QAFWebElement txtZipcode;
	@FindBy(locator = "ss.btn.storego")
	private QAFWebElement btnStorego;
	@FindBy(locator = "ss.lbl.pageheader")
	private QAFWebElement lblPageheader;
	@FindBy(locator = "ss.lnk.makethismystore")
	private QAFWebElement lnkMakeThisMyStore;
	@FindBy(locator = "ss.lbl.storenamealignment")
	private QAFWebElement lblStoreNameUnderDeals;
	@FindBy(locator = "ss.lbl.makethismystorealignment")
	private QAFWebElement lblMakeThisMyStoreUnderStoreName;
	@FindBy(locator = "ss.lbl.storename")
	private QAFWebElement lblStoreName;
	@FindBy(locator = "ss.lbl.storenameintop")
	private QAFWebElement lblStoreNameintop;
	@FindBy(locator = "ss.lbl.myhebstoregreen")
	private QAFWebElement lblMyHebStoreGreen;
	@FindBy(locator = "ss.icn.myhebstoretick")
	private QAFWebElement icnMyHebStoreTick;
	@FindBy(locator = "ss.lbl.myhebstore")
	private QAFWebElement lblMyHebStore;
	@FindBy(locator = "ss.txt.changezipcode")
	private QAFWebElement txtChangeZipcode;
	@FindBy(locator = "ss.lst.nearbystorescount")
	private List<QAFWebElement> lstNearbystorescount;
	@FindBy(locator = "ss.lbl.noweeklyadmsg")
	private QAFWebElement lblNoWeeklyAdMsg;
	@FindBy(locator = "ss.edt.zipcode")
	private QAFWebElement edtZipcode;
	@FindBy(locator = "ss.get.lnk.leftscroll")
	private QAFWebElement lnkLeftscroll;
	@FindBy(locator = "ss.get.lnk.rightscroll")
	private QAFWebElement lnkRightscroll;
	@FindBy(locator = "ss.lbl.featureddeals")
	private QAFWebElement lblFeatureddeals;
	@FindBy(locator = "ss.lbl.featureddealsdropdown")
	private QAFWebElement lblFeatureddealsdropdown;
	
	

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public List<QAFWebElement> getLblStorenamelist() {
		return lblStorenamelist;
	}
	
	public List<QAFWebElement> getLstNearbystorescount() {
		return lstNearbystorescount;
	}

	public List<QAFWebElement> getBtnViewadslist() {
		return btnViewadslist;
	}

	public QAFWebElement getTxtZipcode() {
		return txtZipcode;
	}
	
	public QAFWebElement getLblNoWeeklyAdMsg() {
		return lblNoWeeklyAdMsg;
	}

	public QAFWebElement getBtnStorego() {
		return btnStorego;
	}

	public QAFWebElement getLblPageheader() {
		return lblPageheader;
	}
	
	public QAFWebElement getLnkMakeThisMyStore() {
		return lnkMakeThisMyStore;
	}
	
	public QAFWebElement getLblStoreNameUnderDeals() {
		return lblStoreNameUnderDeals;
	}
	
	public QAFWebElement getLblMakeThisMyStoreUnderStoreName() {
		return lblMakeThisMyStoreUnderStoreName;
	}
	
	public QAFWebElement getLblStoreName() {
		return lblStoreName;
	}
	
	public QAFWebElement getLblStoreNameintop() {
		return lblStoreNameintop;
	}
	
	public QAFWebElement getLblMyHebStoreGreen() {
		return lblMyHebStoreGreen;
	}
	
	public QAFWebElement getIcnMyHebStoreTick() {
		return icnMyHebStoreTick;
	}
	
	public QAFWebElement getLblMyHebStore() {
		return lblMyHebStore;
	}
	
	public QAFWebElement getTxtChangeZipcode() {
		return txtChangeZipcode;
	}
	
	public QAFWebElement getLnkLeftscroll() {
		return lnkLeftscroll;
	}
	
	public QAFWebElement getLnkRightscroll() {
		return lnkRightscroll;
	}
	
	public QAFWebElement getNearbyStoresName(int itemno) {
		String reElm = String.format(pageProps.getString("ss.get.lbl.nearbystoresname"), itemno);
		return new QAFExtendedWebElement(reElm);
	}
	
	public QAFWebElement getNearbyStoresAddress(String itemno) {
		String reElm = String.format(pageProps.getString("ss.get.lbl.nearbystoresaddress"), itemno);
		return new QAFExtendedWebElement(reElm);
	}
	
	public QAFWebElement getNearbyStoresleftscroll(int opacity) {
		String reElm = String.format(pageProps.getString("ss.get.lnk.leftscroll"), opacity);
		return new QAFExtendedWebElement(reElm);
	}
	
	public QAFWebElement getNearbyStoresrightscroll(int opacity) {
		String reElm = String.format(pageProps.getString("ss.get.lnk.rightscroll"), opacity);
		return new QAFExtendedWebElement(reElm);
	}
	
	public QAFWebElement getEdtZipcode() {
		return edtZipcode;
	}
	
	public QAFWebElement getLblFeatureddeals() {
		return lblFeatureddeals;
	}
	
	public QAFWebElement getLblFeatureddealsdropdown() {
		return lblFeatureddealsdropdown;
	}

}
