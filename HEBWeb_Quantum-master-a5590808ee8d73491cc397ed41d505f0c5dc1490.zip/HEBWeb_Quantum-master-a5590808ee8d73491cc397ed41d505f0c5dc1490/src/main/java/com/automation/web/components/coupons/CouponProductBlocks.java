package com.automation.web.components.coupons;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CouponProductBlocks extends QAFWebComponent {

	public CouponProductBlocks(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}

	@FindBy(locator = "couponprdts.img.couponsimglist")
	private QAFWebElement imgCouponsimglist;
	
	@FindBy(locator = "couponprdts.lbl.couponsnamelist")
	private QAFWebElement lblCouponsnamelist;
	
	@FindBy(locator = "couponprdts.lbl.couponspricelabellist")
	private QAFWebElement lblCouponspricelabellist;
	
	@FindBy(locator = "couponprdts.lbl.couponspricevaluelist")
	private QAFWebElement lblCouponspricevaluelist;
	
	@FindBy(locator = "couponprdts.btn.couponsaddtolist")
	private QAFWebElement btnCouponsaddtolist;
	
	@FindBy(locator = "couponprdts.txt.couponsinputqtylist")
	private QAFWebElement txtCouponsinputqtylist;
	
	@FindBy(locator = "couponprdts.btn.couponsinputqtyincreaselist")
	private QAFWebElement btnCouponsinputqtyincreaselist;
	
	@FindBy(locator = "couponprdts.btn.couponsinputqtydecreaselist")
	private QAFWebElement btnCouponsinputqtydecreaselist;
	
	@FindBy(locator = "couponprdts.btn.couponsaddtocartlist")
	private QAFWebElement btnCouponsaddtocartlist;

	public QAFWebElement getImgCouponsimglist() {
		return imgCouponsimglist;
	}

	public QAFWebElement getLblCouponsnamelist() {
		return lblCouponsnamelist;
	}

	public QAFWebElement getLblCouponspricelabellist() {
		return lblCouponspricelabellist;
	}

	public QAFWebElement getLblCouponspricevaluelist() {
		return lblCouponspricevaluelist;
	}

	public QAFWebElement getBtnCouponsaddtolist() {
		return btnCouponsaddtolist;
	}

	public QAFWebElement getTxtCouponsinputqtylist() {
		return txtCouponsinputqtylist;
	}

	public QAFWebElement getBtnCouponsinputqtyincreaselist() {
		return btnCouponsinputqtyincreaselist;
	}

	public QAFWebElement getBtnCouponsinputqtydecreaselist() {
		return btnCouponsinputqtydecreaselist;
	}

	public QAFWebElement getBtnCouponsaddtocartlist() {
		return btnCouponsaddtocartlist;
	}
	

}
