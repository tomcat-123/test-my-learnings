package com.automation.web.pages.paymentgateway;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class GiftcardslandingTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "gc.lbl.pageheader")
	private QAFWebElement gcLblPageheader;
	@FindBy(locator = "gc.lbl.giftcardsubheader")
	private QAFWebElement gcLblGiftcardsubheader;
	@FindBy(locator = "gc.lbl.egiftcardsubheader")
	private QAFWebElement gcLblEgiftcardsubheader;
	@FindBy(locator = "gc.lbl.giftcarddetailslist")
	private List<QAFWebElement> gcLblGiftcarddetailslist;
	@FindBy(locator = "gc.lbl.egiftcarddetailslist")
	private List<QAFWebElement> gcLblEgiftcarddetailslist;
	@FindBy(locator = "gc.btn.shopgiftcards")
	private QAFWebElement gcBtnShopgiftcards;
	@FindBy(locator = "gc.btn.sendegiftcard")
	private QAFWebElement gcBtnSendegiftcard;
	@FindBy(locator = "gc.lbl.alreadygiftcard")
	private QAFWebElement gcLblAlreadygiftcard;
	@FindBy(locator = "gc.btn.checkbalance")
	private QAFWebElement gcBtnCheckbalance;

	@FindBy(locator = "gc.img.giftcardsimage")
	private QAFWebElement imgGiftcardsimage;

	@FindBy(locator = "gc.img.egiftcardsimage")
	private QAFWebElement imgEgiftcardsimage;

	@FindBy(locator = "gc.lbl.lowblncalert")
	private QAFWebElement LblLowblncalert;
	
	@FindBy(locator = "gc.lbl.giftcardheaderpayment")
	private QAFWebElement LblGiftcardheaderpayment;
	
	@FindBy(locator = "gc.lnk.editcart")
	private QAFWebElement LnkEditcart;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblPageheader() {
		return gcLblPageheader;
	}

	public QAFWebElement getLblGiftcardsubheader() {
		return gcLblGiftcardsubheader;
	}

	public QAFWebElement getLblEgiftcardsubheader() {
		return gcLblEgiftcardsubheader;
	}

	public List<QAFWebElement> getLblGiftcarddetailslist() {
		return gcLblGiftcarddetailslist;
	}

	public List<QAFWebElement> getLblEgiftcarddetailslist() {
		return gcLblEgiftcarddetailslist;
	}

	public QAFWebElement getBtnShopgiftcards() {
		return gcBtnShopgiftcards;
	}

	public QAFWebElement getBtnSendegiftcard() {
		return gcBtnSendegiftcard;
	}

	public QAFWebElement getLblAlreadygiftcard() {
		return gcLblAlreadygiftcard;
	}

	public QAFWebElement getBtnCheckbalance() {
		return gcBtnCheckbalance;
	}

	public QAFWebElement getImgGiftcardsimage() {
		return imgGiftcardsimage;
	}

	public QAFWebElement getImgEgiftcardsimage() {
		return imgEgiftcardsimage;
	}
	public QAFWebElement getLblLowblncalert() {
		return LblLowblncalert;
	}
	
	public QAFWebElement getLblGiftcardheaderpayment() {
		return LblGiftcardheaderpayment;
	}
	
	public QAFWebElement getLnkEditcart() {
		return LnkEditcart;
	}

}
