package com.automation.web.steps.homepage;

import com.automation.web.pages.homepage.FrontdoorTestPage;
import com.qmetry.qaf.automation.step.NotYetImplementedException;
import com.qmetry.qaf.automation.step.QAFTestStep;

/*List of steps in FrontDoorHomePage

* click on Shop Now link in New Home Page

*/

public class FrontDoorHomePage {

	@QAFTestStep(description="click on Shop Now link in New Home Page")
	public void clickOnShopNowLinkInNewHomePage(){
		
		FrontdoorTestPage fDoor = new FrontdoorTestPage();
		
		fDoor.getFrontImgLogo().click();		
		fDoor.getFrontImgLogo().click();
		fDoor.getFrontBtnShopNow().waitForPresent(5000);
		fDoor.getFrontBtnShopNow().click();
	}	
	
}