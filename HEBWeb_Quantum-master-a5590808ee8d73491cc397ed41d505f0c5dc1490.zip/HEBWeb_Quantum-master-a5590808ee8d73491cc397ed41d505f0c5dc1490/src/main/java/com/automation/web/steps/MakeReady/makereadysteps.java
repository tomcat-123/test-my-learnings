package com.automation.web.steps.MakeReady;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.components.MakeReadyProducts;
import com.automation.web.pages.make_ready.MakeReadyTestPage;
import com.automation.web.pages.storelocator.SelectStoreTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static com.automation.web.commonutils.PerfectoUtils.reportMessage;

public class makereadysteps {

	@QAFTestStep(description = "Verify Select Store model pop up upon clicking store name link in Make Ready page")
	public void verifySelectStoreModelPopUpUponClickingStoreNameLinkInMakeReadyPage() {
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		makeready.getMakeLnkStorename().verifyPresent();
		String store = makeready.getMakeLnkStorename().getText();
		getBundle().setProperty("availStore", store);
		makeready.getMakeLnkStorename().click();
		makeready.getMakeLblSelectmakereadystore().waitForPresent(50000);
		makeready.getMakeLblSelectmakereadystore().verifyPresent();
	}

	@QAFTestStep(description = "Verify the store name in Make Ready page is changed")
	public void verifyTheStoreNameInMakeReadyPageIsChanged() {
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		makeready.getMakeLnkStorename().waitForPresent(5000);
		String actStore = makeready.getMakeLnkStorename().getText();
		String expStore = getBundle().getString("SelectedStore");

		if (PerfectoUtils.removeSpecialCharacters(actStore).equals(PerfectoUtils.removeSpecialCharacters(expStore))) {
			reportMessage("Selected store is displayed in Make ready page", MessageTypes.Pass);
		} else {
			reportMessage("Selected store is not displayed in Make ready page", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the store name in Make Ready page is not changed")
	public void verifyTheStoreNameInMakeReadyPageIsNotChanged() {
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		makeready.getMakeLnkStorename().waitForPresent(5000);
		String actStore = makeready.getMakeLnkStorename().getText();
		String expStore = getBundle().getString("availStore");

		if (PerfectoUtils.removeSpecialCharacters(actStore).equals(PerfectoUtils.removeSpecialCharacters(expStore))) {
			reportMessage("Store is not modified in Make ready page", MessageTypes.Pass);
		} else {
			reportMessage("Store is modified in Make ready page", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I validate store selection pop up is displayed")
	public void iValidateStoreSelectionPopUpIsDisplayed() {
		SelectStoreTestPage selectstore = new SelectStoreTestPage();

		selectstore.waitForAjaxToComplete();
		selectstore.getSelstoreLblPickupstoretitle().waitForPresent(10000);
		selectstore.getSelstoreLblPickupstoretitle().verifyPresent();
	}

	@QAFTestStep(description = "I add Make Ready product to cart")
	public void iAddMakeReadyProductToCart() {
		MakeReadyTestPage makeready = new MakeReadyTestPage();
		boolean isProductAvail = false;

		for (MakeReadyProducts product : makeready.getMakeLiBoxProductcatridges()) {

			if (product.getMakeBtnAddtocart().isPresent()) {
				String productName = product.getMakeLblProductname().getText();
				product.getMakeBtnAddtocart().click();
				isProductAvail = true;
				break;
			}
		}

		if (!isProductAvail)
			reportMessage("Make Ready product with Add to Cart is not available", MessageTypes.Fail);
		else
			reportMessage("Added Make Ready product to Cart", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Validate the Flowers Make ready page products styling")
	public void validateTheFlowersMakeReadyPageProducts() {
		MakeReadyTestPage makeready = new MakeReadyTestPage();
		boolean isEachPresent = false;

		makeready.waitForAjaxToComplete();
		if (makeready.getMakeLiBoxProductcatridges().size() == 36)
			reportMessage("36 Products are available in Make Ready page", MessageTypes.Pass);
		else
			reportMessage("36 Products are not available in Make Ready page", MessageTypes.Fail);

		for (QAFWebElement productName : makeready.getMakeLiLblProductname()) {

			if (productName.getText().toLowerCase().contains("each")
					|| productName.getText().toLowerCase().contains("sheet"))
				isEachPresent = true;
			else {
				isEachPresent = false;
				break;
			}
		}
		if (isEachPresent)
			reportMessage("All Flower Make ready products contains Each or Sheet Text", MessageTypes.Pass);
		else
			reportMessage("All Flower Make ready products not contains Each or Sheet Text", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Validate the Party trays Make ready page products styling")
	public void validateThePartyTraysMakeReadyPageProductsStyling() {
		MakeReadyTestPage makeready = new MakeReadyTestPage();
		boolean isServesPresent = false;

		makeready.waitForAjaxToComplete();
		if (makeready.getMakeLiBoxProductcatridges().size() == 36)
			reportMessage("36 Products are available in Make Ready page", MessageTypes.Pass);
		else
			reportMessage("36 Products are not available in Make Ready page", MessageTypes.Fail);

		for (QAFWebElement productName : makeready.getMakeLiLblProductname()) {

			if (productName.getText().toLowerCase().contains("serves"))
				isServesPresent = true;
			else {
				isServesPresent = false;
				break;
			}
		}
		if (isServesPresent)
			reportMessage("All Party Tray Make ready products contains Serves Text", MessageTypes.Pass);
		else
			reportMessage("All Flower Make ready products not contains Serves Text", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Validate the Cakes Make ready page products styling")
	public void validateTheCakesMakeReadyPageProductsStyling() {
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		makeready.waitForAjaxToComplete();
		if (makeready.getMakeLiBoxProductcatridges().size() == 36)
			reportMessage("36 Products are available in Make Ready page", MessageTypes.Pass);
		else
			reportMessage("36 Products are not available in Make Ready page", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Navigate to Cakes Make ready tab in Make Ready page")
	public void navigateToCakesMakeReadyTabInMakeReadyPage() {
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		makeready.getMakeLiLblTabs().get(2).verifyPresent();
		makeready.getMakeLiLblTabs().get(2).click();
		makeready.waitForAjaxToComplete();
		if (makeready.getMakeLiLblTabs().get(2).getAttribute("class").contains("active")) {
			reportMessage("Navigated to Cakes Tab in Make Ready Page", MessageTypes.Pass);
		} else {
			reportMessage("Not Navigated to Cakes Tab in Make Ready Page", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Navigate to Party trays Make ready tab in Make Ready page")
	public void navigateToPartyTraysMakeReadyTabInMakeReadyPage() {
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		makeready.getMakeLiLblTabs().get(0).verifyPresent();
		makeready.getMakeLiLblTabs().get(0).click();
		makeready.waitForAjaxToComplete();
		if (makeready.getMakeLiLblTabs().get(0).getAttribute("class").contains("active")) {
			reportMessage("Navigated to Party trays Tab in Make Ready Page", MessageTypes.Pass);
		} else {
			reportMessage("Not Navigated to Party trays Tab in Make Ready Page", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Navigate to Flowers Make ready tab in Make Ready page")
	public void navigateToFlowersMakeReadyTabInMakeReadyPage() {
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		makeready.getMakeLiLblTabs().get(1).verifyPresent();
		makeready.getMakeLiLblTabs().get(1).click();
		makeready.waitForAjaxToComplete();
		if (makeready.getMakeLiLblTabs().get(1).getAttribute("class").contains("active")) {
			reportMessage("Navigated to Flowers Tab in Make Ready Page", MessageTypes.Pass);
		} else {
			reportMessage("Not Navigated to Flowers Tab in Make Ready Page", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify make ready products are available")
	public void iVerifyMakeReadyProductsareAvailable() {
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		if (makeready.getMakeLblNoofproducts().isPresent()) {
			String txtProducts = makeready.getMakeLblNoofproducts().getText();
			String[] noOfProducts = txtProducts.split("Products");
			reportMessage(noOfProducts[0] + " make ready products are available in the selected store",
					MessageTypes.Pass);
		} else {
			reportMessage("In the selected store make ready products are not available", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify make ready product result catridges")
	public void iVerifyMakeReadyProductresultcatridges() {
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		if (makeready.getMakeImgMakereadyfirstproduct().getCssValue("height").equals("200px"))
			reportMessage("Make ready products image height is large "
					+ makeready.getMakeImgMakereadyfirstproduct().getCssValue("height"), MessageTypes.Pass);
		else
			reportMessage("Make ready products image height is not large "
					+ makeready.getMakeImgMakereadyfirstproduct().getCssValue("height"), MessageTypes.Fail);

		if (makeready.getMakeImgMakereadyfirstproduct().getCssValue("max-width").equals("100%"))
			reportMessage("Make ready products image width is large "
					+ makeready.getMakeImgMakereadyfirstproduct().getCssValue("max-width"), MessageTypes.Pass);
		else
			reportMessage("Make ready products image width is not large "
					+ makeready.getMakeImgMakereadyfirstproduct().getCssValue("max-width"), MessageTypes.Fail);

		if (!(makeready.getMakeLblLastpdtinrow("1").getAttribute("class").contains("last"))
				&& !(makeready.getMakeLblLastpdtinrow("2").getAttribute("class").contains("last"))
				&& !(makeready.getMakeLblLastpdtinrow("3").getAttribute("class").contains("last"))
				&& makeready.getMakeLblLastpdtinrow("4").getAttribute("class").contains("last"))
		
		if(makeready.getMakeImgMakereadyfirstproduct().getCssValue("width").equals("274.75px"))
			reportMessage("Make ready products images are large", MessageTypes.Pass);
		else
			reportMessage("Make ready products images are not large", MessageTypes.Fail);
		
		if(!(makeready.getMakeLblLastpdtinrow("1").getAttribute("class").contains("last")) && !(makeready.getMakeLblLastpdtinrow("2").getAttribute("class").contains("last")) && !(makeready.getMakeLblLastpdtinrow("3").getAttribute("class").contains("last")) && makeready.getMakeLblLastpdtinrow("4").getAttribute("class").contains("last"))
			reportMessage("Maximum 4 products per row are displayed", MessageTypes.Pass);
		else
			reportMessage("Maximum 4 products per row is not displayed", MessageTypes.Fail);

		if (makeready.getMakeLblAddtolist().isPresent())
			reportMessage("Add to list button is not hidden in Make ready products", MessageTypes.Fail);
		else
			reportMessage("Add to list button is hidden in Make ready products", MessageTypes.Pass);

		if (makeready.getMakeLnkStorename().isPresent())
			reportMessage("Store selector are displayed", MessageTypes.Pass);
		else
			reportMessage("Store selector are not displayed", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I navigate to Make Ready PDP by clicking on the product")
	public void iNavigateToMakeReadyPDPByClickingOnTheProduct() {
		MakeReadyTestPage makeready = new MakeReadyTestPage();
		
		try {
			makeready.getMakeLiBoxProductcatridges().get(0).verifyPresent();
			String productName = makeready.getMakeLiBoxProductcatridges().get(0).getMakeLblProductname().getText();
			makeready.getMakeLiBoxProductcatridges().get(0).getMakeImgProduct().click();
			reportMessage("Clicked on Make ready product", MessageTypes.Pass);
		} catch (Exception e) {
			reportMessage("Failed to click on Make ready product", MessageTypes.Fail);
		}
	}
}
