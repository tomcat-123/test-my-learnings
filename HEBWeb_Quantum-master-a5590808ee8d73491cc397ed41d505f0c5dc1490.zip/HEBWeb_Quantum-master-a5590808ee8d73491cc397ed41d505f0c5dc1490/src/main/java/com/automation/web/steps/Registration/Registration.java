package com.automation.web.steps.Registration;

import com.automation.web.commonutils.Logger;
import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.commonutils.WriteXMLFile;
import com.automation.web.pages.homepage.FrontdoorTestPage;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.login.LoginTestPage;
import com.automation.web.pages.myAccount.myAccountFlyout;
import com.automation.web.pages.myAccount.myAccountLandingTestPage;
import com.automation.web.pages.registration.RegistrationTestPage;
import com.automation.web.pages.registration.ThankYouTestPage;
import com.automation.web.steps.CommonStepDef;
import com.automation.web.steps.homepage.HomePage;
import com.automation.web.steps.myaccount.myaccountpage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.awt.Color;
import java.util.StringTokenizer;

/*List of steps in Registration

* I navigate to Register page by clicking Register button
* I register a new account
* I register a new account for adding recipebox
* I click Got it Thanks button in Thank You Page
* I register a new account with data{0}{1}{2}{3}
* I click Got it Please enter valid first name error message
* I click Got it Please enter a valid email address error message
* I click Got it Please enter a valid password error message
* I register as a new user
* I log out from the application and login using registered email

*/

public class Registration {

	/**
	 * Navigate to Register page by clicking Register button
	 */
	@QAFTestStep(description = "I navigate to Register page by clicking Register button")
	public static void iNavigateToRegisterPageByClickingRegisterButton() {
		InStoreHomePage instore = new InStoreHomePage();
		FrontdoorTestPage front = new FrontdoorTestPage();
		
		instore.getHomeLblRegister().verifyPresent();
		instore.getHomeLblRegister().click();
		front.getFrontImgFav().verifyPresent();
	}
	
	@QAFTestStep(description = "I Verify the functionality of Home Page Registration")
	public static void iVerifyfunctionalityHomePageRegistration() {
		RegistrationTestPage register = new RegistrationTestPage();
		LoginTestPage login = new LoginTestPage();
		
		register.getRgstrLblHeader().verifyPresent();
		register.getRgstrLblYouraccounttxt().verifyPresent();
		register.getRgstrEdtFirstname().verifyPresent();
		register.getRgstrEdtLastname().verifyPresent();
		register.getRgstrEdtEmail().verifyPresent();
		register.getRgstrEdtPassword().verifyPresent();
		register.getRgstrLblChararctermin().verifyPresent();
		if(register.getRgstrLblChararctermin().getText().equals(getBundle().getString("register.characterminimum"))){
			PerfectoUtils.reportMessage("Minimum characters needed for password is displayed",MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Minimum characters needed for password is not displayed",MessageTypes.Fail);
		}
		register.getRgstrLblSpecialchar().verifyPresent();
		if(register.getRgstrLblSpecialchar().getText().equals(getBundle().getString("register.specialchar"))){
			PerfectoUtils.reportMessage("Special characters needed for password is displayed",MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Special characters needed for password is not displayed",MessageTypes.Fail);
		}
		register.getRgstrChkAlert().verifyPresent();
		register.getRgstrLblAlerts().verifyPresent();
		if(register.getRgstrLblAlerts().getText().contains(getBundle().getString("register.alerttext"))){
			PerfectoUtils.reportMessage("Alert text is displayed",MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Alert text is not displayed",MessageTypes.Fail);
		}
		register.getRgstrBtnCreateaccount().verifyPresent();
		register.getRgstrLnkTermsconditions().verifyPresent();
		register.getRgstrLnkPrivacyPolicy().verifyPresent();
		login.getLoginImgLogo().verifyPresent();
	}
	
	@QAFTestStep(description = "I verify that error messages when mandatory fields are left blank")
	public static void iVerifyErrorMessagesWhenMandatoryFieldsAreLeftBlank() {
		RegistrationTestPage register = new RegistrationTestPage();
		
		register.getRgstrBtnCreateaccount().click();
		
		register.getRgstrLblAllblankFirstnameError().verifyPresent();
		if(register.getRgstrLblAllblankFirstnameError().getText().contains(getBundle().getString("register.firstnameerror"))){
			PerfectoUtils.reportMessage("First name required is displayed",MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("First name required is not displayed",MessageTypes.Fail);
		}
		register.getRgstrLblAllblankEmailError().verifyPresent();
		if(register.getRgstrLblAllblankEmailError().getText().contains(getBundle().getString("register.emailerror"))){
			PerfectoUtils.reportMessage("Email required is displayed",MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Email required is not displayed",MessageTypes.Fail);
		}
		register.getRgstrLblAllblankPasswordError().verifyPresent();
		if(register.getRgstrLblAllblankPasswordError().getText().contains(getBundle().getString("register.passworderror"))){
			PerfectoUtils.reportMessage("Password error message "+getBundle().getString("register.passworderror")+" is displayed",MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Password error message "+getBundle().getString("register.passworderror")+" is not displayed",MessageTypes.Fail);
		}
		
		String hexFirstName = convertRGBToHex(register.getRgstrEdtFirstname().getCssValue("border-color"));
		if(hexFirstName.equals(getBundle().getString("register.errorColor"))){
			PerfectoUtils.reportMessage("Firstname Fields are displayed in red",MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Firstname Fields are not displayed in red",MessageTypes.Fail);
		}
		
		String hexEmail = convertRGBToHex(register.getRgstrEdtEmail().getCssValue("border-color"));
		if(hexEmail.equals(getBundle().getString("register.errorColor"))){
			PerfectoUtils.reportMessage("Email Fields are displayed in red",MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Email Fields are not displayed in red",MessageTypes.Fail);
		}
		
		String hexPassword = convertRGBToHex(register.getRgstrEdtPassword().getCssValue("border-color"));
		if(hexPassword.equals(getBundle().getString("register.errorColor"))){
			PerfectoUtils.reportMessage("Password Fields are displayed in red",MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Password Fields are not displayed in red",MessageTypes.Fail);
		}
		
	}
	
	public static String convertRGBToHex(String color){
		String s1 = color.substring(4);
		color = s1.replace(')', ' ');
		StringTokenizer st = new StringTokenizer(color);
		int r = Integer.parseInt(st.nextToken(",").trim());
		int g = Integer.parseInt(st.nextToken(",").trim());
		int b = Integer.parseInt(st.nextToken(",").trim());
		Color c = new Color(r, g, b);
		String hexColor = "#"+Integer.toHexString(c.getRGB()).substring(2);
		return hexColor;
	}
	
	@QAFTestStep(description = "I validate that account registration email address allows underscores")
	public void iValidatethataccountregistrationemailaddressallowsunderscores() {
		RegistrationTestPage register = new RegistrationTestPage();
		
		iRegisterANewAccountWithData(getBundle().getString("Users.ValidFirstName"),getBundle().getString("Users.ValidLastName"),getBundle().getString("Users.ValidEmailwithUnderscore"),getBundle().getString("Users.ValidPassword"));
		register.getRgstrBtnCreateaccount().click();
	}

	/**
	 * Register new account with random data
	 */
	@QAFTestStep(description = "I register a new account")
	public static void iRegisterANewAccount() {
		RegistrationTestPage registration = new RegistrationTestPage();
		ThankYouTestPage thankYou = new ThankYouTestPage();
		
		String password = getBundle().getString("register.defaultPassword");
		String email;

		registration.getRegistrationBean().fillRandomData();
		registration.getRegistrationBean().setPassword(password);
		email = registration.getRegistrationBean().getEmail();
		getBundle().setProperty("myEmail", email);
		registration.getRegistrationBean().fillUiElements();
		getBundle().setProperty("firstName", registration.getRgstrEdtFirstname().getText());
		PerfectoUtils.scrolltoelement(registration.getRgstrBtnCreateaccount());
		registration.getRgstrBtnCreateaccount().click();
		PerfectoUtils.reportMessage("Clicked on Create Account button..",MessageTypes.Pass);
		
		try {
			thankYou.getThnkuLblHeader().waitForPresent(50000);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured during registration..",MessageTypes.Pass);
			registration.getRgstrEdtPassword().click();
			registration.getRgstrEdtPassword().clear();
			registration.getRgstrEdtPassword().sendKeys(password);
			
			PerfectoUtils.scrolltoelement(registration.getRgstrBtnCreateaccount());
			registration.getRgstrBtnCreateaccount().click();
			PerfectoUtils.reportMessage("Clicked on Create Account button again..",MessageTypes.Pass);
		}
		
		PerfectoUtils.reportMessage("Registered for email: " + email, MessageTypes.Pass);
		
	}
	
	@QAFTestStep(description = "I register a new account for adding recipebox")
	public static void iRegisterANewAccountnopopup() {
		RegistrationTestPage registration = new RegistrationTestPage();
		ThankYouTestPage thankYou = new ThankYouTestPage();
		
		String password = getBundle().getString("register.defaultPassword");
		String email;

		registration.getRegistrationBean().fillRandomData();
		registration.getRegistrationBean().setPassword(password);
		email = registration.getRegistrationBean().getEmail();
		getBundle().setProperty("myEmail", email);
		registration.getRegistrationBean().fillUiElements();
		
		PerfectoUtils.scrolltoelement(registration.getRgstrBtnCreateaccount());
		registration.getRgstrBtnCreateaccount().click();
		PerfectoUtils.reportMessage("Clicked on Create Account button..",MessageTypes.Pass);
		
		PerfectoUtils.reportMessage("Registered for email: " + email, MessageTypes.Pass);
		
	}

	/**
	 * Click Got it Thanks button in Thank You Page
	 */
	@QAFTestStep(description = "I click Got it Thanks button in Thank You Page")
	public static void iClickGotItThanksButtonInThankYouPage() {
		ThankYouTestPage thankYou = new ThankYouTestPage();
		RegistrationTestPage registration = new RegistrationTestPage();

		try {
			thankYou.getThnkuLblHeader().waitForPresent(5000);
			try {
				Logger.saveEmailAndPassword();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (Exception e) {
			if (registration.getRgstrLblEmailError().isPresent()) {
				PerfectoUtils.reportMessage("Email error occurred during registration", MessageTypes.Fail);
				PerfectoUtils.scrolltoelement(thankYou.getThnkuLblHostaddress());
				PerfectoUtils.reportMessage("Executed in Host: "+ thankYou.getThnkuLblHostaddress().getText(), MessageTypes.Fail);
			}
		}
		thankYou.getThnkuLblHeader().verifyPresent();
		thankYou.getThnkuBtnGotit().click();
	}

	/**
	 * Entering Invalid firstname during registration
	 */

	@QAFTestStep(description = "I register a new account with data{0}{1}{2}{3}")
	public void iRegisterANewAccountWithData(String firstName, String lastName, String email, String password) {
		RegistrationTestPage registration = new RegistrationTestPage();
		registration.getRgstrEdtFirstname().waitForPresent(5000);
		CommonStepDef.entervalueintothetextbox(registration.getRgstrEdtFirstname(), firstName);
		CommonStepDef.entervalueintothetextbox(registration.getRgstrEdtLastname(), lastName);
		CommonStepDef.entervalueintothetextbox(registration.getRgstrEdtEmail(), email);
		CommonStepDef.entervalueintothetextbox(registration.getRgstrEdtPassword(), password);
		registration.getRgstrBtnCreateaccount().verifyPresent();

	}

	@QAFTestStep(description = "I click Got it Please enter valid first name error message")
	public void iRegisterANewAccountwithinvalidfirstname() {
		RegistrationTestPage registration = new RegistrationTestPage();
		registration.getRgstrBtnCreateaccount().click();
		registration.getRgstrLblfirstnameerror().waitForPresent(5000);
		String firstNameError = registration.getRgstrLblfirstnameerror().getText();
		if (firstNameError.contains("Please enter valid first name")) {
			PerfectoUtils.reportMessage("User is unable to Register with invalid firstname", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User is able to Register with invalid firstname", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I click Got it Please enter a valid email address error message")
	public void iRegisterANewAccountwithinvalidEmail() {
		RegistrationTestPage registration = new RegistrationTestPage();
		
		PerfectoUtils.scrolltoelement(registration.getRgstrBtnCreateaccount());
		registration.getRgstrBtnCreateaccount().click();
		registration.getRgstrLblEmailError().waitForPresent(5000);
		String emailError = registration.getRgstrLblEmailError().getText();
		if (emailError.contains("Please enter a valid email address")) {
			PerfectoUtils.reportMessage("User is unable to Register with invalid Email Address", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User is able to Register with invalid Email Address", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I click Got it Please enter a valid password error message")
	public void iRegisterANewAccountwithinvalidpassword() {
		RegistrationTestPage registration = new RegistrationTestPage();		
		registration.getRgstrBtnCreateaccount().click();
		registration.getRgstrLblPasswordError().waitForPresent(5000);
		String passwordError = registration.getRgstrLblPasswordError().getText();
		if (passwordError.contains("Please enter a valid password")) {
			PerfectoUtils.reportMessage("User is unable to Register with invalid Password", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User is able to Register with invalid Password", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I register as a new user")
	public void iRegisterAsNewUser() {
		iNavigateToRegisterPageByClickingRegisterButton();
		iRegisterANewAccount();
		iClickGotItThanksButtonInThankYouPage();
	}
	
	@QAFTestStep(description = "I register as a new user from instore home page")
	public void iRegisterAsNewUserfrominstorehomepage() {
		HomePage home = new HomePage();
		
		home.iNavigateToInstoreHomePage();
		iNavigateToRegisterPageByClickingRegisterButton();
		iRegisterANewAccount();
		iClickGotItThanksButtonInThankYouPage();
	}
	
	@QAFTestStep(description = "I log out from the application and login using registered email")
	public static void iLogoutfromapplication() {
		InStoreHomePage inStoreHomePage = new InStoreHomePage();
		LoginTestPage login = new LoginTestPage();
		myaccountpage myAcc = new myaccountpage();
		HomePage home = new HomePage();		
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		if (frontdoor.getFrontLblExploremystore().isPresent())
		{
		frontdoor.getFrontLblExploremystore().waitForPresent(5000);
		frontdoor.getFrontLblExploremystore().click();
		PerfectoUtils.reportMessage("Clicked on Explore My Store Hero Image", MessageTypes.Pass);
		inStoreHomePage.getHomeImgMyaccount().waitForPresent(50000);
		}
		
		PerfectoUtils.mouseoverandclick(inStoreHomePage.getHomeImgMyaccount(), login.getLoginLnkLogout());
		PerfectoUtils.reportMessage("Clicked Log out link from flyout..");
		
		String password = getBundle().getString("register.defaultPassword");
		
		CommonStepDef.entervalueintothetextbox(login.getLoginLblPassword(), password);
		myAcc.iClickonLoginbutton();
		home.iNavigateToInstoreHomePage();

	}
	
	@QAFTestStep(description = "I am a hot user with new registration and login as cold user")
	public static void iAmAHotUserWithNewRegistrationandLoginasColdUser() {
		InStoreHomePage inStoreHomePage = new InStoreHomePage();
		LoginTestPage login = new LoginTestPage();
		
		HomePage.iAmOnHomePage();
		String url = PerfectoUtils.getDriver().getCurrentUrl();
		HomePage.iNavigateToInstoreHomePage();
		Registration.iNavigateToRegisterPageByClickingRegisterButton();
		Registration.iRegisterANewAccount();
		Registration.iClickGotItThanksButtonInThankYouPage();
		PerfectoUtils.mouseoverandclick(inStoreHomePage.getHomeImgMyaccount(), login.getLoginLnkLogout());
		PerfectoUtils.getDriver().get(url);
	}

	
}
