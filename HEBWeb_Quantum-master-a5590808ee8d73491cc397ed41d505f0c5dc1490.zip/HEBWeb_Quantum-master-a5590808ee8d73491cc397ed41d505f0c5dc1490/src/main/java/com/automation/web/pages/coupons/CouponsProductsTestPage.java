package com.automation.web.pages.coupons;

import java.util.List;

import com.automation.web.components.coupons.CouponProductBlocks;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CouponsProductsTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "couponprdts.lbl.header")
	private QAFWebElement couponprdtsLblHeader;

	@FindBy(locator = "couponprdts.box.productblock")
	private List<CouponProductBlocks> couponprdtsBoxProductblock;
	
	@FindBy(locator = "couponprdts.rbtn.inmystore")
	private QAFWebElement rbtnInmystore;
	
	@FindBy(locator = "couponprdts.rbtn.soldonline")
	private QAFWebElement rbtnSoldonline;
	
	@FindBy(locator = "couponprdts.btn.addtolist")
	private QAFWebElement rbtnAddtoList;
	
	public QAFWebElement getRbtnInmystore() {
		return rbtnInmystore;
	}


	public QAFWebElement getRbtnSoldonline() {
		return rbtnSoldonline;
	}
	
	public QAFWebElement getRbtnAddtoList() {
		return rbtnAddtoList;
	}


	/**
	 * Textview of Coupons header
	 */
	public QAFWebElement getCouponprdtsLblHeader(){ return couponprdtsLblHeader; }

	/**
	 * Blockview of Coupons products
	 */
	public List<CouponProductBlocks> getCouponprdtsBoxProductblock(){ return couponprdtsBoxProductblock; }

}