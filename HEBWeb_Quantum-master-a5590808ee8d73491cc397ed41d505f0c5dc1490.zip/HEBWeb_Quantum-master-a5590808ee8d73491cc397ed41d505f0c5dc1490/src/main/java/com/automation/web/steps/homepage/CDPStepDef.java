package com.automation.web.steps.homepage;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.products.CDPTestPage;
import com.automation.web.pages.search.PdtsearchresultTestPage;
import com.automation.web.pages.storelocator.FindAStoreTestPage;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of steps in CDPStepDef

* Verify the Properties of CDP page
* Navigate to Find a Store page
* Enter Valid zipcode and select search button from Find a Store Page
* Verify the Selected Store name is available in the header
* Enter valid zipcode {0} using mouse hover
* Select a Store from Find a Store page
* Select In My Store from Filter products by availablibity
* I Should see the products in CDP page
* Try to add more than {0} qty to cart
* I should see the message product has reached maximum qty
* Verify the Cart quantity is updated with the minimum order quantity
* Verify the sort options in CDP page
* Verify the sort options in search results page

*/

public class CDPStepDef {

	@QAFTestStep(description = "Verify the Properties of CDP page")
	public void verifyThePropertiesOfCDPPage() {
		CDPTestPage cdp = new CDPTestPage();

		cdp.getCdpLblPagetitle().verifyPresent();
		cdp.getCdpLblSortby().verifyPresent();
		cdp.getCdpLblSortoptions().verifyPresent();
		cdp.getCdpLblSubcategorytitle().verifyPresent();
		cdp.getCdpImgLeftnav().verifyPresent();
		PerfectoUtils.scrolltoelement(cdp.getCdpLblRefineresults());
		cdp.getCdpLblRefineresults().verifyPresent();
		PerfectoUtils.scrolltoelement(cdp.getCdpLblPricerange());
		cdp.getCdpLblPricerange().verifyPresent();
		cdp.getCdpImgPricerangeslider().verifyPresent();

	}

	@QAFTestStep(description = "Navigate to Find a Store page")
	public void navigateToFindAStorePage() {
		CDPTestPage cdp = new CDPTestPage();
		FindAStoreTestPage findstore = new FindAStoreTestPage();

		/*
		 * cdp.getCdpLnkFindyourstore().waitForPresent(1000);
		 * cdp.getCdpLnkFindyourstore().click();
		 */
		PerfectoUtils.mouseover(cdp.getCdpLnkFindyourstore());

		String validZipcode = getBundle().getString("storelocator.valid.zipcode");

		cdp.getCdpTxtEnterzipcodemousehover().sendKeys(validZipcode);
		cdp.getCdpBtnFindmousehover().click();
		PerfectoUtils.reportMessage("Clicked on Find your store option from the header..");

		try {
			findstore.getFindstoreLblPagetitle().waitForPresent(5000);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Wait timeout on Navigating to Find a Store page..", MessageTypes.Fail);
		}

		if (findstore.getFindstoreLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Find a Store page..");
		} else {
			PerfectoUtils.reportMessage("Error occured while navigating to Find a Store page..", MessageTypes.Fail);
		}

		int storeResultsSize = findstore.getFindstoreLiStorenameslist().size();

		if (storeResultsSize > 0) {
			PerfectoUtils.reportMessage(storeResultsSize + " results found..");
			PerfectoUtils.reportMessage("Selecting the first store..");

			String StoreName = findstore.getFindstoreLiStorenameslist().get(0).getText();
			getBundle().setProperty("SelectedStorename", StoreName);

			findstore.getFindstoreBtnSelect().get(0).click();
			PerfectoUtils.reportMessage("Clicked on Select button for the first store..");

		} else {
			PerfectoUtils.reportMessage("No Stores found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Enter Valid zipcode and select search button from Find a Store Page")
	public void enterValidZipcodeAndSelectSearchButtonFromFindAStorePage() {
		FindAStoreTestPage findstore = new FindAStoreTestPage();

		String validZipcode = getBundle().getString("storelocator.valid.zipcode");

		findstore.getFindstoreTxtEnterzipcode().waitForPresent(1000);
		findstore.getFindstoreTxtEnterzipcode().click();
		findstore.getFindstoreTxtEnterzipcode().sendKeys(validZipcode);
		PerfectoUtils.reportMessage("Entered Valid zipcode " + validZipcode);

		findstore.getFindstoreBtnSearch().click();
		PerfectoUtils.reportMessage("Clicked on Search button..");

		int storeResultsSize = findstore.getFindstoreLiStorenameslist().size();

		if (storeResultsSize > 0) {
			PerfectoUtils.reportMessage(storeResultsSize + " results found..");
			PerfectoUtils.reportMessage("Selecting the first store..");

			String StoreName = findstore.getFindstoreLiStorenameslist().get(0).getText();
			getBundle().setProperty("SelectedStorename", StoreName);

			findstore.getFindstoreBtnSelect().get(0).click();
			PerfectoUtils.reportMessage("Clicked on Select button for the first store..");

		} else {
			PerfectoUtils.reportMessage("No Stores found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify the Selected Store name is available in the header")
	public void verifyTheSelectedStoreNameIsAvailableInTheHeader() {
		CDPTestPage cdp = new CDPTestPage();

		try {
			cdp.getCdpLblPagetitle().waitForPresent(30000);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Wait time out on Selecting store and navigating back to cdp..",
					MessageTypes.Fail);
		}

		String selectedStorename = getBundle().getString("SelectedStorename");
		String storeNameFromCDP = cdp.getCdpLnkMystorename().getText();

		if (selectedStorename.equalsIgnoreCase(storeNameFromCDP)) {
			PerfectoUtils.reportMessage("Store name changed successfully..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Store names doesn't match..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Enter valid zipcode {0} using mouse hover")
	public static void enterValidZipcodeUsingMouseHover(String validZipcode) {
		CDPTestPage cdp = new CDPTestPage();
		FindAStoreTestPage findstore = new FindAStoreTestPage();

		PerfectoUtils.mouseover(cdp.getCdpLnkFindyourstore());

		cdp.getCdpTxtEnterzipcodemousehover().click();
		cdp.getCdpTxtEnterzipcodemousehover().sendKeys(validZipcode);
		cdp.getCdpBtnFindmousehover().click();
		PerfectoUtils.reportMessage("Clicked on Find your store option from the header..");

		try {
			findstore.getFindstoreLblPagetitle().waitForPresent(5000);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Wait timeout on Navigating to Find a Store page..", MessageTypes.Fail);
		}

		if (findstore.getFindstoreLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Find a Store page..");
		} else {
			PerfectoUtils.reportMessage("Error occured while navigating to Find a Store page..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Select a Store from Find a Store page")
	public void selectAStoreFromFindAStorePage() {
		FindAStoreTestPage findstore = new FindAStoreTestPage();

		int storeResultsSize = findstore.getFindstoreLiStorenameslist().size();

		if (storeResultsSize > 0) {
			PerfectoUtils.reportMessage(storeResultsSize + " results found..");
			PerfectoUtils.reportMessage("Selecting the first store..");

			String StoreName = findstore.getFindstoreLiStorenameslist().get(0).getText();
			getBundle().setProperty("SelectedStorename", StoreName);

			findstore.getFindstoreBtnSelect().get(0).click();
			PerfectoUtils.reportMessage("Clicked on Select button for the first store..");

		} else {
			PerfectoUtils.reportMessage("No Stores found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Select In My Store from Filter products by availablibity")
	public void selectInMyStoreFromFilterProductsByAvailablibity() {
		CDPTestPage cdp = new CDPTestPage();

		String validZipcode = getBundle().getString("storelocator.valid.zipcode");
		PerfectoUtils.scrolltoelement(cdp.getCdpLblFilterbyavailability());

		cdp.getCdpLblInmystore().waitForPresent(1000);
		cdp.getCdpLblInmystore().click();
		PerfectoUtils.reportMessage("Clicked on In My Store..");

		if (cdp.getCdpTxtEnterzipcode().isPresent()) {
			PerfectoUtils.reportMessage("Entering the Zipcode to view the products..");
			cdp.getCdpTxtEnterzipcode().clear();
			cdp.getCdpTxtEnterzipcode().sendKeys(validZipcode);
			PerfectoUtils.reportMessage("Entered zipcode " + validZipcode);

			cdp.getCdpBtnGo().click();
			PerfectoUtils.reportMessage("Clicked on Go button..");

			try {
				cdp.getCdpBtnSelectstoreslist().get(0).waitForPresent(10000);
				if (cdp.getCdpBtnSelectstoreslist().size() > 0) {
					cdp.getCdpBtnSelectstoreslist().get(0).click();
					PerfectoUtils.reportMessage("Selected the first store..");
				} else {
					PerfectoUtils.reportMessage("No Stores found..", MessageTypes.Fail);
				}
			} catch (Exception e) {
				PerfectoUtils.reportMessage("Wait timeout for loading the stores..", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("Enter the Zipcode to select store section not found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I Should see the products in CDP page")
	public void iShouldSeeTheProductsInCDPPage() {
		CDPTestPage cdp = new CDPTestPage();

		try {
			cdp.getCdpLblPagetitle().waitForPresent(3000);
			if (cdp.getCdpLblPagetitle().isPresent()) {
				PerfectoUtils.reportMessage("Navigated to CDP..");
			} else {
				PerfectoUtils.reportMessage("Error occured while navigating to cdp..", MessageTypes.Fail);
			}
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Wait timeout for navigating to cdp..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Try to add more than {0} qty to cart")
	public void tryToAddMoreThanQtyToCart(int qtyLimit) throws Exception {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		int quantity = 0, i = 0;
		int AddtocartSize = pdtsearchresult.getBtnAddToCart().size();

		if (AddtocartSize > 0) {

			while ((quantity <= qtyLimit) && (i <= qtyLimit)) {
				PerfectoUtils.scrolltoelement(pdtsearchresult.getBtnAddToCart().get(0));
				pdtsearchresult.getBtnAddToCart().get(0).waitForPresent(2000);
				pdtsearchresult.getBtnAddToCart().get(0).click();
				Thread.sleep(2000);
				pdtsearchresult.waitForPageToLoad();
				pdtsearchresult.getBtnMinusaddtocart().get(0).waitForPresent(5000);
				pdtsearchresult.getTxtCartQuantity().waitForPresent(10000);
				PerfectoUtils.scrolltoelement(pdtsearchresult.getTxtCartQuantity());
				try {
					pdtsearchresult.getTxtCartQuantity().waitForVisible(5000);
				} catch (Exception e) {
					// ignore
				}
				quantity = Integer.parseInt(pdtsearchresult.getTxtCartQuantity().getText());
				i++;
			}

			if (quantity == qtyLimit) {
				PerfectoUtils.reportMessage("99 items added to cart..", MessageTypes.Pass);
			}
		} else {
			PerfectoUtils.reportMessage("Add to cart not found.", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I should see the message product has reached maximum qty")
	public void iShouldSeeTheMessageProductHasReachedMaximumQty() {
		CDPTestPage cdp = new CDPTestPage();

		try {
			cdp.getCdpLblOrderqtylimiterror().waitForPresent(1000);

			if (cdp.getCdpLblOrderqtylimiterror().isPresent()) {
				PerfectoUtils.reportMessage("Order quantity limit error found..");
				PerfectoUtils.reportMessage("This product has reached its maximum order quantity", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Order quantity limit error not found..", MessageTypes.Fail);
			}

		} catch (Exception e) {
			PerfectoUtils.reportMessage("Wait timeout for the Order quantity limit error message..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Cart quantity is updated with the minimum order quantity")
	public void verifyTheCartQuantityIsUpdatedWithTheMinimumOrderQuantity() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		pdtsearchresult.getTxtCartQuantity().waitForPresent(10000);
		PerfectoUtils.scrolltoelement(pdtsearchresult.getTxtCartQuantity());
		int quantityFromCart = Integer.parseInt(pdtsearchresult.getTxtCartQuantity().getText());
		int minQuantityValue = getBundle().getInt("MinQuantity");

		if (quantityFromCart == minQuantityValue) {
			PerfectoUtils.reportMessage("Cart quantity updated with the minimum order quantity", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cart quantity not updated with the minimum order quantity", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the sort options in CDP page")
	public void verifyTheSortOptionsInCDPPage() {
		CDPTestPage cdp = new CDPTestPage();

		cdp.getCdpLblSortoptions().waitForPresent(1000);

		int sortOptionsSize = cdp.getCdpLblSortoptionslist().size();
		if (sortOptionsSize > 0) {
			PerfectoUtils.reportMessage(sortOptionsSize + " Sort options found..");
			for (QAFWebElement ele : cdp.getCdpLblSortoptionslist()) {
				PerfectoUtils.reportMessage(ele.getText());
			}
		} else {
			PerfectoUtils.reportMessage("Sort options not found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify the sort options in search results page")
	public void verifyTheSortOptionsInSearchResultsPage() {
		verifyTheSortOptionsInCDPPage();
	}

	@QAFTestStep(description = "I navigate to Find a Store page on clicking Find a Store link")
	public void iNavigateToFindAStorePageonClickingFindAStoreLink() {
		CDPTestPage cdp = new CDPTestPage();

		cdp.getCdpLnkFindyourstore().waitForPresent(1000);
		cdp.getCdpLnkFindyourstore().click();
	}
	
	@QAFTestStep(description = "I verify Refine option {0} is available in CDP page")
	public void iVerifyRefineOptionIsAvailableInCDPPage(String refineOption) {
		CDPTestPage cdp = new CDPTestPage();

		cdp.getCdpLblRefineOptionByName(refineOption).waitForPresent(1000);
		cdp.getCdpLblRefineOptionByName(refineOption).verifyPresent();
		cdp.getCdpChkRefineOptionByName(refineOption).verifyPresent();
	}
	
	@QAFTestStep(description = "I validate the products of Refine option {0} alone displayed upon selecting it")
	public void iValidateTheProductsOfRefineOptionAloneDisplayedUponSelectingIt(String refineOption) {
		CDPTestPage cdp = new CDPTestPage();

		String count = cdp.getCdpLblRefineOptionByName(refineOption).getText();
		count = count.substring(count.indexOf("(")).replace("(", "").replace(")", "");
		
		cdp.getCdpChkRefineOptionByName(refineOption).click();
		PerfectoUtils.reportMessage("Refine Option: "+refineOption+" is selected");
		cdp.waitForPageToLoad();
		cdp.waitForAjaxToComplete();
		
		int actSize = cdp.getCdpLiProductblock().size();
		
		if(Integer.parseInt(count)==actSize){
			PerfectoUtils.reportMessage("Only the selected Refine results are displayed", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Refine results are not displayed", MessageTypes.Fail);
		}
		
		PerfectoUtils.scrolltoelement(cdp.getCdpChkRefineOptionByName(refineOption));
		cdp.getCdpChkRefineOptionByName(refineOption).verifyAttribute("checked", "true");
		
		PerfectoUtils.scrolltoelement(cdp.getCdpLblFilterbyavailabilityTypes().get(0));
		String allStores = cdp.getCdpLblFilterbyavailabilityTypes().get(0).getText();
		String inMyStore = cdp.getCdpLblFilterbyavailabilityTypes().get(1).getText();
		String soldOnline = cdp.getCdpLblFilterbyavailabilityTypes().get(2).getText();
		
		System.out.println(allStores.substring(allStores.indexOf("(")));
		
		if(actSize < Integer.parseInt(allStores.substring(allStores.indexOf("(")).replace("(", "").replace(")", ""))){
			PerfectoUtils.reportMessage("Filter type: All Stores is having incorrect product numbers", MessageTypes.Fail);
		}else if(actSize < Integer.parseInt(inMyStore.substring(inMyStore.indexOf("(")).replace("(", "").replace(")", ""))){
			PerfectoUtils.reportMessage("Filter type: In My Store is having incorrect product numbers", MessageTypes.Fail);
		}else if(actSize < Integer.parseInt(soldOnline.substring(soldOnline.indexOf("(")).replace("(", "").replace(")", ""))){
			PerfectoUtils.reportMessage("Filter type: Sold Online is having incorrect product numbers", MessageTypes.Fail);
		}else{
			PerfectoUtils.reportMessage("Validated the Filter types", MessageTypes.Pass);
		}
	}
}