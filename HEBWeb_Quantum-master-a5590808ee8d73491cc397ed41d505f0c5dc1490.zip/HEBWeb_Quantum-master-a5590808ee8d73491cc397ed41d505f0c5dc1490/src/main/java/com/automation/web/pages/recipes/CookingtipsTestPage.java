package com.automation.web.pages.recipes;

import java.util.List;

import com.automation.web.components.CookinghowtoItems;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CookingtipsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "cookingtips.lbl.pageheader")
	private QAFWebElement cookingtipsLblPageheader;
	@FindBy(locator = "cookingtips.lbl.cookingarticles")
	private QAFWebElement cookingtipsLblCookingarticles;
	@FindBy(locator = "cookingtips.lnk.cookingguides")
	private QAFWebElement cookingtipsLnkCookingguides;
	@FindBy(locator = "cookingtips.lbl.firstarticlename")
	private QAFWebElement cookingtipsLblFirstarticlename;

	@FindBy(locator = "cookingtips.lbl.cookinghowtoheader")
	private QAFWebElement cookingtipsLblCookinghowtoheader;
	@FindBy(locator = "cookingtips.lbl.cookinghowtoitemslist")
	private List<CookinghowtoItems> cookingtipsLblCookinghowtoitemslist;
	@FindBy(locator = "cookingtips.lbl.cookinghowtoitemnamelist")
	private List<QAFWebElement> cookingtipsLblCookinghowtoitemnamelist;
	@FindBy(locator = "cookingtips.lbl.cookinghowtoitemtextlist")
	private List<QAFWebElement> cookingtipsLblCookinghowtoitemtextlist;
	@FindBy(locator = "cookingtips.lnk.cookinghowtoitemreadmorelist")
	private List<QAFWebElement> cookingtipsLnkCookinghowtoitemreadmorelist;
	@FindBy(locator = "cookingtips.img.cookinghowtoitemimagelist")
	private List<QAFWebElement> cookingtipsImgCookinghowtoitemimagelist;
	@FindBy(locator = "cookingtips.lbl.articlecategorieslist")
	private List<QAFWebElement> cookingtipsLblArticlecategorieslist;
	@FindBy(locator = "cookingtips.lbl.categoriesheader")
	private QAFWebElement cookingtipsLblCategoriesheader;
	@FindBy(locator = "cookingtips.lbl.articlesnameslist")
	private List<QAFWebElement> cookingtipsLblArticlesnameslist;
	
	@FindBy(locator = "cookingtips.lbl.cookingguidesheader")
	private QAFWebElement lblCookingGuidesHeader;
	@FindBy(locator = "cookingtips.lbl.recipevideosheader")
	private QAFWebElement lblRecipeVideosHeader;
	@FindBy(locator = "cookingtips.lbl.barbecueandbrisketheader")
	private QAFWebElement lblBarbecueAndBrisketHeader;
	@FindBy(locator = "cookingtips.lnk.recipevideos")
	private QAFWebElement lnkRecipeVideos;
	@FindBy(locator = "cookingtips.lnk.barbecueandbrisket")
	private QAFWebElement lnkBarbecueAndBrisket;
	@FindBy(locator = "cookingtips.lnk.grilling")
	private QAFWebElement lnkGrilling;
	@FindBy(locator = "cookingtips.lnk.healthiercooking")
	private QAFWebElement lnkHealthierCooking;
	@FindBy(locator = "cookingtips.lnk.meatandpoultry")
	private QAFWebElement lnkMeatAndPoultry;
	@FindBy(locator = "cookingtips.lnk.seafood")
	private QAFWebElement lnkSeafood;
	@FindBy(locator = "cookingtips.lnk.produce")
	private QAFWebElement lnkProduce;
	@FindBy(locator = "cookingtips.lnk.foodsafety")
	private QAFWebElement lnkFoodSafety;
	@FindBy(locator = "cookingtips.lbl.grillingheader")
	private QAFWebElement lblGrillingHeader;
	@FindBy(locator = "cookingtips.lbl.healthiercookingheader")
	private QAFWebElement lblHealthierCookingHeader;
	@FindBy(locator = "cookingtips.lbl.meatandpoultryheader")
	private QAFWebElement lblMeatAndPoultryHeader;
	@FindBy(locator = "cookingtips.lbl.seafoodheader")
	private QAFWebElement lblSeafoodHeader;
	@FindBy(locator = "cookingtips.lbl.produceheader")
	private QAFWebElement lblProduceHeader;
	@FindBy(locator = "cookingtips.lbl.foodsafetyheader")
	private QAFWebElement lblFoodSafetyHeader;
	@FindBy(locator = "cookingtips.lbl.showing")
	private QAFWebElement lblShowing;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblPageheader() {
		return cookingtipsLblPageheader;
	}
	
	public QAFWebElement getLblShowing() {
		return lblShowing;
	}

	public QAFWebElement getLblCookingarticles() {
		return cookingtipsLblCookingarticles;
	}

	public QAFWebElement getLblCookingguides() {
		return cookingtipsLnkCookingguides;
	}

	public QAFWebElement getLblFirstarticlename() {
		return cookingtipsLblFirstarticlename;
	}

	public QAFWebElement getLblCookinghowtoheader() {
		return cookingtipsLblCookinghowtoheader;
	}

	public List<CookinghowtoItems> getLblCookinghowtoitemslist() {
		return cookingtipsLblCookinghowtoitemslist;
	}

	public List<QAFWebElement> getLblCookinghowtoitemnamelist() {
		return cookingtipsLblCookinghowtoitemnamelist;
	}

	public List<QAFWebElement> getLblCookinghowtoitemtextlist() {
		return cookingtipsLblCookinghowtoitemtextlist;
	}

	public List<QAFWebElement> getLnkCookinghowtoitemreadmorelist() {
		return cookingtipsLnkCookinghowtoitemreadmorelist;
	}

	public List<QAFWebElement> getImgCookinghowtoitemimagelist() {
		return cookingtipsImgCookinghowtoitemimagelist;
	}

	public List<QAFWebElement> getLblArticlecategorieslist() {
		return cookingtipsLblArticlecategorieslist;
	}

	public QAFWebElement getLblCategoriesheader() {
		return cookingtipsLblCategoriesheader;
	}

	public List<QAFWebElement> getLblArticlesnameslist() {
		return cookingtipsLblArticlesnameslist;
	}
	
	public QAFWebElement getLblCookingGuidesHeader() {
		return lblCookingGuidesHeader;
	}
	
	public QAFWebElement getLblRecipeVideosHeader() {
		return lblRecipeVideosHeader;
	}
	
	public QAFWebElement getLblBarbecueAndBrisketHeader() {
		return lblBarbecueAndBrisketHeader;
	}
	
	public QAFWebElement getLnkRecipeVideos() {
		return lnkRecipeVideos;
	}
	
	public QAFWebElement getLnkBarbecueAndBrisket() {
		return lnkBarbecueAndBrisket;
	}
	
	public QAFWebElement getLnkGrilling() {
		return lnkGrilling;
	}
	
	public QAFWebElement getLnkHealthierCooking() {
		return lnkHealthierCooking;
	}
	
	public QAFWebElement getLnkMeatAndPoultry() {
		return lnkMeatAndPoultry;
	}
	
	public QAFWebElement getLnkSeafood() {
		return lnkSeafood;
	}
	
	public QAFWebElement getLnkProduce() {
		return lnkProduce;
	}
	
	public QAFWebElement getLnkFoodSafety() {
		return lnkFoodSafety;
	}
	
	public QAFWebElement getLblGrillingHeader() {
		return lblGrillingHeader;
	}
	
	public QAFWebElement getLblHealthierCookingHeader() {
		return lblHealthierCookingHeader;
	}
	
	public QAFWebElement getLblMeatAndPoultryHeader() {
		return lblMeatAndPoultryHeader;
	}
	
	public QAFWebElement getLblSeafoodHeader() {
		return lblSeafoodHeader;
	}
	
	public QAFWebElement getLblProduceHeader() {
		return lblProduceHeader;
	}
	
	public QAFWebElement getLblFoodSafetyHeader() {
		return lblFoodSafetyHeader;
	}

}
