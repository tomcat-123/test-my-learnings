package com.automation.web.pages.email;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class EmailTemplateTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "email.lbl.header")
	private QAFWebElement emailLblHeader;

	@FindBy(locator = "email.edt.recipentemails")
	private QAFWebElement emailEdtRecipentemails;

	@FindBy(locator = "email.edt.yourname")
	private QAFWebElement emailEdtYourname;

	@FindBy(locator = "email.edt.youremail")
	private QAFWebElement emailEdtYouremail;

	@FindBy(locator = "email.chk.sendmecopy")
	private QAFWebElement emailChkSendmecopy;

	@FindBy(locator = "email.rbt.iamnotrobot")
	private QAFWebElement emailRbtIamnotrobot;

	@FindBy(locator = "email.btn.sendemail")
	private QAFWebElement emailBtnSendemail;

	@FindBy(locator = "email.btn.cancel")
	private QAFWebElement emailBtnCancel;

	@FindBy(locator = "email.iframe.iamnotrobot")
	private QAFWebElement emailIframeIamnotrobot;

	/**
	 * Textview of email page header
	 */
	public QAFWebElement getEmailLblHeader(){ return emailLblHeader; }

	/**
	 * EditTextview of recipent emails
	 */
	public QAFWebElement getEmailEdtRecipentemails(){ return emailEdtRecipentemails; }

	/**
	 * EditTextview of your name
	 */
	public QAFWebElement getEmailEdtYourname(){ return emailEdtYourname; }

	/**
	 * EditTextview of your email
	 */
	public QAFWebElement getEmailEdtYouremail(){ return emailEdtYouremail; }

	/**
	 * CheckBoxview of send me a copy
	 */
	public QAFWebElement getEmailChkSendmecopy(){ return emailChkSendmecopy; }

	/**
	 * RadioButtonview of i am not a robot
	 */
	public QAFWebElement getEmailRbtIamnotrobot(){ return emailRbtIamnotrobot; }

	/**
	 * Buttonview of Send email
	 */
	public QAFWebElement getEmailBtnSendemail(){ return emailBtnSendemail; }

	/**
	 * Buttonview of cancel
	 */
	public QAFWebElement getEmailBtnCancel(){ return emailBtnCancel; }

	/**
	 * iframeview of i am not a robot
	 */
	public QAFWebElement getEmailIframeIamnotrobot(){ return emailIframeIamnotrobot; }

}