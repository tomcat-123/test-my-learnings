package com.automation.web.steps.Curbside;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.homepage.FrontdoorTestPage;
import com.automation.web.pages.storelocator.StoreLocatorTestPage;
import com.perfecto.reportium.client.ReportiumClient;
import com.perfecto.reportium.test.TestContext;
import com.perfecto.reportium.test.result.TestResult;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.NotYetImplementedException;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.perfecto.reportium.client.ReportiumClient;
import com.perfecto.reportium.client.ReportiumClientFactory;
import com.perfecto.reportium.exception.ReportiumException;
import com.perfecto.reportium.model.PerfectoExecutionContext;
import com.perfecto.reportium.model.Project;
import com.perfecto.reportium.test.TestContext;
import com.perfecto.reportium.test.result.TestResultFactory;

/*List of steps in CurbsideSteps

* Validate Curbside link should not present under Store Finder icon
* Validate curbside and click curbside
* Validate whether it navigates to shop.hebtoyou.com
* Check whether hebtoyou page is launched
* Validate the curside details on store fly out

*/

public class CurbsideSteps {

	@QAFTestStep(description = "Validate Curbside link should not present under Store Finder icon")
	public void validateCurbsideLinkShouldNotPresentUnderStoreFinderIcon() {

		StoreLocatorTestPage storeLoc = new StoreLocatorTestPage();

		storeLoc.getTxtCurbside().verifyNotPresent("Curbside");
	}

	@QAFTestStep(description = "Validate curbside and click curbside")
	public void validateCurbsideAndClickCurbside() throws InterruptedException {
		StoreLocatorTestPage storeLoc = new StoreLocatorTestPage();
		FrontdoorTestPage front = new FrontdoorTestPage();
		// storeLoc.getTxtCurbside().isPresent();
		storeLoc.getTxtCurbside().click();
		front.getFrontImgFav().verifyPresent();
	}

	@QAFTestStep(description = "Validate whether it navigates to shop.hebtoyou.com")
	public void validateWhetherItNavigatesToShopHebtoyouCom() {
		StoreLocatorTestPage storeLoc = new StoreLocatorTestPage();
		String winHandleBefore = storeLoc.getTestBase().getDriver().getWindowHandle();

		storeLoc.getTestBase().getDriver().switchTo().window(winHandleBefore);
		System.out.println(storeLoc.getTestBase().getDriver().getCurrentUrl());

		if (storeLoc.getTestBase().getDriver().getCurrentUrl().contains("https://shop.hebtoyou.com")) {
			System.out.println(storeLoc.getTestBase().getDriver().getCurrentUrl() + "Is Opened successfully");

		} else {

			// Report.reportiumAssert("Wrong Page Opened",false);

		}

	}

	@QAFTestStep(description = "Check whether hebtoyou page is launched")
	public void checkWhetherHebtoyouPageIsLaunched() {
		StoreLocatorTestPage storeLoc = new StoreLocatorTestPage();
		String winHandleBefore = storeLoc.getTestBase().getDriver().getWindowHandle();

		storeLoc.getTestBase().getDriver().switchTo().window(winHandleBefore);
		System.out.println(storeLoc.getTestBase().getDriver().getCurrentUrl());

		if (storeLoc.getTestBase().getDriver().getCurrentUrl().equalsIgnoreCase("https://hebtoyou.com/home/")) {
			System.out.println(storeLoc.getTestBase().getDriver().getCurrentUrl() + "  Is Opened successfully");
			// Report.reportiumAssert(storeLoc.getTestBase().getDriver().getCurrentUrl(),true);
		} else {
			// Report.reportiumAssert("Wrong Page Opened",false);
		}
	}

	@QAFTestStep(description = "Validate the curside details on store fly out")
	public void validateTheCursideDetailsOnStoreFlyOut() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontLblStorename().waitForPresent(50000);
		PerfectoUtils.mousehover(frontdoor.getFrontLblStorename());
		frontdoor.getFrontLiLblStoreflyoutstorenames().get(0).verifyPresent();
		String actCurbStore = frontdoor.getFrontLiLblStoreflyoutstorenames().get(2).getText();
		String expCurbStore = "Curbside";

		frontdoor.getFrontLblStoreflyoutcurbphone().verifyPresent();
		frontdoor.getFrontLblStoreflyoutcurbtimings().verifyPresent();

		if (actCurbStore.equalsIgnoreCase(expCurbStore)) {
			PerfectoUtils.reportMessage(
					"Cubside text is displayed, Phone details: " + frontdoor.getFrontLblStoreflyoutcurbphone().getText()
							+ " Timings: " + frontdoor.getFrontLblStoreflyoutcurbtimings().getText(),
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cubside text is not displayed", MessageTypes.Fail);
		}

	}

}