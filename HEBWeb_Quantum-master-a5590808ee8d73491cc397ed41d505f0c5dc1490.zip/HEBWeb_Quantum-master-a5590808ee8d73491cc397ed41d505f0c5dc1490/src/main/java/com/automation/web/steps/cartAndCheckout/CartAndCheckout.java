package com.automation.web.steps.cartAndCheckout;

import static com.automation.web.commonutils.PerfectoUtils.reportMessage;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.support.ui.Select;

import com.automation.web.commonutils.Logger;
import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.components.MakeReadyProducts;
import com.automation.web.components.Shoppingcart;
import com.automation.web.pages.cart.CartTestPage;
import com.automation.web.pages.cart.Donations;
import com.automation.web.pages.checkout.CheckoutTestPage;
import com.automation.web.pages.checkout.ConfirmationTestPage;
import com.automation.web.pages.checkout.DeliveryTestPage;
import com.automation.web.pages.checkout.PaymentTestPage;
import com.automation.web.pages.checkout.PickupdetailsTestPage;
import com.automation.web.pages.checkout.ShippingTestPage;
import com.automation.web.pages.homepage.FrontdoorTestPage;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.make_ready.MakeReadyTestPage;
import com.automation.web.pages.myAccount.QuickReorderTestPage;
import com.automation.web.pages.orderhistory.OrderhistoryTestPage;
import com.automation.web.pages.paymentgateway.GiftcardslandingTestPage;
import com.automation.web.pages.products.CustomizeTestPage;
import com.automation.web.pages.products.PDPTestPage;
import com.automation.web.pages.products.ShopTestPage;
import com.automation.web.pages.registration.RegistrationTestPage;
import com.automation.web.pages.registration.ThankYouTestPage;
import com.automation.web.pages.storelocator.StoreLocatorTestPage;
import com.automation.web.steps.homepage.HomePage;
import com.automation.web.steps.paymentgateway.PaymentGatewayStepdef;
import com.automation.web.steps.search.PdtsearchresultPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

/*List of steps in CartAndCheckout

* I navigate to CheckOut page
* I validate CheckOut page
* I Checkout the items as a hot user
* I Checkout the items as a guest user
* I select Guest CheckOut in CheckOut page
* I enter delivery details in Delivery page
* I make the payments with credit card
* Enter Invalid phonenumber in payments page and select Submit button
* Verify the error message for Invalid Phonenumber in Payments page
* I verify the Order confirmation page
* Select Guest Checkout option
* Enter Invalid phonenumber in Delivery tab and select Submit button
* Verify the error message for Invalid Phonenumber in Delivery tab
* I register and Checkout the items
* I make the payments with gift card alone
* I add deli item to Shopping cart
* I customize the bakery item and add it to cart
* I customize the same bakery item and add it to cart
* I customize a cake {0} and add it to the cart
* I customize ordered cake {0} and add it to the cart
* I Add ship to home items {0} to the cart
* I Add an eGift card to the cart
* I Add a physical gift card to the cart and proceed through checkout
* I customize the floral product as store pickup and add it to cart
* I customize the floral product and add it to cart
* I add bakery item to Shopping cart
* I add floral item to Shopping cart
* I add gift card to Shopping cart
* I validate the properties of cart page
* I navigate to cart by selecting View Cart in Cart Mouseover option
* I increase the product quantity by {0} and validate the item total
* I click on edit details link
* I update the quantity in Edit details and validate the item total
* I validate the added shipping address
* I enter gift card details and apply
* I remove the gift card and validate the order total amount is changed
* Navigate to donations page by launching url {0}
* Verify Donation page properties
* Verify donation value can be added to cart
* Validate error message with wrong zip code and street combination in Delivery section
* Enter correct zipcode and street combination and continue with payment
* I make the payments with credit card and registered mail id {0}
* I verify easy sign up option is not available for registered email
* I verify easy sign up option is available for non-registered email
* I sign up an account using easy sign up option
* I customize the SPU item and add it to cart
* I validate the order summary section
* I verify special handling fees is not listed in order summary section
* I verify shipping and handling link on shipping page navigates to Delivery and Returns page
* I verify special handling fees is not listed in order confirmation page
* I verify shipping and handling link on shipping page navigates to Shipping and Handling page
* I enter shipping address as {0}
* I verify discount and order total after update
* I verify tax and order total after update
* I validate the system generated nick name in Shipping page
* Verify the added item name in the Cart flyout
* I add physical gift card to Shopping cart
* I verify MOQ in cart page
* I verify gift card payment type is not allowed
* I order the product and sign up on order confirmation page
* I verify option to save credit card

*/

public class CartAndCheckout {

	@QAFTestStep(description = "I navigate to CheckOut page")
	public void iCheckOutTheProduct() {
		CartTestPage cart = new CartTestPage();
		FrontdoorTestPage front = new FrontdoorTestPage();
		
		PerfectoUtils.scrolltoelement(cart.getCartBtnCheckout());
		cart.getCartBtnCheckout().waitForPresent(3000);
		cart.getCartBtnCheckout().verifyPresent();

		// Getting image Attribute from PDP
		String image = cart.getCartLblImageView().getAttribute("src");
		getBundle().setProperty("imageAfetrCustamization", image);
		cart.getCartBtnCheckout().click();
		front.getFrontImgFav().verifyPresent();
	}

	@QAFTestStep(description = "I validate CheckOut page")
	public void iValidateCheckOutPage() {
		CheckoutTestPage checkout = new CheckoutTestPage();

		checkout.getCheckoutLblSecurecheckout().verifyPresent();
		checkout.getCheckoutLblGuestcheckout().verifyPresent();
		checkout.getCheckoutLblNewcustomer().verifyPresent();
		checkout.getCheckoutLblRegisteredcustomer().verifyPresent();
		checkout.getCheckoutBtnLogin().verifyPresent();
		checkout.getCheckoutBtnCreateaccount().verifyPresent();
		checkout.getCheckoutBtnGuestcheckout().verifyPresent();

	}

	@QAFTestStep(description = "I Checkout the items as a hot user")
	public synchronized void iCheckoutTheItemsAsAHotUser() throws InterruptedException {
		PickupdetailsTestPage pickupdetails = new PickupdetailsTestPage();
		DeliveryTestPage delivery = new DeliveryTestPage();
		ShippingTestPage shipping = new ShippingTestPage();

		// 2. Entering the Pickup, Delivery and/or Shipping Details.
		if (pickupdetails.getPickupdetailsLblPickuplocation().isPresent()) {
			entertPickupDetails();
		}

		if (delivery.getDeliveryLblDeliveryaddress().isPresent()) {
			entertDeliveryDetails();
		}

		if (shipping.getShippingtabLblShippingheader().getAttribute("class").contains("active")) {
			enterShippingDetails();
		}
	}

	@QAFTestStep(description = "I Checkout the items as a guest user")
	public void iCheckoutTheItemsAsAGuestUser() throws InterruptedException {
		CheckoutTestPage checkout = new CheckoutTestPage();
		PickupdetailsTestPage pickupdetails = new PickupdetailsTestPage();
		DeliveryTestPage delivery = new DeliveryTestPage();
		ShippingTestPage shipping = new ShippingTestPage();
		FrontdoorTestPage front = new FrontdoorTestPage();
		
		// 1. Selecting Guest checkout option from 'Secure Checkout tab'
		selectGuestcheckout(checkout.getCheckoutLblGuestcheckout(), checkout.getCheckoutBtnGuestcheckout());
		front.getFrontImgFav().verifyPresent();
		// 2. Entering the Pickup, Delivery and/or Shipping Details.
		if (pickupdetails.getPickupdetailsLblPickuplocation().isPresent()) {
			entertPickupDetails();
			front.getFrontImgFav().verifyPresent();
		}

		if (delivery.getDeliveryLblDeliveryaddress().isPresent()) {
			entertDeliveryDetails();
			front.getFrontImgFav().verifyPresent();
		}

		if (shipping.getShippingtabLblShippingheader().getAttribute("class").contains("active")) {
			enterShippingDetails();
			front.getFrontImgFav().verifyPresent();
		}
	}

	@QAFTestStep(description = "I select Guest CheckOut in CheckOut page")
	public void iSelectGuestCheckoutInCheckOutPage() {
		CheckoutTestPage checkout = new CheckoutTestPage();
		selectGuestcheckout(checkout.getCheckoutLblGuestcheckout(), checkout.getCheckoutBtnGuestcheckout());
	}

	public void selectGuestcheckout(QAFWebElement scrollelement, QAFWebElement clickelement) {

		if (clickelement.isPresent()) {
			PerfectoUtils.scrolltoelement(scrollelement);
			PerfectoUtils.reportMessage("Selecting Guest checkout option", MessageTypes.Pass);
			clickelement.click();

			if (!scrollelement.isPresent()) {
				PerfectoUtils.reportMessage("Navigated to the next section", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Not navigated to the next section", MessageTypes.Fail);
			}

		} else {
			PerfectoUtils.reportMessage("Guest Checkout option not found.", MessageTypes.Fail);
		}
	}

	public synchronized void entertPickupDetails() {
		PickupdetailsTestPage pickupdetails = new PickupdetailsTestPage();

		PerfectoUtils.reportMessage("Navigated to Pickup details section.", MessageTypes.Pass);
		PerfectoUtils.reportMessage(
				"Pickup location: " + pickupdetails.getPickupdetailsLblPickuplocationname().getText(),
				MessageTypes.Info);
		PerfectoUtils.reportMessage("Total Qty: " + pickupdetails.getPickupdetailsLblInstorepickupqty().getText(),
				MessageTypes.Info);

		PerfectoUtils.scrolltoelement(pickupdetails.getPickupdetailsLblPickuplocation());

		/*
		 * String strPickpdate =
		 * pickupdetails.getTxtSelectdate().getAttribute("value"); String
		 * strPickuptime =
		 * pickupdetails.getLblSelectTimeValueByLabel(strPickpdate).getText();
		 * PerfectoUtils.reportMessage("Pickup date: " + strPickpdate);
		 * PerfectoUtils.reportMessage( "Pickup time: " + strPickuptime);
		 */

		pickupdetails.getPickupdetailsBtnContinue().waitForPresent(5000);
		pickupdetails.getPickupdetailsBtnContinue().click();
		pickupdetails.getPickupdetailsLblPickuplocation().waitForNotPresent(10000);
	}

	@QAFTestStep(description = "I enter delivery details in Delivery page")
	public synchronized void entertDeliveryDetails() {
		DeliveryTestPage delivery = new DeliveryTestPage();

		PerfectoUtils.reportMessage("Navigated to Delivery section.", MessageTypes.Pass);
		PerfectoUtils.reportMessage("Pickup date: " + delivery.getDeliveryTxtDeliverydate().getAttribute("value"),
				MessageTypes.Info);

		PerfectoUtils.scrolltoelement(delivery.getDeliveryLblDeliveryaddress());
		PerfectoUtils.reportMessage("Entering the mandatory fields..", MessageTypes.Pass);
		delivery.getDeliveryTxtFirstname().sendKeys(getBundle().getString("shippingaddress1.FirstName"));
		delivery.getDeliveryTxtLastname().sendKeys(getBundle().getString("shippingaddress1.LastName"));
		delivery.getDeliveryTxtPhonefield1().sendKeys(getBundle().getString("shippingaddress1.phonenumberone"));
		delivery.getDeliveryTxtPhonefield2().sendKeys(getBundle().getString("shippingaddress1.phonenumbertwo"));
		delivery.getDeliveryTxtPhonefield3().sendKeys(getBundle().getString("shippingaddress1.phonenumberthree"));

		PerfectoUtils.scrolltoelement(delivery.getDeliveryTxtPhonefield1());
		delivery.getDeliveryTxtStreetaddress1().sendKeys(getBundle().getString("shippingaddress1.street"));
		delivery.getDeliveryTxtCity().sendKeys(getBundle().getString("shippingaddress1.city"));
		PerfectoUtils.reportMessage("Entered the mandatory fields.", MessageTypes.Pass);

		getBundle().setProperty("firstName", getBundle().getString("shippingaddress1.FirstName"));
		getBundle().setProperty("lastName", getBundle().getString("shippingaddress1.LastName"));

		String imageDelvry = delivery.getLblImageView().getAttribute("src");

		if (imageDelvry.equals(getBundle().getString("imageAfetrCustamization"))) {
			PerfectoUtils.reportMessage("Same image is getting displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Same image is not getting displayed", MessageTypes.Fail);
		}

		try {
			int size = delivery.getDeliveryLiBtnUsesameadd().size();
			if (size > 0) {
				for (QAFWebElement useSameaddBox : delivery.getDeliveryLiBtnUsesameadd()) {
					PerfectoUtils.scrolltoelement(useSameaddBox);
					useSameaddBox.click();
					PerfectoUtils.reportMessage("Use Same Address is selected in Delivery Address Page!",
							MessageTypes.Info);
				}
			}
		} catch (Exception e) {
			// ignore
		}

		PerfectoUtils.scrolltoelement(delivery.getDeliveryBtnContinue());
		delivery.getDeliveryBtnContinue().waitForPresent(5000);
		delivery.getDeliveryBtnContinue().click();
		PerfectoUtils.reportMessage("Clicked Continue button.", MessageTypes.Pass);
		delivery.getDeliveryLblDeliveryaddress().waitForNotPresent(10000);
	}

	public void entertInvalidPhoneNumInDeliveryDetails() {
		DeliveryTestPage delivery = new DeliveryTestPage();

		PerfectoUtils.reportMessage("Navigated to Delivery section.", MessageTypes.Pass);
		PerfectoUtils.reportMessage("Pickup date: " + delivery.getDeliveryTxtDeliverydate().getAttribute("value"),
				MessageTypes.Info);

		PerfectoUtils.scrolltoelement(delivery.getDeliveryLblDeliveryaddress());
		PerfectoUtils.reportMessage("Entering the mandatory fields..", MessageTypes.Pass);
		delivery.getDeliveryTxtFirstname().sendKeys(getBundle().getString("shippingaddress1.FirstName"));
		delivery.getDeliveryTxtLastname().sendKeys(getBundle().getString("shippingaddress1.LastName"));
		delivery.getDeliveryTxtPhonefield1().sendKeys("###");
		delivery.getDeliveryTxtPhonefield2().sendKeys("###");
		delivery.getDeliveryTxtPhonefield3().sendKeys("###");

		PerfectoUtils.scrolltoelement(delivery.getDeliveryTxtPhonefield1());
		delivery.getDeliveryTxtStreetaddress1().sendKeys(getBundle().getString("shippingaddress1.street"));
		delivery.getDeliveryTxtCity().sendKeys(getBundle().getString("shippingaddress1.city"));
		PerfectoUtils.reportMessage("Entered the mandatory fields.", MessageTypes.Pass);
		try {
			int size = delivery.getDeliveryLiBtnUsesameadd().size();
			if (size > 0) {
				for (QAFWebElement useSameaddBox : delivery.getDeliveryLiBtnUsesameadd()) {
					useSameaddBox.click();
					PerfectoUtils.reportMessage("Use Same Address is selected in Delivery Address Page!",
							MessageTypes.Info);
				}
			}
		} catch (Exception e) {
			// ignore
		}

		PerfectoUtils.scrolltoelement(delivery.getDeliveryBtnContinue());
		delivery.getDeliveryBtnContinue().waitForPresent(5000);
		delivery.getDeliveryBtnContinue().click();
		PerfectoUtils.reportMessage("Clicked Continue button.", MessageTypes.Pass);
	}

	public synchronized void enterShippingDetails() throws InterruptedException {
		ShippingTestPage shipping = new ShippingTestPage();

		PerfectoUtils.reportMessage("Navigated to Shipping section.", MessageTypes.Pass);

		if (shipping.getShippingtabLblShippingto().isPresent()) {
			PerfectoUtils.reportMessage("Shipping address available as:", MessageTypes.Pass);

			for (QAFWebElement temp : shipping.getShippingtabLiLblShippingtoaddresslist()) {
				PerfectoUtils.reportMessage(temp.getText(), MessageTypes.Info);
			}

			// Clicking continue button
			shipping.getShippingtabBtnContinueexistingaddress().waitForPresent(5000);
			shipping.getShippingtabBtnContinueexistingaddress().click();

		} else if (shipping.getShippingtabRbtnShiptomultiad().isPresent()) {
			if (shipping.getShippingtabRbtnShiptomultiad().isSelected())
				PerfectoUtils.reportMessage("Shipping to Multiple address", MessageTypes.Pass);

			// Clicking continue button
			shipping.getShippingtabBtnContinueexistingaddress().waitForPresent(5000);
			shipping.getShippingtabBtnContinueexistingaddress().click();

		} else if (shipping.getShippingtabTxtCountrydropdown().isPresent()) {
			enterShippingAddressAs("shippingaddress3");
		}

		PerfectoUtils.reportMessage("Checking for Verify your email address popup ", MessageTypes.Pass);

		// Handling the "Verify your email address" pop-up, if present
		if (shipping.getShippingtabLblVerifyshippingsddress().isPresent()) {
			PerfectoUtils.reportMessage("Pop-up found: Verify your email address", MessageTypes.Pass);
			PerfectoUtils.reportMessage("Waiting for Use this address button to be present.", MessageTypes.Pass);
			shipping.getShippingtabBtnUsethisaddress().waitForEnabled(10000);

			shipping.getShippingtabBtnUsethisaddress().waitForPresent(5000);
			shipping.getShippingtabBtnUsethisaddress().click();
			PerfectoUtils.reportMessage("Clicked on Use this address button", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("Verify your email address popup not populated", MessageTypes.Info);
		}

	}

	@QAFTestStep(description = "I make the payments with credit card")
	public synchronized void iMakeThePaymentsWithCreditCard() {
		PaymentTestPage payment = new PaymentTestPage();
		DeliveryTestPage delivery = new DeliveryTestPage();
		FrontdoorTestPage front = new FrontdoorTestPage();
		
		if (payment.getPaymentLblPaymentmethod().isPresent()) {
			
			front.getFrontImgFav().verifyPresent();
			String imagePymnt = delivery.getLblImageView().getAttribute("src");

			if (imagePymnt.equals(getBundle().getString("imageAfetrCustamization")))
				PerfectoUtils.reportMessage("Same image is getting displayed", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Same image is not getting displayed", MessageTypes.Fail);

			makePaymentsUsingCreditcard();

		} else {
			PerfectoUtils.reportMessage("Not navigated to Payments section.", MessageTypes.Fail);
		}

	}
	
	@QAFTestStep(description = "I make the payments and validate that Billing email address allows underscores")
	public synchronized void iMakeThePaymentsandValidateBillingemailaddressallowsunderscores() {
		PaymentTestPage payment = new PaymentTestPage();
		DeliveryTestPage delivery = new DeliveryTestPage();
		FrontdoorTestPage front = new FrontdoorTestPage();
		
		if (payment.getPaymentLblPaymentmethod().isPresent()) {
			
			front.getFrontImgFav().verifyPresent();
			String imagePymnt = delivery.getLblImageView().getAttribute("src");

			if (imagePymnt.equals(getBundle().getString("imageAfetrCustamization")))
				PerfectoUtils.reportMessage("Same image is getting displayed", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Same image is not getting displayed", MessageTypes.Fail);

			String email = getBundle().getString("myEmail");
			PerfectoUtils.reportMessage("Navigated to Payment section.", MessageTypes.Pass);

			// 1. Entering the credit card details
			PerfectoUtils.scrolltoelement(payment.getPaymentLblEnteracreditcard());
			enterCreditCardDetailsInpayment();

			if (email.equals("Cold")) {
				payment.getPaymentChkSavecreditcard().verifyNotPresent();
			}

			// 2. Entering the Billing address details
			PerfectoUtils.scrolltoelement(payment.getPaymentLblBillingaddress());

			String firstname = payment.getPaymentTxtFirstname().getAttribute("value");
			String lastname = payment.getPaymentTxtLastname().getAttribute("value");

			if (firstname.length() < 1)
				payment.getPaymentTxtFirstname().sendKeys(getBundle().getString("address.firstname"));

			if (lastname.length() < 1)
				payment.getPaymentTxtLastname().sendKeys(getBundle().getString("address.lastname"));

			payment.getPaymentTxtPhonenumber1().sendKeys(getBundle().getString("address.phonenumber.field1"));
			payment.getPaymentTxtPhonenumber2().sendKeys(getBundle().getString("address.phonenumber.field2"));
			payment.getPaymentTxtPhonenumber3().sendKeys(getBundle().getString("address.phonenumber.field3"));

			PerfectoUtils.scrolltoelement(payment.getPaymentTxtPhonenumber1());
			payment.getPaymentTxtStreetaddress1().sendKeys(getBundle().getString("address.streetaddress1"));
			payment.getPaymentTxtCity().sendKeys(getBundle().getString("address.city"));
			payment.getPaymentTxtZipcode().sendKeys(getBundle().getString("address.zipcode1"));

			String emailID = payment.getPaymentTxtEmail().getAttribute("value");

			if (emailID.length() < 1) {

				// getting a unique email id
				DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
				Date date = new Date();
				String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
				String strBillingEmail = strTimeStmp + "_@heb.com";
				PerfectoUtils.reportMessage("Entered tBilling Email ID with underscore "+strBillingEmail, MessageTypes.Info);
				payment.getPaymentTxtEmail().sendKeys(strBillingEmail);
				payment.getPaymentTxtConfirmemail().sendKeys(strBillingEmail);
				getBundle().setProperty("myEmail", strBillingEmail);

			} else {
				payment.getPaymentTxtConfirmemail().sendKeys(emailID);
			}

			PerfectoUtils.reportMessage("Entered the mandatory fields.", MessageTypes.Pass);

			// Verify whether the state box has been pre-populated as "UNITED
			// STATES"
			String strState = payment.getPaymentTxtState().getAttribute("value");
			if (strState.length() > 0) {
				PerfectoUtils.reportMessage("State field has been pre-populated as: " + strState, MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("State field has not been pre-populated", MessageTypes.Fail);
			}

			// Applying Tax Exemption for Tax-exempted user
			if (payment.getPaymentLblApplytaxexemption().isPresent()) {
				applyTaxExemption();
			}

			// Chk the checkbox of 21 years old or more for Wine products
			if (payment.getPaymentChkAgeverification().isPresent()) {
				payment.getPaymentChkAgeverification().click();
			}

			// Click on Submit order
			clickSubnmitOrderInPaymentsPage();

		} else {
			PerfectoUtils.reportMessage("Not navigated to Payments section.", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Enter Invalid phonenumber in payments page and select Submit button")
	public void enterInvalidPhonenumberInPaymentsPageAndSelectSubmitButton() {
		PaymentTestPage payment = new PaymentTestPage();

		PerfectoUtils.reportMessage("Navigated to Payment section.", MessageTypes.Pass);

		// 1. Entering the credit card details
		PerfectoUtils.scrolltoelement(payment.getPaymentLblEnteracreditcard());
		enterCreditCardDetailsInpayment();

		// 2. Entering Invalid Mobile number in Billing address field
		PerfectoUtils.scrolltoelement(payment.getPaymentLblBillingaddress());
		enterInvalidPhoneNumberInBillingAddress();

		// 3. Click on Submit order
		PerfectoUtils.scrolltoelement(payment.getPaymentBtnSubmitorder());
		payment.getPaymentBtnSubmitorder().click();

	}

	@QAFTestStep(description = "Verify the error message for Invalid Phonenumber in Payments page")
	public void verifyTheErrorMessageForInvalidPhonenumberInPaymentsPage() {
		PaymentTestPage payment = new PaymentTestPage();

		try {
			payment.getPaymentLblEntervalidphonenumbererrormsg().waitForPresent(5000);

			if (payment.getPaymentLblEntervalidphonenumbererrormsg().isPresent()) {
				PerfectoUtils.reportMessage("Error message found for invalid mobile number entry..", MessageTypes.Pass);
				PerfectoUtils.scrolltoelement(payment.getPaymentLblBillingaddress());
				payment.getPaymentTxtPhonenumber1error().verifyPresent();
				payment.getPaymentTxtPhonenumber2error().verifyPresent();
				payment.getPaymentTxtPhonenumber3error().verifyPresent();
			} else {
				PerfectoUtils.reportMessage("Error message not found for invalid phone number..", MessageTypes.Fail);
			}

		} catch (Exception e) {
			PerfectoUtils.reportMessage("Wait timeout for 'Enter Valid Phone number error message..'",
					MessageTypes.Fail);
		}

	}

	public void makePaymentsUsingCreditcard() {
		PaymentTestPage payment = new PaymentTestPage();

		String email = getBundle().getString("myEmail");
		PerfectoUtils.reportMessage("Navigated to Payment section.", MessageTypes.Pass);

		// 1. Entering the credit card details
		PerfectoUtils.scrolltoelement(payment.getPaymentLblEnteracreditcard());
		enterCreditCardDetailsInpayment();

		if (email.equals("Cold")) {
			payment.getPaymentChkSavecreditcard().verifyNotPresent();
		}

		// 2. Entering the Billing address details
		PerfectoUtils.scrolltoelement(payment.getPaymentLblBillingaddress());
		enterBillingAddressInPayment();

		// Verify whether the state box has been pre-populated as "UNITED
		// STATES"
		String strState = payment.getPaymentTxtState().getAttribute("value");
		if (strState.length() > 0) {
			PerfectoUtils.reportMessage("State field has been pre-populated as: " + strState, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("State field has not been pre-populated", MessageTypes.Fail);
		}

		// Applying Tax Exemption for Tax-exempted user
		if (payment.getPaymentLblApplytaxexemption().isPresent()) {
			applyTaxExemption();
		}

		// Chk the checkbox of 21 years old or more for Wine products
		if (payment.getPaymentChkAgeverification().isPresent()) {
			payment.getPaymentChkAgeverification().click();
		}

		// Click on Submit order
		clickSubnmitOrderInPaymentsPage();

	}

	public void clickSubnmitOrderInPaymentsPage() {
		PaymentTestPage payment = new PaymentTestPage();

		// Clicking the "Submit order" button
		final QAFWebElement submitOrder = payment.getPaymentBtnSubmitorder();
		submitOrder.waitForPresent(5000);
		submitOrder.click();
		payment.waitForAjaxToComplete();

		if (payment.getPaymentLblErrormsg().isPresent()) {

			String error = payment.getPaymentLblErrormsg().getText();
			PerfectoUtils.reportMessage("Error while submitting the order " + error, MessageTypes.Info);

			PerfectoUtils.reportMessage("Entering another credit card details", MessageTypes.Info);
			payment.getPaymentTxtCardtypeamericanexcard().click();
			payment.getPaymentTxtCardtypeamericanexcard().clear();
			payment.getPaymentTxtCardtypeamericanexcard().sendKeys(getBundle().getString("payment.card2.cardnumber"));
			// payment.getTxtCardexpirymonthvalue().click();
			// payment.getTxtCardexpiryyearvalue().click();
			payment.getPaymentTxtCardcvc().clear();
			payment.getPaymentTxtCardcvc().sendKeys(getBundle().getString("payment.card2.cvc"));
			submitOrder.waitForPresent(5000);
			submitOrder.click();
			if (payment.getPaymentLblErrormsg().isPresent()) {
				PerfectoUtils.reportMessage("Error in entered credit cards", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("Clicked Submit order button", MessageTypes.Pass);
		}

	}

	public void enterCreditCardDetailsInpayment() {
		PaymentTestPage payment = new PaymentTestPage();

		if (payment.getPaymentLblEnteracreditcard().isPresent()) {
			if (!payment.getPaymentRbtnEnteracreditcard().isSelected()) {
				payment.getPaymentRbtnEnteracreditcard().click();
			}
		}

		payment.getPaymentTxtNameoncard().sendKeys(getBundle().getString("payment.card.nameoncard"));
		payment.getPaymentTxtCardtypemastercard().click();
		payment.getPaymentTxtCardnumber().sendKeys(getBundle().getString("payment.card.cardnumber"));
		payment.getPaymentTxtCardexpirymonthvalue().click();
		payment.getPaymentTxtCardexpiryyearvalue().click();
		payment.getPaymentTxtCardcvc().sendKeys(getBundle().getString("payment.card.cvc"));

	}

	public void enterBillingAddressInPayment() {
		PaymentTestPage payment = new PaymentTestPage();

		PerfectoUtils.scrolltoelement(payment.getPaymentLblBillingaddress());

		String firstname = payment.getPaymentTxtFirstname().getAttribute("value");
		String lastname = payment.getPaymentTxtLastname().getAttribute("value");

		if (firstname.length() < 1)
			payment.getPaymentTxtFirstname().sendKeys(getBundle().getString("address.firstname"));

		if (lastname.length() < 1)
			payment.getPaymentTxtLastname().sendKeys(getBundle().getString("address.lastname"));

		payment.getPaymentTxtPhonenumber1().sendKeys(getBundle().getString("address.phonenumber.field1"));
		payment.getPaymentTxtPhonenumber2().sendKeys(getBundle().getString("address.phonenumber.field2"));
		payment.getPaymentTxtPhonenumber3().sendKeys(getBundle().getString("address.phonenumber.field3"));

		PerfectoUtils.scrolltoelement(payment.getPaymentTxtPhonenumber1());
		payment.getPaymentTxtStreetaddress1().sendKeys(getBundle().getString("address.streetaddress1"));
		payment.getPaymentTxtCity().sendKeys(getBundle().getString("address.city"));
		payment.getPaymentTxtZipcode().sendKeys(getBundle().getString("address.zipcode1"));

		String email = payment.getPaymentTxtEmail().getAttribute("value");

		if (email.length() < 1) {

			// getting a unique email id
			DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
			Date date = new Date();
			String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
			String strBillingEmail = strTimeStmp + "@heb.com";

			payment.getPaymentTxtEmail().sendKeys(strBillingEmail);
			payment.getPaymentTxtConfirmemail().sendKeys(strBillingEmail);
			getBundle().setProperty("myEmail", strBillingEmail);

		} else {
			payment.getPaymentTxtConfirmemail().sendKeys(email);
		}

		PerfectoUtils.reportMessage("Entered the mandatory fields.", MessageTypes.Pass);
	}

	public void enterInvalidPhoneNumberInBillingAddress() {
		PaymentTestPage payment = new PaymentTestPage();

		PerfectoUtils.scrolltoelement(payment.getPaymentLblBillingaddress());

		String firstname = payment.getPaymentTxtFirstname().getAttribute("value");
		String lastname = payment.getPaymentTxtLastname().getAttribute("value");

		if (firstname.length() < 1)
			payment.getPaymentTxtFirstname().sendKeys(getBundle().getString("address.firstname"));

		if (lastname.length() < 1)
			payment.getPaymentTxtLastname().sendKeys(getBundle().getString("address.lastname"));

		payment.getPaymentTxtPhonenumber1().sendKeys("###");
		payment.getPaymentTxtPhonenumber2().sendKeys("###");
		payment.getPaymentTxtPhonenumber3().sendKeys("###");

		PerfectoUtils.scrolltoelement(payment.getPaymentTxtPhonenumber1());
		payment.getPaymentTxtStreetaddress1().sendKeys(getBundle().getString("address.streetaddress1"));
		payment.getPaymentTxtCity().sendKeys(getBundle().getString("address.city"));
		payment.getPaymentTxtZipcode().sendKeys(getBundle().getString("address.zipcode1"));

		String email = payment.getPaymentTxtEmail().getAttribute("value");

		if (email.length() < 1) {

			// getting a unique email id
			DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
			Date date = new Date();
			String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
			String strBillingEmail = strTimeStmp + "@heb.com";

			payment.getPaymentTxtEmail().sendKeys(strBillingEmail);
			payment.getPaymentTxtConfirmemail().sendKeys(strBillingEmail);
		} else {
			payment.getPaymentTxtConfirmemail().sendKeys(email);
		}

		PerfectoUtils.reportMessage("Entered the mandatory fields.", MessageTypes.Pass);
	}

	public synchronized void applyTaxExemption() {
		PaymentTestPage payment = new PaymentTestPage();

		PerfectoUtils.reportMessage("Apply Tax Exemption option is present.", MessageTypes.Pass);

		PerfectoUtils.scrolltoelement(payment.getPaymentLblOrdersubtotalamt());
		String strEstimatedTaxInitialValue = payment.getPaymentLblEstimatedtaxamt().getText();
		PerfectoUtils.reportMessage("Estimated tax initial value=" + strEstimatedTaxInitialValue, MessageTypes.Pass);

		PerfectoUtils.scrolltoelement(payment.getPaymentLblApplytaxexemption());
		payment.getPaymentChkApplytaxexemption().click();

		PerfectoUtils.scrolltoelement(payment.getPaymentLblOrdersubtotalamt());
		String strEstimatedTaxFinalValue = payment.getPaymentLblEstimatedtaxamt().getText();
		PerfectoUtils.reportMessage("Estimated tax after tax exemption=" + strEstimatedTaxFinalValue,
				MessageTypes.Pass);

		if (strEstimatedTaxFinalValue.equalsIgnoreCase("$0.00")) {
			PerfectoUtils.reportMessage("Taxes have been waived off.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Taxes haven't been waived off.", MessageTypes.Fail);
		}

		PerfectoUtils.scrolltoelement(payment.getPaymentLblEnteracreditcard());
		payment.getPaymentTxtCardtypemastercard().click();

	}

	@QAFTestStep(description = "I verify the Order confirmation page")
	public synchronized void iVerifyTheOrderConfirmationPage() {
		ConfirmationTestPage confirmation = new ConfirmationTestPage();
		OrderhistoryTestPage orderhistoryPage = new OrderhistoryTestPage();
		DeliveryTestPage delivery = new DeliveryTestPage();
		FrontdoorTestPage front = new FrontdoorTestPage();
		
		confirmation.waitForPageToLoad();
		if (confirmation.getConfirmLblThankyou().isPresent()) {
			front.getFrontImgFav().verifyPresent();
			PerfectoUtils.reportMessage("Navigated to Confirmation page.", MessageTypes.Pass);
			PerfectoUtils.reportMessage("Order number: " + confirmation.getConfirmLblOrdernum().getText(),
					MessageTypes.Info);
			getBundle().setProperty("OrderId", confirmation.getConfirmLblOrdernum().getText());
			getBundle().setProperty("OrderTotal", orderhistoryPage.getOdrhistoryLblOrdertotaldetails().getText());

		} else {
			PerfectoUtils.reportMessage("Not Navigated to Confirmation page.", MessageTypes.Fail);
		}

		String imageConfmtion = delivery.getLblImageView().getAttribute("src");
		if (imageConfmtion.equals(getBundle().getString("imageAfetrCustamization")))
			PerfectoUtils.reportMessage("Same image is getting displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Same image is not getting displayed", MessageTypes.Fail);
		// WriteXMLFile.getOrderId();
	}

	@QAFTestStep(description = "Select Guest Checkout option")
	public void selectGuestCheckoutOption() {
		CheckoutTestPage checkout = new CheckoutTestPage();

		selectGuestcheckout(checkout.getCheckoutLblGuestcheckout(), checkout.getCheckoutBtnGuestcheckout());
	}

	@QAFTestStep(description = "Enter Invalid phonenumber in Delivery tab and select Submit button")
	public void enterInvalidPhonenumberInDeliveryTabAndSelectSubmitButton() {
		entertInvalidPhoneNumInDeliveryDetails();
	}

	@QAFTestStep(description = "Verify the error message for Invalid Phonenumber in Delivery tab")
	public void verifyTheErrorMessageForInvalidPhonenumberInDeliveryTab() {
		DeliveryTestPage delivery = new DeliveryTestPage();

		try {
			delivery.getLblPlsentervalidphonenumerrormsg().waitForPresent(3000);
			if (delivery.getLblPlsentervalidphonenumerrormsg().isPresent()) {
				PerfectoUtils.reportMessage("Error message found as expected..", MessageTypes.Pass);
				PerfectoUtils.reportMessage(delivery.getLblPlsentervalidphonenumerrormsg().getText(),
						MessageTypes.Info);
			}
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Wait timeout for the Please enter a valid phone number error message..",
					MessageTypes.Fail);
		}

	}

	public synchronized void selectNewCustomercheckout() {
		RegistrationTestPage register = new RegistrationTestPage();
		CheckoutTestPage checkout = new CheckoutTestPage();
		String password = getBundle().getString("register.defaultPassword");

		register.getCheckOutRegistration().fillRandomData();
		getBundle().setProperty("myEmail", register.getCheckOutRegistration().getEmail());
		register.getCheckOutRegistration().setPassword(password);
		register.getCheckOutRegistration().fillUiElements();

		PerfectoUtils.scrolltoelement(checkout.getCheckoutBtnCreateaccount());
		checkout.getCheckoutBtnCreateaccount().click();
		checkout.waitForAjaxToComplete();
		checkout.waitForPageToLoad();
		checkout.getCheckoutLblNewcustomer().waitForNotPresent(50000);

		if (!checkout.getCheckoutLblNewcustomer().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to the next section", MessageTypes.Pass);
			try {
				Logger.saveEmailAndPassword();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			PerfectoUtils.reportMessage("Not navigated to the next section", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I register and Checkout the items")
	public synchronized void iRegisterAndCheckoutTheItems() throws InterruptedException {
		PickupdetailsTestPage pickupdetails = new PickupdetailsTestPage();
		DeliveryTestPage delivery = new DeliveryTestPage();
		ShippingTestPage shipping = new ShippingTestPage();

		// 1. Selecting Guest checkout option from 'Secure Checkout tab'
		selectNewCustomercheckout();

		// 2. Entering the Pickup, Delivery and/or Shipping Details.
		if (pickupdetails.getPickupdetailsLblPickuplocation().isPresent()) {
			entertPickupDetails();
		}

		if (delivery.getDeliveryLblDeliveryaddress().isPresent()) {
			entertDeliveryDetails();
		}

		if (shipping.getShippingtabLblShippingheader().getAttribute("class").contains("active")) {
			enterShippingDetails();
		}
	}

	@QAFTestStep(description = "I make the payments with gift card alone")
	public synchronized void iMakeThePaymentsWithGiftCardAlone() {
		PaymentTestPage payment = new PaymentTestPage();

		if (payment.getPaymentLblPaymentmethod().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Payment section.", MessageTypes.Pass);
			makePaymentsUsingGiftCardAlone();

			// 2. Entering the Billing address details
			PerfectoUtils.scrolltoelement(payment.getPaymentLblBillingaddress());
			payment.getPaymentTxtFirstname().sendKeys(getBundle().getString("address.firstname"));
			payment.getPaymentTxtLastname().sendKeys(getBundle().getString("address.lastname"));
			payment.getPaymentTxtPhonenumber1().sendKeys(getBundle().getString("address.phonenumber.field1"));
			payment.getPaymentTxtPhonenumber2().sendKeys(getBundle().getString("address.phonenumber.field2"));
			payment.getPaymentTxtPhonenumber3().sendKeys(getBundle().getString("address.phonenumber.field3"));

			PerfectoUtils.scrolltoelement(payment.getPaymentTxtPhonenumber1());
			payment.getPaymentTxtStreetaddress1().sendKeys(getBundle().getString("address.streetaddress1"));
			payment.getPaymentTxtCity().sendKeys(getBundle().getString("address.city"));
			payment.getPaymentTxtZipcode().sendKeys(getBundle().getString("address.zipcode1"));
			payment.getPaymentTxtEmail().sendKeys(getBundle().getString("address.email"));
			payment.getPaymentTxtConfirmemail().sendKeys(getBundle().getString("address.confirmemail"));
			PerfectoUtils.reportMessage("Entered the mandatory fields.", MessageTypes.Pass);

			// 3. Verify whether the state box has been pre-populated
			String strState = payment.getPaymentTxtState().getAttribute("value");
			if (strState.length() > 0) {
				PerfectoUtils.reportMessage("State field has been pre-populated as: " + strState, MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("State field has not been pre-populated", MessageTypes.Fail);
			}

			// Clicking the "Submit order" button
			payment.getPaymentBtnSubmitorder().waitForPresent(5000);
			payment.getPaymentBtnSubmitorder().click();
			PerfectoUtils.reportMessage("Clicked Submit order button", MessageTypes.Pass);
			payment.getPaymentBtnSubmitorder().waitForNotPresent(10000);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Payments section.", MessageTypes.Fail);
		}

	}
	
	@QAFTestStep(description = "I make the payments with gift card and Credit Card")
	public synchronized void iMakeThePaymentsWithGiftCardandCreditCard() {
		PaymentTestPage payment = new PaymentTestPage();

		if (payment.getPaymentLblPaymentmethod().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Payment section.", MessageTypes.Pass);
			makePaymentsUsingGiftCardAlone();
			iMakeThePaymentsWithCreditCard();
		} else {
			PerfectoUtils.reportMessage("Not navigated to Payments section.", MessageTypes.Fail);
		}

	}

	public void makePaymentsUsingGiftCardAlone() {
		PaymentTestPage payment = new PaymentTestPage();
		GiftcardslandingTestPage giftcard = new GiftcardslandingTestPage();

		boolean giftCardApplied = false;

		// 1. Entering the Gift Card details
		if (payment.getPaymentLblGiftcardandegiftcard().isPresent()) {
			PerfectoUtils.reportMessage("Proceeding the payment through giftcard alone", MessageTypes.Pass);

			PerfectoUtils.scrolltoelement(payment.getPaymentLblGiftcardandegiftcard());
			QAFWebElement eleGiftCardNum = payment.getPaymentTxtGiftcardnumber();
			QAFWebElement eleGiftCardPin = payment.getPaymentTxtGiftcardpin();

			for (int i = 1; i <= 5; i++) {
				eleGiftCardNum.clear();
				eleGiftCardNum.sendKeys(getBundle().getString("payment.gitftcard" + i + ".num"));
				eleGiftCardPin.sendKeys(getBundle().getString("payment.gitftcard" + i + ".pin"));
				PerfectoUtils.reportMessage("Entered " + i + " Giftcard num and pin", MessageTypes.Pass);
				QAFWebElement eleApplyGiftCard = payment.getPaymentBtnApplygiftcard();
				eleApplyGiftCard.click();
				PerfectoUtils.reportMessage("Clicked Apply gift card button.", MessageTypes.Pass);

				try {
					payment.getPaymentLblGiftcardappliedmessage().waitForPresent(10000);
				} catch (Exception e) {
					e.printStackTrace();
				}

				// Validate the Giftcard applied message
				if (payment.getPaymentLblGiftcardappliedmessage().isPresent()) {
					PerfectoUtils.reportMessage(payment.getPaymentLblGiftcardappliedmessage().getText(),
							MessageTypes.Pass);
					giftCardApplied = true;
				} else {
					PerfectoUtils.reportMessage("Giftcard not applied", MessageTypes.Info);
					if (giftcard.getLblLowblncalert().isPresent()) {
						PerfectoUtils.reportMessage(
								"Gift Card does not have sufficient balance. Please try with a another Gift Card.",
								MessageTypes.Info);
						giftCardApplied = false;
						continue;
					}
					continue;
				}

				PerfectoUtils.scrolltoelement(payment.getPaymentLblOrdersubtotalamt());

				PerfectoUtils.reportMessage("Order subtotal: " + payment.getPaymentLblOrdersubtotalamt().getText(),
						MessageTypes.Info);
				PerfectoUtils.reportMessage("Giftcard amount: " + payment.getPaymentLblGiftcardamt().getText(),
						MessageTypes.Info);
				PerfectoUtils.reportMessage("Order total amount: " + payment.getPaymentLblOrdertotalamt().getText(),
						MessageTypes.Info);

				// Validate the Order total has been changed to Zero.
				if (payment.getPaymentLblOrdertotalamt().getText().equalsIgnoreCase("$0.00")) {
					PerfectoUtils.reportMessage("Order total value reduced to zero with the use of Giftcard",
							MessageTypes.Pass);
					PerfectoUtils.reportMessage("Order total amount: " + payment.getPaymentLblOrdertotalamt().getText(),
							MessageTypes.Info);
					giftCardApplied = true;
					break;

				} else {
					PerfectoUtils.reportMessage("Order total value not reduced to zero with the use of Giftcard",
							MessageTypes.Info);
					PerfectoUtils.reportMessage("Using another Giftcard or Choose Credit card payment option",
							MessageTypes.Info);
				}
			}

			if (!giftCardApplied)
				PerfectoUtils.reportMessage(
						"Order total value not reduced to zero with the use of 5 Giftcards. Change Gift card data.",
						MessageTypes.Fail);

		} else {
			PerfectoUtils.reportMessage("Payment through Giftcard option not found.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I add deli item to Shopping cart")
	public void iAddDeliItemToShoppingCart() throws Exception {

		PdtsearchresultPage.ienterValidSearchTermAndSelectSearchButton(getBundle().getString("products.deliProduct"));
		PdtsearchresultPage.iSeeSearchResultsPage();
		PdtsearchresultPage.iAddItemToCart();

	}

	@QAFTestStep(description = "I customize the bakery item and add it to cart")
	public void iCustomizeTheBakeryItemAndAddItToCart() {
		PDPTestPage pdp = new PDPTestPage();

		PdtsearchresultPage.iNavigateToPDPByClickingOnTheProduct();
		HomePage.iValidateTheBakeryCustomizeOptions();
		PerfectoUtils.scrolltoelement(pdp.getPdpBtnAddtocart());
		pdp.getPdpBtnAddtocart().waitForPresent(3000);
		pdp.getPdpBtnAddtocart().click();
	}
	
	@QAFTestStep(description = "I customize the same bakery item and add it to cart")
	public void iCustomizeTheSameBakeryItemAndAddItToCart() {
		PDPTestPage pdp = new PDPTestPage();

		PdtsearchresultPage.iNavigateToPDPByClickingOnTheProduct();
		HomePage.iValidateTheSameBakerywithDiffCustomizeOptions();
		PerfectoUtils.scrolltoelement(pdp.getPdpBtnAddtocart());
		pdp.getPdpBtnAddtocart().waitForPresent(3000);
		pdp.getPdpBtnAddtocart().click();
	}

	@QAFTestStep(description = "I customize a cake {0} and add it to the cart")
	public void iCustomizeCakeAndAddItToCart(String searchtext) {
		PdtsearchresultPage pdp = new PdtsearchresultPage();

		pdp.ienterValidSearchTermAndSelectSearchButton(searchtext);
		pdp.iSeeSearchResultsPage();
		iCustomizeTheBakeryItemAndAddItToCart();
	}
	
	@QAFTestStep(description = "I customize a cake {0} with multiple lines in the Message field and add it to the cart")
	public void iCustomizeCakeWithMultilpleLinesinMessageAndAddItToCart(String searchtext) {
		PdtsearchresultPage pdpsearch = new PdtsearchresultPage();
		PDPTestPage pdp = new PDPTestPage();
		
		pdpsearch.ienterValidSearchTermAndSelectSearchButton(searchtext);
		pdpsearch.iSeeSearchResultsPage();
		PdtsearchresultPage.iNavigateToPDPByClickingOnTheProduct();
		HomePage.iValidateTheBakeryWithMultipleLinesInMessageBoxCustomizeOptions();
		PerfectoUtils.scrolltoelement(pdp.getPdpBtnAddtocart());
		pdp.getPdpBtnAddtocart().waitForPresent(3000);
		pdp.getPdpBtnAddtocart().click();
	}
	
	@QAFTestStep(description = "I enter the Bakery Customize Options without Message and add to cart")
	public void iEnterTheBakeryCustomizeOptionsWithoutMessageAndAddItToCart(String searchtext) {
		PDPTestPage pdp = new PDPTestPage();
		
		HomePage.iEnterTheBakeryCustomizeOptionsWithoutMessage();
		PerfectoUtils.scrolltoelement(pdp.getPdpBtnAddtocart());
		pdp.getPdpBtnAddtocart().waitForPresent(3000);
		pdp.getPdpBtnAddtocart().click();
	}

	@QAFTestStep(description = "I customize ordered cake {0} and add it to the cart")
	public void iCustomizeOrderedCakeAndAddItToCart(String searchtext) {
		PdtsearchresultPage pdp = new PdtsearchresultPage();

		pdp.ienterValidSearchTermAndSelectSearchButton(searchtext);
		pdp.iSeeSearchResultsPage();
		iCustomizeTheSameBakeryItemAndAddItToCart();
	}

	@QAFTestStep(description = "I Add ship to home items {0} to the cart")
	public void iAddShiptoHomeItemToCart(String searchtext) throws Exception {
		PdtsearchresultPage pdp = new PdtsearchresultPage();

		pdp.navigateToShipToHomePage();
		pdp.ienterValidSearchTermAndSelectSearchButton(searchtext);
		pdp.iSeeSearchResultsPage();
		pdp.iAddItemToCart();
	}

	@QAFTestStep(description = "I Add an eGift card to the cart")
	public void iAddeGiftcardToCart() throws Exception {
		PaymentGatewayStepdef payment = new PaymentGatewayStepdef();

		payment.navigateToGiftCardsPage();
		payment.navigateToSendAnEGiftCardPage();
		payment.addTheEGiftCardToCart();
	}

	@QAFTestStep(description = "I Add a physical gift card to the cart and proceed through checkout")
	public void iAddPhysicalGiftCardToCart() throws Exception {
		PdtsearchresultPage pdp = new PdtsearchresultPage();

		iAddFloralItemToShoppingCart();
		iAddPhysicalGiftCardToShoppingCart();
		pdp.iNavigateToCartPage();
		iCheckOutTheProduct();

	}

	@QAFTestStep(description = "I customize the floral product as store pickup and add it to cart")
	public void iCustomizeTheFloralProductAsStorePickUpAndAddItToCart() {
		CustomizeTestPage customizepage = new CustomizeTestPage();
		PDPTestPage pdp = new PDPTestPage();

		PdtsearchresultPage.iNavigateToPDPByClickingOnTheProduct();

		// Validating Select delivery
		customizepage.getCustomizeLblSelectdelivery().verifyPresent();
		customizepage.getCustomizeBtnDelivery().verifyPresent();
		customizepage.getCustomizeBtnStorepickup().verifyPresent();
		customizepage.getCustomizeBtnStorepickup().click();
		PerfectoUtils.reportMessage("Store Pickup option is selected", MessageTypes.Pass);

		// Validating Bouquet Quality
		customizepage.getCustomizeLblBqtquality().verifyPresent();
		PerfectoUtils.reportMessage(
				"Current Bouquet Quality: " + customizepage.getCustomizeLblBqtqualityoption().getText(),
				MessageTypes.Info);

		// Validating Rose Primary Color
		PerfectoUtils.scrolltoelement(customizepage.getCustomizeLblPrimarycolor());
		customizepage.getCustomizeLblPrimarycolor().verifyPresent();
		PerfectoUtils.scrolltoelement(customizepage.getCustomizeLblPrimarycoloroptions().get(0));
		customizepage.getCustomizeLblPrimarycoloroptions().get(0).click();
		PerfectoUtils.reportMessage("Rose Primary Color has selected as: "
				+ customizepage.getCustomizeLblPrimarycoloroptions().get(0).getText(), MessageTypes.Pass);

		// Validating Enter Free Card Message
		PerfectoUtils.scrolltoelement(customizepage.getCustomizeLblMessage());
		customizepage.getCustomizeLblMessage().verifyPresent();
		customizepage.getCustomizeTxtMessage().sendKeys(getBundle().getString("floralCustomize.cardMsg"));
		PerfectoUtils.reportMessage("Entered Card message!", MessageTypes.Pass);

		PerfectoUtils.scrolltoelement(pdp.getPdpBtnAddtocart());
		pdp.getPdpBtnAddtocart().waitForPresent(3000);
		pdp.getPdpBtnAddtocart().click();
	}

	@QAFTestStep(description = "I customize the floral product and add it to cart")
	public void iCustomizeTheFloralProductAndAddItToCart() {
		PDPTestPage pdp = new PDPTestPage();

		PdtsearchresultPage.iNavigateToPDPByClickingOnTheProduct();
		HomePage.iValidateTheFloralCustomizeOptions();
		PerfectoUtils.scrolltoelement(pdp.getPdpBtnAddtocart());
		pdp.getPdpBtnAddtocart().waitForPresent(3000);
		pdp.getPdpBtnAddtocart().click();
		pdp.waitForPageToLoad();
		pdp.waitForAjaxToComplete();
	}
	
	@QAFTestStep(description = "I validate Delivery Options")
	public void iValidateDeliveryOptions() {
		PDPTestPage pdp = new PDPTestPage();

		pdp.getImgDeliveryFirstPdt().click();
		HomePage.iValidateTheFloralCustomizeOptions();
		PerfectoUtils.scrolltoelement(pdp.getPdpBtnAddtocart());
		pdp.getPdpBtnAddtocart().waitForPresent(3000);
		pdp.getPdpBtnAddtocart().click();
		pdp.waitForPageToLoad();
		pdp.waitForAjaxToComplete();
	}
	
	@QAFTestStep(description = "I customize the floral product with Multiple lines in MessageBox and add it to cart")
	public void iCustomizeTheFloralProductWithMultipleLinesinMessageAndAddItToCart() {
		PDPTestPage pdp = new PDPTestPage();

		PdtsearchresultPage.iNavigateToPDPByClickingOnTheProduct();
		HomePage.iValidateTheFloralCustomizeOptionsWithMultipleLinesinMessageBox();
		PerfectoUtils.scrolltoelement(pdp.getPdpBtnAddtocart());
		pdp.getPdpBtnAddtocart().waitForPresent(3000);
		pdp.getPdpBtnAddtocart().click();
		pdp.waitForPageToLoad();
		pdp.waitForAjaxToComplete();
	}

	@QAFTestStep(description = "I add bakery item to Shopping cart")
	public void iAddBakeryItemToShoppingCart() {

		PdtsearchresultPage.ienterValidSearchTermAndSelectSearchButton(getBundle().getString("products.customcake"));
		PdtsearchresultPage.iSeeSearchResultsPage();
		iCustomizeTheBakeryItemAndAddItToCart();

	}

	@QAFTestStep(description = "I add floral item to Shopping cart")
	public void iAddFloralItemToShoppingCart() {

		PdtsearchresultPage
				.ienterValidSearchTermAndSelectSearchButton(getBundle().getString("products.floralCustomize"));
		PdtsearchresultPage.iSeeSearchResultsPage();
		iCustomizeTheFloralProductAndAddItToCart();

	}

	@QAFTestStep(description = "I add gift card to Shopping cart")
	public void iAddGiftCardToShoppingCart() {

		PaymentGatewayStepdef.navigateToGiftCardsPage();
		PaymentGatewayStepdef.navigateToSendAnEGiftCardPage();
		PaymentGatewayStepdef.addTheEGiftCardToCart();

	}

	@QAFTestStep(description = "I validate the properties of cart page")
	public void iValidateThePropertiesOfCartPage() {
		CartTestPage cart = new CartTestPage();

		cart.getCartLblHeader().verifyPresent();
		cart.getCartLnkContinueshopping().verifyPresent();
		cart.getCartBtnCheckout().verifyPresent();

		cart.getCartBoxCartproductblock().verifyPresent();
		cart.getCartLblProductname().verifyPresent();
		cart.getCartEdtQty().verifyPresent();
		cart.getCartLnkRemove().verifyPresent();

		PerfectoUtils.scrolltoelement(cart.getCartBtnApply());
		cart.getCartBtnApply().verifyPresent();
		cart.getCartLblItemtotal().verifyPresent();
		cart.getCartLblSubtotal().verifyPresent();
	}

	@QAFTestStep(description = "I navigate to cart by selecting View Cart in Cart Mouseover option")
	public static void iNavigateToCartBySelectingViewCartInCartMouseoverOption() {
		InStoreHomePage instorehome = new InStoreHomePage();
		CartTestPage cartpage = new CartTestPage();
		FrontdoorTestPage front = new FrontdoorTestPage();
		
		PerfectoUtils.scrolltoelement(instorehome.getHomeBtnCart());
		PerfectoUtils.mousehoverusingActions(instorehome.getHomeBtnCart());
		instorehome.getHomeBtnCartviewcart().click();
		cartpage.getCartLblHeader().waitForPresent(5000);
		front.getFrontImgFav().verifyPresent();
	}

	@QAFTestStep(description = "I increase the product quantity by {0} and validate the item total")
	public void iIncreaseTheProductQuantityAndValidateTheItemTotal(int count) {
		CartTestPage cartpage = new CartTestPage();
		String ordertotal = "0";
		String oldOrdertotal = "0";
		String oldSubtotal = "0";
		// Float increasedAmount;
		// String finalTotalValue = "0";
		String taxvalue = "0";

		if (cartpage.getCartLblTaxValue().isPresent()) {
			taxvalue = cartpage.getCartLblTaxValue().getText().replace("$", "");
			taxvalue = taxvalue.trim();
		}
		getBundle().setProperty("taxvalue", taxvalue);

		cartpage.getCartBoxCartproductblockComp().get(0).waitForPresent(5000);
		cartpage.getCartBoxCartproductblockComp().get(0).verifyPresent();

		Shoppingcart cartComponent = cartpage.getCartBoxCartproductblockComp().get(0);
		String existingQty = cartComponent.getCartEdtQty().getAttribute("value");
		String existingItemtotal = cartpage.getCartLblSubtotalvalue().getText().replace("$", "");
		float singleItemPrice = Float.parseFloat(existingItemtotal) / Integer.parseInt(existingQty);

		oldOrdertotal = cartpage.getCartLblOrderTotalValue().getText().replace("$", "");
		oldOrdertotal = oldOrdertotal.trim();

		oldSubtotal = cartpage.getCartLblSubtotalvalue().getText().replace("$", "");

		String updateQty = Integer.toString(Integer.parseInt(existingQty) + count);
		cartComponent.getCartEdtQty().clear();
		cartComponent.getCartEdtQty().sendKeys(updateQty);
		cartComponent.getCartBtnUpdate().click();
		PerfectoUtils.reportMessage("Increased Quantity by " + count);
		cartComponent.getCartLblItemtotal().waitForPresent(8000);
		cartpage.getCartLblSubtotalvalue().waitForPresent(5000);
		String updatedItemtotal = cartpage.getCartLblSubtotalvalue().getText().replace("$", "");

		if (Float.parseFloat(
				updatedItemtotal) == (float) (Math.round((singleItemPrice * Integer.parseInt(updateQty)) * 100.0)
						/ 100.0)) {
			PerfectoUtils.reportMessage("Updating Quantity, updates the item total", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Updating Quantity, does not update the item total", MessageTypes.Fail);
		}

		ordertotal = cartpage.getCartLblOrderTotalValue().getText().replace("$", "");
		ordertotal = ordertotal.trim();

		/*
		 * increasedAmount = Float.parseFloat(updatedItemtotal) -
		 * Float.parseFloat(oldSubtotal);
		 * 
		 * finalTotalValue = String.valueOf(Float.parseFloat(oldOrdertotal) +
		 * increasedAmount);
		 * 
		 * if (Float.parseFloat(ordertotal) ==
		 * Float.parseFloat(finalTotalValue)) { PerfectoUtils.reportMessage(
		 * "Updating Quantity, updates the total item amount",
		 * MessageTypes.Pass); } else { PerfectoUtils.reportMessage(
		 * "Updating Quantity, does not update the total item amount",
		 * MessageTypes.Fail); }
		 */
	}

	@QAFTestStep(description = "I click on edit details link")
	public void iClickOnEditDetailsLink() {
		CartTestPage cartpage = new CartTestPage();
		String discount = "0";
		String morediscount = "0";
		String taxvalue = "0";
		String subtotal = "0";
		String ordertotal = "0";

		Shoppingcart cartComponent = cartpage.getCartBoxCartproductblockComp().get(0);
		String existingQty = cartComponent.getCartEdtQty().getAttribute("value");
		String existingItemtotal = cartpage.getCartLblSubtotalvalue().getText().replace("$", "");
		if (cartComponent.getCartLblDiscountvalue().isPresent()) {
			discount = cartComponent.getCartLblDiscountvalue().getText().replace("$", "").replace("-", "").trim();
			if (discount.contains(" ")) {
				String[] discountText = discount.split(" ");
				discount = discountText[0];
			}
		}

		if (cartpage.getCartLblMoreDiscountsValue().isPresent()) {
			morediscount = cartpage.getCartLblMoreDiscountsValue().getText().replace("$", "").replace("-", "");
			morediscount = morediscount.trim();
		}

		if (cartpage.getCartLblTaxValue().isPresent()) {
			taxvalue = cartpage.getCartLblTaxValue().getText().replace("$", "");
			taxvalue = taxvalue.trim();
		}

		if (cartpage.getCartLblOrderSubtotalValue().isPresent()) {
			subtotal = cartpage.getCartLblOrderSubtotalValue().getText().replace("$", "");
			subtotal = subtotal.trim();
		}

		if (cartpage.getCartLblOrderTotalValue().isPresent()) {
			ordertotal = cartpage.getCartLblOrderTotalValue().getText().replace("$", "");
			ordertotal = ordertotal.trim();
		}
		float singleItemPrice = (Float.parseFloat(existingItemtotal) + Float.parseFloat(discount))
				/ Integer.parseInt(existingQty);
		String oldSubttl = cartComponent.getCartLblItemtotal().getText().replace("$", "");
		getBundle().setProperty("singleItemPrice", singleItemPrice);
		getBundle().setProperty("morediscount", morediscount);
		getBundle().setProperty("taxvalue", taxvalue);
		getBundle().setProperty("subtotal", subtotal);
		getBundle().setProperty("oldSubttl", oldSubttl);
		getBundle().setProperty("ordertotal", ordertotal);

		cartpage.getCartBoxCartproductblockComp().get(0).waitForPresent(5000);
		cartpage.getCartBoxCartproductblockComp().get(0).getCartLnkEditdetails().verifyPresent();
		cartpage.getCartBoxCartproductblockComp().get(0).getCartLnkEditdetails().click();
	}

	@QAFTestStep(description = "I update the quantity in Edit details and validate the item total")
	public void iUpdateTheQuantityInEditDetailsAndValidateTheItemTotal() {
		CartTestPage cartpage = new CartTestPage();

		cartpage.waitForPageToLoad();
		// cartpage.waitForAjaxToComplete();

		String existingQty = cartpage.getCartEdtEditqty().getAttribute("value");
		float singleItemPrice = getBundle().getFloat("singleItemPrice");
		String oldOrdertotal = ConfigurationManager.getBundle().getString("ordertotal");
		String newOrdertotal = "0";
		Float increasedAmount;
		String finalTotalValue = "0";
		String oldSubtotal = ConfigurationManager.getBundle().getString("oldSubttl");

		String updateQty = Integer.toString(Integer.parseInt(existingQty) + 1);
		cartpage.getCartEdtEditqty().clear();
		cartpage.getCartEdtEditqty().sendKeys(updateQty);
		cartpage.getCartBtnEditupdate().click();
		PerfectoUtils.reportMessage("Increased Quantity by 1");

		Shoppingcart cartComponent = cartpage.getCartBoxCartproductblockComp().get(0);
		cartComponent.getCartLblItemtotal().waitForPresent(5000);
		String updatedItemtotal = cartComponent.getCartLblItemtotal().getText().replace("$", "");

		newOrdertotal = cartpage.getCartLblOrderTotalValue().getText().replace("$", "");
		newOrdertotal = newOrdertotal.trim();

		increasedAmount = Float.valueOf(updatedItemtotal) - Float.valueOf(oldSubtotal);

		finalTotalValue = String.valueOf(Float.valueOf(oldOrdertotal) + increasedAmount);

		if (Float.parseFloat(
				updatedItemtotal) == (float) (Math.round((singleItemPrice * Integer.parseInt(updateQty)) * 100.0)
						/ 100.0)) {
			PerfectoUtils.reportMessage("Updating Quantity, updates the item total", MessageTypes.Pass);
		} else {
			if (cartComponent.getCartLblDiscountvalue().isPresent()) {
				String discount = cartComponent.getCartLblDiscountvalue().getText().replace("$", "").replace("-", "");
				System.out.println((Float.parseFloat(updatedItemtotal) + Float.parseFloat(discount)));
				System.out.println((singleItemPrice * Integer.parseInt(updateQty)));

				if ((Float.parseFloat(updatedItemtotal) + Float.parseFloat(discount)) == Math
						.round((singleItemPrice * Integer.parseInt(updateQty))))
					PerfectoUtils.reportMessage("Updating Quantity, updates the item total and discount applied",
							MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("Updating Quantity, does not update the item total", MessageTypes.Fail);
			} else {
				PerfectoUtils.reportMessage("Updating Quantity, does not update the item total", MessageTypes.Fail);
			}
		}

		if (Float.parseFloat(newOrdertotal) == Float.parseFloat(finalTotalValue)) {
			PerfectoUtils.reportMessage("Updating Quantity, updates the total item amount", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Updating Quantity, does not update the total item amount", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I validate the added shipping address")
	public void iValidateTheAddedShippingAddress() {
		ShippingTestPage shipping = new ShippingTestPage();

		PerfectoUtils.reportMessage("Navigated to Shipping section.", MessageTypes.Pass);
		List<String> shippingAd = getBundle().getList("myAccount.addressbook.address1.atShippingTab");
		System.out.println(shippingAd);
		int i = 0;

		if (shipping.getShippingtabLblShippingto().isPresent()) {
			PerfectoUtils.reportMessage("Shipping address available as:", MessageTypes.Pass);

			for (QAFWebElement temp : shipping.getShippingtabLiLblShippingtoaddresslist()) {
				String address = temp.getText();
				address = PerfectoUtils.removeSpecialCharacters(address);

				// Validate all fields of shipping address
				if (PerfectoUtils.removeSpecialCharacters(shippingAd.get(i)).equals(address)) {
					PerfectoUtils.reportMessage("Matching Address: " + address, MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Non Matching Address: " + address, MessageTypes.Fail);
				}
				i++;
			}

			// Clicking continue button
			shipping.getShippingtabBtnContinueexistingaddress().waitForPresent(5000);
			shipping.getShippingtabBtnContinueexistingaddress().click();
		} else {
			PerfectoUtils.reportMessage("Added Shipping address is not available!!", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I enter gift card details and apply")
	public void iEnterGiftCardDetailsAndApply() {
		PaymentTestPage payment = new PaymentTestPage();

		PerfectoUtils.reportMessage("Navigated to Payment section.", MessageTypes.Pass);
		getBundle().setProperty("orderTotal", payment.getPaymentLblOrdertotalamt().getText());
		PerfectoUtils.scrolltoelement(payment.getPaymentLblOrdertotalamt());
		PerfectoUtils.reportMessage(
				"Order total amount before applying GiftCard: " + payment.getPaymentLblOrdertotalamt().getText(),
				MessageTypes.Pass);
		makePaymentsUsingGiftCardAlone();
	}

	@QAFTestStep(description = "I remove the gift card and validate the order total amount is changed")
	public void iRemoveTheGiftCardAndValidateTheOrderTotalAmountIsChanged() {
		PaymentTestPage payment = new PaymentTestPage();

		payment.getPaymentLnkGiftcardremove().verifyPresent();
		payment.getPaymentLnkGiftcardremove().click();

		String orderTotal = payment.getPaymentLblOrdertotalamt().getText();

		if (orderTotal.equals(getBundle().getString("orderTotalWithGiftCard"))) {
			PerfectoUtils.reportMessage("Total Amount is not modified!!", MessageTypes.Fail);
		} else if (orderTotal.equals(getBundle().getString("orderTotal"))) {
			PerfectoUtils.reportMessage("Total Amount is modified, With Gift card: "
					+ getBundle().getString("orderTotalWithGiftCard") + " " + "WithOut Gift Card: " + orderTotal,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Total Amount is modified, but not like before! Pls chk it!",
					MessageTypes.Info);
		}
	}

	@QAFTestStep(description = "Navigate to donations page by launching url {0}")
	public void NavigateToDonationsPageByLaunchingUrl(String url) {
		PerfectoUtils.getDriver().get(url);
	}

	@QAFTestStep(description = "Verify Donation page properties")
	public void verifyDonationValueIncrementsShowOnThePageDropDown() {
		Donations donation = new Donations();

		donation.getDonationLblHeader().verifyPresent();
		donation.getDonationLblDonatenow().verifyPresent();
		donation.getDonationBtnAmountdropdown().verifyPresent();
		donation.getDonationBtnAddtocart().verifyPresent();
	}

	@QAFTestStep(description = "Verify donation value can be added to cart")
	public void verifyDonationValueCanBeAddedToCart() {
		Donations donation = new Donations();

		PerfectoUtils.dropdownSelectByIndex(donation.getDonationBtnAmountdropdown(), 0);
		PerfectoUtils.reportMessage("Donation amount selected", MessageTypes.Pass);
		donation.getDonationBtnAddtocart().click();
	}

	@QAFTestStep(description = "Validate error message with wrong zip code and street combination in Delivery section")
	public synchronized void entertDeliveryAddressWithWrongZipCodeAndStreetCombination() {
		DeliveryTestPage delivery = new DeliveryTestPage();

		PerfectoUtils.reportMessage("Navigated to Delivery section.", MessageTypes.Pass);
		PerfectoUtils.reportMessage("Pickup date: " + delivery.getDeliveryTxtDeliverydate().getAttribute("value"));

		PerfectoUtils.scrolltoelement(delivery.getDeliveryLblDeliveryaddress());
		PerfectoUtils.reportMessage("Entering the mandatory fields..", MessageTypes.Pass);
		delivery.getDeliveryTxtFirstname().sendKeys(getBundle().getString("shippingaddress1.FirstName"));
		delivery.getDeliveryTxtLastname().sendKeys(getBundle().getString("shippingaddress1.LastName"));
		delivery.getDeliveryTxtPhonefield1().sendKeys(getBundle().getString("shippingaddress1.phonenumberone"));
		delivery.getDeliveryTxtPhonefield2().sendKeys(getBundle().getString("shippingaddress1.phonenumbertwo"));
		delivery.getDeliveryTxtPhonefield3().sendKeys(getBundle().getString("shippingaddress1.phonenumberthree"));

		PerfectoUtils.scrolltoelement(delivery.getDeliveryTxtPhonefield1());
		delivery.getDeliveryTxtStreetaddress1().sendKeys(getBundle().getString("shippingaddress1.inValidStreet"));
		delivery.getDeliveryTxtCity().sendKeys(getBundle().getString("shippingaddress1.city"));
		PerfectoUtils.reportMessage("Entered the mandatory fields.", MessageTypes.Pass);
		try {
			int size = delivery.getDeliveryLiBtnUsesameadd().size();
			if (size > 0) {
				for (QAFWebElement useSameaddBox : delivery.getDeliveryLiBtnUsesameadd()) {
					PerfectoUtils.scrolltoelement(useSameaddBox);
					useSameaddBox.click();
					PerfectoUtils.reportMessage("Use Same Address is selected in Delivery Address Page!");
				}
			}
		} catch (Exception e) {
			// ignore
		}

		PerfectoUtils.scrolltoelement(delivery.getDeliveryBtnContinue());
		delivery.getDeliveryBtnContinue().waitForPresent(5000);
		delivery.getDeliveryBtnContinue().click();
		PerfectoUtils.reportMessage("Clicked Continue button.", MessageTypes.Pass);
		delivery.waitForPageToLoad();
		delivery.waitForAjaxToComplete();
		delivery.getLblErrormsg().waitForPresent(5000);
		delivery.getLblErrormsg().verifyText(getBundle().getString("cartAndChkOut.delivery.errormsg.validadd"));
	}

	@QAFTestStep(description = "Enter correct zipcode and street combination and continue with payment")
	public synchronized void enterCorrectZipcodeAndStreetCombinationAndContinueWithPayment() {
		DeliveryTestPage delivery = new DeliveryTestPage();
		ShippingTestPage shipping = new ShippingTestPage();

		PerfectoUtils.scrolltoelement(delivery.getDeliveryTxtStreetaddress1());
		delivery.getDeliveryTxtStreetaddress1().clear();
		delivery.getDeliveryTxtStreetaddress1().sendKeys(getBundle().getString("shippingaddress1.street"));
		PerfectoUtils.reportMessage("Corrected street address", MessageTypes.Pass);
		try {
			int size = delivery.getDeliveryLiBtnUsesameadd().size();
			if (size > 0) {
				for (QAFWebElement useSameaddBox : delivery.getDeliveryLiBtnUsesameadd()) {
					PerfectoUtils.scrolltoelement(useSameaddBox);
					useSameaddBox.click();
					PerfectoUtils.reportMessage("Use Same Address is selected in Delivery Address Page!");
				}
			}
		} catch (Exception e) {
			// ignore
		}

		PerfectoUtils.scrolltoelement(delivery.getDeliveryBtnContinue());
		delivery.getDeliveryBtnContinue().waitForPresent(5000);
		delivery.getDeliveryBtnContinue().click();
		PerfectoUtils.reportMessage("Clicked Continue button.", MessageTypes.Pass);
		delivery.waitForPageToLoad();
		delivery.waitForAjaxToComplete();

		if (shipping.getShippingtabLblShippingheader().getAttribute("class").contains("active")) {
			try {
				enterShippingDetails();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@QAFTestStep(description = "I make the payments with credit card and registered mail id {0}")
	public synchronized void iMakeThePaymentsWithCreditCardAndRegisteredMailId(String emailId) {
		PaymentTestPage payment = new PaymentTestPage();

		if (payment.getPaymentLblPaymentmethod().isPresent()) {
			makePaymentsUsingCreditcard(emailId);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Payments section.", MessageTypes.Fail);
		}
	}

	public void enterBillingAddressInPayment(String mailId) {
		PaymentTestPage payment = new PaymentTestPage();

		PerfectoUtils.scrolltoelement(payment.getPaymentLblBillingaddress());

		String firstname = payment.getPaymentTxtFirstname().getAttribute("value");
		String lastname = payment.getPaymentTxtLastname().getAttribute("value");

		if (firstname.length() < 1)
			payment.getPaymentTxtFirstname().sendKeys(getBundle().getString("address.firstname"));

		if (lastname.length() < 1)
			payment.getPaymentTxtLastname().sendKeys(getBundle().getString("address.lastname"));

		payment.getPaymentTxtPhonenumber1().sendKeys(getBundle().getString("address.phonenumber.field1"));
		payment.getPaymentTxtPhonenumber2().sendKeys(getBundle().getString("address.phonenumber.field2"));
		payment.getPaymentTxtPhonenumber3().sendKeys(getBundle().getString("address.phonenumber.field3"));

		PerfectoUtils.scrolltoelement(payment.getPaymentTxtPhonenumber1());
		payment.getPaymentTxtStreetaddress1().sendKeys(getBundle().getString("address.streetaddress1"));
		payment.getPaymentTxtCity().sendKeys(getBundle().getString("address.city"));
		payment.getPaymentTxtZipcode().sendKeys(getBundle().getString("address.zipcode1"));

		payment.getPaymentTxtEmail().sendKeys(mailId);
		payment.getPaymentTxtConfirmemail().sendKeys(mailId);

		PerfectoUtils.reportMessage("Entered the mandatory fields.", MessageTypes.Pass);
	}

	public void makePaymentsUsingCreditcard(String mailId) {
		PaymentTestPage payment = new PaymentTestPage();

		String email = getBundle().getString("myEmail");
		if (email.equals("Cold")) {
			email = getBundle().getString("address.email");
		}

		PerfectoUtils.reportMessage("Navigated to Payment section.", MessageTypes.Pass);

		// 1. Entering the credit card details
		PerfectoUtils.scrolltoelement(payment.getPaymentLblEnteracreditcard());
		enterCreditCardDetailsInpayment();

		// 2. Entering the Billing address details
		PerfectoUtils.scrolltoelement(payment.getPaymentLblBillingaddress());
		enterBillingAddressInPayment(mailId);

		// Verify whether the state box has been pre-populated as "UNITED
		// STATES"
		String strState = payment.getPaymentTxtState().getAttribute("value");
		if (strState.length() > 0) {
			PerfectoUtils.reportMessage("State field has been pre-populated as: " + strState, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("State field has not been pre-populated", MessageTypes.Fail);
		}

		// Applying Tax Exemption for Tax-exempted user
		if (payment.getPaymentLblApplytaxexemption().isPresent()) {
			applyTaxExemption();
		}

		// Chk the checkbox of 21 years old or more for Wine products
		if (payment.getPaymentChkAgeverification().isPresent()) {
			payment.getPaymentChkAgeverification().click();
		}

		// Click on Submit order
		clickSubnmitOrderInPaymentsPage();

	}

	@QAFTestStep(description = "I verify easy sign up option is not available for registered email")
	public synchronized void iVerifyEasySignUpOptionIsNotAvailableForRegisteredEmail() {
		ConfirmationTestPage confirmation = new ConfirmationTestPage();

		confirmation.getConfirmBtnSignup().waitForNotPresent(5000);
		confirmation.getConfirmBtnSignup().verifyNotPresent();
	}

	@QAFTestStep(description = "I verify easy sign up option is available for non-registered email")
	public synchronized void iVerifyEasySignUpOptionIsAvailableForNonRegisteredEmail() {
		ConfirmationTestPage confirmation = new ConfirmationTestPage();

		confirmation.getConfirmBtnSignup().waitForPresent(5000);
		PerfectoUtils.scrolltoelement(confirmation.getConfirmBtnSignup());
		confirmation.getConfirmBtnSignup().verifyPresent();
	}

	@QAFTestStep(description = "I sign up an account using easy sign up option")
	public synchronized void iSignUpAnAccountUsingEasySignUpOption() {
		ConfirmationTestPage confirmation = new ConfirmationTestPage();
		ThankYouTestPage thankYou = new ThankYouTestPage();
		RegistrationTestPage registration = new RegistrationTestPage();

		confirmation.getConfirmBtnSignup().waitForPresent(5000);
		confirmation.getConfirmBtnSignup().verifyPresent();
		confirmation.getConfirmTxtPasswordsignup().sendKeys(getBundle().getString("register.defaultPassword"));
		confirmation.getConfirmBtnSignup().click();
		confirmation.waitForPageToLoad();
		confirmation.waitForAjaxToComplete();

		if (confirmation.getConfirmLblSignuperror().isPresent()) {
			PerfectoUtils.reportMessage("Unexpected error occurred during registration", MessageTypes.Fail);
			PerfectoUtils.scrolltoelement(thankYou.getThnkuLblHostaddress());
			PerfectoUtils.reportMessage("Executed in Host: " + thankYou.getThnkuLblHostaddress().getText(),
					MessageTypes.Fail);
		} else {
			try {
				Logger.saveEmailAndPassword();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	@QAFTestStep(description = "I customize the SPU item and add it to cart")
	public void iCustomizeTheSPUItemAndAddItToCart() {
		PDPTestPage pdp = new PDPTestPage();

		PdtsearchresultPage.iNavigateToPDPByClickingOnTheProduct();
		HomePage.iValidateTheSPUCustomizeOptions();
		PerfectoUtils.scrolltoelement(pdp.getPdpBtnAddtocart());
		pdp.getPdpBtnAddtocart().waitForPresent(3000);
		pdp.getPdpBtnAddtocart().click();
	}

	@QAFTestStep(description = "I validate the order summary section")
	public void iValidateTheOrderSummarySection() {
		CartTestPage cart = new CartTestPage();

		cart.getCartLblInstorePickup().verifyPresent();
		PerfectoUtils.reportMessage("Product is listed under " + cart.getCartLblInstorePickup().getText() + " header",
				MessageTypes.Pass);

		PerfectoUtils.scrolltoelement(cart.getCartBtnApply());
		cart.getCartLblOrderSubtotal().verifyPresent();
		cart.getCartLblDiscounts().verifyPresent();
		cart.getCartLblEstimatedTax().verifyPresent();
		cart.getCartLblOrderTotal().verifyPresent();
	}

	@QAFTestStep(description = "I verify special handling fees is not listed in order summary section")
	public void iVerifySpecialHandlingFeesIsNotListedInOrderSummarySection() {
		CartTestPage cart = new CartTestPage();

		cart.getCartLblNospecialhandling().verifyPresent();
		cart.getCartLblSpecialhandling().verifyNotPresent();

	}

	@QAFTestStep(description = "I verify shipping and handling link on shipping page navigates to Delivery and Returns page")
	public void iVerifyShippingAndHandlingLinkOnShippingPageNavigatesToDeliveryAndReturnsPage() {

		ShippingTestPage shipping = new ShippingTestPage();

		PerfectoUtils.scrolltoelement(shipping.getShippingtabLnkViewAllShipping());
		shipping.getShippingtabLnkViewAllShipping().waitForPresent(2000);

		if (shipping.getShippingtabLnkViewAllShipping().isPresent()) {
			PerfectoUtils.reportMessage("Link for Shipping and handling is present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Link for Shipping and handling is not present", MessageTypes.Fail);
		}
		shipping.getShippingtabLnkViewAllShipping().click();

		if (PerfectoUtils.getDriver().getCurrentUrl()
				.equals(getBundle().getString("cartAndChkOut.shippingAndHandlingLink.deliveryAndReturnsPage"))) {
			PerfectoUtils.reportMessage("Navigated to Delivery and Returns static page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not Navigated to Delivery and Returns static page", MessageTypes.Fail);
		}

		// Verifying Shipping and Handling Link
		String shpnhand = shipping.getShippingtabLblDeliveryandReturns().getText();
		if (shpnhand.equalsIgnoreCase("Delivery and Returns")) {
			PerfectoUtils.reportMessage("Navigated to Delivery and Returns Page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not ablr to see Delivery and Returns Page", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify special handling fees is not listed in order confirmation page")
	public void iVerifySpecialHandlingFeesIsNotListedInOrderConfirmationPage() {
		ConfirmationTestPage checkout = new ConfirmationTestPage();

		checkout.getConfirmTxtSpecialhandlingamount().verifyNotPresent();

	}

	@QAFTestStep(description = "I verify shipping and handling link on shipping page navigates to Shipping and Handling page")
	public void iVerifyShippingAndHandlingLinkOnShippingPageNavigatesToShippingAndHandlingPage() {

		ShippingTestPage shipping = new ShippingTestPage();

		PerfectoUtils.scrolltoelement(shipping.getShippingtabLnkViewAllShipping());
		shipping.getShippingtabLnkViewAllShipping().waitForPresent(2000);

		if (shipping.getShippingtabLnkViewAllShipping().isPresent()) {
			PerfectoUtils.reportMessage("Link for Shipping and handling is present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Link for Shipping and handling is not present", MessageTypes.Fail);
		}

		String currentWindow = PerfectoUtils.getDriver().getWindowHandle();
		shipping.getShippingtabLnkViewAllShipping().click();

		Set<String> windows = PerfectoUtils.getDriver().getWindowHandles();

		for (String window : windows) {
			if (!(currentWindow.equals(window))) {
				PerfectoUtils.getDriver().switchTo().window(window);
			}
		}

		if (PerfectoUtils.getDriver().getCurrentUrl()
				.equals(getBundle().getString("cartAndChkOut.shippingAndHandlingLink.shippingAndHandlingPage"))) {
			PerfectoUtils.reportMessage("URL of Shipping and Handling details static page is displayed",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("URL of Shipping and Handling details static page is not displayed",
					MessageTypes.Fail);
		}

		// Verifying Shipping and Handling Link
		String shpnhand = shipping.getShippingtabLblShippingandhandling().getText();
		if (shpnhand.equalsIgnoreCase("shipping and handling details")) {
			PerfectoUtils.reportMessage("Navigated to Shipping and Handling details static page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not Navigated to Shipping and Handling details static page",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I enter shipping address as {0}")
	public void enterShippingAddressAs(String shipAddressPath) {
		ShippingTestPage shipping = new ShippingTestPage();

		PerfectoUtils.reportMessage("Navigated to Shipping section.", MessageTypes.Pass);
		
		if(!shipping.getShippingtabRbtnNewShippingAddress().isSelected()){
			shipping.getShippingtabRbtnNewShippingAddress().click();
		}

		if (shipping.getShippingtabTxtCountrydropdown().isPresent()) {
			PerfectoUtils.reportMessage("Creating a new shipping address..", MessageTypes.Pass);

			// Verify whether the country box has been pre-populated as "UNITED
			// STATES"
			String strCountry = shipping.getShippingtabTxtCountrydropdown().getText();
			if (strCountry.length() > 0) {
				PerfectoUtils.reportMessage("Country text box has been pre-populated as: " + strCountry,
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Country text box hasn't been pre-populated", MessageTypes.Fail);
			}

			// Filling up the remaining fields in the "Create a new Shipping
			// address" section
			Select sel = new Select(shipping.getShippingtabTxtPrefixdropdown());
			sel.selectByValue("Mr.");

			System.out.println(shipAddressPath + ".AddressNickname");
			System.out.println(getBundle().getString(shipAddressPath + ".AddressNickname"));

			if (shipping.getShippingtabTxtNickname().isPresent()) {
				shipping.getShippingtabTxtNickname().clear();
				shipping.getShippingtabTxtNickname()
						.sendKeys(getBundle().getString(shipAddressPath + ".AddressNickname"));
			}
			if (shipping.getShippingtabTxtFirstname().getAttribute("value").isEmpty()) {
				shipping.getShippingtabTxtFirstname().sendKeys(getBundle().getString(shipAddressPath + ".FirstName"));
			}
			if (shipping.getShippingtabTxtLastname().getAttribute("value").isEmpty()) {
				shipping.getShippingtabTxtLastname().sendKeys(getBundle().getString(shipAddressPath + ".LastName"));
			}

			shipping.getShippingtabTxtPhonenumber1()
					.sendKeys(getBundle().getString(shipAddressPath + ".phonenumberone"));
			shipping.getShippingtabTxtPhonenumber2()
					.sendKeys(getBundle().getString(shipAddressPath + ".phonenumbertwo"));
			shipping.getShippingtabTxtPhonenumber3()
					.sendKeys(getBundle().getString(shipAddressPath + ".phonenumberthree"));

			PerfectoUtils.scrolltoelement(shipping.getShippingtabTxtPhonenumber1());
			shipping.getShippingtabTxtStreetaddress1().clear();
			shipping.getShippingtabTxtStreetaddress1().sendKeys(getBundle().getString(shipAddressPath + ".street"));
			shipping.getShippingtabTxtCity().clear();
			shipping.getShippingtabTxtCity().sendKeys(getBundle().getString(shipAddressPath + ".city"));
			shipping.getShippingtabTxtZipcode1().clear();
			shipping.getShippingtabTxtZipcode1().sendKeys(getBundle().getString(shipAddressPath + ".zipcode"));
			shipping.getShippingtabTxtZipcode2().clear();
			shipping.getShippingtabTxtZipcode2().sendKeys(getBundle().getString(shipAddressPath + ".zipcode2"));
			PerfectoUtils.reportMessage("Entered the mandatory fields.", MessageTypes.Pass);
			
			List<String> newlist = new ArrayList<String>();
			
			newlist.add(getBundle().getString(shipAddressPath + ".FirstName") + " "+ getBundle().getString(shipAddressPath + ".LastName"));
			newlist.add(getBundle().getString(shipAddressPath + ".street"));
			newlist.add(getBundle().getString(shipAddressPath + ".city") + " "+ "TX"+" "+ getBundle().getString(shipAddressPath + ".zipcode"));
			getBundle().setProperty("EnteredShipAddress", newlist);

			// Verify whether the State box has been pre-populated as "UNITED
			// STATES"
			String strState = shipping.getShippingtabTxtStatedropdown().getAttribute("value");
			if (strState.length() > 0) {
				PerfectoUtils.reportMessage("State field has been pre-populated as: " + strState, MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("State field hasn't been pre-populated", MessageTypes.Fail);
			}

			// Clicking the Save button
			shipping.getShippingtabBtnContinuenewaddress().waitForPresent(5000);
			shipping.getShippingtabBtnContinuenewaddress().click();

			// Clicking the continue button
			try {
				shipping.getShippingtabBtnContinueexistingaddress().waitForPresent(5000);
				shipping.getShippingtabBtnContinueexistingaddress().click();
			} catch (Exception e) {
				PerfectoUtils.reportMessage("Continue Btn with Existing address is not present", MessageTypes.Info);
			}

			PerfectoUtils.reportMessage("Clicked the continue button.", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I verify discount and order total after update")
	public void iVerifyDiscountAndOrderTotalAfterUpdate() {
		CartTestPage cartpage = new CartTestPage();

		String morediscount = getBundle().getString("morediscount");
		String SubTotal = getBundle().getString("subtotal");
		String OrderTotal = getBundle().getString("ordertotal");

		// Getting new more discount value
		String newmorediscount = cartpage.getCartLblMoreDiscountsValue().getText().replace("$", "").replace("-", "");
		newmorediscount = newmorediscount.trim();

		// Getting new sub total value
		String newsubtotal = cartpage.getCartLblOrderSubtotalValue().getText().replace("$", "");
		newsubtotal = newsubtotal.trim();

		// Getting new Order total value
		String newordertotal = cartpage.getCartLblOrderTotalValue().getText().replace("$", "");
		newordertotal = newordertotal.trim();

		if (!newsubtotal.equals(SubTotal)) {
			PerfectoUtils.reportMessage("SubTotal has changed after update.New SubTotal is " + newsubtotal,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Discount is still same", MessageTypes.Fail);
		}

		if (!newordertotal.equals(OrderTotal)) {
			PerfectoUtils.reportMessage("Order Total has changed after update.New OrderTotal is " + newordertotal,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Discount is still same", MessageTypes.Fail);
		}

		if (!morediscount.equals(newmorediscount)) {
			PerfectoUtils.reportMessage("Discount has changed after update.New Discount is " + newmorediscount,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Discount is still same", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify tax and order total after update")
	public void iVerifyTaxAndOrderTotalAfterUpdate() {
		CartTestPage cartpage = new CartTestPage();

		String taxvalue = getBundle().getString("taxvalue");
		String SubTotal = getBundle().getString("subtotal");
		String OrderTotal = getBundle().getString("ordertotal");

		// Getting new Tax value
		cartpage.getCartLblTaxValue().verifyPresent();
		String newtaxvalue = cartpage.getCartLblTaxValue().getText().replace("$", "");
		newtaxvalue = newtaxvalue.trim();

		// Getting new sub total value
		String newsubtotal = cartpage.getCartLblOrderSubtotalValue().getText().replace("$", "");
		newsubtotal = newsubtotal.trim();

		// Getting new Order total value
		String newordertotal = cartpage.getCartLblOrderTotalValue().getText().replace("$", "");
		newordertotal = newordertotal.trim();

		if (!newsubtotal.equals(SubTotal)) {
			PerfectoUtils.reportMessage("SubTotal has changed after update.New SubTotal is " + newsubtotal,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Discount is still same", MessageTypes.Fail);
		}

		if (!newordertotal.equals(OrderTotal)) {
			PerfectoUtils.reportMessage("Order Total has changed after update.New OrderTotal is " + newordertotal,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Discount is still same", MessageTypes.Fail);
		}

		if (!taxvalue.equals(newtaxvalue)) {
			PerfectoUtils.reportMessage("Tax has changed after update.New Tax value is " + newtaxvalue,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Tax is still same", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I validate the system generated nick name in Shipping page")
	public void iValidateTheSystemGeneratedNickNameInShippingPage() {
		ShippingTestPage shipping = new ShippingTestPage();
		String expNickName = getBundle().getString("firstName") + getBundle().getString("lastName").charAt(0);

		if (shipping.getShippingtabLblShippingto().isPresent()) {
			PerfectoUtils.reportMessage("Shipping address available as:", MessageTypes.Pass);

			for (QAFWebElement temp : shipping.getShippingtabLiLblShippingtoaddresslist()) {
				PerfectoUtils.reportMessage(temp.getText());
			}
			String actNickName = shipping.getShippingtabLiLblShippingtoaddresslist().get(0).getText()
					.replace("Shipping to: ", "").trim();

			System.out.println("Actual name: " + actNickName);
			System.out.println("Expected name: " + expNickName);

			if (actNickName.equals(expNickName)) {
				PerfectoUtils.reportMessage("System generated nick name is present as expected", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("System generated nick name is not present as expected, Actual name: "
						+ actNickName + ", Expected name: " + expNickName, MessageTypes.Fail);
			}

			// Clicking continue button
			shipping.getShippingtabBtnContinueexistingaddress().waitForPresent(5000);
			shipping.getShippingtabBtnContinueexistingaddress().click();
		} else {
			PerfectoUtils.reportMessage("Shipping address is not available", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the added item name in the Cart flyout")
	public void verifyTheAddedItemNameInTheCartFlyout() {
		InStoreHomePage instorehome = new InStoreHomePage();

		instorehome.getHomeImgCart().waitForPresent(5000);
		PerfectoUtils.mousehover(instorehome.getHomeImgCart());

		boolean isPresent = false;
		String addingItemName = getBundle().getString("addingItemName");

		List<QAFWebElement> cartFlyoutItemNames = instorehome.getLiCartflyoutitemslist();

		for (QAFWebElement ele : cartFlyoutItemNames) {

			System.out.println(ele.getText());
			System.out.println(addingItemName);

			if (addingItemName.contains(ele.getText())) {
				isPresent = true;
				break;
			}
		}

		if (isPresent)
			PerfectoUtils.reportMessage("Added item available in the Cart flyout..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Added item not available in the Cart flyout..", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I add physical gift card to Shopping cart")
	public void iAddPhysicalGiftCardToShoppingCart() {

		PaymentGatewayStepdef.navigateToGiftCardsPage();
		PaymentGatewayStepdef.navigateToShopGiftCardsPage();
		PaymentGatewayStepdef.addThePhysicalGiftCardToCart();

	}

	@QAFTestStep(description = "I verify MOQ in cart page")
	public void iVerifyMOQInCartPage() {
		CartTestPage cartpage = new CartTestPage();
		String addedItem = getBundle().getString("addingItemName");
		String expQty = Integer.toString(getBundle().getInt("MinQuantity"));
		String actQty = "";
		boolean isItemFound = false;

		cartpage.getCartBoxCartproductblockComp().get(0).verifyPresent();

		for (Shoppingcart cartItem : cartpage.getCartBoxCartproductblockComp()) {
			if (PerfectoUtils.removeSpecialCharacters(addedItem)
					.contains(PerfectoUtils.removeSpecialCharacters(cartItem.getCartLblProductname().getText()))) {
				actQty = cartItem.getCartEdtQty().getAttribute("value");
				isItemFound = true;
				break;
			} else {
				isItemFound = false;
			}
		}

		if (isItemFound) {
			if (actQty.equals(expQty)) {
				reportMessage("Minimum order Quantity displays in Cart page", MessageTypes.Pass);
			} else {
				reportMessage("Minimum order Quantity is not displayed in Cart page", MessageTypes.Fail);
			}
		} else {
			reportMessage("Item not found in Cart", MessageTypes.Fail);

		}
	}

	@QAFTestStep(description = "I verify gift card payment type is not allowed")
	public void iVerifygiftcardpaymenttypeisnotallowed() {
		GiftcardslandingTestPage giftcard = new GiftcardslandingTestPage();

		if (giftcard.getLblGiftcardheaderpayment().verifyNotPresent()) {
			PerfectoUtils.reportMessage("Gift card payment type is not allowed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Gift card payment type is allowed", MessageTypes.Fail);
		}
		giftcard.getLnkEditcart().click();

	}

	@QAFTestStep(description = "I verify reordering MOQ product in cart page")
	public void iVerifyReorderingMOQInCartPage() {
		CartTestPage cartpage = new CartTestPage();
		String addedItem = getBundle().getString("addingItemName");
		String expQty = Integer.toString(getBundle().getInt("MinQuantity"));
		String actQty = "";
		boolean isItemFound = false;

		cartpage.getCartBoxCartproductblockComp().get(0).verifyPresent();

		for (Shoppingcart cartItem : cartpage.getCartBoxCartproductblockComp()) {
			if (PerfectoUtils.removeSpecialCharacters(addedItem)
					.contains(PerfectoUtils.removeSpecialCharacters(cartItem.getCartLblProductname().getText()))) {
				actQty = cartItem.getCartLblMinqty().getText().trim().split(" ")[0];
				isItemFound = true;
				break;
			} else {
				isItemFound = false;
			}
		}

		if (isItemFound) {
			if (actQty.equals(expQty)) {
				reportMessage("Minimum order Quantity displays in Cart page", MessageTypes.Pass);
			} else {
				reportMessage("Minimum order Quantity is not displayed in Cart page", MessageTypes.Fail);
			}
		} else {
			reportMessage("Item not found in Cart", MessageTypes.Fail);

		}
	}

	@QAFTestStep(description = "I select customize floral product from Make Ready page and add it to cart")
	public void iSelectCustomizeFloralProductFromMakeReadyPageAndAddItToCart() {
		PDPTestPage pdp = new PDPTestPage();

		iNavigateToCustomizeProductPDPFromMakeReadyPage();
		HomePage.iValidateTheFloralCustomizeOptions();
		PerfectoUtils.scrolltoelement(pdp.getPdpBtnAddtocart());
		pdp.getPdpBtnAddtocart().waitForPresent(3000);
		pdp.getPdpBtnAddtocart().click();
	}

	@QAFTestStep(description = "I navigate to Customize Product PDP from Make Ready page")
	public void iNavigateToCustomizeProductPDPFromMakeReadyPage() {
		MakeReadyTestPage makeready = new MakeReadyTestPage();
		boolean isProductAvail = false;

		for (MakeReadyProducts product : makeready.getMakeLiBoxProductcatridges()) {

			if (product.getMakeBtnCustomize().isPresent()) {
				String productName = product.getMakeLblProductname().getText();
				product.getMakeBtnCustomize().click();
				isProductAvail = true;
				break;
			}
		}

		if (!isProductAvail)
			reportMessage("Make Ready product with Customize is not available", MessageTypes.Fail);
		else
			reportMessage("Navigated to Customize product PDP", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I select customize bakery product from Make Ready page and add it to cart")
	public void iSelectCustomizeBakeryProductFromMakeReadyPageAndAddItToCart() {
		PDPTestPage pdp = new PDPTestPage();

		iNavigateToCustomizeProductPDPFromMakeReadyPage();
		HomePage.iValidateTheBakeryCustomizeOptions();
		PerfectoUtils.scrolltoelement(pdp.getPdpBtnAddtocart());
		pdp.getPdpBtnAddtocart().waitForPresent(3000);
		pdp.getPdpBtnAddtocart().click();
	}

	@QAFTestStep(description = "I validate the shpping method as {0} in shipping tab")
	public void iValidateTheShppingMethodAsInShippingTab(String shipMethod) {
		ShippingTestPage shipping = new ShippingTestPage();
		String shipAddressPath = "shippingaddress.maxNickName";

		PerfectoUtils.reportMessage("Navigated to Shipping section.", MessageTypes.Pass);

		if (shipping.getShippingtabTxtCountrydropdown().isPresent()) {
			PerfectoUtils.reportMessage("Creating a new shipping address..", MessageTypes.Pass);

			// Verify whether the country box has been pre-populated as "UNITED
			// STATES"
			String strCountry = shipping.getShippingtabTxtCountrydropdown().getText();
			if (strCountry.length() > 0) {
				PerfectoUtils.reportMessage("Country text box has been pre-populated as: " + strCountry,
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Country text box hasn't been pre-populated", MessageTypes.Fail);
			}

			// Filling up the remaining fields in the "Create a new Shipping
			// address" section
			Select sel = new Select(shipping.getShippingtabTxtPrefixdropdown());
			sel.selectByValue("Mr.");

			System.out.println(shipAddressPath + ".AddressNickname");
			System.out.println(getBundle().getString(shipAddressPath + ".AddressNickname"));

			if (shipping.getShippingtabTxtNickname().isPresent()) {
				shipping.getShippingtabTxtNickname()
						.sendKeys(getBundle().getString(shipAddressPath + ".AddressNickname"));
			}
			if (shipping.getShippingtabTxtFirstname().getAttribute("value").isEmpty()) {
				shipping.getShippingtabTxtFirstname().sendKeys(getBundle().getString(shipAddressPath + ".FirstName"));
			}
			if (shipping.getShippingtabTxtLastname().getAttribute("value").isEmpty()) {
				shipping.getShippingtabTxtLastname().sendKeys(getBundle().getString(shipAddressPath + ".LastName"));
			}

			shipping.getShippingtabTxtPhonenumber1()
					.sendKeys(getBundle().getString(shipAddressPath + ".phonenumberone"));
			shipping.getShippingtabTxtPhonenumber2()
					.sendKeys(getBundle().getString(shipAddressPath + ".phonenumbertwo"));
			shipping.getShippingtabTxtPhonenumber3()
					.sendKeys(getBundle().getString(shipAddressPath + ".phonenumberthree"));

			PerfectoUtils.scrolltoelement(shipping.getShippingtabTxtPhonenumber1());
			shipping.getShippingtabTxtStreetaddress1().sendKeys(getBundle().getString(shipAddressPath + ".street"));
			shipping.getShippingtabTxtCity().sendKeys(getBundle().getString(shipAddressPath + ".city"));
			shipping.getShippingtabTxtZipcode1().sendKeys(getBundle().getString(shipAddressPath + ".zipcode"));
			shipping.getShippingtabTxtZipcode2().sendKeys(getBundle().getString(shipAddressPath + ".zipcode2"));
			PerfectoUtils.reportMessage("Entered the mandatory fields.", MessageTypes.Pass);

			// Verify whether the State box has been pre-populated as "UNITED
			// STATES"
			String strState = shipping.getShippingtabTxtStatedropdown().getAttribute("value");
			if (strState.length() > 0) {
				PerfectoUtils.reportMessage("State field has been pre-populated as: " + strState, MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("State field hasn't been pre-populated", MessageTypes.Fail);
			}

			// Clicking the Save button
			shipping.getShippingtabBtnContinuenewaddress().waitForPresent(5000);
			shipping.getShippingtabBtnContinuenewaddress().click();

			// Validate the shipping method
			shipping.getShippingtabLblShippingmethod().verifyPresent();
			if (shipping.getShippingtabLblShippingmethod().getText().contains(shipMethod)) {
				reportMessage("Shipping method is displayed as " + shipMethod, MessageTypes.Pass);
			} else {
				reportMessage("Shipping method is not displayed as " + shipMethod, MessageTypes.Fail);
			}

			// Clicking the continue button
			shipping.getShippingtabBtnContinueexistingaddress().waitForPresent(5000);
			shipping.getShippingtabBtnContinueexistingaddress().click();
			PerfectoUtils.reportMessage("Clicked the continue button.", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I validate sth products and shipping method as {0} in Payments tab")
	public void iValidateSthProductsAndShippingMethodAsInPaymentsTab(String shipMethod) {
		PaymentTestPage payment = new PaymentTestPage();

		// Validate the shipping method
		payment.getPaymentLblShippingmethod().verifyPresent();
		if (payment.getPaymentLblShippingmethod().getText().contains(shipMethod)) {
			reportMessage("Shipping method is displayed as " + shipMethod, MessageTypes.Pass);
		} else {
			reportMessage("Shipping method is not displayed as " + shipMethod, MessageTypes.Fail);
		}

		payment.getPaymentLblShiptohome().verifyPresent();
		payment.getPaymentLblShippingamount().verifyPresent();

	}

	@QAFTestStep(description = "I validate sth products and shipping method as {0} in Order Confirmation tab")
	public void iValidateSthProductsAndShippingMethodAsInOrderConfirmationTab(String shipMethod) {

		iValidateSthProductsAndShippingMethodAsInPaymentsTab(shipMethod);

	}

	@QAFTestStep(description = "I order the product and sign up on order confirmation page")
	public void iOrderProductandSignuponOrderConfirmationpage() throws Exception {
		PdtsearchresultPage pdt = new PdtsearchresultPage();

		pdt.iSeeSearchResultsPage();
		iCustomizeTheFloralProductAsStorePickUpAndAddItToCart();
		pdt.iNavigateToCartPage();
		iCheckOutTheProduct();
		iCheckoutTheItemsAsAGuestUser();
		iMakeThePaymentsWithCreditCard();
		iVerifyTheOrderConfirmationPage();
		iVerifyEasySignUpOptionIsAvailableForNonRegisteredEmail();
	}

	@QAFTestStep(description = "I order the deli product and checkout as a guest user")
	public void iOrderDeliProductandCheckoutasGustUser() throws Exception {
		PdtsearchresultPage pdt = new PdtsearchresultPage();

		pdt.iNavigateToCartPage();
		iCheckOutTheProduct();
		iCheckoutTheItemsAsAGuestUser();
	}

	@QAFTestStep(description = "I verify option to save credit card")
	public synchronized void iVerifyOptiontosavecreditcard() {
		ConfirmationTestPage confirmation = new ConfirmationTestPage();
		ThankYouTestPage thankYou = new ThankYouTestPage();

		confirmation.getConfirmTxtPasswordsignup().sendKeys(getBundle().getString("register.defaultPassword"));
		confirmation.getConfirmChkSavepaymentinfo().verifyPresent();
		confirmation.getConfirmChkSavepaymentinfo().click();
		if (confirmation.getConfirmChkSavepaymentinfo().getAttribute("value").equals("true")) {
			PerfectoUtils.reportMessage("Save credit card / payment Info is checked", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Save credit card / payment Info is not checked", MessageTypes.Fail);
		}
		confirmation.getConfirmBtnSignup().click();
		confirmation.waitForPageToLoad();
		confirmation.waitForAjaxToComplete();

		if (confirmation.getConfirmLblSignuperror().isPresent()) {
			PerfectoUtils.reportMessage("Unexpected error occurred during registration", MessageTypes.Fail);
			PerfectoUtils.scrolltoelement(thankYou.getThnkuLblHostaddress());
			PerfectoUtils.reportMessage("Executed in Host: " + thankYou.getThnkuLblHostaddress().getText(),
					MessageTypes.Fail);
		} else {
			try {
				Logger.saveEmailAndPassword();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	@QAFTestStep(description = "Enter Invalid expiration date for credit card and select Submit button")
	public void enterInvalidExpirationDateInPaymentsPageAndSelectSubmitButton() {
		PaymentTestPage payment = new PaymentTestPage();

		PerfectoUtils.reportMessage("Navigated to Payment section.", MessageTypes.Pass);

		// 1. Entering the credit card details
		PerfectoUtils.scrolltoelement(payment.getPaymentLblEnteracreditcard());
		enterInvalidExpirationDateCreditCardDetailsInpayment();

		// 2. Entering Invalid Mobile number in Billing address field
		PerfectoUtils.scrolltoelement(payment.getPaymentLblBillingaddress());
		enterBillingAddressInPayment();

		// 3. Click on Submit order
		PerfectoUtils.scrolltoelement(payment.getPaymentBtnSubmitorder());
		payment.getPaymentBtnSubmitorder().click();

	}

	public void enterInvalidExpirationDateCreditCardDetailsInpayment() {
		PaymentTestPage payment = new PaymentTestPage();

		if (payment.getPaymentLblEnteracreditcard().isPresent()) {
			if (!payment.getPaymentRbtnEnteracreditcard().isSelected()) {
				payment.getPaymentRbtnEnteracreditcard().click();
			}
		}

		payment.getPaymentTxtNameoncard().sendKeys(getBundle().getString("payment.card.nameoncard"));
		payment.getPaymentTxtCardtypemastercard().click();
		payment.getPaymentTxtCardnumber().sendKeys(getBundle().getString("payment.card.cardnumber"));
		payment.getPaymentTxtCardexpirymonthvalue().click();
		payment.getPaymentTxtCardexpiryyearinvalidvalue().click();
		payment.getPaymentTxtCardcvc().sendKeys(getBundle().getString("payment.card.cvc"));

	}

	@QAFTestStep(description = "I verify whether credit card number wiped out on error")
	public void iVerifywhethercreditcardnumberwipedoutonerror() {
		PaymentTestPage payment = new PaymentTestPage();

		if (payment.getPaymentTxtCardnumber().getText().equals("")) {
			PerfectoUtils.reportMessage("Credit card number wiped out", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Credit card number is not wiped out", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I validate Estimated tax {0} in the order summary section")
	public void iValidateEstimatedtaxTheOrderSummarySection(double taxpercent) {
		CartTestPage cart = new CartTestPage();

		String orderSubtotal = cart.getCartLblOrderSubtotalValue().getText();
		String orderSubtotalwithoutdollar = orderSubtotal.replace("$", "");
		double taxCalc = (Double.parseDouble(orderSubtotalwithoutdollar) * taxpercent) / 100;
		DecimalFormat f = new DecimalFormat("##.00");
		String taxCalcwithtwodec = f.format(taxCalc);
		getBundle().setProperty("taxCalc", taxCalcwithtwodec);
		String estimatedTax = cart.getCartLblTaxValue().getText();
		if (estimatedTax.contains(taxCalcwithtwodec)) {
			PerfectoUtils.reportMessage(
					"Order summary section displayed with correct value " + estimatedTax + " of Estimated tax",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Order summary section is displayed with incorrect value " + estimatedTax
					+ " of Estimated tax. Expected value is " + Double.toString(taxCalc), MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify tax is getting calculated for taxable product in Payment page")
	public void iVerifytaxisgettingcalculatedfortaxableproductinPaymentpage() {
		PaymentTestPage payment = new PaymentTestPage();

		if (payment.getPaymentLblEstimatedtaxamt().getText().contains(getBundle().getString("taxCalc"))) {
			PerfectoUtils.reportMessage("Order summary section displayed with correct value of Estimated tax",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Order summary section is displayed with incorrect value of Estimated tax.",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I make the payments with credit card and gift card")
	public synchronized void iMakeThePaymentsWithCreditcardandGiftCard() {
		PaymentTestPage payment = new PaymentTestPage();

		if (payment.getPaymentLblPaymentmethod().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Payment section.", MessageTypes.Pass);
			makePaymentsUsingGiftCardAlone();
			makePaymentsUsingCreditcard();
		} else {
			PerfectoUtils.reportMessage("Not navigated to Payments section.", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I navigate to Home page after checkout")
	public synchronized void iNavigatetoHomePageAfterCheckout() {
		CartTestPage cart = new CartTestPage();
		
		cart.getCartImgLogo().click();
	}

	@QAFTestStep(description = "I verify HEB logo in cdp pdp and till order Confirmation page")
	public synchronized void iVerifyHEBlogoincdppdpandtillorderConfirmationpage() throws Exception {
		InStoreHomePage logo = new InStoreHomePage();
		PdtsearchresultPage pdt = new PdtsearchresultPage();
		CartTestPage cart = new CartTestPage();
		PaymentGatewayStepdef pay = new PaymentGatewayStepdef();
		HomePage home = new HomePage();
		StoreLocatorTestPage getLnkFindStore = new StoreLocatorTestPage();

		pdt.iSeeSearchResultsPage();
		logo.getHomeLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed in cdp", MessageTypes.Pass);

		pdt.iSeeSearchResultPageWithSoldOnlineTag();

		pdt.iNavigateToPDPByClickingOnTheProduct();
		logo.getHomeLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed in pdp", MessageTypes.Pass);

		pdt.iAddItemToCartFromPDP();
		iNavigateToCartBySelectingViewCartInCartMouseoverOption();

		logo.getHomeLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed in cart", MessageTypes.Pass);
		iCheckOutTheProduct();
		cart.getCartImgLogo().verifyPresent();
		cart.getCartImgFooterlogo().verifyPresent();
		iCheckoutTheItemsAsAHotUser();
		cart.getCartImgLogo().verifyPresent();
		cart.getCartImgFooterlogo().verifyPresent();
		iMakeThePaymentsWithCreditCard();
		cart.getCartImgLogo().verifyPresent();
		cart.getCartImgFooterlogo().verifyPresent();
		iVerifyTheOrderConfirmationPage();
		cart.getCartImgLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed in order confirmation page", MessageTypes.Pass);
		cart.getCartImgFooterlogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB footer Logo is displayed in order confirmation page", MessageTypes.Pass);
		pay.selectContinueShoppingOptionFromOrderConfirmationPage();
		home.iNavigateToInstoreHomePage();
		getLnkFindStore.getLnkFindStore().click();
	}
	
	@QAFTestStep(description = "I verify that Phone number field is not accepting blank spaces and special characters {0}")
	public void iVerifyPhonenumberfieldisnotacceptingblankspaces(String shipAddressPath) {
		ShippingTestPage shipping = new ShippingTestPage();

		PerfectoUtils.reportMessage("Navigated to Shipping section.", MessageTypes.Pass);

		if (shipping.getShippingtabTxtCountrydropdown().isPresent()) {
			PerfectoUtils.reportMessage("Creating a new shipping address..", MessageTypes.Pass);

			// Verify whether the country box has been pre-populated as "UNITED
			// STATES"
			String strCountry = shipping.getShippingtabTxtCountrydropdown().getText();
			if (strCountry.length() > 0) {
				PerfectoUtils.reportMessage("Country text box has been pre-populated as: " + strCountry,
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Country text box hasn't been pre-populated", MessageTypes.Fail);
			}

			// Filling up the remaining fields in the "Create a new Shipping
			// address" section
			Select sel = new Select(shipping.getShippingtabTxtPrefixdropdown());
			sel.selectByValue("Mr.");

			System.out.println(shipAddressPath + ".AddressNickname");
			System.out.println(getBundle().getString(shipAddressPath + ".AddressNickname"));

			if (shipping.getShippingtabTxtNickname().isPresent()) {
				shipping.getShippingtabTxtNickname()
						.sendKeys(getBundle().getString(shipAddressPath + ".AddressNickname"));
			}
			if (shipping.getShippingtabTxtFirstname().getAttribute("value").isEmpty()) {
				shipping.getShippingtabTxtFirstname().sendKeys(getBundle().getString(shipAddressPath + ".FirstName"));
			}
			if (shipping.getShippingtabTxtLastname().getAttribute("value").isEmpty()) {
				shipping.getShippingtabTxtLastname().sendKeys(getBundle().getString(shipAddressPath + ".LastName"));
			}
			
			shipping.getShippingtabTxtPhonenumber1().clear();
			shipping.getShippingtabTxtPhonenumber1()
					.sendKeys(getBundle().getString(shipAddressPath + ".phonenumberone"));
			shipping.getShippingtabTxtPhonenumber2()
					.sendKeys(getBundle().getString(shipAddressPath + ".phonenumbertwo"));
			shipping.getShippingtabTxtPhonenumber3().clear();
			shipping.getShippingtabTxtPhonenumber3()
					.sendKeys(getBundle().getString(shipAddressPath + ".phonenumberthree"));

			PerfectoUtils.scrolltoelement(shipping.getShippingtabTxtPhonenumber1());
			shipping.getShippingtabTxtStreetaddress1().clear();
			shipping.getShippingtabTxtStreetaddress1().sendKeys(getBundle().getString(shipAddressPath + ".street"));
			shipping.getShippingtabTxtCity().clear();
			shipping.getShippingtabTxtCity().sendKeys(getBundle().getString(shipAddressPath + ".city"));
			shipping.getShippingtabTxtZipcode1().sendKeys(getBundle().getString(shipAddressPath + ".zipcode"));
			shipping.getShippingtabTxtZipcode2().sendKeys(getBundle().getString(shipAddressPath + ".zipcode2"));
			PerfectoUtils.reportMessage("Entered the mandatory fields.", MessageTypes.Pass);

			// Verify whether the State box has been pre-populated as "UNITED
			// STATES"
			String strState = shipping.getShippingtabTxtStatedropdown().getAttribute("value");
			if (strState.length() > 0) {
				PerfectoUtils.reportMessage("State field has been pre-populated as: " + strState, MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("State field hasn't been pre-populated", MessageTypes.Fail);
			}

			// Clicking the Save button
			shipping.getShippingtabBtnContinuenewaddress().waitForPresent(5000);
			shipping.getShippingtabBtnContinuenewaddress().click();
			
			if(shipping.getShippingtabLblErrormsgdesc().getText().contains(getBundle().getString("shippingaddress.invaildphnerrmsg"))){
				PerfectoUtils.reportMessage("Phone number field is not accepting blank spaces and special characters", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Phone number field is accepting blank spaces and special characters", MessageTypes.Fail);
			}

		}
	}
	
	@QAFTestStep(description = "I Apply Promotional Code {0} In Cart Page")
	public synchronized void iApplyPromotionalCodeInCartPage(String promotionalCode) throws InterruptedException {
		CartTestPage cart = new CartTestPage();
		
		cart.getCartTxtPromotionalcode().clear();
		cart.getCartTxtPromotionalcode().sendKeys(promotionalCode);
		cart.getCartBtnApply().click();
	}
	
	@QAFTestStep(description = "I Remove Promotional Code In Cart Page")
	public synchronized void iRemovePromotionalCodeInCartPage() throws InterruptedException {
		CartTestPage cart = new CartTestPage();
		
		cart.getCartLnkRemovePromotionalcode().click();
		cart.getCartLnkRemovePromotionalcode().verifyNotPresent();
	}

	@QAFTestStep(description = "I select go back to edit address link on verify your shipping address pop up")
	public void ISelectGoBackToEditAddressLinkOnVerifyYourShippingAddressPopUp() {
		ShippingTestPage shipping = new ShippingTestPage();

		shipping.getShippingtabLblVerifyshippingsddress().verifyPresent();
		shipping.getShippingtabLnkGobacktoeditadd().verifyPresent();
		shipping.getShippingtabLnkGobacktoeditadd().click();

	}

	@QAFTestStep(description = "I select Use this address link on verify your shipping address pop up")
	public void ISelectUseThisAddressLinkOnVerifyYourShippingAddressPopUp() {
		ShippingTestPage shipping = new ShippingTestPage();

		shipping.getShippingtabLblVerifyshippingsddress().verifyPresent();
		shipping.getShippingtabBtnUsethisaddress().verifyPresent();
		shipping.getShippingtabBtnUsethisaddress().click();

		// Clicking the continue button
		try {
			shipping.getShippingtabBtnContinueexistingaddress().waitForPresent(5000);
			shipping.getShippingtabBtnContinueexistingaddress().click();
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Continue Btn with Existing address is not present", MessageTypes.Info);
		}
	}

	@QAFTestStep(description = "I validate the USPS Pop up for entering wrong address")
	public void iValidateTheUSPSPopUpForEnteringWrongAddress() {
		ShippingTestPage shipping = new ShippingTestPage();
		List<String> enteredShipAddress = getBundle().getList("EnteredShipAddress");

		shipping.getShippingtabLblVerifyshippingsddress().waitForPresent(5000);
		shipping.getShippingtabLnkGobacktoeditadd().verifyPresent();
		shipping.getShippingtabLblUsethisrecomm().verifyPresent();
		shipping.getShippingtabLblUsetheaddentered().verifyPresent();
		shipping.getShippingtabRbtUsetheaddentered().verifyPresent();
		shipping.getShippingtabRbtUsetheaddentered().verifyPresent();
		if (shipping.getShippingtabRbtUsethisrecomm().isSelected())
			PerfectoUtils.reportMessage("Use this recommendation radion button is selected by default",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Use this recommendation radion button is not selected by default",
					MessageTypes.Fail);
		
		shipping.getShippingtabLblEnteredaddressinusps().verifyPresent();
		String actAddress = shipping.getShippingtabLblEnteredaddressinusps().getText();
		System.out.println(actAddress);
		System.out.println(enteredShipAddress);

	}
	
	@QAFTestStep(description = "I validate the duplicate err msg and USPS Pop up is not displayed for the same wrong address")
	public void iValidateTheDuplicateErrMsgAndUSPSPopUpIsNotDisplayedForTheSameWrongAddress() {
		ShippingTestPage shipping = new ShippingTestPage();
		String expErr = getBundle().getString("shippingaddress.duplicateaddErr");
		
		shipping.getShippingtabLblVerifyshippingsddress().verifyNotPresent();
		shipping.getShippingtabLblErrormsg().verifyPresent();
		shipping.getShippingtabLblErrormsgdesc().verifyText(expErr);
		
	}
	
	@QAFTestStep(description = "I verify item in the cart flyout")
	public void iVerifyiteminthecartflyout() {
		CartTestPage cart = new CartTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		
		String iteminCart = getBundle().getString("addingWeRecommendItemName");
		PerfectoUtils.scrolltoelement(instorehome.getHomeBtnCart());
		PerfectoUtils.mouseover(instorehome.getHomeBtnCart());
		String actualIteminCart = cart.getCartLblCartItemName().getText();
		
		if(iteminCart.contains(actualIteminCart)){
			PerfectoUtils.reportMessage("Added Item displayed in the cart flyout", MessageTypes.Pass);
		} else{
			PerfectoUtils.reportMessage("Added Item is not displayed in the cart flyout", MessageTypes.Fail);
		}
		
	}
	
	@QAFTestStep(description = "I verify the functionality of Shopping Cart icon")
	public void iVerifythefunctionalityofShoppingCarticon() {
		ShopTestPage shop = new ShopTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		OrderhistoryTestPage order = new OrderhistoryTestPage();
		QuickReorderTestPage reorder = new QuickReorderTestPage();
		
		PerfectoUtils.mouseover(instorehome.getHomeBtnCart());
		instorehome.getHomeLblCartZeroItem().verifyPresent();
		instorehome.getHomeLblCartNoItems().verifyPresent();
		instorehome.getHomeBtnCartstartshopping().verifyPresent();
		instorehome.getBtnCartorderhistory().verifyPresent();
		instorehome.getHomeBtnCartquickreorder().verifyPresent();
		instorehome.getHomeBtnCartstartshopping().click();
		shop.getShopLblHeader().verifyPresent();
		PerfectoUtils.mouseoverandclick(instorehome.getHomeBtnCart(), instorehome.getBtnCartorderhistory());
		order.getOdrhistoryTxtOrderhistory().verifyPresent();
		PerfectoUtils.mouseoverandclick(instorehome.getHomeBtnCart(), instorehome.getHomeBtnCartquickreorder());
		reorder.getQuickReoderTxtheader().verifyPresent();
	}
	
	@QAFTestStep(description = "I verify the count on Shopping Cart icon")
	public void iVerifytheCountonShoppingCarticon() {
		ShopTestPage shop = new ShopTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		
		PerfectoUtils.mouseover(instorehome.getHomeBtnCart());
		int totalItems = instorehome.getLiCartflyoutitemsCountlist().size();
		int firstItemsCount=0;
		int secondItemsCount=0;
		String totalRecentlyAddedCount="";
		String totalRecentlyAddedCountSplited="";
		switch(totalItems)
		{
		case 1:
			firstItemsCount = Integer.parseInt(instorehome.getLiCartflyoutitemsCountlist().get(0).getText());
			totalRecentlyAddedCount=instorehome.getLblCartflyoutitemstotalcountlist().getText();
			String[] temp = totalRecentlyAddedCount.split("(");
			totalRecentlyAddedCountSplited=temp[1];
			if(totalRecentlyAddedCountSplited.equals(firstItemsCount+" total)")){
				PerfectoUtils.reportMessage("Item Count displayed as expected in the cart flyout", MessageTypes.Pass);
			} else{
				PerfectoUtils.reportMessage("Item Count is not displayed as expected in the cart flyout", MessageTypes.Fail);
			}
			break;
		case 2:
			firstItemsCount = Integer.parseInt(instorehome.getLiCartflyoutitemsCountlist().get(0).getText());
			secondItemsCount = Integer.parseInt(instorehome.getLiCartflyoutitemsCountlist().get(1).getText());
			totalRecentlyAddedCount=instorehome.getLblCartflyoutitemstotalcountlist().getText();
			String[] temp1 = totalRecentlyAddedCount.split("(");
			totalRecentlyAddedCountSplited=temp1[1];
			int totalCount = firstItemsCount+secondItemsCount;
			if(totalRecentlyAddedCountSplited.equals(totalCount+" total)")){
				PerfectoUtils.reportMessage("Item Count displayed as expected in the cart flyout", MessageTypes.Pass);
			} else{
				PerfectoUtils.reportMessage("Item Count is not displayed as expected in the cart flyout", MessageTypes.Fail);
			}
			break;
		}
	}
	
	@QAFTestStep(description = "Remove the recently added item in cart")
	public void removeRecentlyAddedItemincart() {
		InStoreHomePage instorehome = new InStoreHomePage();
		CartTestPage cartpage = new CartTestPage();

		// Navigating to the cart Page
		instorehome.getHomeImgCart().waitForPresent(1000);
		instorehome.getHomeImgCart().click();
		PerfectoUtils.reportMessage("Clicked on Cart Icon..");

		cartpage.getCartLblHeader().waitForPresent(1000);
		if (cartpage.getCartLblHeader().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Cart page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Cart page", MessageTypes.Fail);
		}

		int RemoveItemsSize = cartpage.getCartLiLnkRemove().size();

				PerfectoUtils.scrolltoelement(cartpage.getCartLiLnkRemove().get(RemoveItemsSize-1));
				cartpage.getCartLiLnkRemove().get(RemoveItemsSize-1).click();
				PerfectoUtils.reportMessage("Clicked on Remove Item " + RemoveItemsSize);

				cartpage.getCartBtnYes().waitForPresent(50000);
				if (cartpage.getCartBtnYes().isPresent()) {
					cartpage.getCartBtnYes().click();
				} else {
					PerfectoUtils.reportMessage("Remove Item Popup not found.", MessageTypes.Fail);
				}

	}
	
	@QAFTestStep(description = "I verify the total item count in the cart flyout")
	public void iVerifyTheTotalItemCountInTheCartFlyout() {
		CartTestPage cart = new CartTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		
		int expCount = getBundle().getInt("MinQuantity");
		PerfectoUtils.scrolltoelement(instorehome.getHomeBtnCart());
		PerfectoUtils.mouseover(instorehome.getHomeBtnCart());
		String actCount = instorehome.getLblCartflyoutitemstotalcountlist().getText().replace("Recently Added (", "").replace("total)", "").trim();
		
		if(expCount== Integer.parseInt(actCount)){
			PerfectoUtils.reportMessage("Added Item count is correctly displaying in the cart flyout", MessageTypes.Pass);
		} else{
			PerfectoUtils.reportMessage("Added Item count is not correct in the cart flyout", MessageTypes.Fail);
		}
		
	}
	
	@QAFTestStep(description = "Validate the error msg if user jump to {0} from {1}")
	public void validateTheErrorMsgIfUserJumpToConfirmationPageFromShippingPage(String jumpUrl, String currentPage) {
		CartTestPage cart = new CartTestPage();
		
		String currentURL = PerfectoUtils.getDriver().getCurrentUrl();
		String requestId = currentURL.substring(currentURL.indexOf("=")+1);
		getBundle().setProperty("requestId", requestId);
		
		System.out.println(getBundle().getString(jumpUrl));
		PerfectoUtils.getDriver().get(getBundle().getString(jumpUrl));
		cart.getCartLblErrormsg().waitForPresent(5000);
		cart.getCartLblErrormsg().verifyText(getBundle().getString("cartAndChkOut.errorMsg.redirectedToCheckOut"));
//		cart.getCartBtnCheckout().verifyPresent();
		

	}
}
