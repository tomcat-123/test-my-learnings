package com.automation.web.steps.MyList;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.TimeZone;

import org.openqa.selenium.support.ui.Select;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.components.ShoppingLists.ManageListsBlocks;
import com.automation.web.pages.coupons.CouponsProductsTestPage;
import com.automation.web.pages.email.EmailTemplateTestPage;
import com.automation.web.pages.homepage.FrontdoorTestPage;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.login.LoginTestPage;
import com.automation.web.pages.myList.MyListTestPage;
import com.automation.web.pages.products.PDPTestPage;
import com.automation.web.pages.products.ShopTestPage;
import com.automation.web.pages.recipes.CookingconnectionTestPage;
import com.automation.web.pages.recipes.RecipedetailTestpage;
import com.automation.web.pages.recipes.RecipelandingTestPage;
import com.automation.web.pages.registration.RegistrationTestPage;
import com.automation.web.pages.registration.ThankYouTestPage;
import com.automation.web.pages.search.PdtsearchresultTestPage;
import com.automation.web.pages.storelocator.SelectStoreTestPage;
import com.automation.web.pages.weeklyads.MiniListTestPage;
import com.automation.web.pages.weeklyads.WeeklyadprintversionTestPage;
import com.automation.web.steps.CommonStepDef;
import com.automation.web.steps.Registration.Registration;
import com.automation.web.steps.weeklyads.WeeklyAdsStepDef;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

/*List of steps in MyList

* I navigate to MyList page
* I verify the different section in the Shopping List landing page
* I click add to list and verify the item in mini list
* I add to shopping list from PDP and verify the item in mini list
* I delete item from the list
* I verify item removed from the list
* I rename {0} the shopping list
* I register for user from shopping list
* I add recommended item to list
* I verify the item present in shopping list
* I verify all the shopping list are displayed in add to list dropdown
* I change the profile store from shopping list
* I click product catalog and verify the product catalog page is loaded
* I create new list from shopping list page
* I click coupon and verify coupon page is loaded
* I click weeklyad and verify weeklyad page is loaded
* I click primopick and verify primopick page is loaded
* I search UPC specific item by search menu and add to list
* I search freeform item by search menu and add to list
* I add receipt items to list
* I navigate to the manage my list landing page
* I save a copy of a list
* I combine two list to a single list
* I delete the list
* I click see all link and verify the respective page
* I click buy it again link and verify the respective page
* I create new list using create new list from list flyout
* I navigate to new list from flyout
* I Add {0} different items to shopping list
* Mouseover My Shopping List
* I Verify the error message is displayed when the user trying to add more than 400 items
* I verify a user cannot add more than 400 items via product catalog, weekly ad, coupons, recipes or primo pick pages
* I verify user can print a list with 400 items
* I click weeklyad and select a store from select a store pop up
* Verify all my list items are loaded in My Lists page
* Verify {0} more items are loaded in My Lists page

*/

public class MyList {

	/**
	 * Click on My Shopping List in-store HomePage
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I navigate to MyList page")
	public void iNavigateToMyListTestPage() throws InterruptedException {
		InStoreHomePage instorehome = new InStoreHomePage();
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		
		instorehome.getHomeEdtSearchtext().waitForPresent(5000);
		instorehome.getHomeEdtSearchtext().click();
		instorehome.getHomeLblShoppinglistfromheader().verifyPresent();
		instorehome.getHomeLblShoppinglistfromheader().click();
		frontdoor.getFrontImgFav().verifyPresent();
	}

	/**
	 * Verify the Presence of My List Header,Text Box,Add to List button,add a
	 * receipt,MyList Name
	 */
	@QAFTestStep(description = "I verify the different section in the Shopping List landing page")
	public void iSeetheDifferentSectionintheShoppingListLandingPage() {
		MyListTestPage mylisttestpage = new MyListTestPage();

		mylisttestpage.getMylistLblMinilist().waitForPresent(5000);
		mylisttestpage.getMylistLblMinilist().verifyPresent();
		mylisttestpage.getMylistLblMylist().verifyPresent();
		mylisttestpage.getMylistEdtMylisttextbox().verifyPresent();
		mylisttestpage.getMylistBtnMylistaddtolist().verifyPresent();
		mylisttestpage.getMylistLblMylistaddareceipt().verifyPresent();
	}
	
	@QAFTestStep(description = "I click on Find Recipes using this List")
	public void iClickonFindRecipesusingthisList() {
		MyListTestPage mylisttestpage = new MyListTestPage();

		PerfectoUtils.scrolltoelement(mylisttestpage.getMylistBtnFindrecipesusingthislist());
		mylisttestpage.getMylistBtnFindrecipesusingthislist().verifyPresent();
		mylisttestpage.getMylistBtnFindrecipesusingthislist().click();
		PerfectoUtils.reportMessage("Clicked the link Find Recipes using this List", MessageTypes.Pass);
	}
	
	@QAFTestStep(description = "I verify recipes are listed for both UPC and nonUPC items")
	public void iVerifyRecipesarelistedforbothUPCandnonUPCitems() {
		InStoreHomePage instore = new InStoreHomePage();
		CookingconnectionTestPage ccTestpage = new CookingconnectionTestPage();
		
		String recipesSearchTxt = instore.getHomeEdtSearchtext().getAttribute("value");
		if(recipesSearchTxt.contains(getBundle().getString("mylist.UPCrecipes")) && recipesSearchTxt.contains(getBundle().getString("mylist.NonUPCrecipes"))){
			PerfectoUtils.reportMessage("Both UPC and nonUPC items are listed in search recipes", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Both UPC and nonUPC items are not listed in search recipes", MessageTypes.Fail);
		}
		String recipesCount = ccTestpage.getLblCCRecipesResultsCount().getText();
		if(Integer.parseInt(recipesCount) > 0){
			PerfectoUtils.reportMessage("Recipes are listed for both UPC and nonUPC items", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Recipes are not listed for both UPC and nonUPC items", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I verify Showing in all my list items section")
	public void iVerifyShowinginallmylistitemssection() {
		CookingconnectionTestPage cookingconnection = new CookingconnectionTestPage();
		
		String showing = cookingconnection.getLblShowingXofY().getText();
		if(showing.contains("Showing")){
			PerfectoUtils.reportMessage("System displays the number of items out of total available items being presented to user "+showing, MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("System not displayed the number of items out of total available items "+showing, MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I verify Sorting options in all my list items section")
	public void iVerifySortingoptionsinallmylistitemssection() throws InterruptedException {
		MyListTestPage mylisttestpage = new MyListTestPage();
		
		Select selectSort = new Select(mylisttestpage.getDDSort());
		String defaultSortOption = selectSort.getFirstSelectedOption().getText();
		if(defaultSortOption.contains(getBundle().getString("mylist.defaultsortoption"))){
			PerfectoUtils.reportMessage("Alphabetically A-Z is the default option displayed", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Alphabetically A-Z is not displayed as default option", MessageTypes.Fail);
		}
		if(selectSort.getOptions().size() == 3){
			String option2 = selectSort.getOptions().get(1).getText();
			String option3 = selectSort.getOptions().get(2).getText();
			if(option2.contains(getBundle().getString("mylist.sortOption2"))){
				PerfectoUtils.reportMessage("Sort option 2 is displayed "+option2, MessageTypes.Pass);
			}else{
				PerfectoUtils.reportMessage("Sort option 2 is not displayed", MessageTypes.Fail);
			}
			if(option3.contains(getBundle().getString("mylist.sortOption3"))){
				PerfectoUtils.reportMessage("Sort option 3 is displayed "+option3, MessageTypes.Pass);
			}else{
				PerfectoUtils.reportMessage("Sort option 3 is not displayed", MessageTypes.Fail);
			}
		}
		//Alphabetically Z-A
		selectSort.selectByValue("1");
		String firstItemName = mylisttestpage.getListItemName("1").getText();
		String secondItemName = mylisttestpage.getListItemName("2").getText();
		String thirdItemName = mylisttestpage.getListItemName("3").getText();
		
		ArrayList < String > al=new ArrayList < String >();
        al.add(firstItemName);
        al.add(secondItemName);
        al.add(thirdItemName);
        
        boolean isSorted=true;
        for(int i=1;i < al.size();i++){
            if(al.get(i-1).compareTo(al.get(i)) < 0){
                isSorted= false;
                PerfectoUtils.reportMessage("Alphabetically Z-A is not sorted", MessageTypes.Fail);
                break;
            }
        }
        if(isSorted == true){
        	PerfectoUtils.reportMessage("Alphabetically Z-A is sorted", MessageTypes.Pass);
        }
        
        selectSort.selectByValue("2");
        
        String firstItemDepartmentName = mylisttestpage.getListItemNameDepartment("1").getText();
		String secondItemDepartmentName = mylisttestpage.getListItemNameDepartment("2").getText();
		String thirdItemDepartmentName = mylisttestpage.getListItemNameDepartment("3").getText();
		
		ArrayList < String > bl=new ArrayList < String >();
		bl.add(firstItemDepartmentName);
		bl.add(secondItemDepartmentName);
		bl.add(thirdItemDepartmentName);
        
		boolean isDepartmentSorted=true;
        for(int j=1;j < bl.size();j++){
            if(bl.get(j-1).compareTo(bl.get(j)) > 0){
            	isDepartmentSorted= false;
                PerfectoUtils.reportMessage("Department is not sorted", MessageTypes.Fail);
                break;
            }
        }
        if(isDepartmentSorted == true){
        	PerfectoUtils.reportMessage("Department is sorted", MessageTypes.Pass);
        }
	}
	
	@QAFTestStep(description = "I verify Email to a friend overlay")
	public void iVerifyEmailtoafriendoverlay() {
		MyListTestPage mylisttestpage = new MyListTestPage();
		EmailTemplateTestPage email = new EmailTemplateTestPage();
		
		mylisttestpage.getIconEmail().click();
		email.getEmailLblHeader().waitForPresent(5000);
		email.getEmailLblHeader().verifyPresent();
		email.getEmailBtnSendemail().verifyPresent();
		email.getEmailEdtRecipentemails().verifyPresent();
		email.getEmailEdtYouremail().verifyPresent();
		email.getEmailEdtYourname().verifyPresent();
		email.getEmailChkSendmecopy().verifyPresent();
		PerfectoUtils.getDriver().switchTo().frame(email.getEmailIframeIamnotrobot());
		email.getEmailRbtIamnotrobot().verifyPresent();
		email.getEmailBtnCancel().click();
		mylisttestpage.getIconEmail().verifyPresent();
		mylisttestpage.getIconEmail().click();
	}

	/**
	 * Verify the item in the MiniList After click on Add to List button
	 */

	@QAFTestStep(description = "I click add to list and verify the item in mini list")
	public void iClickAddToListAndVerifyTheIteminMiniList() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		MyListTestPage mylisttestpage = new MyListTestPage();
		MiniListTestPage minilist = new MiniListTestPage();

		pdtsearchresult.getLnkAddtoList().waitForPresent(3000);
		String productName = pdtsearchresult.getLblProductname().getText();
		pdtsearchresult.getLnkAddtoList().click();
		pdtsearchresult.getLblMiniShoppinglist().waitForPresent(40000);
		String item = minilist.getLiItemsegments().get(0).getLblItemdescriptions().getText();

		if (productName.contains(item)) {
			PerfectoUtils.reportMessage("Product add to list is successful", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Product add to list is not successful", MessageTypes.Fail);
		}

		mylisttestpage.getMylistBtnMinilistclosewindowbutton().click();
	}

	/**
	 * Verify the item in the MiniList After click on Add to Shopping List
	 * Expand Icon
	 */

	@QAFTestStep(description = "I add to shopping list from PDP and verify the item in mini list")
	public void iAddToShoppingListFromPDPAndVerifyTheIteminMiniList() {
		PDPTestPage pdptestpage = new PDPTestPage();
		MyListTestPage mylisttestpage = new MyListTestPage();
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		MiniListTestPage minilist = new MiniListTestPage();

		pdptestpage.getPdpLblProductname().waitForPresent(30000);
		String productName = pdptestpage.getPdpLblProductname().getText();
		pdptestpage.getPdpDpdExpanDropdown().click();
		pdptestpage.getPdpLnkMyList().waitForPresent(1000);
		pdptestpage.getPdpLnkMyList().click();
		minilist.getLblPagetitle().waitForPresent(40000);
		String item = minilist.getLiItemsegments().get(0).getLblItemdescriptions().getText();

		if (item.equalsIgnoreCase(productName)) {
			PerfectoUtils.reportMessage("Product add to list is successful", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Product add to list is not successful", MessageTypes.Fail);
		}

		mylisttestpage.getMylistBtnMinilistclosewindowbutton().click();
	}

	/**
	 * Verify user is able to delete item from default list
	 */

	@QAFTestStep(description = "I delete item from the list")
	public void iDeleteItemFromTheList() {
		PDPTestPage pdptestpage = new PDPTestPage();
		MyListTestPage mylist = new MyListTestPage();

		boolean isItemPresent = false;
		String productName = null;

		pdptestpage.getPdpLblItemNameFromDefaultList().waitForPresent(50000);
		mylist.getMylistLiLblListitems().get(0).verifyPresent();

		for (int i = 0; i < mylist.getMylistLiLblListitems().size(); i++) {
			String itemName = mylist.getMylistLiLblListitems().get(i).getText();
			productName = ConfigurationManager.getBundle().getString("ProductName");
			productName = PerfectoUtils.removeSpecialCharacters(productName);
			itemName = PerfectoUtils.removeSpecialCharacters(itemName);

			if (itemName.equalsIgnoreCase(productName)) {
				PerfectoUtils.reportMessage("Item name matches in default shopping list", MessageTypes.Pass);
				mylist.getMylistLiImgListitemdelete().get(i).click();

				isItemPresent = true;
				break;
			}
		}

		if (!isItemPresent)
			PerfectoUtils.reportMessage("Item name not matches in default shopping list", MessageTypes.Fail);

	}

	/**
	 * Verify the item removed from list
	 */

	@QAFTestStep(description = "I verify item removed from the list")
	public void iVerifyItemRemovedFromTheList() {
		PDPTestPage pdptestpage = new PDPTestPage();
		MyListTestPage mylist = new MyListTestPage();
		String productName = ConfigurationManager.getBundle().getString("ProductName");
		productName = PerfectoUtils.removeSpecialCharacters(productName);

		pdptestpage.getPdpLblItemsInYourList().waitForPresent(3000);

		for (int i = 0; i < mylist.getMylistLiLblListitems().size(); i++) {
			String itemName = mylist.getMylistLiLblListitems().get(i).getText();

			itemName = PerfectoUtils.removeSpecialCharacters(itemName);

			if (itemName.equalsIgnoreCase(productName)) {
				PerfectoUtils.reportMessage("Item is not removed from the list", MessageTypes.Fail);
			} else {
				PerfectoUtils.reportMessage("Item is removed from the list", MessageTypes.Pass);
			}
		}

	}

	/**
	 * Verify user is able to rename the shopping list name
	 */

	@QAFTestStep(description = "I rename {0} the shopping list")
	public void iRenameTheShoppingList(String reName) {
		PDPTestPage pdptestpage = new PDPTestPage();

		pdptestpage.getPdpBtnEditButton().waitForPresent(50000);
		pdptestpage.getPdpBtnEditButton().click();
		pdptestpage.getPdpLblEditListNameTextBox().waitForPresent(3000);
		Random rand = new Random();
		int num = rand.nextInt(99999);
		String newname = reName + num;
		pdptestpage.getPdpLblEditListNameTextBox().clear();
		System.out.println(newname);

		CommonStepDef.entervalueintothetextbox(pdptestpage.getPdpLblEditListNameTextBox(), newname);
		pdptestpage.getPdpBtnEditSave().click();
		pdptestpage.getPdpLblEditListName().waitForPresent(50000);
		String editName = pdptestpage.getPdpLblEditListName().getText();
		String edtName = editName.replace(" Edit", "");
		System.out.println(edtName);
		System.out.println(newname);

		if (edtName.equals(newname)) {
			PerfectoUtils.reportMessage("Rename is sucessfull", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Rename is not sucessfull", MessageTypes.Fail);
		}

	}

	/**
	 * Verify user add items to the shopping list and register for user
	 */

	@QAFTestStep(description = "I register for user from shopping list")
	public void iRegisterForUserFromShoppingList() {
		MyListTestPage mylisttestpage = new MyListTestPage();
		LoginTestPage loginpage = new LoginTestPage();
		RegistrationTestPage registration = new RegistrationTestPage();
		ThankYouTestPage thankYou = new ThankYouTestPage();
		InStoreHomePage inStoredoor = new InStoreHomePage();

		mylisttestpage.getMylistBtnSavebuttontogologinpage().click();
		loginpage.getLoginLnkCreateOne().waitForPresent(50000);
		loginpage.getLoginLnkCreateOne().click();
		registration.getRgstrEdtFirstname().waitForPresent(30000);
		Registration.iRegisterANewAccount();
		thankYou.getThnkuBtnSaveButton().waitForPresent(3000);
		thankYou.getThnkuBtnSaveButton().verifyPresent();
		thankYou.getThnkuBtnSaveButton().click();

		inStoredoor.getHomeLblUserdetail().waitForPresent(5000);
		String howdy = inStoredoor.getHomeLblUserdetail().getText();
		if (howdy.contains("Howdy")) {
			PerfectoUtils.reportMessage("User is sucessfully Registered", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User is not Registered", MessageTypes.Fail);
		}
	}

	/**
	 * Verify user Add recommended item to shopping list
	 */

	@QAFTestStep(description = "I add recommended item to list")
	public void iAddRecommendedItemToList() {
		MyListTestPage mylisttestpage = new MyListTestPage();

		mylisttestpage.getMylistLblRecommendedproductname().waitForPresent(50000);
		PerfectoUtils.scrolltoelement(mylisttestpage.getMylistLnkRecommendedaddtolist());
		mylisttestpage.getMylistLnkRecommendedaddtolist().verifyPresent();
		ConfigurationManager.getBundle().setProperty("recPrdName",
				mylisttestpage.getMylistLblRecommendedproductname().getText());
		mylisttestpage.getMylistLnkRecommendedaddtolist().click();
	}

	/**
	 * Verify the item present in shopping list
	 */

	@QAFTestStep(description = "I verify the item present in shopping list")
	public void iVerifyTheItemPresentInShoppingList() {
		MyListTestPage mylisttestpage = new MyListTestPage();

		mylisttestpage.getMylistLblProductnamefromshoppinglist().waitForPresent(50000);
		String pdtName = mylisttestpage.getMylistLblProductnamefromshoppinglist().getText();
		String recpdtName = ConfigurationManager.getBundle().getString("recPrdName");
		recpdtName = PerfectoUtils.removeSpecialCharacters(recpdtName);
		pdtName = PerfectoUtils.removeSpecialCharacters(pdtName);
		System.out.println("Recommeded Product name **** " + recpdtName);
		System.out.println("Recommeded Product name **** " + pdtName);

		if (pdtName.contains(recpdtName)) {
			PerfectoUtils.reportMessage("Receommended item is added to Shopping List", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Receommended item is not added to Shopping List", MessageTypes.Fail);
		}
	}

	/**
	 * Verify Added lists are getting displayed in Add to List drop down
	 */

	@QAFTestStep(description = "I verify all the shopping list are displayed in add to list dropdown")
	public void iVerifyAllTheShoppingListAreDisplayedInAddToListDropdown() {
		InStoreHomePage instorehome = new InStoreHomePage();
		MyListTestPage mylisttestpage = new MyListTestPage();

		instorehome.getHomeEdtSearchtext().waitForPresent(5000);
		instorehome.getHomeEdtSearchtext().click();
		PerfectoUtils.mousehoverusingActions(instorehome.getHomeLblShoppinglistfromheader());
		int myAdedList = instorehome.getHomeLnkMyAddedList().size();
		List<String> listNames = new ArrayList<String>();

		if (myAdedList > 0) {
			PerfectoUtils.reportMessage(myAdedList + " results found.", MessageTypes.Pass);
			for (QAFWebElement elem : instorehome.getHomeLnkMyAddedList()) {
				listNames.add(elem.getText().trim());
			}
		} else {
			PerfectoUtils.reportMessage("No List elements found..", MessageTypes.Fail);
		}

		instorehome.getHomeLblShoppinglistfromheader().click();
		mylisttestpage.getMylistDpdShoppinglist().waitForPresent(50000);
		mylisttestpage.getMylistDpdShoppinglist().click();
		int dpdList = mylisttestpage.getMylistLiLblAddedlistfromdrpdown().size();
		List<String> listName = new ArrayList<String>();

		if (dpdList > 0) {
			PerfectoUtils.reportMessage(dpdList + " results found.", MessageTypes.Pass);
			for (QAFWebElement ele : mylisttestpage.getMylistLiLblAddedlistfromdrpdown()) {
				listName.add(ele.getText().trim());
			}
		} else {
			PerfectoUtils.reportMessage("No List elements found..", MessageTypes.Fail);
		}
		if (listName.containsAll(listNames)) {
			PerfectoUtils.reportMessage("Added Lists are getting displayed in Add to List drop down",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Added Lists are not getting displayed in Add to List drop down",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I change the profile store from shopping list")
	public void iChangeTheProfileStoreFromShoppingList() {
		// TODO: call test steps
		MyListTestPage mylistPage = new MyListTestPage();

		mylistPage.waitForPageToLoad();
		mylistPage.getMylistLinkChangeprofilestr().verifyPresent();
		mylistPage.getMylistLinkChangeprofilestr().click();

		if (mylistPage.getMylistLblChangestroverlay().isDisplayed())
			PerfectoUtils.reportMessage("Change store overlay displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Change store overlay not displayed", MessageTypes.Fail);

		mylistPage.getMylistLblZipcodeinput().click();
		mylistPage.getMylistLblZipcodeinput().clear();
		String strZip = ConfigurationManager.getBundle().getString("mylist.storename");
		mylistPage.getMylistLblZipcodeinput().sendKeys(strZip);

		mylistPage.getMylistBtnGobtn().click();
		mylistPage.getMylistLblStrname().waitForVisible(30000);
		String newStrName = mylistPage.getMylistLblStrname().getText();
		ConfigurationManager.getBundle().setProperty("storename", newStrName);
		mylistPage.getMylistBtnSelectstr().click();

		mylistPage.getMylistLblChangestroverlay().waitForNotPresent(30000);

		mylistPage.waitForPageToLoad();
		newStrName = PerfectoUtils.removeSpecialCharacters(newStrName);
		try {
			mylistPage.getMylistLblMyliststorename().waitForPresent(50000);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Page is not loaded");
		}
		String changedName = PerfectoUtils.removeSpecialCharacters(mylistPage.getMylistLblMyliststorename().getText());
		if (changedName.equalsIgnoreCase(newStrName))
			PerfectoUtils.reportMessage("New store name is updated in shopping list", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("New store name is not updated in shopping list", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I click product catalog and verify the product catalog page is loaded")
	public void iClickProductCatalogAndVerifyTheProductCatalogPageIsLoaded() {
		// TODO: call test steps
		MyListTestPage mylistPage = new MyListTestPage();
		ShopTestPage shoppg = new ShopTestPage();

		PerfectoUtils.scrolltoelement(mylistPage.getMylistLblProductcatalog());
		mylistPage.getMylistLblProductcatalog().verifyPresent();
		mylistPage.getMylistLblProductcatalog().click();

		shoppg.waitForPageToLoad();

		if (shoppg.getShopLblHeader().getText().contains(ConfigurationManager.getBundle().getString("mylist.shoppage")))
			PerfectoUtils.reportMessage("Shop page is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Shop page is not displayed", MessageTypes.Fail);

		PerfectoUtils.scrolltoelement(mylistPage.getMylistLnkCategory1());
		mylistPage.getMylistLnkCategory1().click();
		PerfectoUtils.scrolltoelement(mylistPage.getMylistLnkCategory1());
		mylistPage.getMylistLnkCategory1().click();

	}

	@QAFTestStep(description = "I create new list from shopping list page")
	public void iCreateNewListFromShoppingListPage() {
		// TODO: call test steps
		MyListTestPage mylisttestpage = new MyListTestPage();

		mylisttestpage.waitForPageToLoad();
		mylisttestpage.getMylistBtnCreatenewlistbtn().verifyPresent();
		mylisttestpage.getMylistBtnCreatenewlistbtn().click();
		String defListNm = mylisttestpage.getMylistLblDefaultlist().getText();
		Date today = new Date();
		DateFormat df = new SimpleDateFormat("MM/dd/yy");
		df.setTimeZone(TimeZone.getTimeZone("CST"));
		String time = df.format(today);
		System.out.println(time);

		if ((defListNm.contains(time)) && (defListNm.contains("My List"))) {
			PerfectoUtils.reportMessage("Default list name is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Default list name is not displayed", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I click coupon and verify coupon page is loaded")
	public void iClickCouponAndVerifyCouponPageIsLoaded() {
		// TODO: call test steps
		MyListTestPage mylisttestpage = new MyListTestPage();
		CouponsProductsTestPage couponsProducts = new CouponsProductsTestPage();

		PerfectoUtils.scrolltoelement(mylisttestpage.getMylistLblCoupons());
		mylisttestpage.getMylistLblCoupons().verifyPresent();
		mylisttestpage.getMylistLblCoupons().click();

		if (couponsProducts.getCouponprdtsLblHeader().isPresent())
			PerfectoUtils.reportMessage("Coupons products page is loaded", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Coupons products page is not loaded", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I click weeklyad and verify weeklyad page is loaded")
	public void iClickWeeklyadAndVerifyWeeklyadPageIsLoaded() {
		MyListTestPage mylisttestpage = new MyListTestPage();
		WeeklyadprintversionTestPage printversion = new WeeklyadprintversionTestPage();

		PerfectoUtils.scrolltoelement(mylisttestpage.getMylistLblWeeklyad());
		mylisttestpage.getMylistLblWeeklyad().verifyPresent();
		mylisttestpage.getMylistLblWeeklyad().click();
		printversion.waitForPageToLoad();

		if (printversion.getLblPageheader().getText().trim().equalsIgnoreCase("weekly ads"))
			PerfectoUtils.reportMessage("Weekly Ad Page is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Weekly Ad Page is not displayed", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I click primopick and verify primopick page is loaded")
	public void iClickPrimopickAndVerifyPrimopickPageIsLoaded() {
		// TODO: call test steps
		MyListTestPage mylisttestpage = new MyListTestPage();

		PerfectoUtils.scrolltoelement(mylisttestpage.getMylistLblPrimopick());
		mylisttestpage.getMylistLblPrimopick().verifyPresent();
		mylisttestpage.getMylistLblPrimopick().click();
		mylisttestpage.waitForPageToLoad();
		if (mylisttestpage.getMylistLblPrimopicktitle().getText().contains("Primo Picks"))
			PerfectoUtils.reportMessage("Primo pick page is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Primo pick page is not displayed", MessageTypes.Fail);
		PdtsearchresultTestPage pdtserchrstpg = new PdtsearchresultTestPage();

		PerfectoUtils.scrolltoelement(pdtserchrstpg.getLnkAddToList());
		pdtserchrstpg.getLnkAddToList().verifyPresent();
	}

	@QAFTestStep(description = "I search UPC specific item by search menu and add to list")
	public void iSearchUPCSpecificItemBySearchMenuAndAddToList() {
		// TODO: call test steps
		MyListTestPage mylisttestpage = new MyListTestPage();
		mylisttestpage.getMylistEdtMylisttextbox()
				.sendKeys(ConfigurationManager.getBundle().getString("mylist.guidedsearch"));

		if (mylisttestpage.getMylistLblFreeformitemname().isDisplayed())
			PerfectoUtils.reportMessage("Search suggestion is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Search suggestion is not displayed", MessageTypes.Fail);

		mylisttestpage.getMylistLblUpcitemname().verifyPresent();

		String UPCItm = mylisttestpage.getMylistLblUpcitemname().getText();
		UPCItm = PerfectoUtils.removeSpecialCharacters(UPCItm);

		mylisttestpage.getMylistLnkUpcitem().click();
		System.out.println(UPCItm);
		mylisttestpage.getMylistLblCatalogitems().waitForPresent(5000);

		boolean itmpresent = false;
		int getsize = mylisttestpage.getMylistLiLblDynamicproduct().size();
		System.out.println(getsize);
		for (int i = 0; i < getsize; i++) {
			String itemname = mylisttestpage.getMylistLiLblDynamicproduct().get(i).getText();
			itemname = PerfectoUtils.removeSpecialCharacters(itemname);
			System.out.println(itemname);

			if (UPCItm.contains(itemname)) {
				System.out.println("item1 " + itemname);
				PerfectoUtils.reportMessage(
						"Selected product1 " + UPCItm + " is added into the shopping list as expected",
						MessageTypes.Pass);
				itmpresent = true;
				break;
			}
		}
		if (!itmpresent)
			PerfectoUtils.reportMessage("Selected item is not added to list", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I search freeform item by search menu and add to list")
	public void iSearchFreeformItemBySearchMenuAndAddToList() {
		// TODO: call test steps
		MyListTestPage mylisttestpage = new MyListTestPage();

		mylisttestpage.waitForPageToLoad();
		mylisttestpage.getMylistEdtMylisttextbox().verifyPresent();
		mylisttestpage.getMylistEdtMylisttextbox()
				.sendKeys(ConfigurationManager.getBundle().getString("mylist.guidedsearch"));
		// mylisttestpage.getGuidedSearchSuggestion().waitForPresent(2000);
		// System.out.println(mylisttestpage.getGuidedSearchSuggestion().getAttribute("style"));
		if (mylisttestpage.getMylistLblFreeformitemname().isDisplayed())
			PerfectoUtils.reportMessage("Search suggestion is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Search suggestion is not displayed", MessageTypes.Fail);

		mylisttestpage.getMylistLblFreeformitemname().verifyPresent();

		String freeformDisplayed = mylisttestpage.getMylistLblFreeformitemname().getText();
		System.out.println(freeformDisplayed);
		mylisttestpage.getMylistLnkFreeformitem().click();
		mylisttestpage.waitForAjaxToComplete();

		System.out.println(mylisttestpage.getMylistLblUnknownlocationitmname().getText());

		if (mylisttestpage.getMylistLblUnknownlocationitmname().getText().equals(freeformDisplayed))
			PerfectoUtils.reportMessage("Freeform item is added to list", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Freeform item is not added to list", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I add receipt items to list")
	public void iAddReceiptItemsToList() {
		MyListTestPage mylistPage = new MyListTestPage();

		mylistPage.getMylistTxtReceiptadd().sendKeys(ConfigurationManager.getBundle().getString("mylist.receiptID"));
		mylistPage.getMylistTxtReceiptadd().verifyPresent();
		PerfectoUtils.reportMessage("Receipt no entered..");
		mylistPage.getMylistBtnAddreceipttolist().click();
		mylistPage.getMylistLblCatalogitems().waitForEnabled(3000);
		PerfectoUtils.scrolltoelement(mylistPage.getMylistLblMylist());

		try {
			if (mylistPage.getMylistLiLblDynamicproduct().get(0).isDisplayed())
				PerfectoUtils.reportMessage("Receipt item added to list", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Receipt item is not added to list", MessageTypes.Fail);
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Receipt item is not added to list", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I navigate to the manage my list landing page")
	public void iNavigateToTheManageMyListLandingPage() {
		MyListTestPage mylistPage = new MyListTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();

		String userName = null;
		String userName1 = null;
		mylistPage.getMylistLnkManagelistmouseover().waitForPresent(3000);
		mylistPage.getMylistLnkManagelistmouseover().click();
		mylistPage.waitForPageToLoad();
		userName1 = instorehome.getHomeLblUsername().getText();
		System.out.println(userName1);

		userName = userName1.substring(7, userName1.length());
		System.out.println(userName);

		if (mylistPage.getMylistLblUsernamelist().getText().contains(userName))
			PerfectoUtils.reportMessage("Manage list Page is selected", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Manage list page is not selected", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I save a copy of a list")
	public void iSaveACopyOfAList() {
		MyListTestPage mylistPage = new MyListTestPage();

		String listNameOld = null;
		String copyListName = null;

		listNameOld = mylistPage.getMylistLblManagelistname1().getText();
		System.out.println(listNameOld);
		mylistPage.getMylistChkManagelistcheckbox1().verifyPresent();
		mylistPage.getMylistChkManagelistcheckbox1().click();
		PerfectoUtils.reportMessage("list checkbox selected");
		PerfectoUtils.scrolltoelement(mylistPage.getMylistBtnSaveacopy());
		mylistPage.getMylistBtnSaveacopy().verifyPresent();
		mylistPage.getMylistBtnSaveacopy().click();
		mylistPage.waitForPageToLoad();
		copyListName = mylistPage.getMylistLblManagelistname1().getText();

		if (copyListName.contains("Copy of " + listNameOld))
			PerfectoUtils.reportMessage("New list " + copyListName + " is created", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Copy list is not successful", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I combine two list to a single list")
	public void iCombineTwoListToASingleList() {
		MyListTestPage mylistPage = new MyListTestPage();
		String combinationListName = null;

		PerfectoUtils.scrolltoelement(mylistPage.getMylistChkManagelistcheckbox1());
		mylistPage.getMylistChkManagelistcheckbox1().click();
		PerfectoUtils.scrolltoelement(mylistPage.getMylistChkManagelistcheckbox2());
		mylistPage.getMylistChkManagelistcheckbox2().click();
		mylistPage.getMylistChkManagelistcheckbox2().verifyPresent();

		PerfectoUtils.scrolltoelement(mylistPage.getMylistBtnCombinelist());
		mylistPage.getMylistBtnCombinelist().verifyPresent();
		mylistPage.getMylistBtnCombinelist().click();

		mylistPage.waitForPageToLoad();
		combinationListName = mylistPage.getMylistLblManagelistname1().getText();

		if (combinationListName.contains("Combination List"))
			PerfectoUtils.reportMessage("Combination list " + combinationListName + " is created", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Combination list is not created", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I delete the list")
	public void iDeleteTheList() {
		MyListTestPage mylistPage = new MyListTestPage();

		String oldListName = null;
		String newFirsList = null;

		oldListName = mylistPage.getMylistLblManagelistname1().getText();
		PerfectoUtils.scrolltoelement(mylistPage.getMylistChkManagelistcheckbox1());
		mylistPage.getMylistChkManagelistcheckbox1().click();
		mylistPage.getMylistChkManagelistcheckbox2().click();
		mylistPage.getMylistChkManagelistcheckbox3().click();
		mylistPage.getMylistChkManagelistcheckbox2().verifyPresent();

		PerfectoUtils.scrolltoelement(mylistPage.getMylistBtnDeletelist());
		mylistPage.getMylistBtnDeletelist().verifyPresent();
		mylistPage.getMylistBtnDeletelist().click();
		mylistPage.waitForPageToLoad();

		PerfectoUtils.scrolltoelement(mylistPage.getMylistBtnDeleteyes());
		mylistPage.getMylistBtnDeleteyes().waitForPresent(2000);
		mylistPage.getMylistBtnDeleteyes().verifyPresent();
		mylistPage.getMylistBtnDeleteyes().click();
		mylistPage.getMylistLblManagelistname1().waitForPresent(2000);
		newFirsList = mylistPage.getMylistLblManagelistname1().getText();

		// Verify the deleted list name
		if (!newFirsList.equals(oldListName))
			PerfectoUtils.reportMessage("List is deleted", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("List is not deleted", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I click see all link and verify the respective page")
	public void iClickSeeAllLinkAndVerifyTheRespectivePage() {
		MyListTestPage mylistPage = new MyListTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();

		PerfectoUtils.mouseover(instorehome.getHomeLnkMylist());
		mylistPage.getMylistLblListflyout().verifyPresent();
		if (mylistPage.getMylistLnkSeeallmouseover().verifyPresent())
			PerfectoUtils.reportMessage("See All link is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("See All link is not displayed", MessageTypes.Fail);

		PerfectoUtils.mouseover(instorehome.getHomeLnkMylist());
		mylistPage.getMylistLnkSeeallmouseover().click();

		if (mylistPage.getMylistLblMylist().getText().contains("My Lists"))
			PerfectoUtils.reportMessage("My list page is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("My list page is not displayed", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I click buy it again link and verify the respective page")
	public void iClickBuyItAgainLinkAndVerifyTheRespectivePage() {
		MyListTestPage mylistPage = new MyListTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();

		PerfectoUtils.mouseover(instorehome.getHomeLnkMylist());
		mylistPage.getMylistLblListflyout().verifyPresent();
		if (mylistPage.getMylistLnkBuyitagain().verifyPresent())
			PerfectoUtils.reportMessage("Buy it again link is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Buy it again link is not displayed", MessageTypes.Fail);

		PerfectoUtils.mouseover(instorehome.getHomeLnkMylist());
		mylistPage.getMylistLnkBuyitagain().click();

		if (mylistPage.getMylistLblQuickreorder().getText().contains("Quick Reorder"))
			PerfectoUtils.reportMessage("Quick reorder page is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Quick reorder page is not displayed", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I create new list using create new list from list flyout")
	public void iCreateNewListUsingCreateNewListFromListFlyout() {
		MyListTestPage mylistPage = new MyListTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();

		String listNameDefault = null;
		String newListName = null;

		PerfectoUtils.mouseover(instorehome.getHomeLnkMylist());
		mylistPage.getMylistLblListflyout().verifyPresent();
		if (mylistPage.getMylistLnkCreatenewlistmouseover().verifyPresent())
			PerfectoUtils.reportMessage("Create a new list link is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Create a new list link is not displayed", MessageTypes.Fail);

		PerfectoUtils.mouseover(instorehome.getHomeLnkMylist());
		mylistPage.getMylistLiLnkMouseoverlist().get(0).waitForVisible(5000);
		listNameDefault = mylistPage.getMylistLiLnkMouseoverlist().get(0).getText();

		PerfectoUtils.mouseover(instorehome.getHomeLnkMylist());
		mylistPage.getMylistLnkCreatenewlistmouseover().click();
		for (QAFWebElement loadSpinner : mylistPage.getMylistLiImgLoadspinner()) {
			loadSpinner.waitForNotVisible(30000);
		}
		PerfectoUtils.reportMessage("Create new list link clicked", MessageTypes.Info);
		PerfectoUtils.mouseover(instorehome.getHomeLnkMylist());
		mylistPage.getMylistLiLnkMouseoverlist().get(0).waitForEnabled(20000);
		instorehome.getHomeEdtSearchtext().waitForVisible(30000);
		instorehome.getHomeEdtSearchtext().click();

		PerfectoUtils.mouseover(instorehome.getHomeLnkMylist());
		mylistPage.getMylistLblListflyout().verifyPresent();
		PerfectoUtils.mouseover(instorehome.getHomeLnkMylist());
		mylistPage.getMylistLiLnkMouseoverlist().get(0).waitForVisible(50000);
		newListName = mylistPage.getMylistLiLnkMouseoverlist().get(0).getText();
		Date today = new Date();
		DateFormat df = new SimpleDateFormat("MM/dd/yy");
		df.setTimeZone(TimeZone.getTimeZone("CST"));
		String time = df.format(today);
		System.out.println(time);

		if ((newListName.contains(time)) && (newListName.contains("My List"))
				&& (!newListName.equals(listNameDefault))) {
			System.out.println(newListName);
			PerfectoUtils.reportMessage("New list name " + newListName + " is created", MessageTypes.Pass);
			ConfigurationManager.getBundle().setProperty("mylist.newListName", newListName);
		} else {
			PerfectoUtils.reportMessage("New list name is not created", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I navigate to new list from flyout")
	public void iNavigateToNewListFromFlyout() {
		MyListTestPage mylistPage = new MyListTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		String newlistName = null;
		String currentlistName = null;

		instorehome.getHomeEdtSearchtext().waitForVisible(3000);
		instorehome.getHomeEdtSearchtext().click();
		PerfectoUtils.mouseover(instorehome.getHomeLnkMylist());
		mylistPage.getMylistLblListflyout().verifyPresent();
		mylistPage.getMylistLiLnkMouseoverlist().get(0).click();
		mylistPage.waitForPageToLoad();
		mylistPage.getMylistLblDefaultlist().waitForVisible(5000);

		newlistName = ConfigurationManager.getBundle().getString("mylist.newListName");
		System.out.println(newlistName);
		currentlistName = mylistPage.getMylistLblDefaultlist().getText();

		System.out.println(currentlistName);

		if (currentlistName.contains(newlistName))
			PerfectoUtils.reportMessage("New list " + newlistName + " page is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("New list " + newlistName + " page is not displayed", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I Add {0} different items to shopping list")
	public void iAddMoreThan400DifferentItems(int count) {
		InStoreHomePage instorehome = new InStoreHomePage();
		MyListTestPage mylisttestpage = new MyListTestPage();
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();

		PerfectoUtils.mousehoverusingActions(instorehome.getHomeLblShoppinglistfromheader());
		int myAddedListItems = Integer.parseInt(mylisttestpage.getMyShoppingListCount().getText());

		int i = 1;
		if (myAddedListItems < count) {
			for (; Integer.parseInt(mylisttestpage.getMyShoppingListCount().getText()) < count;) {
				int ShoppingListCount = Integer.parseInt(mylisttestpage.getMyShoppingListCount().getText());
				if (mylisttestpage.getLnkViewAllProductResults().isPresent()) {
					PerfectoUtils.scrolltoelement(mylisttestpage.getLnkViewAllProductResults());
					mylisttestpage.getLnkViewAllProductResults().click();
				}
				if (i == 33) {
					i = 1;
					PerfectoUtils.scrolltoelement(mylisttestpage.getLnkNextPage());
					mylisttestpage.getLnkNextPage().click();
				}
				if (mylisttestpage.getAddToList_Product(Integer.toString(i)).isPresent()) {
					PerfectoUtils.scrolltoelement(mylisttestpage.getAddToList_Product(Integer.toString(i)));
					mylisttestpage.getAddToList_Product(Integer.toString(i)).click();
					i++;
				} else {
					PerfectoUtils.scrolltoelement(mylisttestpage.getLnkNextPage());
					mylisttestpage.getLnkNextPage().click();
					PerfectoUtils.scrolltoelement(mylisttestpage.getAddToList_Product(Integer.toString(i)));
					mylisttestpage.getAddToList_Product(Integer.toString(i)).click();
					i++;
				}

				if (ShoppingListCount == 400) {
					try {
						mylisttestpage.getLblExceedError().isDisplayed();
						PerfectoUtils.scrolltoelement(mylisttestpage.getLblExceedError());
						break;
					} catch (Exception e) {
						// ignore..
					}

				}

				mylisttestpage.getTestBase().getDriver().waitForAjax(50000);

				if (mylisttestpage.getMylistBtnMinilistclosewindowbutton().isPresent()) {
					mylisttestpage.getMylistBtnMinilistclosewindowbutton().waitForVisible(50000);
					mylisttestpage.getMylistBtnMinilistclosewindowbutton().click();
				}

				mouseoverMyShoppingList();
			}
			PerfectoUtils.reportMessage(count + " Items added successfully.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(count + " Items are already added", MessageTypes.Pass);
		}

	}

	@QAFTestStep(description = "Mouseover My Shopping List")
	public void mouseoverMyShoppingList() {
		InStoreHomePage instorehome = new InStoreHomePage();
		PerfectoUtils.scrolltoelement(instorehome.getHomeLblShoppinglistfromheader());
		PerfectoUtils.mousehoverusingActions(instorehome.getHomeLblShoppinglistfromheader());
	}

	@QAFTestStep(description = "I Verify the error message is displayed when the user trying to add more than 400 items")
	public void iVerifyErrorMessageDisplayedForMoreThan400Items() {
		MyListTestPage mylisttestpage = new MyListTestPage();

		mylisttestpage.getLblExceedError().waitForVisible(50000);
		mylisttestpage.getLblExceedError().verifyPresent();
		mouseoverMyShoppingList();
		mylisttestpage.getLnkMyList1().click();
		mylisttestpage.getMylistLblMylist().verifyPresent();
		mylisttestpage.getLnkMyList1PdtDelete().click();
		mouseoverMyShoppingList();
		if ((Integer.parseInt(mylisttestpage.getMyShoppingListCount().getText()) == 399)) {
			PerfectoUtils.reportMessage("Deleted 1 product item from the list of 400 different items successfully.",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Unable to delete 1 product item from the list of 400 different items successfully.",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify a user cannot add more than 400 items via product catalog, weekly ad, coupons, recipes or primo pick pages")
	public void iVerifyUserCannotAddMoreThan400Items() {
		MyListTestPage mylisttestpage = new MyListTestPage();
		CouponsProductsTestPage coupons = new CouponsProductsTestPage();
		RecipelandingTestPage recipe = new RecipelandingTestPage();
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();
		WeeklyAdsStepDef weeklyAdSteps = new WeeklyAdsStepDef();

		mouseoverMyShoppingList();
		mylisttestpage.getLnkMyList1().click();
		mylisttestpage.getMylistLblMylist().verifyPresent();
		mylisttestpage.getMylistLblWeeklyad().click();
		weeklyAdSteps.navigateToWeeklyAdGridViewPage();
		weeklyAdSteps.selectAddToListFromWeeklyAdsDealsPage();
		// PerfectoUtils.scrolltoelement(weeklyAd.getWklyadLnkAddtolist());
		// weeklyAd.getWklyadLnkAddtolist().click();
		mylisttestpage.getLblExceedError().waitForVisible(50000);
		PerfectoUtils.scrolltoelement(mylisttestpage.getLblExceedError());
		mylisttestpage.getLblExceedError().verifyPresent();

		mouseoverMyShoppingList();
		mylisttestpage.getLnkMyList1().click();
		mylisttestpage.getMylistLblMylist().verifyPresent();
		mylisttestpage.getMylistLblCoupons().click();
		PerfectoUtils.scrolltoelement(coupons.getRbtnAddtoList());
		coupons.getRbtnAddtoList().click();
		mylisttestpage.getLblExceedError().waitForVisible(50000);
		mylisttestpage.getLblExceedError().verifyPresent();

		mouseoverMyShoppingList();
		mylisttestpage.getLnkMyList1().click();
		mylisttestpage.getMylistLblMylist().verifyPresent();
		mylisttestpage.getMylistLblRecipe().click();
		PerfectoUtils.scrolltoelement(recipe.getRecipeLblFirstrecipeaddtolist());
		recipe.getRecipeLblFirstrecipeaddtolist().click();
		recipedetail.getRecipedetailBtnCheckall().waitForPresent(20000);
		recipedetail.getRecipedetailBtnCheckall().verifyPresent();
		recipedetail.getRecipedetailGetChkChkbox("1").click();
		recipedetail.getRecipedetailBtnAddtolist().click();
		mylisttestpage.getLblExceedError().waitForVisible(50000);
		mylisttestpage.getLblExceedError().verifyPresent();

		mouseoverMyShoppingList();
		mylisttestpage.getLnkMyList1().click();
		mylisttestpage.getMylistLblMylist().verifyPresent();
		mylisttestpage.getMylistLblPrimopick().click();
		PerfectoUtils.scrolltoelement(coupons.getRbtnAddtoList());
		coupons.getRbtnAddtoList().click();
		iVerifyErrorMessageDisplayedForMoreThan400Items();
	}

	@QAFTestStep(description = "I verify user can print a list with 400 items")
	public void iVerifyUserCanPrintListWith400Items() {
		MyListTestPage mylisttestpage = new MyListTestPage();

		mouseoverMyShoppingList();
		mylisttestpage.getLnkMyList1().click();
		mylisttestpage.getMylistLblMylist().verifyPresent();
		PerfectoUtils.scrolltoelement(mylisttestpage.getLnkPrint());
		mylisttestpage.getLnkPrint().verifyPresent();
		mylisttestpage.getLnkPrint().click();
		mylisttestpage.getLblLikeToPrint().waitForPresent(50000);
		mylisttestpage.getLblLikeToPrint().verifyPresent();
		mylisttestpage.getBtnPrint().verifyPresent();
		mylisttestpage.getLnkClose().click();
		mylisttestpage.getLnkMyList1PdtDelete().click();
		mouseoverMyShoppingList();
		if ((Integer.parseInt(mylisttestpage.getMyShoppingListCount().getText()) == 399)) {
			PerfectoUtils.reportMessage("Deleted 1 product item from the list of 400 different items successfully.",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Unable to delete 1 product item from the list of 400 different items successfully.",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I click weeklyad and select a store from select a store pop up")
	public void iClickWeeklyadAndSelectAStoreFromSelectAStorePopUp() {
		MyListTestPage mylisttestpage = new MyListTestPage();
		WeeklyadprintversionTestPage weeklyadprint = new WeeklyadprintversionTestPage();
		SelectStoreTestPage selectstore = new SelectStoreTestPage();

		PerfectoUtils.scrolltoelement(mylisttestpage.getMylistLblWeeklyad());
		mylisttestpage.getMylistLblWeeklyad().verifyPresent();
		mylisttestpage.getMylistLblWeeklyad().click();
		weeklyadprint.waitForPageToLoad();

		selectstore.getSelstoreTxtZipcode().waitForPresent(5000);
		selectstore.getSelstoreTxtZipcode().clear();
		selectstore.getSelstoreTxtZipcode().click();
		selectstore.getSelstoreTxtZipcode().sendKeys("78258");
		selectstore.getSelstoreBtnGo().click();
		selectstore.waitForAjaxToComplete();
		selectstore.getSelstoreGetBtnStoreselectwithstoreid("108").waitForPresent(5000);
		selectstore.getSelstoreGetBtnStoreselectwithstoreid("108").click();

		weeklyadprint.waitForPageToLoad();
		selectstore.waitForAjaxToComplete();
		if (weeklyadprint.getLblPageheader().getText().trim().equalsIgnoreCase("weekly ads"))
			PerfectoUtils.reportMessage("Weekly Ad Page is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Weekly Ad Page is not displayed", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify all my list items are loaded in My Lists page")
	public void verifyAllMyListItemsAreLoadedInMyListsPage() {
		MyListTestPage mylist = new MyListTestPage();

		mylist.waitForPageToLoad();
		mylist.waitForAjaxToComplete();
		mylist.getMylistLblAllmylistitems().waitForPresent(5000);
		mylist.getMylistLblAllmylistitems().verifyPresent();
		int initialCount = mylist.getMylistLiBoxAllmylistitems().size();

		if (initialCount > 0) {
			PerfectoUtils.reportMessage("Available All my list items are " + initialCount, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("All my list items are not available", MessageTypes.Fail);
		}

		ConfigurationManager.getBundle().setProperty("initialCount", initialCount);
	}

	@QAFTestStep(description = "Verify {0} more items are loaded in My Lists page")
	public void verifyMoreItemsAreLoadedInMyListsPage(int increaseCount) {
		MyListTestPage mylist = new MyListTestPage();

		mylist.waitForAjaxToComplete();
		mylist.waitForPageToLoad();
		int initialCount = getBundle().getInt("initialCount");
		mylist.getMylistLiBoxAllmylistitems().get(initialCount + increaseCount - 1).waitForPresent(50000);
		int updatedCount = mylist.getMylistLiBoxAllmylistitems().size();

		if ((initialCount + increaseCount) == updatedCount) {
			PerfectoUtils.reportMessage(
					"All My list items Count is increased by " + increaseCount + ". Total Count: " + updatedCount,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"All My list items count is not increased by " + increaseCount + ". Total Count: " + updatedCount,
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Click on Watch the how-to-video link")
	public void clickOnWatchTheHowToVideoLink() {
		MyListTestPage mylist = new MyListTestPage();

		mylist.getLnkWatchthehowtovideo().waitForPresent(5000);
		mylist.getLnkWatchthehowtovideo().click();
		PerfectoUtils.reportMessage("Clicked on Watch the how-to-video link", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify the system expands the video section")
	public void verifyTheSystemExpandsTheVideoSection() {
		MyListTestPage mylist = new MyListTestPage();

		mylist.getImgWatchthehowtovideoexpandedsection().waitForPresent(5000);

		if (mylist.getImgWatchthehowtovideoexpandedsection().isPresent())
			PerfectoUtils.reportMessage("System expands the video section..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("System doesn't expands the video section..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Enter a valid receipt number in the text box and press add to list button")
	public void enterAValidReceiptNumberInTheTextBoxAndPressAddToListButton() {
		MyListTestPage mylist = new MyListTestPage();

		String validReceiptNumber = getBundle().getString("mylist.receiptID");

		mylist.getMylistTxtReceiptadd().waitForPresent(5000);
		mylist.getMylistTxtReceiptadd().sendKeys(validReceiptNumber);
		PerfectoUtils.reportMessage("Entered Valid receipt number", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Validate the Shopping list banner")
	public void validateTheShoppingListBanner() {
		MyListTestPage mylisttestpage = new MyListTestPage();
		String expBanner = getBundle().getString("mylist.banner");

		mylisttestpage.getMylistLblBanner().waitForPresent(5000);
		mylisttestpage.getMylistLblBanner().verifyText(expBanner);
		mylisttestpage.getMylistLnkBannerclose().click();
		mylisttestpage.waitForAjaxToComplete();
		mylisttestpage.getMylistLnkBannerclose().verifyNotPresent();
	}

	@QAFTestStep(description = "Verify the receipts got added successfully")
	public void verifyTheReceiptsGotAddedSuccessfully() {
		MyListTestPage mylist = new MyListTestPage();

		mylist.getLblTotalitemcount().waitForPresent(5000);

		int totalItemCount = Integer.parseInt(mylist.getLblTotalitemcount().getText());

		if (totalItemCount > 0)
			PerfectoUtils.reportMessage("Receipts added successfully..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Receipts not added..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify the Last Updated on timestamp displays below each list name")
	public void verifyTheLastUpdatedOnTimestampDisplaysBelowEachListName() {
		MyListTestPage mylist = new MyListTestPage();

		int i = 1;
		boolean isNotPresent = false;

		for (ManageListsBlocks ele : mylist.getLiManagelistblocks()) {
			if (!ele.getLiManageliststimestamp().isPresent()) {
				isNotPresent = true;
				PerfectoUtils.reportMessage(
						"Last Updated timestamp not available for the list name under manage lists section-" + i,
						MessageTypes.Fail);
			}
			i++;
		}
		PerfectoUtils.reportMessage("Clicked on Watch the how-to-video link", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Select checkboxes of multiple lists")
	public void selectCheckboxesOfMultipleLists() {
		MyListTestPage mylist = new MyListTestPage();

		mylist.getLiManagelistscheckboxes().get(0).waitForPresent(3000);
		mylist.getLiManagelistscheckboxes().get(0).click();
		PerfectoUtils.reportMessage("Clicked on Checkbox1..", MessageTypes.Pass);

		mylist.getLiManagelistscheckboxes().get(1).click();
		PerfectoUtils.reportMessage("Clicked on Checkbox2..", MessageTypes.Pass);

	}

	@QAFTestStep(description = "Click on Save a copy button")
	public void clickOnSaveACopyButton() {
		MyListTestPage mylist = new MyListTestPage();

		mylist.getMylistBtnSaveacopy().waitForPresent(5000);
		mylist.getMylistBtnSaveacopy().click();
		PerfectoUtils.reportMessage("Clicked on Save a Copy button..", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify the error message You can only select one Shopping List to copy")
	public void verifyTheErrorMessageYouCanOnlySelectOneShoppingListToCopy() {
		MyListTestPage mylist = new MyListTestPage();

		mylist.getLblManagelistsaveacopyerrormessage().waitForPresent(5000);

		if (mylist.getLblManagelistsaveacopyerrormessage().isPresent())
			PerfectoUtils.reportMessage("Error message found..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Error message not found..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify the Product disclaimer and last update values")
	public void verifyTheProductDisclaimerAndLastUpdateValues() {
		MyListTestPage mylist = new MyListTestPage();

		mylist.getLblItemsinyourlist().waitForPresent(5000);
		mylist.getLblItemsinyourlist().verifyPresent();
		mylist.getLnkPrint().verifyPresent();
		mylist.getIconEmail().verifyPresent();
		mylist.getBtnSavecurrentlistsection().verifyPresent();
		mylist.getLblShoppingtimestamp().verifyPresent();
	}

	@QAFTestStep(description = "I validate the added recipe ingredients in shopping list page")
	public void iValidateTheAddedRecipeIngredientsInShoppingListPage() {
		MyListTestPage mylisttestpage = new MyListTestPage();
		int expIngListSize = getBundle().getInt("ingList");
		List<String> expIngList = getBundle().getList("strIngList");
		List<String> actIngList = new ArrayList<String>();
		boolean isAllAvail = false;

		mylisttestpage.getLiBoxListitems().get(0).verifyPresent();
		for (QAFWebElement items : mylisttestpage.getLiLblItemrecipeingredients()) {
			actIngList.add(items.getText().trim());
		}
		if (mylisttestpage.getLiBoxListitems().size() == expIngListSize) {
			for (String expStr : expIngList) {
				for (String actStr : actIngList) {
					if (actStr.contains(expStr))
						isAllAvail = true;
					else {
						isAllAvail = false;
						break;
					}
				}
			}
		}

		if (isAllAvail) {
			PerfectoUtils.reportMessage("All added ingredients are available", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("All added ingredients are not available", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I mouseover on My Shopping list in the header and validate the default My List")
	public void iMouseoverOnMyShoppingListInTheHeaderAndValidateTheDefaultMyList() {
		InStoreHomePage instorehome = new InStoreHomePage();
		MyListTestPage mylisttestpage = new MyListTestPage();

		PerfectoUtils.mouseover(instorehome.getHomeLblShoppinglistfromheader());
		mylisttestpage.getMylistLiLnkMouseoverlist().get(0).verifyPresent();
		;

		if (mylisttestpage.getMylistLiLnkMouseoverlist().size() == 1) {
			mylisttestpage.getMylistLiLnkMouseoverlist().get(0).verifyText("My List");
			PerfectoUtils.reportMessage("Cold user's default list is verified as My List", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cold user's default list is wrngly displayed", MessageTypes.Fail);
		}

		mylisttestpage.getMyShoppingListCount().verifyText("0");

	}
}
