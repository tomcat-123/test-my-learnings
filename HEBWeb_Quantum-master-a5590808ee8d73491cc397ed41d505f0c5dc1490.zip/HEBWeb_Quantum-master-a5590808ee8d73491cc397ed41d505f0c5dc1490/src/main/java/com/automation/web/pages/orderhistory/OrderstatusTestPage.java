package com.automation.web.pages.orderhistory;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class OrderstatusTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "orderstatus.lbl.header")
	private QAFWebElement orderstatusLblHeader;

	@FindBy(locator = "orderstatus.lbl.orderConfirNum")
	private QAFWebElement orderstatusLblOrderConfirNum;

	@FindBy(locator = "orderstatus.edt.orderConfirNum")
	private QAFWebElement orderstatusEdtOrderConfirNum;

	@FindBy(locator = "orderstatus.lbl.emailaddress")
	private QAFWebElement orderstatusLblEmailaddress;

	@FindBy(locator = "orderstatus.edt.emailaddress")
	private QAFWebElement orderstatusEdtEmailaddress;

	@FindBy(locator = "orderstatus.lnk.whereismyorderconfi")
	private QAFWebElement orderstatusLnkWhereismyorderconfi;

	@FindBy(locator = "orderstatus.btn.submit")
	private QAFWebElement orderstatusBtnSubmit;

	@FindBy(locator = "orderstatus.lnk.cancel")
	private QAFWebElement orderstatusLnkCancel;

	@FindBy(locator = "orderstatus.lbl.breadcrumb")
	private QAFWebElement orderstatusLblBreadcrumb;
	
	@FindBy(locator = "orderstatus.lbl.orderconfirmationmandatorystar")
	private QAFWebElement orderstatusLblOrderConfirmationMandatoryStar;

	/**
	 * Textview for Order status
	 */
	public QAFWebElement getOrderstatusLblHeader(){ return orderstatusLblHeader; }

	/**
	 * Textview for Order confirmation number
	 */
	public QAFWebElement getOrderstatusLblOrderConfirNum(){ return orderstatusLblOrderConfirNum; }

	/**
	 * EditTextview for Order confirmation number
	 */
	public QAFWebElement getOrderstatusEdtOrderConfirNum(){ return orderstatusEdtOrderConfirNum; }

	/**
	 * Textview for email address
	 */
	public QAFWebElement getOrderstatusLblEmailaddress(){ return orderstatusLblEmailaddress; }

	/**
	 * EditTextview for email address
	 */
	public QAFWebElement getOrderstatusEdtEmailaddress(){ return orderstatusEdtEmailaddress; }

	/**
	 * Linkview for Where is my order confirmation number
	 */
	public QAFWebElement getOrderstatusLnkWhereismyorderconfi(){ return orderstatusLnkWhereismyorderconfi; }

	/**
	 * Buttonview for Submit
	 */
	public QAFWebElement getOrderstatusBtnSubmit(){ return orderstatusBtnSubmit; }

	/**
	 * Linkview for Cancel
	 */
	public QAFWebElement getOrderstatusLnkCancel(){ return orderstatusLnkCancel; }

	/**
	 * Textview for Breadcrumb Check order status
	 */
	public QAFWebElement getOrderstatusLblBreadcrumb(){ return orderstatusLblBreadcrumb; }
	
	public QAFWebElement getOrderstatusLblOrderConfirmationMandatoryStar(){ return orderstatusLblOrderConfirmationMandatoryStar; }

}