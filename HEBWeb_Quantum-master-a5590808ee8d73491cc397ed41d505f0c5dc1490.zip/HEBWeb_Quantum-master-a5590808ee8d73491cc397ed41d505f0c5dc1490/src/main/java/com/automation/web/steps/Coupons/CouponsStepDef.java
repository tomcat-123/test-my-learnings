package com.automation.web.steps.Coupons;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Point;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.components.coupons.CouponProductBlocks;
import com.automation.web.components.coupons.DigitalCouponBlocks;
import com.automation.web.components.coupons.DigitalCouponBlocksInSelectedSection;
import com.automation.web.components.coupons.PrintableCouponBlocks;
import com.automation.web.pages.coupons.CouponsOverlayTestPage;
import com.automation.web.pages.coupons.CouponsProductsTestPage;
import com.automation.web.pages.coupons.CouponsTestPage;
import com.automation.web.pages.coupons.DigitalCouponsLoginPopupTestPage;
import com.automation.web.pages.coupons.DigitalCouponsSelectedSectionTestPage;
import com.automation.web.pages.coupons.DigitalCouponsTestPage;
import com.automation.web.pages.coupons.PrintTestPage;
import com.automation.web.pages.coupons.PrintableCouponsTestPage;
import com.automation.web.pages.homepage.FrontdoorTestPage;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.login.LoginTestPage;
import com.automation.web.pages.myAccount.TaxExemptionTestPage;
import com.automation.web.pages.myList.MyListTestPage;
import com.automation.web.pages.registration.ThankYouTestPage;
import com.automation.web.pages.weeklyads.MiniListTestPage;
import com.automation.web.pages.weeklyads.WeeklyAdsAndCouponsPage;
import com.automation.web.steps.myaccount.myaccountpage;
import com.automation.web.steps.weeklyads.WeeklyAdsStepDef;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of steps in CouponsStepDef

* Select View Digital Coupons option
* I Should see the Digital Coupons page
* Select More option for any available coupon
* I should see the Coupons Description Overlay popup
* Verify the Coupons Description Overlay aligned properly
* I navigate to coupon page from New Home Page
* I verify the coupons page is displayed
* I navigate to coupon page from Explore HEB page
* I navigate to coupons page by searching coupons
* I navigate to digital coupon page using view digital coupon button
* I navigate using Learn more about Digital Coupons link
* Validate Sign up in coupon selection page
* Validate Sign up in digital coupon landing page
* I verify the digital coupons landing page is displayed
* I navigate to Digital Coupons page from coupons page
* Verify navigated to Weekly ads and coupons landing page
* Click on See and print coupons from Weekly Ads and coupons page
* Verify navigated to Printable coupons page
* Click on View printable coupons from Coupons page
* Verify the properties of Coupons page
* Verify the properties of Digital coupons page
* Verify the properties of Printable coupons page
* Click on Login button from Digital Coupons page
* Enter valid credentials and click login button from login page
* I Should see the Digital Coupons page for hotuser
* Click on Sign Up button from Digital Coupons page
* Select Show Digital Coupons option from the Thanks for register popup
* Validate the category list in left navigation
* Select any category from the left navigation options
* Verify the Coupons getting listed based on the category selected
* Validate the Sort coupons by Newest
* Validate the Sort coupons by Highest Value
* Validate the Sort coupons by Expiration Date
* Validate the Sort coupons by Populatity
* Validate the Search option in Digital coupons page
* Validate the properties of Digital Coupons Display tile
* Click on Select button for any available coupon
* Verify the user navigated to Login page
* Verify the Digital Coupons page as a hotuser
* Verify the properties of Coupons Overlay popup
* Verify the button becomes Selected after selecting it
* Verify the Selected Coupons count is updated after selecting the coupon
* Navigate to Selected Coupons section from Digital coupons page
* Verify the Selected Coupons is available under Selected Coupons
* Click and navigate to In My Store view from Coupon Products page
* Verify the Coupons list in Coupon Products page from In MyStore View
* Click and navigate to Sold Online view from Coupon Products page
* Verify the Coupons list in Coupon Products page from Sold Online View
* Verify the Coupons list in Coupon Products page from Ship to home View
* Verify coupons are loaded in digital coupons landing page
* Verify Load More Items is not displayed while scrolling to the bottom of the page
* Verify {0} more coupons are loaded
* Verify the Coupons Avilable and Selected count after selecting it
* Verify the Avilable and Selected Coupon savings
* Verify the Select button becomes Selected after selecting {0} th coupon
* Click on Select button for {0} th available coupon
* Validate the page does not jump around from {0} th coupon
* Verify the Select button becomes Selected after selecting {0} th coupon from more popup
* Select More option for {0} th available coupon and Select Coupon
* Verify all links landing page
* Validate user can see more than {0} email exclusive coupons
* Validate user can search {0} coupons
* I verify the modal window pop
* I verify all tabs available in Digital Coupons page
* I verify all tabs available in Digital Coupons page for hot user
* Verify the button turned into Selected and Grayed out
* Select Details option for any available coupon
* Click on Select button from the Coupons overlay popup
* Click on Close button from the Coupons overlay popup
* Verify the Coupons overlay popup got closed
* Select checkbox for any available coupon in selected section
* Select anywhere in any available coupon in selected section
* Verify the Add to list button got enabled
* Select Add to list button from Selected section
* Verify the Add to list button got disabled
* Verify the Add to list button is grayed out
* Verify the Add to list button turns to blue
* Try to click Add to list button
* Verify the user not able to add the coupons to list
* Click on Login in Digtal Coupons modal window
* I verify the window popup closes out when clicking on browse as Guest User
* I verify Coupons page banner and validate learn more link navigation
* I validate coupons results count and category displays in Total Available tab
* Select Create one option from Login page
* Click on Print Page option from Selected section
* Verify navigated to Print page
* Verify the properties of My Selected section
* Click on Register in Digtal Coupons modal window
* I validate coupons results count and category displays in My Selected tab
* Validate coupons search results when searching for a coupon {0}
* Validate the selected coupon is available in My Selected tab
* Clear the search and validate default Total Available coupons are loaded
* Validate Coupons sort by options {0} in Total Available tab
* Validate Coupons sort by options {0} in My Selected tab
* Verify the slowness is not occurred past {0} coupons loaded
* I close mini list
* I verify whether the same coupons are not added to list again

*/

public class CouponsStepDef {

	@QAFTestStep(description = "Select View Digital Coupons option")
	public static void selectViewDigitalCouponsOption() {
		CouponsTestPage couponslanding = new CouponsTestPage();

		couponslanding.getBtnViewdigcoupons().waitForPresent(1000);
		couponslanding.getBtnViewdigcoupons().click();
	}

	@QAFTestStep(description = "I Should see the Digital Coupons page")
	public static void iShouldSeeTheDigitalCouponsPage() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getLblDigcouponsheader().waitForPresent(1000);
		if (dc.getLblDigcouponsheader().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Digital Coupons page..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Digital Coupons page..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Select More option for any available coupon")
	public void selectMoreOptionForAnyAvailableCoupon() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		int MoreListSize = dc.getLiCouponblocks().size();

		if (MoreListSize > 0) {
			PerfectoUtils.reportMessage(MoreListSize + " Coupons found..");
			PerfectoUtils.scrolltoelement(dc.getLiCouponblocks().get(0).getLblCouponblockmorelist());
			dc.getLiCouponblocks().get(0).getLblCouponblockmorelist().click();
		} else {
			PerfectoUtils.reportMessage("No Coupons found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I should see the Coupons Description Overlay popup")
	public void iShouldSeeTheCouponsDescriptionOverlayPopup() {
		CouponsOverlayTestPage couponsoverlay = new CouponsOverlayTestPage();

		couponsoverlay.getLblCouponname().waitForPresent(3000);
		if (couponsoverlay.getLblCouponname().isPresent()) {
			PerfectoUtils.reportMessage("Coupons overlay popup found..");
		} else {
			PerfectoUtils.reportMessage("Coupons overlay popup found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Coupons Description Overlay aligned properly")
	public void verifyTheCouponsDescriptionOverlayAlignedProperly() {
		CouponsOverlayTestPage couponsoverlay = new CouponsOverlayTestPage();

		couponsoverlay.getBtnSelect().verifyPresent();
		couponsoverlay.getImgTwitter().verifyPresent();
		couponsoverlay.getImgSendemail().verifyPresent();
	}

	@QAFTestStep(description = "I navigate to coupon page from New Home Page")
	public void iNavigateToCouponPageFromNewHomePage() {
		FrontdoorTestPage frontDoor = new FrontdoorTestPage();

		PerfectoUtils.scrolltoelement(frontDoor.getFrontImgCoupons());
		frontDoor.getFrontImgCoupons().verifyPresent();
		frontDoor.getFrontImgCoupons().click();
		PerfectoUtils.reportMessage("Clicked Coupons link from home...");

	}

	@QAFTestStep(description = "I verify the coupons page is displayed")
	public void iVerifyTheDigitalCouponsPageIsDisplayed() {
		CouponsTestPage couponsPage = new CouponsTestPage();
		FrontdoorTestPage front = new FrontdoorTestPage();
		
		couponsPage.getLblCouponsheader().verifyPresent();
		front.getFrontImgFav().verifyPresent();
		if (couponsPage.getLblCouponsheader().isPresent())
			PerfectoUtils.reportMessage("Navigated to Coupons page..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not navigated to Coupons page..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I navigate to coupon page from Explore HEB page")
	public void iNavigateToCouponPageFromExploreHEBPage() {
		InStoreHomePage instorehomepahe = new InStoreHomePage();

		instorehomepahe.getHomeLblDigitalcoupons().verifyPresent();
		instorehomepahe.getHomeLblDigitalcoupons().click();
		PerfectoUtils.reportMessage("Clicked Digital Coupons banner from Explore HEB page...");

	}

	@QAFTestStep(description = "I navigate to coupons page by searching coupons")
	public void iNavigateToCouponsPageBySearchingCoupons() {
		InStoreHomePage instorehomepahe = new InStoreHomePage();

		instorehomepahe.getHomeEdtSearchtext().verifyPresent();
		instorehomepahe.getHomeEdtSearchtext().sendKeys("coupons");
		instorehomepahe.getHomeBtnSearch().click();
		PerfectoUtils.reportMessage("Clicked Search icon after entering coupons in search field...");

	}

	@QAFTestStep(description = "I navigate to digital coupon page using view digital coupon button")
	public void iNavigateToDigitalCouponUsingViewDigitalCouponsButton() {
		WeeklyAdsAndCouponsPage wklyadsandcoupons = new WeeklyAdsAndCouponsPage();

		wklyadsandcoupons.getBtnViewdigitalcoupons().waitForPresent(5000);
		wklyadsandcoupons.getBtnViewdigitalcoupons().verifyPresent();
		wklyadsandcoupons.getBtnViewdigitalcoupons().click();
		PerfectoUtils.reportMessage("Clicked View digital coupons button...");

	}

	@QAFTestStep(description = "I navigate using Learn more about Digital Coupons link")
	public void iNavigateUsingLearnmoreaboutDigitalCouponsLink() {
		WeeklyAdsAndCouponsPage wklyadsandcoupons = new WeeklyAdsAndCouponsPage();

		wklyadsandcoupons.getLnkLearnMoreaboutDigitalcoupons().waitForPresent(5000);
		wklyadsandcoupons.getLnkLearnMoreaboutDigitalcoupons().verifyPresent();
		wklyadsandcoupons.getLnkLearnMoreaboutDigitalcoupons().click();
		PerfectoUtils.reportMessage("Clicked Learn More about digital coupons button...");

	}

	@QAFTestStep(description = "Validate Sign up in coupon selection page")
	public void iValidateSignUpinCouponSelectionPage() {
		WeeklyAdsAndCouponsPage wklyadsandcoupons = new WeeklyAdsAndCouponsPage();
		LoginTestPage login = new LoginTestPage();

		wklyadsandcoupons.getLnkLoginunderDigitalbanner().waitForPresent(5000);
		wklyadsandcoupons.getLnkLoginunderDigitalbanner().verifyPresent();
		wklyadsandcoupons.getLnkLoginunderDigitalbanner().click();
		PerfectoUtils.reportMessage("Clicked Login under Digital banner...");
		login.getLoginLnkCreateOne().click();
		String actualCurrentURL = PerfectoUtils.getDriver().getCurrentUrl();
		if (actualCurrentURL.contains(ConfigurationManager.getBundle().getString("digitalcoupons.registerURL")))
			PerfectoUtils.reportMessage("Navigated to Register page..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not navigated to Register page..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Validate Sign up in digital coupon landing page")
	public void iValidateSignUpinDigitalCouponLandingPage() {
		WeeklyAdsAndCouponsPage wklyadsandcoupons = new WeeklyAdsAndCouponsPage();

		wklyadsandcoupons.getLnkSignUpNow().waitForPresent(5000);
		wklyadsandcoupons.getLnkSignUpNow().verifyPresent();
		wklyadsandcoupons.getLnkSignUpNow().click();
		PerfectoUtils.reportMessage("Clicked Sign Up Now...");
		String actualCurrentURL = PerfectoUtils.getDriver().getCurrentUrl();
		if (actualCurrentURL.contains(ConfigurationManager.getBundle().getString("digitalcoupons.registerURL")))
			PerfectoUtils.reportMessage("Navigated to Register page..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not navigated to Register page..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I verify the digital coupons landing page is displayed")
	public void iVerifyTheDigitalCouponsLandingPageIsDisplayed() {
		DigitalCouponsTestPage digcoupons = new DigitalCouponsTestPage();

		digcoupons.getLblDigcouponsheader().verifyPresent();
		if (digcoupons.getLblDigcouponsheader().isPresent())
			PerfectoUtils.reportMessage("Navigated to Digital Coupons landing page..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not navigated to Digital Coupons landing page..", MessageTypes.Fail);

	}
	
	@QAFTestStep(description = "I verify breadcrumb in the digital coupons landing page")
	public void iVerifyBreadcrumbintheDigitalCouponsLandingPage() {
		DigitalCouponsTestPage digcoupons = new DigitalCouponsTestPage();
		TaxExemptionTestPage breadcrump = new TaxExemptionTestPage();
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		digcoupons.getLblDigcouponsheader().verifyPresent();
		if (digcoupons.getLblDigcouponsheader().isPresent())
			PerfectoUtils.reportMessage("Navigated to Digital Coupons landing page..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not navigated to Digital Coupons landing page..", MessageTypes.Fail);
		
		breadcrump.getTaxExemptionLnkDigitalCouponsBreadcrumb().verifyPresent();
		breadcrump.getTaxExemptionLnkCouponsBreadcrumb().verifyPresent();
		breadcrump.getTaxExemptionLnkHomebreadcrumb().verifyPresent();
		
		breadcrump.getTaxExemptionLnkCouponsBreadcrumb().click();
		iNavigateToCouponPageFromExploreHEBPage();
		breadcrump.getTaxExemptionLnkHomebreadcrumb().click();
		frontdoor.getFrontImgExploremystore().verifyPresent();
		frontdoor.getFrontLblExploremystore().click();
	}
	
	@QAFTestStep(description = "I verify breadcrumb in the printable coupons landing page")
	public void iVerifyBreadcrumbinthePrintableCouponsLandingPage() {
		PrintableCouponsTestPage printablecoupons = new PrintableCouponsTestPage();
		TaxExemptionTestPage breadcrump = new TaxExemptionTestPage();
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		printablecoupons.getLblPrintablecouponsheader().waitForPresent(10000);
		if (printablecoupons.getLblPrintablecouponsheader().isPresent())
			PerfectoUtils.reportMessage("Navigated to Printable coupons page..");
		else
			PerfectoUtils.reportMessage("Error occured while navigating to Printable coupons page..",
					MessageTypes.Fail);
		
		breadcrump.getTaxExemptionLnkPrintableCouponsBreadcrumb().verifyPresent();
		breadcrump.getTaxExemptionLnkCouponsBreadcrumb().verifyPresent();
		breadcrump.getTaxExemptionLnkHomebreadcrumb().verifyPresent();
		
		breadcrump.getTaxExemptionLnkCouponsBreadcrumb().click();
		clickOnViewPrintableCouponsFromCouponsPage();
		breadcrump.getTaxExemptionLnkHomebreadcrumb().click();
		frontdoor.getFrontImgExploremystore().verifyPresent();
		frontdoor.getFrontLblExploremystore().click();
	}

	@QAFTestStep(description = "I navigate to Digital Coupons page from coupons page")
	public void iNavigateToDigitalCouponsPageFromCouponsPage() {
		CouponsTestPage coupons = new CouponsTestPage();

		coupons.getBtnViewdigcoupons().verifyPresent();
		coupons.getBtnViewdigcoupons().click();
		PerfectoUtils.reportMessage("Clicked View coupons button...");

	}

	@QAFTestStep(description = "Verify navigated to Weekly ads and coupons landing page")
	public void verifyNavigatedToWeeklyAdsAndCouponsLandingPage() {
		WeeklyAdsAndCouponsPage wklyadsandcoupons = new WeeklyAdsAndCouponsPage();

		wklyadsandcoupons.getLblPageheader().verifyPresent();
		if (wklyadsandcoupons.getLblPageheader().isPresent())
			PerfectoUtils.reportMessage(" Weekly ads and coupons landing page is displayed...");
		else
			PerfectoUtils.reportMessage(" Weekly ads and coupons landing page is not displayed...", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Click on See and print coupons from Weekly Ads and coupons page")
	public void clickOnSeeAndPrintCouponsFromWeeklyAdsAndCouponsPage() {
		CouponsTestPage coupons = new CouponsTestPage();

		coupons.getBtnViewprintablecoupons().waitForPresent(3000);
		coupons.getBtnViewprintablecoupons().click();
		PerfectoUtils.reportMessage("Clicked on View Coupons button..");
	}

	@QAFTestStep(description = "Verify navigated to Printable coupons page")
	public void verifyNavigatedToPrintableCouponsPage() {
		PrintableCouponsTestPage printablecoupons = new PrintableCouponsTestPage();

		printablecoupons.getLblPrintablecouponsheader().waitForPresent(10000);
		if (printablecoupons.getLblPrintablecouponsheader().isPresent())
			PerfectoUtils.reportMessage("Navigated to Printable coupons page..");
		else
			PerfectoUtils.reportMessage("Error occured while navigating to Printable coupons page..",
					MessageTypes.Fail);
	}

	@QAFTestStep(description = "Click on View printable coupons from Coupons page")
	public void clickOnViewPrintableCouponsFromCouponsPage() {
		CouponsTestPage coupons = new CouponsTestPage();

		coupons.getBtnViewprintablecoupons().waitForPresent(10000);
		coupons.getBtnViewprintablecoupons().click();
		PerfectoUtils.reportMessage("Clicked on Clip Coupons..");
	}

	@QAFTestStep(description = "Verify the properties of Coupons page")
	public void verifyThePropertiesOfCouponsPage() {
		CouponsTestPage coupons = new CouponsTestPage();

		coupons.getLblCouponsheader().verifyPresent();
		PerfectoUtils.scrolltoelement(coupons.getLblCouponsheader());
		coupons.getLblDigcoupons().verifyPresent();
		coupons.getLblPrintablecoupons().verifyPresent();
		coupons.getBtnViewdigcoupons().verifyPresent();
		coupons.getBtnViewprintablecoupons().verifyPresent();
		coupons.getLnkViewcouponpolicy().verifyPresent();
		coupons.getBtnViewdigcoupons().click();
		coupons.getLnkDigcouponslearnmore().verifyPresent();
	}

	@QAFTestStep(description = "Verify the properties of Digital coupons page")
	public void verifyThePropertiesOfDigitalCouponsPage() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getLblDigcouponsheader().verifyPresent();
		dc.getLnkLearnmore().verifyPresent();
		dc.getLblAvailablesection().verifyPresent();
		dc.getLblSelectedsection().verifyPresent();
		dc.getLblSavingtoDateSection().verifyPresent();
		dc.getLnkMyselectedLogin().verifyPresent();
		dc.getLnkSavingtodateLogin().verifyPresent();

		dc.getTxtSearchcoupons().verifyPresent();
		PerfectoUtils.scrolltoelement(dc.getTxtSearchcoupons());
		dc.getBtnSearchicon().verifyPresent();
		dc.getLblSortby().verifyPresent();

		int sortbyOptionsSize = dc.getLiSortoptions().size();
		if (sortbyOptionsSize > 0) {
			PerfectoUtils.reportMessage(sortbyOptionsSize + "Sort options found in the Sort by dropdown..");
		} else {
			PerfectoUtils.reportMessage("No Sort options found in the Sort by dropdown");
		}

		dc.getLblCouponsresult().verifyPresent();

		int availableCouponsblocksSize = dc.getLiCouponblocks().size();
		if (availableCouponsblocksSize > 0) {
			PerfectoUtils.reportMessage(availableCouponsblocksSize + " Coupons found..");

			for (DigitalCouponBlocks ele : dc.getLiCouponblocks()) {
				ele.getImgCouponblockimageslist().verifyPresent();
				ele.getLblCouponblockdescriptionslist().verifyPresent();
				ele.getLblCouponblockmorelist().verifyPresent();
				ele.getLblCouponblocklimitdeslist().verifyPresent();
				ele.getLblCouponblockexpirydatelist().verifyPresent();
				ele.getBtnCouponblockselectlist().verifyPresent();
				break;
			}
		} else {
			PerfectoUtils.reportMessage("No Coupons available....", MessageTypes.Fail);
		}

		dc.getLblLoadmoreitems().verifyNotPresent();
	}

	@QAFTestStep(description = "Verify the properties of Printable coupons page")
	public void verifyThePropertiesOfPrintableCouponsPage() {
		PrintableCouponsTestPage pc = new PrintableCouponsTestPage();

		pc.getLblPrintablecouponsheader().verifyPresent();
		PerfectoUtils.scrolltoelement(pc.getLblPrintablecouponsheader());

		pc.getLblCategories().verifyPresent();
		int categoriesListSize = pc.getLiCategorieslist().size();

		if (categoriesListSize > 0) {
			PerfectoUtils.reportMessage(categoriesListSize + " categories found..");
		} else {
			PerfectoUtils.reportMessage("No categories found..", MessageTypes.Fail);
		}

		pc.getLblAvailablesavings().verifyPresent();
		pc.getLblAvailablesavingsvalue().verifyPresent();
		pc.getImgSavingsmeter().verifyPresent();
		pc.getBtnPrintcoupons().verifyPresent();
		pc.getLblFreeprintablecoupons().verifyPresent();

		PerfectoUtils.scrolltoelement(pc.getLblFreeprintablecoupons());
		int couponBlocksSize = pc.getLiCouponblocks().size();

		if (couponBlocksSize > 0) {
			PerfectoUtils.reportMessage(couponBlocksSize + " Coupon blocks found..");

			for (PrintableCouponBlocks ele : pc.getLiCouponblocks()) {
				ele.getImgCouponimagelist().verifyPresent();
				ele.getLblCouponsummarylist().verifyPresent();
				ele.getLblCouponbrandslist().verifyPresent();
				ele.getLblCoupondetailslist().verifyPresent();
				break;
			}

		} else {
			PerfectoUtils.reportMessage("No Coupon Blocks found..", MessageTypes.Fail);
		}

		PerfectoUtils.scrolltoelement(pc.getBtnShowmorecoupons());
		pc.getBtnShowmorecoupons().verifyPresent();
	}

	@QAFTestStep(description = "Click on Login button from Digital Coupons page")
	public void clickOnLoginButtonFromDigitalCouponsPage() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getLnkLogin().waitForPresent(5000);
		dc.getLnkLogin().click();
		PerfectoUtils.reportMessage("Clicked on Login link..");
	}

	@QAFTestStep(description = "Enter valid credentials and click login button from login page")
	public void enterValidCredentialsAndClickLoginButtonFromLoginPage() {
		String email = getBundle().getString("login.user.email");
		String password = getBundle().getString("login.user.password");

		try {
			if (!getBundle().getString("myEmail").equals("Cold")) {
				email = getBundle().getString("myEmail");
				password = getBundle().getString("myPassword");
			}
		} catch (Exception e) {
			// ignore
		}

		myaccountpage.iEnteremailandpassword(email, password);
		myaccountpage.iClickonLoginbutton();

	}

	@QAFTestStep(description = "I Should see the Digital Coupons page for hotuser")
	public void iShouldSeeTheDigitalCouponsPageForHotuser() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getLblAvailablesection().waitForPresent(10000);
		if (dc.getLblAvailablesection().isPresent())
			PerfectoUtils.reportMessage("Navigated to DC page as hotuser..");
		else
			PerfectoUtils.reportMessage("Error occured while navigating to Digital Coupons page as hotuser..",
					MessageTypes.Fail);
	}

	@QAFTestStep(description = "Click on Sign Up button from Digital Coupons page")
	public void clickOnSignUpButtonFromDigitalCouponsPage() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getLnkSignup().waitForPresent(5000);
		dc.getLnkSignup().click();
		PerfectoUtils.reportMessage("Clicked on Signup link..");
	}

	@QAFTestStep(description = "Select Show Digital Coupons option from the Thanks for register popup")
	public void selectShowDigitalCouponsOptionFromTheThanksForRegisterPopup() {
		ThankYouTestPage ty = new ThankYouTestPage();

		ty.getBtnGotodigitalcoupons().waitForPresent(10000);
		ty.getBtnGotodigitalcoupons().click();
		PerfectoUtils.reportMessage("Clicked on 'Not Now. Show me my Digital Coupons' option..", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Validate the category list in left navigation")
	public void validateTheCategoryListInLeftNavigation() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		int leftnavOptionSize = dc.getLiLeftnavoptions().size();
		if (leftnavOptionSize > 0) {
			PerfectoUtils.scrolltoelement(dc.getLblBycategory());
			PerfectoUtils.reportMessage(leftnavOptionSize + " results found in leftnav options..", MessageTypes.Pass);

			for (QAFWebElement ele : dc.getLiLeftnavoptions()) {
				PerfectoUtils.reportMessage(ele.getText());
			}
		} else {
			PerfectoUtils.reportMessage("No Items found in leftnav options..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Select any category from the left navigation options")
	public void selectAnyCategoryFromTheLeftNavigationOptions() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getLiLeftnavoptions().get(0).waitForPresent(10000);
		int leftnavOptionSize = dc.getLiLeftnavoptions().size();
		if (leftnavOptionSize > 0) {
			PerfectoUtils.scrolltoelement(dc.getLblBycategory());
			PerfectoUtils.reportMessage(leftnavOptionSize + " results found in leftnav options..");

			String leftnavSelectingOption = dc.getLiLeftnavoptions().get(2).getText();
			int pdtCount = Integer.parseInt(PerfectoUtils.getIntCharacters(leftnavSelectingOption));
			getBundle().setProperty("pdtCount", pdtCount);
			dc.getLiLeftnavoptions().get(2).click();
			PerfectoUtils.reportMessage("Selected leftnav option: " + leftnavSelectingOption);
		} else {
			PerfectoUtils.reportMessage("No Items found in leftnav options..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Coupons getting listed based on the category selected")
	public void verifyTheCouponsGettingListedBasedOnTheCategorySelected() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		int pdtCount = getBundle().getInt("pdtCount");
		int pdtCountFromResultsSection = Integer.parseInt(dc.getLblResultscount().getText());

		if (pdtCount == pdtCountFromResultsSection) {
			PerfectoUtils.reportMessage("Coupons getting listed based on the category selected");
		} else {
			PerfectoUtils.reportMessage("Error occured while changing the Category..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate the Sort coupons by Newest")
	public void validateTheSortCouponsByNewest() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getLblSortoptionnewest().waitForPresent(10000);
		dc.getLblSortoptionnewest().click();
		PerfectoUtils.reportMessage("Selected the Sort option Newest..", MessageTypes.Pass);

		try {
			if (dc.getLblSortoptionnewest().getAttribute("selected").equalsIgnoreCase("true")) {
				PerfectoUtils.reportMessage("Validated the Coupons sort by Newest..", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Error occured while Sorting the coupons by Newest..", MessageTypes.Fail);
			}
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured while Sorting the coupons by Newest..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate the Sort coupons by Highest Value")
	public void validateTheSortCouponsByHighestValue() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getLblSortoptionhighestvalue().waitForPresent(10000);
		dc.getLblSortoptionhighestvalue().click();
		PerfectoUtils.reportMessage("Selected the Sort option Highest Value..", MessageTypes.Pass);

		try {
			if (dc.getLblSortoptionhighestvalue().getAttribute("selected").equalsIgnoreCase("true")) {
				PerfectoUtils.reportMessage("Validated the Coupons sort by Highest Value..", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Error occured while Sorting the coupons by Highest Value..",
						MessageTypes.Fail);
			}
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured while Sorting the coupons by Highest Value..",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate the Sort coupons by Expiration Date")
	public void validateTheSortCouponsByExpirationDate() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getLblSortoptionexpdate().waitForPresent(10000);
		dc.getLblSortoptionexpdate().click();
		PerfectoUtils.reportMessage("Selected the Sort option Expiration Date..", MessageTypes.Pass);

		try {
			if (dc.getLblSortoptionexpdate().getAttribute("selected").equalsIgnoreCase("true")) {
				PerfectoUtils.reportMessage("Validated the Coupons sort by Expiration Date..", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Error occured while Sorting the coupons by Expiration Date..",
						MessageTypes.Fail);
			}
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured while Sorting the coupons by Expiration Date..",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate the Sort coupons by Populatity")
	public void validateTheSortCouponsByPopulatity() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getLblSortoptionpopularity().waitForPresent(20000);
		dc.getLblSortoptionpopularity().click();
		PerfectoUtils.reportMessage("Selected the Sort option Populatity..", MessageTypes.Pass);

		try {
			if (dc.getLblSortoptionpopularity().getAttribute("selected").equalsIgnoreCase("true")) {
				PerfectoUtils.reportMessage("Validated the Coupons sort by Populatity..", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Error occured while Sorting the coupons by Populatity..",
						MessageTypes.Fail);
			}
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured while Sorting the coupons by Populatity..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate the Search option in Digital coupons page")
	public void validateTheSearchOptionInDigitalCouponsPage() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		enterValidTermAndSelectSearchButtonInDigitalCouponsPage();

		try {
			dc.getLblResultscount().waitForPresent(10000);
			int resultsCount = Integer.parseInt(dc.getLblResultscount().getText());

			if (resultsCount > 0)
				PerfectoUtils.reportMessage(resultsCount + " results found..");
			else
				PerfectoUtils.reportMessage("No results found..", MessageTypes.Fail);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured while searching coupons..", MessageTypes.Fail);
		}
	}

	public void enterValidTermAndSelectSearchButtonInDigitalCouponsPage() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		String searchTerm = getBundle().getString("digitalcoupons.searchcoupons");
		dc.getTxtSearchcoupons().waitForPresent(10000);
		dc.getTxtSearchcoupons().sendKeys(searchTerm);
		dc.getBtnSearchicon().click();
		PerfectoUtils.reportMessage("Entered '" + searchTerm + "' and clicked search icon..");
	}

	@QAFTestStep(description = "Validate the properties of Digital Coupons Display tile")
	public void validateThePropertiesOfDigitalCouponsDisplayTile() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		PerfectoUtils.scrolltoelement(dc.getTxtSearchcoupons());

		int availableCouponsblocksSize = dc.getLiCouponblocks().size();
		if (availableCouponsblocksSize > 0) {
			PerfectoUtils.reportMessage(availableCouponsblocksSize + " Coupons found..");

			for (DigitalCouponBlocks ele : dc.getLiCouponblocks()) {
				ele.getImgCouponblockamountslist().verifyPresent();
				ele.getImgCouponblockimageslist().verifyPresent();
				ele.getLblCouponblockdescriptionslist().verifyPresent();
				ele.getLblCouponblockmorelist().verifyPresent();
				ele.getLblCouponblocklimitdeslist().verifyPresent();
				ele.getLblCouponblockexpirydatelist().verifyPresent();
				ele.getBtnCouponblockselectlist().verifyPresent();
				break;
			}
		} else {
			PerfectoUtils.reportMessage("No Coupons available....", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Click on Select button for any available coupon")
	public void clickOnSelectButtonForAnyAvailableCoupon() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		PerfectoUtils.scrolltoelement(dc.getTxtSearchcoupons());

		int availableCouponsblocksSize = dc.getLiCouponblocks().size();
		if (availableCouponsblocksSize > 0) {
			PerfectoUtils.reportMessage(availableCouponsblocksSize + " Coupons found..");

			String selectedCoupon = dc.getLiCouponblocks().get(0).getLblCouponblockdescriptionslist().getText();
			getBundle().setProperty("selectedCoupon", selectedCoupon);

			dc.getLiCouponblocks().get(0).getBtnCouponblockselectlist().verifyPresent();
			dc.getLiCouponblocks().get(0).getBtnCouponblockselectlist().click();
			PerfectoUtils.reportMessage("Clicked on Select button for the 1st Coupon..");
		} else {
			PerfectoUtils.reportMessage("No Coupons available....", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the user navigated to Login page")
	public void verifyTheUserNavigatedToLoginPage() {
		LoginTestPage loginpage = new LoginTestPage();

		try {
			loginpage.getLoginLblEmail().waitForPresent(3000);
			if (loginpage.getLoginLblEmail().isPresent())
				PerfectoUtils.reportMessage("Navigated to Login page..", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Not navigated to Login page..", MessageTypes.Fail);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured while navigating to Login page..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Digital Coupons page as a hotuser")
	public void verifyTheDigitalCouponsPageAsAHotuser() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		try {
			dc.getLblAvailablesection().waitForPresent(10000);
			dc.getLblAvailablesection().verifyPresent();
			dc.getLblSelectedsection().verifyPresent();
			dc.getLblSavingtoDateSection().verifyPresent();
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured while navigating to Digital coupons page..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the properties of Coupons Overlay popup")
	public void verifyThePropertiesOfCouponsOverlayPopup() {
		CouponsOverlayTestPage couponsoverlay = new CouponsOverlayTestPage();

		couponsoverlay.getLblCouponname().waitForPresent(5000);
		couponsoverlay.getLblCouponname().verifyPresent();
		couponsoverlay.getImgPopupimg().verifyPresent();
		couponsoverlay.getLblExpirydate().verifyPresent();
		couponsoverlay.getLblLimitdescription().verifyPresent();
		couponsoverlay.getBtnSelect().verifyPresent();
		couponsoverlay.getImgTwitter().verifyPresent();
		couponsoverlay.getImgSendemail().verifyPresent();
		couponsoverlay.getLblTermsandconditionsheader().verifyPresent();
		couponsoverlay.getLblTermsandconditionscontent().verifyPresent();
	}

	@QAFTestStep(description = "Verify the button becomes Selected after selecting it")
	public void verifyTheButtonBecomesSelectedAfterSelectingIt() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		PerfectoUtils.scrolltoelement(dc.getTxtSearchcoupons());

		int availableCouponsblocksSize = dc.getLiCouponblocks().size();
		if (availableCouponsblocksSize > 0) {

			dc.getLiCouponblocks().get(0).getBtnCouponblockselectedlist().waitForPresent(50000);
			if (dc.getLiCouponblocks().get(0).getBtnCouponblockselectedlist().isPresent()) {
				PerfectoUtils.reportMessage("Button became 'Selected' on selecting it..", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Button didn't became 'Selected' on selecting it..", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("No Coupons available....", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Selected Coupons count is updated after selecting the coupon")
	public void verifyTheSelectedCouponsCountIsUpdatedAfterSelectingTheCoupon() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		int selCouponsCountBefore = Integer
				.parseInt(PerfectoUtils.getIntCharacters(dc.getLblSelectedCouponsQty().getText()));

		clickOnSelectButtonForAnyAvailableCoupon();

		dc.getLiCouponblocks().get(0).getBtnCouponblockselectedlist().waitForPresent(5000);

		int selCouponsCountAfter = Integer
				.parseInt(PerfectoUtils.getIntCharacters(dc.getLblSelectedsection().getText()));

		if (selCouponsCountBefore == (selCouponsCountAfter - 1)) {
			PerfectoUtils.reportMessage("Selected Coupons count updated after selecting a coupon..");
		} else {
			PerfectoUtils.reportMessage("Selected Coupons count not updated after selecting a coupon..",
					MessageTypes.Fail);
			PerfectoUtils.reportMessage("selCouponsCountBefore: " + selCouponsCountBefore);
			PerfectoUtils.reportMessage("selCouponsCountAfter: " + selCouponsCountAfter);
		}
	}

	@QAFTestStep(description = "Navigate to Selected Coupons section from Digital coupons page")
	public void navigateToSelectedCouponsSectionFromDigitalCouponsPage() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		PerfectoUtils.getDriver().navigate().refresh();
		dc.getLblSelectedsection().waitForPresent(50000);
		dc.getLblSelectedsection().click();
		dc.waitForAjaxToComplete();
		dc.waitForPageToLoad();
		PerfectoUtils.reportMessage("Clicked on Selected Coupons..");
	}

	@QAFTestStep(description = "Verify the Selected Coupons is available under Selected Coupons")
	public void verifyTheSelectedCouponsIsAvailableUnderSelectedCoupons() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		boolean ispresent = false;
		String selectedCouponName = getBundle().getString("selectedCoupon").trim();
		int selCouponSize = dc.getLblSelectedsectioncouponnames().size();

		if (selCouponSize > 0) {
			PerfectoUtils.reportMessage(selCouponSize + " found under Selected Coupons..");

			for (QAFWebElement ele : dc.getLblSelectedsectioncouponnames()) {
				if (PerfectoUtils.removeSpecialCharacters(ele.getText()).trim()
						.contains(PerfectoUtils.removeSpecialCharacters(selectedCouponName))) {
					ispresent = true;
					break;
				}
			}

			if (ispresent)
				PerfectoUtils.reportMessage("Selected Coupon available in the Selected Coupons section..",
						MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Selected Coupon not available in the Selected Coupons section..",
						MessageTypes.Fail);

		} else {
			PerfectoUtils.reportMessage("No Coupons found under Selected Coupons..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Click and navigate to In My Store view from Coupon Products page")
	public void clickAndNavigateToInMyStoreViewFromCouponProductsPage() {
		CouponsProductsTestPage cp = new CouponsProductsTestPage();

		PerfectoUtils.scrolltoelement(cp.getRbtnInmystore());
		cp.getRbtnInmystore().click();
		PerfectoUtils.reportMessage("Clicked on In My Store option..");

		WeeklyAdsStepDef.searchForWeeklyadsUsingTheZipCode();
		WeeklyAdsStepDef.selectAStoreFromTheSelectAStoreToViewAdsPage();
	}

	@QAFTestStep(description = "Verify the Coupons list in Coupon Products page from In MyStore View")
	public void verifyTheCouponsListInCouponProductsPageFromInMyStoreView() {
		CouponsProductsTestPage cp = new CouponsProductsTestPage();

		PerfectoUtils.scrolltoelement(cp.getCouponprdtsBoxProductblock().get(0));

		int couponBlockSize = cp.getCouponprdtsBoxProductblock().size();

		if (couponBlockSize > 0) {
			PerfectoUtils.reportMessage(couponBlockSize + " Coupon blocks found..");

			for (CouponProductBlocks ele : cp.getCouponprdtsBoxProductblock()) {
				ele.getImgCouponsimglist().verifyPresent();
				ele.getLblCouponsnamelist().verifyPresent();
				ele.getLblCouponspricelabellist().verifyPresent();
				ele.getLblCouponspricevaluelist().verifyPresent();
				ele.getBtnCouponsaddtolist().verifyPresent();
				ele.getTxtCouponsinputqtylist().verifyPresent();
				ele.getBtnCouponsinputqtyincreaselist().verifyPresent();
				ele.getBtnCouponsinputqtydecreaselist().verifyPresent();
				break;
			}

		} else {
			PerfectoUtils.reportMessage("No Coupon blocks found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Click and navigate to Sold Online view from Coupon Products page")
	public void clickAndNavigateToSoldOnlineViewFromCouponProductsPage() {
		CouponsProductsTestPage cp = new CouponsProductsTestPage();

		PerfectoUtils.scrolltoelement(cp.getRbtnSoldonline());
		cp.getRbtnSoldonline().click();
		PerfectoUtils.reportMessage("Clicked on Sold Online option..");
	}

	@QAFTestStep(description = "Verify the Coupons list in Coupon Products page from Sold Online View")
	public void verifyTheCouponsListInCouponProductsPageFromSoldOnlineView() {
		CouponsProductsTestPage cp = new CouponsProductsTestPage();

		PerfectoUtils.scrolltoelement(cp.getCouponprdtsBoxProductblock().get(0));

		int couponBlockSize = cp.getCouponprdtsBoxProductblock().size();

		if (couponBlockSize > 0) {
			PerfectoUtils.reportMessage(couponBlockSize + " Coupon blocks found..");

			for (CouponProductBlocks ele : cp.getCouponprdtsBoxProductblock()) {
				ele.getImgCouponsimglist().verifyPresent();
				ele.getLblCouponsnamelist().verifyPresent();
				ele.getLblCouponspricelabellist().verifyPresent();
				ele.getLblCouponspricevaluelist().verifyPresent();
				ele.getBtnCouponsaddtocartlist().verifyPresent();
				break;
			}
		} else {
			PerfectoUtils.reportMessage("No Coupon blocks found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Coupons list in Coupon Products page from Ship to home View")
	public void verifyTheCouponsListInCouponProductsPageFromShipToHomeView() {
		verifyTheCouponsListInCouponProductsPageFromSoldOnlineView();
	}

	@QAFTestStep(description = "Verify coupons are loaded in digital coupons landing page")
	public void verifyCouponsAreLoadedInDigitalCouponsLandingPage() {
		DigitalCouponsTestPage digcoupons = new DigitalCouponsTestPage();

		String availableCoupons = digcoupons.getLblAvailableCouponsQty().getText().replace(" Coupons", "").trim();
		String selCoupons = digcoupons.getLblSelectedCouponsQty().getText().replace(" Coupons", "").trim();
		int initialCount = digcoupons.getLiCouponblocks().size();

		if (!availableCoupons.equalsIgnoreCase("")) {
			PerfectoUtils.reportMessage("Available Coupons: " + availableCoupons, MessageTypes.Pass);
			PerfectoUtils.reportMessage("Displaying Coupons Count: " + initialCount);
		} else {
			PerfectoUtils.reportMessage("Coupons are not available", MessageTypes.Info);
		}

		getBundle().setProperty("initialCount", initialCount);
		getBundle().setProperty("totalCoupons", Integer.parseInt(availableCoupons)-Integer.parseInt(selCoupons));
	}

	@QAFTestStep(description = "Verify Load More Items is not displayed while scrolling to the bottom of the page")
	public void scrollToTheBottomOfThePage() {
		DigitalCouponsTestPage digcoupons = new DigitalCouponsTestPage();
		MyListTestPage mylist = new MyListTestPage();

		int sizeAllMtListItemsSection = mylist.getMylistLiBoxAllmylistitems().size();

		PerfectoUtils.scrolltoelement(mylist.getMylistLiBoxAllmylistitems().get(sizeAllMtListItemsSection - 1));
		PerfectoUtils.reportMessage("Scrolled to " + sizeAllMtListItemsSection + "th item..", MessageTypes.Pass);

		mylist.waitForAjaxToComplete();
		digcoupons.getLblLoadmoreitems().verifyNotVisible();
	}

	@QAFTestStep(description = "Verify {0} more coupons are loaded")
	public void verifyMoreCouponsAreLoaded(int increaseCount) {
		DigitalCouponsTestPage digcoupons = new DigitalCouponsTestPage();

		digcoupons.waitForAjaxToComplete();
		int initialCount = getBundle().getInt("initialCount");
		digcoupons.getLiCouponblocks().get(initialCount + increaseCount - 1).waitForPresent(50000);
		int updatedCount = digcoupons.getLiCouponblocks().size();

		if ((initialCount + increaseCount) == updatedCount) {
			PerfectoUtils.reportMessage(
					"Coupons display Count is increased by " + increaseCount + ". Total Count: " + updatedCount,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Coupons display count is not increased by " + increaseCount + ". Total Count: " + updatedCount,
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Coupons Avilable and Selected count after selecting it")
	public void verifytheCouponsAvilableandSelectedcountafterselectingit() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		int selCouponsCountBefore = Integer
				.parseInt(PerfectoUtils.getIntCharacters(dc.getLblSelectedCouponsQty().getText()));
		int avilCouponsCountBefore = Integer
				.parseInt(PerfectoUtils.getIntCharacters(dc.getLblAvailableCouponsQty().getText()));

		String strAvlSavingsbefore = dc.getLblAvlSavingsAmount().getText();
		String strSldSavingsbefore = dc.getLblSelectedSavingsAmount().getText();

		getBundle().setProperty("strAvlSavingsbefore", strAvlSavingsbefore);
		getBundle().setProperty("strSldSavingsbefore", strSldSavingsbefore);

		clickOnSelectButtonForAnyAvailableCoupon();

		dc.waitForAjaxToComplete();
		dc.getLiCouponblocks().get(0).getBtnCouponblockselectedlist().waitForPresent(5000);

		PerfectoUtils.getDriver().navigate().refresh();
		int selCouponsCountAfter = Integer
				.parseInt(PerfectoUtils.getIntCharacters(dc.getLblSelectedCouponsQty().getText()));
		int avilCouponsCountAfter = Integer
				.parseInt(PerfectoUtils.getIntCharacters(dc.getLblAvailableCouponsQty().getText()));

		if (selCouponsCountBefore == (selCouponsCountAfter - 1)) {
			PerfectoUtils.reportMessage("Selected Coupons count updated after selecting a coupon..");
		} else {
			PerfectoUtils.reportMessage("Selected Coupons count not updated after selecting a coupon..",
					MessageTypes.Fail);
			PerfectoUtils.reportMessage("selCouponsCountBefore: " + selCouponsCountBefore);
			PerfectoUtils.reportMessage("selCouponsCountAfter: " + selCouponsCountAfter);
		}

		if (avilCouponsCountAfter == (avilCouponsCountBefore - 1)) {
			PerfectoUtils.reportMessage("Selected Coupons count updated after selecting a coupon..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Avilable Coupons count not updated after selecting a coupon..",
					MessageTypes.Fail);
			PerfectoUtils.reportMessage("avilCouponsCountBefore: " + avilCouponsCountBefore);
			PerfectoUtils.reportMessage("avilCouponsCountAfter: " + avilCouponsCountAfter);
		}

	}

	@QAFTestStep(description = "Verify the Avilable and Selected Coupon savings")
	public void verifytheAvilableandSelectedCouponsavings() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		String strAvlSavingsbefore = getBundle().getString("strAvlSavingsbefore");
		String strSldSavingsbefore = getBundle().getString("strSldSavingsbefore");
		strAvlSavingsbefore = PerfectoUtils.removeSpecialCharacters(strAvlSavingsbefore);
		strSldSavingsbefore = PerfectoUtils.removeSpecialCharacters(strSldSavingsbefore);

		int avlSavingsbefore = Integer.parseInt(strAvlSavingsbefore);
		int sldSavingsbefore = Integer.parseInt(strSldSavingsbefore);

		dc.getLnkUpdateSavings().click();
		dc.waitForAjaxToComplete();
		PerfectoUtils.getDriver().navigate().refresh();

		dc.getLblAvlSavingsAmount().waitForPresent(50000);

		String strAvlSavingsafter = dc.getLblAvlSavingsAmount().getText();
		String strSldSavingsafter = dc.getLblSelectedSavingsAmount().getText();
		strAvlSavingsafter = PerfectoUtils.removeSpecialCharacters(strAvlSavingsafter);
		strSldSavingsafter = PerfectoUtils.removeSpecialCharacters(strSldSavingsafter);

		int avlSavingsafter = Integer.parseInt(strAvlSavingsafter);
		int sldSavingsafter = Integer.parseInt(strSldSavingsafter);

		if (avlSavingsbefore > avlSavingsafter) {
			PerfectoUtils.reportMessage("Avilable Savings Amount updated after clicking update savings..");
		} else {
			PerfectoUtils.reportMessage("Avilable Savings Amount not updated clicking update savings..",
					MessageTypes.Fail);
			PerfectoUtils.reportMessage("avlSavingsbefore: " + avlSavingsbefore);
			PerfectoUtils.reportMessage("avlSavingsafter: " + avlSavingsafter);
		}

		if (sldSavingsbefore < sldSavingsafter) {
			PerfectoUtils.reportMessage("Selected Savings Amount updated after clicking update savings..");
		} else {
			PerfectoUtils.reportMessage("Selected Savings Amount not updated clicking update savings..",
					MessageTypes.Fail);
			PerfectoUtils.reportMessage("sldSavingsbefore: " + sldSavingsbefore);
			PerfectoUtils.reportMessage("sldSavingsafter: " + sldSavingsafter);
		}
	}

	@QAFTestStep(description = "Verify the Select button becomes Selected after selecting {0} th coupon")
	public void VerifyTheSelectButtonBecomesSelectedAfterSelectingACouponFromMiddleOfThePage(int couponNnum) {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		int selCouponsCountBefore = Integer
				.parseInt(PerfectoUtils.getIntCharacters(dc.getLblSelectedCouponsQty().getText()));
		int avilCouponsCountBefore = Integer
				.parseInt(PerfectoUtils.getIntCharacters(dc.getLblAvailableCouponsQty().getText()));

		PerfectoUtils.scrolltoelement(dc.getLiCouponblocks().get(couponNnum - 1).getBtnCouponblockselectlist());
		Point beforeSelectPoint = dc.getLiCouponblocks().get(couponNnum - 1).getLocation();
		getBundle().setProperty("beforeSelectPoint", beforeSelectPoint);

		clickOnSelectButtonForthAnyAvailableCoupon(couponNnum);

		dc.getLiCouponblocks().get(couponNnum - 1).getBtnCouponblockselectedlist().waitForPresent(5000);

		int selCouponsCountAfter = Integer
				.parseInt(PerfectoUtils.getIntCharacters(dc.getLblSelectedCouponsQty().getText()));
		int avilCouponsCountAfter = Integer
				.parseInt(PerfectoUtils.getIntCharacters(dc.getLblAvailableCouponsQty().getText()));

		if (selCouponsCountBefore == (selCouponsCountAfter - 1)) {
			PerfectoUtils.reportMessage("Selected Coupons count updated after selecting a coupon..");
		} else {
			PerfectoUtils.reportMessage("Selected Coupons count not updated after selecting a coupon..",
					MessageTypes.Fail);
			PerfectoUtils.reportMessage("selCouponsCountBefore: " + selCouponsCountBefore);
			PerfectoUtils.reportMessage("selCouponsCountAfter: " + selCouponsCountAfter);
		}

		if (avilCouponsCountAfter == (avilCouponsCountBefore - 1)) {
			PerfectoUtils.reportMessage("Selected Coupons count updated after selecting a coupon..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Avilable Coupons count not updated after selecting a coupon..",
					MessageTypes.Fail);
			PerfectoUtils.reportMessage("avilCouponsCountBefore: " + avilCouponsCountBefore);
			PerfectoUtils.reportMessage("avilCouponsCountAfter: " + avilCouponsCountAfter);
		}

	}

	@QAFTestStep(description = "Click on Select button for {0} th available coupon")
	public void clickOnSelectButtonForthAnyAvailableCoupon(int couponNum) {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		PerfectoUtils.scrolltoelement(dc.getTxtSearchcoupons());

		int availableCouponsblocksSize = dc.getLiCouponblocks().size();
		if (availableCouponsblocksSize > 0) {
			PerfectoUtils.reportMessage(availableCouponsblocksSize + " Coupons found..");

			String selectedCoupon = dc.getLiCouponblocks().get(couponNum - 1).getLblCouponblockdescriptionslist()
					.getText();
			getBundle().setProperty("selectedCoupon", selectedCoupon);

			dc.getLiCouponblocks().get(couponNum - 1).getBtnCouponblockselectlist().verifyPresent();
			dc.getLiCouponblocks().get(couponNum - 1).getBtnCouponblockselectlist().click();
			PerfectoUtils.reportMessage("Clicked on Select button for the 1st Coupon..");
		} else {
			PerfectoUtils.reportMessage("No Coupons available....", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate the page does not jump around from {0} th coupon")
	public void validateThePageDoesNotJumpAround(int couponNum) {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getLiCouponblocks().get(couponNum - 1).getBtnCouponblockselectlist().verifyVisible();
		Point afterSelectPoint = dc.getLiCouponblocks().get(couponNum - 1).getLocation();
		Point beforeSelectPoint = (Point) getBundle().getProperty("beforeSelectPoint");

		if ((afterSelectPoint.toString().equals(beforeSelectPoint.toString()))
				&& (dc.getLiCouponblocks().get(couponNum - 1).getBtnCouponblockselectedlist().isDisplayed())) {
			PerfectoUtils.reportMessage("The page does not jump after selecting the coupon", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("The page has jumped after selecting the coupon", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify the Select button becomes Selected after selecting {0} th coupon from more popup")
	public void VerifyTheSelectButtonBecomesSelectedAfterSelectingACouponFromMorePopUp(int couponNnum) {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		int selCouponsCountBefore = Integer
				.parseInt(PerfectoUtils.getIntCharacters(dc.getLblSelectedsection().getText()));
		int avilCouponsCountBefore = Integer
				.parseInt(PerfectoUtils.getIntCharacters(dc.getLblAvailablesection().getText()));
		System.out.println("Before Scroll");
		System.out.println("Co ordinates " + dc.getLiCouponblocks().get(couponNnum - 1).getCoordinates());
		// System.out.println("Rect " +
		// dc.getLiCouponblocks().get(couponNnum-1).getRect());

		PerfectoUtils.scrolltoelement(dc.getLiCouponblocks().get(couponNnum - 1).getLblCouponblockmorelist());
		Point beforeSelectPoint = dc.getLiCouponblocks().get(couponNnum - 1).getLocation();

		System.out.println("After Scroll");
		System.out.println("Co ordinates " + dc.getLiCouponblocks().get(couponNnum - 1).getCoordinates());
		// System.out.println("Rect " +
		// dc.getLiCouponblocks().get(couponNnum-1).getRect());

		getBundle().setProperty("beforeSelectPoint", beforeSelectPoint);

		selectMoreOptionForThAvailableCouponAndSelectCoupon(couponNnum);

		dc.getLiCouponblocks().get(couponNnum - 1).getBtnCouponblockselectedlist().waitForPresent(5000);

		int selCouponsCountAfter = Integer
				.parseInt(PerfectoUtils.getIntCharacters(dc.getLblSelectedsection().getText()));
		int avilCouponsCountAfter = Integer
				.parseInt(PerfectoUtils.getIntCharacters(dc.getLblAvailablesection().getText()));

		if (selCouponsCountBefore == (selCouponsCountAfter - 1)) {
			PerfectoUtils.reportMessage("Selected Coupons count updated after selecting a coupon..");
		} else {
			PerfectoUtils.reportMessage("Selected Coupons count not updated after selecting a coupon..",
					MessageTypes.Fail);
			PerfectoUtils.reportMessage("selCouponsCountBefore: " + selCouponsCountBefore);
			PerfectoUtils.reportMessage("selCouponsCountAfter: " + selCouponsCountAfter);
		}

		if (avilCouponsCountAfter == (avilCouponsCountBefore - 1)) {
			PerfectoUtils.reportMessage("Selected Coupons count updated after selecting a coupon..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Avilable Coupons count not updated after selecting a coupon..",
					MessageTypes.Fail);
			PerfectoUtils.reportMessage("avilCouponsCountBefore: " + avilCouponsCountBefore);
			PerfectoUtils.reportMessage("avilCouponsCountAfter: " + avilCouponsCountAfter);
		}

	}

	@QAFTestStep(description = "Select More option for {0} th available coupon and Select Coupon")
	public void selectMoreOptionForThAvailableCouponAndSelectCoupon(int couponNum) {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();
		CouponsOverlayTestPage overlay = new CouponsOverlayTestPage();

		int MoreListSize = dc.getLiCouponblocks().size();

		if (MoreListSize > 0) {
			PerfectoUtils.reportMessage(MoreListSize + " Coupons found..");
			PerfectoUtils.scrolltoelement(dc.getLiCouponblocks().get(couponNum - 1).getLblCouponblockmorelist());
			dc.getLiCouponblocks().get(couponNum - 1).getLblCouponblockmorelist().click();

			overlay.waitForAjaxToComplete();

			overlay.getBtnSelect().waitForPresent(5000);
			overlay.getBtnSelect().click();
		} else {
			PerfectoUtils.reportMessage("No Coupons found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify all links landing page")
	public void verifyAllLinksLandingPage() {
		CouponsTestPage couponslanding = new CouponsTestPage();

		couponslanding.getLnkDigcouponslearnmore().waitForPresent(50000);
		couponslanding.getLnkDigcouponslearnmore().click();
		couponslanding.getImgLearnMoreLanpage().waitForPresent(50000);
		couponslanding.getImgLearnMoreLanpage().verifyPresent();
		PerfectoUtils.getDriver().navigate().back();

		couponslanding.getTxtCheckLanpage().waitForPresent(50000);
		couponslanding.getTxtCheckLanpage().verifyPresent();
		PerfectoUtils.getDriver().navigate().back();

		couponslanding.getTxtFaqsLanpage().waitForPresent(50000);
		couponslanding.getTxtFaqsLanpage().verifyPresent();
		PerfectoUtils.getDriver().navigate().back();

		couponslanding.getLnkViewcouponpolicy().waitForPresent(50000);
		couponslanding.getLnkViewcouponpolicy().click();
		couponslanding.getTxtPolicyLanpage().waitForPresent(50000);
		couponslanding.getTxtPolicyLanpage().verifyPresent();
		PerfectoUtils.getDriver().navigate().back();
	}

	@QAFTestStep(description = "Validate user can see more than {0} email exclusive coupons")
	public void ValidateUserCanSeeMoreThanEmailExclusiveCoupons(int expCount) {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();
		expCount++;
		int actCount = 0;
		int emailExclusiveCount = 0;

		dc.getLiCouponblocks().get(0).verifyPresent();
		for (DigitalCouponBlocks couponBlock : dc.getLiCouponblocks()) {
			if (couponBlock.getImgSpecialOffers().isPresent()) {
				actCount++;
				String couponDesc = couponBlock.getLblCouponblockdescriptionslist().getText();
				if (couponDesc.contains("Email Exclusive")) {
					emailExclusiveCount++;
				}
			}
		}

		if (actCount > 0 && actCount >= expCount) {
			PerfectoUtils.reportMessage(
					actCount + "Special Offers Coupons are found and Available Email exclusive offers are: "
							+ emailExclusiveCount,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Special offers coupons are not found", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate user can search {0} coupons")
	public void validateUserCanSearchCoupons(String searchText) {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();
		int actCount = 0;
		int emailExclusiveCount = 0;

		dc.getTxtSearchcoupons().verifyPresent();
		dc.getTxtSearchcoupons().click();
		dc.getTxtSearchcoupons().sendKeys(searchText);
		dc.getBtnSearchicon().click();

		dc.getLiCouponblocks().get(0).waitForPresent();
		int size = dc.getLiCouponblocks().size();

		dc.getLiCouponblocks().get(0).verifyPresent();
		for (DigitalCouponBlocks couponBlock : dc.getLiCouponblocks()) {
			if (couponBlock.getImgSpecialOffers().isPresent()) {
				actCount++;
				String couponDesc = couponBlock.getLblCouponblockdescriptionslist().getText();
				if (couponDesc.contains("Email Exclusive")) {
					emailExclusiveCount++;
				}
			}
		}

		if (actCount > 0 && actCount == size) {
			PerfectoUtils.reportMessage(
					actCount + "Special Offers Coupons are found and Available Email exclusive offers are: "
							+ emailExclusiveCount,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Special offers coupons are not found", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the modal window pop")
	public void iVerifyTheModalWindowPop() {
		DigitalCouponsLoginPopupTestPage loginpopup = new DigitalCouponsLoginPopupTestPage();

		loginpopup.getBtnLogin().waitForPresent(50000);
		loginpopup.getBtnLogin().verifyPresent();
		loginpopup.getBtnGuest().verifyPresent();
		loginpopup.getLnkRegister().verifyPresent();
		loginpopup.getImgPopupclose().verifyPresent();
		PerfectoUtils.reportMessage("Modal Windpw pop up is present", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I verify all tabs available in Digital Coupons page")
	public void iVerifyAllTabsAvailableInDigitalCouponsPage() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();
		LoginTestPage login = new LoginTestPage();
		DigitalCouponsLoginPopupTestPage loginpopup = new DigitalCouponsLoginPopupTestPage();
		String totalavlcouponsqty = "0";
		String totalsavingamt = "0";

		if (loginpopup.getBtnLogin().isPresent()) {
			loginpopup.getImgPopupclose().click();
		}

		// Verifying Total available tab
		if (dc.getLblAvailablesection().isPresent()) {
			totalavlcouponsqty = dc.getLblAvailableCouponsQty().getText();
			PerfectoUtils.reportMessage("Total Available Coupons are " + totalavlcouponsqty, MessageTypes.Pass);

			totalsavingamt = dc.getLblAvlSavingsAmount().getText();
			PerfectoUtils.reportMessage("Total Saving amount is " + totalsavingamt, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to find Total Available Coupons section", MessageTypes.Fail);
		}

		// Verifying My Selected tab
		if (dc.getLblSelectedsection().isPresent()) {
			dc.getLnkMyselectedLogin().verifyPresent();
		} else {
			PerfectoUtils.reportMessage("Unable to find My Selected section", MessageTypes.Fail);
		}

		// Verifying Savings-to-Date tab
		if (dc.getLblSavingtoDateSection().isPresent()) {
			dc.getLnkSavingtodateLogin().verifyPresent();
		} else {
			PerfectoUtils.reportMessage("Unable to find Savings To Date section", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify all tabs available in Digital Coupons page for hot user")
	public void iVerifyAllTabsAvailableInDigitalCouponsPageForHotUser() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();
		LoginTestPage login = new LoginTestPage();
		String totalavlcouponsqty = "0";
		String totalsavingamt = "0";

		// Verifying Total available tab
		if (dc.getLblAvailablesection().isPresent()) {
			totalavlcouponsqty = dc.getLblAvailableCouponsQty().getText();
			PerfectoUtils.reportMessage("Total Available Coupons are " + totalavlcouponsqty, MessageTypes.Pass);

			totalsavingamt = dc.getLblAvlSavingsAmount().getText();
			PerfectoUtils.reportMessage("Total Saving amount is " + totalsavingamt, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to find Total Available Coupons section", MessageTypes.Fail);
		}

		// Verifying My Selected tab
		if (dc.getLblSelectedsection().isPresent()) {
			String selectedcouponsqty = dc.getLblSelectedCouponsQty().getText();
			PerfectoUtils.reportMessage("Total Available Coupons are " + selectedcouponsqty, MessageTypes.Pass);

			String selectedsavingamt = dc.getLblSelectedSavingsAmount().getText();
			PerfectoUtils.reportMessage("Total Saving amount is " + selectedsavingamt, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to find My Selected section", MessageTypes.Fail);
		}

		// Verifying Savings-to-Date tab
		if (dc.getLblSavingtoDateSection().isPresent()) {
			String savingtodatecouponsqty = dc.getLblSavingtoDateCouponsQty().getText();
			PerfectoUtils.reportMessage("Total Available Coupons are " + savingtodatecouponsqty, MessageTypes.Pass);

			String savingtodateamt = dc.getLblSavingtoDateAmount().getText();
			PerfectoUtils.reportMessage("Total Saving amount is " + savingtodateamt, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to find My Selected section", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the button turned into Selected and Grayed out")
	public void verifyTheButtonTurnedIntoSelectedAndGrayedOut() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		PerfectoUtils.scrolltoelement(dc.getTxtSearchcoupons());

		dc.waitForAjaxToComplete();
		dc.getLiCouponblocks().get(0).getBtnCouponblockselectedlist().waitForPresent(5000);

		if (dc.getLiCouponblocks().get(0).getBtnCouponblockselectedlist().isPresent()) {
			PerfectoUtils.reportMessage("Button turned in to Selected..", MessageTypes.Pass);

			String buttonColour = dc.getLiCouponblocks().get(0).getBtnCouponblockselectedlist().getCssValue("color");
			String expButtonColour = getBundle().getString("digitalcoupons.colorcode.selectbtngray");

			if (buttonColour.equals(expButtonColour))
				PerfectoUtils.reportMessage("Button grayed out as expected..", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Button not grayed out..", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("Button not turned in to Selected..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Select Details option for any available coupon")
	public void selectDetailsOptionForAnyAvailableCoupon() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		int DetailsListSize = dc.getLiCouponblocks().size();

		if (DetailsListSize > 0) {
			PerfectoUtils.reportMessage(DetailsListSize + " Coupons found..", MessageTypes.Pass);
			PerfectoUtils.scrolltoelement(dc.getLiCouponblocks().get(0).getLblCouponblockdetailslist());
			dc.getLiCouponblocks().get(0).getLblCouponblockdetailslist().click();
			PerfectoUtils.reportMessage("Clicked on Details for an available coupons..");
		} else {
			PerfectoUtils.reportMessage("No Coupons found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Click on Select button from the Coupons overlay popup")
	public void clickOnSelectButtonFromTheCouponsOverlayPopup() {
		CouponsOverlayTestPage couponsoverlay = new CouponsOverlayTestPage();

		couponsoverlay.waitForAjaxToComplete();
		couponsoverlay.waitForPageToLoad();
		couponsoverlay.getLblCouponname().waitForPresent(50000);
		if (couponsoverlay.getLblCouponname().isPresent()) {
			PerfectoUtils.reportMessage("Coupons overlay popup found..", MessageTypes.Pass);

			String selectedCoupon = couponsoverlay.getLblCouponname().getText();
			getBundle().setProperty("selectedCoupon", selectedCoupon);
			couponsoverlay.getBtnSelect().waitForPresent(1000);
			couponsoverlay.getBtnSelect().click();
			PerfectoUtils.reportMessage("Clicked on Select button..", MessageTypes.Pass);

		} else {
			PerfectoUtils.reportMessage("Coupons overlay popup found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Click on Close button from the Coupons overlay popup")
	public void clickOnCloseButtonFromTheCouponsOverlayPopup() {
		CouponsOverlayTestPage couponsoverlay = new CouponsOverlayTestPage();

		couponsoverlay.waitForAjaxToComplete();
		couponsoverlay.getLblCouponname().waitForPresent(5000);
		if (couponsoverlay.getLblCouponname().isPresent()) {
			PerfectoUtils.reportMessage("Coupons overlay popup found..", MessageTypes.Pass);

			couponsoverlay.getImgPopupclose().waitForPresent(1000);
			couponsoverlay.getImgPopupclose().click();
			PerfectoUtils.reportMessage("Clicked on Close icon..", MessageTypes.Pass);

		} else {
			PerfectoUtils.reportMessage("Coupons overlay popup found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Coupons overlay popup got closed")
	public void verifyTheCouponsOverlayPopupGotClosed() {
		CouponsOverlayTestPage couponsoverlay = new CouponsOverlayTestPage();

		couponsoverlay.waitForAjaxToComplete();
		if (!couponsoverlay.getLblCouponname().isPresent()) {
			PerfectoUtils.reportMessage("Popup got closed..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons overlay popup not closed..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Select checkbox for any available coupon in selected section")
	public void selectCheckboxForAnyAvailableCouponInSelectedSection() {
		DigitalCouponsSelectedSectionTestPage dcsel = new DigitalCouponsSelectedSectionTestPage();

		dcsel.waitForAjaxToComplete();
		int couponSize = dcsel.getLiCouponblocks().size();

		if (couponSize > 0) {
			PerfectoUtils.reportMessage(couponSize + " Coupons found in selected section..", MessageTypes.Pass);

			for (DigitalCouponBlocksInSelectedSection ele : dcsel.getLiCouponblocks()) {

				String couponName = ele.getLblCouponblockitemdescription().getText();
				getBundle().setProperty("ProductName", couponName);
				ele.getChkCouponblockitemcheckbox().waitForPresent(1000);
				ele.getChkCouponblockitemcheckbox().click();
				PerfectoUtils.reportMessage("Clicked checkbox for item: " + couponName);
			}
		} else {
			PerfectoUtils.reportMessage("No Coupons found in selected section..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Select anywhere in any available coupon in selected section")
	public void selectAnywhereInAnyAvailableCouponInSelectedSection() {
		DigitalCouponsSelectedSectionTestPage dcsel = new DigitalCouponsSelectedSectionTestPage();

		dcsel.waitForAjaxToComplete();
		int couponSize = dcsel.getLiCouponblocks().size();

		if (couponSize > 0) {
			PerfectoUtils.reportMessage(couponSize + " Coupons found in selected section..", MessageTypes.Pass);

			for (DigitalCouponBlocksInSelectedSection ele : dcsel.getLiCouponblocks()) {

				String couponName = ele.getLblCouponblockitemdescription().getText();
				getBundle().setProperty("ProductName", couponName);
				ele.getLblCouponblockitemdescription().waitForPresent(1000);
				ele.getLblCouponblockitemdescription().click();
				PerfectoUtils.reportMessage("Clicked anywhere on item name:  " + couponName);
			}
		} else {
			PerfectoUtils.reportMessage("No Coupons found in selected section..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Add to list button got enabled")
	public void verifyTheAddToListButtonGotEnabled() {
		DigitalCouponsSelectedSectionTestPage dcsel = new DigitalCouponsSelectedSectionTestPage();

		dcsel.waitForAjaxToComplete();
		String expFontColour = getBundle().getString("digitalcoupons.colorcode.blue");
		String expBorderColour = getBundle().getString("digitalcoupons.colorcode.blue");
		String expBackGroundColour = getBundle().getString("digitalcoupons.colorcode.white");

		String actFontColor = dcsel.getBtnAddtolist().getCssValue("color");
		String actBoderColor = dcsel.getBtnAddtolist().getCssValue("border");
		String actBackGroundColor = dcsel.getBtnAddtolist().getCssValue("background-color");

		if (expFontColour.equals(actFontColor)) {
			if (expBorderColour.equals(actBoderColor)) {
				if (expBackGroundColour.equals(actBackGroundColor)) {
					PerfectoUtils.reportMessage(
							"Add to list button enabled and colors/properties have been validated..",
							MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Background colour doesn't match..", MessageTypes.Fail);
					PerfectoUtils.reportMessage("Expected: " + expBackGroundColour);
					PerfectoUtils.reportMessage("Actual: " + actBackGroundColor);
				}
			} else {
				PerfectoUtils.reportMessage("Border colour doesn't match..", MessageTypes.Fail);
				PerfectoUtils.reportMessage("Expected: " + expBorderColour);
				PerfectoUtils.reportMessage("Actual: " + actBoderColor);
			}
		} else {
			PerfectoUtils.reportMessage("Font colour doesn't match..", MessageTypes.Fail);
			PerfectoUtils.reportMessage("Expected: " + expFontColour);
			PerfectoUtils.reportMessage("Actual: " + actFontColor);
		}

	}

	@QAFTestStep(description = "Select Add to list button from Selected section")
	public void selectAddToListButtonFromSelectedSection() {
		DigitalCouponsSelectedSectionTestPage dcsel = new DigitalCouponsSelectedSectionTestPage();

		dcsel.waitForAjaxToComplete();

		dcsel.getBtnAddtolist().waitForPresent(3000);
		dcsel.getBtnAddtolist().click();
		PerfectoUtils.reportMessage("Clicked on Add to list button..", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify the Add to list button got disabled")
	public void verifyTheAddToListButtonGotDisabled() {
		DigitalCouponsSelectedSectionTestPage dcsel = new DigitalCouponsSelectedSectionTestPage();

		dcsel.waitForAjaxToComplete();
		dcsel.getBtnAddtolistwhendisabled().waitForPresent(5000);

		String expFontColour = getBundle().getString("digitalcoupons.colorcode.white");
		String expBackGroundColour = getBundle().getString("digitalcoupons.colorcode.addalltolistgray");

		String actFontColor = dcsel.getBtnAddtolistwhendisabled().getCssValue("color");
		String actBackGroundColor = dcsel.getBtnAddtolistwhendisabled().getCssValue("background-color");

		if (expFontColour.equals(actFontColor)) {

			if (expBackGroundColour.equals(actBackGroundColor)) {
				PerfectoUtils.reportMessage("Add to list button disabled and colors/properties have been validated..",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Background colour doesn't match..", MessageTypes.Fail);
				PerfectoUtils.reportMessage("Expected: " + expBackGroundColour);
				PerfectoUtils.reportMessage("Actual: " + actBackGroundColor);
			}
		} else {
			PerfectoUtils.reportMessage("Font colour doesn't match..", MessageTypes.Fail);
			PerfectoUtils.reportMessage("Expected: " + expFontColour);
			PerfectoUtils.reportMessage("Actual: " + actFontColor);
		}
	}

	@QAFTestStep(description = "Verify the Add to list button is grayed out")
	public void verifyTheAddToListButtonIsGrayedOut() {
		DigitalCouponsSelectedSectionTestPage dcsel = new DigitalCouponsSelectedSectionTestPage();

		dcsel.waitForAjaxToComplete();

		String buttonColour = dcsel.getBtnAddtolistwhendisabled().getCssValue("color");
		String expButtonColour = getBundle().getString("digitalcoupons.colorcode.addalltolistgray");

		if (buttonColour.equals(expButtonColour))
			PerfectoUtils.reportMessage("Add to list button is grayed out..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Add to list button not grayed out..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify the Add to list button turns to blue")
	public void verifyTheAddToListButtonTurnsToBlue() {
		DigitalCouponsSelectedSectionTestPage dcsel = new DigitalCouponsSelectedSectionTestPage();

		dcsel.waitForAjaxToComplete();

		String buttonColour = dcsel.getBtnAddtolist().getCssValue("color");
		String expButtonColour = getBundle().getString("digitalcoupons.colorcode.blue");

		if (buttonColour.equals(expButtonColour))
			PerfectoUtils.reportMessage("Add to list button turns to blue..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Add to list button not turned to blue..", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Try to click Add to list button")
	public void tryToClickAddToListButton() {
		DigitalCouponsSelectedSectionTestPage dcsel = new DigitalCouponsSelectedSectionTestPage();

		dcsel.waitForAjaxToComplete();

		if (dcsel.getBtnAddtolistwhendisabled().isPresent()) {
			PerfectoUtils.reportMessage("Add to list button is disabled..");
			dcsel.getBtnAddtolistwhendisabled().click();
			PerfectoUtils.reportMessage("Clicked on Add to list button..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Add to list button not disabled..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the user not able to add the coupons to list")
	public void verifyTheUserNotAbleToAddTheCouponsToList() {
		MyListTestPage mylist = new MyListTestPage();

		mylist.waitForPageToLoad();
		mylist.waitForAjaxToComplete();

		if (!mylist.getMylistLblMinilist().isPresent())
			PerfectoUtils.reportMessage("User not able to add the coupons to list..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("User able to add the coupons to list.. Mini Shopping list is displayed",
					MessageTypes.Fail);
	}

	@QAFTestStep(description = "Click on Login in Digtal Coupons modal window")
	public void clickOnloginInDigtalCouponsModalWindow() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();
		DigitalCouponsLoginPopupTestPage loginpopup = new DigitalCouponsLoginPopupTestPage();

		loginpopup.getBtnLogin().waitForPresent(4000);
		if (loginpopup.getBtnLogin().verifyPresent()) {
			loginpopup.getBtnLogin().click();
			PerfectoUtils.reportMessage("Modal Windpw pop up Login is clicked", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Modal Windpw pop up Login is not been clicked", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I verify the window popup closes out when clicking on browse as Guest User")
	public void iVerifyTheWindowPopupClosesOutWhenClickingOnBrowseAsGuestUser() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();
		DigitalCouponsLoginPopupTestPage loginpopup = new DigitalCouponsLoginPopupTestPage();

		loginpopup.getBtnGuest().click();
		dc.waitForAjaxToComplete();
		if (loginpopup.getBtnLogin().verifyNotPresent()) {
			PerfectoUtils.reportMessage("Modal Windpw pop up is not present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Modal Windpw pop up is present", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I verify Coupons page banner and validate learn more link navigation")
	public void iVerifyCouponsPageBannerAndValidateLearnMoreLinkNavigation() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();
		CouponsTestPage coupons = new CouponsTestPage();

		dc.getImgBanner().verifyVisible();
		dc.getLnkLearnmore().verifyPresent();
		dc.getLnkLearnmore().click();
		dc.waitForPageToLoad();
		coupons.getTxtFaqsLanpage().verifyPresent();
	}

	@QAFTestStep(description = "I validate coupons results count and category displays in Total Available tab")
	public void iValidateCouponsResultsCountAndCategoryDisplaysInLeft() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getLblCouponsresult().verifyPresent();
		String[] couponsResult = dc.getLblCouponsresult().getText().split(" ");
		String couponsResultQty = couponsResult[0];
		String couponsResultCat = couponsResult[3].replace("\"", "");

		dc.getLblShowingofqty().verifyPresent();
		String[] showingOf = dc.getLblShowingofqty().getText().trim().split(" ");
		String showingOfQty = showingOf[showingOf.length - 1];

		dc.getDrpdwnFilterby().verifyPresent();
		String[] filter = PerfectoUtils.dropdownGetSelectedValue(dc.getDrpdwnFilterby()).trim().split(" ");
		String filterCat = filter[0];
		String filterQty = filter[1].replace("(", "").replace(")", "");

		if (couponsResultQty.equals(showingOfQty) && couponsResultQty.equals(filterQty)) {
			PerfectoUtils.reportMessage("Coupons Results Qty is verified with Showing of Qty and Filtered category Qty",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons Results Qty is not same as Showing of Qty and Filtered category Qty",
					MessageTypes.Fail);
		}

		if (couponsResultCat.equals(filterCat)) {
			PerfectoUtils.reportMessage("Coupons Results Category is verified with Filtered category",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons Results Category is not same as Filtered category", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Select Create one option from Login page")
	public void selectCreateOneOptionFromLoginPage() {
		LoginTestPage login = new LoginTestPage();

		login.getLoginLnkCreateOne().waitForPresent(5000);
		login.getLoginLnkCreateOne().click();
		PerfectoUtils.reportMessage("Clicked on Create one link..", MessageTypes.Pass);

	}

	@QAFTestStep(description = "Click on Print Page option from Selected section")
	public void clickOnPrintPageOptionFromSelectedSection() {
		DigitalCouponsSelectedSectionTestPage dcsel = new DigitalCouponsSelectedSectionTestPage();

		dcsel.waitForAjaxToComplete();

		dcsel.getLnkPrintpage().waitForPresent(5000);
		dcsel.getLnkPrintpage().click();
		PerfectoUtils.reportMessage("Clicked on Print Page option..", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify navigated to Print page")
	public void verifyNavigatedToPrintPage() {
		PrintTestPage print = new PrintTestPage();

		print.waitForAjaxToComplete();

		try {
			print.getLblPagetitle().waitForPresent(10000);
		} catch (Exception e) {
			print.getLblPagetitle().waitForPresent(10000);
			PerfectoUtils.reportMessage("Waiting few more time..");
		}

		print.getLblPagetitle().verifyPresent();
	}

	@QAFTestStep(description = "Verify the properties of My Selected section")
	public void verifyThePropertiesOfMySelectedSection() {
		DigitalCouponsSelectedSectionTestPage dcsel = new DigitalCouponsSelectedSectionTestPage();

		dcsel.getLblResultscount().waitForPresent(5000);
		dcsel.getLblResultscount().verifyPresent();

		// Validating the sort options
		dcsel.getLblSortby().verifyPresent();
		int sortOptionSize = dcsel.getLiSortoptions().size();

		if (sortOptionSize > 0)
			PerfectoUtils.reportMessage(sortOptionSize + " Sort options found..");
		else
			PerfectoUtils.reportMessage("No Sort options found..", MessageTypes.Fail);

		// Validating the Filter by options
		dcsel.getLblFilterby().verifyPresent();
		int filterbyOptionSize = dcsel.getLiFilterbyoptions().size();

		if (filterbyOptionSize > 0)
			PerfectoUtils.reportMessage(filterbyOptionSize + " filter by Options found..");
		else
			PerfectoUtils.reportMessage("No filter by Options found..", MessageTypes.Fail);

		dcsel.getLnkPrintpage().verifyPresent();
		dcsel.getChkAddallcouponstolist().verifyPresent();
		dcsel.getBtnAddtolistwhendisabled().verifyPresent();

		// validating the Coupon blocks
		int CouponBlockSize = dcsel.getLiCouponblocks().size();

		if (CouponBlockSize > 0) {
			PerfectoUtils.reportMessage(CouponBlockSize + " Coupon blocks found..", MessageTypes.Pass);

			for (DigitalCouponBlocksInSelectedSection ele : dcsel.getLiCouponblocks()) {
				ele.getLblCouponblockitemdescription().verifyPresent();
				ele.getImgCouponblockitemimage().verifyPresent();
				ele.getLblCouponblockexpdate().verifyPresent();
				ele.getLblCouponblocklimitdescription().verifyPresent();
				ele.getLblCouponblockitemprice().verifyPresent();
				break;
			}

		} else {
			PerfectoUtils.reportMessage("No Coupon blocks found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Click on Register in Digtal Coupons modal window")
	public void clickOnRegisterInDigtalCouponsModalWindow() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();
		DigitalCouponsLoginPopupTestPage loginpopup = new DigitalCouponsLoginPopupTestPage();

		loginpopup.getLnkRegister().waitForPresent(4000);
		if (loginpopup.getLnkRegister().verifyPresent()) {
			loginpopup.getLnkRegister().click();
			PerfectoUtils.reportMessage("Modal Windpw pop up Register is clicked", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Modal Windpw pop up Register is not been clicked", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I validate coupons results count and category displays in My Selected tab")
	public void iValidateCouponsResultsCountAndCategoryDisplaysInMySelectedTab() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getLblCouponsresult().verifyPresent();
		String[] couponsResult = dc.getLblCouponsresult().getText().split(" ");
		String couponsResultQty = couponsResult[0];
		String couponsResultCat = couponsResult[3].replace("\"", "");

		dc.getDrpdwnFilterby().verifyPresent();
		String[] filter = PerfectoUtils.dropdownGetSelectedValue(dc.getDrpdwnFilterby()).trim().split(" ");
		String filterCat = filter[0];
		String filterQty = filter[1].replace("(", "").replace(")", "");

		if (couponsResultQty.equals(filterQty)) {
			PerfectoUtils.reportMessage("Coupons Results Qty is verified with Showing of Qty and Filtered category Qty",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons Results Qty is not same as Showing of Qty and Filtered category Qty",
					MessageTypes.Fail);
		}

		if (couponsResultCat.equals(filterCat)) {
			PerfectoUtils.reportMessage("Coupons Results Category is verified with Filtered category",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons Results Category is not same as Filtered category", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate coupons search results when searching for a coupon {0}")
	public void validateCouponsSearchResultsWhenSearchingForACoupon(String searchTerm) {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getTxtSearchcoupons().verifyPresent();
		dc.getTxtSearchcoupons().click();
		dc.getTxtSearchcoupons().sendKeys(searchTerm);
		dc.getBtnSearchicon().click();

		dc.getLblResultscount().verifyPresent();
		String[] searchResults = dc.getLblResultscount().getText().split(" ");
		String qty = searchResults[2];
		String actSearchTerm = searchResults[5].replace("\"", "");

		if (searchTerm.equalsIgnoreCase(actSearchTerm)) {
			PerfectoUtils.reportMessage(qty + " Coupons search results are displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons search results are not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate the selected coupon is available in My Selected tab")
	public void validateTheSelectedCouponIsAvailableInMySelectedTab() {
		DigitalCouponsSelectedSectionTestPage dcsel = new DigitalCouponsSelectedSectionTestPage();

		dcsel.waitForAjaxToComplete();
		int couponSize = dcsel.getLiCouponblocks().size();
		String selectedCoupon = getBundle().getString("selectedCoupon");
		boolean isAvailable = false;

		if (couponSize > 0) {
			PerfectoUtils.reportMessage(couponSize + " Coupons found in selected section..", MessageTypes.Pass);

			for (DigitalCouponBlocksInSelectedSection ele : dcsel.getLiCouponblocks()) {
				String couponName = ele.getLblCouponblockitemdescription().getText();
				if (PerfectoUtils.removeSpecialCharacters(selectedCoupon)
						.equalsIgnoreCase(PerfectoUtils.removeSpecialCharacters(couponName))) {
					PerfectoUtils.reportMessage("Selected Coupon is availble in My Selected tab", MessageTypes.Pass);
					isAvailable = true;
					break;
				}
			}
		} else {
			PerfectoUtils.reportMessage("No Coupons found in selected section..", MessageTypes.Fail);
		}

		if (!isAvailable) {
			PerfectoUtils.reportMessage("Selected coupon is not available in My Selected tab", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Clear the search and validate default Total Available coupons are loaded")
	public void clearTheSearchAndValidateDefaultTotalAvailableCouponsAreLoaded() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getLnkClear().verifyPresent();
		dc.getLnkClear().click();
		dc.waitForAjaxToComplete();
		dc.getLblCouponsresult().verifyVisible();
		dc.getDrpdwnFilterby().verifyVisible();
		dc.getLblResultscount().verifyNotPresent();

		if (dc.getLblCouponsresult().getText().contains("All")) {
			PerfectoUtils.reportMessage("Default Coupons page is loaded", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Default Coupons page is not loaded", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate Coupons sort by options {0} in Total Available tab")
	public void validateSortByOptionsinTotalAvailableTab(List<String> expSortOptions) {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();

		dc.getLblSortby().verifyPresent();
		dc.getLblAvailablesection().verifyPresent();
		dc.getLiSortoptions().get(0).verifyPresent();
		System.out.println(expSortOptions);

		for (QAFWebElement sortOption : dc.getLiSortoptions()) {
			String actSortOption = sortOption.getText().trim();

			if (expSortOptions.contains(actSortOption)) {
				PerfectoUtils.reportMessage("Expected Sort option " + actSortOption + " is available",
						MessageTypes.Info);
			} else {
				PerfectoUtils.reportMessage("Sort option " + actSortOption + " is not expected", MessageTypes.Fail);
			}
		}
	}

	@QAFTestStep(description = "Validate Coupons sort by options {0} in My Selected tab")
	public void validateSortByOptionsinMySelectedTab(List<String> expSortOptions) {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();
		DigitalCouponsSelectedSectionTestPage dcsel = new DigitalCouponsSelectedSectionTestPage();

		dcsel.getLblSortby().verifyPresent();
		dc.getLblSelectedsection().verifyPresent();
		dcsel.getLiSortoptions().get(0).verifyPresent();
		System.out.println(expSortOptions);

		for (QAFWebElement sortOption : dcsel.getLiSortoptions()) {
			String actSortOption = sortOption.getText().trim();

			if (expSortOptions.contains(actSortOption)) {
				PerfectoUtils.reportMessage("Expected Sort option " + actSortOption + " is available",
						MessageTypes.Info);
			} else {
				PerfectoUtils.reportMessage("Sort option " + actSortOption + " is not expected", MessageTypes.Fail);
			}
		}
	}

	@QAFTestStep(description = "Verify the slowness is not occurred past {0} coupons loaded")
	public void verifyTheSlownessIsNotOccurredPastCouponsLoaded(int minCount) {
		DigitalCouponsTestPage digcoupons = new DigitalCouponsTestPage();

		digcoupons.waitForAjaxToComplete();
		int totalCoupons = getBundle().getInt("totalCoupons");
		int availableCoupons = digcoupons.getLiCouponblocks().size();

		try {
			for (; availableCoupons <= totalCoupons;) {
				PerfectoUtils.scrolltoelement(digcoupons.getLiCouponblocks().get(availableCoupons - 1));
				digcoupons.getLiCouponblocks().get(availableCoupons + 14).waitForPresent(50000);
				availableCoupons = digcoupons.getLiCouponblocks().size();
			}
			PerfectoUtils.reportMessage("No Slowness while loading total coupons", MessageTypes.Pass);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Slowness occurred after loading " + availableCoupons
					+ " coupons in the total of " + totalCoupons + " Coupons", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Validate the main checkbox is deselected by deselecting any checkbox")
	public void validateTheMainCheckboxIsDeselectedByDeselectingAnyCheckbox() {
		DigitalCouponsSelectedSectionTestPage dc = new DigitalCouponsSelectedSectionTestPage();

		dc.getBtnAddtolistwhendisabled().waitForPresent(50000);
		dc.getChkAddallcouponstolist().verifyPresent();

		dc.getChkAddallcouponstolist().click();
		if (dc.getLiCouponblocks().get(0).getChkCouponblockitemcheckbox().isSelected()) {
			PerfectoUtils.reportMessage("CheckBoxes are selected");
			dc.getBtnAddtolist().verifyPresent();
		}

		dc.getLiCouponblocks().get(0).getChkCouponblockitemcheckbox().click();

		if (!dc.getLiCouponblocks().get(0).getChkCouponblockitemcheckbox().isSelected()) {
			PerfectoUtils.reportMessage("CheckBox 1 is deselected");

			if (!dc.getChkAddallcouponstolist().isSelected()) {
				PerfectoUtils.reportMessage("All Coupons CheckBox is deselected on deselecting single checkbox",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("All Coupons CheckBox is not deselected on deselecting single checkbox",
						MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("CheckBox 1 is not deselected", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I close mini list")
	public void iCloseMiniList() {
		MiniListTestPage mylist = new MiniListTestPage();

		mylist.getImgClosewindow().waitForPresent(50000);
		mylist.getImgClosewindow().click();
	}

	@QAFTestStep(description = "I verify whether the same coupons are not added to list again")
	public void iVerifySameCouponsNotAddedtoListAgain() {
		MiniListTestPage minilist = new MiniListTestPage();
		DigitalCouponsSelectedSectionTestPage dc = new DigitalCouponsSelectedSectionTestPage();

		selectAnywhereInAnyAvailableCouponInSelectedSection();
		selectAddToListButtonFromSelectedSection();
		iCloseMiniList();
		dc.getChkAddallcouponstolist().verifyPresent();
		dc.getChkAddallcouponstolist().click();
		selectAddToListButtonFromSelectedSection();

		int ItemCount = Integer.parseInt(PerfectoUtils.getIntCharacters(minilist.getLblItemcount().getText()));

		if (ItemCount == 1) {
			PerfectoUtils.reportMessage("Same coupons are not added to list again", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Same coupons are added to list again", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I verify only the savings dollar amount is displayed on the Savings to Date tab")
	public void iVerifyonlySavingsdollaramount() {
		DigitalCouponsTestPage dc = new DigitalCouponsTestPage();
		
	// Verifying Savings-to-Date tab
			if (dc.getLblSavingtoDateSection().isPresent()) {
				dc.getLnkSavingtodateLogin().click();
				String savingtodatesection = dc.getLblSavingtoDateCouponsQty().getText();
				PerfectoUtils.reportMessage("Navigated to the tab " + savingtodatesection, MessageTypes.Pass);

				String savingtodateamt = dc.getLblSavingtoDateAmount().getText();
				if(savingtodateamt.contains("$")){
					PerfectoUtils.reportMessage("Total Saving amount is " + savingtodateamt, MessageTypes.Pass);
				}else{
					PerfectoUtils.reportMessage("Savings dollar amount is not displayed on the Savings to Date tab. The displayed text is " + savingtodateamt, MessageTypes.Fail);
				}
			} else {
				PerfectoUtils.reportMessage("Unable to find Savings-to-Date tab", MessageTypes.Fail);
			}
	}

}
