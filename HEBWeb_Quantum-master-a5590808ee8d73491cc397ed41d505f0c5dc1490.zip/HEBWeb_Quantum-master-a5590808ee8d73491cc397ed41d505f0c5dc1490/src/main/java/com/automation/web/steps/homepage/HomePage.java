package com.automation.web.steps.homepage;

import static com.automation.web.commonutils.PerfectoUtils.reportMessage;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.components.CDPProductBlocks;
import com.automation.web.pages.Curbside.CurbsideHomePage;
import com.automation.web.pages.cart.CartTestPage;
import com.automation.web.pages.coupons.CouponsTestPage;
import com.automation.web.pages.coupons.DigitalCouponsLoginPopupTestPage;
import com.automation.web.pages.homepage.FooterTestPage;
import com.automation.web.pages.homepage.FrontdoorTestPage;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.login.LoginTestPage;
import com.automation.web.pages.make_ready.MakeReadyTestPage;
import com.automation.web.pages.myAccount.MyAccountPage;
import com.automation.web.pages.orderhistory.OrderstatusTestPage;
import com.automation.web.pages.pharmacy.PharmacyLandingTestPage;
import com.automation.web.pages.products.ArtifycakedetailaTestPage;
import com.automation.web.pages.products.CDPTestPage;
import com.automation.web.pages.products.CustomizeTestPage;
import com.automation.web.pages.products.CustomizebakeryTestPage;
import com.automation.web.pages.products.PDPTestPage;
import com.automation.web.pages.products.ShopTestPage;
import com.automation.web.pages.recipes.RecipedetailTestpage;
import com.automation.web.pages.recipes.RecipelandingTestPage;
import com.automation.web.pages.search.PdtsearchresultTestPage;
import com.automation.web.pages.storelocator.SelectStoreTestPage;
import com.automation.web.pages.weeklyads.WeeklyaddealsTestPage;
import com.automation.web.steps.CommonStepDef;
import com.automation.web.steps.Coupons.CouponsStepDef;
import com.automation.web.steps.MyList.MyList;
import com.automation.web.steps.Recipes.Recipes;
import com.automation.web.steps.Registration.Registration;
import com.automation.web.steps.myaccount.myaccountpage;
import com.automation.web.steps.paymentgateway.PaymentGatewayStepdef;
import com.automation.web.steps.weeklyads.WeeklyAdsStepDef;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

/*List of steps in HomePage

* I am on home page
* I am on home page for mobile
* I validate the new home page for logo, Search Bar and Store Finder
* I search {0} in Search Bar of HomePage
* I click on Store Finder
* I navigate back to new homepage
* I validate the new home page for Hero Images
* I click on Explore My Store Hero Image
* I click on Explore My Store Hero Image for mobile
* I click on CurbSide Image
* I see Explore my store context page
* I see Explore my store context page for mobile
* I see hebToYou.com site
* I validate the new home page for Catridges
* I click on WeeklyAd Catridge
* I click on Coupons Catridge
* I click on Pharmacy Catridge
* I click on Curbside Catridge
* I see Coupons page
* I see Pharmacy page
* I validate the new home page for Recipes
* I select a Recipe
* I see recipe details page of Explore My Store context
* I see weekly ads page
* I see front door page
* I navigate to external link specific to product {0}
* I see PDP page
* I validate Explore my store context url to have {0}
* I validate Ship To Home context url to have {0}
* I click weeklyad from instore context page
* I click coupons from instore context page
* I click pharmacy from instore context page
* I navigate back to instore context page
* I validate all the headers in the home page
* I navigate to instore home page
* I navigate to instore home page for mobile
* I click and validate {0} megamenu
* I mouser over on Fooddrink{0} megamenu
* I mouser over on homekitchen{0} megamenu
* I mousehover over on Pets{0} megamenu
* I mousehover over on healthnbeauty{0} megamenu
* I mousehover over on baby{0} megamenu
* I mousehover over on outdoornsports{0} megamenu
* I mousehover over on officeschool{0} megamenu
* I mousehover over on flowers{0} megamenu
* I mousehover over on more{0} megamenu
* I navigate to the footer
* I navigate to shop page
* I see all departments and its images
* I select a department
* I see the categories and its images
* I see the products and its images
* I mouse over my shopping list and navigate to login page
* I mouse over my shopping list and navigate to registration page
* I verify the Customer service options
* verify page header navigation
* I verify the Service list navigation
* I verify the Company Information options and navigation
* I navigate to categories {0} and subcategory {1}
* I select a product with customize button
* I validate the floral customize options
* I verify Best seller carousals
* Navigate to front door page
* I verify shop by type
* I see Sale carousal, primo picks, Our Brands
* I navigate to order status page
* I verify error message for invalid data
* Select Add to cart button from floral PDP
* I validate the properties of artify cake details page
* I enter product ID {0} and select Search button
* I see related product
* I select a category at search results page
* I verify the search result categories
* I select subcategory
* I verify subcategory product display page
* I click on see all from our brands
* I verify corresponding displayed page
* I click and verify on see all from primo picks
* Verify the estimated ship date in PDP
* I click on first online targetter
* I navigated to corresponding detail page
* I click on right arrow online targetter
* I click on last online targetter
* I validate the Bakery customize options
* I validate the Same Bakery with different customize options
* I select a product with customize button and update Qty and add to cart
* I select a store from Select a pickup store page with Zipcode {0}
* I see error message when enters quantity more than {0} for custom bakery product
* I Verify the estimated ship date in Cart
* I am on home page in minimized view
* Validate the Make ready catridge image, name and description
* Clicks on each make ready catridge and validate its landing page
* Verify Make ready catridge is not available
* Navigate to Pharmacy page from inStore homepage
* Validate delivery calender is not displayed with duplicate dates
* I select a {0} th product with customize button
* I validate the SPU customize options
* I select other picker and verify the price changes
* I validate selected store is displayed as my HEB store in Store flyout
* Navigate to Digital Coupons page as a cold user
* I click on the current store link

*/

public class HomePage {

	/**
	 * Verify the new Home Page is opened
	 */
	@QAFTestStep(description = "I am on home page")
	public synchronized static void iAmOnHomePage() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		System.out.println("Opening Application");
		PerfectoUtils.getDriver().manage().deleteAllCookies();
		PerfectoUtils.getDriver().get(getBundle().getString("env.baseurl"));
		PerfectoUtils.getDriver().manage().window().maximize();

		frontdoor.getFrontImgExploremystore().verifyPresent();
		frontdoor.getFrontImgFav().verifyPresent();
		getBundle().setProperty("myEmail", "Cold");

	}
	
	@QAFTestStep(description = "I navigate to our brand")
	public synchronized static void iNavigateToOurBrand() {
		String brandURL = PerfectoUtils.getDriver().getCurrentUrl() + getBundle().getString("products.ourbrandurl");
		PerfectoUtils.getDriver().get(brandURL);
	}
	
	@QAFTestStep(description = "I verify products that can be sold online")
	public synchronized static void iVerifyProductsSoldOnline() {
		CDPTestPage cdp = new CDPTestPage();
		
		cdp.getCdpLblSoldOnline().verifyPresent();
	}

	@QAFTestStep(description = "I am on home page for mobile")
	public synchronized static void iAmOnHomePageformobile() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		System.out.println("Opening Application");
		PerfectoUtils.getDriver().manage().deleteAllCookies();
		PerfectoUtils.getDriver().get(getBundle().getString("env.baseurl"));
		frontdoor.getFrontImgExploremystoremobile().waitForVisible(50000);
		frontdoor.getFrontImgExploremystoremobile().verifyPresent();
		getBundle().setProperty("myEmail", "Cold");

	}

	/**
	 * Validates HEB logo, Search Bar and Store finder
	 */
	@QAFTestStep(description = "I validate the new home page for logo, Search Bar and Store Finder")
	public void iValidateTheNewHomePageForLogoSearchBarAndStoreFinder() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontImgLogo().verifyPresent();
		frontdoor.getFrontEdtSearchbar().verifyPresent();
		frontdoor.getFrontLblStorefinder().verifyPresent();

	}

	/**
	 * Search a term in Front door page
	 */
	@QAFTestStep(description = "I search {0} in Search Bar of HomePage")
	public void iSearchInSearchBarOfHomePage(String searchTerm) {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontEdtSearchbar().verifyPresent();
		frontdoor.getFrontEdtSearchbar().click();
		frontdoor.getFrontEdtSearchbar().sendKeys(searchTerm);
		frontdoor.getFrontBtnSearch().click();
	}

	/**
	 * Clicking on Store Finder in New Home page
	 */
	@QAFTestStep(description = "I click on Store Finder")
	public void iClickOnStoreFinder() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontLblStorefinder().verifyPresent();
		frontdoor.getFrontLblStorefinder().click();

	}

	/**
	 * Navigates back to home page
	 */
	@QAFTestStep(description = "I navigate back to new homepage")
	public void iNavigateBackToNewHomepage() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontImgLogo().verifyPresent();
		frontdoor.getFrontImgLogo().click();
		frontdoor.getFrontImgLogo().verifyPresent();
	}

	/**
	 * Validate New Home Page Hero Images
	 */
	@QAFTestStep(description = "I validate the new home page for Hero Images")
	public void iValidateTheNewHomePageForHeroImages() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontImgCurbsideheroimg().verifyPresent();
		frontdoor.getFrontImgExploremystore().verifyPresent();
	}

	/**
	 * Click Explore my Store Hero Images
	 */
	@QAFTestStep(description = "I click on Explore My Store Hero Image")
	public static void iClickOnExploreMyStoreHeroImage() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontLblExploremystore().waitForPresent(5000);
		frontdoor.getFrontLblExploremystore().click();
		PerfectoUtils.reportMessage("Clicked on Explore My Store Hero Image", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I click on Explore My Store Hero Image for mobile")
	public static void iClickOnExploreMyStoreHeroImageformobile() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontImgExploremystoremobile().click();
		PerfectoUtils.reportMessage("Clicked on Explore My Store Hero Image", MessageTypes.Pass);
	}

	/**
	 * Click Explore my Store Hero Images
	 */
	@QAFTestStep(description = "I click on CurbSide Image")
	public void iClickOnCurbSideImage() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontLblCurbsidegetstarted().click();
		PerfectoUtils.reportMessage("Clicked on CurbSide Hero Image", MessageTypes.Pass);
	}

	/**
	 * Validate Explore my Store Page
	 */
	@QAFTestStep(description = "I see Explore my store context page")
	public static void iSeeExploreMyStoreContextPage() {
		InStoreHomePage instorehome = new InStoreHomePage();
		MyAccountPage myAccountPage = new MyAccountPage();

		try {
			instorehome.getHomeLblRegister().waitForPresent(30000);
			instorehome.getHomeLblLogin().waitForPresent(30000);
		} catch (Exception e) {
			myAccountPage.getMyAccountLnkUserName().waitForPresent(30000);
		}
		instorehome.getHomeBtnCart().verifyPresent();
	}

	@QAFTestStep(description = "I see Explore my store context page for mobile")
	public static void iSeeExploreMyStoreContextPageformobile() {
		InStoreHomePage instorehome = new InStoreHomePage();
		MyAccountPage myAccountPage = new MyAccountPage();

		instorehome.getHomeBtnCartMobile().verifyPresent();
	}

	/**
	 * Validate Curbside Page
	 */
	@QAFTestStep(description = "I see hebToYou.com site")
	public static void iSeeHebToYouComSite() {
		CurbsideHomePage curbsidehome = new CurbsideHomePage();

		PerfectoUtils.ClickContinueOnCogException();
		curbsidehome.getCurbsideLblGreeter().verifyPresent();
		// curbsidehome.getCurbsideImgMap().verifyPresent();
	}

	/**
	 * Validate New Home Page Catridge Images
	 */
	@QAFTestStep(description = "I validate the new home page for Catridges")
	public void iValidateTheNewHomePageForCatridges() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontImgCurbside().verifyPresent();
		frontdoor.getFrontImgCoupons().verifyPresent();
		frontdoor.getFrontImgWeeklyad().verifyPresent();
		frontdoor.getFrontImgPharmacy().verifyPresent();
	}

	/**
	 * Click on Weekly Ad Catridge
	 */
	@QAFTestStep(description = "I click on WeeklyAd Catridge")
	public void iClickOnWeeklyAdCatridge() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontImgWeeklyad().waitForPresent(3000);
		frontdoor.getFrontImgWeeklyad().click();
	}

	/**
	 * Click on Coupons Catridge
	 */
	@QAFTestStep(description = "I click on Coupons Catridge")
	public void iClickOnCouponsCatridge() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontImgCoupons().waitForPresent(3000);
		frontdoor.getFrontImgCoupons().click();
	}

	/**
	 * Click on Pharmacy Catridge
	 */
	@QAFTestStep(description = "I click on Pharmacy Catridge")
	public void iClickOnPharmacyCatridge() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontImgPharmacy().waitForPresent(3000);
		frontdoor.getFrontImgPharmacy().click();
	}

	/**
	 * Click on Curbside Catridge
	 */
	@QAFTestStep(description = "I click on Curbside Catridge")
	public void iClickOnCurbsideCatridge() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontImgCurbside().waitForPresent(3000);
		frontdoor.getFrontImgCurbside().click();
	}

	/**
	 * Validate if Coupons page is displayed
	 */
	@QAFTestStep(description = "I see Coupons page")
	public void iSeeCouponsPage() {
		CouponsTestPage couponsPage = new CouponsTestPage();

		couponsPage.getLblCouponsheader().waitForPresent(5000);
		couponsPage.getLblCouponsheader().verifyPresent();
	}

	/**
	 * Validate if Coupons page is displayed
	 */
	@QAFTestStep(description = "I see Pharmacy page")
	public void iSeePharmacyPage() {
		PharmacyLandingTestPage pharmacyPage = new PharmacyLandingTestPage();

		pharmacyPage.getPharmacyLblHeader().waitForPresent(5000);
		pharmacyPage.getPharmacyLblHeader().verifyPresent();
	}

	/**
	 * Validate if Recipes are available
	 */
	@QAFTestStep(description = "I validate the new home page for Recipes")
	public void iValidateTheNewHomePageForRecipes() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		PerfectoUtils.scrolltoelement(frontdoor.getFrontLblRecipe());
		frontdoor.getFrontLblRecipe().waitForPresent();
		frontdoor.getFrontLblRecipe().verifyPresent();
		frontdoor.getFrontLiRecipeimg().get(0).verifyPresent();
	}
	
	@QAFTestStep(description = "I verify the functionality of Home Page Recipes Section")
	public void functionalityOfHomePageRecipesSection() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		
		PerfectoUtils.scrolltoelement(frontdoor.getFrontLblRecipe());
		frontdoor.getFrontLblRecipe().verifyPresent();
		int recipesList = frontdoor.getFrontLiRecipeimg().size();
		if(recipesList == 8){
			PerfectoUtils.reportMessage("8 Recipes products are displayed", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("8 Recipes products are not displayed", MessageTypes.Fail);
		}
		frontdoor.getFrontBtnExplorerecipes().verifyPresent();
	}
	
	@QAFTestStep(description = "I verify the functionality of Home Page Search Box")
	public void functionalityOfHomePageSearchBox() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		InStoreHomePage instore = new InStoreHomePage();
		
		frontdoor.getFrontEdtSearchbar().sendKeys(getBundle().getString("searchproducts.product.specialchar"));
		frontdoor.getFrontBtnSearchToolTip().verifyPresent();
		frontdoor.getFrontBtnSearch().click();
		String searchedText = instore.getHomeLblSearchresultsfound().getText();
		if(searchedText.contains(getBundle().getString("searchproducts.product.specialchar"))){
			PerfectoUtils.reportMessage("Able to search using Special characters", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Not able to search using Special characters", MessageTypes.Fail);
		}
	}

	/**
	 * Click on Recipe Image
	 */
	@QAFTestStep(description = "I select a Recipe")
	public void iSelectARecipe() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontLiRecipeimg().get(0).verifyPresent();
		String recipeName = frontdoor.getFrontLiRecipeimg().get(0).getAttribute("title");
		frontdoor.getFrontLiRecipeimg().get(0).click();
		PerfectoUtils.reportMessage("Selected Recipe" + recipeName, MessageTypes.Pass);
	}

	/**
	 * Validate Recipe details page
	 */
	@QAFTestStep(description = "I see recipe details page of Explore My Store context")
	public void iSeeRecipeDetailsPageOfExploreMyStorecontext() {
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();

		recipedetail.getRecipedetailLblRecipename().waitForPresent(3000);
		PerfectoUtils.reportMessage("Viewing Recipe" + recipedetail.getRecipedetailLblRecipename().getText(),
				MessageTypes.Pass);
		recipedetail.getRecipedetailLblIngredientstitle().verifyPresent();
	}

	/**
	 * Validate if Weekly Ad's page is displayed
	 */
	@QAFTestStep(description = "I see weekly ads page")
	public void iSeeWeeklyAdsPage() {
		WeeklyaddealsTestPage weeklyads = new WeeklyaddealsTestPage();
		weeklyads.getLblPageheader().verifyPresent();
	}

	/**
	 * Validate Front door page is displayed
	 */
	@QAFTestStep(description = "I see front door page")
	public void iSeeFrontDoorPage() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontImgCurbsideheroimg().verifyPresent();
		frontdoor.getFrontImgExploremystore().verifyPresent();
	}

	/**
	 * Launch the product path url
	 */
	@QAFTestStep(description = "I navigate to external link specific to product {0}")
	public void iNavigateToExternalLinkSpecificToProduct(String productPath) {

		PerfectoUtils.getDriver().get(productPath);
	}

	/**
	 * Validate Front door page is displayed
	 */
	@QAFTestStep(description = "I see PDP page")
	public void iSeePDPPage() {
		PDPTestPage pdppage = new PDPTestPage();
		String productName;

		pdppage.getPdpLblName().waitForPresent(3000);
		productName = pdppage.getPdpLblName().getText();
		pdppage.getPdpLblProductdesc().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to PDP page of product: " + productName, MessageTypes.Pass);
	}

	/**
	 * Validate Explore my Store Page URL
	 */
	@QAFTestStep(description = "I validate Explore my store context url to have {0}")
	public void iValidateExploreMyStoreContextUrlToHave(String keyWord) {

		String URL = PerfectoUtils.getDriver().getCurrentUrl();

		if (URL.contains(keyWord)) {
			PerfectoUtils.reportMessage("Explore My Store URL contains the keyword " + keyWord, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Explore My Store URL does not contain the keyword " + keyWord,
					MessageTypes.Fail);
		}
	}

	/**
	 * Validate Explore my Store Page URL
	 */
	@QAFTestStep(description = "I validate Ship To Home context url to have {0}")
	public void iValidateShipToHomeContextUrlToHave(String keyWord) {

		String URL = PerfectoUtils.getDriver().getCurrentUrl();

		if (URL.contains(keyWord)) {
			PerfectoUtils.reportMessage("Ship To Home URL contains the keyword " + keyWord, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Ship To Home URL does not contain the keyword " + keyWord, MessageTypes.Fail);
		}
	}

	/**
	 * Click on Weekly Ad Catridge
	 */
	@QAFTestStep(description = "I click weeklyad from instore context page")
	public void iClickOnWeeklyAdCatridgeFromInstoreContextPage() {
		InStoreHomePage instore = new InStoreHomePage();

		instore.getHomeLblHeaderweeklyad().waitForPresent(3000);
		instore.getHomeLblHeaderweeklyad().click();
	}

	/**
	 * Click on Coupons Catridge
	 */
	@QAFTestStep(description = "I click coupons from instore context page")
	public void iClickOnCouponsFromInstoreContextPage() {
		InStoreHomePage instore = new InStoreHomePage();

		instore.waitForPageToLoad();
		instore.waitForAjaxToComplete();
		instore.getHomeLblDigitalcoupons().waitForPresent(3000);
		instore.getHomeLblDigitalcoupons().click();
	}

	/**
	 * Click on Pharmacy Catridge
	 */
	@QAFTestStep(description = "I click pharmacy from instore context page")
	public void iClickOnPharmacyFromInstoreContextPage() {
		InStoreHomePage instore = new InStoreHomePage();

		instore.getHomeLblHeaderpharmacy().waitForPresent(3000);
		instore.getHomeLblHeaderpharmacy().click();
	}

	/**
	 * Navigate back to instore context page
	 */
	@QAFTestStep(description = "I navigate back to instore context page")
	public void iNavigateBackToInstoreContextPage() {

		PerfectoUtils.getDriver()
				.get("https://cert-selling1.heb.com/explore?exp=instoreview&cid=H-O-HP-BG-plan-your-shop");
	}

	@QAFTestStep(description = "I validate all the headers in the home page")
	public void ivalidatealltheheadersinthehomepage() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();

		try {

			instorehome.getHomeLogo().verifyPresent();
			instorehome.getHomeLblHeaderweeklyad().verifyPresent();
			instorehome.getHomeBtnSearch().verifyPresent();
			instorehome.getHomeLblHeaderpharmacy().verifyPresent();
			instorehome.getHomeLblHeaderrecipe().verifyPresent();
			instorehome.getHomeLblShoppinglistfromheader().verifyPresent();
			instorehome.getHomeBtnCart().verifyPresent();
			instorehome.getHomeLblLogin().verifyPresent();

			System.out.println("All elements are displayed  in the header");

		} catch (Exception e) {
			System.out.println("All elements are not displayed properly");
		}
	}

	/*
	 * @QAFTestStep(description = "I navigate to Instore home page") public void
	 * inavigatetoInstorehomepage() { FrontdoorTestPage frontdoor = new
	 * FrontdoorTestPage(); <<<<<<< HEAD ======= <<<<<<< HEAD >>>>>>>
	 * 369e0183cc909b6fb1b9640994757428e42d5fe0 if
	 * (frontdoor.getFrontImgExploremystore().verifyPresent()) {
	 * frontdoor.getFrontImgExploremystore().click(); System.out.println(
	 * "Navigated to Instore home page"); } else { <<<<<<< HEAD
	 * System.out.println("not navigated to instore home page"); } } =======
	 * System.out.println("not navigated to instore home page"); } }
	 * 
	 * ======= if(frontdoor.getFrontImgExploremystore().verifyPresent()){
	 * frontdoor.getFrontImgExploremystore().click(); System.out.println(
	 * "Navigated to Instore home page"); } else{ System.out.println(
	 * "not navigated to instore home page"); } }
	 */

	/**
	 * Verify the instore Home Page is opened
	 */
	@QAFTestStep(description = "I navigate to instore home page")
	public static void iNavigateToInstoreHomePage() {
		FrontdoorTestPage front = new FrontdoorTestPage();

		iClickOnExploreMyStoreHeroImage();
		iSeeExploreMyStoreContextPage();
		front.getFrontImgFav().verifyPresent();
	}

	@QAFTestStep(description = "I navigate to instore home page for mobile")
	public static void iNavigateToInstoreHomePageformobile() {

		iClickOnExploreMyStoreHeroImageformobile();
		iSeeExploreMyStoreContextPageformobile();
	}

	/**
	 * Clicking and verifying the megamenu
	 */

	@QAFTestStep(description = "I click and validate {0} megamenu")
	public void iClickAndValidateMegamenu(List<String> megamenuhomenkitchen) {
		InStoreHomePage instore = new InStoreHomePage();
		ShopTestPage shopPage = new ShopTestPage();

		for (String megamenu : megamenuhomenkitchen) {
			List<String> megamenuname = new ArrayList<>();
			List<String> pageSubCat = new ArrayList<>();

			String submenu = megamenu;
			if (megamenu.contains("&")) {
				submenu = megamenu.replace("&", "and");
			}
			System.out.println(megamenu);
			if (megamenu.equalsIgnoreCase("Baby")) {
				
				for (QAFWebElement element : instore.getHomeLblBaby()
						.findElements("shop.li.lbl.subcategorymegamenuchild")) {
					String menu = element.getText().toUpperCase().trim();
					if (menu.contains("‑")) {
						menu = menu.replace("‑", "");
					} else if (menu.contains("-")) {
						menu = menu.replace("-", "");
					}
					if (!menu.equals("Baby"))
						megamenuname.add(menu);
				}
				instore.getHomeLblBaby().click();
				
			} else if (megamenu.equalsIgnoreCase("Flowers")) {
				PerfectoUtils.reportMessage("Make Ready page changes are displayed when clicking on Flowers!!");
				break;
			} else {
				shopPage.getMainCategory(megamenu).waitForPresent(5000);
				shopPage.getMainCategory(megamenu).click();
				PerfectoUtils.mouseover(shopPage.getMainCategory(megamenu));
				for (QAFWebElement element : shopPage.getMainCategory(megamenu)
						.findElements("shop.li.lbl.subcategorymegamenuchild")) {
					String menu = element.getText().toUpperCase().trim();
					if (menu.contains("‑")) {
						menu = menu.replace("‑", "");
					} else if (menu.contains("-")) {
						menu = menu.replace("-", "");
					}
					if (!menu.equals(""))
						megamenuname.add(menu);
				}

			}
			PerfectoUtils.reportMessage("Clicked:" + megamenu, MessageTypes.Pass);

			String pgtitle = instore.getHomeLblMegamenutitle().getText();
			if (pgtitle.contains(submenu)) {
				PerfectoUtils.reportMessage("Corresponding megamenu detail page is displayed", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Corresponding megamenu detail page is not displayed", MessageTypes.Fail);
			}

			for (QAFWebElement element : shopPage.getShopLiLblSubcategories()) {
				String text = element.getText();
				if (text.contains("‑")) {
					text = text.replace("‑", "");
				} else if (text.contains("-")) {
					text = text.replace("-", "");
				}
				pageSubCat.add(text.substring(0, text.indexOf("(")).trim());
			}
			System.out.println(pageSubCat);
			System.out.println(megamenuname);
			if (megamenuname.containsAll(pageSubCat)) {
				PerfectoUtils.reportMessage(
						"All megamenu sub categories are available in the first category landing page",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage(
						"All megamenu sub categories are not available in the first category landing page",
						MessageTypes.Fail);
			}

		}

	}

	@QAFTestStep(description = "I mouser over on Fooddrink{0} megamenu")
	public void iMouserOverOnFooddrinkMegamenu(String megamenu) {
		InStoreHomePage instore = new InStoreHomePage();

		PerfectoUtils.mouseover(instore.getHomeListMegamenulbl(megamenu));
		List<String> megamenuname = new ArrayList<>();
		List<QAFWebElement> hovertext = instore.getHomeLblFoodndrinksubmenu();
		for (QAFWebElement temp : hovertext) {

			String menu = temp.getText();
			if (menu.contains("‑")) {
				menu = menu.replace("‑", "");
			} else if (menu.contains("-")) {
				menu = menu.replace("-", "");
			}
			megamenuname.add(menu);
			System.out.println(megamenuname);
		}
		List<String> submenuname = ConfigurationManager.getBundle().getList("FoodandDrinks.submenu");
		System.out.println(submenuname);
		if (submenuname.equals(megamenuname)) {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I mouser over on homekitchen{0} megamenu")
	public void iMouserOverOnHomekitchenMegamenu(String megamenu) {
		InStoreHomePage instore = new InStoreHomePage();

		PerfectoUtils.mouseover(instore.getHomeListMegamenulbl(megamenu));
		List<String> megamenuname = new ArrayList<>();
		List<QAFWebElement> hovertext = instore.getHomeLblHomenkitchenmenu();

		for (QAFWebElement temp : hovertext) {
			megamenuname.add(temp.getText().replace("‑", "-"));
			System.out.println(megamenuname);
		}
		List submenuname = ConfigurationManager.getBundle().getList("Homekitchen.submenu");
		System.out.println(submenuname);
		// submenuname.remove("-");
		if (submenuname.equals(megamenuname)) {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I mousehover over on Pets{0} megamenu")
	public void iMousehoverOverOnPetsMegamenu(String megamenu) {
		InStoreHomePage instore = new InStoreHomePage();

		PerfectoUtils.mouseover(instore.getHomeListMegamenulbl(megamenu));
		List<String> megamenuname = new ArrayList<>();
		List<QAFWebElement> hovertext = instore.getHomeLblPetsubmenu();

		for (QAFWebElement temp : hovertext) {
			megamenuname.add(temp.getText());
			System.out.println(megamenuname);
		}
		List<String> submenuname = ConfigurationManager.getBundle().getList("Pets.submenu");
		System.out.println(submenuname);
		if (submenuname.equals(megamenuname)) {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I mousehover over on healthnbeauty{0} megamenu")
	public void iMousehoverOverOnHealthnbeautyMegamenu(String megamenu) {
		InStoreHomePage instore = new InStoreHomePage();

		PerfectoUtils.mouseover(instore.getHomeListMegamenulbl(megamenu));
		List<String> megamenuname = new ArrayList<>();
		List<QAFWebElement> hovertext = instore.getHomeLblHealthnbeauty();

		for (QAFWebElement temp : hovertext) {
			megamenuname.add(temp.getText());
			System.out.println(megamenuname);
		}
		List<String> submenuname = ConfigurationManager.getBundle().getList("Healthnbeauty.submenu");
		System.out.println(submenuname);
		if (submenuname.equals(megamenuname)) {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I mousehover over on baby{0} megamenu")
	public void iMousehoverOverOnBabyMegamenu(String megamenu) {
		InStoreHomePage instore = new InStoreHomePage();

		PerfectoUtils.mouseover(instore.getHomeListMegamenulbl(megamenu));
		List<String> megamenuname = new ArrayList<>();
		List<QAFWebElement> hovertext = instore.getHomeLblBabyntoy();

		for (QAFWebElement temp : hovertext) {
			megamenuname.add(temp.getText());
			System.out.println(megamenuname);
		}
		List submenuname = ConfigurationManager.getBundle().getList("Baby.submenu");
		System.out.println(submenuname);
		if (submenuname.equals(megamenuname)) {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is not displayed", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I mousehover over on outdoornsports{0} megamenu")
	public void iMousehoverOverOnOutdoornSportsMegamenu(String megamenu) {
		InStoreHomePage instore = new InStoreHomePage();

		PerfectoUtils.mouseover(instore.getHomeListMegamenulbl(megamenu));
		List<String> megamenuname = new ArrayList<>();
		List<QAFWebElement> hovertext = instore.getHomeLblOutdoornSports();

		for (QAFWebElement temp : hovertext) {
			megamenuname.add(temp.getText());
			System.out.println(megamenuname);
		}
		List submenuname = ConfigurationManager.getBundle().getList("OutdoornSports.submenu");
		System.out.println(submenuname);
		if (submenuname.equals(megamenuname)) {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is not displayed", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I mousehover over on officeschool{0} megamenu")
	public void iMousehoverOverOnOfficeschoolMegamenu(String megamenu) {
		InStoreHomePage instore = new InStoreHomePage();

		PerfectoUtils.mouseover(instore.getHomeListMegamenulbl(megamenu));
		List<String> megamenuname = new ArrayList<>();
		List<QAFWebElement> hovertext = instore.getHomeLblOfficeandschool();

		for (QAFWebElement temp : hovertext) {
			megamenuname.add(temp.getText().replace("‑", "-"));
			System.out.println(megamenuname);
		}
		List submenuname = ConfigurationManager.getBundle().getList("Officenschools.submenu");
		System.out.println(submenuname);
		// submenuname.remove("-");
		if (submenuname.equals(megamenuname)) {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I mousehover over on flowers{0} megamenu")
	public void iMousehoverOverOnFlowersMegamenu(String megamenu) {
		InStoreHomePage instore = new InStoreHomePage();

		PerfectoUtils.mouseover(instore.getHomeListMegamenulbl(megamenu));
		List<String> megamenuname = new ArrayList<>();
		List<QAFWebElement> hovertext = instore.getHomeLblFlowers();

		for (QAFWebElement temp : hovertext) {
			megamenuname.add(temp.getText().replace("‑", "-"));
			System.out.println(megamenuname);
		}
		List submenuname = ConfigurationManager.getBundle().getList("Flowers.submenu");
		System.out.println(submenuname);
		// submenuname.remove("-");
		if (submenuname.equals(megamenuname)) {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I mousehover over on more{0} megamenu")
	public void iMousehoverOverOnMoreMegamenu(String megamenu) {
		InStoreHomePage instore = new InStoreHomePage();

		PerfectoUtils.mouseover(instore.getHomeListMegamenulbl(megamenu));
		List<String> megamenuname = new ArrayList<>();
		List<QAFWebElement> hovertext = instore.getHomeLblMore();

		for (QAFWebElement temp : hovertext) {
			megamenuname.add(temp.getText().replace("‑", "-"));
			System.out.println(megamenuname);
		}
		List submenuname = ConfigurationManager.getBundle().getList("More.submenu");
		System.out.println(submenuname);
		// submenuname.remove("-");
		if (submenuname.equals(megamenuname)) {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Corresponding megamenu detail page is not displayed", MessageTypes.Fail);
		}
	}

	// @QAFTestStep(description = "I navigate to the footer")
	// public void inavigatetothefooter() {
	//
	// PerfectoUtils.scrolltoelement(element);
	//
	// }
	@QAFTestStep(description = "I navigate to the footer")
	public void inavigatetothefooter() {
		FooterTestPage footer = new FooterTestPage();

		PerfectoUtils.scrolltoelement(footer.getLblfooter());

	}

	@QAFTestStep(description = "I navigate to shop page")
	public void iNavigateToShopPage() {
		InStoreHomePage instore = new InStoreHomePage();
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontImgLogo().verifyPresent();
		frontdoor.getFrontImgLogo().click();
		iClickOnExploreMyStoreHeroImage();
		iSeeExploreMyStoreContextPage();
		frontdoor.getFrontImgFav().verifyPresent();
		// Clicking on start shopping
		PerfectoUtils.mouseoverandclick(instore.getHomeImgCart(), instore.getHomeBtnCartstartshopping());
	}

	@QAFTestStep(description = "I see all departments and its images")
	public void iSeeAllDepartmentsAndItsImages() {
		ShopTestPage shopPage = new ShopTestPage();

		List<String> strAllDepartmnt = getBundle().getList("shopPage.department");

		for (String department : strAllDepartmnt) {
			shopPage.getFirstCategory(department).verifyPresent();
			shopPage.getFirstCategoryImg(department).verifyPresent();
		}
	}

	@QAFTestStep(description = "I select a department")
	public void iSelectADepartment() {
		ShopTestPage shopPage = new ShopTestPage();

		List<String> strAllDepartmnt = getBundle().getList("shopPage.department");
		shopPage.getFirstCategory(strAllDepartmnt.get(0)).click();
	}

	@QAFTestStep(description = "I see the categories and its images")
	public void iSeeTheCategoriesAndItsImages() {
		ShopTestPage shopPage = new ShopTestPage();

		PerfectoUtils.scrolltoelement(shopPage.getLblShopbyType());
		int departSize = shopPage.getshopLblDepartments().size();
		int departimgSize = shopPage.getshopImgSubcategory().size();

		if (departimgSize == departSize) {
			PerfectoUtils.reportMessage(
					"No of Sub Categories displayed: " + departSize + " And its all images are displayed",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("No of Sub Categories displayed: " + departSize
					+ " No of Sub Category images displayed: " + departimgSize, MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I see the products and its images")
	public void iSeeTheProductsAndItsImages() {
		CDPTestPage cdppage = new CDPTestPage();
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontImgFav().verifyPresent();
		for (CDPProductBlocks ChooseProduct : cdppage.getCdpLiProductblock()) {

			ChooseProduct.getCdpTxtProductname().isPresent();
			ChooseProduct.getCdpImgProductImage().isPresent();
			break;
		}

	}

	/**
	 * Mouse over my shopping list and navigate to login page
	 */

	@QAFTestStep(description = "I mouse over my shopping list and navigate to login page")
	public synchronized void iMouseovernavigatetologinpage() {
		InStoreHomePage instorehome = new InStoreHomePage();

		instorehome.getHomeLblLogin().waitForPresent(7000);
		PerfectoUtils.mouseoverandclick(instorehome.getHomeLnkMylist(), instorehome.getHomeLnkIalreadyhaveaccount());
	}

	/**
	 * Mouse over my shopping list and navigate to Create a New List page
	 */

	@QAFTestStep(description = "I mouse over my shopping list and navigate to Create a New List page")
	public synchronized void iMouseovernavigatetocreateanewlistpage() {
		InStoreHomePage instorehome = new InStoreHomePage();

		instorehome.getHomeLblLogin().waitForPresent(5000);
		PerfectoUtils.mouseoverandclick(instorehome.getHomeLnkCreateanewlist(), instorehome.getHomeLnkCreateanewlist());
	}

	@QAFTestStep(description = "I verify My Lists got displayed")
	public synchronized void iVerifyMyListsgotdisplayed() {
		InStoreHomePage instorehome = new InStoreHomePage();

		instorehome.getHomeLnkMylists().waitForPresent(5000);
		if (instorehome.getHomeLnkMylists().isDisplayed()) {
			String strMyList = instorehome.getHomeLnkMylists().getText();
			PerfectoUtils.reportMessage("My Lists is displayed as " + strMyList, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("My Lists is not displayed..", MessageTypes.Fail);
		}

	}

	/**
	 * Mouse over my shopping list and navigate to registration page
	 */
	@QAFTestStep(description = "I mouse over my shopping list and navigate to registration page")
	public synchronized void iMouseovernavigatetoregistrationpage() {
		InStoreHomePage instorehome = new InStoreHomePage();
		instorehome.getHomeLnkMylist().waitForPresent(5000);
		PerfectoUtils.mouseoverandclick(instorehome.getHomeLnkMylist(),
				instorehome.getHomeLnkCreateaccountfromshoppinglist());
	}

	@QAFTestStep(description = "I mouse over my shopping list and navigate to Login page")
	public synchronized void iMouseovernavigatetoLoginpage() {
		InStoreHomePage instorehome = new InStoreHomePage();
		instorehome.getHomeLnkMylist().waitForPresent(5000);
		PerfectoUtils.mouseoverandclick(instorehome.getHomeLnkMylist(), instorehome.getHomeLnkIalreadyhaveaccount());
	}

	@QAFTestStep(description = "I verify the Customer service options")
	public void iverifytheCustomerserviceoptions() {
		FooterTestPage footer = new FooterTestPage();
		HomePage obj = new HomePage();

		footer.getFooterLnkContactus().verifyPresent();
		footer.getFooterLnkCouponpolicy().verifyPresent();
		footer.getFooterLnkFaq().verifyPresent();
		footer.getFooterLnkProductrecall().verifyPresent();
		footer.getFooterLnkRefundpolicy().verifyPresent();
		footer.getFooterLnkSitemap().verifyPresent();

		footer.getFooterLnkContactus().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkCouponpolicy().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkFaq().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkProductrecall().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkRefundpolicy().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkSitemap().click();
		obj.verifypageheadernavigation();

	}

	@QAFTestStep(description = "verify page header navigation")
	public void verifypageheadernavigation() {
		String pghdr = null;
		FooterTestPage footer = new FooterTestPage();
		try {
			footer.getLblheader().waitForPresent(3000);
			footer.getLblheader().verifyPresent();
			pghdr = footer.getLblheader().getText();
		} catch (Exception e) {
			footer.getLblheader1().verifyPresent();
			pghdr = footer.getLblheader1().getText();
		}

		System.out.println(pghdr);
		PerfectoUtils.reportMessage("Page header is displayed as " + pghdr, MessageTypes.Info);
		PerfectoUtils.getDriver().navigate().back();

	}

	@QAFTestStep(description = "I verify the Service list navigation")
	public void iverifytheServicelistnavigation() {
		FooterTestPage footer = new FooterTestPage();
		HomePage obj = new HomePage();

		footer.getFooterLnkBussinesscentre().verifyPresent();
		// footer.getFooterLnkCurbside().verifyPresent();
		footer.getFooterLnkGrocerydelivery().verifyPresent();
		footer.getFooterLnkSth().verifyPresent();
		footer.getFooterLnkOptical().verifyPresent();
		footer.getFooterLnkRestaurants().verifyPresent();
		footer.getFooterLnkTicketsale().verifyPresent();
		footer.getFooterLnkWeeklyaddcoupons().verifyPresent();

		footer.getFooterLnkBussinesscentre().click();
		obj.verifypageheadernavigation();

		// footer.getFooterLnkCurbside().click();
		// obj.verifypageheadernavigation();

		footer.getFooterLnkGrocerydelivery().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkSth().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkOptical().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkRestaurants().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkTicketsale().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkWeeklyaddcoupons().click();
		obj.verifypageheadernavigation();
	}

	@QAFTestStep(description = "I verify the Company Information options and navigation")
	public void iverifytheCompanyInformationoptionsandnavigation() {
		FooterTestPage footer = new FooterTestPage();
		HomePage obj = new HomePage();

		footer.getFooterLnkAboutus().verifyPresent();
		footer.getFooterLnkCareers().verifyPresent();
		footer.getFooterLnkCommunity().verifyPresent();
		footer.getFooterLnkEnvironmentalresponsibility().verifyPresent();
		footer.getFooterLnkPartners().verifyPresent();
		footer.getFooterLnkPressreleases().verifyPresent();
		footer.getFooterLnkSuppliers().verifyPresent();
		footer.getFooterLnkTvcommercials().verifyPresent();
		footer.getFooterLnkCentralmarket().verifyPresent();
		footer.getFooterLnkHebmexico().verifyPresent();

		footer.getFooterLnkAboutus().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkCareers().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkCommunity().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkEnvironmentalresponsibility().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkPartners().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkPressreleases().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkSuppliers().click();
		obj.verifypageheadernavigation();

		footer.getFooterLnkTvcommercials().click();
		obj.verifypageheadernavigation();

		/*
		 * New tab handling for central market
		 */
		String currenthandl = PerfectoUtils.getDriver().getWindowHandle();
		footer.getFooterLnkCentralmarket().click();
		Set<String> winhandles = PerfectoUtils.getDriver().getWindowHandles();

		for (String handle : winhandles) {
			if (!handle.equals(currenthandl)) {
				PerfectoUtils.getDriver().switchTo().window(handle);
				footer.lblheaderCentralmarket().verifyPresent();
				PerfectoUtils.reportMessage("page title is displayed", MessageTypes.Info);
				PerfectoUtils.getDriver().switchTo().window(currenthandl);
			}
		}

		//
		// footer.getFooterLnkHebmexico().click();
		// Set<String>winhandles2 =
		// PerfectoUtils.getDriver().getWindowHandles();
		//
		// for(String newhandle:winhandles2){
		// if(!handle.equals(currenthandl)){
		// PerfectoUtils.getDriver().switchTo().window(handle);
		// footer.getLblheader2().verifyPresent();
		// PerfectoUtils.reportMessage("page title is displayed",
		// MessageTypes.Info);
		// PerfectoUtils.getDriver().switchTo().window(currenthandl);
		//
	}

	@QAFTestStep(description = "I navigate to categories {0} and subcategory {1}")
	public void iNavigateToCategoriesAndSubcategory(String firstCat, String subCat) {
		ShopTestPage shopPage = new ShopTestPage();

		shopPage.getMainCategory(firstCat).waitForPresent(5000);
		shopPage.getMainCategory(firstCat).click();
		shopPage.getGetCdpcategories(subCat).waitForPresent(5000);
		shopPage.getGetCdpcategories(subCat).click();
	}

	@QAFTestStep(description = "I select a product with customize button")
	public void iSelectAProductWithCustomizeButton() {
		CDPTestPage cdppage = new CDPTestPage();

		try {
			cdppage.getcdpBtnCustomize().get(0).waitForPresent(3000);
			PerfectoUtils.scrolltoelement(cdppage.getcdpBtnCustomize().get(0));
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Customize button is not available", MessageTypes.Info);
		}

		cdppage.getcdpBtnCustomize().get(0).verifyPresent();
		cdppage.getcdpBtnCustomize().get(0).click();
	}

	@QAFTestStep(description = "I validate the floral customize options")
	public static void iValidateTheFloralCustomizeOptions() {
		CustomizeTestPage customizepage = new CustomizeTestPage();
		FrontdoorTestPage front = new FrontdoorTestPage();

		front.getFrontImgFav().verifyPresent();
		// Validating Select delivery
		customizepage.getCustomizeLblSelectdelivery().verifyPresent();
		customizepage.getCustomizeBtnDelivery().verifyPresent();
		customizepage.getCustomizeBtnStorepickup().verifyPresent();
		customizepage.getCustomizeTxtZipcode().verifyPresent();
		customizepage.getCustomizeTxtZipcode().click();
		customizepage.getCustomizeTxtZipcode().sendKeys(getBundle().getString("shippingaddress1.zipcode"));
		PerfectoUtils.reportMessage("Delivery Zipcode is Entered", MessageTypes.Pass);
		customizepage.getCustomizeBtnStorepickup().click();

		// Validating Bouquet Quality
		customizepage.getCustomizeLblBqtquality().verifyPresent();
		PerfectoUtils.reportMessage(
				"Current Bouquet Quality: " + customizepage.getCustomizeLblBqtqualityoption().getText(),
				MessageTypes.Info);

		// Validating Rose Primary Color
		PerfectoUtils.scrolltoelement(customizepage.getCustomizeLblPrimarycolor());
		customizepage.getCustomizeLblPrimarycolor().verifyPresent();
		PerfectoUtils.scrolltoelement(customizepage.getCustomizeLblPrimarycoloroptions().get(0));
		customizepage.getCustomizeLblPrimarycoloroptions().get(0).click();
		PerfectoUtils.reportMessage("Rose Primary Color has selected as: "
				+ customizepage.getCustomizeLblPrimarycoloroptions().get(0).getText(), MessageTypes.Pass);

		/*
		 * if (customizepage.getCustomizeLblSecondarycoloroptions().get(1).
		 * isPresent()) {
		 * customizepage.getCustomizeLblSecondarycoloroptions().get(1).click();
		 * PerfectoUtils.reportMessage("Rose Primary Color has selected as: " +
		 * customizepage.getCustomizeLblSecondarycoloroptions().get(1).getText()
		 * , MessageTypes.Pass); }
		 */
		// Validating Enter Free Card Message
		PerfectoUtils.scrolltoelement(customizepage.getCustomizeLblMessage());
		customizepage.getCustomizeLblMessage().verifyPresent();
		customizepage.getCustomizeTxtMessage().sendKeys(getBundle().getString("floralCustomize.cardMsg"));
		PerfectoUtils.reportMessage("Entered Card message!", MessageTypes.Pass);

		// Validating Delivery date
		PerfectoUtils.scrolltoelement(customizepage.getCustomizeLblDeliverydate());
		customizepage.getCustomizeLblDeliverydate().verifyPresent();
		customizepage.getCustomizeBtnDeliverydatecalender().verifyPresent();
		customizepage.getCustomizeBtnDeliverydatecalender().click();
		int calenderAvailabledateSize = customizepage.getCustomizeBtnCalenderdatepicker().size();
		customizepage.getCustomizeBtnCalenderdatepicker().get(calenderAvailabledateSize - 1).waitForVisible(3000);
		customizepage.getCustomizeBtnCalenderdatepicker().get(calenderAvailabledateSize - 1).click();
		PerfectoUtils.reportMessage("Delivery date is selected", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I validate the floral customize options with Multiple lines in MessageBox")
	public static void iValidateTheFloralCustomizeOptionsWithMultipleLinesinMessageBox() {
		CustomizeTestPage customizepage = new CustomizeTestPage();

		// Validating Select delivery
		customizepage.getCustomizeLblSelectdelivery().verifyPresent();
		customizepage.getCustomizeBtnDelivery().verifyPresent();
		customizepage.getCustomizeBtnStorepickup().verifyPresent();
		customizepage.getCustomizeTxtZipcode().verifyPresent();
		customizepage.getCustomizeTxtZipcode().click();
		customizepage.getCustomizeTxtZipcode().sendKeys(getBundle().getString("shippingaddress1.zipcode"));
		PerfectoUtils.reportMessage("Delivery Zipcode is Entered", MessageTypes.Pass);
		customizepage.getCustomizeBtnStorepickup().click();

		// Validating Bouquet Quality
		customizepage.getCustomizeLblBqtquality().verifyPresent();
		PerfectoUtils.reportMessage(
				"Current Bouquet Quality: " + customizepage.getCustomizeLblBqtqualityoption().getText(),
				MessageTypes.Info);

		// Validating Rose Primary Color
		PerfectoUtils.scrolltoelement(customizepage.getCustomizeLblPrimarycolor());
		customizepage.getCustomizeLblPrimarycolor().verifyPresent();
		PerfectoUtils.scrolltoelement(customizepage.getCustomizeLblPrimarycoloroptions().get(0));
		customizepage.getCustomizeLblPrimarycoloroptions().get(0).click();
		PerfectoUtils.reportMessage("Rose Primary Color has selected as: "
				+ customizepage.getCustomizeLblPrimarycoloroptions().get(0).getText(), MessageTypes.Pass);

		/*
		 * if (customizepage.getCustomizeLblSecondarycoloroptions().get(1).
		 * isPresent()) {
		 * customizepage.getCustomizeLblSecondarycoloroptions().get(1).click();
		 * PerfectoUtils.reportMessage("Rose Primary Color has selected as: " +
		 * customizepage.getCustomizeLblSecondarycoloroptions().get(1).getText()
		 * , MessageTypes.Pass); }
		 */
		// Validating Enter Free Card Message
		PerfectoUtils.scrolltoelement(customizepage.getCustomizeLblMessage());
		customizepage.getCustomizeLblMessage().verifyPresent();
		customizepage.getCustomizeTxtMessage().sendKeys(getBundle().getString("floralCustomize.MultipleLinescardMsg"));
		PerfectoUtils.reportMessage("Entered Card message!", MessageTypes.Pass);

		// Validating Delivery date
		PerfectoUtils.scrolltoelement(customizepage.getCustomizeLblDeliverydate());
		customizepage.getCustomizeLblDeliverydate().verifyPresent();
		customizepage.getCustomizeBtnDeliverydatecalender().verifyPresent();
		customizepage.getCustomizeBtnDeliverydatecalender().click();
		int calenderAvailabledateSize = customizepage.getCustomizeBtnCalenderdatepicker().size();
		customizepage.getCustomizeBtnCalenderdatepicker().get(calenderAvailabledateSize - 1).waitForVisible(3000);
		customizepage.getCustomizeBtnCalenderdatepicker().get(calenderAvailabledateSize - 1).click();
		PerfectoUtils.reportMessage("Delivery date is selected", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I verify Best seller carousals")
	public void iVerifyBestSellerCarousals() {
		ShopTestPage shoptest = new ShopTestPage();

		int size = shoptest.getLblSellercorusel().size();
		PerfectoUtils.scrolltoelement(shoptest.getLblSellercorusel().get(1));
		if (!(size == 0)) {
			PerfectoUtils.reportMessage("No of seller Corusels peresent:" + size, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("No of seller Corusels peresent:" + size, MessageTypes.Fail);

		}
	}

	@QAFTestStep(description = "Navigate to front door page")
	public void navigateToFrontDoorPage() {
		InStoreHomePage instorehomepage = new InStoreHomePage();
		FrontdoorTestPage frontdoorpage = new FrontdoorTestPage();

		instorehomepage.getHomeLogo().waitForPresent(1000);
		instorehomepage.getHomeLogo().click();
		PerfectoUtils.reportMessage("Clicked on Home logo..");

		try {
			frontdoorpage.getFrontBtnExplorerecipes().waitForPresent(3000);
			if (frontdoorpage.getFrontLblExploremystore().isPresent()) {
				PerfectoUtils.reportMessage("Navigated to Front door page..");
			} else {
				PerfectoUtils.reportMessage("Not Navigated to Front door page..", MessageTypes.Fail);
			}
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Wait timeout for navigating to Front door page..", MessageTypes.Fail);

		}
	}

	@QAFTestStep(description = "I verify shop by type")
	public void iVerifyShopByType() {

		iSeeTheCategoriesAndItsImages();
	}

	@QAFTestStep(description = "I see Sale carousal, primo picks, Our Brands")
	public void iSeeSaleCarousalPrimoPicksOurBrands() {
		ShopTestPage shoptest = new ShopTestPage();

		PerfectoUtils.scrolltoelement(shoptest.getLblOurBrands());
		shoptest.getLblOurBrands().verifyPresent();
		shoptest.getLblPrimoPicks().verifyPresent();
	}

	@QAFTestStep(description = "I navigate to order status page")
	public void iNavigateToOrderStatusPage() {
		InStoreHomePage instorehomepage = new InStoreHomePage();

		PerfectoUtils.mouseover(instorehomepage.getHomeImgCart());
		instorehomepage.getHomeLblOrderstatus().verifyPresent();
		instorehomepage.getHomeLblOrderstatus().click();
	}
	
	@QAFTestStep(description = "I verify mandatory star for Order confirmation Number")
	public void iVerifyMandatoryStarforOrderconfirmationNumber() {
		OrderstatusTestPage orderstatus = new OrderstatusTestPage();

		orderstatus.getOrderstatusLblOrderConfirmationMandatoryStar().verifyPresent();
	}

	@QAFTestStep(description = "I verify error message for invalid data")
	public void iVerifyErrorMessageForInvalidData() {
		InStoreHomePage instorehomepage = new InStoreHomePage();

		instorehomepage.getTxtOrderStatus().waitForPresent(1000);
		instorehomepage.getEdtOrderNumber().sendKeys("123");
		instorehomepage.getEdtEmailAddress().sendKeys("abc@hmail.com");
		instorehomepage.getBtnOrderSubmit().verifyPresent();
		instorehomepage.getBtnOrderSubmit().click();

		if (instorehomepage.getTxtOrderStatusError().isPresent()) {
			PerfectoUtils.reportMessage(
					"The order confirmation entered does not match the email address we have on file. Expected error is present",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"The order confirmation entered does not match the email address we have on file. Expected error is not present",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Select Add to cart button from floral PDP")
	public void selectAddToCartButtonFromFloralPDP() {
		CustomizeTestPage customizepage = new CustomizeTestPage();

		PerfectoUtils.scrolltoelement(customizepage.getBtnAddtocart());
		customizepage.getBtnAddtocart().click();
		PerfectoUtils.reportMessage("Clicked on add to cart button..");
	}

	@QAFTestStep(description = "I validate the properties of artify cake details page")
	public static void iValidateThePropertiesOfArtifyCakeDetailsPage() {
		ArtifycakedetailaTestPage arifycakedetails = new ArtifycakedetailaTestPage();

		PerfectoUtils.getDriver().switchTo().frame(arifycakedetails.getArtifycakeParentFrame());

		// Validate Cake Sheet Size
		arifycakedetails.getListChoicestitle().get(0).verifyPresent();
		PerfectoUtils.reportMessage("Current Cake Sheet Size: " + arifycakedetails.getLblSheetsizecurrent().getText(),
				MessageTypes.Pass);

		// Validate Cake Frosting
		arifycakedetails.getListChoicestitle().get(1).verifyPresent();
		arifycakedetails.getListFirstchoice().get(1).click();
		PerfectoUtils.reportMessage("2nd Option Selected: " + arifycakedetails.getListChoicestitle().get(1).getText(),
				MessageTypes.Pass);

		// Validate Cake Flavor
		arifycakedetails.getImgCake().waitForVisible(30000);
		arifycakedetails.getListChoicestitle().get(2).waitForPresent(30000);
		arifycakedetails.getListChoicestitle().get(2).verifyPresent();
		QAFWebElement eleSecondChoice = arifycakedetails.getListSecondchoice().get(0);
		PerfectoUtils.scrolltoelement(eleSecondChoice);
		eleSecondChoice.waitForPresent(3000);
		eleSecondChoice.click();
		PerfectoUtils.reportMessage("3rd Option Selected: " + arifycakedetails.getListChoicestitle().get(2).getText(),
				MessageTypes.Pass);

		// Validate Cake Filling
		arifycakedetails.getImgCake().waitForPresent(30000);
		arifycakedetails.getListChoicestitle().get(3).waitForVisible(10000);
		arifycakedetails.getListChoicestitle().get(3).verifyPresent();
		arifycakedetails.getListThirdchoice().get(0).click();
		PerfectoUtils.reportMessage("4th Option Selected: " + arifycakedetails.getListChoicestitle().get(3).getText(),
				MessageTypes.Pass);

		// Validate Top Border
		arifycakedetails.getImgCake().waitForPresent(30000);
		arifycakedetails.getListChoicestitle().get(4).waitForVisible(10000);
		arifycakedetails.getListChoicestitle().get(4).verifyPresent();
		arifycakedetails.getListFourthchoice().get(1).click();
		PerfectoUtils.reportMessage("5th Option Selected: " + arifycakedetails.getListChoicestitle().get(4).getText(),
				MessageTypes.Pass);

		// Validate Bottom border
		arifycakedetails.getImgCake().waitForPresent(30000);
		arifycakedetails.getListChoicestitle().get(5).waitForVisible(10000);
		PerfectoUtils.scrolltoelement(arifycakedetails.getListChoicestitle().get(5));
		arifycakedetails.getListChoicestitle().get(5).verifyPresent();
		arifycakedetails.getListFifthchoice().get(1).click();
		PerfectoUtils.reportMessage("6th Option Selected: " + arifycakedetails.getListChoicestitle().get(5).getText(),
				MessageTypes.Pass);

		// Validate Flower Color
		arifycakedetails.getImgCakebackground().waitForNotPresent(30000);
		arifycakedetails.getImgCake().waitForPresent(30000);
		arifycakedetails.getListChoicestitle().get(6).waitForVisible(10000);
		arifycakedetails.getListChoicestitle().get(6).verifyPresent();
		arifycakedetails.getListSixthchoice().get(1).click();
		PerfectoUtils.reportMessage("7th Option Selected: " + arifycakedetails.getListChoicestitle().get(6).getText(),
				MessageTypes.Pass);

		// Validate Text Color
		arifycakedetails.getImgCake().waitForPresent(30000);
		arifycakedetails.getListChoicestitle().get(7).waitForVisible(10000);
		PerfectoUtils.scrolltoelement(arifycakedetails.getListChoicestitle().get(7));
		arifycakedetails.getListChoicestitle().get(7).verifyPresent();
		arifycakedetails.waitForAjaxToComplete();
		arifycakedetails.getListSeventhchoice().get(1).click();
		arifycakedetails.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("8th Option Selected: " + arifycakedetails.getListChoicestitle().get(7).getText(),
				MessageTypes.Pass);

		// Validate and Enter card message
		arifycakedetails.getImgCake().waitForPresent(30000);
		arifycakedetails.getListChoicestitle().get(7).waitForVisible(10000);
		arifycakedetails.getListChoicestitle().get(7).verifyPresent();
		arifycakedetails.getLblCardmsg().sendKeys(getBundle().getString("floralCustomize.cardMsg"));
		arifycakedetails.getBtnUpdatetext().click();
		arifycakedetails.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("Card message Entered!", MessageTypes.Pass);

		if (arifycakedetails.getImgCake().isPresent()) {
			PerfectoUtils.reportMessage("Artify Cake has been validated!", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Artify Cake has not been validated!", MessageTypes.Fail);
		}

		PerfectoUtils.getDriver().switchTo().defaultContent();
	}

	@QAFTestStep(description = "I enter product ID {0} and select Search button")
	public void iEnterProductIDAndSelectSearchButton(String productid) {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();

		PerfectoUtils.scrolltoelement(instorehome.getTxtSearchField());
		getBundle().setProperty("ProductID", productid);
		CommonStepDef.entervalueintothetextbox(instorehome.getTxtSearchField(), productid);
		frontdoor.getFrontBtnSearch().click();
	}

	@QAFTestStep(description = "I see related product")
	public void iSeeRelatedProduct() {
		CDPTestPage cdp = new CDPTestPage();
		PdtsearchresultTestPage searchresult = new PdtsearchresultTestPage();

		try {
			cdp.getCdpLblPagetitle().waitForPresent(3000);
			PerfectoUtils.reportMessage("Navigated to CDP..", MessageTypes.Pass);
		} catch (Exception e) {
			try {
				searchresult.getLblSearchresult().waitForPresent(3000);
				PerfectoUtils.reportMessage("Navigated to Search Results page..", MessageTypes.Pass);
			} catch (Exception ef) {
				PerfectoUtils.reportMessage("Error occured while navigating to CDP or search result page..",
						MessageTypes.Fail);
			}
		}
		String result = cdp.getCdpLblResultFound().getText();
		if (result.contains(getBundle().getString("ProductID"))) {
			PerfectoUtils.reportMessage("Able to see with product ID", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not able to see with product ID", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I select a category at search results page")
	public void iSelectACategoryAtSearchResultsPage() {
		CDPTestPage cdp = new CDPTestPage();

		// Selecting first category
		cdp.getCdpLisByCategory().get(0).waitForPresent(15000);
		cdp.getCdpLisByCategory().get(0).verifyPresent();
		cdp.getCdpLisByCategory().get(0).click();
	}

	@QAFTestStep(description = "I verify the search result categories")
	public void iVerifyTheSearchResultCategories() {
		CDPTestPage cdp = new CDPTestPage();

		cdp.waitForPageToLoad();

		int i = 1;
		while (i <= 3) {
			cdp.getLnkCategories(i).verifyPresent();
			String category = cdp.getLnkCategories(i).getText();

			if (cdp.getLnkCategories(i).isDisplayed()) {
				PerfectoUtils.reportMessage(category + " is present", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage(category + " is not present", MessageTypes.Fail);
			}
			i++;
		}
	}

	@QAFTestStep(description = "I select subcategory")
	public void iSelectSubcategory() {
		ShopTestPage shoptest = new ShopTestPage();

		String subcategoryname = shoptest.getListSubcategory().get(1).getText();
		shoptest.getListSubcategory().get(1).click();
		PerfectoUtils.reportMessage("Clicked on sub category:  " + subcategoryname, MessageTypes.Info);
	}

	@QAFTestStep(description = "I verify subcategory product display page")
	public void iVerifySubcategoryProductDisplayPage() {
		ShopTestPage shoptest = new ShopTestPage();

		int size = shoptest.getListSubcategoryproductname().size();
		PerfectoUtils.reportMessage("Number of product displaying  in sub category page is: " + size,
				MessageTypes.Info);
	}

	@QAFTestStep(description = "I click on see all from our brands")
	public void iClickOnSeeAllFromOurBrands() {
		ShopTestPage shoptest = new ShopTestPage();

		iNavigateToShopPage();
		PerfectoUtils.scrolltoelement(shoptest.getLblOurBrands());
		shoptest.getLblOurBrands().click();
		shoptest.waitForPageToLoad();
		PerfectoUtils.reportMessage("Clicked on see all from our brands", MessageTypes.Info);
	}

	@QAFTestStep(description = "I verify corresponding displayed page")
	public void iVerifyCorrespondingDisplayedPage() {
		ShopTestPage shoptest = new ShopTestPage();

		String pgtitle = shoptest.getShopLblBrandnPrimoPick().getText();
		System.out.println(pgtitle);

		// Verifying page title for Primo Picks and Our Brands
		shoptest.getShopLblBrandnPrimoPick().verifyPresent("Our Brands");
		PerfectoUtils.reportMessage("Navigated to Our brands", MessageTypes.Info);

	}

	@QAFTestStep(description = "I click and verify on see all from primo picks")
	public void iClickAndVerifyOnSeeAllFromPrimoPicks() {
		ShopTestPage shoptest = new ShopTestPage();

		iNavigateToShopPage();
		PerfectoUtils.scrolltoelement(shoptest.getLblPrimoPicks());
		shoptest.getLblPrimoPicks().click();
		shoptest.waitForPageToLoad();
		PerfectoUtils.reportMessage("Clicked on see all from PrimoPicks", MessageTypes.Info);

		shoptest.getShopLblBrandnPrimoPick().verifyPresent("Primo Picks");
		PerfectoUtils.reportMessage("Navigated to Primo picks", MessageTypes.Info);

	}

	@QAFTestStep(description = "Verify the estimated ship date in PDP")
	public void verifyTheEstimatedShipDateInPDP() {
		PDPTestPage pdp = new PDPTestPage();

		String estimatedShipDate = pdp.getLblEstimatedshipdate().getText();
		DateFormat df = new SimpleDateFormat("MMM dd, yyyy");
		if (estimatedShipDate.startsWith("Ships in")) {
			pdp.getLblEstimatedshipdate().verifyPresent();
			PerfectoUtils.reportMessage("Estimated ShipDate Flag is Off", MessageTypes.Info);
		} else {
			try {
				df.parse(estimatedShipDate);
				PerfectoUtils.reportMessage("Correct Estimated ShipDate is displayed and Flag is On",
						MessageTypes.Info);
			} catch (ParseException e) {
				PerfectoUtils.reportMessage("Correct Estimated ShipDate is not displayed and Flag is On",
						MessageTypes.Info);
			}
		}
	}

	@QAFTestStep(description = "I click on first online targetter")
	public void iClickOnFirstOnlineTargetter() {
		InStoreHomePage instorehome = new InStoreHomePage();

		PerfectoUtils.scrolltoelement(instorehome.getHomeListOnlinecoruselname().get(0));
		instorehome.getHomeListOnlinecoruselname().get(0).verifyPresent();
		String onlineordername = instorehome.getHomeListOnlinecoruselname().get(0).getText();
		instorehome.getHomeListOnlinecoruselname().get(0).click();
		PerfectoUtils.reportMessage("First Online Corusels name is : " + onlineordername, MessageTypes.Pass);
	}

	@QAFTestStep(description = "I navigated to corresponding detail page")
	public void iNavigatedToCorrespondingDetailPage() {
		InStoreHomePage instorehome = new InStoreHomePage();

		String pgtitle = instorehome.getHomeLblMegamenutitle().getText();
		PerfectoUtils.reportMessage("Cliked Online Corusels page title : " + pgtitle, MessageTypes.Pass);
	}

	@QAFTestStep(description = "I click on right arrow online targetter")
	public void iClickOnRightArrowOnlineTargetter() {
		InStoreHomePage instorehome = new InStoreHomePage();

		PerfectoUtils.scrolltoelement(instorehome.getHomeListOnlinecoruselname().get(0));
		if (instorehome.getHomeImgRightarrowonline().isPresent()) {
			instorehome.getHomeImgRightarrowonline().click();
			PerfectoUtils.reportMessage("Right arrow is visible:", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("No more products to scroll right", MessageTypes.Info);
		}
	}

	@QAFTestStep(description = "I click on last online targetter")
	public void iClickOnLastOnlineTargetter() {
		InStoreHomePage instorehome = new InStoreHomePage();

		PerfectoUtils.scrolltoelement(instorehome.getHomeListOnlinecoruselname().get(1));
		String onlineordername = instorehome.getHomeListOnlinecoruselname().get(1).getText();
		instorehome.getHomeListOnlinecoruselname().get(1).click();
		PerfectoUtils.reportMessage("Second Online Corusels name is : " + onlineordername, MessageTypes.Pass);
	}

	@QAFTestStep(description = "I validate the Bakery customize options")
	public static void iValidateTheBakeryCustomizeOptions() {
		CustomizebakeryTestPage customBakery = new CustomizebakeryTestPage();

		int options = customBakery.getCustomcakeListChoicestitle().size();

		// 1. Validate Cake Sheet Size
		// customBakery.getCustomcakeLblSheetsize().verifyPresent();
		if (options > 1) {
			customBakery.getCustomcakeListChoicestitle().get(0).verifyPresent();
			PerfectoUtils.reportMessage(
					"Current Cake Sheet Size: " + customBakery.getCustomcakeLblSheetsizecurrent().getText(),
					MessageTypes.Pass);
		}

		// 2. Validate Cake Frosting
		if (options > 2) {
			customBakery.getCustomcakeListChoicestitle().get(1).verifyPresent();
			customBakery.getCustomcakeListFirstchoice().get(1).click();
			PerfectoUtils.reportMessage(
					"2nd Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(0).getText(),
					MessageTypes.Pass);
		}

		// 3. Validate Cake Flavor
		if (options > 3) {
			customBakery.getCustomcakeListChoicestitle().get(2).verifyPresent();
			PerfectoUtils.scrolltoelement(customBakery.getCustomcakeListSecondchoice().get(0));
			customBakery.getCustomcakeListSecondchoice().get(0).waitForPresent(3000);
			customBakery.getCustomcakeListSecondchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"3rd Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(1).getText(),
					MessageTypes.Pass);
		}

		// 4. Validate Cake Filling
		if (options > 4) {
			customBakery.getCustomcakeListChoicestitle().get(3).verifyPresent();
			customBakery.getCustomcakeListThirdchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"4th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(2).getText(),
					MessageTypes.Pass);
		}

		// 5. Validate Top Border
		if (options > 5) {
			customBakery.getCustomcakeListChoicestitle().get(4).verifyPresent();
			customBakery.getCustomcakeListFourthchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"5th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(3).getText(),
					MessageTypes.Pass);
		}

		// 6. Validate Bottom border
		if (options > 6) {
			PerfectoUtils.scrolltoelement(customBakery.getCustomcakeListChoicestitle().get(5));
			customBakery.getCustomcakeListChoicestitle().get(5).verifyPresent();
			customBakery.getCustomcakeListFifthchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"6th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(4).getText(),
					MessageTypes.Pass);
		}

		// 7. Validate Text Color
		if (options > 7) {
			customBakery.getCustomcakeListChoicestitle().get(6).verifyPresent();
			customBakery.getCustomcakeListSixthchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"7th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(5).getText(),
					MessageTypes.Pass);
		}

		// 8. Validate polka dot Color
		if (options > 8) {
			customBakery.getCustomcakeListChoicestitle().get(7).verifyPresent();
			customBakery.getCustomcakeListSeventhchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"8th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(7).getText(),
					MessageTypes.Pass);
		}

		// 9. Validate and Enter card message
		customBakery.getCustomcakeListChoicestitle().get(options - 1).verifyPresent();
		customBakery.getCustomcakeLblCardmsg().sendKeys(getBundle().getString("floralCustomize.cardMsg"));
		PerfectoUtils.reportMessage("Card message Entered!", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I validate the Bakery with Multiple lines in MessageBox customize options")
	public static void iValidateTheBakeryWithMultipleLinesInMessageBoxCustomizeOptions() {
		CustomizebakeryTestPage customBakery = new CustomizebakeryTestPage();

		int options = customBakery.getCustomcakeListChoicestitle().size();

		// 1. Validate Cake Sheet Size
		// customBakery.getCustomcakeLblSheetsize().verifyPresent();
		if (options > 1) {
			customBakery.getCustomcakeListChoicestitle().get(0).verifyPresent();
			PerfectoUtils.reportMessage(
					"Current Cake Sheet Size: " + customBakery.getCustomcakeLblSheetsizecurrent().getText(),
					MessageTypes.Pass);
		}

		// 2. Validate Cake Frosting
		if (options > 2) {
			customBakery.getCustomcakeListChoicestitle().get(1).verifyPresent();
			customBakery.getCustomcakeListFirstchoice().get(1).click();
			PerfectoUtils.reportMessage(
					"2nd Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(0).getText(),
					MessageTypes.Pass);
		}

		// 3. Validate Cake Flavor
		if (options > 3) {
			customBakery.getCustomcakeListChoicestitle().get(2).verifyPresent();
			PerfectoUtils.scrolltoelement(customBakery.getCustomcakeListSecondchoice().get(0));
			customBakery.getCustomcakeListSecondchoice().get(0).waitForPresent(3000);
			customBakery.getCustomcakeListSecondchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"3rd Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(1).getText(),
					MessageTypes.Pass);
		}

		// 4. Validate Cake Filling
		if (options > 4) {
			customBakery.getCustomcakeListChoicestitle().get(3).verifyPresent();
			customBakery.getCustomcakeListThirdchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"4th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(2).getText(),
					MessageTypes.Pass);
		}

		// 5. Validate Top Border
		if (options > 5) {
			customBakery.getCustomcakeListChoicestitle().get(4).verifyPresent();
			customBakery.getCustomcakeListFourthchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"5th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(3).getText(),
					MessageTypes.Pass);
		}

		// 6. Validate Bottom border
		if (options > 6) {
			PerfectoUtils.scrolltoelement(customBakery.getCustomcakeListChoicestitle().get(5));
			customBakery.getCustomcakeListChoicestitle().get(5).verifyPresent();
			customBakery.getCustomcakeListFifthchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"6th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(4).getText(),
					MessageTypes.Pass);
		}

		// 7. Validate Text Color
		if (options > 7) {
			customBakery.getCustomcakeListChoicestitle().get(6).verifyPresent();
			customBakery.getCustomcakeListSixthchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"7th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(5).getText(),
					MessageTypes.Pass);
		}

		// 8. Validate polka dot Color
		if (options > 8) {
			customBakery.getCustomcakeListChoicestitle().get(7).verifyPresent();
			customBakery.getCustomcakeListSeventhchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"8th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(7).getText(),
					MessageTypes.Pass);
		}

		// 9. Validate and Enter card message
		customBakery.getCustomcakeListChoicestitle().get(options - 1).verifyPresent();
		customBakery.getCustomcakeLblCardmsg().sendKeys(getBundle().getString("floralCustomize.MultipleLinescardMsg"));
		PerfectoUtils.reportMessage("Card message Entered!", MessageTypes.Pass);
	}
	
	@QAFTestStep(description = "I enter the Bakery Customize Options without Message")
	public static void iEnterTheBakeryCustomizeOptionsWithoutMessage() {
		CustomizebakeryTestPage customBakery = new CustomizebakeryTestPage();

		int options = customBakery.getCustomcakeListChoicestitle().size();

		// 1. Validate Cake Sheet Size
		// customBakery.getCustomcakeLblSheetsize().verifyPresent();
		if (options > 1) {
			customBakery.getCustomcakeListChoicestitle().get(0).verifyPresent();
			PerfectoUtils.reportMessage(
					"Current Cake Sheet Size: " + customBakery.getCustomcakeLblSheetsizecurrent().getText(),
					MessageTypes.Pass);
		}

		// 2. Validate Cake Frosting
		if (options > 2) {
			customBakery.getCustomcakeListChoicestitle().get(1).verifyPresent();
			customBakery.getCustomcakeListFirstchoice().get(1).click();
			PerfectoUtils.reportMessage(
					"2nd Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(0).getText(),
					MessageTypes.Pass);
		}

		// 3. Validate Cake Flavor
		if (options > 3) {
			customBakery.getCustomcakeListChoicestitle().get(2).verifyPresent();
			PerfectoUtils.scrolltoelement(customBakery.getCustomcakeListSecondchoice().get(0));
			customBakery.getCustomcakeListSecondchoice().get(0).waitForPresent(3000);
			customBakery.getCustomcakeListSecondchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"3rd Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(1).getText(),
					MessageTypes.Pass);
		}

		// 4. Validate Cake Filling
		if (options > 4) {
			customBakery.getCustomcakeListChoicestitle().get(3).verifyPresent();
			customBakery.getCustomcakeListThirdchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"4th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(2).getText(),
					MessageTypes.Pass);
		}

		// 5. Validate Top Border
		if (options > 5) {
			customBakery.getCustomcakeListChoicestitle().get(4).verifyPresent();
			customBakery.getCustomcakeListFourthchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"5th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(3).getText(),
					MessageTypes.Pass);
		}

		// 6. Validate Bottom border
		if (options > 6) {
			PerfectoUtils.scrolltoelement(customBakery.getCustomcakeListChoicestitle().get(5));
			customBakery.getCustomcakeListChoicestitle().get(5).verifyPresent();
			customBakery.getCustomcakeListFifthchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"6th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(4).getText(),
					MessageTypes.Pass);
		}

		// 7. Validate Text Color
		if (options > 7) {
			customBakery.getCustomcakeListChoicestitle().get(6).verifyPresent();
			customBakery.getCustomcakeListSixthchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"7th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(5).getText(),
					MessageTypes.Pass);
		}

		// 8. Validate polka dot Color
		if (options > 8) {
			customBakery.getCustomcakeListChoicestitle().get(7).verifyPresent();
			customBakery.getCustomcakeListSeventhchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"8th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(7).getText(),
					MessageTypes.Pass);
		}

	}

	@QAFTestStep(description = "I validate the Same Bakery with different customize options")
	public static void iValidateTheSameBakerywithDiffCustomizeOptions() {
		CustomizebakeryTestPage customBakery = new CustomizebakeryTestPage();

		int options = customBakery.getCustomcakeListChoicestitle().size();

		// 1. Validate Cake Sheet Size
		// customBakery.getCustomcakeLblSheetsize().verifyPresent();
		if (options > 1) {
			customBakery.getCustomcakeListChoicestitle().get(0).verifyPresent();
			PerfectoUtils.reportMessage(
					"Current Cake Sheet Size: " + customBakery.getCustomcakeLblSheetsizecurrent().getText(),
					MessageTypes.Pass);
		}

		// 2. Validate Cake Frosting
		if (options > 2) {
			customBakery.getCustomcakeListChoicestitle().get(1).verifyPresent();
			customBakery.getCustomcakeListFirstchoice().get(3).click();
			PerfectoUtils.reportMessage(
					"2nd Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(0).getText(),
					MessageTypes.Pass);
		}

		// 3. Validate Cake Flavor
		if (options > 3) {
			customBakery.getCustomcakeListChoicestitle().get(2).verifyPresent();
			PerfectoUtils.scrolltoelement(customBakery.getCustomcakeListSecondchoice().get(3));
			customBakery.getCustomcakeListSecondchoice().get(3).waitForPresent(3000);
			customBakery.getCustomcakeListSecondchoice().get(3).click();
			PerfectoUtils.reportMessage(
					"3rd Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(1).getText(),
					MessageTypes.Pass);
		}

		// 4. Validate Cake Filling
		if (options > 4) {
			customBakery.getCustomcakeListChoicestitle().get(3).verifyPresent();
			customBakery.getCustomcakeListThirdchoice().get(5).click();
			PerfectoUtils.reportMessage(
					"4th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(2).getText(),
					MessageTypes.Pass);
		}

		// 5. Validate Top Border
		if (options > 5) {
			customBakery.getCustomcakeListChoicestitle().get(4).verifyPresent();
			customBakery.getCustomcakeListFourthchoice().get(8).click();
			PerfectoUtils.reportMessage(
					"5th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(3).getText(),
					MessageTypes.Pass);
		}

		// 6. Validate Bottom border
		if (options > 6) {
			PerfectoUtils.scrolltoelement(customBakery.getCustomcakeListChoicestitle().get(5));
			customBakery.getCustomcakeListChoicestitle().get(5).verifyPresent();
			customBakery.getCustomcakeListFifthchoice().get(1).click();
			PerfectoUtils.reportMessage(
					"6th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(4).getText(),
					MessageTypes.Pass);
		}

		// 7. Validate Text Color
		if (options > 7) {
			customBakery.getCustomcakeListChoicestitle().get(6).verifyPresent();
			customBakery.getCustomcakeListSixthchoice().get(2).click();
			PerfectoUtils.reportMessage(
					"7th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(5).getText(),
					MessageTypes.Pass);
		}

		// 8. Validate polka dot Color
		if (options > 8) {
			customBakery.getCustomcakeListChoicestitle().get(7).verifyPresent();
			customBakery.getCustomcakeListSeventhchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"8th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(7).getText(),
					MessageTypes.Pass);
		}

		// 9. Validate and Enter card message
		customBakery.getCustomcakeListChoicestitle().get(options - 1).verifyPresent();
		customBakery.getCustomcakeLblCardmsg().sendKeys(getBundle().getString("floralCustomize.cardMsg2"));
		PerfectoUtils.reportMessage("Card message Entered!", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I select a product with customize button and update Qty and add to cart")
	public synchronized void iSelectAProductWithCustomizeButtonAndUpdateQtyAndAddToCart() {
		PDPTestPage pdpPage = new PDPTestPage();
		CDPTestPage cdppage = new CDPTestPage();

		for (int i = 0; i < cdppage.getcdpBtnCustomize().size(); i++) {
			iSelectaTHProductWithCustomizeButton(i);
			if (pdpPage.getPdpBtnAddtocart().getAttribute("class").contains("disabled")) {
				PerfectoUtils.reportMessage("Add To cart is not available for the product");
				PerfectoUtils.getDriver().navigate().back();
				cdppage.waitForPageToLoad();
				continue;
			} else {
				PerfectoUtils.reportMessage("Product found with Add to cart button");
				break;
			}
		}

		if (PerfectoUtils.getDriver().getCurrentUrl().contains("1815960")) {
			iValidateThePropertiesOfArtifyCakeDetailsPage();
		} else {
			HomePage.iValidateTheBakeryCustomizeOptions();
		}
		pdpPage.waitForAjaxToComplete();
		pdpPage.waitForPageToLoad();
		PerfectoUtils.scrolltoelement(pdpPage.getPdpEdtQuantity());
		// PerfectoUtils.scrollToTop();
		pdpPage.getPdpEdtQuantity().verifyPresent();
		pdpPage.getPdpEdtQuantity().click();
		pdpPage.getPdpEdtQuantity().clear();
		pdpPage.getPdpEdtQuantity().sendKeys("11");

		pdpPage.getPdpBtnAddtocart().verifyPresent();
		pdpPage.getPdpBtnAddtocart().click();
	}

	@QAFTestStep(description = "I select a store from Select a pickup store page with Zipcode {0}")
	public void iSelectAStoreFromSelectAPickupStorePage(String zipCode) {
		SelectStoreTestPage selectstore = new SelectStoreTestPage();

		try {
			selectstore.getSelstoreLblPickupstoretitle().waitForPresent(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (selectstore.getSelstoreLblPickupstoretitle().isPresent()) {
			PerfectoUtils.reportMessage("Selecting the Store from the pop-up.", MessageTypes.Pass);
			selectstore.getSelstoreLblPickupstoretitle().verifyPresent();

			// Enter Zip code
			selectstore.getSelstoreTxtZipcode().click();
			selectstore.getSelstoreTxtZipcode().clear();
			selectstore.getSelstoreTxtZipcode().sendKeys(zipCode);
			selectstore.getSelstoreBtnGo().click();
			selectstore.waitForAjaxToComplete();

			if (selectstore.getSelstoreLblResults().isPresent()) {
				PerfectoUtils.reportMessage(selectstore.getSelstoreLblResults().getText(), MessageTypes.Info);
			}

			// Select Store
			selectstore.getSelstoreGetLblStorename("3").waitForPresent(30000);
			String strStore = selectstore.getSelstoreGetLblStorename("3").getText();
			getBundle().setProperty("SelectedStore", strStore);
			getBundle().setProperty("selectedStrName", strStore);

			selectstore.getSelstoreGetBtnStoreselect("3").click();
			selectstore.waitForAjaxToComplete();
			selectstore.getSelstoreLblTitle().waitForNotPresent(50000);
		} else {
			PerfectoUtils.reportMessage("Select a store pop-up not found.");
		}
	}
	
	@QAFTestStep(description = "I select a store from Select a pickup store page {0}")
	public void iSelectAStoreFromSelectAPickupStore(String zipCode) {
		SelectStoreTestPage selectstore = new SelectStoreTestPage();

		try {
			selectstore.getSelstoreLblPickupstoretitle().waitForPresent(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (selectstore.getSelstoreLblPickupstoretitle().isPresent()) {
			PerfectoUtils.reportMessage("Selecting the Store from the pop-up.", MessageTypes.Pass);
			selectstore.getSelstoreLblPickupstoretitle().verifyPresent();

			// Enter Zip code
			selectstore.getSelstoreTxtZipcode().click();
			selectstore.getSelstoreTxtZipcode().clear();
			selectstore.getSelstoreTxtZipcode().sendKeys(zipCode);
			selectstore.getSelstoreBtnGo().click();
			selectstore.waitForAjaxToComplete();

			if (selectstore.getSelstoreLblResults().isPresent()) {
				PerfectoUtils.reportMessage(selectstore.getSelstoreLblResults().getText(), MessageTypes.Info);
			}

			// Select Store
			selectstore.getSelstoreGetLblPickUpStorename("3").waitForPresent(30000);
			String strStore = selectstore.getSelstoreGetLblPickUpStorename("3").getText();
			getBundle().setProperty("SelectedStore", strStore);
			getBundle().setProperty("selectedStrName", strStore);

			selectstore.getSelstoreGetBtnStoreselect("3").click();
			selectstore.waitForAjaxToComplete();
			selectstore.getSelstoreLblTitle().waitForNotPresent(50000);
		} else {
			PerfectoUtils.reportMessage("Select a store pop-up not found.");
		}
	}

	@QAFTestStep(description = "I see error message when enters quantity more than {0} for custom bakery product")
	public void iSeeErrorMessageWhenEntersQuantityMoreThanForCustomBakeryProduct(long l1) {
		PDPTestPage pdpPage = new PDPTestPage();

		pdpPage.waitForAjaxToComplete();
		pdpPage.getPdpLblErrormsg().waitForPresent(50000);
		pdpPage.getPdpLblErrormsg().verifyPresent();
		pdpPage.getPdpLblErrormsg().verifyText(getBundle().getString("products.errorMsg.bakQtyError"));
		PerfectoUtils.reportMessage("Error message: " + pdpPage.getPdpLblErrormsg().getText(), MessageTypes.Info);
	}

	@QAFTestStep(description = "I Verify the estimated ship date in Cart")
	public void iVerifyTheEstimatedShipDateInCart() {
		CartTestPage cartpage = new CartTestPage();
		String estimatedShipDate = cartpage.getCartLblEstimatedShipDate().getText();
		DateFormat df = new SimpleDateFormat("MMM dd, yyyy");
		if (estimatedShipDate.startsWith("Ships in")) {
			cartpage.getCartLblEstimatedShipDate().verifyPresent();
			PerfectoUtils.reportMessage("Estimated ShipDate Flag is Off", MessageTypes.Info);
		} else {
			try {
				df.parse(estimatedShipDate);
				PerfectoUtils.reportMessage("Correct Estimated ShipDate is displayed and Flag is On",
						MessageTypes.Info);
			} catch (ParseException e) {
				PerfectoUtils.reportMessage("Correct Estimated ShipDate is not displayed and Flag is On",
						MessageTypes.Info);
			}
		}
	}

	/**
	 * Verify the new Home Page is opened
	 */
	@QAFTestStep(description = "I am on home page in minimized view")
	public synchronized static void iAmOnHomePageInMinimizedView() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		System.out.println("Opening Application");
		PerfectoUtils.getDriver().manage().deleteAllCookies();
		PerfectoUtils.getDriver().manage().window().setSize(new Dimension(940, 559));
		PerfectoUtils.getDriver().get(getBundle().getString("env.baseurl"));

		frontdoor.getFrontImgExploremystore().verifyPresent();
		getBundle().setProperty("myEmail", "Cold");

	}

	@QAFTestStep(description = "Validate the Make ready catridge image, name and description")
	public void validateTheMakeReadyCatridgeImageNameAndDescription() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontLiBlockCatridges().get(0).waitForPresent(5000);

		for (int i = 0; i < frontdoor.getFrontLiBlockCatridges().size(); i++) {
			frontdoor.getFrontLiBlockCatridges().get(i).verifyPresent();
			frontdoor.getFrontLiImgCatridges().get(i).verifyPresent();
			frontdoor.getFrontLiLblCatridgenamess().get(i).verifyPresent();
			frontdoor.getFrontLiLblCatridgedesc().get(i).verifyPresent();
			String desc = frontdoor.getFrontLiLblCatridgedesc().get(i).getText();

			if (i == 0 && !desc.replace("Party Trays", "")
					.equalsIgnoreCase(getBundle().getString("testdata.cartridge.parttrays"))) {
				PerfectoUtils.reportMessage("Part Trays descriotion is not Present", MessageTypes.Fail);

			} else if (i == 1
					&& !desc.replace("BaKery", "").trim().equalsIgnoreCase(getBundle().getString("cartridge.Bakery"))) {
				PerfectoUtils.reportMessage("BaKery descriotion is not Present", MessageTypes.Fail);
				System.out.println(desc + "****" + (getBundle().getString("cartridge.Bakery")));

			} else if (i == 2 && !desc.replace("Flowers", "").trim()
					.equalsIgnoreCase(getBundle().getString("cartridge.Flowers"))) {
				PerfectoUtils.reportMessage("Flowers descriotion is not Present", MessageTypes.Fail);

			} else if (i == 3
					&& !desc.replace("Wine", "").trim().equalsIgnoreCase(getBundle().getString("cartridge.Wine"))) {
				PerfectoUtils.reportMessage("Wine descriotion is not Present", MessageTypes.Fail);
			}

			PerfectoUtils.reportMessage(
					"Catridge verified: " + frontdoor.getFrontLiBlockCatridges().get(i).getAttribute("title"));
		}
	}

	@QAFTestStep(description = "Clicks on each make ready catridge and validate its landing page")
	public void clicksOnEachMakeReadyCatridgeAndValidateItsLandingPage() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		CDPTestPage cdppage = new CDPTestPage();

		frontdoor.getFrontLiBlockCatridges().get(0).waitForPresent(5000);
		int size = frontdoor.getFrontLiBlockCatridges().size();

		PerfectoUtils.reportMessage("Number of Make ready catridges available: " + size);

		for (int i = 0; i < size; i++) {
			frontdoor.getFrontLiBlockCatridges().get(i).waitForPresent(5000);
			PerfectoUtils.reportMessage(
					"Selected Catridge: " + frontdoor.getFrontLiBlockCatridges().get(i).getAttribute("title"));
			frontdoor.getFrontLiBlockCatridges().get(i).click();
			frontdoor.waitForPageToLoad();
			frontdoor.waitForAjaxToComplete();
			cdppage.getCdpLblPagetitle().verifyPresent();
			PerfectoUtils.reportMessage("Page opened: " + cdppage.getCdpLblPagetitle().getText() + ", URL: "
					+ PerfectoUtils.getDriver().getCurrentUrl(), MessageTypes.Pass);
			PerfectoUtils.getDriver().navigate().back();
		}
	}

	@QAFTestStep(description = "Verify Make ready catridge is not available")
	public void verifyMakeReadyCatridgeIsNotAvailable() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.waitForPageToLoad();
		int blockSize = frontdoor.getFrontLiBlockCatridges().size();
		int imgSize = frontdoor.getFrontLiImgCatridges().size();
		int nameSize = frontdoor.getFrontLiLblCatridgenamess().size();
		int descSize = frontdoor.getFrontLiLblCatridgedesc().size();

		if (blockSize == 0 && imgSize == 0 && nameSize == 0 && descSize == 0)
			PerfectoUtils.reportMessage("Verified ship to home page to not have Make ready catridge!",
					MessageTypes.Pass);
		else {
			PerfectoUtils.reportMessage("Ship to home page contains Make ready catridge!", MessageTypes.Fail);
		}
	}

	/**
	 * Click on Pharmacy from Header
	 */
	@QAFTestStep(description = "Navigate to Pharmacy page from inStore homepage")
	public void navigateToPharmacyPageFromInStoreHomepage() {
		InStoreHomePage instore = new InStoreHomePage();
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		instore.getHomeLnkPharmacy().verifyPresent();
		instore.getHomeLnkPharmacy().click();
		iSeePharmacyPage();
		frontdoor.getFrontImgFav().verifyPresent();
	}

	@QAFTestStep(description = "Validate delivery calender is not displayed with duplicate dates")
	public static void validateDeliveryCalenderIsNotDisplayedWithDuplicateDates() {
		CustomizeTestPage customizepage = new CustomizeTestPage();

		customizepage.getCustomizeLblSelectdelivery().verifyPresent();
		PerfectoUtils.scrolltoelement(customizepage.getCustomizeLblDeliverydate());
		customizepage.getCustomizeLblDeliverydate().verifyPresent();
		customizepage.getCustomizeBtnDeliverydatecalender().verifyPresent();
		customizepage.getCustomizeBtnDeliverydatecalender().click();

		String calMonth = customizepage.getLblCalendermonth().getText();
		String calYear = customizepage.getLblCalenderyear().getText();
		customizepage.getLiLblCalenderdates().get(0).verifyPresent();

		int daysOfMonth = PerfectoUtils.getDaysOfMonth(calMonth, calYear);
		int date = 1;
		boolean duplicateFound = false;

		for (int i = 0; i < daysOfMonth; i++) {
			if (date == (Integer.parseInt(customizepage.getLiLblCalenderdates().get(i).getText()))) {
				System.out.println(customizepage.getLiLblCalenderdates().get(i).getText());
				duplicateFound = false;
			} else {
				duplicateFound = true;
				break;
			}
			date++;
		}

		if (duplicateFound) {
			PerfectoUtils.reportMessage("Duplicate Calendar dates found for the month " + calMonth, MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("Duplicate Calendar dates are not found for the month " + calMonth,
					MessageTypes.Pass);
		}

	}

	@QAFTestStep(description = "I select a {0} th product with customize button")
	public void iSelectaTHProductWithCustomizeButton(int i) {
		CDPTestPage cdppage = new CDPTestPage();

		try {
			cdppage.getcdpBtnCustomize().get(i).waitForPresent(3000);
			PerfectoUtils.scrolltoelement(cdppage.getcdpBtnCustomize().get(i));
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Customize button is not available", MessageTypes.Info);
		}

		cdppage.getcdpBtnCustomize().get(i).verifyPresent();
		cdppage.getcdpBtnCustomize().get(i).click();
	}

	@QAFTestStep(description = "I validate the SPU customize options")
	public static void iValidateTheSPUCustomizeOptions() {
		CustomizebakeryTestPage customBakery = new CustomizebakeryTestPage();

		int options = customBakery.getCustomcakeListChoicestitle().size();

		// 1. Validate Cake Sheet Size
		// customBakery.getCustomcakeLblSheetsize().verifyPresent();
		if (options > 1) {
			customBakery.getCustomcakeListChoicestitle().get(0).verifyPresent();
			customBakery.getCustomcakeListSheetsize().get(2).click();
			PerfectoUtils.reportMessage(
					"Current Cake Sheet Size: " + customBakery.getCustomcakeLblSheetsizecurrent().getText(),
					MessageTypes.Pass);
		}

		// 2. Validate Cake Frosting
		if (options > 2) {
			customBakery.getCustomcakeListChoicestitle().get(1).verifyPresent();
			customBakery.getCustomcakeListFirstchoice().get(1).click();
			PerfectoUtils.reportMessage(
					"2nd Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(0).getText(),
					MessageTypes.Pass);
		}

		// 3. Validate Cake Flavor
		if (options > 3) {
			customBakery.getCustomcakeListChoicestitle().get(2).verifyPresent();
			PerfectoUtils.scrolltoelement(customBakery.getCustomcakeListSecondchoice().get(0));
			customBakery.getCustomcakeListSecondchoice().get(0).waitForPresent(3000);
			customBakery.getCustomcakeListSecondchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"3rd Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(1).getText(),
					MessageTypes.Pass);
		}

		// 4. Validate Cake Filling
		if (options > 4) {
			customBakery.getCustomcakeListChoicestitle().get(3).verifyPresent();
			customBakery.getCustomcakeListThirdchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"4th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(2).getText(),
					MessageTypes.Pass);
		}

		// 5. Validate Top Border
		if (options > 5) {
			customBakery.getCustomcakeListChoicestitle().get(4).verifyPresent();
			customBakery.getCustomcakeListFourthchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"5th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(3).getText(),
					MessageTypes.Pass);
		}

		// 6. Validate Bottom border
		if (options > 6) {
			PerfectoUtils.scrolltoelement(customBakery.getCustomcakeListChoicestitle().get(5));
			customBakery.getCustomcakeListChoicestitle().get(5).verifyPresent();
			customBakery.getCustomcakeListFifthchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"6th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(4).getText(),
					MessageTypes.Pass);
		}

		// 7. Validate Text Color
		if (options > 7) {
			customBakery.getCustomcakeListChoicestitle().get(6).verifyPresent();
			customBakery.getCustomcakeListSixthchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"7th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(5).getText(),
					MessageTypes.Pass);
		}

		// 8. Validate polka dot Color
		if (options > 8) {
			customBakery.getCustomcakeListChoicestitle().get(7).verifyPresent();
			customBakery.getCustomcakeListSeventhchoice().get(0).click();
			PerfectoUtils.reportMessage(
					"8th Option Selected: " + customBakery.getCustomcakeListChoicestitle().get(7).getText(),
					MessageTypes.Pass);
		}

		// 9. Validate and Enter card message
		customBakery.getCustomcakeListChoicestitle().get(options - 1).verifyPresent();
		customBakery.getCustomcakeLblCardmsg().sendKeys(getBundle().getString("floralCustomize.cardMsg"));
		PerfectoUtils.reportMessage("Card message Entered!", MessageTypes.Pass);
		customBakery.waitForAjaxToComplete();
	}

	@QAFTestStep(description = "I select other picker and verify the price changes")
	public static void iSelectOtherPickerAndVerifyThePriceChanges() {
		ArtifycakedetailaTestPage arifycakedetails = new ArtifycakedetailaTestPage();

		String initialPrice = arifycakedetails.getArtifycakeLblPrice().getAttribute("content");

		PerfectoUtils.getDriver().switchTo().frame(arifycakedetails.getArtifycakeParentFrame());
		arifycakedetails.getLblSheetsizecurrent().verifyPresent();

		String currentSheet = arifycakedetails.getLblSheetsizecurrent().getText();
		int availSizes = arifycakedetails.getArtifycakeLiBtnSheetsize().size();
		int initialSize = 0;

		PerfectoUtils.reportMessage("Current Cake Sheet Size: " + currentSheet, MessageTypes.Info);

		for (int i = 0; i < availSizes; i++) {

			if (currentSheet.equalsIgnoreCase(arifycakedetails.getArtifycakeLiBtnSheetsize().get(i).getText())) {
				if (i == 0) {
					arifycakedetails.getArtifycakeLiBtnSheetsize().get(i + 1).click();
				} else if (i == availSizes - 1) {
					arifycakedetails.getArtifycakeLiBtnSheetsize().get(i - 1).click();
				} else {
					arifycakedetails.getArtifycakeLiBtnSheetsize().get(i + 1).click();
				}

				initialSize = i;
				break;
			}
		}

		arifycakedetails.waitForAjaxToComplete();
		PerfectoUtils.getDriver().switchTo().defaultContent();
		PerfectoUtils.scrolltoelement(arifycakedetails.getArtifycakeLblPrice());

		if (arifycakedetails.getArtifycakeLblPrice().getAttribute("content").equalsIgnoreCase(initialPrice)) {
			PerfectoUtils.reportMessage("Price not changes when selecting different sheet", MessageTypes.Fail);
		} else {

			PerfectoUtils.reportMessage("Price changes when selecting different sheet", MessageTypes.Pass);
		}

		// Selecting the initial cake size
		PerfectoUtils.getDriver().switchTo().frame(arifycakedetails.getArtifycakeParentFrame());
		arifycakedetails.getArtifycakeLiBtnSheetsize().get(initialSize).click();
		arifycakedetails.waitForAjaxToComplete();

		PerfectoUtils.getDriver().switchTo().defaultContent();
		PerfectoUtils.scrolltoelement(arifycakedetails.getArtifycakeLblPrice());

		if (arifycakedetails.getArtifycakeLblPrice().getAttribute("content").equalsIgnoreCase(initialPrice)) {
			PerfectoUtils.reportMessage("Price changes when selecting sheet back to initial sheet", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Price not changes when seleting sheet back to initial sheet",
					MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I validate selected store is displayed as my HEB store in Store flyout")
	public void iValidateSelectedStoreIsDisplayedAsMyHEBStoreInStoreFlyout() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		frontdoor.getFrontLblStorename().waitForPresent(50000);
		PerfectoUtils.mousehover(frontdoor.getFrontLblStorename());
		frontdoor.getFrontLiLblStoreflyoutstorenames().get(0).verifyPresent();
		String storeNameinTop = PerfectoUtils.removeSpecialCharacters(frontdoor.getFrontLblStorename().getText());
		String selectedStore = PerfectoUtils.removeSpecialCharacters(getBundle().getString("selectedStrName"));

		if (selectedStore.equals(storeNameinTop))
			PerfectoUtils.reportMessage("Selected Store has been successfully become the profile store",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Selected Store has not been successfully become the profile store",
					MessageTypes.Fail);
	}

	@QAFTestStep(description = "Navigate to Digital Coupons page as a cold user")
	public void navigateToDigitalCouponsPageAsAColdUser() {

		iClickOnCouponsCatridge();
		clickSeelectDigitalCouponsFromCouponsPage();
		clickCloseFromTheDigCouponsLoginpopup();
		CouponsStepDef.iShouldSeeTheDigitalCouponsPage();
	}

	public void clickSeelectDigitalCouponsFromCouponsPage() {
		CouponsTestPage coupons = new CouponsTestPage();

		coupons.waitForAjaxToComplete();
		coupons.getBtnSelectdigcoupons().waitForPresent(5000);
		coupons.getBtnSelectdigcoupons().click();
		PerfectoUtils.reportMessage("Clicked on Select Digital Coupons..", MessageTypes.Pass);
	}

	public void clickCloseFromTheDigCouponsLoginpopup() {
		DigitalCouponsLoginPopupTestPage dcloginpopup = new DigitalCouponsLoginPopupTestPage();

		if (dcloginpopup.getLblPopuptext().isPresent()) {
			PerfectoUtils.reportMessage("Login popup present..", MessageTypes.Pass);
			dcloginpopup.getImgPopupclose().click();
			PerfectoUtils.reportMessage("Clicked Close icon");
		}
	}

	/**
	 * Navigate to Party trays Make ready page from home page
	 */
	@QAFTestStep(description = "Navigate to Party trays Make ready page from home page")
	public void NavigateToPartyTraysMakeReadyPageFromHomePage() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		frontdoor.getFrontLiImgCatridges().get(0).verifyPresent();
		frontdoor.getFrontLiImgCatridges().get(0).click();
		makeready.getMakeLblMadeforu().waitForPresent(5000);
		makeready.getMakeLblPickup().verifyPresent();
	}

	/**
	 * Navigate to Flowers Make ready page from home page
	 */
	@QAFTestStep(description = "Navigate to Flowers Make ready page from home page")
	public void NavigateToFlowersMakeReadyPageFromHomePage() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		frontdoor.getFrontLiImgCatridges().get(2).verifyPresent();
		frontdoor.getFrontLiImgCatridges().get(2).click();
		makeready.getMakeLblMadeforu().waitForPresent(5000);
		frontdoor.getFrontImgFav().verifyPresent();
		makeready.getMakeLblPickup().verifyPresent();
	}

	/**
	 * Navigate to Cakes Make ready page from home page
	 */
	@QAFTestStep(description = "Navigate to Cakes Make ready page from home page")
	public void NavigateToCakesMakeReadyPageFromHomePage() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		frontdoor.getFrontLiImgCatridges().get(1).verifyPresent();
		frontdoor.getFrontLiImgCatridges().get(1).click();
		makeready.getMakeLblMadeforu().waitForPresent(5000);
		makeready.getMakeLblPickup().verifyPresent();
	}

	@QAFTestStep(description = "I enter zipcode {0} and cancel the store selection process")
	public void iEnterZipcodeAndCancelTheStoreSelectionProcess(String zipCode) {
		SelectStoreTestPage selectstore = new SelectStoreTestPage();

		try {
			selectstore.getSelstoreLblPickupstoretitle().waitForPresent(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (selectstore.getSelstoreLblPickupstoretitle().isPresent()) {
			reportMessage("Selecting the Store from the pop-up.", MessageTypes.Pass);
			selectstore.getSelstoreLblPickupstoretitle().verifyPresent();

			// Enter Zip code
			selectstore.getSelstoreTxtZipcode().click();
			selectstore.getSelstoreTxtZipcode().clear();
			selectstore.getSelstoreTxtZipcode().sendKeys(zipCode);
			selectstore.getSelstoreBtnGo().click();
			selectstore.waitForAjaxToComplete();

			if (selectstore.getSelstoreLblResults().isPresent()) {
				reportMessage(selectstore.getSelstoreLblResults().getText(), MessageTypes.Info);
			}

			selectstore.getSelstoreBtnClose().click();

		} else {
			reportMessage("Select a store pop up is not present", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I click on the current store link")
	public void iClickonCurrentStoreLink() {
		MakeReadyTestPage selectstore = new MakeReadyTestPage();

		selectstore.getMakeLnkStorename().click();
		reportMessage("Clicked on the current store " + selectstore.getMakeLnkStorename().getText() + " link",
				MessageTypes.Info);
	}

	/**
	 * Navigate to Party trays Make ready page from home page
	 */
	@QAFTestStep(description = "Navigate to Flowers Make ready page from instore home page")
	public void NavigateToFlowersMakeReadyPageFromInstoreHomePage() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		frontdoor.getFrontLiBlockCatridges().get(0).waitForPresent(5000);
		int size = frontdoor.getFrontLiBlockCatridges().size();

		PerfectoUtils.reportMessage("Number of Make ready catridges available: " + size);

		frontdoor.getFrontLiBlockCatridges().get(2).waitForPresent(5000);
		reportMessage("Selected Catridge: " + frontdoor.getFrontLiBlockCatridges().get(2).getAttribute("title"));
		frontdoor.getFrontLiBlockCatridges().get(2).click();
		frontdoor.waitForPageToLoad();
		frontdoor.waitForAjaxToComplete();

		makeready.getMakeLblMadeforu().waitForPresent(5000);
		makeready.getMakeLblPickup().verifyPresent();
	}

	/**
	 * Navigate to Party trays Make ready page from home page
	 */
	@QAFTestStep(description = "Navigate to Cakes Make ready page from instore home page")
	public void NavigateToCakesMakeReadyPageFromInstoreHomePage() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		frontdoor.getFrontLiBlockCatridges().get(0).waitForPresent(5000);
		int size = frontdoor.getFrontLiBlockCatridges().size();

		PerfectoUtils.reportMessage("Number of Make ready catridges available: " + size);

		frontdoor.getFrontLiBlockCatridges().get(1).waitForPresent(5000);
		reportMessage("Selected Catridge: " + frontdoor.getFrontLiBlockCatridges().get(1).getAttribute("title"));
		frontdoor.getFrontLiBlockCatridges().get(1).click();
		frontdoor.waitForPageToLoad();
		frontdoor.waitForAjaxToComplete();

		makeready.getMakeLblMadeforu().waitForPresent(5000);
		makeready.getMakeLblPickup().verifyPresent();
	}

	/**
	 * Navigate to Party trays Make ready page from home page
	 */
	@QAFTestStep(description = "Navigate to Party trays Make ready page from instore home page")
	public void NavigateToPartyTraysMakeReadyPageFromInstoreHomePage() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		frontdoor.getFrontLiBlockCatridges().get(0).waitForPresent(5000);
		int size = frontdoor.getFrontLiBlockCatridges().size();

		PerfectoUtils.reportMessage("Number of Make ready catridges available: " + size);

		frontdoor.getFrontLiBlockCatridges().get(0).waitForPresent(5000);
		reportMessage("Selected Catridge: " + frontdoor.getFrontLiBlockCatridges().get(0).getAttribute("title"));
		frontdoor.getFrontLiBlockCatridges().get(0).click();
		frontdoor.waitForPageToLoad();
		frontdoor.waitForAjaxToComplete();

		makeready.getMakeLblMadeforu().waitForPresent(5000);
		makeready.getMakeLblPickup().verifyPresent();
	}

	@QAFTestStep(description = "Navigate to any make ready tabs from any make ready tab")
	public void NavigateToAnyMakereadytabsfromanyMakereadytab() {
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		makeready.getMakeLnkDelitraysTab().click();
		makeready.getMakeLnkActiveTab().waitForPresent(5000);
		if (makeready.getMakeLnkActiveTab().getText()
				.equals(ConfigurationManager.getBundle().getString("MakeReadyTab.DeliTrays"))) {
			PerfectoUtils.reportMessage("Navigated to Deli Trays Make Ready Tab successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not Navigated to Deli Trays Make Ready Tab", MessageTypes.Fail);
		}

		makeready.getMakeLnkCakesTab().click();
		makeready.getMakeLnkActiveTab().waitForPresent(5000);
		if (makeready.getMakeLnkActiveTab().getText()
				.equals(ConfigurationManager.getBundle().getString("MakeReadyTab.Cakes"))) {
			PerfectoUtils.reportMessage("Navigated to Cakes Make Ready Tab successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not Navigated to Cakes Make Ready Tab", MessageTypes.Fail);
		}

		makeready.getMakeLnkFlowersTab().click();
		makeready.getMakeLnkActiveTab().waitForPresent(5000);
		if (makeready.getMakeLnkActiveTab().getText()
				.equals(ConfigurationManager.getBundle().getString("MakeReadyTab.Flowers"))) {
			PerfectoUtils.reportMessage("Navigated to Flowers Make Ready Tab successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not Navigated to Flowers Make Ready Tab", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify HEB logo in home page Login and Register page")
	public void iVerifyHEBMainlogo() {
		InStoreHomePage logo = new InStoreHomePage();
		myaccountpage myAcc = new myaccountpage();
		LoginTestPage login = new LoginTestPage();
		Registration register = new Registration();

		logo.getHomeLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed in Home page", MessageTypes.Pass);
		iNavigateToInstoreHomePage();
		logo.getHomeLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed in InStore Home page", MessageTypes.Pass);
		myAcc.iClickonLoginlink();
		login.getLoginImgLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed in Login page", MessageTypes.Pass);
		login.getLoginLnkCreateOne().click();
		login.getLoginImgLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed in Registration page", MessageTypes.Pass);
		register.iRegisterANewAccount();
		register.iClickGotItThanksButtonInThankYouPage();
		logo.getHomeLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed after Registration", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I Verify HEB Main Logo")
	public void iVerifyHEBlogo() {
		InStoreHomePage logo = new InStoreHomePage();

		logo.getHomeLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I verify HEB logo in Weekly ads recipe coupons My Account Gift cards MyList and forgot password link")
	public void iVerifyHEBlogoWeeklyAdCouponsRecipesMyAccountGiftCard() throws InterruptedException {
		InStoreHomePage logo = new InStoreHomePage();
		WeeklyAdsStepDef weeklyad = new WeeklyAdsStepDef();
		Recipes recipes = new Recipes();
		CouponsStepDef coupons = new CouponsStepDef();
		MyList list = new MyList();
		PaymentGatewayStepdef pay = new PaymentGatewayStepdef();
		myaccountpage myacc = new myaccountpage();
		LoginTestPage login = new LoginTestPage();

		pay.navigateToGiftCardsPage();
		logo.getHomeLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed in Gift Card Page", MessageTypes.Pass);
		myacc.clickUserNameLink();
		logo.getHomeLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed in My Account Page", MessageTypes.Pass);
		weeklyad.clickOnWeeklyAdsFromInstoreHomepage();
		logo.getHomeLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed in WeeklyAds", MessageTypes.Pass);
		logo.getHomeLogo().click();
		recipes.iNavigateToRecipeLandingPage();
		logo.getHomeLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed in Recipes", MessageTypes.Pass);
		coupons.iNavigateToCouponPageFromNewHomePage();
		logo.getHomeLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed in Coupons", MessageTypes.Pass);

		list.iNavigateToMyListTestPage();
		logo.getHomeLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed in MyList", MessageTypes.Pass);
		myacc.iClickonLoginlink();
		myacc.iClickForgotPasswordLink();
		login.getLoginImgLogo().verifyPresent();
		PerfectoUtils.reportMessage("HEB Logo is displayed in Forgot Password page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I validate the view page source Canonical element")
	public synchronized static void IValidateTheViewPageSourceCanonicalElement() {
		InStoreHomePage logo = new InStoreHomePage();
		String expURL = "<link rel=\"canonical\" href=\"https://www.heb.com/recipe/landing\"";
		String pageSource = PerfectoUtils.getDriver().getPageSource();
		System.out.println(expURL);
		
		if(pageSource.contains(expURL)){
			PerfectoUtils.reportMessage("Canonical element have correct URL value " , MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Canonical element does not have correct URL value ", MessageTypes.Fail);
		}
		
	}
	
	@QAFTestStep(description = "I verify session times out if user keeps system idle for {0} minutes")
	public synchronized static void IVerifySessionTimesOut(int min) throws InterruptedException {
		LoginTestPage loginpage = new LoginTestPage();
		MyAccountPage myAccountPage = new MyAccountPage();
		
		TimeUnit.MINUTES.sleep(min);
		PerfectoUtils.reportMessage("System is idle for "+min+" minutes" , MessageTypes.Pass);
		myAccountPage.getMyAccountLnkUserName().click();	
		loginpage.getLoginBtnLogin().verifyPresent();
	}

}
