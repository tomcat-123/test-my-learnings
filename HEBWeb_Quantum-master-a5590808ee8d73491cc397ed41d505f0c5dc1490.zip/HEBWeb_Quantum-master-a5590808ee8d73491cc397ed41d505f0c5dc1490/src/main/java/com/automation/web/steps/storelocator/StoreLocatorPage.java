package com.automation.web.steps.storelocator;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.homepage.FrontdoorTestPage;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.search.PdtsearchresultTestPage;
import com.automation.web.pages.storelocator.FindAStoreTestPage;
import com.automation.web.pages.storelocator.SelectStoreTestPage;
import com.automation.web.pages.storelocator.StoreDetailsTestPage;
import com.automation.web.pages.storelocator.StoreLocatorTestPage;
import com.automation.web.pages.weeklyads.WeeklyaddealsTestPage;
import com.automation.web.steps.homepage.CDPStepDef;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

/*List of steps in StoreLocatorPage

* I enter a valid zipcode {0} in find store
* I enter a valid zipcode {0} and click find button
* I enter a valid zipcode {0} for Hot User
* I enter a valid city {0} in find store
* I click on find button
* I verify the stores getting displayed for the zipcode {0}
* I verify the stores getting displayed on the Bing map
* I select a store with store id {0}
* I select a store details with store id {0}
* Select a store from zipcode {0} with store id {1}
* Click on store details link {0}
* I Verify the store detail page {0}
* I Verify Invalid ZiporCity Error Message {0}
* I Find A Store within {0} miles
* I Load All Stores in find a store page
* I Verify the store details with StoreID {0} {1}
* I mouseover My Store and verify address {0}
* I verify the selected store is displayed on the top
* User click on Store Finder icon
* User mouse hovers on Store Finder icon
* Select a store from Front door page using zipcode {0} with store id {1}
* I verify the selected store is displayed on the top of frontdoor page

*/

public class StoreLocatorPage {

	@QAFTestStep(description = "I enter a valid zipcode {0} in find store")
	public void iEnterAValidZipcodeInFindStore(String zipcode) {
		StoreLocatorTestPage getLnkFindStore = new StoreLocatorTestPage();

		getLnkFindStore.getLnkFindStore().verifyPresent();
		PerfectoUtils.mousehoverusingActions(getLnkFindStore.getLnkFindStore());
		getLnkFindStore.getBtnFind().waitForVisible(3000);
		if (getLnkFindStore.getTbxFindStore().verifyPresent())
			PerfectoUtils.reportMessage("Find a store flyout is displayed");
		else
			PerfectoUtils.reportMessage("Find a store flyout is not displayed");
		// PerfectoUtils.mouseoverandclick(getLnkFindStore.getTbxFindStore());
		getLnkFindStore.getTbxFindStore().click();
		getLnkFindStore.getTbxFindStore().sendKeys(zipcode);
		ConfigurationManager.getBundle().setProperty("ZIPCODE", zipcode);
	}
	
	@QAFTestStep(description = "I enter a valid zipcode {0} and click find button")
	public static void iEnterAValidZipcodeClickFindButton(String zipcode) {
		StoreLocatorTestPage getLnkFindStore = new StoreLocatorTestPage();
		getLnkFindStore.getLnkFindStore().verifyPresent();
		PerfectoUtils.mousehoverusingActions(getLnkFindStore.getLnkFindStore());
		getLnkFindStore.getBtnFind().waitForVisible(3000);
		if (getLnkFindStore.getTbxFindStore().verifyPresent())
			PerfectoUtils.reportMessage("Find a store flyout is displayed");
		else
			PerfectoUtils.reportMessage("Find a store flyout is not displayed");
		getLnkFindStore.getTbxFindStore().click();
		getLnkFindStore.getTbxFindStore().sendKeys(zipcode);
		getLnkFindStore.getBtnFind().click();
		
		getBundle().setProperty("ZIPCODE", zipcode);
	}
	
	@QAFTestStep(description = "I enter a valid zipcode {0} for Hot User")
	public void iEnterAValidZipcodeforHotUser(String zipcode) {
		StoreLocatorTestPage getLnkFindStore = new StoreLocatorTestPage();
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		getLnkFindStore.getLnkFindStore().verifyPresent();
		getLnkFindStore.getLnkFindStore().click();
		getLnkFindStore.getTxtFindAStore().verifyPresent();
		pdtsearchresult.getTxtFindyourstore().sendKeys(zipcode);
		pdtsearchresult.getBtnSearchFindyourstore().click();
	}
	
	@QAFTestStep(description = "I enter a valid city {0} in find store")
	public void iEnterAValidCityInFindStore(String city) {
		StoreLocatorTestPage getLnkFindStore = new StoreLocatorTestPage();

		getLnkFindStore.getLnkFindStore().verifyPresent();
		PerfectoUtils.mousehoverusingActions(getLnkFindStore.getLnkFindStore());
		getLnkFindStore.getBtnFind().waitForVisible(3000);
		if (getLnkFindStore.getTbxFindStore().verifyPresent())
			PerfectoUtils.reportMessage("Find a store flyout is displayed");
		else
			PerfectoUtils.reportMessage("Find a store flyout is not displayed");
		getLnkFindStore.getTbxFindStore().click();
		getLnkFindStore.getTbxFindStore().sendKeys(city);
		getLnkFindStore.getBtnFind().click();
	}
	
	@QAFTestStep(description = "I click Find your store in front door page")
	public synchronized void iClickFindyourstoreinfrontdoorpage() {
		FrontdoorTestPage front = new FrontdoorTestPage();
		
		front.getFrontLnkFindyourstore().click();
	}

	@QAFTestStep(description = "I click on find button")
	public synchronized void iClickOnFindButton() {
		StoreLocatorTestPage storelocator = new StoreLocatorTestPage();

		// PerfectoUtils.mouseoverandclick(storelocator.getLnkFindStore(),
		// storelocator.getBtnFind());
		// storelocator.getBtnFind().waitForVisible(50000);
		// PerfectoUtils.mouseoverandclick(storelocator.getBtnFind());
		storelocator.getBtnFind().click();
		storelocator.getTxtFindAStore().waitForPresent(30000);

		if (storelocator.getTxtFindAStore().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Find a store page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Find a store page.", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I verify the stores getting displayed for the zipcode {0}")
	public void iVerifyTheStoresGettingDisplayedusingZip(String zipcode) {
		StoreLocatorTestPage storelocator = new StoreLocatorTestPage();

		// Verifying the Find Store page
		storelocator.getTxtFindAStore().verifyPresent();

		String myzipcodeaddress = storelocator.getTxtZipcodeUnderResults().getText();
		System.out.println("myzipcode: " + myzipcodeaddress);

		if (myzipcodeaddress.contains(zipcode)) {
			PerfectoUtils.reportMessage("Entered zipcode matched", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Entered zipcode does not matched", MessageTypes.Fail);
		}

	}
	

	@QAFTestStep(description = "I verify the stores getting displayed on the Bing map")
	public void iVerifyTheStoresGettingDisplayedOnTheBingMap() {
		StoreLocatorTestPage storelocator = new StoreLocatorTestPage();

		int i = 0;

		// Verifying the Find Store page
		storelocator.getTxtFindAStore().verifyPresent();

		// Verify error message
		try {
			while (storelocator.getLblErrorSection().isDisplayed() && i < 10) {
				PerfectoUtils.reportMessage("Error message displayed: Retrying.." + i);
				i++;
				storelocator.getBtnSearch().click();
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error message is not displayed");
		}

		try {
			if (storelocator.getLblErrorSection().isDisplayed()) {
				if (storelocator.getTxtStorersName().size() < 1)
					PerfectoUtils.reportMessage("No store is displayed", MessageTypes.Fail);
				else
					PerfectoUtils.reportMessage("Store finder error message is displayed");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		String myzipcode = storelocator.getTbxEnterStore().getAttribute("value");
		System.out.println("myzipcode: " + myzipcode);
		String zipcode = ConfigurationManager.getBundle().getString("ZIPCODE");

		System.out.println("zipcode: " + zipcode);

		if (myzipcode.equals(zipcode)) {
			PerfectoUtils.reportMessage("Entered zipcode matched", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Entered zipcode does not matched", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I select a store with store id {0}")
	public void iSelectAStoreWithStoreId(String storeId) {
		StoreLocatorTestPage storelocator = new StoreLocatorTestPage();
		String altStoreId = "108";
		String selecedStore;

		try {
			// Work around to click search button
			storelocator.getBtnSearch().verifyPresent();
			storelocator.getBtnSearch().click();

			storelocator.getSelstoreGetBtnStoreselectwithstoreid(storeId).waitForPresent(30000);
			if (storelocator.getSelstoreGetBtnStoreselectwithstoreid(storeId).isPresent()) {
				PerfectoUtils.scrolltoelement(storelocator.getSelstoreGetBtnStoreselectwithstoreid(storeId));
				storelocator.getSelstoreGetLblStoreid(storeId).verifyPresent();
				storelocator.getSelstoreGetLblStorename(storeId).verifyPresent();
				selecedStore = storelocator.getSelstoreGetLblStorename(storeId).getText();
				storelocator.getSelstoreGetBtnStoreselectwithstoreid(storeId).click();
				PerfectoUtils.reportMessage("Selected store with store ID: " + storeId, MessageTypes.Pass);

			} else {
				PerfectoUtils.reportMessage("Store with store ID: " + storeId + " not found, Hence selecting store id: " + altStoreId,
						MessageTypes.Info);
				PerfectoUtils.scrolltoelement(storelocator.getSelstoreGetBtnStoreselectwithstoreid(altStoreId));
				storelocator.getSelstoreGetLblStoreid(altStoreId).verifyPresent();
				storelocator.getSelstoreGetLblStorename(altStoreId).verifyPresent();
				selecedStore = storelocator.getSelstoreGetLblStorename(altStoreId).getText();
				storelocator.getSelstoreGetBtnStoreselectwithstoreid(altStoreId).click();
				PerfectoUtils.reportMessage("Selected store with store ID: " + altStoreId, MessageTypes.Pass);

			}

			getBundle().setProperty("selectedStore", selecedStore);

		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured while searching for the store with store ID: " + storeId, MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I select a store details with store id {0}")
	public void iSelectAStoreDetailsWithStoreId(String storeId) {
		StoreDetailsTestPage selectStore = new StoreDetailsTestPage();
		selectStore.getSelectStoreDetailswithstoreid(storeId).waitForPresent(50000);
		if (selectStore.getSelectStoreDetailswithstoreid(storeId).isPresent()) {
			PerfectoUtils.scrolltoelement(selectStore.getSelectStoreDetailswithstoreid(storeId));
			selectStore.getSelectStoreDetailswithstoreid(storeId).click();
			PerfectoUtils.reportMessage("Selected store details with store ID: " + storeId, MessageTypes.Pass);

			}
	}

	@QAFTestStep(description = "Select a store from zipcode {0} with store id {1}")
	public void selectaStoreFromZipcodeWithStoreId(String zipCode, String storeId) {
		FrontdoorTestPage front = new FrontdoorTestPage();

		CDPStepDef.enterValidZipcodeUsingMouseHover(zipCode);
		iSelectAStoreWithStoreId(storeId);
		iVerifyTheSelectedStoreIsDisplayedOnTheTop();
		front.getFrontImgFav().verifyPresent();
	}
	
	@QAFTestStep(description = "Click on store details link {0}")
	public void clickonStoreDetailsLink(String header) {
		StoreLocatorTestPage storelocatorpage = new StoreLocatorTestPage();
		StoreDetailsTestPage getStoreDetails = new StoreDetailsTestPage();
		PerfectoUtils.scrolltoelement(getStoreDetails.getSelectStoreDetailswithstoreid("556"));
		PerfectoUtils.mousehoverusingActions(storelocatorpage.getLnkStoreDetails());
		storelocatorpage.getLnkStoreDetails().click();
		getStoreDetails.getLnkAddressHeader(header).waitForPresent(30000);

		if (getStoreDetails.getLnkAddressHeader(header).isPresent()) {
			PerfectoUtils.reportMessage("Navigated to store details page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to store details page.", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I Verify the store detail page {0}")
	public void iVerifyStoreDetailPage(String header) {
		StoreDetailsTestPage getStoreDetails = new StoreDetailsTestPage();
		getStoreDetails.getLnkAddressHeader(header).verifyPresent();
		getStoreDetails.getLblAddresssubtitle().verifyPresent();
		getStoreDetails.getLblAddressdesc1().verifyPresent();
		getStoreDetails.getLblAddressdesc2().verifyPresent();
		getStoreDetails.getLblAddressdesc3().verifyPresent();
		getStoreDetails.getLblAddressMiles().verifyPresent();
		getStoreDetails.getLnkDirectiontostore().verifyPresent();
		getStoreDetails.getLblStorehrsphnnum().verifyPresent();
		getStoreDetails.getLblmainphnsubtitle().verifyPresent();
		getStoreDetails.getLblStorehrssubtitle().verifyPresent();
		getStoreDetails.getLblPharmacysubtitle().verifyPresent();
		getStoreDetails.getLblPharmacyhrssubtitle().verifyPresent();
		getStoreDetails.getLblphonenum().verifyPresent();
		getStoreDetails.getLnkViewstoread().verifyPresent();
		getStoreDetails.getLblAvailabledeptservice().verifyPresent();
		getStoreDetails.getLblStoreFeatures().verifyPresent();
	}
	
	@QAFTestStep(description = "I verify layout of bottom portion of Store Details page")
	public void iVerifyLayoutofBottomPortionofStoreDetailPage() {
		StoreLocatorTestPage storeloc = new StoreLocatorTestPage();
		StoreDetailsTestPage getStoreDetails = new StoreDetailsTestPage();
		WeeklyaddealsTestPage print = new WeeklyaddealsTestPage();
		
		PerfectoUtils.scrolltoelement(storeloc.getStoreResultsStoreName("1", "1"));
		storeloc.getLnkStoreDetails().click();
		PerfectoUtils.scrolltoelement(getStoreDetails.getLblHereeverything());
		getStoreDetails.getLblHereeverything().verifyPresent();
		getStoreDetails.getImgHereeverythingLogo().verifyPresent();
		getStoreDetails.getLnkViewstoread().verifyPresent();
		getStoreDetails.getLnkViewstoreguide().verifyPresent();
		getStoreDetails.getLnkViewstoread().click();
		print.getLblViewprintversion().verifyPresent();
		PerfectoUtils.getDriver().navigate().back();
		String viewGuideLink = getStoreDetails.getLnkViewstoreguide().getAttribute("href");
		PerfectoUtils.reportMessage(viewGuideLink+" view guide link", MessageTypes.Info);
		if(viewGuideLink.contains(".pdf")){
			PerfectoUtils.reportMessage("View guide link opens pdf file", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("View guide link don't have pdf file", MessageTypes.Fail);
		}
		getStoreDetails.getLblAvailabledeptservice().verifyPresent();
		getStoreDetails.getLblNostoredoes().verifyPresent();
		getStoreDetails.getLnkLearnmore().verifyPresent();
	}
	

	@QAFTestStep(description = "I verify Store Guide hyperlink does not appear")
	public void iVerifyStoreGuidehyperlinknotDisplayed() {
		StoreDetailsTestPage getStoreDetails = new StoreDetailsTestPage();
		
		PerfectoUtils.scrolltoelement(getStoreDetails.getLblHereeverything());
		getStoreDetails.getLnkViewstoreguide().verifyNotPresent();
	}

	@QAFTestStep(description = "I Verify Invalid ZiporCity Error Message {0}")
	public void iVerifyInvalidZipErrorMessage(String errorMsg) {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		String actualerrorMsg = pdtsearchresult.getTxtFindastoreErrormsg().getText();
		if (actualerrorMsg.equals(errorMsg)) {
			PerfectoUtils.reportMessage("Actual Error message '" + actualerrorMsg + " is matched with '" + errorMsg,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Actual Error message '" + actualerrorMsg + " is not matched with '" + errorMsg,
					MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I Find A Store within {0} miles")
	public void iFindaStorewithinMiles(String miles) {
		FindAStoreTestPage storelocatorpage = new FindAStoreTestPage();
		PerfectoUtils.dropdownSelectByValue(storelocatorpage.getDdlDistanceOptions(),miles);
		storelocatorpage.getFindstoreBtnSearch().click();
		String storeCounttxt ="";
		String temp = "";
		try{
		storelocatorpage.getBtnLoadNext().waitForPresent(20000);
		storelocatorpage.clickLoadMoreStoresuntilVisible();
		}catch(Exception e){
			temp = "InitialStoreCount";
			System.out.println("No more Load Store button link");
		}
		
		if(temp.equals("InitialStoreCount")){
			storeCounttxt = storelocatorpage.getLblPageInitialCount().getText();
		}else
		{
			storeCounttxt = storelocatorpage.getLblPageStoreCount().getText();
		}
		String[] storeCounttxtSplit = storeCounttxt.split("of ");
		String maxStoreCount = storeCounttxtSplit[1];
		String maxmilestext = storelocatorpage.getMaxMilestoStore(maxStoreCount).getText();
		String[] maxmilestextSplit = maxmilestext.split("miles");
		float maxMiles = Float.parseFloat(maxmilestextSplit[0].trim());
		float selectedMiles = Integer.parseInt(miles);
		if(maxMiles <= selectedMiles)
			PerfectoUtils.reportMessage("Search Results of Store contains "+maxStoreCount+" stores with in "+selectedMiles+" miles", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Search Results of Store does not contain stores with in "+selectedMiles+" miles", MessageTypes.Fail);
	}
	
	@QAFTestStep(description = "I Load All Stores in find a store page")
	public void iLoadAllStores() {
		FindAStoreTestPage storelocatorpage = new FindAStoreTestPage();
		storelocatorpage.getBtnLoadNext().waitForPresent(20000);
		storelocatorpage.clickLoadMoreStoresuntilVisible();
		String storeCounttxt = storelocatorpage.getLblPageStoreCount().getText();
		String[] storeCounttxtSplit = storeCounttxt.split("of ");
		String maxStoreCount = storeCounttxtSplit[1];
		if(storelocatorpage.getMaxMilestoStore(maxStoreCount).verifyPresent())
			PerfectoUtils.reportMessage("Search Results of Store contains "+maxStoreCount+" stores and loaded all stores", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Search Results of Store does not loaded with all stores", MessageTypes.Fail);
	}
	
	@QAFTestStep(description = "I Verify the store details with StoreID {0} {1}")
	public void iVerifyStoreDetailsWithStoreID(String storeId, String storeHeader) {
		StoreDetailsTestPage getStoreDetails = new StoreDetailsTestPage();
		iSelectAStoreDetailsWithStoreId(storeId);
		String currentURL = PerfectoUtils.getDriver().getCurrentUrl();
		if(currentURL.contains(storeId))
			PerfectoUtils.reportMessage("Store Details retrieved using Store ID successfully", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Store Details not retrieved using Store ID", MessageTypes.Fail);
		getStoreDetails.getLnkAddressHeader(storeHeader).verifyPresent();
	}
	
	@QAFTestStep(description = "I mouseover My Store and verify address {0}")
	public void iMouseoverMyStoreAndVerifyAddress(String storeHeader) {
		StoreLocatorTestPage getStoreDetails = new StoreLocatorTestPage();
		String myStoreAddress = getStoreDetails.getTxtFindStoreAddress().getText();
		if(myStoreAddress.equals(storeHeader))
			PerfectoUtils.reportMessage("My Store is updated with the selected store", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("My Store is not updated with the selected store", MessageTypes.Fail);
		PerfectoUtils.mousehoverusingActions(getStoreDetails.getLnkFindStore());
		String myStoreDropAddress = getStoreDetails.getTxtFindStoreDropAddress().getText();
		if(myStoreDropAddress.equals(storeHeader))
			PerfectoUtils.reportMessage("My Store Drop is updated with the selected store", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("My Store Drop is not updated with the selected store", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I verify the selected store is displayed on the top")
	public static void iVerifyTheSelectedStoreIsDisplayedOnTheTop() {
		InStoreHomePage instorehome = new InStoreHomePage();

		String ExpStore = getBundle().getString("selectedStore");
		String actualStore;

		try {
			actualStore = instorehome.getHomeLblStorename().getText();
			instorehome.getHomeLblStorename().waitForText(ExpStore, 50000);
		} catch (Exception e) {
			// Ignore
		}

		actualStore = instorehome.getHomeLblStorename().getText();
		actualStore = PerfectoUtils.removeSpecialCharacters(actualStore);
		ExpStore = PerfectoUtils.removeSpecialCharacters(ExpStore);

		if (ExpStore.equalsIgnoreCase(actualStore)) {
			PerfectoUtils.reportMessage("Selected store is displayed on the top", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected store is not displayed on the top", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description="User click on Store Finder icon")
	public void userClickOnStoreFinderIcon(){
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		frontdoor.getFrontLblStorefinder().click();
	}
	
	@QAFTestStep(description="User mouse hovers on Store Finder icon")
	public void UsermousehoversonStoreFindericon(){
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		//frontdoor.getFrontLblStorefinder().click();
		PerfectoUtils.mouseover(frontdoor.getFrontLblStorefinder());
	}
	
	@QAFTestStep(description = "Select a store from Front door page using zipcode {0} with store id {1}")
	public void selectaStoreFromFrontDoorPageUsingZipcodeWithStoreId(String zipCode, String storeId) {
		CDPStepDef.enterValidZipcodeUsingMouseHover(zipCode);
		iSelectAStoreWithStoreId(storeId);
		iVerifyTheSelectedStoreIsDisplayedOnTheTopOfFrontDoorPage();

	}
	
	@QAFTestStep(description = "I verify the selected store is displayed on the top of frontdoor page")
	public static void iVerifyTheSelectedStoreIsDisplayedOnTheTopOfFrontDoorPage() {
		FrontdoorTestPage front = new FrontdoorTestPage();

		String ExpStore = getBundle().getString("selectedStore");
		String actualStore;

		try {
			actualStore = front.getFrontLblStorename().getText();
			front.getFrontLblStorename().waitForText(ExpStore, 50000);
		} catch (Exception e) {
			// Ignore
		}

		actualStore = front.getFrontLblStorename().getText();
		actualStore = PerfectoUtils.removeSpecialCharacters(actualStore);
		ExpStore = PerfectoUtils.removeSpecialCharacters(ExpStore);

		if (ExpStore.equalsIgnoreCase(actualStore)) {
			PerfectoUtils.reportMessage("Selected store is displayed on the top", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected store is not displayed on the top", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I validate the Find a Store page properties")
	public void iValidateTheFindAStorePageProperties() {
		FindAStoreTestPage findAStore = new FindAStoreTestPage();
		
		findAStore.getFindstoreLblPagetitle().verifyPresent();
		findAStore.getFindstoreBtnSearch().verifyPresent();
		findAStore.getFindstoreTxtEnterzipcode().verifyPresent();
		findAStore.getDdlDistanceOptions().verifyPresent();
		findAStore.getFindstoreImgMap().verifyPresent();
		findAStore.getFindstoreImgRefineyourresults().verifyPresent();
		PerfectoUtils.reportMessage("Checkboxes available in this page: "+ findAStore.getFindstoreLiChkRefinecheckboxes().size());
		findAStore.getFindstoreLiChkRefinecheckboxes().get(0).verifyPresent();
		PerfectoUtils.reportMessage("See more links available in this page: "+ findAStore.getFindstoreLiLnkSeemore().size());
		findAStore.getFindstoreLiLnkSeemore().get(0).verifyPresent();
		findAStore.getFindstoreLnkCentralmarket().verifyPresent();
		findAStore.getFindstoreLblBreadcrumb().verifyPresent();
		
	}
	
	
}
