package com.automation.web.pages.coupons;

import java.util.List;

import com.automation.web.components.coupons.DigitalCouponBlocksInSelectedSection;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class DigitalCouponsSelectedSectionTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "dcselected.btn.addtolist")
	private QAFWebElement btnAddtolist;

	@FindBy(locator = "dcselected.btn.addtolistwhendisabled")
	private QAFWebElement btnAddtolistwhendisabled;

	@FindBy(locator = "dcselected.lbl.sortby")
	private QAFWebElement lblSortby;

	@FindBy(locator = "dcselected.li.sortoptions")
	private List<QAFWebElement> liSortoptions;

	@FindBy(locator = "dcselected.lnk.printpage")
	private QAFWebElement lnkPrintpage;

	@FindBy(locator = "dcselected.li.couponblocks")
	private List<DigitalCouponBlocksInSelectedSection> liCouponblocks;

	@FindBy(locator = "dcselected.lbl.filterby")
	private QAFWebElement lblFilterby;

	@FindBy(locator = "dcselected.li.filterbyoptions")
	private List<QAFWebElement> liFilterbyoptions;

	@FindBy(locator = "dcselected.lbl.resultscount")
	private QAFWebElement lblResultscount;

	@FindBy(locator = "dcselected.chk.addallcouponstolist")
	private QAFWebElement chkAddallcouponstolist;

	public QAFWebElement getLblFilterby() {
		return lblFilterby;
	}

	public List<QAFWebElement> getLiFilterbyoptions() {
		return liFilterbyoptions;
	}

	public QAFWebElement getChkAddallcouponstolist() {
		return chkAddallcouponstolist;
	}

	public QAFWebElement getLblSortby() {
		return lblSortby;
	}

	public List<QAFWebElement> getLiSortoptions() {
		return liSortoptions;
	}

	public QAFWebElement getLnkPrintpage() {
		return lnkPrintpage;
	}

	public List<DigitalCouponBlocksInSelectedSection> getLiCouponblocks() {
		return liCouponblocks;
	}

	public QAFWebElement getBtnAddtolist() {
		return btnAddtolist;
	}

	public QAFWebElement getBtnAddtolistwhendisabled() {
		return btnAddtolistwhendisabled;
	}

	public QAFWebElement getLblResultscount() {
		return lblResultscount;
	}

}