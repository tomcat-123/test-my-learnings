package com.automation.web.components;

import java.util.List;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CDPProductBlocks extends QAFWebComponent{

	public CDPProductBlocks(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}
	@FindBy(locator = "cdp.txt.productTitle")
	private QAFWebElement cdpTxtProductname;
	@FindBy(locator = "cdp.img.productimage")
	private QAFWebElement cdpImgProductImage;
	@FindBy(locator = "cdp.txt.productPrice")
	private QAFWebElement cdpTxtProductPrice;
	@FindBy(locator = "cdp.txt.productQuantity")
	private QAFWebElement cdpTxtProductQuantity;
	@FindBy(locator = "cdp.btn.productAddtoCart")
	private QAFWebElement cdpBtnAddtoCart;
	@FindBy(locator = "cdp.btn.productAddtoList")
	private QAFWebElement cdpBtnAddtoList;
	@FindBy(locator = "cdp.btn.productIncrementAddtoList")
	private QAFWebElement cdpBtnIncAddtoList;
	@FindBy(locator = "cdp.btn.productDecrementAddtoList")
	private QAFWebElement cdpBtnDecAddtoList;
	@FindBy(locator = "cdp.img.feature")
	private List<QAFWebElement> cdpImgFeature;
	@FindBy(locator = "cdp.lbl.minimumquantity")
	private QAFWebElement cdpLblMinimumquantity;
	@FindBy(locator = "cdp.btn.minusaddtocart")
	private QAFWebElement cdpBtnMinusaddtocart;	
	@FindBy(locator = "cdp.edt.inputqty")
	private QAFWebElement Edtinputqty;
	@FindBy(locator = "cdp.lbl.ratings")
	private QAFWebElement cdpLblRatings;
	
	
	
	public List<QAFWebElement> getCdpImgFeature() {
		return cdpImgFeature;
	}

	public QAFWebElement getCdpTxtProductname() {
		return cdpTxtProductname;
	}

	public QAFWebElement getCdpImgProductImage() {
		return cdpImgProductImage;
	}

	public QAFWebElement getCdpTxtProductPrice() {
		return cdpTxtProductPrice;
	}

	public QAFWebElement getCdpTxtProductQuantity() {
		return cdpTxtProductQuantity;
	}

	public QAFWebElement getCdpBtnAddtoCart() {
		return cdpBtnAddtoCart;
	}

	public QAFWebElement getCdpBtnAddtoList() {
		return cdpBtnAddtoList;
	}

	public QAFWebElement getCdpBtnIncAddtoList() {
		return cdpBtnIncAddtoList;
	}

	public QAFWebElement getCdpBtnDecAddtoList() {
		return cdpBtnDecAddtoList;
	}
	
	public QAFWebElement getCdpLblMinimumquantity() {
		return cdpLblMinimumquantity;
	}
	
	public QAFWebElement getCdpBtnMinusaddtocart() {
		return cdpBtnMinusaddtocart;
	}

	public QAFWebElement getEdtInputQty() {
		return Edtinputqty;
	}
	
	public QAFWebElement getCdpLblRatings() {
		return cdpLblRatings;
	}
	
}
