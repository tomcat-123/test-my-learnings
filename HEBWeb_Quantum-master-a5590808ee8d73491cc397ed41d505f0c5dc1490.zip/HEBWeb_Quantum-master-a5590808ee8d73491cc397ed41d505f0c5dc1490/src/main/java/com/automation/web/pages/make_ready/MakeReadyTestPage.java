package com.automation.web.pages.make_ready;

import java.util.List;

import com.automation.web.components.MakeReadyProducts;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MakeReadyTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "make.lbl.madeforu")
	private QAFWebElement makeLblMadeforu;

	@FindBy(locator = "make.lbl.pickup")
	private QAFWebElement makeLblPickup;

	@FindBy(locator = "make.lbl.header")
	private QAFWebElement makeLblHeader;

	@FindBy(locator = "make.li.lbl.tabs")
	private List<QAFWebElement> makeLiLblTabs;

	@FindBy(locator = "make.li.img.topcatridgesactive")
	private List<QAFWebElement> makeLiImgTopcatridgesactive;

	@FindBy(locator = "make.img.topcatridgeactive")
	private QAFWebElement makeImgTopcatridgeactive;

	@FindBy(locator = "make.lbl.topcatridgeactive")
	private QAFWebElement makeLblTopcatridgeactive;

	@FindBy(locator = "make.lbl.noofproducts")
	private QAFWebElement makeLblNoofproducts;

	@FindBy(locator = "make.lnk.storename")
	private QAFWebElement makeLnkStorename;

	@FindBy(locator = "make.li.box.productcatridges")
	private List<MakeReadyProducts> makeLiBoxProductcatridges;

	@FindBy(locator = "make.img.product")
	private QAFWebElement makeImgProduct;

	@FindBy(locator = "make.lbl.productname")
	private QAFWebElement makeLblProductname;
	
	@FindBy(locator = "make.lbl.productname")
	private List<QAFWebElement> makeLiLblProductname;

	@FindBy(locator = "make.img.productrating")
	private QAFWebElement makeImgProductrating;

	@FindBy(locator = "make.lbl.productprice")
	private QAFWebElement makeLblProductprice;

	@FindBy(locator = "make.btn.addtocart")
	private QAFWebElement makeBtnAddtocart;

	@FindBy(locator = "make.btn.customize")
	private QAFWebElement makeBtnCustomize;

	@FindBy(locator = "make.drp.sort")
	private QAFWebElement makeDrpSort;

	@FindBy(locator = "make.lbl.selectmakereadystore")
	private QAFWebElement makeLblSelectmakereadystore;
	
	@FindBy(locator = "make.lbl.addtolist")
	private QAFWebElement makeLblAddtolist;

	@FindBy(locator = "make.img.makereadyfirstproduct")
	private QAFWebElement makeImgMakereadyfirstproduct;
	
	@FindBy(locator = "make.lnk.delitraystab")
	private QAFWebElement makeLnkDelitraysTab;
	
	@FindBy(locator = "make.lnk.flowerstab")
	private QAFWebElement makeLnkFlowersTab;
	
	@FindBy(locator = "make.lnk.cakestab")
	private QAFWebElement makeLnkCakesTab;
	
	@FindBy(locator = "make.lnk.activetab")
	private QAFWebElement makeLnkActiveTab;

	/**
	 * TextView of Made for you
	 */
	public QAFWebElement getMakeLblMadeforu(){ return makeLblMadeforu; }
	
	public QAFWebElement getMakeLblLastpdtinrow(String linktext) {
		String loc = String.format(pageProps.getString("make.get.lbl.lastpdtinrow"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getMakeLblAddtolist(){ return makeLblAddtolist; }
	
	public QAFWebElement getMakeImgMakereadyfirstproduct(){ return makeImgMakereadyfirstproduct; }

	/**
	 * TextView of pick up 24 hrs
	 */
	public QAFWebElement getMakeLblPickup(){ return makeLblPickup; }

	/**
	 * TextView of Header
	 */
	public QAFWebElement getMakeLblHeader(){ return makeLblHeader; }

	/**
	 * TextView of tabs in make ready
	 */
	public List<QAFWebElement> getMakeLiLblTabs(){ return makeLiLblTabs; }

	/**
	 * ImageView of active catridges
	 */
	public List<QAFWebElement> getMakeLiImgTopcatridgesactive(){ return makeLiImgTopcatridgesactive; }

	/**
	 * ImageView of active catridge
	 */
	public QAFWebElement getMakeImgTopcatridgeactive(){ return makeImgTopcatridgeactive; }

	/**
	 * TextView of active catridge
	 */
	public QAFWebElement getMakeLblTopcatridgeactive(){ return makeLblTopcatridgeactive; }

	/**
	 * TextView of number of products in the page
	 */
	public QAFWebElement getMakeLblNoofproducts(){ return makeLblNoofproducts; }

	/**
	 * LinkView of store name
	 */
	public QAFWebElement getMakeLnkStorename(){ return makeLnkStorename; }

	/**
	 * TextView of product catridges
	 */
	public List<MakeReadyProducts> getMakeLiBoxProductcatridges(){ return makeLiBoxProductcatridges; }

	/**
	 * TextView of product image
	 */
	public QAFWebElement getMakeImgProduct(){ return makeImgProduct; }

	/**
	 * TextView of product name
	 */
	public QAFWebElement getMakeLblProductname(){ return makeLblProductname; }

	/**
	 * ImageView of rating
	 */
	public QAFWebElement getMakeImgProductrating(){ return makeImgProductrating; }

	/**
	 * TextView of price
	 */
	public QAFWebElement getMakeLblProductprice(){ return makeLblProductprice; }

	/**
	 * ButtonView Add to cart
	 */
	public QAFWebElement getMakeBtnAddtocart(){ return makeBtnAddtocart; }

	/**
	 * ButtonView of Customize
	 */
	public QAFWebElement getMakeBtnCustomize(){ return makeBtnCustomize; }

	/**
	 * DropdownView of Sort
	 */
	public QAFWebElement getMakeDrpSort(){ return makeDrpSort; }

	/**
	 * TextView of Select a Make Ready Store
	 */
	public QAFWebElement getMakeLblSelectmakereadystore(){ return makeLblSelectmakereadystore; }
	
	public QAFWebElement getMakeLnkDelitraysTab(){ return makeLnkDelitraysTab; }

	public QAFWebElement getMakeLnkFlowersTab(){ return makeLnkFlowersTab; }

	public QAFWebElement getMakeLnkCakesTab(){ return makeLnkCakesTab; }

	public QAFWebElement getMakeLnkActiveTab(){ return makeLnkActiveTab; }

	public List<QAFWebElement> getMakeLiLblProductname(){ return makeLiLblProductname; }
	
}
