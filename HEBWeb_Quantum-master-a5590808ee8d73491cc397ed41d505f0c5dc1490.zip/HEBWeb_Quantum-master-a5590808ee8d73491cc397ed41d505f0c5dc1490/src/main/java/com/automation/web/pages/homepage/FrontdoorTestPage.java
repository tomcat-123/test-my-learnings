package com.automation.web.pages.homepage;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class FrontdoorTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "front.img.logo")
	private QAFWebElement frontImgLogo;
	
	@FindBy(locator = "front.img.fav")
	private QAFWebElement frontImgFav;

	@FindBy(locator = "front.edt.searchbar")
	private QAFWebElement frontEdtSearchbar;

	@FindBy(locator = "front.lbl.storefinder")
	private QAFWebElement frontLblStorefinder;

	@FindBy(locator = "front.img.curbsideheroimg")
	private QAFWebElement frontImgCurbsideheroimg;

	@FindBy(locator = "front.img.exploremystore")
	private QAFWebElement frontImgExploremystore;
	
	@FindBy(locator = "front.img.exploremystoremobile")
	private QAFWebElement frontImgExploremystoremobile;

	@FindBy(locator = "front.lbl.curbsidetitle")
	private QAFWebElement frontLblCurbsidetitle;

	@FindBy(locator = "front.lbl.curbsidesubtitle")
	private QAFWebElement frontLblCurbsidesubtitle;

	@FindBy(locator = "front.lbl.curbsidegetstarted")
	private QAFWebElement frontLblCurbsidegetstarted;

	@FindBy(locator = "front.lbl.exploremystoretitle")
	private QAFWebElement frontLblExploremystoretitle;

	@FindBy(locator = "front.lbl.exploremystoresubtitle")
	private QAFWebElement frontLblExploremystoresubtitle;

	@FindBy(locator = "front.lbl.exploremystore")
	private QAFWebElement frontLblExploremystore;

	@FindBy(locator = "front.img.curbside")
	private QAFWebElement frontImgCurbside;

	@FindBy(locator = "front.img.coupons")
	private QAFWebElement frontImgCoupons;

	@FindBy(locator = "front.img.weeklyad")
	private QAFWebElement frontImgWeeklyad;
	
	@FindBy(locator = "front.img.weeklyadmobile")
	private QAFWebElement frontImgWeeklyadmobile;

	@FindBy(locator = "front.img.pharmacy")
	private QAFWebElement frontImgPharmacy;

	@FindBy(locator = "front.lbl.onlyatHEB")
	private QAFWebElement frontLblOnlyatHEB;

	@FindBy(locator = "front.btn.search")
	private QAFWebElement frontBtnSearch;
	
	@FindBy(locator = "front.btn.searchtooltip")
	private QAFWebElement frontBtnSearchToolTip;

	@FindBy(locator = "front.lbl.recipe")
	private QAFWebElement frontLblRecipe;

	@FindBy(locator = "front.li.recipeimg")
	private List<QAFWebElement> frontLiRecipeimg;

	@FindBy(locator = "front.btn.explorerecipes")
	private QAFWebElement frontBtnExplorerecipes;
	
	@FindBy(locator = "front.btn.ShopNow")
	private QAFWebElement frontBtnShopNow;
	
	@FindBy(locator = "front.lbl.header")
	private List<QAFWebElement> frontlblHeader;
	
	@FindBy(locator = "front.lbl.storename")
	private QAFWebElement frontLblStorename;
	
	@FindBy(locator = "front.li.lbl.storeflyoutstorenames")
	private List<QAFWebElement> frontLiLblStoreflyoutstorenames;
	
	@FindBy(locator = "front.lbl.storeflyoutcurbphone")
	private QAFWebElement frontLblStoreflyoutcurbphone;
	
	@FindBy(locator = "front.lbl.storeflyoutcurbtimings")
	private QAFWebElement frontLblStoreflyoutcurbtimings;
	
	@FindBy(locator = "front.li.block.catridges")
	private List<QAFWebElement> frontLiBlockCatridges;
	
	@FindBy(locator = "front.li.img.catridges")
	private List<QAFWebElement> frontLiImgCatridges;
	
	@FindBy(locator = "front.li.lbl.catridgenames")
	private List<QAFWebElement> frontLiLblCatridgenamess;
	
	@FindBy(locator = "front.li.lbl.catridgedesc")
	private List<QAFWebElement> frontLiLblCatridgedesc;
	
	@FindBy(locator = "front.lnk.findyourstore")
	private QAFWebElement frontLnkFindyourstore;
	
	
	/**
	 * ImageView of Mainlogo in Front door page
	 */
	public QAFWebElement getFrontImgLogo(){ return frontImgLogo; }
	
	public QAFWebElement getFrontImgFav(){ return frontImgFav; }
	
	public QAFWebElement getFrontLnkFindyourstore(){ return frontLnkFindyourstore; }

	/**
	 * EditView of Search Bar
	 */
	public QAFWebElement getFrontEdtSearchbar(){ return frontEdtSearchbar; }

	/**
	 * TextView of Store Finder
	 */
	public QAFWebElement getFrontLblStorefinder(){ return frontLblStorefinder; }

	/**
	 * ImageView of CurbSide Hero Image
	 */
	public QAFWebElement getFrontImgCurbsideheroimg(){ return frontImgCurbsideheroimg; }

	/**
	 * ImageView of Explore My Store Hero Image
	 */
	public QAFWebElement getFrontImgExploremystore(){ return frontImgExploremystore; }
	
	public QAFWebElement getFrontImgExploremystoremobile(){ return frontImgExploremystoremobile; }

	/**
	 * ImageView of CurbSide Hero Image Title
	 */
	public QAFWebElement getFrontLblCurbsidetitle(){ return frontLblCurbsidetitle; }

	/**
	 * ImageView of CurbSide Hero Image SubTitle
	 */
	public QAFWebElement getFrontLblCurbsidesubtitle(){ return frontLblCurbsidesubtitle; }

	/**
	 * ImageView of CurbSide Hero Image GetStarted
	 */
	public QAFWebElement getFrontLblCurbsidegetstarted(){ return frontLblCurbsidegetstarted; }

	/**
	 * ImageView of Explore My Store Hero Image Title
	 */
	public QAFWebElement getFrontLblExploremystoretitle(){ return frontLblExploremystoretitle; }

	/**
	 * ImageView of Explore My Store Hero Image SubTitle
	 */
	public QAFWebElement getFrontLblExploremystoresubtitle(){ return frontLblExploremystoresubtitle; }

	/**
	 * ImageView of Explore My Store Hero Image GetStarted
	 */
	public QAFWebElement getFrontLblExploremystore(){ return frontLblExploremystore; }

	/**
	 * ImageView CurbSide Catridge
	 */
	public QAFWebElement getFrontImgCurbside(){ return frontImgCurbside; }

	/**
	 * ImageView Coupons Catridge
	 */
	public QAFWebElement getFrontImgCoupons(){ return frontImgCoupons; }

	/**
	 * ImageView WeeklyAd Catridge
	 */
	public QAFWebElement getFrontImgWeeklyad(){ return frontImgWeeklyad; }
	
	public QAFWebElement getFrontImgWeeklyadmobile(){ return frontImgWeeklyadmobile; }

	/**
	 * ImageView Pharmacy Catridge
	 */
	public QAFWebElement getFrontImgPharmacy(){ return frontImgPharmacy; }

	/**
	 * LabelView of only at HEB
	 */
	public QAFWebElement getFrontLblOnlyatHEB(){ return frontLblOnlyatHEB; }

	/**
	 * ButtonView of Search icon
	 */
	public QAFWebElement getFrontBtnSearch(){ return frontBtnSearch; }
	
	public QAFWebElement getFrontBtnSearchToolTip(){ return frontBtnSearchToolTip; }

	/**
	 * TextView of Recipes title
	 */
	public QAFWebElement getFrontLblRecipe(){ return frontLblRecipe; }

	/**
	 * ListView of Recipe Images
	 */
	public List<QAFWebElement> getFrontLiRecipeimg(){ return frontLiRecipeimg; }

	/**
	 * ButtonView of Explore Recipes
	 */
	public QAFWebElement getFrontBtnExplorerecipes(){ return frontBtnExplorerecipes; }


	public QAFWebElement getFrontBtnShopNow() {
		return frontBtnShopNow;
	}


	public List<QAFWebElement> getFrontlblHeader() {
		return frontlblHeader;
	}
	
	public QAFWebElement getFrontLblStorename() {
		return frontLblStorename;
	}
	
	public List<QAFWebElement> getFrontLiLblStoreflyoutstorenames() {
		return frontLiLblStoreflyoutstorenames;
	}
	
	public QAFWebElement getFrontLblStoreflyoutcurbphone() {
		return frontLblStoreflyoutcurbphone;
	}
	
	public QAFWebElement getFrontLblStoreflyoutcurbtimings() {
		return frontLblStoreflyoutcurbtimings;
	}
	
	public List<QAFWebElement> getFrontLiBlockCatridges() {
		return frontLiBlockCatridges;
	}


	public List<QAFWebElement> getFrontLiImgCatridges() {
		return frontLiImgCatridges;
	}


	public List<QAFWebElement> getFrontLiLblCatridgenamess() {
		return frontLiLblCatridgenamess;
	}


	public List<QAFWebElement> getFrontLiLblCatridgedesc() {
		return frontLiLblCatridgedesc;
	}
	
}