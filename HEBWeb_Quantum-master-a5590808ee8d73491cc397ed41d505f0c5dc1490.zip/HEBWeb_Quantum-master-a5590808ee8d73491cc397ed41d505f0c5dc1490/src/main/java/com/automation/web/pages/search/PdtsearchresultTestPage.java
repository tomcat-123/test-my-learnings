package com.automation.web.pages.search;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class PdtsearchresultTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	
	
	@FindBy(locator = "pdtresult.lnk.recipeaddtolist")
	private QAFWebElement LnkRcipeaddtolist;
	@FindBy(locator = "pdtresult.lbl.searchresultcount")
	private QAFWebElement LblSearchresultcount;
	@FindBy(locator = "pdtresult.lbl.werecommend")
	private QAFWebElement LblWeRecommend;
	@FindBy(locator = "pdtresult.lnk.werecommendAddtocart")
	private QAFWebElement LnkWeRecommendAddtocart;
	@FindBy(locator = "pdtresult.lnk.addtolist")
	private QAFWebElement LnkAddtolist;
	@FindBy(locator = "pdtresult.img.product")
	private QAFWebElement ImgProduct;
	@FindBy(locator = "pdtresult.img.dynamicproduct")
	private QAFWebElement ImgDynamicproduct;
	@FindBy(locator = "pdtresult.lbl.productname")
	private QAFWebElement LblProductname;
	@FindBy(locator = "pdtresult.lbl.dynamicproductname")
	private QAFWebElement LblDynamicproductname;
	@FindBy(locator = "pdtresult.lbl.pageheader")
	private QAFWebElement LblPageheader;
	@FindBy(locator = "pdtresult.lbl.search")
	private QAFWebElement LblSearchresult;
	@FindBy(locator = "pdtresult.lnk.selectedcategory")
	private QAFWebElement LnkSelectedCategory;
	@FindBy(locator = "pdtresult.lnk.categories")
	private QAFWebElement LnkCategories;
	@FindBy(locator = "pdtresult.rdb.filterproducts")
	private QAFWebElement RdbFilterProducts;
	@FindBy(locator = "pdtresult.txt.firstproduct")
	private QAFWebElement TxtFirstProduct;
	@FindBy(locator = "pdtresult.txt.product")
	private QAFWebElement TxtProduct;
	@FindBy(locator = "pdtresult.txt.recipes")
	private QAFWebElement TxtRecipes;
	@FindBy(locator = "pdtresult.lnk.firstproductitem")
	private QAFWebElement LnkFirstProductItem;
	@FindBy(locator = "pdtresult.btn.addtocart")
	private List<QAFWebElement> BtnAddToCart;
	@FindBy(locator = "pdtresult.lnk.addtoshoppinglist")
	private QAFWebElement LnkAddToShoppingList;
	@FindBy(locator = "pdtresult.lnk.firstrecipeitem")
	private QAFWebElement LnkFfirstRecipeItem;
	@FindBy(locator = "pdtresult.lbl.filterall")
	private QAFWebElement LblFilterAll;
	@FindBy(locator = "pdtresult.lbl.filterinmystore")
	private QAFWebElement LblFilterInMyStore;
	@FindBy(locator = "pdtresult.lbl.filtersoldonline")
	private QAFWebElement LblFilterSoldOnline;
	@FindBy(locator = "pdtresult.lnk.viewallproduct")
	private QAFWebElement LnkViewAllProduct;
	@FindBy(locator = "pdtresult.list.items")
	private List<QAFWebElement> pdtResultListItems;
	@FindBy(locator = "pdtresult.lnk.choosemyheb")
	private QAFWebElement LnkChooseMyHEB;
	@FindBy(locator = "pdtresult.txt.resultmsg")
	private QAFWebElement TxtResultMsg;
	@FindBy(locator = "pdtresult.rdb.checkedsoldonline")
	private QAFWebElement RdbCheckedSoldOnline;
	@FindBy(locator = "pdtresult.txt.soldonline")
	private QAFWebElement TxtSoldOnline;
	@FindBy(locator = "pdtresult.lnk.recipefirstitem")
	private QAFWebElement LnkRecipeFirstItem;
	@FindBy(locator = "pdtresult.lnk.addtorecipebox")
	private QAFWebElement LnkAddToRecipeBox;
	@FindBy(locator = "pdtresult.txt.filterproducts")
	private QAFWebElement TxtFilterProducts;
	@FindBy(locator = "pdtresult.txt.errormsg")
	private QAFWebElement TxtErrorMsg;
	@FindBy(locator = "pdtresult.lnk.pdtgridview")
	private QAFWebElement LnkPdtGridView;
	@FindBy(locator = "pdtresult.lnk.recipegridview")
	private QAFWebElement LnkRecipeGridView;
	@FindBy(locator = "pdtresult.lnk.contentview")
	private QAFWebElement LnkContentView;
	@FindBy(locator = "pdtresult.txt.selectedpdtname")
	private QAFWebElement TxtSelectedPdtName;
	@FindBy(locator = "pdtresult.lbl.searchheader")
	private QAFWebElement LblSearchHeader;
	@FindBy(locator = "pdtresult.link.viewallproducts")
	private QAFWebElement LblViewallproducts;
	@FindBy(locator = "pdtresult.chk.checkbox")
	private List<QAFWebElement> ChkCheckbox;
	@FindBy(locator = "pdtresult.btn.compare")
	private QAFWebElement BtnCompare;
	@FindBy(locator = "pdtresult.lnk.addtolist")
	private QAFWebElement LnkAddToList;
	@FindBy(locator = "pdtresult.list.bycategory")
	private List<QAFWebElement> ListBycategory;
	@FindBy(locator = "pdtresult.lbl.searchresultscount")
	private QAFWebElement lblSearchresultscount;
	@FindBy(locator = "pdtresult.txt.yourfirstorder")
	private QAFWebElement TxtYourfirstorder;
	@FindBy(locator = "pdtresult.txt.shop")
	private QAFWebElement TxtShop;
	@FindBy(locator = "pdtresult.txt.cartprice")
	private QAFWebElement TxtCartPrice;
	@FindBy(locator = "pdtresult.txt.cartquantity")
	private QAFWebElement TxtCartQuantity;
	@FindBy(locator = "pdtresult.btn.minusaddtocart")
	private List<QAFWebElement> btnMinusaddtocart;
	@FindBy(locator = "pdtresult.lbl.minimumquantity")
	private List<QAFWebElement> lblMinimumquantity;

	@FindBy(locator = "pdtresult.lbl.ratings")
	private QAFWebElement LblRatings;

	@FindBy(locator = "pdtresult.lnk.addtolist")
	private QAFWebElement LnkAddtoList;

	@FindBy(locator = "pdtresult.lbl.minishoppinglist")
	private QAFWebElement LblMiniShoppinglist;

	@FindBy(locator = "pdtresult.lnk.gotofulllist")
	private QAFWebElement LnkGotofullList;

	@FindBy(locator = "pdtresult.img.primopick")
	private QAFWebElement ImgPrimoPick;

	@FindBy(locator = "pdtresult.list.featureicons")
	private List<QAFWebElement> ListFeatureIcons;

	@FindBy(locator = "pdtresult.txt.viewproducts")
	private QAFWebElement TxtViewProducts;
	@FindBy(locator = "pdtresult.txt.viewrecipes")
	private QAFWebElement TxtViewRecipes;
	@FindBy(locator = "pdtresult.txt.viewcontents")
	private QAFWebElement TxtViewContents;

	@FindBy(locator = "pdtresult.txt.allproductsheader")
	private QAFWebElement TxtAllproductsheader;
	@FindBy(locator = "pdtresult.txt.recipesheader")
	private QAFWebElement TxtRecipesheader;
	@FindBy(locator = "pdtresult.txt.contentsheader")
	private QAFWebElement TxtContentsheader;

	@FindBy(locator = "pdtresult.lst.searchresultsaheadterms")
	private List<QAFWebElement> LstSearchresultsAheadTerms;

	@FindBy(locator = "pdtresult.get.lst.searchresults")
	private QAFWebElement SearchresultsAheadTerms;

	@FindBy(locator = "pdtresult.lnk.aheadtxtcontainer")
	private QAFWebElement AheadRightcontainer;

	@FindBy(locator = "pdtresult.txt.zerosearchresult")
	private QAFWebElement TxtZerosearchresult;

	@FindBy(locator = "pdtresult.rdb.inmystore")
	private QAFWebElement RdbInMyStore;

	@FindBy(locator = "pdtresult.txt.inmystoreerrormsg")
	private QAFWebElement TxtInMyStoreErrorMsg;
	@FindBy(locator = "pdtresult.txt.findastoreerrormsg")
	private QAFWebElement TxtFindastoreErrormsg;

	@FindBy(locator = "pdtresult.btn.goinmystore")
	private QAFWebElement BtnGoInMyStore;

	@FindBy(locator = "pdtresult.lnk.findyourstore")
	private QAFWebElement LnkFindyourstore;

	@FindBy(locator = "pdtresult.btn.findyourstore")
	private QAFWebElement BtnFindyourstore;
	@FindBy(locator = "pdtresult.btn.searchfindyourstore")
	private QAFWebElement BtnSearchFindyourstore;
	@FindBy(locator = "pdtresult.txt.findyourstore")
	private QAFWebElement TxtFindyourstore;

	@FindBy(locator = "pdtresult.txt.zipcodetext")
	private QAFWebElement TxtZipcodetext;

	@FindBy(locator = "pdtresult.lnk.food")
	private QAFWebElement LnkFood;
	@FindBy(locator = "pdtresult.lnk.home")
	private QAFWebElement LnkHome;
	@FindBy(locator = "pdtresult.lnk.health")
	private QAFWebElement LnkHealth;
	@FindBy(locator = "pdtresult.lnk.baby")
	private QAFWebElement LnkBaby;
	@FindBy(locator = "pdtresult.lnk.outdoor")
	private QAFWebElement LnkOutdoor;
	@FindBy(locator = "pdtresult.lnk.office")
	private QAFWebElement LnkOffice;
	@FindBy(locator = "pdtresult.lnk.subbakery")
	private QAFWebElement LnkSubBakery;
	@FindBy(locator = "pdtresult.lnk.babysub")
	private QAFWebElement LnkBabySub;
	@FindBy(locator = "pdtresult.lnk.oudoorsub")
	private QAFWebElement LnkOutdoorSub;
	@FindBy(locator = "pdtresult.lnk.officesub")
	private QAFWebElement LnkOfficeSub;
	@FindBy(locator = "pdtresult.lbl.allpdts")
	private QAFWebElement LblAllProducts;
	@FindBy(locator = "pdtresult.lbl.hebstore")
	private QAFWebElement LblHebStore;
	@FindBy(locator = "pdtresult.lbl.soldonline")
	private QAFWebElement LblSoldOnline;
	@FindBy(locator = "pdtresult.lnk.grocerysub")
	private QAFWebElement LnkGrocerysub;
	@FindBy(locator = "pdtresult.lnk.kitchentoolssub")
	private QAFWebElement LnkKitchentoolssub;
	@FindBy(locator = "pdtresult.lnk.makeupsub")
	private QAFWebElement LnkMakeupsub;

	@FindBy(locator = "pdtresult.rdb.filterall")
	private QAFWebElement RdbFilterAll;
	@FindBy(locator = "pdtresult.rdb.filterinmystore")
	private QAFWebElement RdbFilterinmystore;
	@FindBy(locator = "pdtresult.rdb.filtersoldonline")
	private QAFWebElement RdbFilterSoldOnline;
	@FindBy(locator = "pdtresult.txt.searchtext")
	private QAFWebElement txtSearchtext;
	@FindBy(locator = "pdtresult.btn.searchsubmit")
	private QAFWebElement btnSearchsubmit;
	@FindBy(locator = "pdtresult.lbl.noresultfounderrormessage")
	private QAFWebElement lblNoresultfounderrormessage;
	@FindBy(locator = "pdtresult.txt.zeroresultinvalid")
	private QAFWebElement txtZeroResultInvalid;
	@FindBy(locator = "pdtresult.dd.prodsortByselect")
	private QAFWebElement ddProdSortBySelect;
	@FindBy(locator = "pdtresult.lbl.ratingcontainer")
	private QAFWebElement lblRatingContainer;
	@FindBy(locator = "pdtresult.lbl.cdpproducttitle")
	private QAFWebElement lblCDPProductTitle;
	@FindBy(locator = "pdtresult.lbl.pdpratingcontainer")
	private QAFWebElement lblPDPRatingContainer;
	@FindBy(locator = "pdtresult.lst.ratingcontainer")
	private List<QAFWebElement> lstRatingContainer;
	@FindBy(locator = "pdtresult.lst.pdpratingcontainer")
	private List<QAFWebElement> lstPDPRatingContainer;
	@FindBy(locator = "pdtresult.box.aheadsearch")
	private QAFWebElement boxAheadsearch;
	@FindBy(locator = "cdp.box.productquantity")
	private List<QAFWebElement> boxProductQuantity;
	@FindBy(locator = "pdtresult.btn.plusaddtocart")
	private List<QAFWebElement> btnPlusAddtoCart;	
	@FindBy(locator = "pdtresult.lbl.addtocrterror")
	private QAFWebElement lbladdtocrterror;
	
	@FindBy(locator = "pdtresult.edt.inputqty")
	private QAFWebElement Edtinputqty;
	@FindBy(locator = "pdtresult.btn.customize")
	private QAFWebElement BtnCustomize;
	
	@FindBy(locator = "pdtresult.lnk.viewallrecipe")
	private QAFWebElement lnkViewallrecipe;
	@FindBy(locator = "pdtresult.lnk.viewallcontent")
	private QAFWebElement lnkViewallcontent;
	@FindBy(locator = "pdtresult.li.lnk.searchresulttypes")
	private List<QAFWebElement> liLnkSearchresulttypes;
	@FindBy(locator = "pdtresult.li.img.recipeimages")
	private List<QAFWebElement> liImgRecipeimages;
	@FindBy(locator = "pdtresult.li.lnk.addtorecipebox")
	private List<QAFWebElement> liLnkAddtorecipebox;
	@FindBy(locator = "pdtresult.img.marketingbugprimopick")
	private QAFWebElement imgMarketingbugPrimopick;
	@FindBy(locator = "pdtresult.lbl.showing")
	private QAFWebElement lblShowing;
	@FindBy(locator = "pdtresult.lbl.lastpage")
	private QAFWebElement lblLastpage;
	@FindBy(locator = "pdtresult.lnk.prevpage")
	private QAFWebElement lnkPrevpage;
	@FindBy(locator = "pdtresult.lnk.nextpage")
	private QAFWebElement lnkNextpage;
	@FindBy(locator = "pdtresult.lbl.alternatemessage")
	private QAFWebElement lblAlternateMessage;
	@FindBy(locator = "pdtresult.txt.zeroresultincorrect")
	private QAFWebElement txtZeroresultIncorrect;
	@FindBy(locator = "pdtresult.lbl.refineacorelle")
	private QAFWebElement lblRefineAcorelle;
	@FindBy(locator = "pdtresult.lbl.refinealmond")
	private QAFWebElement lblRefineAlmond;
	@FindBy(locator = "pdtresult.lst.contentstitle")
	private List<QAFWebElement> lstContentsTitle;
	@FindBy(locator = "pdtresult.lst.contentsdesc")
	private List<QAFWebElement> lstContentsDesc;
	@FindBy(locator = "pdtresult.lst.contentsdescreadmore")
	private List<QAFWebElement> lstContentsDescReadMore;
	@FindBy(locator = "pdtresult.lbl.contentsreadmorepage")
	private QAFWebElement lblContentsReadmorePage;
	@FindBy(locator = "pdtresult.lbl.viewoncolor")
	private QAFWebElement lblViewOnColor;
	@FindBy(locator = "pdtresult.lst.addtofolder")
	private List<QAFWebElement> lstAddtofolder;
	@FindBy(locator = "pdtresult.lnk.myrecipebox")
	private QAFWebElement lnkMyrecipebox;
	@FindBy(locator = "pdtresult.lnk.listviewrecipes")
	private QAFWebElement lnkListViewRecipes;
	@FindBy(locator = "pdtresult.lnk.addtorecipeboxlistview")
	private QAFWebElement lnkAddtorecipeboxListView;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}
	
	public QAFWebElement getLblContentsReadmorePage() {
		return lblContentsReadmorePage;
	}
	
	public QAFWebElement getLnkAddtorecipeboxListView() {
		return lnkAddtorecipeboxListView;
	}
	
	public QAFWebElement getLnkListViewRecipes() {
		return lnkListViewRecipes;
	}
	
	public QAFWebElement getLnkMyrecipebox() {
		return lnkMyrecipebox;
	}
	
	public List<QAFWebElement> getLstAddtofolder() {
		return lstAddtofolder;
	}
	
	public QAFWebElement getLblViewOnColor() {
		return lblViewOnColor;
	}
	
	public List<QAFWebElement> getLstContentsTitle() {
		return lstContentsTitle;
	}
	
	public List<QAFWebElement> getLstContentsDescReadMore() {
		return lstContentsDescReadMore;
	}
	
	public List<QAFWebElement> getLstContentsDesc() {
		return lstContentsDesc;
	}
	
	public QAFWebElement getLblShowing() {
		return lblShowing;
	}
	
	public QAFWebElement getLblRefineAcorelle() {
		return lblRefineAcorelle;
	}
	
	public QAFWebElement getLblRefineAlmond() {
		return lblRefineAlmond;
	}
	
	public QAFWebElement getLblAlternateMessage() {
		return lblAlternateMessage;
	}
	
	public QAFWebElement getTxtZeroresultIncorrect() {
		return txtZeroresultIncorrect;
	}
	
	public QAFWebElement getLblLastpage() {
		return lblLastpage;
	}
	
	public QAFWebElement getLnkPrevpage() {
		return lnkPrevpage;
	}
	
	public QAFWebElement getLnkNextpage() {
		return lnkNextpage;
	}
	
	public QAFWebElement getImgMarketingbugPrimopick() {
		return imgMarketingbugPrimopick;
	}

	public QAFWebElement getRdbFilterAll() {
		return RdbFilterAll;
	}
	
	public QAFWebElement getLnkPages(String lable) {
		String loc = String.format(pageProps.getString("pdtresult.lnk.pages"), lable);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getImgMarketingBug(String lable) {
		String loc = String.format(pageProps.getString("pdtresult.img.marketingbug"), lable);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getLblWeRecommend() {
		return LblWeRecommend;
	}
	
	public QAFWebElement getLnkWeRecommendAddtocart() {
		return LnkWeRecommendAddtocart;
	}

	public QAFWebElement getRdbFilterinmystore() {
		return RdbFilterinmystore;
	}

	public QAFWebElement getRdbFilterSoldOnline() {
		return RdbFilterSoldOnline;
	}

	public QAFWebElement getLnkGrocerysub() {
		return LnkGrocerysub;
	}

	public QAFWebElement getLnkKitchentoolssub() {
		return LnkKitchentoolssub;
	}

	public QAFWebElement getLnkMakeupsub() {
		return LnkMakeupsub;
	}

	public QAFWebElement getLnkFood() {
		return LnkFood;
	}

	public QAFWebElement getLnkHome() {
		return LnkHome;
	}

	public QAFWebElement getLnkHealth() {
		return LnkHealth;
	}

	public QAFWebElement getLnkBaby() {
		return LnkBaby;
	}

	public QAFWebElement getLnkOutdoor() {
		return LnkOutdoor;
	}

	public QAFWebElement getLnkOffice() {
		return LnkOffice;
	}

	public QAFWebElement getLnkSubBakery() {
		return LnkSubBakery;
	}

	public QAFWebElement getLnkBabySub() {
		return LnkBabySub;
	}

	public QAFWebElement getLnkOutdoorSub() {
		return LnkOutdoorSub;
	}

	public QAFWebElement getLnkOfficeSub() {
		return LnkOfficeSub;
	}

	public QAFWebElement getLblAllProducts() {
		return LblAllProducts;
	}

	public QAFWebElement getLblHebStore() {
		return LblHebStore;
	}

	public QAFWebElement getLblSoldOnline() {
		return LblSoldOnline;
	}

	public QAFWebElement getTxtZipcodetext() {
		return TxtZipcodetext;
	}

	public QAFWebElement getTxtFindyourstore() {
		return TxtFindyourstore;
	}

	public QAFWebElement getBtnSearchFindyourstore() {
		return BtnSearchFindyourstore;
	}

	public QAFWebElement getBtnFindyourstore() {
		return BtnFindyourstore;
	}

	public QAFWebElement getLnkFindyourstore() {
		return LnkFindyourstore;
	}

	public QAFWebElement getBtnGoInMyStore() {
		return BtnGoInMyStore;
	}

	public QAFWebElement getTxtFindastoreErrormsg() {
		return TxtFindastoreErrormsg;
	}

	public QAFWebElement getTxtInMyStoreErrorMsg() {
		return TxtInMyStoreErrorMsg;
	}

	public QAFWebElement getRdbInMyStore() {
		return RdbInMyStore;
	}

	public QAFWebElement getTxtZerosearchresult() {
		return TxtZerosearchresult;
	}

	public List<QAFWebElement> getLstSearchresultsAheadTerms() {
		return LstSearchresultsAheadTerms;
	}

	public QAFWebElement getEachLstSearchresultsAheadTerms(String count) {
		String appendListTag = "[" + count + "]/a";
		String reElm = String.format(pageProps.getString("pdtresult.get.lst.searchresults"), appendListTag);
		return new QAFExtendedWebElement(reElm);
	}

	public QAFWebElement getAheadRightcontainer() {
		return AheadRightcontainer;
	}

	public QAFWebElement getTxtAllproductsheader() {
		return TxtAllproductsheader;
	}

	public QAFWebElement getTxtRecipesheader() {
		return TxtRecipesheader;
	}

	public QAFWebElement getTxtContentsheader() {
		return TxtContentsheader;
	}

	public QAFWebElement getTxtViewProducts() {
		return TxtViewProducts;
	}

	public QAFWebElement getTxtViewRecipes() {
		return TxtViewRecipes;
	}

	public QAFWebElement getTxtViewContents() {
		return TxtViewContents;
	}

	public QAFWebElement getLblSearchresult() {
		return LblSearchresult;
	}

	public QAFWebElement getLblSearchresultcount() {
		return LblSearchresultcount;
	}

	public QAFWebElement getLnkAddtolist() {
		return LnkAddtolist;
	}

	public QAFWebElement getImgProduct() {
		return ImgProduct;
	}

	public QAFWebElement getImgDynamicproduct() {
		return ImgDynamicproduct;
	}

	public QAFWebElement getLblProductname() {
		return LblProductname;
	}

	public QAFWebElement getLblDynamicproductname() {
		return LblDynamicproductname;
	}

	public QAFWebElement getLblPageheader() {
		return LblPageheader;
	}

	public QAFWebElement getTxtFirstProduct() {
		return TxtFirstProduct;
	}

	public QAFWebElement getTxtProduct() {
		return TxtProduct;
	}

	public QAFWebElement getLnkFirstProductItem() {
		return LnkFirstProductItem;
	}

	public List<QAFWebElement> getBtnAddToCart() {
		return BtnAddToCart;
	}

	public QAFWebElement getLnkAddToShoppingList() {
		return LnkAddToShoppingList;
	}

	public QAFWebElement getTxtRecipes() {
		return TxtRecipes;
	}

	public QAFWebElement getLnkFfirstRecipeItem() {
		return LnkFfirstRecipeItem;
	}

	public QAFWebElement getLblFilterAll() {
		return LblFilterAll;
	}

	public QAFWebElement getLblFilterInMyStore() {
		return LblFilterInMyStore;
	}

	public QAFWebElement getLblFilterSoldOnline() {
		return LblFilterSoldOnline;
	}

	public QAFWebElement getLnkViewAllProduct() {
		return LnkViewAllProduct;
	}

	public QAFWebElement getLnkChooseMyHEB() {
		return LnkChooseMyHEB;
	}

	public QAFWebElement getTxtResultMsg() {
		return TxtResultMsg;
	}

	public QAFWebElement getRdbCheckedSoldOnline() {
		return RdbCheckedSoldOnline;
	}

	public QAFWebElement getTxtSoldOnline() {
		return TxtSoldOnline;
	}

	public QAFWebElement getLnkRecipeFirstItem() {
		return LnkRecipeFirstItem;
	}

	public QAFWebElement getLnkAddToRecipeBox() {
		return LnkAddToRecipeBox;
	}

	public QAFWebElement getTxtFilterProducts() {
		return TxtFilterProducts;
	}

	public QAFWebElement getTxtErrorMsg() {
		return TxtErrorMsg;
	}

	public QAFWebElement getLnkPdtGridView() {
		return LnkPdtGridView;
	}

	public QAFWebElement getLnkRecipeGridView() {
		return LnkRecipeGridView;
	}

	public QAFWebElement getLnkContentView() {
		return LnkContentView;
	}

	public QAFWebElement getTxtSelectedPdtName() {
		return TxtSelectedPdtName;
	}

	public List<QAFWebElement> getPdtResultListItems() {
		return pdtResultListItems;
	}

	public QAFWebElement getLnkSelectedCategory(int i) {
		String selcategory = String.format(pageProps.getString("pdtresult.lnk.selectedcategory"), i);
		return new QAFExtendedWebElement(selcategory);
	}

	public QAFWebElement getLnkCategories(int i) {
		String category = String.format(pageProps.getString("pdtresult.lnk.categories"), i);
		return new QAFExtendedWebElement(category);
	}

	public QAFWebElement getRdbFilterProducts(int i) {
		String filter = String.format(pageProps.getString("pdtresult.rdb.filterproducts"), i);
		return new QAFExtendedWebElement(filter);
	}

	public QAFWebElement getLblSearchHeader() {
		return LblSearchHeader;
	}

	public QAFWebElement getLblViewallproducts() {
		return LblViewallproducts;
	}

	public List<QAFWebElement> getChkCheckbox() {
		return ChkCheckbox;
	}

	public QAFWebElement getBtnCompare() {
		return BtnCompare;
	}

	public QAFWebElement getLnkAddToList() {
		return LnkAddToList;
	}

	public List<QAFWebElement> getListBycategory() {
		return ListBycategory;
	}

	public QAFWebElement getLblSearchresultscount() {
		return lblSearchresultscount;
	}

	public QAFWebElement getTxtYourfirstorder() {
		return TxtYourfirstorder;
	}

	public QAFWebElement getTxtShop() {
		return TxtShop;
	}

	public QAFWebElement getTxtCartPrice() {
		return TxtCartPrice;
	}

	public QAFWebElement getTxtCartQuantity() {
		return TxtCartQuantity;
	}

	public List<QAFWebElement> getBtnMinusaddtocart() {
		return btnMinusaddtocart;
	}

	public QAFWebElement getLblRatings() {
		return LblRatings;
	}

	public QAFWebElement getLnkAddtoList() {
		return LnkAddtoList;
	}

	public QAFWebElement getLblMiniShoppinglist() {
		return LblMiniShoppinglist;
	}

	public QAFWebElement getLnkGotofullList() {
		return LnkGotofullList;
	}

	public QAFWebElement getImgPrimoPick() {
		return ImgPrimoPick;
	}

	public List<QAFWebElement> getLblMinimumquantity() {
		return lblMinimumquantity;
	}

	public List<QAFWebElement> getListFeatureIcons() {
		return ListFeatureIcons;
	}

	public QAFWebElement getTxtSearchtext() {
		return txtSearchtext;
	}

	public QAFWebElement getBtnSearchsubmit() {
		return btnSearchsubmit;
	}
	
	public QAFWebElement getLblNoresultfounderrormessage() {
		return lblNoresultfounderrormessage;
	}
	
	public QAFWebElement getDidYouMeanCorrectedSearchText(String correctedSearchText) {
		String filter = String.format(pageProps.getString("pdtresult.get.txt.didyoumean"), correctedSearchText);
		return new QAFExtendedWebElement(filter);
	}
	
	public QAFWebElement getZeroResultIncorrectSearchText(String incorrectSearchText) {
		String filter = String.format(pageProps.getString("pdtresult.get.txt.zeroresultincorrect"), incorrectSearchText);
		return new QAFExtendedWebElement(filter);
	}
	
	public QAFWebElement getTxtZeroResultInvalid() {
		return txtZeroResultInvalid;
	}
	
	public QAFWebElement getDDProdSortBySelect() {
		return ddProdSortBySelect;
	}
	
	public QAFWebElement getLblRatingContainer() {
		return lblRatingContainer;
	}
	
	public QAFWebElement getLblCDPFirstProductTitle() {
		return lblCDPProductTitle;
	}
	
	public QAFWebElement getLblPDPRatingContainer() {
		return lblPDPRatingContainer;
	}
	
	public List<QAFWebElement> getLstRatingContainer() {
		return lstRatingContainer;
	}
	
	public List<QAFWebElement> getLstPDPRatingContainer() {
		return lstPDPRatingContainer;
	}
	
	public QAFWebElement getBoxAheadsearch() {
		return boxAheadsearch;
	}
	
	public List<QAFWebElement> getboxProductQuantity() {
		return boxProductQuantity;
	}
	
	public List<QAFWebElement> getBtnPlusAddtoCart() {
		return btnPlusAddtoCart;
	}
	
	public QAFWebElement getLblAddToCrtError() {
		return lbladdtocrterror;
	}
			
	public QAFWebElement getEdtInputQty() {
		return Edtinputqty;
	}
	
	public QAFWebElement getBtnCustomize() {
		return BtnCustomize;
	}
	
	public QAFWebElement getLnkRcipeaddtolist() {
		return LnkRcipeaddtolist;
	}
		
	
	public QAFWebElement getLnkViewallrecipe() {
		return lnkViewallrecipe;
	}

	public QAFWebElement getLnkViewallcontent() {
		return lnkViewallcontent;
	}

	public List<QAFWebElement> getLiLnkSearchresulttypes() {
		return liLnkSearchresulttypes;
	}

	public List<QAFWebElement> getLiImgRecipeimages() {
		return liImgRecipeimages;
	}

	public List<QAFWebElement> getLiLnkAddtorecipebox() {
		return liLnkAddtorecipebox;
	}
	
	public QAFWebElement getLblRefineTerm(String term) {
		String loc = String.format(pageProps.getString("pdtresult.get.lbl.refineterm"), term);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getLblProductNameDynamic(int productlistno) {
		String loc = String.format(pageProps.getString("pdtresult.get.lbl.productname"), productlistno);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getLnkAddtofolderBreakfast(int recipelistno) {
		String loc = String.format(pageProps.getString("pdtresult.get.lnk.addtofolderbreakfast"), recipelistno);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getLblAddedtoRecipebox(int recipelistno) {
		String loc = String.format(pageProps.getString("pdtresult.get.lbl.addedtorecipebox"), recipelistno);
		return new QAFExtendedWebElement(loc);
	}

}
