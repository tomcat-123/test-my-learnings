package com.automation.web.pages.coupons;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CouponsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "coupons.lbl.couponsheader")
	private QAFWebElement lblCouponsheader;
	@FindBy(locator = "coupons.lbl.digcoupons")
	private QAFWebElement lblDigcoupons;
	@FindBy(locator = "coupons.btn.viewdigcoupons")
	private QAFWebElement btnViewdigcoupons;
	@FindBy(locator = "coupons.lbl.printablecoupons")
	private QAFWebElement lblPrintablecoupons;
	@FindBy(locator = "coupons.btn.viewprintablecoupons")
	private QAFWebElement btnViewprintablecoupons;
	@FindBy(locator = "coupons.lnk.digcouponslearnmore")
	private QAFWebElement lnkDigcouponslearnmore;
	@FindBy(locator = "coupons.lnk.viewcouponpolicy")
	private QAFWebElement lnkViewcouponpolicy;
	@FindBy(locator = "coupons.img.learnmorelanpage")
	private QAFWebElement imglearnmorelanpage;
	@FindBy(locator = "coupons.txt.checklanpage")
	private QAFWebElement txtchecklanpage;
	@FindBy(locator = "coupons.txt.faqslanpage")
	private QAFWebElement txtfaqslanpage;
	@FindBy(locator = "coupons.txt.policylanpage")
	private QAFWebElement txtpolicylanpage;
	@FindBy(locator = "coupons.btn.selectdigcoupons")
	private QAFWebElement btnSelectdigcoupons;

	public QAFWebElement getBtnSelectdigcoupons() {
		return btnSelectdigcoupons;
	}

	public QAFWebElement getLblCouponsheader() {
		return lblCouponsheader;
	}

	public QAFWebElement getLblDigcoupons() {
		return lblDigcoupons;
	}

	public QAFWebElement getBtnViewdigcoupons() {
		return btnViewdigcoupons;
	}

	public QAFWebElement getLblPrintablecoupons() {
		return lblPrintablecoupons;
	}

	public QAFWebElement getBtnViewprintablecoupons() {
		return btnViewprintablecoupons;
	}

	public QAFWebElement getLnkDigcouponslearnmore() {
		return lnkDigcouponslearnmore;
	}

	public QAFWebElement getLnkViewcouponpolicy() {
		return lnkViewcouponpolicy;
	}

	public QAFWebElement getImgLearnMoreLanpage() {
		return imglearnmorelanpage;
	}

	public QAFWebElement getTxtCheckLanpage() {
		return txtchecklanpage;
	}

	public QAFWebElement getTxtFaqsLanpage() {
		return txtfaqslanpage;
	}

	public QAFWebElement getTxtPolicyLanpage() {
		return txtpolicylanpage;
	}

}