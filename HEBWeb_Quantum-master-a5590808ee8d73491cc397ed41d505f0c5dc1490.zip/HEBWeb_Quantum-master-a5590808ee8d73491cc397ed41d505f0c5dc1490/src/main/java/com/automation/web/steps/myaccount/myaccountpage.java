package com.automation.web.steps.myaccount;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.cart.CartTestPage;
import com.automation.web.pages.checkout.ConfirmationTestPage;
import com.automation.web.pages.checkout.PaymentTestPage;
import com.automation.web.pages.checkout.ShippingTestPage;
import com.automation.web.pages.coupons.DigitalCouponsTestPage;
import com.automation.web.pages.homepage.FrontdoorTestPage;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.login.LoginTestPage;
import com.automation.web.pages.login.PasswordResetTestPage;
import com.automation.web.pages.myAccount.AddressBookTestPage;
import com.automation.web.pages.myAccount.CommunicationPrefsTestPage;
import com.automation.web.pages.myAccount.ManageCreditCardsTestPage;
import com.automation.web.pages.myAccount.ManageSubscriptionTestPage;
import com.automation.web.pages.myAccount.MyAccountPage;
import com.automation.web.pages.myAccount.MyaccountDigitalcouponsTestPage;
import com.automation.web.pages.myAccount.QuickReorderTestPage;
import com.automation.web.pages.myAccount.TaxExemptionTestPage;
import com.automation.web.pages.myAccount.myAccountFlyout;
import com.automation.web.pages.myAccount.myAccountLandingTestPage;
import com.automation.web.pages.myAccount.profileInformationTestpage;
import com.automation.web.pages.myList.MyListTestPage;
import com.automation.web.pages.orderhistory.OrderhistoryTestPage;
import com.automation.web.pages.pharmacy.PharmacyProfileTestPage;
import com.automation.web.pages.products.CDPTestPage;
import com.automation.web.pages.products.PDPTestPage;
import com.automation.web.pages.recipes.RecipeBoxTestpage;
import com.automation.web.pages.registration.RegistrationTestPage;
import com.automation.web.steps.CommonStepDef;
import com.automation.web.steps.Registration.Registration;
import com.automation.web.steps.cartAndCheckout.CartAndCheckout;
import com.automation.web.steps.homepage.HomePage;
import com.automation.web.steps.paymentgateway.PaymentGatewayStepdef;
import com.automation.web.steps.storelocator.StoreLocatorPage;
import com.automation.web.steps.search.PdtsearchresultPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of steps in myaccountpage

* I navigate to login page
* I navigate to login page for mobile
* I enter valid email {0} and password {1}
* I click Login button
* I see the user is logged in
* I see the user is logged in for mobile
* I see the error message
* I navigate to My Account using mouseover
* I navigate to Address Book page
* I navigate to Profile Information page
* I verify Add a New Shipping Address functionality
* I am a hot user with {0} {1} credentials
* I am a hot user with {0} {1} credentials for mobile
* I am a hot user with stores selected
* I am a hot user with no stores selected
* I delete the newly added address
* I edit my HEB store
* I verify new store getting displayed in My HEB store
* I click edit Profile Information
* I edit Profile information
* I verify edited Profile information getting displayed
* I change the password
* I navigate to change password page
* I verify user able to login with new password
* I am a hot user with new registration
* I am a hot user with new registration for coupons
* I click forgot password link
* I enter valid email {0} to send password reset link
* I click Send Email button
* I see the password reset confirmation message
* I logout from the account
* I click edit communication preferences
* I edit communication preferences
* I verify the updated communication preferences
* I click on change in myaccount flyout
* I fill all details in Profile Information section
* I verify all edited Profile information getting displayed
* I verify newly added address
* Update Store with zipcode {0} and StoreId {1}
* Change store for hot user with {0} {1}
* I add new credit card to account
* I delete the new credit card
* I navigate to billing page with some item in cart
* I verify the saved card and billing address in checkout page
* I change the password {0} times
* I do re-login with {0} {1} credentials
* Clicking the username on instore homepage
* Navigate to My Account page
* I see My Account Page
* Clicking the My Account label on instore homepage
* I Validate the options from the username mouseover
* Mouseover username
* I Validate My Account Page
* I Validate left navigation items
* Click on Profile Information link
* I should see Profile Information page
* Click on Pharmacy Profiles link
* I should see Pharmacy Profiles page
* Click on Communication Preferences link
* I should see Communication Preferences page
* Click on Address Book link
* I should see Address Book page
* Click on Order History link
* I should see Order History page
* Click on Quick reorder link
* I should see Quick reorder page
* I navigate to the Quick reorder page
* I verify user can quick reorder
* I verify user cannot quick reorder
* I get the choices {0} for customized cake in the cart
* I verify original choices are persisted for customized cake
* Click on Change Password link
* I should see Change Password page
* Click on Tax exemption link
* I should see Tax exemption page
* Click on Manage Credit cards link
* I should see Manage Credit cards page
* Click on Manage Subscriptions link
* I should see Manage Subscriptions page
* Click on Digital Coupons link
* I should see Digital Coupons page
* Click on Recipe box link
* I should see Recipe box page
* Click on Shopping list link
* I should see My lists page
* Verify the link to the login page on the password reset page
* I Add a subscription product to the cart
* I Verify that customer has option to select from any previously addresses
* I Enter new Shipping Address
* I Enter Credit Card details
* I Verify that address information is stored to address book in Customer Profile
* Verify that option to add a new address is available
* I Verify that option to add a new card is available
* Verify that customer has option to select from any previously saved cards
* Verify check box for save credit card information is visible and checked and not editable
* Verify the used credit card is saved as the subscription credit card for future fulfillments
* Verify that customer moves to billing information section of screen
* Register account for {0} times
* I logout from .com application in mobile
* Click on Save by updating mobile number and get offers by text checkbox
* Validate mobile number and get offers are updated by navigating again to Digital Coupons page
* I verify shipping address nick name has {0} characters utmost

*/

public class myaccountpage {

	/**
	 * click on Login link in In-Store HomePage
	 */
	
	@QAFTestStep(description = "I Login with valid credentials {0} {1}")
	public void iLoginwithValidCredentials(String email, String password) {
		iClickonLoginlink();
		iEnteremailandpassword(email,password);
		iClickonLoginbutton();
		iSeetheuserisloggedin();
		getBundle().setProperty("myEmail", email);
		getBundle().setProperty("myPassword", password);
	}
	
	@QAFTestStep(description = "I navigate to login page")
	public void iClickonLoginlink() {
		InStoreHomePage inStoredoor = new InStoreHomePage();
		LoginTestPage loginpage = new LoginTestPage();

		inStoredoor.getHomeLblLogin().waitForPresent(5000);
		inStoredoor.getHomeLblLogin().click();
		loginpage.getLoginLblEmail().waitForPresent(5000);
		loginpage.getLoginLblEmail().verifyPresent();
	}
	
	@QAFTestStep(description = "I verify the Login Page")
	public void iVerifyLoginPage() {
		LoginTestPage login = new LoginTestPage();
		
		login.getLoginLblHeader().verifyPresent();
		login.getLoginLblDonthaveanacc().verifyPresent();
		login.getLoginLnkCreateOne().verifyPresent();
		login.getLoginLblEmailLabel().verifyPresent();
		login.getLoginLblPasswordLabel().verifyPresent();
		login.getLoginLblEmail().verifyPresent();
		login.getLoginLblPassword().verifyPresent();
		login.getLoginBtnLogin().verifyPresent();
		login.getLoginLnkForgotpwd().verifyPresent();
		login.getLoginLnkViewPrivacyPolicy().verifyPresent();
		login.getLoginLnkViewTermsConditions().verifyPresent();
		login.getLoginImgLogo().verifyPresent();
		login.getLoginLblCopyright().verifyPresent();
	}

	@QAFTestStep(description = "I navigate to login page for mobile")
	public void iClickonLoginlinkformobile() {
		InStoreHomePage inStoredoor = new InStoreHomePage();
		LoginTestPage loginpage = new LoginTestPage();

		inStoredoor.getHomeLnkHumburgermobile().click();
		try {
			inStoredoor.getHomeLblLoginMobile().waitForPresent(5000);
			inStoredoor.getHomeLblLoginMobile().click();
		} catch (Exception e) {
			inStoredoor.getHomeBtnLogoutmobile().waitForPresent(5000);
			inStoredoor.getHomeBtnLogoutmobile().click();
		}

		loginpage.getLoginLblEmail().waitForPresent(5000);
		loginpage.getLoginLblEmail().verifyPresent();
	}

	/**
	 * Enter email and password in LoginPage
	 */
	@QAFTestStep(description = "I enter valid email {0} and password {1}")
	public static void iEnteremailandpassword(String email, String password) {
		LoginTestPage loginpage = new LoginTestPage();

		System.out.println(email + password);
		loginpage.getLoginLblEmail().waitForPresent(5000);
		loginpage.getLoginLblEmail().clear();
		CommonStepDef.entervalueintothetextbox(loginpage.getLoginLblEmail(), email);
		CommonStepDef.entervalueintothetextbox(loginpage.getLoginLblPassword(), password);
	}

	/**
	 * Click on Login button in LoginPage
	 */
	@QAFTestStep(description = "I click Login button")
	public static void iClickonLoginbutton() {
		LoginTestPage loginpage = new LoginTestPage();

		loginpage.getLoginBtnLogin().verifyPresent();
		loginpage.getLoginBtnLogin().click();
	}

	/**
	 * Verify user is logged in
	 */
	@QAFTestStep(description = "I see the user is logged in")
	public void iSeetheuserisloggedin() {
		InStoreHomePage inStoredoor = new InStoreHomePage();
		inStoredoor.getHomeLblUserdetail().waitForPresent(50000);
		String howdy = inStoredoor.getHomeLblUserdetail().getText();
		if (howdy.contains("Howdy")) {
			PerfectoUtils.reportMessage("User is sucessfully loged in", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User is not sucessfully loged in", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I see the user is logged in for mobile")
	public void iSeetheuserisloggedinformobile() {
		InStoreHomePage inStoredoor = new InStoreHomePage();
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		/*
		 * inStoredoor.getHomeLnkHumburgermobile().click();
		 * inStoredoor.getHomeLblUserdetailmobile().waitForPresent(50000);
		 * String howdy = inStoredoor.getHomeLblUserdetailmobile().getText(); if
		 * (howdy.contains("Howdy")) { PerfectoUtils.reportMessage(
		 * "User is sucessfully loged in", MessageTypes.Pass); } else {
		 * PerfectoUtils.reportMessage("User is not sucessfully loged in",
		 * MessageTypes.Fail); }
		 */

		frontdoor.getFrontImgExploremystoremobile().waitForVisible(50000);
		frontdoor.getFrontImgExploremystoremobile().verifyPresent();
	}

	/**
	 * Verify the error message
	 */
	@QAFTestStep(description = "I see the error message")
	public void iSeetheerrormessage() {
		LoginTestPage loginpage = new LoginTestPage();

		loginpage.getLoginLblError().verifyPresent();
		String error = loginpage.getLoginLblError().getText();

		if (error.contains("The email address or password you entered does not match our records")) {
			PerfectoUtils.reportMessage("Error message is getting displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Error message is not getting displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Verify user land in my account page using mouseover
	 */
	@QAFTestStep(description = "I navigate to My Account using mouseover")
	public static void iNavigateToMyAccountUsingMouseover() {
		InStoreHomePage inStoreHomePage = new InStoreHomePage();
		myAccountFlyout myAccFlyout = new myAccountFlyout();
		myAccountLandingTestPage myAccLanding = new myAccountLandingTestPage();

		PerfectoUtils.mouseoverandclick(inStoreHomePage.getHomeImgMyaccount(), myAccFlyout.getLnkMyaccount());
		PerfectoUtils.reportMessage("Clicked My account link from flyout..");

		String pageTitle = myAccLanding.getMyacclandingLblPagetitle().getText();

		if (pageTitle.equals("My Account"))
			PerfectoUtils.reportMessage("My Account page is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("My Account page is not Displayed....", MessageTypes.Fail);

	}

	/**
	 * Verify user land in addressbook page from my account
	 */
	@QAFTestStep(description = "I navigate to Address Book page")
	public void iNavigateToAddressBookPage() {
		myAccountLandingTestPage myAccLanding = new myAccountLandingTestPage();

		myAccLanding.getMyacclandingLnkAddressbook().verifyPresent();
		myAccLanding.getMyacclandingLnkAddressbook().click();
		PerfectoUtils.reportMessage("Clicked Address book link..");

		myAccLanding.getMyacclandingLblPagetitle().waitForPresent(5000);
		String pageTitle = myAccLanding.getMyacclandingLblPagetitle().getText();

		if (pageTitle.equals("Address Book"))
			PerfectoUtils.reportMessage("Address Book page is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Address Book page is not Displayed....", MessageTypes.Fail);

	}

	/**
	 * Verify user land in Profile Information page from my account
	 */
	@QAFTestStep(description = "I navigate to Profile Information page")
	public static void iNavigateToProfileInformationPage() {
		myAccountLandingTestPage myAccLanding = new myAccountLandingTestPage();

		myAccLanding.getMyacclandingLnkProfileinformation().verifyPresent();
		myAccLanding.getMyacclandingLnkProfileinformation().click();
		PerfectoUtils.reportMessage("Clicked Profile Information link..");

		String pageTitle = myAccLanding.getMyacclandingLblPagetitle().getText();

		if (pageTitle.equals("Profile Information"))
			PerfectoUtils.reportMessage("Profile Information page is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Profile Information page is not Displayed....", MessageTypes.Fail);

	}

	/**
	 * Verify Add a New Shipping Address functionality
	 */
	@QAFTestStep(description = "I verify Add a New Shipping Address functionality")
	public void iVerifyAddAShippingAddressFunctionality() {
		AddressBookTestPage addressBook = new AddressBookTestPage();

		String pageTitle = addressBook.getAddressbookLblAddnewaddress().getText();

		if (pageTitle.equals("Add a New Shipping Address"))
			PerfectoUtils.reportMessage("Add a New Shipping Address section is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Add a New Shipping Address section is not Displayed....", MessageTypes.Fail);

		addressBook.getAddressbookTxtNickname()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.nickname"));
		addressBook.getAddressbookTxtFirstname()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.fname"));
		addressBook.getAddressbookTxtLastname()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.lname"));
		addressBook.getAddressbookTxtPhno1()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.ph1"));
		addressBook.getAddressbookTxtPhno2()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.ph2"));
		addressBook.getAddressbookTxtPhno3()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.ph3"));
		addressBook.getAddressbookTxtStreetaddress()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.street"));
		addressBook.getAddressbookLblCity()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.city"));
		addressBook.getAddressbookLblZipCodeBox1()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.zipcode"));
		addressBook.getAddressbookLblZipCodeBox2().click();
		addressBook.waitForAjaxToComplete();
		// addressBook.getAddressbookTxtStreetaddress().click();

		// String zipC = addressBook.getAddressbookLblZipCodeBox2().getText();
		// int i = 0;
		/*
		 * while (zipC.equals("")&& i < 200) { zipC =
		 * addressBook.getAddressbookLblZipCodeBox2().getText(); i++; }
		 */
		String zipCode = addressBook.getAddressbookTxtStreetaddress().getText();
		addressBook.getAddressbookBtnSave().verifyPresent();
		addressBook.getAddressbookBtnSave().click();
		PerfectoUtils.reportMessage("Clicked Save button...");

		addressBook.getAddressbookLblSavedaddress().waitForPresent(5000);
		addressBook.getAddressbookLblSavedaddress().verifyPresent();
		addressBook.getAddressbookLblDefaultaddresstitle().verifyPresent();
		addressBook.getAddressbookLnkEdit().verifyPresent();
		addressBook.getAddressbookLnkRemove().verifyPresent();

		String savedNicName = addressBook.getAddressbookLblSavednickname().getText();

		if (savedNicName.equals(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.nickname")))
			PerfectoUtils.reportMessage("Address saved successfullly...", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Address not saved successfullly...", MessageTypes.Fail);
	}

	/**
	 * Verify the user login functionality
	 */
	@QAFTestStep(description = "I am a hot user with {0} {1} credentials")
	public void iAmAHotUserWithCredentials(String email, String password) {
		HomePage home = new HomePage();
		myaccountpage myAcc = new myaccountpage();
		FrontdoorTestPage front = new FrontdoorTestPage();
		
		home.iAmOnHomePage();
		front.getFrontImgFav().verifyPresent();
		home.iNavigateToInstoreHomePage();
		myAcc.iClickonLoginlink();
		front.getFrontImgFav().verifyPresent();
		myAcc.iEnteremailandpassword(email, password);
		myAcc.iClickonLoginbutton();
		myAcc.iSeetheuserisloggedin();
		getBundle().setProperty("myEmail", email);
		getBundle().setProperty("myPassword", password);

	}

	@QAFTestStep(description = "I am a hot user with {0} {1} credentials for mobile")
	public void iAmAHotUserWithCredentialsformobile(String email, String password) {
		HomePage home = new HomePage();
		myaccountpage myAcc = new myaccountpage();

		home.iAmOnHomePageformobile();
		home.iNavigateToInstoreHomePageformobile();
		myAcc.iClickonLoginlinkformobile();
		myAcc.iEnteremailandpassword(email, password);
		myAcc.iClickonLoginbutton();
		myAcc.iSeetheuserisloggedinformobile();
		getBundle().setProperty("myEmail", email);

	}

	@QAFTestStep(description = "I am a hot user with stores selected")
	public void iAmAHotUserWithStoresSelected() {
		myaccountpage myAcc = new myaccountpage();

		String email = getBundle().getString("hotuserwithstore.user");
		String password = getBundle().getString("hotuserwithstore.password");
		HomePage.iAmOnHomePage();
		HomePage.iNavigateToInstoreHomePage();
		myAcc.iClickonLoginlink();
		myAcc.iEnteremailandpassword(email, password);
		myAcc.iClickonLoginbutton();
		myAcc.iSeetheuserisloggedin();
		getBundle().setProperty("myEmail", email);

	}

	@QAFTestStep(description = "I am a hot user with no stores selected")
	public void iAmAHotUserWithNoStoresSelected() {
		myaccountpage myAcc = new myaccountpage();

		String email = getBundle().getString("hotuserwithoutstore.user");
		String password = getBundle().getString("hotuserwithoutstore.password");
		HomePage.iAmOnHomePage();
		HomePage.iNavigateToInstoreHomePage();
		myAcc.iClickonLoginlink();
		myAcc.iEnteremailandpassword(email, password);
		myAcc.iClickonLoginbutton();
		myAcc.iSeetheuserisloggedin();
		getBundle().setProperty("myEmail", email);

	}

	/**
	 * Verify the user able to elete the newly added address
	 */
	@QAFTestStep(description = "I delete the newly added address")
	public void iDeleteTheNewlyAddedAddress() {
		AddressBookTestPage addressBook = new AddressBookTestPage();

		addressBook.getAddressbookLnkRemove().verifyPresent();
		addressBook.getAddressbookLnkRemove().click();
		PerfectoUtils.reportMessage("Clicked Remove button..");

		addressBook.getAddressbookBtnYes().click();

		addressBook.getAddressbookLblSavedaddress().waitForNotPresent(5000);
		if (!addressBook.getAddressbookLblDefaultaddresstitle().isPresent())
			PerfectoUtils.reportMessage("Address is deleted successfully..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Address is not deleted successfully..", MessageTypes.Fail);

	}

	/**
	 * Verify the user able to elete the newly added address
	 */
	@QAFTestStep(description = "I edit my HEB store")
	public void iEditMyHebStore() {
		profileInformationTestpage profileInfo = new profileInformationTestpage();
		String displayStore;
		String selectedStrName = null;
		PerfectoUtils.scrolltoelement(profileInfo.getProfileLblMyyhebstore());
		String bannerStatu = profileInfo.getProfileLblMyhebstorebanner().getAttribute("title");

		if (bannerStatu.contains("Expand My H-E-B Store"))
			profileInfo.getProfileLblMyyhebstore().click();

		displayStore = profileInfo.getProfileLblMyhebstorename().getText();
		displayStore = PerfectoUtils.removeSpecialCharacters(displayStore);
		profileInfo.getProfileLnkEditstore().waitForPresent(50000);
		profileInfo.getProfileLnkEditstore().verifyPresent();
		profileInfo.getProfileLnkEditstore().click();
		PerfectoUtils.reportMessage("Clicked Edit link..");

		profileInfo.getProfileLblStoreselector().waitForPresent(8000);

		profileInfo.getProfileTxtZipcode().clear();
		profileInfo.getProfileTxtZipcode()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.zipcode"));
		profileInfo.getProfileBtnGo().click();
		PerfectoUtils.reportMessage("Clicked Go button..");

		profileInfo.getProfileLblSelectbuttonlist().get(0).waitForPresent(10000);
		ArrayList<QAFWebElement> storeList = new ArrayList<QAFWebElement>(profileInfo.getProfileLblStorenamelist());

		for (int i = 0; i < storeList.size(); i++) {

			selectedStrName = storeList.get(i).getText();
			selectedStrName = PerfectoUtils.removeSpecialCharacters(selectedStrName);
			if (!selectedStrName.equalsIgnoreCase(displayStore)) {

				profileInfo.getProfileLblSelectbuttonlist().get(i).click();
				PerfectoUtils.reportMessage("Selected store..." + selectedStrName, MessageTypes.Pass);
				ConfigurationManager.getBundle().setProperty("selectedStrName", selectedStrName);
				break;
			}

		}

		profileInfo.getProfileLblStoreselector().waitForNotPresent(10000);

	}
	
	@QAFTestStep(description = "I edit my HEB store with zipcode {0}")
	public void iEditMyHebStorewithzip(String zipcode) {
		profileInformationTestpage profileInfo = new profileInformationTestpage();
		String displayStore;
		String selectedStrName = null;
		PerfectoUtils.scrolltoelement(profileInfo.getProfileLblMyyhebstore());
		String bannerStatu = profileInfo.getProfileLblMyhebstorebanner().getAttribute("title");

		if (bannerStatu.contains("Expand My H-E-B Store"))
			profileInfo.getProfileLblMyyhebstore().click();

		displayStore = profileInfo.getProfileLblMyhebstorename().getText();
		displayStore = PerfectoUtils.removeSpecialCharacters(displayStore);
		profileInfo.getProfileLnkEditstore().waitForPresent(50000);
		profileInfo.getProfileLnkEditstore().verifyPresent();
		profileInfo.getProfileLnkEditstore().click();
		PerfectoUtils.reportMessage("Clicked Edit link..");

		profileInfo.getProfileLblStoreselector().waitForPresent(8000);

		profileInfo.getProfileTxtZipcode().clear();
		profileInfo.getProfileTxtZipcode()
				.sendKeys(zipcode);
		profileInfo.getProfileBtnGo().click();
		PerfectoUtils.reportMessage("Clicked Go button..");

		profileInfo.getProfileLblSelectbuttonlist().get(0).waitForPresent(10000);
		ArrayList<QAFWebElement> storeList = new ArrayList<QAFWebElement>(profileInfo.getProfileLblStorenamelist());

		for (int i = 0; i < storeList.size(); i++) {

			selectedStrName = storeList.get(i).getText();
			selectedStrName = PerfectoUtils.removeSpecialCharacters(selectedStrName);
			if (!selectedStrName.equalsIgnoreCase(displayStore)) {

				profileInfo.getProfileLblSelectbuttonlist().get(i).click();
				PerfectoUtils.reportMessage("Selected store..." + selectedStrName, MessageTypes.Pass);
				ConfigurationManager.getBundle().setProperty("selectedStrName", selectedStrName);
				break;
			}

		}

		profileInfo.getProfileLblStoreselector().waitForNotPresent(10000);

	}

	/**
	 * Verify new store getting displayed in My HEB store
	 */
	@QAFTestStep(description = "I verify new store getting displayed in My HEB store")
	public void iVerifyNewStoreGettingDisplayedinMyHebStore() {
		profileInformationTestpage profileInfo = new profileInformationTestpage();
		String displayStore;
		String selectedStrName = ConfigurationManager.getBundle().getString("selectedStrName");
		selectedStrName = PerfectoUtils.removeSpecialCharacters(selectedStrName);

		profileInfo.getProfileLblStoreselector().waitForNotPresent(5000);
		profileInfo.getProfileLblMyyhebstore().verifyPresent();
		profileInfo.getProfileLblMyyhebstore().click();
		profileInfo.getProfileLblMyhebstorename().verifyPresent();
		profileInfo.getProfileLblMyhebstorename().waitForPresent(5000);
		profileInfo.getProfileLblMyyhebstore().click();
		profileInfo.getProfileLblMyhebstorename().isDisplayed();
		displayStore = profileInfo.getProfileLblMyhebstorename().getText();
		System.out.println("****" + displayStore);
		displayStore = PerfectoUtils.removeSpecialCharacters(displayStore);

		System.out.println(displayStore + "*****" + selectedStrName);

		if (displayStore.equalsIgnoreCase(selectedStrName))
			PerfectoUtils.reportMessage("Selected store get displayed in My HEB store..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Selected store not displayed in My HEB store..", MessageTypes.Fail);

		profileInfo.getProfileLblMapview().verifyPresent();
		profileInfo.getProfileLnkEditstore().verifyPresent();
		profileInfo.getProfileLnkGetdirection().verifyPresent();
		profileInfo.getProfileLnkSeestoredetail().verifyPresent();

	}

	/**
	 * Verify user land in edit Profile Information
	 */
	@QAFTestStep(description = "I click edit Profile Information")
	public void iClickEditProfileInformation() {
		myAccountLandingTestPage myAccLanding = new myAccountLandingTestPage();

		myAccLanding.getMyacclandingLnkEditprofile().verifyPresent();
		myAccLanding.getMyacclandingLnkEditprofile().click();
		PerfectoUtils.reportMessage("Clicked Edit profile information link...");

		String pageTitle = myAccLanding.getMyacclandingLblPagetitle().getText();

		if (pageTitle.equals("Profile Information"))
			PerfectoUtils.reportMessage("Profile Information page is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Profile Information page is not Displayed....", MessageTypes.Fail);

	}

	/**
	 * Verify user able to edit profile information
	 */
	@QAFTestStep(description = "I edit Profile information")
	public void iEditProfileInformation() {
		profileInformationTestpage profTestPage = new profileInformationTestpage();
		myAccountLandingTestPage myAccLanding = new myAccountLandingTestPage();
		String newFName = "NewName";
		String newEmail;
		String suffix;

		profTestPage.getProfileTxtFirstName().click();
		profTestPage.getProfileTxtFirstName().clear();
		profTestPage.getProfileTxtFirstName().sendKeys(newFName);
		ConfigurationManager.getBundle().setProperty("newFName", newFName);

		PerfectoUtils.reportMessage("ENtered new first name..");

		Date dt = new Date();
		SimpleDateFormat format = new SimpleDateFormat("ddMMyyHHmmss");
		suffix = format.format(dt.getTime());
		newEmail = "newtestemail" + suffix + "@domain.com";

		profTestPage.getProfileTxtEmail().click();
		profTestPage.getProfileTxtEmail().clear();
		profTestPage.getProfileTxtEmail().sendKeys(newEmail);
		ConfigurationManager.getBundle().setProperty("newEmail", newEmail);

		PerfectoUtils.reportMessage("ENtered new email..");

		PerfectoUtils.scrolltoelement(profTestPage.getProfileBtnSaveprofile());
		profTestPage.getProfileBtnSaveprofile().verifyPresent();
		profTestPage.getProfileBtnSaveprofile().click();

		PerfectoUtils.reportMessage("Clicked Save..");

		profTestPage.getProfileBtnSaveprofile().waitForNotPresent(5000);

		String pageTitle = myAccLanding.getMyacclandingLblPagetitle().getText();

		if (pageTitle.equals("My Account"))
			PerfectoUtils.reportMessage("My Account page is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("My Account page is not Displayed....", MessageTypes.Fail);

	}

	/**
	 * Verify edited Profile information getting displayed
	 */
	@QAFTestStep(description = "I verify edited Profile information getting displayed")
	public void iVerifyEditedProfileInformationGettingDisplayed() {
		myAccountLandingTestPage myAccLanding = new myAccountLandingTestPage();

		String newName = ConfigurationManager.getBundle().getString("newFName");
		String newEmail = ConfigurationManager.getBundle().getString("newEmail");

		String dispName = myAccLanding.getMyacclandingLblUsername().getText();
		String dispEmail = myAccLanding.getMyacclandingLblEmail().getText();

		if (dispName.contains(newName))
			PerfectoUtils.reportMessage("Updated name is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Updated name is not Displayed....", MessageTypes.Fail);

		if (dispEmail.equals(newEmail))
			PerfectoUtils.reportMessage("Updated email is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Updated email is not Displayed....", MessageTypes.Fail);

	}

	/**
	 * Verify user able to change the password
	 */
	@QAFTestStep(description = "I change the password")
	public void iChangeThePassword() {
		myAccountLandingTestPage myAccLanding = new myAccountLandingTestPage();
		profileInformationTestpage profTestPage = new profileInformationTestpage();
		String password = getBundle().getString("register.defaultPassword");
		String newPassword;

		Date dt = new Date();
		SimpleDateFormat format = new SimpleDateFormat("HHmmss");
		String suffix = format.format(dt.getTime());
		newPassword = "AutO" + suffix;

		profTestPage.getProfileTxtCurrentpwd().waitForPresent(5000);

		profTestPage.getProfileTxtCurrentpwd().sendKeys(password);
		profTestPage.getProfileTxtNewpwd().click();
		profTestPage.getProfileTxtNewpwd().sendKeys(newPassword);
		profTestPage.getProfileTxtConfirmnewpwd().click();
		profTestPage.getProfileTxtConfirmnewpwd().sendKeys(newPassword);
		profTestPage.getProfileBtnSavePwd().verifyPresent();
		profTestPage.getProfileIconPwdtickmark().verifyPresent();
		profTestPage.getProfileBtnSavePwd().click();
		String pageTitle = myAccLanding.getMyacclandingLblPagetitle().getText();

		if (pageTitle.equals("My Account"))
			PerfectoUtils.reportMessage("Password changed....new password" + newPassword, MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Password is not changed..My Account page is not Displayed....",
					MessageTypes.Fail);

		ConfigurationManager.getBundle().setProperty("newPassword", newPassword);
	}

	/**
	 * Verify change password page getting displayed
	 */
	@QAFTestStep(description = "I navigate to change password page")
	public void iNavigateToChangePasswordPage() {
		myAccountLandingTestPage myAccLanding = new myAccountLandingTestPage();

		myAccLanding.getMyacclandingLnkChangepassword().verifyPresent();
		myAccLanding.getMyacclandingLnkChangepassword().click();

		PerfectoUtils.reportMessage("CLicked Change password link..");

	}

	/**
	 * Verify change password page getting displayed
	 */
	@QAFTestStep(description = "I verify user able to login with new password")
	public void iVerifyUserAbleToLoginWithNewPassword() {
		myAccountLandingTestPage myAccLanding = new myAccountLandingTestPage();
		LoginTestPage loginpage = new LoginTestPage();
		myaccountpage myAcc = new myaccountpage();
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();

		String newPwd = ConfigurationManager.getBundle().getString("newPassword");

		CommonStepDef.entervalueintothetextbox(loginpage.getLoginLblPassword(), newPwd);

		myAcc.iClickonLoginbutton();
		frontdoor.getFrontImgExploremystore().waitForPresent(8000);
		frontdoor.getFrontImgExploremystore().verifyPresent();
		if (frontdoor.getFrontImgExploremystore().isPresent())
			PerfectoUtils.reportMessage("Able to login with changed password..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not able to login with changed password..", MessageTypes.Fail);
	}

	/**
	 * I am a hot user with new registration
	 */
	@QAFTestStep(description = "I am a hot user with new registration")
	public void iAmAHotUserWithNewRegistration() {

		HomePage.iAmOnHomePage();
		HomePage.iNavigateToInstoreHomePage();
		Registration.iNavigateToRegisterPageByClickingRegisterButton();
		Registration.iRegisterANewAccount();
		Registration.iClickGotItThanksButtonInThankYouPage();
	}
	
	@QAFTestStep(description = "I verify the my account section in the top navigation bar")
	public void iVerifyMyAccountSection() {
		MyAccountPage acc = new MyAccountPage();
		
		String accountName = acc.getMyAccountLblUserName().getText();
		if(accountName.contains(getBundle().getString("firstName")))
			PerfectoUtils.reportMessage("First Name is displayed in My Account", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("First Name is not displayed in My Account", MessageTypes.Fail);
	}

	/**
	 * I am a hot user with new registration
	 */
	@QAFTestStep(description = "I am a hot user with new registration for coupons")
	public void iAmAHotUserWithNewRegistrationForCoupons() {

		HomePage.iAmOnHomePage();
		HomePage.iNavigateToInstoreHomePage();
		Registration.iNavigateToRegisterPageByClickingRegisterButton();
		Registration.iRegisterANewAccount();
	}

	/**
	 * Click on Forgot Your Password Link in Login Page
	 */
	@QAFTestStep(description = "I click forgot password link")
	public void iClickForgotPasswordLink() {
		LoginTestPage loginpage = new LoginTestPage();
		loginpage.getLoginLnkForgotpwd().verifyPresent();
		loginpage.getLoginLnkForgotpwd().click();
	}

	/**
	 * Enter email and password in LoginPage
	 */
	@QAFTestStep(description = "I enter valid email {0} to send password reset link")
	public void iEnterValidEmailtoSendpasswordResetLink(String email) {
		LoginTestPage loginpage = new LoginTestPage();
		loginpage.getLoginEdtEmailpwdReset().waitForPresent(5000);
		CommonStepDef.entervalueintothetextbox(loginpage.getLoginEdtEmailpwdReset(), email);
	}

	/**
	 * Click on Send Email in Forgot Your Password Login Page
	 */
	@QAFTestStep(description = "I click Send Email button")
	public void iClickSendEmailButton() {
		LoginTestPage loginpage = new LoginTestPage();

		loginpage.getLoginBtnSendEmail().verifyPresent();
		loginpage.getLoginBtnSendEmail().click();
		loginpage.waitForAjaxToComplete();
	}

	/**
	 * Verify the confirmation message for password reset
	 */
	@QAFTestStep(description = "I see the password reset confirmation message")
	public void iSeethePasswordResetConfirmationMessage() {
		LoginTestPage loginpage = new LoginTestPage();

		loginpage.getLoginLblRestLinkSent().waitForPresent(5000);
		String confMessage = loginpage.getLoginLblRestLinkSent().getText();

		if (confMessage.contains("A password reset link has been sent to the email address you provided")) {
			PerfectoUtils.reportMessage("User is able to Reset the password....", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User is not able to Reset the password....", MessageTypes.Fail);
		}
	}

	/**
	 * Verify user able to logout from the account
	 */
	@QAFTestStep(description = "I logout from the account")
	public void iLogoutFromTheAccount() {
		InStoreHomePage inStoreHomePage = new InStoreHomePage();
		myAccountFlyout myAccFlyout = new myAccountFlyout();
		LoginTestPage loginpage = new LoginTestPage();

		PerfectoUtils.mouseoverandclick(inStoreHomePage.getHomeImgMyaccount(), myAccFlyout.getMyaccflyoutLnkLogout());
		PerfectoUtils.reportMessage("Clicked Logout link from flyout..");

		loginpage.getLoginLblEmail().waitForPresent(5000);
		loginpage.getLoginLblEmail().verifyPresent();

	}

	/**
	 * Verify user able to land edit communication preferences
	 */
	@QAFTestStep(description = "I click edit communication preferences")
	public void iClickEditCommunicationPreferences() {

		myAccountLandingTestPage myAccLanding = new myAccountLandingTestPage();
		CommunicationPrefsTestPage communicationPrefsPage = new CommunicationPrefsTestPage();

		myAccLanding.getMyacclandingLnkEditcommPref().click();
		PerfectoUtils.reportMessage("Clicked Edit communication preferences link..");

		iSeeCommunicationPreferencespage();
	}

	/**
	 * Verify user able to edit communication preferences
	 */
	@QAFTestStep(description = "I edit communication preferences")
	public void iEditCommunicationPreferences() {

		myAccountLandingTestPage myAccLanding = new myAccountLandingTestPage();
		CommunicationPrefsTestPage communicationPrefsPage = new CommunicationPrefsTestPage();
		String newsLetterCheckbox = "test";

		newsLetterCheckbox = communicationPrefsPage.getCommprefChkMonthlynewsletter().getAttribute("checked");

		if (newsLetterCheckbox == null) {
			PerfectoUtils.reportMessage("Monthly news letter check box not selected..");
			communicationPrefsPage.getCommprefChkBoxMonthlynewsletter().click();
			communicationPrefsPage.getCommprefChkMonthlynewsletter().verifyPresent();
			String temp = communicationPrefsPage.getCommprefChkMonthlynewsletter().getAttribute("checked");
			if (temp.equals("true")) {
				PerfectoUtils.reportMessage("Monthly news letter check box is selected..");
				ConfigurationManager.getBundle().setProperty("monthlyNewsLetter", "checked");
			} else
				PerfectoUtils.reportMessage("Unable to select Monthly news letter check box..", MessageTypes.Fail);
		}

		if (newsLetterCheckbox != null) {
			PerfectoUtils.reportMessage("Monthly news letter check box is selected..");
			communicationPrefsPage.getCommprefChkBoxMonthlynewsletter().click();
			String temp = communicationPrefsPage.getCommprefChkMonthlynewsletter().getAttribute("checked");
			if (temp == null) {
				PerfectoUtils.reportMessage("Monthly news letter check box is unchecked..", MessageTypes.Pass);
				ConfigurationManager.getBundle().setProperty("monthlyNewsLetter", "unchecked");
			} else
				PerfectoUtils.reportMessage("Monthly news letter check box is not unchecked..", MessageTypes.Fail);
		}

		communicationPrefsPage.getCommprefBtnSave().verifyPresent();
		communicationPrefsPage.getCommprefBtnSave().click();

		String pageTitle = myAccLanding.getMyacclandingLblPagetitle().getText();

		if (pageTitle.equals("My Account"))
			PerfectoUtils.reportMessage("communication preference edited....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("communication preference not edited..My Account page is not Displayed....",
					MessageTypes.Fail);
	}

	/**
	 * Verify user able to land edit communication preferences
	 */
	@QAFTestStep(description = "I verify the updated communication preferences")
	public void iVerifyTheUpdatedCommunicationPreferences() {
		CommunicationPrefsTestPage communicationPrefsPage = new CommunicationPrefsTestPage();

		String monthlyNewsLetterCheckBox = ConfigurationManager.getBundle().getString("monthlyNewsLetter");

		if (monthlyNewsLetterCheckBox.equals("checked")) {
			String temp = communicationPrefsPage.getCommprefChkMonthlynewsletter().getAttribute("checked");
			if (temp.equals("true"))
				PerfectoUtils.reportMessage("Monthly news letter check box is selected..", MessageTypes.Pass);
		} else {
			String temp = communicationPrefsPage.getCommprefChkMonthlynewsletter().getAttribute("checked");
			if (temp == null)
				PerfectoUtils.reportMessage("Monthly news letter check box is unchecked..", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Monthly news letter check box is not unchecked..", MessageTypes.Fail);
		}

	}

	/**
	 * Verify user able to land edit communication preferences
	 */
	@QAFTestStep(description = "I click on change in myaccount flyout")
	public void iClickOnChangeInMyAccountFlyout() {
		InStoreHomePage inStoreHomePage = new InStoreHomePage();
		myAccountFlyout myAccFlyout = new myAccountFlyout();
		myAccountLandingTestPage myAccLanding = new myAccountLandingTestPage();

		inStoreHomePage.getHomeImgMyaccount().waitForPresent(5000);
		PerfectoUtils.mouseoverandclick(inStoreHomePage.getHomeImgMyaccount(),
				myAccFlyout.getMyaccflyoutLnkChangemystore());
		PerfectoUtils.reportMessage("Clicked Change link from flyout..");

		myAccLanding.getMyacclandingLblPagetitle().waitForPresent(5000);
		String pageTitle = myAccLanding.getMyacclandingLblPagetitle().getText();

		if (pageTitle.equals("Profile Information"))
			PerfectoUtils.reportMessage("Profile Information page is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Profile Information page is not Displayed....", MessageTypes.Fail);

	}

	/**
	 * Verify user able to edit profile information
	 */
	@QAFTestStep(description = "I fill all details in Profile Information section")
	public void iFillAllDetailsInProfileInformationSection() {
		profileInformationTestpage profTestPage = new profileInformationTestpage();
		myAccountLandingTestPage myAccLanding = new myAccountLandingTestPage();
		String newFName = "NewName";
		String newEmail;
		String suffix;
		Date dt = new Date();
		SimpleDateFormat format = new SimpleDateFormat("ddHHmmss");
		suffix = format.format(dt.getTime());

		CommonStepDef.clearAndEntervalueintothetextbox(profTestPage.getProfileTxtFirstName(), "Fname" + suffix);
		ConfigurationManager.getBundle().setProperty("Fname", "Fname" + suffix);
		CommonStepDef.clearAndEntervalueintothetextbox(profTestPage.getProfileTxtLastName(), "Lname" + suffix);
		ConfigurationManager.getBundle().setProperty("Lname", "Lname" + suffix);
		CommonStepDef.clearAndEntervalueintothetextbox(profTestPage.getProfileTxtScreenname(), "Screenname" + suffix);
		ConfigurationManager.getBundle().setProperty("Screenname", "Screenname" + suffix);
		CommonStepDef.clearAndEntervalueintothetextbox(profTestPage.getProfileTxtStreetaddress(),
				ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.street"));
		ConfigurationManager.getBundle().setProperty("Streetaddress1",
				ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.street"));
		CommonStepDef.clearAndEntervalueintothetextbox(profTestPage.getProfileTxtStreetaddress2(),
				"Streetaddress2" + suffix);
		ConfigurationManager.getBundle().setProperty("Streetaddress2", "Streetaddress2" + suffix);
		CommonStepDef.clearAndEntervalueintothetextbox(profTestPage.getProfileTxtCity(),
				ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.city"));
		ConfigurationManager.getBundle().setProperty("City",
				ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.city"));

		profTestPage.getProfileLblState().click();
		Select sel = new Select(profTestPage.getProfileLblState());
		sel.selectByValue("TN");

		CommonStepDef.clearAndEntervalueintothetextbox(profTestPage.getProfileTxtprofZipcode(),
				ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.zipcode"));
		ConfigurationManager.getBundle().setProperty("zipcode",
				ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.zipcode"));

		PerfectoUtils.scrolltoelement(profTestPage.getProfileTxtFirstName());
		profTestPage.getProfileBtnSaveprofile().verifyPresent();
		profTestPage.getProfileBtnSaveprofile().click();

		PerfectoUtils.reportMessage("Clicked Save..");

		profTestPage.getProfileBtnSaveprofile().waitForNotPresent(5000);

		String pageTitle = myAccLanding.getMyacclandingLblPagetitle().getText();

		if (pageTitle.equals("My Account"))
			PerfectoUtils.reportMessage("My Account page is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("My Account page is not Displayed....", MessageTypes.Fail);

	}

	/**
	 * Verify edited Profile information getting displayed
	 */
	@QAFTestStep(description = "I verify all edited Profile information getting displayed")
	public void iVerifyAllEditedProfileInformationGettingDisplayed() {
		profileInformationTestpage profTestPage = new profileInformationTestpage();

		String fName = ConfigurationManager.getBundle().getString("Fname");
		String lName = ConfigurationManager.getBundle().getString("Lname");
		String screenName = ConfigurationManager.getBundle().getString("Screenname");
		String stAdd1 = ConfigurationManager.getBundle().getString("Streetaddress1");
		String stAdd2 = ConfigurationManager.getBundle().getString("Streetaddress2");
		String city = ConfigurationManager.getBundle().getString("City");
		String ziCod = ConfigurationManager.getBundle().getString("zipcode");

		String dispFName = profTestPage.getProfileTxtFirstName().getAttribute("value");
		String dispLname = profTestPage.getProfileTxtLastName().getAttribute("value");
		String dispScreenName = profTestPage.getProfileTxtScreenname().getAttribute("value");
		String dispAdd1 = profTestPage.getProfileTxtStreetaddress().getAttribute("value");
		String dispAdd2 = profTestPage.getProfileTxtStreetaddress2().getAttribute("value");
		String dispCity = profTestPage.getProfileTxtCity().getAttribute("value");
		String dispZipcd = profTestPage.getProfileTxtprofZipcode().getAttribute("value");

		if (dispFName.equals(fName))
			PerfectoUtils.reportMessage("Updated fname is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Updated fname is not Displayed....", MessageTypes.Fail);

		if (dispLname.equals(lName))
			PerfectoUtils.reportMessage("Updated lName is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Updated lName is not Displayed....", MessageTypes.Fail);

		if (dispScreenName.equals(screenName))
			PerfectoUtils.reportMessage("Updated screenName is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Updated screenName is not Displayed....", MessageTypes.Fail);

		if (dispAdd1.equals(stAdd1))
			PerfectoUtils.reportMessage("Updated street Add1 is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Updated street Add1 is not Displayed....", MessageTypes.Fail);

		if (dispAdd2.equals(stAdd2))
			PerfectoUtils.reportMessage("Updated street Add2 is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Updated street Add2 is not Displayed....", MessageTypes.Fail);

		if (dispCity.equals(city))
			PerfectoUtils.reportMessage("Updated city is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Updated city is not Displayed....", MessageTypes.Fail);

		if (dispZipcd.equals(ziCod))
			PerfectoUtils.reportMessage("Updated zipCode is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Updated zipCode is not Displayed....", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I verify newly added address")
	public synchronized void iVerifyNewlyAddedAddress() {
		myAccountLandingTestPage shipaddress = new myAccountLandingTestPage();

		shipaddress.waitForPageToLoad();
		PerfectoUtils.scrolltoelement(shipaddress.getMyacclandingLnkAddressbook());

		if (shipaddress.getMyacclandingBtnAddressedit().isPresent()) {
			PerfectoUtils.reportMessage("Successfully added the shipping address", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("UnSuccessfull attempt to add the shipping address", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Update Store with zipcode {0} and StoreId {1}")
	public static void updateStoreWithZipCodeAndStoreId(String zipCode, String storeId) {
		profileInformationTestpage profileInfo = new profileInformationTestpage();
		String displayStore;
		String selectedStrName = null;
		PerfectoUtils.scrolltoelement(profileInfo.getProfileLblMyyhebstore());
		String bannerStatu = profileInfo.getProfileLblMyhebstorebanner().getAttribute("title");

		if (bannerStatu.contains("Expand My H-E-B Store"))
			profileInfo.getProfileLblMyyhebstore().click();

		displayStore = profileInfo.getProfileLblMyhebstorename().getText();
		displayStore = PerfectoUtils.removeSpecialCharacters(displayStore);
		profileInfo.getProfileLnkEditstore().verifyPresent();
		profileInfo.getProfileLnkEditstore().click();
		PerfectoUtils.reportMessage("Clicked Edit link..");

		profileInfo.getProfileLblStoreselector().waitForPresent(8000);

		profileInfo.getProfileTxtZipcode().clear();
		profileInfo.getProfileTxtZipcode().sendKeys(zipCode);
		profileInfo.getProfileBtnGo().click();
		PerfectoUtils.reportMessage("Clicked Go button..");

		try {
			profileInfo.getProfileGetBtnSelectWithStoreId(storeId).waitForPresent(5000);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Store with store id " + storeId + " is not available");
		}

		String storeName = profileInfo.getProfileGetLblStoreNameWithStoreId(storeId).getText();
		getBundle().setProperty("selectedStore", storeName);
		profileInfo.getProfileGetBtnSelectWithStoreId(storeId).click();
	}

	@QAFTestStep(description = "Change store for hot user with {0} {1}")
	public static void changeStoreForHotUserWith(String zipCode, String storeId) {
		myAccountLandingTestPage shipaddress = new myAccountLandingTestPage();

		iNavigateToMyAccountUsingMouseover();
		iNavigateToProfileInformationPage();
		updateStoreWithZipCodeAndStoreId(zipCode, storeId);
		StoreLocatorPage.iVerifyTheSelectedStoreIsDisplayedOnTheTop();
	}

	/**
	 * Verify add new credit card to account
	 */
	@QAFTestStep(description = "I add new credit card to account")
	public void iAddNewCreditCardToAccount() {
		ManageCreditCardsTestPage manageCreditCard = new ManageCreditCardsTestPage();

		myaccountpage myAcc = new myaccountpage();
		myAcc.iDeleteExistingCards();

		manageCreditCard.getManageccBtnAddanewcreditcard().verifyPresent();
		manageCreditCard.getManageccBtnAddanewcreditcard().click();
		PerfectoUtils.reportMessage("Clicked add new credit card..");

		manageCreditCard.getManageccLblAddnewcreditordebitcardheader().verifyPresent();

		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtNameoncard(),
				ConfigurationManager.getBundle().getString("myAccount.creditcards.visa.nameoncard"));
		manageCreditCard.getManageCCDropCardtype().click();
		Select sel = new Select(manageCreditCard.getManageCCDropCardtype());
		sel.selectByValue(ConfigurationManager.getBundle().getString("myAccount.creditcards.visa.name"));

		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtCardnumber(),
				ConfigurationManager.getBundle().getString("myAccount.creditcards.visa.cardnumber"));

		manageCreditCard.getManageCCDropExpmonth().click();
		Select sel1 = new Select(manageCreditCard.getManageCCDropExpmonth());
		sel1.selectByValue(ConfigurationManager.getBundle().getString("myAccount.creditcards.visa.expmonth"));
		// manageCreditCard.getManageCCDropExpyear().click();
		Select sel2 = new Select(manageCreditCard.getManageCCDropExpyear());
		sel2.selectByValue(ConfigurationManager.getBundle().getString("myAccount.creditcards.visa.expyear"));

		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtCvc(),
				ConfigurationManager.getBundle().getString("myAccount.creditcards.visa.cvc"));

		PerfectoUtils.scrolltoelement(manageCreditCard.getManageCCTxtBillfname());
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtBillfname(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.fname"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtBilllname(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.lname"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtPhoneNumber1(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.ph1"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtPhoneNumber2(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.ph2"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtPhoneNumber3(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.ph3"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtBillAddr1(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.street"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtBillcity(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.city"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtBillzipcode(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.zipcode"));

		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtBillemail(),
				ConfigurationManager.getBundle().getString("myEmail"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtBillconfirmemail(),
				ConfigurationManager.getBundle().getString("myEmail"));

		manageCreditCard.getManageCCBtnAddcreditcardsubmit().verifyPresent();
		manageCreditCard.getManageCCBtnAddcreditcardsubmit().click();
		PerfectoUtils.reportMessage("Clicked add credit card button after entereing all details..");

		manageCreditCard.getManageCCLblDefaultCard().verifyPresent();
		manageCreditCard.getManageCCLblMycreditcards().verifyPresent();

		String dispName = manageCreditCard.getManageCCLblAddedbillname().getText();

		String addedName = ConfigurationManager.getBundle().getString("myAccount.billing.address1.fname");

		if (dispName.contains(addedName))
			PerfectoUtils.reportMessage("Added card displayed...", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Added card is not displayed...", MessageTypes.Fail);

	}

	public void iDeleteExistingCards() {
		ManageCreditCardsTestPage manageCreditCard = new ManageCreditCardsTestPage();

		int i = manageCreditCard.getManageccLiLblCreditcarddeletelist().size();

		while (i > 0 && manageCreditCard.getManageCCLnkDeleteCard().isPresent()) {
			PerfectoUtils.reportMessage("Existing card available.. Deleting..");
			manageCreditCard.getManageCCLnkDeleteCard().verifyPresent();
			manageCreditCard.getManageCCLnkDeleteCard().click();
			manageCreditCard.getManageCCBtnYes().verifyPresent();
			manageCreditCard.getManageCCBtnYes().click();
			PerfectoUtils.reportMessage("Clicked delete for one card..");
			i--;
		}

		manageCreditCard.getManageCCLblMycreditcards().verifyNotPresent();
	}

	/**
	 * Verify delete the new credit card
	 */
	@QAFTestStep(description = "I delete the new credit card")
	public void iDeleteTheNewCreditCard() {
		ManageCreditCardsTestPage manageCreditCard = new ManageCreditCardsTestPage();

		manageCreditCard.getManageCCLnkDeleteCard().verifyPresent();
		manageCreditCard.getManageCCLnkDeleteCard().click();
		manageCreditCard.getManageCCBtnYes().verifyPresent();
		manageCreditCard.getManageCCBtnYes().click();
		PerfectoUtils.reportMessage("Clicked Delete card...");
		manageCreditCard.getManageCCLblMycreditcards().verifyNotPresent();

	}

	/**
	 * I navigate to billing page with some item in cart
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I navigate to billing page with some item in cart")
	public void iNavigateToBillingPageWithSomeItemInCart() throws Exception {

		PdtsearchresultPage pdtSearch = new PdtsearchresultPage();
		CartAndCheckout cartCheckout = new CartAndCheckout();

		String searchtext = ConfigurationManager.getBundle().getString("products.STHProduct");

		pdtSearch.navigateToShipToHomePage();
		pdtSearch.ienterValidSearchTermAndSelectSearchButton(searchtext);
		pdtSearch.iSeeSearchResultsPage();
		pdtSearch.iAddItemToCart();
		pdtSearch.iNavigateToCartPage();
		cartCheckout.iCheckOutTheProduct();
		cartCheckout.iCheckoutTheItemsAsAHotUser();

	}

	/**
	 * I verify the saved card and billing address in checkout page
	 */
	@QAFTestStep(description = "I verify the saved card and billing address in checkout page")
	public void iVerifyTheSavedCardAndBillingAddressInCheckoutPage() {

		CartAndCheckout cartCheckout = new CartAndCheckout();
		PaymentTestPage payment = new PaymentTestPage();

		PerfectoUtils.scrolltoelement(payment.getPaymentTxtNameoncard());

		String firstname = payment.getPaymentTxtFirstname().getAttribute("value");
		String lastname = payment.getPaymentTxtLastname().getAttribute("value");

		String nameOnCard = payment.getPaymentTxtNameoncard().getAttribute("value");
		String cardNumber = payment.getPaymentTxtCardnumber().getAttribute("value");

		if (firstname.equalsIgnoreCase(ConfigurationManager.getBundle().getString("myAccount.billing.address1.fname")))
			PerfectoUtils.reportMessage("Billing address first name matched..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Billing address first name not matched..", MessageTypes.Fail);

		if (lastname.equalsIgnoreCase(ConfigurationManager.getBundle().getString("myAccount.billing.address1.lname")))
			PerfectoUtils.reportMessage("Billing address last name matched..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Billing address last name not matched..", MessageTypes.Fail);

		if (nameOnCard
				.equalsIgnoreCase(ConfigurationManager.getBundle().getString("myAccount.creditcards.visa.nameoncard")))
			PerfectoUtils.reportMessage("Card name matched..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Card name not matched..", MessageTypes.Fail);

		String cardNum = ConfigurationManager.getBundle().getString("myAccount.creditcards.visa.cardnumber");
		cardNum = cardNum.substring(12, 16);
		if (cardNumber.contains(cardNum))
			PerfectoUtils.reportMessage("Card number matched..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Card number not matched..", MessageTypes.Fail);

	}

	/**
	 * Verify user able to change the password n times
	 */
	@QAFTestStep(description = "I change the password {0} times")
	public void iChangeThePasswordTimes(String str0) {
		myAccountLandingTestPage myAccLanding = new myAccountLandingTestPage();
		profileInformationTestpage profTestPage = new profileInformationTestpage();
		String password = getBundle().getString("register.defaultPassword");

		String newPassword;
		int i = 1;
		int n = Integer.parseInt(str0);

		for (int j = 0; j < n; j++) {

			newPassword = "AutoMation" + i;

			profTestPage.getProfileTxtCurrentpwd().waitForPresent(5000);

			profTestPage.getProfileTxtCurrentpwd().sendKeys(password);
			profTestPage.getProfileTxtNewpwd().click();
			profTestPage.getProfileTxtNewpwd().sendKeys(newPassword);
			profTestPage.getProfileTxtConfirmnewpwd().click();
			profTestPage.getProfileTxtConfirmnewpwd().sendKeys(newPassword);
			profTestPage.getProfileBtnSavePwd().verifyPresent();
			profTestPage.getProfileIconPwdtickmark().verifyPresent();
			profTestPage.getProfileBtnSavePwd().click();
			String pageTitle = myAccLanding.getMyacclandingLblPagetitle().getText();
			password = newPassword;
			if (pageTitle.equals("My Account"))
				PerfectoUtils.reportMessage(i + " time Password changed....new password" + newPassword,
						MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Password is not changed..My Account page is not Displayed....",
						MessageTypes.Fail);

			ConfigurationManager.getBundle().setProperty("newPassword", newPassword);
			i++;
			myAccLanding.getMyacclandingLnkChangepassword().verifyPresent();
			myAccLanding.getMyacclandingLnkChangepassword().click();

			PerfectoUtils.reportMessage("CLicked Change password link..");
		}
	}

	@QAFTestStep(description = "I do re-login with {0} {1} credentials")
	public void iDoReloginWithCredentials(String email, String password) {
		myaccountpage myAcc = new myaccountpage();
		LoginTestPage loginpage = new LoginTestPage();
		HomePage home = new HomePage();
		loginpage.getLoginLblEmail().clear();
		myAcc.iEnteremailandpassword(email, password);
		myAcc.iClickonLoginbutton();
		home.iNavigateToInstoreHomePage();
		myAcc.iSeetheuserisloggedin();

	}

	/**
	 * Verify Navigation of My Account Page on clicking UserName
	 */
	@QAFTestStep(description = "Clicking the username on instore homepage")
	public synchronized void clickUserNameLink() {
		MyAccountPage myAccountPage = new MyAccountPage();
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		
		myAccountPage.getMyAccountLnkUserName().waitForPresent(5000);
		myAccountPage.getMyAccountLnkUserName().verifyPresent();
		myAccountPage.getMyAccountLnkUserName().click();	

		// PerfectoUtils.mouseoverandclick(myAccountPage.getMyAccountLnkUserName());
		PerfectoUtils.reportMessage("Clicked on username on instore homepage", MessageTypes.Pass);
		frontdoor.getFrontImgFav().verifyPresent();
	}

	@QAFTestStep(description = "Navigate to My Account page")
	public synchronized void navigateToMyAccountPage() {
		clickUserNameLink();
		iSeeMyAccountPage();
	}

	/**
	 * Validates HEB logo, Search Bar and Store finder
	 */
	@QAFTestStep(description = "I see My Account Page")
	public void iSeeMyAccountPage() {
		MyAccountPage myAccountPage = new MyAccountPage();

		if (myAccountPage.getMyAccountLblMyAccountHeader().verifyPresent()) {
			PerfectoUtils.reportMessage("Navigated to My Account Page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to Navigate to My Account Page", MessageTypes.Fail);
		}
	}

	/**
	 * Search a term in Front door page
	 */
	@QAFTestStep(description = "Clicking the My Account label on instore homepage")
	public void clickMyAccountLabelOnHomePage() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkMyAccountUserName().verifyPresent();
		myAccountPage.getMyAccountLnkMyAccountUserName().click();
		PerfectoUtils.reportMessage("Clicked on My Account label on instore homepage", MessageTypes.Pass);
	}

	/**
	 * Clicking on Store Finder in New Home page
	 */
	@QAFTestStep(description = "I Validate the options from the username mouseover")
	public void iValidateOptionsfromUserNameMouseOver() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkChange().verifyPresent();
		myAccountPage.getMyAccountLblMypreferredstore().verifyPresent();
		myAccountPage.getMyAccountLnkOrderstatus().verifyPresent();
		myAccountPage.getMyAccountLnkMyrecipebox().verifyPresent();
		myAccountPage.getMyAccountLnkMycoupons().verifyPresent();
		myAccountPage.getMyAccountLnkPharmacyprofile().verifyPresent();
		myAccountPage.getMyAccountLnkMyAccountUserName().verifyPresent();
		myAccountPage.getMyAccountLnkLogout().verifyPresent();
	}

	/**
	 * Navigates back to home page
	 */
	@QAFTestStep(description = "Mouseover username")
	public void mouseoverUserName() {
		MyAccountPage myAccountPage = new MyAccountPage();
		PerfectoUtils.mousehover(myAccountPage.getMyAccountLnkUserName());
		PerfectoUtils.reportMessage("Mouseover on the UserName", MessageTypes.Pass);
	}

	/**
	 * Validate New Home Page Hero Images
	 */
	@QAFTestStep(description = "I Validate My Account Page")
	public void iValidateMyAccountPage() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLblInformationtab().verifyPresent();
		myAccountPage.getMyAccountLblOnlineorderstab().verifyPresent();
		myAccountPage.getMyAccountLblMysavingstab().verifyPresent();
		myAccountPage.getMyAccountLblFeaturestab().verifyPresent();
		myAccountPage.getMyAccountLblProfileinformationsubtitle().verifyPresent();
		myAccountPage.getMyAccountLblNameemailpwdleftcontainer().verifyPresent();
		myAccountPage.getMyAccountLblMyhebleftcontainer().verifyPresent();
		myAccountPage.getMyAccountLblPharmacysubtitle().verifyPresent();
		myAccountPage.getMyAccountLnkEditprofileinfo().verifyPresent();
		myAccountPage.getMyAccountLnkEditcommpref().verifyPresent();
		myAccountPage.getMyAccountLnkChangepwd().verifyPresent();
		myAccountPage.getMyAccountLnkCreatepharmacyprofile().verifyPresent();
		myAccountPage.getMyAccountLblAddressbooksubtitle().verifyPresent();
		myAccountPage.getMyAccountLblOrderhistorysubtitle().verifyPresent();
		myAccountPage.getMyAccountLnkEditaddbk().verifyPresent();
		myAccountPage.getMyAccountLnkStartshoppingnw().verifyPresent();
		myAccountPage.getMyAccountLblDigitalcouponssubtitle().verifyPresent();
		myAccountPage.getMyAccountLnkEditmobpref().verifyPresent();
		myAccountPage.getMyAccountLnkSeecurrentcoupons().verifyPresent();
		myAccountPage.getMyAccountLblShoppinglistsubtitle().verifyPresent();
		myAccountPage.getMyAccountLblRecipeboxsubtitle().verifyPresent();
		myAccountPage.getMyAccountLnkManagemylist().verifyPresent();
		myAccountPage.getMyAccountLnkGotorecipebox().verifyPresent();
		myAccountPage.getMyAccountLblShoplist().verifyPresent();
		myAccountPage.getMyAccountLblMyaacountbreadcrumblast().verifyPresent();
	}

	/**
	 * Click Explore my Store Hero Images
	 */
	@QAFTestStep(description = "I Validate left navigation items")
	public static void iValidateLeftNavigationItems() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkLeftmyaccount().verifyPresent();
		myAccountPage.getMyAccountLnkLeftprofileinformation().verifyPresent();
		myAccountPage.getMyAccountLnkLeftpharmacyprofiles().verifyPresent();
		myAccountPage.getMyAccountLnkLeftcommunicationprefs().verifyPresent();
		myAccountPage.getMyAccountLblLeftonlineorders().verifyPresent();
		myAccountPage.getMyAccountLnkLeftaddressbook().verifyPresent();
		myAccountPage.getMyAccountLnkLeftorderhistory().verifyPresent();
		myAccountPage.getMyAccountLnkLeftquickreorder().verifyPresent();
		myAccountPage.getMyAccountLnkLeftchangepassword().verifyPresent();
		myAccountPage.getMyAccountLnkLefttaxexemption().verifyPresent();
		myAccountPage.getMyAccountLnkLeftmanagecreditcards().verifyPresent();
		myAccountPage.getMyAccountLnkLeftmanagesubscriptions().verifyPresent();
		myAccountPage.getMyAccountLblLeftsavings().verifyPresent();
		myAccountPage.getMyAccountLnkLeftdigitalcoupons().verifyPresent();
		myAccountPage.getMyAccountLblLeftfeatures().verifyPresent();
		myAccountPage.getMyAccountLnkLeftrecipebox().verifyPresent();
		myAccountPage.getMyAccountLnkLeftshoppinglist().verifyPresent();
	}

	@QAFTestStep(description = "Click on Profile Information link")
	public static void clickonProfileInformationlink() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkLeftprofileinformation().verifyPresent();
		myAccountPage.getMyAccountLnkLeftprofileinformation().click();
		PerfectoUtils.reportMessage("Clicked on Profile Information link on My Account Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I should see Profile Information page")
	public static void iSeeProfileInformationPage() {
		profileInformationTestpage profileInfopage = new profileInformationTestpage();
		profileInfopage.getProfileLblProfileinfotitle().verifyPresent();
		profileInfopage.getProfileIconProfileinfobullet().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to Profile Information Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Click on Pharmacy Profiles link")
	public static void clickonPharmacyProfileslink() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkLeftpharmacyprofiles().verifyPresent();
		myAccountPage.getMyAccountLnkLeftpharmacyprofiles().click();
		PerfectoUtils.reportMessage("Clicked on Pharmacy Profiles link on My Account Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I should see Pharmacy Profiles page")
	public static void iSeePharmacyProfilespage() {
		PharmacyProfileTestPage pharmacyProfilePage = new PharmacyProfileTestPage();
		pharmacyProfilePage.getPharmacyprofileLblBreadcrump().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to Pharmacy Profiles Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Click on Communication Preferences link")
	public static void clickCommunicationPreferenceslink() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkLeftcommunicationprefs().verifyPresent();
		myAccountPage.getMyAccountLnkLeftcommunicationprefs().click();
		PerfectoUtils.reportMessage("Clicked on Communication Preferences link on My Account Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I should see Communication Preferences page")
	public static void iSeeCommunicationPreferencespage() {
		CommunicationPrefsTestPage communicationPrefsPage = new CommunicationPrefsTestPage();
		communicationPrefsPage.getCommPrefLblCommPrefheader().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to Communication Preferences Page", MessageTypes.Pass);
	}
	
	@QAFTestStep(description = "I navigate to Communication Preferences page")
	public void iNavigatetoCommunicationPreferencespage() {
		myaccountpage myacc = new myaccountpage();
		
		myacc.clickUserNameLink();
		myacc.clickCommunicationPreferenceslink();
		PerfectoUtils.reportMessage("Navigated to Communication Preferences Page", MessageTypes.Pass);
	}
	
	@QAFTestStep(description = "I navigate to Manage Subscriptions page")
	public void iNavigatetoManageSubscriptionspage() {
		myaccountpage myacc = new myaccountpage();
		
		myacc.clickUserNameLink();
		myacc.clickManageSubscriptionsLink();
		PerfectoUtils.reportMessage("Navigated to Manage Subscriptions Page", MessageTypes.Pass);
	}
	
	@QAFTestStep(description = "I verify error message for product no longer available")
	public void iVerifyErrorMessageforProductsNotAvailable() {
		ManageSubscriptionTestPage managesubscription = new ManageSubscriptionTestPage();
		
		managesubscription.getManageSubscriptionLblItemnotavilable().verifyPresent();
		managesubscription.getItemnotavilableOopsEM(getBundle().getString("products.errorMsg.subscriptionpdtnotavailable")).verifyPresent();
	}
	
	@QAFTestStep(description = "I deselect monthly and promotions checkbox in Communication Preferences page")
	public void iDeselectmonthlyandpromotionscheckboxCommunicationPreferencespage() {
		CommunicationPrefsTestPage communicationPrefsPage = new CommunicationPrefsTestPage();
		
		communicationPrefsPage.getCommprefChkBoxMonthlynewsletter().click();
		communicationPrefsPage.getCommprefChkBoxPromotions().click();
		communicationPrefsPage.getCommprefBtnSave().click();
		PerfectoUtils.reportMessage("Deselected monthly and promotions checkbox in Communication Preferences page", MessageTypes.Pass);
	}
	
	@QAFTestStep(description = "I verify user is NOT auto enrolled into weekly ads")
	public void iVerifyuserisNOTautoenrolledintoweeklyads() {
		CommunicationPrefsTestPage communicationPrefsPage = new CommunicationPrefsTestPage();
		
		communicationPrefsPage.getCommprefChkBoxVerifyCheckedWeeklyads().verifyNotVisible();
	}

	@QAFTestStep(description = "Click on Address Book link")
	public static void clickAddressBookLink() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkLeftaddressbook().verifyPresent();
		myAccountPage.getMyAccountLnkLeftaddressbook().click();
		PerfectoUtils.reportMessage("Clicked on Address Book link on My Account Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I should see Address Book page")
	public static void iSeeAddressBookpage() {
		AddressBookTestPage addressBkPage = new AddressBookTestPage();
		addressBkPage.getAddressbookLblheader().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to Address Book Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Click on Order History link")
	public static void clickOrderHistoryLink() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkLeftorderhistory().verifyPresent();
		myAccountPage.getMyAccountLnkLeftorderhistory().click();
		PerfectoUtils.reportMessage("Clicked on Order History link on My Account Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I should see Order History page")
	public static void iSeeOrderHistorypage() {
		OrderhistoryTestPage orderhistoryPage = new OrderhistoryTestPage();
		
		orderhistoryPage.getOdrhistoryTxtOrderhistory().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to Order History Page", MessageTypes.Pass);		
		orderhistoryPage.getLnkViewDetails().click();
		String imageOrdhis = orderhistoryPage.getLblImageView().getAttribute("src");
		
		if (imageOrdhis.equals(getBundle().getString("imageAfetrCustamization")))
			PerfectoUtils.reportMessage("Same image is getting displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Same image is not getting displayed", MessageTypes.Fail);
		
	}

	@QAFTestStep(description = "Click on Quick reorder link")
	public static void clickQuickreorderLink() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkLeftquickreorder().verifyPresent();
		myAccountPage.getMyAccountLnkLeftquickreorder().click();
		PerfectoUtils.reportMessage("Clicked on Quick reorder link on My Account Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I should see Quick reorder page")
	public static void iSeeQuickReorderpage() {
		QuickReorderTestPage quickReorderPage = new QuickReorderTestPage();
		quickReorderPage.getQuickReoderTxtheader().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to Quick reorder Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I navigate to the Quick reorder page")
	public synchronized void iNavigatetoQuickReorderpage() {
		clickUserNameLink();
		iSeeMyAccountPage();
		clickQuickreorderLink();
		iSeeQuickReorderpage();
	}
	
	@QAFTestStep(description = "I navigate to Order history page verify image")
	public synchronized void iNavigateToOrderHistoryPage() {
		clickUserNameLink();
		iSeeMyAccountPage();
		clickOrderHistoryLink();
		iSeeOrderHistorypage();
	}
	
	@QAFTestStep(description = "I verify user can quick reorder")
	public synchronized void iVerifyUserQuickReorder() {
		HomePage homepage = new HomePage();
		QuickReorderTestPage quickreorder = new QuickReorderTestPage();

		//homepage.iNavigateToInstoreHomePage();
		iNavigatetoQuickReorderpage();
		if (quickreorder.getLblProductName().isPresent()) {
			String productName = quickreorder.getLblProductName().getText();
			String expectedProductName = (String) getBundle().getProperty("addingItemName");
			if (productName.contains("-")) {
				String[] productNameSplit = productName.split("B");
				if (expectedProductName.contains(productNameSplit[1])) {
					PerfectoUtils.reportMessage("User able to reorder when profile store is same as purchased store",
							MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage(
							"User not able to reorder when profile store is same as purchased store",
							MessageTypes.Fail);
				}
			} else {
				if (expectedProductName.contains(productName)) {
					PerfectoUtils.reportMessage("User able to reorder when profile store is same as purchased store",
							MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage(
							"User not able to reorder when profile store is same as purchased store",
							MessageTypes.Fail);
				}
			}
			quickreorder.getLblAddtocart().verifyPresent();
		} else {
			PerfectoUtils.reportMessage("User not able to reorder when profile store is same as purchased store",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify user cannot quick reorder")
	public synchronized void iVerifyUserCannotQuickReorder() {
		HomePage homepage = new HomePage();
		QuickReorderTestPage quickreorder = new QuickReorderTestPage();

		// homepage.iNavigateToInstoreHomePage();
		iNavigatetoQuickReorderpage();
		if (quickreorder.getLblAddtocart().isPresent()) {
			PerfectoUtils.reportMessage("User able to reorder when profile store is not same as purchased store",
					MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("User cannot able to reorder when profile store is not same as purchased store",
					MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I get the choices {0} for customized cake in the cart")
	public synchronized void iGetthechoicesforcustomizedcakeinthecart(String orderedno) throws InterruptedException {
		QuickReorderTestPage quickreorder = new QuickReorderTestPage();
		CartAndCheckout cart = new CartAndCheckout();
		PaymentGatewayStepdef payment = new PaymentGatewayStepdef();
		HomePage home = new HomePage();

		cart.iNavigateToCartBySelectingViewCartInCartMouseoverOption();
		getBundle().setProperty("price", quickreorder.getQuickreorderlblPrice(orderedno).getText());
		getBundle().setProperty("size", quickreorder.getQuickreorderlblSize(orderedno).getText());
		getBundle().setProperty("border", quickreorder.getQuickreorderlblBorder(orderedno).getText());
		getBundle().setProperty("topborder", quickreorder.getQuickreorderlblTopborder(orderedno).getText());
		getBundle().setProperty("color", quickreorder.getQuickreorderlblColor(orderedno).getText());
		getBundle().setProperty("icing", quickreorder.getQuickreorderlblIcing(orderedno).getText());
		getBundle().setProperty("filling", quickreorder.getQuickreorderlblFilling(orderedno).getText());
		getBundle().setProperty("message", quickreorder.getQuickreorderlblMessage(orderedno).getText());
		cart.iCheckOutTheProduct();
		cart.iCheckoutTheItemsAsAHotUser();
		cart.iMakeThePaymentsWithCreditCard();
		cart.iVerifyTheOrderConfirmationPage();
		payment.selectContinueShoppingOptionFromOrderConfirmationPage();
		home.iNavigateToInstoreHomePage();
	}

	@QAFTestStep(description = "I verify original choices are persisted for customized cake")
	public synchronized void iVerifyOriginalchoicesforcustomizedcake() {
		HomePage homepage = new HomePage();
		QuickReorderTestPage quickreorder = new QuickReorderTestPage();

		iNavigatetoQuickReorderpage();

		if (quickreorder.getQuickreorderlblPrice("2").getText().contains(getBundle().getString("price")))
			PerfectoUtils.reportMessage("Price original choices are persisted for customized cake", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Price original choices are not persisted for customized cake",
					MessageTypes.Fail);

		if (quickreorder.getQuickreorderlblSize("2").getText().equals(getBundle().getString("size")))
			PerfectoUtils.reportMessage("Size original choices are persisted for customized cake", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Size original choices are not persisted for customized cake",
					MessageTypes.Fail);

		if (quickreorder.getQuickreorderlblBorder("2").getText().equals(getBundle().getString("border")))
			PerfectoUtils.reportMessage("Border original choices are persisted for customized cake", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Border original choices are not persisted for customized cake",
					MessageTypes.Fail);

		if (quickreorder.getQuickreorderlblTopborder("2").getText().equals(getBundle().getString("topborder")))
			PerfectoUtils.reportMessage("Topborder original choices are persisted for customized cake",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Topborder original choices are not persisted for customized cake",
					MessageTypes.Fail);

		if (quickreorder.getQuickreorderlblColor("2").getText().equals(getBundle().getString("color")))
			PerfectoUtils.reportMessage("Color original choices are persisted for customized cake", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Color original choices are not persisted for customized cake",
					MessageTypes.Fail);

		if (quickreorder.getQuickreorderlblIcing("2").getText().equals(getBundle().getString("icing")))
			PerfectoUtils.reportMessage("Icing original choices are persisted for customized cake", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Icing original choices are not persisted for customized cake",
					MessageTypes.Fail);

		if (quickreorder.getQuickreorderlblFilling("2").getText().equals(getBundle().getString("filling")))
			PerfectoUtils.reportMessage("Filling original choices are persisted for customized cake",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Filling original choices are not persisted for customized cake",
					MessageTypes.Fail);

		if (quickreorder.getQuickreorderlblMessage("2").getText().equals(getBundle().getString("message")))
			PerfectoUtils.reportMessage("Message original choices are persisted for customized cake",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Message original choices are not persisted for customized cake",
					MessageTypes.Fail);
	}

	@QAFTestStep(description = "Click on Change Password link")
	public static void clickChangePasswordLink() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkLeftchangepassword().verifyPresent();
		myAccountPage.getMyAccountLnkLeftchangepassword().click();
		PerfectoUtils.reportMessage("Clicked on Change Password link on My Account Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I should see Change Password page")
	public static void iSeeChangePasswordpage() {
		profileInformationTestpage profileInfopage = new profileInformationTestpage();
		profileInfopage.getProfileLblProfileinfotitle().verifyPresent();
		profileInfopage.getProfileIconChangepwdbullet().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to Change Password Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Click on Tax exemption link")
	public static void clickTaxExemptionLink() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkLefttaxexemption().verifyPresent();
		myAccountPage.getMyAccountLnkLefttaxexemption().click();
		PerfectoUtils.reportMessage("Clicked on Tax Exemption link on My Account Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I should see Tax exemption page")
	public static void iSeeTaxExemptionpage() {
		TaxExemptionTestPage taxExemptionPage = new TaxExemptionTestPage();
		taxExemptionPage.getTaxExemptionTxtheader().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to Tax Exemption Page", MessageTypes.Pass);
	}
	
	@QAFTestStep(description = "I verify the UI of Tax exemption page")
	public static void iVerifyUIofTaxExemptionpage() {
		TaxExemptionTestPage taxExemptionPage = new TaxExemptionTestPage();
		
		taxExemptionPage.getTaxExemptionTxtheader().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to Tax Exemption Page", MessageTypes.Pass);
		taxExemptionPage.getTaxExemptionLblRegister().verifyPresent();
		taxExemptionPage.getTaxExemptionLblPrintform().verifyPresent();
		taxExemptionPage.getTaxExemptionLnkHomebreadcrumb().verifyPresent();
		taxExemptionPage.getTaxExemptionLnkMyAccBreadcrumbr().verifyPresent();
		taxExemptionPage.getTaxExemptiontaxexemptionLnkBreadcrumbr().verifyPresent();
		String breadcrumbcolor = taxExemptionPage.getTaxExemptiontaxexemptionLnkBreadcrumbr().getCssValue("color");
		if(breadcrumbcolor.equals(getBundle().getString("products.rgbaColourCode.red"))){
			PerfectoUtils.reportMessage("Tax Exemption breadcrumb color is red", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Tax Exemption breadcrumb color is not red", MessageTypes.Fail);
		}
		taxExemptionPage.getTaxExemptionLblID().verifyPresent();
		taxExemptionPage.getTaxExemptionTxtID().verifyPresent();
		taxExemptionPage.getTaxExemptionLblRequirednote().verifyPresent();
		taxExemptionPage.getTaxExemptionLnkImagingService().verifyPresent();
		String imagingServiceColor = taxExemptionPage.getTaxExemptionLnkImagingService().getCssValue("color");
		if(imagingServiceColor.equals(getBundle().getString("products.rgbaColourCode.blue"))){
			PerfectoUtils.reportMessage("Tax Exemption breadcrumb color is blue", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Tax Exemption breadcrumb color is not blue", MessageTypes.Fail);
		}
		taxExemptionPage.getTaxExemptionLblOrgName().verifyPresent();
		taxExemptionPage.getTaxExemptionLblTaxexemptionstate().verifyPresent();
		String defaultTEState = PerfectoUtils.dropdownGetFirstSelectedOption(taxExemptionPage.getTaxExemptionDDTaxexemptionstate());
		if(defaultTEState.contains(getBundle().getString("myAccount.taxexemption.taxexceptionstate"))){
			PerfectoUtils.reportMessage("Tax Exemption Default state is "+defaultTEState, MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Tax Exemption Default state is not "+defaultTEState, MessageTypes.Fail);
		}
		taxExemptionPage.getTaxExemptionLblContactEmail().verifyPresent();
		taxExemptionPage.getTaxExemptionLblContactName().verifyPresent();
		taxExemptionPage.getTaxExemptionLblTitle().verifyPresent();
		taxExemptionPage.getTaxExemptionLblPhoneNo().verifyPresent();
		taxExemptionPage.getTaxExemptionLblRegisteras().verifyPresent();
		String defaultRegisteredAs = PerfectoUtils.dropdownGetFirstSelectedOption(taxExemptionPage.getTaxExemptionDDRegisteras());
		if(defaultRegisteredAs.contains(getBundle().getString("myAccount.taxexemption.registeredAsDefault"))){
			PerfectoUtils.reportMessage("Tax Exemption RegisteredAs Default value is "+defaultRegisteredAs, MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Tax Exemption RegisteredAs Default value is not "+defaultRegisteredAs, MessageTypes.Fail);
		}
		taxExemptionPage.getTaxExemptionLblBusinessdesc().verifyPresent();
		taxExemptionPage.getTaxExemptionLblGeneraldesc().verifyPresent();
		taxExemptionPage.getTaxExemptionTxtGeneraldesc().verifyPresent();
		taxExemptionPage.getTaxExemptionLblOrgaddress1().verifyPresent();
		taxExemptionPage.getTaxExemptionLblOrgaddress2().verifyPresent();
		taxExemptionPage.getTaxExemptionLblCity().verifyPresent();
		taxExemptionPage.getTaxExemptionLblState().verifyPresent();
		String defaultState = PerfectoUtils.dropdownGetFirstSelectedOption(taxExemptionPage.getTaxExemptionDDState());
		if(defaultState.contains(getBundle().getString("myAccount.taxexemption.taxexceptionstate"))){
			PerfectoUtils.reportMessage("Tax Exemption Default State is "+defaultState, MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Tax Exemption Default State is not "+defaultState, MessageTypes.Fail);
		}
		taxExemptionPage.getTaxExemptionLblZip().verifyPresent();
		taxExemptionPage.getTaxExemptionChkIverify().verifyPresent();
		String iVerifyTxt = taxExemptionPage.getTaxExemptionLblIverify().getText();
		if(iVerifyTxt.equals(getBundle().getString("myAccount.taxexemption.label"))){
			PerfectoUtils.reportMessage("I verify text is displayed: "+iVerifyTxt, MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("I verify text is not displayed: "+iVerifyTxt, MessageTypes.Fail);
		}
		taxExemptionPage.getTaxExemptionBtnContinue().verifyPresent();
		taxExemptionPage.getTaxExemptionLnkCancel().verifyPresent();
	}

	@QAFTestStep(description = "Click on Manage Credit cards link")
	public static void clickManageCreditcardsLink() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkLeftmanagecreditcards().verifyPresent();
		myAccountPage.getMyAccountLnkLeftmanagecreditcards().click();
		PerfectoUtils.reportMessage("Clicked on Manage Credit cards link on My Account Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I should see Manage Credit cards page")
	public static void iSeeManageCreditcardspage() {
		ManageCreditCardsTestPage manageCCPage = new ManageCreditCardsTestPage();
		manageCCPage.getManageCCTxtHeader().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to Manage Credit cards Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Click on Manage Subscriptions link")
	public static void clickManageSubscriptionsLink() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkLeftmanagesubscriptions().verifyPresent();
		myAccountPage.getMyAccountLnkLeftmanagesubscriptions().click();
		PerfectoUtils.reportMessage("Clicked on Manage Subscriptions link on My Account Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I should see Manage Subscriptions page")
	public static void iSeeManageSubscriptionspage() {
		ManageSubscriptionTestPage manageSubscriptionsPage = new ManageSubscriptionTestPage();
		manageSubscriptionsPage.getManageSubscriptionTxtheader().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to Manage Subscriptions Page", MessageTypes.Pass);
	}
	
	@QAFTestStep(description = "I change the ship date for a subscribable product")
	public static void iChangeShipdateforsubscribableproduct() {
		ManageSubscriptionTestPage manageSubscriptionsPage = new ManageSubscriptionTestPage();
		
		manageSubscriptionsPage.getManageSubscriptionLnkChange().click();
		String changedDate = manageSubscriptionsPage.getManageSubscriptionLnkChangeDate().getText();
		manageSubscriptionsPage.getManageSubscriptionLnkChangeDate().click();
		getBundle().setProperty("changedDate", changedDate);
	}
	
	@QAFTestStep(description = "I verify whether ship date is changed")
	public static void iVerifywhethershipdateischanged() {
		ManageSubscriptionTestPage manageSubscriptionsPage = new ManageSubscriptionTestPage();
		
		String actualChangedDate = manageSubscriptionsPage.getManageSubscriptionLblDate().getText();
		if(actualChangedDate.contains(getBundle().getString("changedDate"))){
			PerfectoUtils.reportMessage("Ship date got updated", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Ship date is not updated", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Click on Digital Coupons link")
	public static void clickDigitalCouponsLink() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkLeftdigitalcoupons().verifyPresent();
		myAccountPage.getMyAccountLnkLeftdigitalcoupons().click();
		PerfectoUtils.reportMessage("Clicked on Digital Coupons link on My Account Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I should see Digital Coupons page")
	public static void iSeeDigitalCouponspage() {
		DigitalCouponsTestPage digitalCouponsPage = new DigitalCouponsTestPage();
		digitalCouponsPage.getLblDigcouponsheader().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to Digital Coupons Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Click on Recipe box link")
	public static void clickRecipeBoxLink() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkLeftrecipebox().verifyPresent();
		myAccountPage.getMyAccountLnkLeftrecipebox().click();
		PerfectoUtils.reportMessage("Clicked on Recipe box link on My Account Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I should see Recipe box page")
	public static void iSeeRecipeBoxpage() {
		RecipeBoxTestpage recipeBoxPage = new RecipeBoxTestpage();
		recipeBoxPage.getRecipeBoxLblHeader().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to Recipe box Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Click on Shopping list link")
	public static void clickShoppingListLink() {
		MyAccountPage myAccountPage = new MyAccountPage();
		myAccountPage.getMyAccountLnkLeftshoppinglist().verifyPresent();
		myAccountPage.getMyAccountLnkLeftshoppinglist().click();
		PerfectoUtils.reportMessage("Clicked on Shopping list link on My Account Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I should see My lists page")
	public static void iSeeMyListspage() {
		MyListTestPage myListPage = new MyListTestPage();
		myListPage.getMylistLblMylist().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to My lists Page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify the link to the login page on the password reset page")
	public void verifyTheLinkToTheLoginPageOnThePasswordResetPage() {
		PasswordResetTestPage passreset = new PasswordResetTestPage();

		if (passreset.getLnkLogintoaccessaccount().isPresent()) {
			PerfectoUtils.reportMessage("Link to the Login page is present..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Link to the Login page is not present..", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I verify Subscribe radio button is present")
	public void iVerifySubscriptionRadioButton() {
		PDPTestPage pdp = new PDPTestPage();
		
		pdp.getRgbSubscription().verifyPresent();
	}

	@QAFTestStep(description = "I Add a subscription product to the cart")
	public void iAddSubscriptionProductToTheCart() {
		MyAccountPage myAccountPage = new MyAccountPage();
		ManageSubscriptionTestPage manageSubs = new ManageSubscriptionTestPage();
		CDPTestPage cdp = new CDPTestPage();
		PDPTestPage pdp = new PDPTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		CartTestPage cartpage = new CartTestPage();
		ShippingTestPage ship = new ShippingTestPage();
		PerfectoUtils.scrolltoelement(cdp.getProductTitle2Subscription());
		cdp.getProductTitle2Subscription().click();
		pdp.getRgbSubscription().click();
		pdp.getPdpBtnAddtocart().click();

		PerfectoUtils.scrolltoelement(instorehome.getHomeBtnCart());
		PerfectoUtils.mousehoverusingActions(instorehome.getHomeBtnCart());
		instorehome.getHomeBtnCartviewcart().click();
		cartpage.getCartLblHeader().waitForPresent(5000);

		PerfectoUtils.scrolltoelement(cartpage.getCartBtnCheckout());
		cartpage.getCartBtnCheckout().waitForPresent(3000);
		cartpage.getCartBtnCheckout().verifyPresent();
		cartpage.getCartBtnCheckout().click();

		HomePage home = new HomePage();
		PerfectoUtils.scrolltoelement(ship.getShippingtabRbtnNewShippingAddress());
		ship.getShippingtabRbtnNewShippingAddress().click();
		ship.getShippingtabTxtNickname()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.AddressNickname"));
		ship.getShippingtabTxtFirstname()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.FirstName"));
		ship.getShippingtabTxtLastname()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.LastName"));
		ship.getShippingtabTxtPhonenumber1()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.phonenumberone"));
		ship.getShippingtabTxtPhonenumber2()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.phonenumbertwo"));
		ship.getShippingtabTxtPhonenumber3()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.phonenumberthree"));
		ship.getShippingtabTxtStreetaddress1()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.street"));
		ship.getShippingtabTxtCity().sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.city"));
		ship.getShippingtabTxtZipcode1()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.zipcode"));
		ship.getShippingtabTxtZipcode2().click();
		ship.waitForAjaxToComplete();
		ship.getShippingtabBtnSave().verifyPresent();
		ship.getShippingtabBtnSave().click();
		PerfectoUtils.reportMessage("Clicked Save button...");

		ship.getShippingtabBtnContinueexistingaddress().click();

		iEnterCreditCardDetails();

		home.iClickOnExploreMyStoreHeroImage();
		navigateToMyAccountPage();
		myAccountPage.getMyAccountLnkLeftmanagesubscriptions().click();
		PerfectoUtils.scrolltoelement(manageSubs.getManageSubscriptionLblsubscribeditem());
		manageSubs.getManageSubscriptionLblsubscribeditem().verifyPresent();

	}

	@QAFTestStep(description = "I Verify that customer has option to select from any previously addresses")
	public void iVerifyCustomerhasOptionToSelectPreviouslyAddresses() {
		CDPTestPage cdp = new CDPTestPage();
		PDPTestPage pdp = new PDPTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		CartTestPage cartpage = new CartTestPage();
		ShippingTestPage ship = new ShippingTestPage();
		PaymentTestPage payment = new PaymentTestPage();
		HomePage home = new HomePage();
		ConfirmationTestPage confirmationPage = new ConfirmationTestPage();
		MyAccountPage myAccountPage = new MyAccountPage();
		ManageSubscriptionTestPage manageSubs = new ManageSubscriptionTestPage();

		PerfectoUtils.scrolltoelement(cdp.getProductTitle2Subscription());
		cdp.getProductTitle2Subscription().click();
		pdp.getRgbSubscription().click();
		pdp.getPdpBtnAddtocart().click();

		// PerfectoUtils.scrolltoelement(instorehome.getHomeBtnCart());
		instorehome.getHomeBtnCart().waitForPresent(5000);
		// PerfectoUtils.mousehoverusingActions(instorehome.getHomeBtnCart());
		PerfectoUtils.mouseoverandclick(instorehome.getHomeBtnCart(), instorehome.getHomeBtnCartviewcart());
		// instorehome.getHomeBtnCartviewcart().click();
		cartpage.getCartLblHeader().waitForPresent(5000);

		// PerfectoUtils.scrolltoelement(cartpage.getCartBtnCheckout());
		cartpage.getCartBtnCheckout().waitForPresent(3000);
		cartpage.getCartBtnCheckout().verifyPresent();
		cartpage.getCartBtnCheckout().click();

		ship.getShippingtabDDShipTo().waitForPresent(5000);
		PerfectoUtils.dropdownSelectByValue(ship.getShippingtabDDShipTo(),
				ConfigurationManager.getBundle().getString("myAccount.addressbook.address2nickname"));
		// Select select = new Select(ship.getShippingtabDDShipTo());
		// select.selectByVisibleText(
		// ConfigurationManager.getBundle().getString("myAccount.addressbook.address2nickname"));
		ship.waitForAjaxToComplete();
		String addressToSplit = ship.getShippingtabLblShippingToAddressNickName().getText();
		String[] addressSplited = addressToSplit.split(":");
		String finaladdress = addressSplited[1].trim();
		if (finaladdress.equals(ConfigurationManager.getBundle().getString("myAccount.addressbook.address2nickname"))) {
			PerfectoUtils.reportMessage("The Customer able to change the Address successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("The Customer is not able to change the Address", MessageTypes.Fail);
		}

		ship.getShippingtabBtnContinueexistingaddress().click();
		PerfectoUtils.scrolltoelement(payment.getPaymentTxtCardcvc());
		payment.getPaymentTxtCardcvc().sendKeys(getBundle().getString("payment.card.cvc"));
		PerfectoUtils.scrolltoelement(payment.getPaymentBtnSubmitorder());
		payment.getPaymentBtnSubmitorder().click();
		PerfectoUtils.scrolltoelement(confirmationPage.getConfirmBtnContinueshopping());
		confirmationPage.getConfirmBtnContinueshopping().click();
		home.iClickOnExploreMyStoreHeroImage();
		navigateToMyAccountPage();
		myAccountPage.getMyAccountLnkLeftmanagesubscriptions().click();
		PerfectoUtils.scrolltoelement(manageSubs.getManageSubscriptionLblsubscribeditem());
		manageSubs.getManageSubscriptionLblsubscribeditem().verifyPresent();
	}

	@QAFTestStep(description = "I Enter new Shipping Address")
	public void iEnternewShippingAddress() {
		ShippingTestPage ship = new ShippingTestPage();
		PerfectoUtils.scrolltoelement(ship.getShippingtabRbtnNewShippingAddress());
		ship.getShippingtabRbtnNewShippingAddress().click();
		ship.getShippingtabTxtNickname()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.AddressNickname"));
		ship.getShippingtabTxtFirstname()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.FirstName"));
		ship.getShippingtabTxtLastname()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.LastName"));
		ship.getShippingtabTxtPhonenumber1()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.phonenumberone"));
		ship.getShippingtabTxtPhonenumber2()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.phonenumbertwo"));
		ship.getShippingtabTxtPhonenumber3()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.phonenumberthree"));
		ship.getShippingtabTxtStreetaddress1()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.street"));
		ship.getShippingtabTxtCity().sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.city"));
		ship.getShippingtabTxtZipcode1()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.zipcode"));
		ship.getShippingtabTxtZipcode2().click();
		ship.waitForAjaxToComplete();
		ship.getShippingtabBtnSave().verifyPresent();
		ship.getShippingtabBtnSave().click();
		PerfectoUtils.reportMessage("Clicked Save button...");

		Select select = new Select(ship.getShippingtabDDShipTo());
		WebElement option = select.getFirstSelectedOption();
		if (option.getText().equals(ConfigurationManager.getBundle().getString("shippingaddress1.AddressNickname"))) {
			PerfectoUtils.reportMessage(
					"New Address has been updated successfully in the Ship To dropdown and got selected",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("New Address has not selected in the Ship To dropdown", MessageTypes.Fail);
		}

		if (ship.getShippingtabLblShippingToAddressNickName().getText()
				.equals(ConfigurationManager.getBundle().getString("shippingaddress1.AddressNickname"))) {
			PerfectoUtils.reportMessage("New Address has been updated successfully in the Shipping To Label",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("New Address is not updated in the Shipping To Label", MessageTypes.Fail);
		}

		ship.getShippingtabBtnContinueexistingaddress().click();

	}

	@QAFTestStep(description = "I Enter Credit Card details")
	public void iEnterCreditCardDetails() {
		PaymentTestPage payment = new PaymentTestPage();
		CartAndCheckout cartandcheckout = new CartAndCheckout();
		ConfirmationTestPage confirmationPage = new ConfirmationTestPage();

		PerfectoUtils.reportMessage("Navigated to Payment section.", MessageTypes.Pass);

		// 1. Entering the credit card details
		PerfectoUtils.scrolltoelement(payment.getPaymentLblEnteracreditcard());
		cartandcheckout.enterCreditCardDetailsInpayment();
		if (payment.getPaymentChkSavecreditcard().isEnabled()) {
			PerfectoUtils.reportMessage("Save credit card option is enabled", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("Save credit card option is not enabled.", MessageTypes.Pass);
		}
		PerfectoUtils.scrolltoelement(payment.getPaymentChkSameAsShippingAddress());
		payment.getPaymentChkSameAsShippingAddress().click();
		PerfectoUtils.scrolltoelement(payment.getPaymentBtnSubmitorder());
		payment.getPaymentBtnSubmitorder().click();
		PerfectoUtils.scrolltoelement(confirmationPage.getConfirmBtnContinueshopping());
		confirmationPage.getConfirmBtnContinueshopping().click();
	}

	@QAFTestStep(description = "I Verify that address information is stored to address book in Customer Profile")
	public void iVerifyAddressinCustomerProfile() {
		AddressBookTestPage addressBook = new AddressBookTestPage();
		clickAddressBookLink();
		String address = addressBook.getAddressbookLbldefaultshippingaddressname().getText();
		if (address.equals(ConfigurationManager.getBundle().getString("shippingaddress1.AddressNickname")))
			PerfectoUtils.reportMessage("Address information is stored to address book in Customer Profile",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Address information is not stored to address book in Customer Profile",
					MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify that option to add a new address is available")
	public void iVerifyOptiontoAddNewAddressIsAvailable() {
		AddressBookTestPage addressBook = new AddressBookTestPage();
		MyAccountPage myAccountPage = new MyAccountPage();
		ManageSubscriptionTestPage manageSubs = new ManageSubscriptionTestPage();

		myAccountPage.getMyAccountLnkLeftmanagesubscriptions().click();

		manageSubs.getManageSubscriptionLnkeditshipaddress().verifyPresent();
		manageSubs.getManageSubscriptionLnkeditshipaddress().click();
		manageSubs.getManageSubscriptionLnkAddressbook().click();

		String pageTitle = addressBook.getAddressbookLblAddnewaddress().getText();

		if (pageTitle.equals("Add a New Shipping Address"))
			PerfectoUtils.reportMessage("Add a New Shipping Address section is Displayed....", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Add a New Shipping Address section is not Displayed....", MessageTypes.Fail);

		addressBook.getAddressbookTxtNickname()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address2.nickname"));
		addressBook.getAddressbookTxtFirstname()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address2.fname"));
		addressBook.getAddressbookTxtLastname()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address2.lname"));
		addressBook.getAddressbookTxtPhno1()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.ph1"));
		addressBook.getAddressbookTxtPhno2()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.ph2"));
		addressBook.getAddressbookTxtPhno3()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.ph3"));
		addressBook.getAddressbookTxtStreetaddress()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.street"));
		addressBook.getAddressbookLblCity()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.city"));
		addressBook.getAddressbookLblZipCodeBox1()
				.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.zipcode"));
		addressBook.getAddressbookLblZipCodeBox2().click();
		try {
			addressBook.waitForAjaxToComplete();
		} catch (Exception e) {
			addressBook.getAddressbookLblZipCodeBox2()
					.sendKeys(ConfigurationManager.getBundle().getString("myAccount.addressbook.address1.zipcode2"));
		}
		addressBook.getAddressbookBtnSave().verifyPresent();
		addressBook.getAddressbookBtnSave().click();
		PerfectoUtils.reportMessage("Clicked Save button...");

		int initialAddressCount = addressBook.getAddressbookListAddressCount().size();

		if (addressBook.getAddressbookLblRecentAddressNickname().getText()
				.equals(ConfigurationManager.getBundle().getString("myAccount.addressbook.address2.nickname"))) {
			PerfectoUtils.reportMessage("Address saved successfullly...", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Address not saved successfullly...", MessageTypes.Fail);
		}

		myAccountPage.getMyAccountLnkLeftmanagesubscriptions().click();

		manageSubs.getManageSubscriptionLnkeditshipaddress().click();

		if (manageSubs.getManageSubscriptionLblnewaddressupdate().getText()
				.equals(ConfigurationManager.getBundle().getString("myAccount.addressbook.address2.fullname"))) {
			PerfectoUtils.reportMessage("Address updated successfullly in Change Address Manage Subscription...",
					MessageTypes.Pass);
			manageSubs.getManageSubscriptionRadionewaddressupdate().click();
			manageSubs.getManageSubscriptionLnkSave().click();
			String shippingAddressName = manageSubs.getManageSubscriptionLblshippingaddressname().getText();
			if (shippingAddressName
					.contains(ConfigurationManager.getBundle().getString("myAccount.addressbook.address2.fname"))
					&& shippingAddressName.contains(
							ConfigurationManager.getBundle().getString("myAccount.addressbook.address2.lname")))
				PerfectoUtils.reportMessage("Address updated successfullly in Manage Subscription...",
						MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Address not updated in Manage Subscription...", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("Address not updated in Change Address Manage Subscription...",
					MessageTypes.Fail);
		}

		myAccountPage.getMyAccountLnkLeftaddressbook().click();
		manageSubs.getManageSubscriptionLblCannotRemove().verifyPresent();

		myAccountPage.getMyAccountLnkLeftmanagesubscriptions().click();

		manageSubs.getManageSubscriptionLnkeditshipaddress().click();

		manageSubs.getManageSubscriptionRadiodefaultaddress().click();
		manageSubs.getManageSubscriptionLnkSave().click();
		myAccountPage.getMyAccountLnkLeftaddressbook().click();
		manageSubs.getManageSubscriptionLnkremoveaddedaddress().click();
		manageSubs.getManageSubscriptionLnkyesremoveaddedaddress().waitForVisible(50000);
		manageSubs.getManageSubscriptionLnkyesremoveaddedaddress().click();

		int finalAddressCount = addressBook.getAddressbookListAddressCount().size();

		if (finalAddressCount < initialAddressCount)
			PerfectoUtils.reportMessage("Address deleted successfullly", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Address not deleted", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I Verify that option to add a new card is available")
	public void iVerifyOptionAddNewcardisAvailable() {
		MyAccountPage myAccountPage = new MyAccountPage();
		ManageCreditCardsTestPage manageCreditCard = new ManageCreditCardsTestPage();
		ManageSubscriptionTestPage manageSubs = new ManageSubscriptionTestPage();
		myAccountPage.getMyAccountLnkLeftmanagesubscriptions().click();
		manageSubs.getManageSubscriptionLnkeditpaymentinfo().click();
		manageSubs.getManageSubscriptionLnkmanagecreditcard().waitForVisible(50000);
		manageSubs.getManageSubscriptionLnkmanagecreditcard().click();
		manageSubs.getManageSubscriptionLnkAddnewcreditcard().verifyPresent();
		manageSubs.getManageSubscriptionLnkAddnewcreditcard().click();

		manageCreditCard.getManageccLblAddnewcreditordebitcardheader().verifyPresent();

		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtNameoncard(),
				ConfigurationManager.getBundle().getString("myAccount.creditcards.visa.nameoncard"));
		manageCreditCard.getManageCCDropCardtype().click();
		Select sel = new Select(manageCreditCard.getManageCCDropCardtype());
		sel.selectByValue(ConfigurationManager.getBundle().getString("myAccount.creditcards.visa.name"));

		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtCardnumber(),
				ConfigurationManager.getBundle().getString("myAccount.creditcards.visa.cardnumber"));

		manageCreditCard.getManageCCDropExpmonth().click();
		Select sel1 = new Select(manageCreditCard.getManageCCDropExpmonth());
		sel1.selectByValue(ConfigurationManager.getBundle().getString("myAccount.creditcards.visa.expmonth"));
		// manageCreditCard.getManageCCDropExpyear().click();
		Select sel2 = new Select(manageCreditCard.getManageCCDropExpyear());
		sel2.selectByValue(ConfigurationManager.getBundle().getString("myAccount.creditcards.visa.expyear"));

		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtCvc(),
				ConfigurationManager.getBundle().getString("myAccount.creditcards.visa.cvc"));

		PerfectoUtils.scrolltoelement(manageCreditCard.getManageCCTxtBillfname());
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtBillfname(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.fname"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtBilllname(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.lname"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtPhoneNumber1(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.ph1"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtPhoneNumber2(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.ph2"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtPhoneNumber3(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.ph3"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtBillAddr1(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.street"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtBillcity(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.city"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtBillzipcode(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.zipcode"));

		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtBillemail(),
				ConfigurationManager.getBundle().getString("myEmail"));
		CommonStepDef.entervalueintothetextbox(manageCreditCard.getManageCCTxtBillconfirmemail(),
				ConfigurationManager.getBundle().getString("myEmail"));

		manageCreditCard.getManageCCBtnAddcreditcardsubmit().verifyPresent();
		manageCreditCard.getManageCCBtnAddcreditcardsubmit().click();
		PerfectoUtils.reportMessage("Clicked add credit card button after entereing all details..");

		myAccountPage.getMyAccountLnkLeftmanagesubscriptions().click();
		manageSubs.getManageSubscriptionLnkeditpaymentinfo().click();
		manageSubs.getManageSubscriptionLblAddedvisacreditcard().waitForVisible(50000);
		manageSubs.getManageSubscriptionLblAddedvisacreditcard().verifyPresent();
		manageSubs.getManageSubscriptionRadioNewcreditupdate().click();
		manageSubs.getManageSubscriptionLnksavecredit().click();
		manageSubs.getManageSubscriptionLblnewcreditupdate().verifyPresent();
		myAccountPage.getMyAccountLnkLeftmanagecreditcards().click();
		manageSubs.getManageSubscriptionLnkcannotdeletesubscriptioncard().verifyPresent();

		myAccountPage.getMyAccountLnkLeftmanagesubscriptions().click();
		manageSubs.getManageSubscriptionLnkeditpaymentinfo().click();
		manageSubs.getManageSubscriptionLnkmanagecreditcard().waitForVisible(50000);
		manageSubs.getManageSubscriptionRadiodefaultcreditupdate().click();
		manageSubs.getManageSubscriptionLnksavecredit().click();
		myAccountPage.getMyAccountLnkLeftmanagecreditcards().click();
		manageSubs.getManageSubscriptionLnkdeletecard().click();
		manageSubs.getManageSubscriptionLnkyesdeletecard().waitForVisible(50000);
		manageSubs.getManageSubscriptionLnkyesdeletecard().click();
	}

	@QAFTestStep(description = "Verify that customer has option to select from any previously saved cards")
	public void iVerifyCustomerhasOptionToSelectPreviouslySavedCards() {
		CDPTestPage cdp = new CDPTestPage();
		PDPTestPage pdp = new PDPTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		CartTestPage cartpage = new CartTestPage();
		ShippingTestPage ship = new ShippingTestPage();
		PaymentTestPage payment = new PaymentTestPage();
		HomePage home = new HomePage();
		ConfirmationTestPage confirmationPage = new ConfirmationTestPage();
		MyAccountPage myAccountPage = new MyAccountPage();
		ManageSubscriptionTestPage manageSubs = new ManageSubscriptionTestPage();
		PerfectoUtils.scrolltoelement(cdp.getProductTitle2Subscription());
		cdp.getProductTitle2Subscription().click();
		pdp.getRgbSubscription().click();
		pdp.getPdpBtnAddtocart().click();

		PerfectoUtils.scrolltoelement(instorehome.getHomeBtnCart());
		PerfectoUtils.mousehoverusingActions(instorehome.getHomeBtnCart());
		instorehome.getHomeBtnCartviewcart().click();
		cartpage.getCartLblHeader().waitForPresent(5000);

		PerfectoUtils.scrolltoelement(cartpage.getCartBtnCheckout());
		cartpage.getCartBtnCheckout().waitForPresent(3000);
		cartpage.getCartBtnCheckout().verifyPresent();
		cartpage.getCartBtnCheckout().click();

		ship.getShippingtabBtnContinueexistingaddress().waitForPresent(5000);
		ship.getShippingtabBtnContinueexistingaddress().click();
		PerfectoUtils.scrolltoelement(payment.getPaymentTxtCardcvc());
		payment.getPaymentTxtCardcvc().sendKeys(getBundle().getString("payment.card.cvc"));
		PerfectoUtils.scrolltoelement(payment.getPaymentBtnSubmitorder());
		payment.getPaymentBtnSubmitorder().click();
		PerfectoUtils.scrolltoelement(confirmationPage.getConfirmBtnContinueshopping());
		confirmationPage.getConfirmBtnContinueshopping().click();
		home.iClickOnExploreMyStoreHeroImage();
		navigateToMyAccountPage();
		myAccountPage.getMyAccountLnkLeftmanagesubscriptions().click();
		PerfectoUtils.scrolltoelement(manageSubs.getManageSubscriptionLblsubscribeditem());
		manageSubs.getManageSubscriptionLblsubscribeditem().verifyPresent();
	}

	@QAFTestStep(description = "Verify check box for save credit card information is visible and checked and not editable")
	public void verifyCheckboxforSaveCreditCardInformationisvisibleandcheckedandnoteditable() {
		MyAccountPage myAccountPage = new MyAccountPage();
		ManageSubscriptionTestPage manageSubs = new ManageSubscriptionTestPage();
		CDPTestPage cdp = new CDPTestPage();
		PDPTestPage pdp = new PDPTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		CartTestPage cartpage = new CartTestPage();
		ShippingTestPage ship = new ShippingTestPage();
		PerfectoUtils.scrolltoelement(cdp.getProductTitle2Subscription());
		cdp.getProductTitle2Subscription().click();
		pdp.getRgbSubscription().click();
		pdp.getPdpBtnAddtocart().click();

		PerfectoUtils.scrolltoelement(instorehome.getHomeBtnCart());
		PerfectoUtils.mousehoverusingActions(instorehome.getHomeBtnCart());
		instorehome.getHomeBtnCartviewcart().click();
		cartpage.getCartLblHeader().waitForPresent(5000);

		PerfectoUtils.scrolltoelement(cartpage.getCartBtnCheckout());
		cartpage.getCartBtnCheckout().waitForPresent(3000);
		cartpage.getCartBtnCheckout().verifyPresent();
		cartpage.getCartBtnCheckout().click();

		HomePage home = new HomePage();
		PerfectoUtils.scrolltoelement(ship.getShippingtabRbtnNewShippingAddress());
		ship.getShippingtabRbtnNewShippingAddress().click();
		ship.getShippingtabTxtNickname()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.AddressNickname"));
		ship.getShippingtabTxtFirstname()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.FirstName"));
		ship.getShippingtabTxtLastname()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.LastName"));
		ship.getShippingtabTxtPhonenumber1()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.phonenumberone"));
		ship.getShippingtabTxtPhonenumber2()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.phonenumbertwo"));
		ship.getShippingtabTxtPhonenumber3()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.phonenumberthree"));
		ship.getShippingtabTxtStreetaddress1()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.street"));
		ship.getShippingtabTxtCity().sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.city"));
		ship.getShippingtabTxtZipcode1()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.zipcode"));
		ship.getShippingtabTxtZipcode2().click();
		ship.waitForAjaxToComplete();
		ship.getShippingtabBtnSave().verifyPresent();
		ship.getShippingtabBtnSave().click();
		PerfectoUtils.reportMessage("Clicked Save button...");

		ship.getShippingtabBtnContinueexistingaddress().click();

		PaymentTestPage payment = new PaymentTestPage();
		CartAndCheckout cartandcheckout = new CartAndCheckout();
		ConfirmationTestPage confirmationPage = new ConfirmationTestPage();

		PerfectoUtils.reportMessage("Navigated to Payment section.", MessageTypes.Pass);

		// 1. Entering the credit card details
		PerfectoUtils.scrolltoelement(payment.getPaymentLblEnteracreditcard());
		cartandcheckout.enterCreditCardDetailsInpayment();
		if (payment.getPaymentChkSavecreditcard().verifyVisible()) {
			PerfectoUtils.reportMessage("Save credit card option is visible", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Save credit card option is not visible.", MessageTypes.Fail);
		}
		if (payment.getPaymentChkSavecreditcard().getAttribute("checked").equals("true")) {
			PerfectoUtils.reportMessage("Save credit card option is checked", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Save credit card option is not checked.", MessageTypes.Fail);
		}
		if (payment.getPaymentChkSavecreditcard().getAttribute("disabled").equals("true")) {
			PerfectoUtils.reportMessage("Save credit card option is disabled", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Save credit card option is not disabled.", MessageTypes.Fail);
		}
		PerfectoUtils.scrolltoelement(payment.getPaymentChkSameAsShippingAddress());
		payment.getPaymentChkSameAsShippingAddress().click();
		PerfectoUtils.scrolltoelement(payment.getPaymentBtnSubmitorder());
		payment.getPaymentBtnSubmitorder().click();
		PerfectoUtils.scrolltoelement(confirmationPage.getConfirmBtnContinueshopping());
		confirmationPage.getConfirmBtnContinueshopping().click();

		home.iClickOnExploreMyStoreHeroImage();
		navigateToMyAccountPage();
		myAccountPage.getMyAccountLnkLeftmanagesubscriptions().click();
		PerfectoUtils.scrolltoelement(manageSubs.getManageSubscriptionLblsubscribeditem());
		manageSubs.getManageSubscriptionLblsubscribeditem().verifyPresent();

	}

	@QAFTestStep(description = "Verify the used credit card is saved as the subscription credit card for future fulfillments")
	public void verifyUsedCreditCardSavedassubscriptioncreditcardforfuturefulfillments() {
		MyAccountPage myAccountPage = new MyAccountPage();
		ManageSubscriptionTestPage manageSubs = new ManageSubscriptionTestPage();
		ManageCreditCardsTestPage managecredit = new ManageCreditCardsTestPage();
		CDPTestPage cdp = new CDPTestPage();
		PDPTestPage pdp = new PDPTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		CartTestPage cartpage = new CartTestPage();
		ShippingTestPage ship = new ShippingTestPage();
		PerfectoUtils.scrolltoelement(cdp.getProductTitle2Subscription());
		cdp.getProductTitle2Subscription().click();
		pdp.getRgbSubscription().click();
		pdp.getPdpBtnAddtocart().click();

		PerfectoUtils.scrolltoelement(instorehome.getHomeBtnCart());
		PerfectoUtils.mousehoverusingActions(instorehome.getHomeBtnCart());
		instorehome.getHomeBtnCartviewcart().click();
		cartpage.getCartLblHeader().waitForPresent(5000);

		PerfectoUtils.scrolltoelement(cartpage.getCartBtnCheckout());
		cartpage.getCartBtnCheckout().waitForPresent(3000);
		cartpage.getCartBtnCheckout().verifyPresent();
		cartpage.getCartBtnCheckout().click();

		HomePage home = new HomePage();
		PerfectoUtils.scrolltoelement(ship.getShippingtabRbtnNewShippingAddress());
		ship.getShippingtabRbtnNewShippingAddress().click();
		ship.getShippingtabTxtNickname()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.AddressNickname"));
		ship.getShippingtabTxtFirstname()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.FirstName"));
		ship.getShippingtabTxtLastname()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.LastName"));
		ship.getShippingtabTxtPhonenumber1()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.phonenumberone"));
		ship.getShippingtabTxtPhonenumber2()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.phonenumbertwo"));
		ship.getShippingtabTxtPhonenumber3()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.phonenumberthree"));
		ship.getShippingtabTxtStreetaddress1()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.street"));
		ship.getShippingtabTxtCity().sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.city"));
		ship.getShippingtabTxtZipcode1()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.zipcode"));
		ship.getShippingtabTxtZipcode2().click();
		ship.waitForAjaxToComplete();
		ship.getShippingtabBtnSave().verifyPresent();
		ship.getShippingtabBtnSave().click();
		PerfectoUtils.reportMessage("Clicked Save button...");

		ship.getShippingtabBtnContinueexistingaddress().click();
		iEnterCreditCardDetails();

		home.iClickOnExploreMyStoreHeroImage();
		navigateToMyAccountPage();
		myAccountPage.getMyAccountLnkLeftmanagecreditcards().click();
		managecredit.getManageCCLblDefaultCard().verifyPresent();
	}

	@QAFTestStep(description = "Verify that customer moves to billing information section of screen")
	public void verifyCustomermovestobillinginformationsectionofscreen() {
		MyAccountPage myAccountPage = new MyAccountPage();
		ManageSubscriptionTestPage manageSubs = new ManageSubscriptionTestPage();
		ManageCreditCardsTestPage managecredit = new ManageCreditCardsTestPage();
		CDPTestPage cdp = new CDPTestPage();
		PDPTestPage pdp = new PDPTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		CartTestPage cartpage = new CartTestPage();
		ShippingTestPage ship = new ShippingTestPage();
		PerfectoUtils.scrolltoelement(cdp.getProductTitle2Subscription());
		cdp.getProductTitle2Subscription().click();
		pdp.getRgbSubscription().click();
		pdp.getPdpBtnAddtocart().click();

		PerfectoUtils.scrolltoelement(instorehome.getHomeBtnCart());
		PerfectoUtils.mousehoverusingActions(instorehome.getHomeBtnCart());
		instorehome.getHomeBtnCartviewcart().click();
		cartpage.getCartLblHeader().waitForPresent(5000);

		PerfectoUtils.scrolltoelement(cartpage.getCartBtnCheckout());
		cartpage.getCartBtnCheckout().waitForPresent(3000);
		cartpage.getCartBtnCheckout().verifyPresent();
		cartpage.getCartBtnCheckout().click();

		HomePage home = new HomePage();
		PerfectoUtils.scrolltoelement(ship.getShippingtabRbtnNewShippingAddress());
		ship.getShippingtabRbtnNewShippingAddress().click();
		ship.getShippingtabTxtNickname()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.AddressNickname"));
		ship.getShippingtabTxtFirstname()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.FirstName"));
		ship.getShippingtabTxtLastname()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.LastName"));
		ship.getShippingtabTxtPhonenumber1()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.phonenumberone"));
		ship.getShippingtabTxtPhonenumber2()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.phonenumbertwo"));
		ship.getShippingtabTxtPhonenumber3()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.phonenumberthree"));
		ship.getShippingtabTxtStreetaddress1()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.street"));
		ship.getShippingtabTxtCity().sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.city"));
		ship.getShippingtabTxtZipcode1()
				.sendKeys(ConfigurationManager.getBundle().getString("shippingaddress1.zipcode"));
		ship.getShippingtabTxtZipcode2().click();
		ship.waitForAjaxToComplete();
		ship.getShippingtabBtnSave().verifyPresent();
		ship.getShippingtabBtnSave().click();
		PerfectoUtils.reportMessage("Clicked Save button...");

		ship.getShippingtabBtnContinueexistingaddress().click();
		PaymentTestPage payment = new PaymentTestPage();
		CartAndCheckout cartandcheckout = new CartAndCheckout();
		ConfirmationTestPage confirmationPage = new ConfirmationTestPage();

		PerfectoUtils.reportMessage("Navigated to Payment section.", MessageTypes.Pass);

		// 1. Entering the credit card details
		PerfectoUtils.scrolltoelement(payment.getPaymentLblEnteracreditcard());
		cartandcheckout.enterCreditCardDetailsInpayment();
		PerfectoUtils.scrolltoelement(managecredit.getManageCCTxtBillfname());
		CommonStepDef.entervalueintothetextbox(managecredit.getManageCCTxtBillfname(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.fname"));
		CommonStepDef.entervalueintothetextbox(managecredit.getManageCCTxtBilllname(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.lname"));
		CommonStepDef.entervalueintothetextbox(managecredit.getManageCCTxtPhoneNumber1(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.ph1"));
		CommonStepDef.entervalueintothetextbox(managecredit.getManageCCTxtPhoneNumber2(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.ph2"));
		CommonStepDef.entervalueintothetextbox(managecredit.getManageCCTxtPhoneNumber3(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.ph3"));
		CommonStepDef.entervalueintothetextbox(managecredit.getManageCCTxtBillAddr1(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.street"));
		CommonStepDef.entervalueintothetextbox(managecredit.getManageCCTxtBillcity(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.city"));
		CommonStepDef.entervalueintothetextbox(managecredit.getManageCCTxtBillzipcode(),
				ConfigurationManager.getBundle().getString("myAccount.billing.address1.zipcode"));

		CommonStepDef.entervalueintothetextbox(managecredit.getManageCCTxtBillemail(),
				ConfigurationManager.getBundle().getString("myEmail"));
		CommonStepDef.entervalueintothetextbox(managecredit.getManageCCTxtBillconfirmemail(),
				ConfigurationManager.getBundle().getString("myEmail"));

		PerfectoUtils.scrolltoelement(payment.getPaymentBtnSubmitorder());
		payment.getPaymentBtnSubmitorder().click();
		PerfectoUtils.scrolltoelement(confirmationPage.getConfirmBtnContinueshopping());
		confirmationPage.getConfirmBtnContinueshopping().click();
		home.iClickOnExploreMyStoreHeroImage();
		navigateToMyAccountPage();
		myAccountPage.getMyAccountLnkLeftmanagecreditcards().click();
		managecredit.getManageCCLblDefaultCard().verifyPresent();
		String billingName = managecredit.getManageCCLblAddedbillname().getText();
		if (billingName.equals(ConfigurationManager.getBundle().getString("myAccount.billing.address1.fullname"))) {
			PerfectoUtils.reportMessage(
					"Billing information is reflected in Manage Credit card page for the credit card",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Billing information is not reflected in Manage Credit card page for the credit card",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Register account for {0} times")
	public void registerAccountForTimes(int count) {
		HomePage home = new HomePage();
		Registration registration = new Registration();

		for (int i = 0; i < count; i++) {
			home.iAmOnHomePage();
			home.iNavigateToInstoreHomePage();
			registration.iNavigateToRegisterPageByClickingRegisterButton();
			registration.iRegisterANewAccount();
			registration.iClickGotItThanksButtonInThankYouPage();
		}
	}

	@QAFTestStep(description = "I logout from .com application in mobile")
	public void iLogoutFromCOMApplicationInMobile() {
		InStoreHomePage inStoredoor = new InStoreHomePage();

		inStoredoor.getHomeLnkHumburgermobile().click();
		inStoredoor.getHomeBtnLogoutmobile().waitForPresent(5000);
		inStoredoor.getHomeBtnLogoutmobile().click();
	}

	@QAFTestStep(description = "Click on Save by updating mobile number and get offers by text checkbox")
	public void clickOnSaveByUpdatingMobileNumberAndGetOffersByTextCheckbox() {
		MyaccountDigitalcouponsTestPage myacc = new MyaccountDigitalcouponsTestPage();

		myacc.getMyacccoupLblHeader().verifyPresent();
		myacc.getMyacccoupChkGetoffersbytext().verifyPresent();
		myacc.getMyacccoupChkGetoffersbytext().click();
		myacc.getMyacccoupEdtMobileno1().sendKeys(getBundle().getString("myAccount.digcoup.mobileno1"));
		myacc.getMyacccoupEdtMobileno2().sendKeys(getBundle().getString("myAccount.digcoup.mobileno2"));
		myacc.getMyacccoupEdtMobileno3().sendKeys(getBundle().getString("myAccount.digcoup.mobileno3"));
		myacc.getMyacccoupBtnSave().verifyPresent();
		myacc.getMyacccoupBtnSave().click();
	}

	@QAFTestStep(description = "Validate mobile number and get offers are updated by navigating again to Digital Coupons page")
	public void validateMobileNumberAndGetOffersAreUpdatedByNavigatingAgainToDigitalCouponsPage() {
		MyaccountDigitalcouponsTestPage myacc = new MyaccountDigitalcouponsTestPage();

		clickUserNameLink();
		iSeeMyAccountPage();
		clickDigitalCouponsLink();
		myacc.getMyacccoupLblHeader().verifyPresent();
		String mobileNo1 = myacc.getMyacccoupEdtMobileno1().getAttribute("value");
		String mobileNo2 = myacc.getMyacccoupEdtMobileno2().getAttribute("value");
		String mobileNo3 = myacc.getMyacccoupEdtMobileno3().getAttribute("value");

		if (mobileNo1.equalsIgnoreCase(getBundle().getString("myAccount.digcoup.mobileno1"))
				&& mobileNo2.equalsIgnoreCase(getBundle().getString("myAccount.digcoup.mobileno2"))
				&& mobileNo3.equalsIgnoreCase(getBundle().getString("myAccount.digcoup.mobileno3"))) {
			PerfectoUtils.reportMessage("Mobile number are updated in Digital Coupons page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Mobile number are not updated in Digital Coupons page", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify shipping address nick name has {0} characters utmost")
	public synchronized void iVerifyShippingAddressNickNameHasCharactersUtmost(int max_char) {
		myAccountLandingTestPage myacc = new myAccountLandingTestPage();

		myacc.waitForPageToLoad();
		PerfectoUtils.scrolltoelement(myacc.getMyacclandingLnkAddressbook());

		myacc.getMyacclandingLblAddressnickname1().verifyPresent();
		String nickName = myacc.getMyacclandingLblAddressnickname1().getText();

		if (nickName.length() == max_char) {
			PerfectoUtils.reportMessage(max_char + "Characters are displayed", MessageTypes.Pass);
		} else if (nickName.length() < max_char) {
			PerfectoUtils.reportMessage("Less than" + max_char + "Characters are displayed", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("More than" + max_char + "Characters are displayed", MessageTypes.Fail);
		}

	}
	
	@QAFTestStep(description = "Verify credit cards information saved in Manage Credit Cards page")
	public void verifyTheCreditCardinformationsavedInManageCreditCardsPage() {
		ManageCreditCardsTestPage managecards = new ManageCreditCardsTestPage();

		int cardSize = managecards.getManageccLiLblCreditcarddeletelist().size();

		if (cardSize > 0) {
			PerfectoUtils.scrolltoelement(managecards.getManageccLblMycreditcards());
			PerfectoUtils.reportMessage(cardSize + " saved credit cards found", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("No credit cards found. adding a new credit card..", MessageTypes.Pass);

		}
	}
	
	@QAFTestStep(description = "I verify user can quick reorder and place the order")
	public synchronized void iVerifyUserQuickReorderandplaceorder() throws InterruptedException {
		QuickReorderTestPage quickreorder = new QuickReorderTestPage();
		PaymentGatewayStepdef pay = new PaymentGatewayStepdef();
		
		iVerifyUserQuickReorder();
		quickreorder.getLblAddtocart().click();
		pay.iPurchasedTheProduct();
		
		}
	
	@QAFTestStep(description = "I verify user can quick reorder by selecting the store")
	public synchronized void iVerifyUserQuickReorderbySelectingstore() throws InterruptedException {
		QuickReorderTestPage quickreorder = new QuickReorderTestPage();
		CartAndCheckout cart = new CartAndCheckout();
		HomePage home = new HomePage();
		
		iVerifyUserQuickReorder();
		quickreorder.getLblAddtocart().click();
		home.iSelectAStoreFromSelectAPickupStorePage("");
		cart.iVerifyiteminthecartflyout();
		
		}
	
	@QAFTestStep(description = "I validate the Password Reset Page properties")
	public void iValidateThePasswordResetPageProperties() {
		LoginTestPage loginpage = new LoginTestPage();

		loginpage.getLoginLblPwdresetheader().verifyPresent();
		loginpage.getLoginEdtEmailpwdReset().verifyPresent();
		loginpage.getLoginBtnSendEmail().verifyPresent();
		loginpage.getLoginLnkViewPrivacyPolicy().verifyPresent();
		loginpage.getLoginLnkViewTermsConditions().verifyPresent();
	}
	
	@QAFTestStep(description = "I update quantity {0} for a subscribable product and verify price is updated")
	public static void iChangeQuantityforsubscribableproduct(String quantity) {
		ManageSubscriptionTestPage manageSubscriptionsPage = new ManageSubscriptionTestPage();
		
		int itemTotalBeforeUpdate = Integer.parseInt(manageSubscriptionsPage.getManageSubscriptionLblItemtotal().getText());
		manageSubscriptionsPage.getManageSubscriptionTxtQuantity().sendKeys(quantity);
		manageSubscriptionsPage.getManageSubscriptionLnkUpdate().click();
		int itemTotalAfterUpdate = Integer.parseInt(manageSubscriptionsPage.getManageSubscriptionLblItemtotal().getText());
		if(itemTotalBeforeUpdate==(itemTotalAfterUpdate/2)){
			PerfectoUtils.reportMessage("Item Total got updated", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Item Total is not updated", MessageTypes.Fail);
		}
	}
	
}
