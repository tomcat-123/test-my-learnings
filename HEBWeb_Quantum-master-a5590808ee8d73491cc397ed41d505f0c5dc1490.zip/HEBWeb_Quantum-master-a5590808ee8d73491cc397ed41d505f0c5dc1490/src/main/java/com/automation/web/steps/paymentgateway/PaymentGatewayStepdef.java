package com.automation.web.steps.paymentgateway;

import static com.automation.web.commonutils.PerfectoUtils.navigateToPage;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.components.GiftCardComponents;
import com.automation.web.pages.cart.CartTestPage;
import com.automation.web.pages.checkout.ConfirmationTestPage;
import com.automation.web.pages.checkout.PaymentTestPage;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.myAccount.ManageCreditCardsTestPage;
import com.automation.web.pages.myAccount.myAccountLandingTestPage;
import com.automation.web.pages.paymentgateway.CheckbalanceTestPage;
import com.automation.web.pages.paymentgateway.GiftcardslandingTestPage;
import com.automation.web.pages.paymentgateway.SendegiftcardsTestPage;
import com.automation.web.pages.paymentgateway.ShopgiftcardsTestPage;
import com.automation.web.steps.cartAndCheckout.CartAndCheckout;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of steps in PaymentGatewayStepdef

* Navigate to Gift cards page
* Verify the properties of Gift cards page
* Navigate to Shop gift cards page
* Verify the properties of Shop gift cards page
* Navigate to Send an eGift card page
* Verify the properties of Send an eGift card page
* Navigate to Check balance page
* Verify the properties of Check balance page
* Add the eGift card to cart
* Verify the added eGift card is available in the Shopping cart
* Delete the added eGift card from the Shopping cart
* Add the Physical gift card to cart
* Verify the added PGC is available in the Shopping cart
* Delete the added PGC from the Shopping cart
* Save and make the payments with credit card
* Navigate to manage credit cards page
* Verify the saved credit card is available in credit cards page
* Delete the added credit card from manage credit cards page
* Verify the saved cards are available in manage credit cards page
* Verify the credit cards are available in manage credit cards page
* Delete a credit card from manage credit cards page
* Add two credit cards
* Edit the added credit cards
* I add gift card
* I enter billing address
* Verify Billing address
* Select Continue Shopping option from Order confirmation page
* I purchased the product

*/

public class PaymentGatewayStepdef {

	@QAFTestStep(description = "Navigate to Gift cards page")
	public static void navigateToGiftCardsPage() {
		InStoreHomePage hometest = new InStoreHomePage();
		GiftcardslandingTestPage giftcardlanding = new GiftcardslandingTestPage();

		PerfectoUtils.mouseoverandclick(hometest.getHomeLblMoreoption(), hometest.getHomeLblGiftcard());

		if (giftcardlanding.getLblPageheader().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Gift cards page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Gift cards page.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the properties of Gift cards page")
	public void verifyThePropertiesOfGiftCardsPage() {
		GiftcardslandingTestPage giftcardlanding = new GiftcardslandingTestPage();

		giftcardlanding.getLblPageheader().verifyPresent();
		giftcardlanding.getLblGiftcardsubheader().verifyPresent();
		giftcardlanding.getLblEgiftcardsubheader().verifyPresent();
		giftcardlanding.getImgGiftcardsimage().verifyPresent();
		giftcardlanding.getImgEgiftcardsimage().verifyPresent();

		PerfectoUtils.reportMessage("Gift card details..", MessageTypes.Pass);
		for (QAFWebElement temp : giftcardlanding.getLblGiftcarddetailslist()) {
			PerfectoUtils.reportMessage(temp.getText());
		}

		PerfectoUtils.reportMessage("eGift card details..", MessageTypes.Pass);
		for (QAFWebElement temp : giftcardlanding.getLblEgiftcarddetailslist()) {
			PerfectoUtils.reportMessage(temp.getText());
		}

		giftcardlanding.getBtnShopgiftcards().verifyPresent();
		giftcardlanding.getBtnSendegiftcard().verifyPresent();
		giftcardlanding.getLblAlreadygiftcard().verifyPresent();
		giftcardlanding.getBtnCheckbalance().verifyPresent();
	}

	@QAFTestStep(description = "Navigate to Shop gift cards page")
	public static void navigateToShopGiftCardsPage() {
		GiftcardslandingTestPage giftcardlanding = new GiftcardslandingTestPage();
		ShopgiftcardsTestPage shopgiftcards = new ShopgiftcardsTestPage();

		giftcardlanding.getBtnShopgiftcards().waitForPresent(5000);
		giftcardlanding.getBtnShopgiftcards().click();

		if (shopgiftcards.getLblPageheader().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Shop gift cards page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Shop gift cards page.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the properties of Shop gift cards page")
	public void verifyThePropertiesOfShopGiftCardsPage() {
		ShopgiftcardsTestPage shopgiftcards = new ShopgiftcardsTestPage();

		shopgiftcards.getLblPageheader().verifyPresent();
		shopgiftcards.getLblMaintext().verifyPresent();

		int listsize = 0;
		try {
			listsize = shopgiftcards.getImgGiftcardimageslist().size();
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Error occured while validating the Gift card details.");
		}

		if (listsize > 0) {
			PerfectoUtils.reportMessage(listsize + " giftcards found.", MessageTypes.Pass);

			for (GiftCardComponents temp : shopgiftcards.getListGiftcarditems()) {
				temp.getImgGiftcardimageslist().verifyPresent();
				temp.getLblQuantitylist().verifyPresent();
				temp.getTxtQuantitydropdownlist().verifyPresent();
				temp.getLblAmount().verifyPresent();
				temp.getTxtAmountdropdown().verifyPresent();

				int amountListSize = shopgiftcards.getLblAmountdropdownvalues().size();
				if (amountListSize > 0) {
					PerfectoUtils.reportMessage(amountListSize + " values found in Amount dropdown.", MessageTypes.Pass);

					for (QAFWebElement temp1 : shopgiftcards.getLblAmountdropdownvalues()) {
						PerfectoUtils.reportMessage(temp1.getText());
					}
				} else {
					PerfectoUtils.reportMessage("No values found in amount dropdown.", MessageTypes.Fail);
				}

				temp.getBtnAddtocart().verifyPresent();
				break;
			}
		} else {
			PerfectoUtils.reportMessage("No Giftcards found.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Navigate to Send an eGift card page")
	public static void navigateToSendAnEGiftCardPage() {
		GiftcardslandingTestPage giftcardlanding = new GiftcardslandingTestPage();
		SendegiftcardsTestPage sendegiftcards = new SendegiftcardsTestPage();

		giftcardlanding.getBtnSendegiftcard().waitForPresent(5000);
		giftcardlanding.getBtnSendegiftcard().click();

		if (sendegiftcards.getLblPageheader().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Send an eGift card page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Send an eGift card page", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the properties of Send an eGift card page")
	public void verifyThePropertiesOfSendAnEGiftCardPage() {
		SendegiftcardsTestPage sendegiftcards = new SendegiftcardsTestPage();

		sendegiftcards.getLblPageheader().verifyPresent();
		sendegiftcards.getLblSendegiftcard().verifyPresent();
		PerfectoUtils.scrolltoelement(sendegiftcards.getLblRequiredfields());
		sendegiftcards.getLblRequiredfields().verifyPresent();
		sendegiftcards.getLblBrand().verifyPresent();
		sendegiftcards.getTxtBrand().verifyPresent();
		sendegiftcards.getLblTo().verifyPresent();
		sendegiftcards.getTxtTo().verifyPresent();
		sendegiftcards.getLblRecipientemail().verifyPresent();
		sendegiftcards.getTxtRecipientemail().verifyPresent();
		sendegiftcards.getLblReenterrecipientemail().verifyPresent();
		sendegiftcards.getTxtReenterrecipientemail().verifyPresent();
		sendegiftcards.getLblFrom().verifyPresent();
		sendegiftcards.getTxtFrom().verifyPresent();
		sendegiftcards.getLblAmount().verifyPresent();
		sendegiftcards.getTxtAmount().verifyPresent();

		// Verifying the values in the Amount drop down
		try {
			int amountvaluesSize = sendegiftcards.getTxtAmountvalues().size();
			if (amountvaluesSize > 0) {
				PerfectoUtils.reportMessage(amountvaluesSize + " Values found in the amount dropdown.", MessageTypes.Pass);

				for (QAFWebElement temp : sendegiftcards.getTxtAmountvalues()) {
					PerfectoUtils.reportMessage(temp.getText());
				}
			} else {
				PerfectoUtils.reportMessage("No Values found in the amount dropdown.", MessageTypes.Fail);
			}
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Error occured while validating the Amount dropdown values.", MessageTypes.Fail);
		}

		// Validating the Remaining fields
		sendegiftcards.getLblMessage().verifyPresent();
		sendegiftcards.getTxtMessage().verifyPresent();
		sendegiftcards.getLnkTermsandconditions().verifyPresent();
		sendegiftcards.getBtnAddtocart().verifyPresent();
	}

	@QAFTestStep(description = "Navigate to Check balance page")
	public void navigateToCheckBalancePage() {
		GiftcardslandingTestPage giftcardspage = new GiftcardslandingTestPage();
		CheckbalanceTestPage checkbalance = new CheckbalanceTestPage();

		PerfectoUtils.scrolltoelement(giftcardspage.getBtnCheckbalance());
		navigateToPage(giftcardspage.getBtnCheckbalance(), checkbalance.getLblPageheader(), "Check Balance page");
	}

	@QAFTestStep(description = "Verify the properties of Check balance page")
	public void verifyThePropertiesOfCheckBalancePage() {
		CheckbalanceTestPage checkbalance = new CheckbalanceTestPage();

		checkbalance.getLblPageheader().verifyPresent();
		PerfectoUtils.scrolltoelement(checkbalance.getLblPageheader());
		checkbalance.getLblCheckgiftcardbalanceheader().verifyPresent();
		checkbalance.getLblEntergiftcardnumber().verifyPresent();
		checkbalance.getLnkWhereismygiftcardnumber().verifyPresent();
		checkbalance.getTxtEntergiftcardnumber().verifyPresent();
		checkbalance.getLblEnterpin().verifyPresent();
		checkbalance.getLnkEnterpin().verifyPresent();
		checkbalance.getTxtEnterpin().verifyPresent();
//		checkbalance.getLblTypethecharactersyouseeinimage().verifyPresent();
//		checkbalance.getLblImage().verifyPresent();
//		checkbalance.getImgCaptchaimage().verifyPresent();
//		checkbalance.getImgTryadifferentimage().verifyPresent();
//		checkbalance.getLblClicktoresettheimage().verifyPresent();
//		checkbalance.getLblTypecharactersshownabove().verifyPresent();
//		checkbalance.getTxtTyp	echaractersshownabove().verifyPresent();
		checkbalance.getImgCaptchasection().verifyPresent();
		checkbalance.getBtnCheckbalance().verifyPresent();
	}

	@QAFTestStep(description = "Add the eGift card to cart")
	public static void addTheEGiftCardToCart() {
		SendegiftcardsTestPage sendegidtcards = new SendegiftcardsTestPage();

		PerfectoUtils.scrolltoelement(sendegidtcards.getLblRequiredfields());

		sendegidtcards.getTxtTo().sendKeys(getBundle().getString("sendegiftcard.to"));
		sendegidtcards.getTxtRecipientemail().sendKeys(getBundle().getString("sendegiftcard.recipientemail"));
		sendegidtcards.getTxtReenterrecipientemail()
				.sendKeys(getBundle().getString("sendegiftcard.reenterrecipientemail"));
		sendegidtcards.getTxtFrom().sendKeys(getBundle().getString("sendegiftcard.from"));
		PerfectoUtils.reportMessage("Entered the mandatory fields", MessageTypes.Pass);

		sendegidtcards.getBtnAddtocart().waitForPresent(5000);
		sendegidtcards.getBtnAddtocart().click();
		PerfectoUtils.reportMessage("Clicked Add to cart button.", MessageTypes.Pass);

	}

	@QAFTestStep(description = "Verify the added eGift card is available in the Shopping cart")
	public synchronized void verifyTheAddedEGiftCardIsAvailableInTheShoppingCart() {
		CartTestPage shoppingcart = new CartTestPage();

		if (shoppingcart.getCartLblHeader().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Shopping cart page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Shopping cart page.", MessageTypes.Fail);
		}

		try {
			if (shoppingcart.getCartLblEgiftcardname().isPresent()) {
				PerfectoUtils.scrolltoelement(shoppingcart.getCartLblEgiftcardname());
				PerfectoUtils.reportMessage("Added eGift card is available in the Shopping cart.", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Added eGift card is not available in the Shopping cart.", MessageTypes.Fail);
			}
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Error occured while validating the added eGift card in Shopping cart.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Delete the added eGift card from the Shopping cart")
	public void deleteTheAddedEGiftCardFromTheShoppingCart() {
		CartTestPage shoppingcart = new CartTestPage();

		try {
			if (shoppingcart.getCartLblEgiftcardname().isPresent()) {
				PerfectoUtils.scrolltoelement(shoppingcart.getCartLblEgiftcardname());

				// Clicking on 'Remove' option
				shoppingcart.getCartBtnEgiftcardremove().waitForPresent(5000);
				shoppingcart.getCartBtnEgiftcardremove().click();
				PerfectoUtils.reportMessage("Removing the eGift card from Shopping cart", MessageTypes.Pass);

				// Clicking 'yes' button from the confirmation pop-up
				try {
					shoppingcart.getCartLblRemoveitempopuptitle().waitForPresent(5000);
				} catch (Exception e) {

					e.printStackTrace();
				}

				if (shoppingcart.getCartLblRemoveitempopuptitle().isPresent()) {
					PerfectoUtils.reportMessage("Found confirmation popup:" + shoppingcart.getCartLblRemoveitempopuptitle().getText(),
							MessageTypes.Pass);
					shoppingcart.getCartBtnYes().click();
				} else {
					PerfectoUtils.reportMessage("Confirmation popup not found.", MessageTypes.Fail);
				}

				// validating whether the eGift card is not present
				if (!shoppingcart.getCartLblEgiftcardname().isPresent()) {
					PerfectoUtils.reportMessage("Done.", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("eGift card not removed", MessageTypes.Fail);
				}

			} else {
				PerfectoUtils.reportMessage("eGift card not found.", MessageTypes.Fail);
			}
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Error occured while removing the added eGift card from Shopping cart.", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Add the Physical gift card to cart")
	public static void addThePhysicalGiftCardToCart() {
		ShopgiftcardsTestPage shopgc = new ShopgiftcardsTestPage();

		int addtocartListSize = 0;
		try {
			addtocartListSize = shopgc.getBtnAddtocart().size();
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Error occured while getting the number of PGC present");
		}

		if (addtocartListSize > 0) {
			PerfectoUtils.scrolltoelement(shopgc.getListGiftcarditems().get(0));
			PerfectoUtils.reportMessage(addtocartListSize + " Physical gift cards found.", MessageTypes.Pass);
			String qty = shopgc.getTxtQuantitydropdownlist().get(0).getAttribute("value");
			getBundle().setProperty("PGCQty", qty);
			shopgc.getBtnAddtocart().get(0).waitForPresent(5000);
			shopgc.getBtnAddtocart().get(0).click();
			PerfectoUtils.reportMessage("Clicked Add to cart button", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("No Physical gift cards found.", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify the added PGC is available in the Shopping cart")
	public static void verifyTheAddedPGCIsAvailableInTheShoppingCart() {
		CartTestPage shoppingcart = new CartTestPage();

		if (shoppingcart.getCartLblHeader().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Shopping cart page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Shopping cart page.", MessageTypes.Fail);
		}

		try {
			if (shoppingcart.getCartLblPhysicalgiftcardname().isPresent()) {
				PerfectoUtils.scrolltoelement(shoppingcart.getCartLblPhysicalgiftcardname());
				PerfectoUtils.reportMessage("Added PGC is available in the Shopping cart.", MessageTypes.Pass);
				
				//Verify the quantity
				if(shoppingcart.getCartEdtPhysicalgiftcardqty().getAttribute("value").equals(getBundle().getString("PGCQty"))){
					PerfectoUtils.reportMessage("Added PGC Quantity is correctly updated in the Shopping cart.", MessageTypes.Pass);	
				}else{
					PerfectoUtils.reportMessage("Added PGC Quantity is not correct in the Shopping cart.", MessageTypes.Fail);
				}
			} else {
				PerfectoUtils.reportMessage("Added PGC is not available in the Shopping cart.", MessageTypes.Fail);
			}
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Error occured while validating the added PGC in Shopping cart.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Delete the added PGC from the Shopping cart")
	public void deleteTheAddedPGCFromTheShoppingCart() {
		CartTestPage shoppingcart = new CartTestPage();

		try {
			if (shoppingcart.getCartLblPhysicalgiftcardname().isPresent()) {
				PerfectoUtils.scrolltoelement(shoppingcart.getCartLblPhysicalgiftcardname());

				// Clicking on 'Remove' option
				shoppingcart.getCartBtnPhysicalgiftcardremove().waitForPresent(5000);
				shoppingcart.getCartBtnPhysicalgiftcardremove().click();
				PerfectoUtils.reportMessage("Removing the PGC from Shopping cart", MessageTypes.Pass);

				// Clicking 'yes' button from the confirmation pop-up
				try {
					shoppingcart.getCartLblRemoveitempopuptitle().waitForPresent(5000);
				} catch (Exception e) {

					e.printStackTrace();
				}

				if (shoppingcart.getCartLblRemoveitempopuptitle().isPresent()) {
					PerfectoUtils.reportMessage("Found confirmation popup:" + shoppingcart.getCartLblRemoveitempopuptitle().getText(),
							MessageTypes.Pass);
					shoppingcart.getCartBtnYes().click();
				} else {
					PerfectoUtils.reportMessage("Confirmation popup not found.", MessageTypes.Fail);
				}

				// validating whether the eGift card is not present
				if (!shoppingcart.getCartLblPhysicalgiftcardname().isPresent()) {
					PerfectoUtils.reportMessage("Done.", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("PGC not removed", MessageTypes.Fail);
				}

			} else {
				PerfectoUtils.reportMessage("PGC not found.", MessageTypes.Fail);
			}
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Error occured while removing the added PGC from Shopping cart.", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Save and make the payments with credit card")
	public void saveAndMakeThePaymentsWithCreditCard() {
		PaymentTestPage payment = new PaymentTestPage();
		CartAndCheckout cartandcheckout = new CartAndCheckout();

		PerfectoUtils.reportMessage("Navigated to Payment section.", MessageTypes.Pass);

		// 1. Entering the credit card details
		PerfectoUtils.scrolltoelement(payment.getPaymentLblEnteracreditcard());
		cartandcheckout.enterCreditCardDetailsInpayment();
		getCreditCardName();

		// Saving the Credit card details
		if (payment.getPaymentChkSavecreditcard().isPresent()) {
			PerfectoUtils.scrolltoelement(payment.getPaymentChkSavecreditcard());
			payment.getPaymentChkSavecreditcard().click();
		} else {
			PerfectoUtils.reportMessage("Save credit card option not found.", MessageTypes.Info);
		}

		// 2. Entering the Billing address details
		PerfectoUtils.scrolltoelement(payment.getPaymentLblBillingaddress());
		cartandcheckout.enterBillingAddressInPayment();

		// Verify whether the state box has been pre-populated as "UNITED
		// STATES"
		String strState = payment.getPaymentTxtState().getAttribute("value");
		if (strState.length() > 0) {
			PerfectoUtils.reportMessage("State field has been pre-populated as: " + strState, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("State field has not been pre-populated", MessageTypes.Fail);
		}

		// Applying Tax Exemption for Tax-exempted user
		if (payment.getPaymentLblApplytaxexemption().isPresent()) {
			cartandcheckout.applyTaxExemption();
		}

		// Clicking the "Submit order" button
		payment.getPaymentBtnSubmitorder().waitForPresent(5000);
		payment.getPaymentBtnSubmitorder().click();
		PerfectoUtils.reportMessage("Clicked Submit order button", MessageTypes.Pass);
		payment.waitForPageToLoad();
		// payment.getBtnSubmitorder().waitForNotPresent(10000);

	}

	public void getCreditCardName() {
		String cardNumber = getBundle().getString("payment.card.cardnumber");
		String last4digitsOfcard = cardNumber.substring(12);

		String cardName = "mastercard-" + last4digitsOfcard;
		getBundle().setProperty("creditCardName", cardName);
		PerfectoUtils.reportMessage("Credit card name: " + cardName, MessageTypes.Pass);

	}

	@QAFTestStep(description = "Navigate to manage credit cards page")
	public void navigateToManageCreditCardsPage() {
		myAccountLandingTestPage myaccount = new myAccountLandingTestPage();
		ManageCreditCardsTestPage managecreditcards = new ManageCreditCardsTestPage();

		PerfectoUtils.navigateToPage(myaccount.getMyacclandingLnkManagecreditcards(), managecreditcards.getManageCCTxtHeader(),
				"manage credit cards page");
	}

	@QAFTestStep(description = "Verify the saved credit card is available in credit cards page")
	public void verifyTheSavedCreditCardIsAvailableInCreditCardsPage() {
		ManageCreditCardsTestPage managecards = new ManageCreditCardsTestPage();

		int flag = 0;
		int strCardSize = managecards.getManageccLiLblCreditcardnamelist().size();
		String strSavedCard = PerfectoUtils.removeSpecialCharacters(getBundle().getString("creditCardName"));

		PerfectoUtils.scrolltoelement(managecards.getManageccLblMycreditcards());
		PerfectoUtils.reportMessage("Saved card name: " + getBundle().getString("creditCardName"), MessageTypes.Pass);
		for (int i = 0; i < strCardSize; i++) {

			String creditCardnameInMyAccount = PerfectoUtils
					.removeSpecialCharacters(managecards.getManageccLiLblCreditcardnamelist().get(i).getText());

			if (creditCardnameInMyAccount.equalsIgnoreCase(strSavedCard)) {
				PerfectoUtils.scrolltoelement(managecards.getManageccLiLblCreditcardnamelist().get(i));
				PerfectoUtils.reportMessage("Saved credit card available in the Manage credit cards page.", MessageTypes.Pass);

				// Deleting the added credit card
				managecards.getManageccLiLblCreditcarddeletelist().get(i).click();

				if (managecards.getManageccLblCreditcarddeletepopuptitle().isPresent()) {
					managecards.getManageccBtnCreditcarddeletepopupyes().click();
				}
				flag++;
				break;
			}
		}

		if (flag == 0)
			PerfectoUtils.reportMessage("Saved credit card not found.", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Delete the added credit card from manage credit cards page")
	public void deleteTheAddedCreditCardFromManageCreditCardsPage() {
		ManageCreditCardsTestPage managecards = new ManageCreditCardsTestPage();

		int strCardSize = managecards.getManageccLiLblCreditcardnamelist().size();
		String strSavedCard = PerfectoUtils.removeSpecialCharacters(getBundle().getString("creditCardName"));

		PerfectoUtils.scrolltoelement(managecards.getManageccLblMycreditcards());
		for (int i = 0; i < strCardSize; i++) {

			String creditCardnameInMyAccount = PerfectoUtils
					.removeSpecialCharacters(managecards.getManageccLiLblCreditcardnamelist().get(i).getText());

			if (creditCardnameInMyAccount.equalsIgnoreCase(strSavedCard)) {
				PerfectoUtils.scrolltoelement(managecards.getManageccLiLblCreditcardnamelist().get(i));
				managecards.getManageccLiLblCreditcarddeletelist().get(i).click();

				if (managecards.getManageccLblCreditcarddeletepopuptitle().isPresent()) {
					PerfectoUtils.reportMessage("Delete pop up confirmation found.", MessageTypes.Pass);
					managecards.getManageccBtnCreditcarddeletepopupyes().click();
				}
				break;
			}
		}
	}

	@QAFTestStep(description = "Verify the saved cards are available in manage credit cards page")
	public void verifyTheSavedCardsAreAvailableInManageCreditCardsPage() {
		ManageCreditCardsTestPage managecards = new ManageCreditCardsTestPage();

		int cardSize = managecards.getManageccLiLblCreditcarddeletelist().size();

		if (cardSize > 0) {
			PerfectoUtils.scrolltoelement(managecards.getManageccLiLblCreditcardnamelist().get(0));
			PerfectoUtils.reportMessage(cardSize + " saved credit cards found", MessageTypes.Pass);
			managecards.getManageccLiLblCreditcarddeletelist().get(0).click();

			if (managecards.getManageccLblCreditcarddeletepopuptitle().isPresent()) {
				PerfectoUtils.reportMessage("Delete pop up confirmation found.", MessageTypes.Pass);
				managecards.getManageccBtnCreditcarddeletepopupyes().click();
			} else {
				PerfectoUtils.reportMessage("Delete pop up confirmation not found.", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("No saved credit cards found.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the credit cards are available in manage credit cards page")
	public void verifyTheCreditCardsAreAvailableInManageCreditCardsPage() {
		ManageCreditCardsTestPage managecards = new ManageCreditCardsTestPage();
		CartAndCheckout cartandcheckout = new CartAndCheckout();
		PaymentTestPage payment = new PaymentTestPage();

		int cardSize = managecards.getManageccLiLblCreditcarddeletelist().size();

		if (cardSize > 0) {
			PerfectoUtils.scrolltoelement(managecards.getManageccLblMycreditcards());
			PerfectoUtils.reportMessage(cardSize + " saved credit cards found", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("No credit cards found. adding a new credit card..", MessageTypes.Pass);

			managecards.getManageccBtnAddanewcreditcard().verifyPresent();
			managecards.getManageccBtnAddanewcreditcard().click();

			managecards.getManageccLblAddnewcreditordebitcardheader().waitForPresent(10000);

			managecards.getManageccLblAddnewcreditordebitcardheader().verifyPresent();
			PerfectoUtils.scrolltoelement(managecards.getManageccLblMypaymentinfo());

			cartandcheckout.enterCreditCardDetailsInpayment();

			// 2. Entering the Billing address details
			PerfectoUtils.scrolltoelement(payment.getPaymentLblBillingaddress());
			cartandcheckout.enterBillingAddressInPayment();

			PerfectoUtils.scrolltoelement(managecards.getManageccBtnAddcreditcard());
			managecards.getManageccBtnAddcreditcard().verifyPresent();
			managecards.getManageccBtnAddcreditcard().click();
			PerfectoUtils.reportMessage("Clicked Add credit card button.", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "Delete a credit card from manage credit cards page")
	public void deleteACreditCardFromManageCreditCardsPage() {
		ManageCreditCardsTestPage managecards = new ManageCreditCardsTestPage();

		String strDeletingCreditCard = null;
		PerfectoUtils.scrolltoelement(managecards.getManageccLblMycreditcards());

		int cardSize = managecards.getManageccLiLblCreditcarddeletelist().size();

		if (cardSize > 0) {
			PerfectoUtils.scrolltoelement(managecards.getManageccLblMycreditcards());
			PerfectoUtils.reportMessage(cardSize + " saved credit cards found", MessageTypes.Pass);
			strDeletingCreditCard = managecards.getManageccLiLblCreditcardnamelist().get(0).getText();
			getBundle().setProperty("strDeletingCreditCard", strDeletingCreditCard);
			managecards.getManageccLiLblCreditcarddeletelist().get(0).click();

			managecards.getManageccLblCreditcarddeletepopuptitle().waitForPresent(10000);
			if (managecards.getManageccLblCreditcarddeletepopuptitle().isPresent()) {
				PerfectoUtils.reportMessage("Delete pop up confirmation found.", MessageTypes.Pass);
				managecards.getManageccBtnCreditcarddeletepopupyes().click();

				// verifying whether the Credit card is deleted
				verifyCreditCardIsDeleted();

			} else {
				PerfectoUtils.reportMessage("Delete pop up confirmation not found.", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("No credit cards found.", MessageTypes.Fail);
		}
	}

	public void verifyCreditCardIsDeleted() {
		ManageCreditCardsTestPage managecards = new ManageCreditCardsTestPage();

		int flag = 0;
		String strDeletingCreditCard = PerfectoUtils
				.removeSpecialCharacters(getBundle().getString("strDeletingCreditCard"));

		if (managecards.getManageccLblYoudonothavecreditcard().isPresent()) {
			PerfectoUtils.reportMessage("Credits cards deleted", MessageTypes.Pass);
		} else {

			int cardSize = managecards.getManageccLiLblCreditcardnamelist().size();
			PerfectoUtils.scrolltoelement(managecards.getManageccLblMycreditcards());
			for (int i = 0; i < cardSize; i++) {

				String creditCardnameInMyAccount = PerfectoUtils
						.removeSpecialCharacters(managecards.getManageccLiLblCreditcardnamelist().get(i).getText());

				if (creditCardnameInMyAccount.equalsIgnoreCase(strDeletingCreditCard)) {
					flag = 1;
					break;
				}
			}

			if (flag == 0)
				PerfectoUtils.reportMessage("Credit card deleted.", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Credit card not deleted.", MessageTypes.Fail);

		}
	}

	@QAFTestStep(description = "Add two credit cards")
	public void addTwoCreditCards() {
		ManageCreditCardsTestPage managecards = new ManageCreditCardsTestPage();
		CartAndCheckout cartandcheckout = new CartAndCheckout();
		PaymentTestPage payment = new PaymentTestPage();

		// Click on Add New Credit card
		verifyTheCreditCardsAreAvailableInManageCreditCardsPage();

		managecards.getManageccBtnAddanewcreditcard().verifyPresent();
		managecards.getManageccBtnAddanewcreditcard().click();
		managecards.getManageccLblAddnewcreditordebitcardheader().waitForPresent(10000);
		managecards.getManageccLblAddnewcreditordebitcardheader().verifyPresent();
		PerfectoUtils.scrolltoelement(managecards.getManageccLblMypaymentinfo());

		// 1. Enter credit card details
		if (payment.getPaymentLblEnteracreditcard().isPresent()) {
			if (!payment.getPaymentRbtnEnteracreditcard().isSelected()) {
				payment.getPaymentRbtnEnteracreditcard().click();
			}
		}

		payment.getPaymentTxtNameoncard().sendKeys(getBundle().getString("payment.card2.nameoncard"));
		payment.getPaymentLblCardtypeamericanexpress().click();
		payment.getPaymentTxtCardnumber().sendKeys(getBundle().getString("payment.card2.cardnumber"));
		payment.getPaymentTxtCardexpirymonthvalue().click();
		payment.getPaymentTxtCardexpiryyearvalue().click();
		payment.getPaymentTxtCardcvc().sendKeys(getBundle().getString("payment.card2.cvc"));

		// 2. Entering the Billing address details
		PerfectoUtils.scrolltoelement(payment.getPaymentLblBillingaddress());
		cartandcheckout.enterBillingAddressInPayment();

		PerfectoUtils.scrolltoelement(managecards.getManageccBtnAddcreditcard());
		managecards.getManageccBtnAddcreditcard().verifyPresent();
		managecards.getManageccBtnAddcreditcard().click();
		PerfectoUtils.reportMessage("Clicked Add credit card button.", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Edit the added credit cards")
	public void editTheAddedCreditCards() {
		PaymentTestPage payment = new PaymentTestPage();

		payment.getPayementBtnMakeprimarycard().isPresent();

		String cardnamedefault = payment.getPayementLblCardname().getText();
		System.out.println(cardnamedefault);
		payment.getPayementBtnMakeprimarycard().click();

		payment.waitForPageToLoad();

		if (payment.getPayementLblDefaultcards().isPresent()) {
			String cardname = payment.getPayementLblCardname().getText();
			System.out.println(cardname);
			payment.getPayementBtnMyprimarycard().verifyPresent("cardname");
			getBundle().setProperty("changedcardname", cardname);
		}

		if (!(cardnamedefault.equalsIgnoreCase(payment.getPayementLblCardname().getText()))) {
			PerfectoUtils.reportMessage("Edit credit card is done", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Edit credit card is not done", MessageTypes.Fail);
		}
	}


	@QAFTestStep(description = "I add gift card")
	public void iAddGiftCard() {
		myAccountLandingTestPage myaccount = new myAccountLandingTestPage();
		// PerfectoUtils.getDriver().get("lib\\XMLTest.htm");
		PerfectoUtils.reportMessage("Driver initiated", MessageTypes.Info);
		myaccount.waitForPageToLoad();
		// PerfectoUtils.getDriver().get("D:\\Automation\\QAS_Win32\\HEBWebAppAutomation\\lib\\XMLTest.htm");
		PerfectoUtils.getDriver().navigate()
				.to("file:///D://Automation//QAS_Win32//HEBWebAppAutomation//lib//XMLTest.htm");
		PerfectoUtils.reportMessage("Driver initiated", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I enter billing address")
	public void iEnterBillingAddress() {

		verifyTheCreditCardsAreAvailableInManageCreditCardsPage();
	}

	@QAFTestStep(description = "Verify Billing address")
	public void verifyShiipingAddress() {
		PaymentTestPage payment = new PaymentTestPage();

		PerfectoUtils.scrolltoelement(payment.getPaymentLblBillingaddress());
		// cartandcheckout.enterBillingAddressInPayment();

		payment.getPaymentTxtFirstname().verifyPresent("firstname1");
		payment.getPaymentTxtLastname().verifyPresent("lastname1");

		payment.getPaymentTxtPhonenumber1().verifyPresent("987");
		payment.getPaymentTxtPhonenumber2().verifyPresent("654");
		payment.getPaymentTxtPhonenumber3().verifyPresent("8741");

		PerfectoUtils.scrolltoelement(payment.getPaymentTxtPhonenumber1());
		payment.getPaymentTxtStreetaddress1().verifyPresent("13901 FM 969");
		payment.getPaymentTxtCity().verifyPresent("Austin");
		payment.getPaymentTxtZipcode().verifyPresent("78724");

	}
	
	@QAFTestStep(description="Select Continue Shopping option from Order confirmation page")
	public void selectContinueShoppingOptionFromOrderConfirmationPage(){
		ConfirmationTestPage confirmation = new ConfirmationTestPage();
		
		confirmation.getConfirmBtnContinueshopping().waitForPresent(5000);
		confirmation.getConfirmBtnContinueshopping().click();
	}
	
	@QAFTestStep(description="I purchased the product")
	public void iPurchasedTheProduct() throws InterruptedException{
		CartAndCheckout cart = new CartAndCheckout();
		
		cart.iNavigateToCartBySelectingViewCartInCartMouseoverOption();
		cart.iCheckOutTheProduct();
		cart.iCheckoutTheItemsAsAHotUser();
		cart.iMakeThePaymentsWithCreditCard();
		cart.iVerifyTheOrderConfirmationPage();
		selectContinueShoppingOptionFromOrderConfirmationPage();
	}
	
	@QAFTestStep(description = "I edit EGC values in Edit details model and validate")
	public static void iEditEGCValuesInEditDetailsModelAndValidate() {
		SendegiftcardsTestPage sendegidtcards = new SendegiftcardsTestPage();
		CartTestPage cart = new CartTestPage();
		
		cart.getCartLnkEditdetails().click();
		cart.getCartLblEditheader().waitForPresent(5000);

		PerfectoUtils.scrolltoelement(sendegidtcards.getLblRequiredfields());

		sendegidtcards.getTxtAmount().verifyPresent();
		String selectedEGC = sendegidtcards.getTxtAmountvalues().get(3).getText().trim();
		sendegidtcards.getTxtAmountvalues().get(3).click();
		PerfectoUtils.reportMessage("Updated the EGC amount value", MessageTypes.Pass);

		cart.getCartBtnEditupdateegc().waitForPresent(5000);
		cart.getCartBtnEditupdateegc().click();
		PerfectoUtils.reportMessage("Clicked Update button in edit details", MessageTypes.Pass);
		
		String actEGC = cart.getCartLblSubtotalvalue().getText().trim();
		
		if(actEGC.equalsIgnoreCase(selectedEGC))
			PerfectoUtils.reportMessage("Updated EGC amount through Edit details link", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not Updated EGC amount through Edit details link", MessageTypes.Fail);
	}
	
	@QAFTestStep(description = "Edit PGC quantity to {0} and add them to cart")
	public static void editPGCQuantityToAndAddThemToCart(String qty) {
		ShopgiftcardsTestPage shopgc = new ShopgiftcardsTestPage();

		int addtocartListSize = 0;
		try {
			addtocartListSize = shopgc.getBtnAddtocart().size();
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Error occured while getting the number of PGC present");
		}

		if (addtocartListSize > 0) {
			PerfectoUtils.scrolltoelement(shopgc.getListGiftcarditems().get(0));
			PerfectoUtils.reportMessage(addtocartListSize + " Physical gift cards found.", MessageTypes.Pass);
			
			shopgc.getTxtQuantitydropdownlist().get(0).click();
			shopgc.getTxtQuantitydropdownlist().get(0).clear();
			shopgc.getTxtQuantitydropdownlist().get(0).sendKeys(qty);
			getBundle().setProperty("PGCQty", qty);
			shopgc.getBtnAddtocart().get(0).waitForPresent(5000);
			shopgc.getBtnAddtocart().get(0).click();
			PerfectoUtils.reportMessage("Clicked Add to cart button", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("No Physical gift cards found.", MessageTypes.Fail);
		}

	}
	
	@QAFTestStep(description = "Add {0} Physical gift card to cart and verify the same is added to cart")
	public static void addphysicalGiftCardToCartAndVerifyTheSameInCart(String qty) {
		navigateToGiftCardsPage();
		navigateToShopGiftCardsPage();
		editPGCQuantityToAndAddThemToCart(qty);
		verifyTheAddedPGCIsAvailableInTheShoppingCart();
		
	}
	
	@QAFTestStep(description = "Validate the gift card error message")
	public static void validateTheGiftCardErrorMessage() {
		ShopgiftcardsTestPage pgc = new ShopgiftcardsTestPage();
		
		pgc.getLblErrormsg().waitForPresent(5000);
		pgc.getLblErrormsg().verifyPresent();
	}
	
	@QAFTestStep(description = "Add {0} Physical gift card to cart and verify the error message")
	public static void addphysicalGiftCardToCartAndVerifyTheErrorMessage(String qty) {
		navigateToGiftCardsPage();
		navigateToShopGiftCardsPage();
		editPGCQuantityToAndAddThemToCart(qty);
		validateTheGiftCardErrorMessage();
		
	}
	
	@QAFTestStep(description = "Edit PGC quantity to {0} in cart page")
	public static void editPGCQuantityToInCartPage(String qty) {
		CartTestPage cart = new CartTestPage();
		
		cart.getCartEdtQty().clear();
		cart.getCartEdtQty().sendKeys(qty);
		cart.getCartBtnUpdate().click();
	}
	
}
