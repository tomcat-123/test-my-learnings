package com.automation.web.pages.weeklyads;

import java.util.List;

import com.automation.web.components.weeklyads.WeeklyAdsFromDealsPage;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class WeeklyaddealsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "wklyad.lbl.pageheader")
	private QAFWebElement lblPageheader;
	@FindBy(locator = "wklyad.lbl.storename")
	private QAFWebElement lblStorename;
	@FindBy(locator = "wklyad.lbl.viewprintversion")
	private QAFWebElement lblViewprintversion;
	@FindBy(locator = "wklyad.lnk.addtolist")
	private QAFWebElement wklyadLnkAddtolist;
	@FindBy(locator = "wklyad.lbl.bycategory")
	private QAFWebElement wklyadLblBycategory;
	@FindBy(locator = "wklyad.lbl.breadcrumblast")
	private QAFWebElement wklyadLblBreadcrumblast;
	@FindBy(locator = "wklyad.img.leftnavbar")
	private QAFWebElement wklyadImgLeftnavbar;
	@FindBy(locator = "wklyad.li.leftnavoptions")
	private List<QAFWebElement> wklyadLiLeftnavoptions;
	@FindBy(locator = "wklyad.lbl.storeaddress")
	private QAFWebElement wklyadLblStoreaddress;
	@FindBy(locator = "wklyad.lbl.featureddeals")
	private QAFWebElement wklyadLblFeatureddeals;
	@FindBy(locator = "wklyad.lbl.pricesvalid")
	private QAFWebElement wklyadLblPricesvalid;
	@FindBy(locator = "wklyad.li.weeklyadslist")
	private List<WeeklyAdsFromDealsPage> wklyadLiWeeklyadslist;
	@FindBy(locator = "wklyad.lnk.added")
	private QAFWebElement wklyadLnkAdded;
	@FindBy(locator = "wklyad.lbl.added")
	private QAFWebElement wklyadLblAdded;
	@FindBy(locator = "wklyad.lnk.moredetailsadded")
	private QAFWebElement wklyadLnkMoreDetailsAdded;
	@FindBy(locator = "wklyad.li.weeklyadstorelist")
	private List<QAFWebElement> wklyadLiStoreList;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblPageheader() {
		return lblPageheader;
	}

	public QAFWebElement getLblStorename() {
		return lblStorename;
	}
	
	public QAFWebElement getLnkAdded() {
		return wklyadLnkAdded;
	}
	
	public QAFWebElement getLblAdded() {
		return wklyadLblAdded;
	}

	public QAFWebElement getLblViewprintversion() {
		return lblViewprintversion;
	}

	public QAFWebElement getWklyadLnkAddtolist() {
		return wklyadLnkAddtolist;
	}

	public QAFWebElement getWklyadLblBycategory() {
		return wklyadLblBycategory;
	}

	public QAFWebElement getWklyadLblBreadcrumblast() {
		return wklyadLblBreadcrumblast;
	}

	public QAFWebElement getWklyadImgLeftnavbar() {
		return wklyadImgLeftnavbar;
	}

	public List<QAFWebElement> getWklyadLiLeftnavoptions() {
		return wklyadLiLeftnavoptions;
	}

	public QAFWebElement getWklyadLblStoreaddress() {
		return wklyadLblStoreaddress;
	}

	public QAFWebElement getWklyadLblFeatureddeals() {
		return wklyadLblFeatureddeals;
	}

	public QAFWebElement getWklyadLblPricesvalid() {
		return wklyadLblPricesvalid;
	}
	
	public QAFWebElement getWklyadLnkMoreDetailsAdded() {
		return wklyadLnkMoreDetailsAdded;
	}

	public List<WeeklyAdsFromDealsPage> getWklyadLiWeeklyadslist() {
		return wklyadLiWeeklyadslist;
	}
	
	public List<QAFWebElement> getWklyadLiStorelist() {
		return wklyadLiStoreList;
	}
	
	public QAFWebElement getLblCategorytitledynamic(String item) {
		String items = String.format(pageProps.getString("wklyad.lbl.categorytitledynamic"), item);
		return new QAFExtendedWebElement(items);
	}
	
	public QAFWebElement getLnkWeeklyadSelectStoredynamic(String item) {
		String items = String.format(pageProps.getString("wklyad.get.lnk.weeklyadselectstore"), item);
		return new QAFExtendedWebElement(items);
	}
	
	public QAFWebElement getLnkWeeklyadSelectStoreNamedynamic(String item) {
		String items = String.format(pageProps.getString("wklyad.get.lbl.weeklyadselectstorename"), item);
		return new QAFExtendedWebElement(items);
	}
}
