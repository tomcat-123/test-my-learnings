package com.automation.web.pages.myAccount;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class myAccountLandingTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "myacclanding.lnk.addressbook")
	private QAFWebElement myacclandingLnkAddressbook;
	@FindBy(locator = "myacclanding.lnk.profileinformation")
	private QAFWebElement myacclandingLnkProfileinformation;
	@FindBy(locator = "myacclanding.lbl.pagetitle")
	private QAFWebElement myacclandingLblPagetitle;
	@FindBy(locator = "myacclanding.lnk.changepassword")
	private QAFWebElement myacclandingLnkChangepassword;
	@FindBy(locator = "myacclanding.lnk.editprofile")
	private QAFWebElement myacclandingLnkEditprofile;
	@FindBy(locator = "myacclanding.lbl.username")
	private QAFWebElement myacclandingLblUsername;
	@FindBy(locator = "myacclanding.lbl.email")
	private QAFWebElement myacclandingLblEmail;
	@FindBy(locator = "myacclanding.lnk.editcommPref")
	private QAFWebElement myacclandingLnkEditcommPref;
	@FindBy(locator = "myacclanding.lnk.createpharmprof")
	private QAFWebElement myacclandingLnkCreatepharmprof;
	@FindBy(locator = "myacclanding.lnk.managecreditcards")
	private QAFWebElement myacclandingLnkManagecreditcards;
	@FindBy(locator = "myacclanding.btn.addressedit")
	private QAFWebElement myacclandingBtnAddressedit;
	@FindBy(locator = "myacclanding.lbl.addressnickname1")
	private QAFWebElement myacclandingLblAddressnickname1;
	

	public QAFWebElement getMyacclandingLnkEditcommPref() {
		return myacclandingLnkEditcommPref;
	}


	public QAFWebElement getMyacclandingLnkCreatepharmprof() {
		return myacclandingLnkCreatepharmprof;
	}


	public QAFWebElement getMyacclandingLnkManagecreditcards() {
		return myacclandingLnkManagecreditcards;
	}


	public QAFWebElement getMyacclandingLblEmail() {
		return myacclandingLblEmail;
	}


	public QAFWebElement getMyacclandingLnkEditprofile() {
		return myacclandingLnkEditprofile;
	}


	public QAFWebElement getMyacclandingLblUsername() {
		return myacclandingLblUsername;
	}


	public QAFWebElement getMyacclandingLnkChangepassword() {
		return myacclandingLnkChangepassword;
	}


	public QAFWebElement getMyacclandingLnkProfileinformation() {
		return myacclandingLnkProfileinformation;
	}


	public QAFWebElement getMyacclandingLblPagetitle() {
		return myacclandingLblPagetitle;
	}


	public QAFWebElement getMyacclandingLnkAddressbook() {
		return myacclandingLnkAddressbook;
	}


	public QAFWebElement getMyacclandingBtnAddressedit() {
		// TODO Auto-generated method stub
		return myacclandingBtnAddressedit;
	}
	
	public QAFWebElement getMyacclandingLblAddressnickname1() {
		return myacclandingLblAddressnickname1;
	}



}