package com.automation.web.pages.coupons;

import java.util.List;

import com.automation.web.components.coupons.DigitalCouponBlocksInSelectedSection;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class DigitalCouponsLoginPopupTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "dcloginpopup.img.popupclose")
	private QAFWebElement imgPopupclose;

	@FindBy(locator = "dcloginpopup.lbl.popuptext")
	private QAFWebElement lblPopuptext;
	
	@FindBy(locator = "dcloginpopup.btn.login")
	private QAFWebElement btnLogin;

	@FindBy(locator = "dcloginpopup.btn.guest")
	private QAFWebElement btnGuest;
	
	@FindBy(locator = "dcloginpopup.lnk.register")
	private QAFWebElement lnkRegister;

	public QAFWebElement getImgPopupclose() {
		return imgPopupclose;
	}

	public QAFWebElement getLblPopuptext() {
		return lblPopuptext;
	}
	
	public QAFWebElement getBtnLogin() {
		return btnLogin;
	}
	
	public QAFWebElement getBtnGuest() {
		return btnGuest;
	}
	
	public QAFWebElement getLnkRegister() {
		return lnkRegister;
	}

}