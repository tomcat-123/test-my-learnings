package com.automation.web.pages.recipes;

import java.util.List;

import com.automation.web.components.RecipeItems;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RecipecategorydetailaTestPage
		extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "recipecdp.list.recipeitems")
	private List<RecipeItems> recipecdpListRecipeitems;
	@FindBy(locator = "recipecdp.lbl.recipename")
	private QAFWebElement recipecdpLblRecipename;
	@FindBy(locator = "recipecdp.lbl.pageheader")
	private QAFWebElement recipecdpLblPageheader;
	@FindBy(locator = "recipecdp.lbl.recipegridview")
	private QAFWebElement recipecdpLblRecipegridview;
	@FindBy(locator = "recipecdp.lbl.recipelistview")
	private QAFWebElement recipecdpLblRecipelistview;
	@FindBy(locator = "recipecdp.lbl.sortby")
	private QAFWebElement recipecdpLblSortby;
	@FindBy(locator = "recipecdp.txt.sortbydropdown")
	private QAFWebElement recipecdpTxtSortbydropdown;
	@FindBy(locator = "recipecdp.lbl.resultcount")
	private QAFWebElement recipecdpLblResultcount;
	@FindBy(locator = "recipecdp.lbl.results")
	private QAFWebElement recipecdpLblResults;
	@FindBy(locator = "recipecdp.lbl.filterby")
	private QAFWebElement recipecdpLblFilterby;
	@FindBy(locator = "recipecdp.chk.filterbyoptionsdynamic")
	private QAFWebElement recipecdpChkFilterbyoptionsdynamic;
	@FindBy(locator = "recipecdp.chk.filterbyoptionslist")
	private List<QAFWebElement> recipecdpChkFilterbyoptionslist;
	@FindBy(locator = "recipecdp.lbl.filterbyoptionslist")
	private List<QAFWebElement> recipecdpLblFilterbyoptionslist;
	@FindBy(locator = "recipecdp.btn.loadmoreitems")
	private QAFWebElement recipecdpBtnLoadmoreitems;
	@FindBy(locator = "recipecdp.lbl.totalorcooktime")
	private List<QAFWebElement> recipecdpLblTotalorcooktime;
	

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}
	
	public QAFWebElement getRecipeImage(String listno) {
		String loc = String.format(pageProps.getString("recipecdp.get.lbl.recipeimage"), listno);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getRecipeName(String listno) {
		String loc = String.format(pageProps.getString("recipecdp.get.lbl.recipename"), listno);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getRecipeRating(String listno) {
		String loc = String.format(pageProps.getString("recipecdp.get.lbl.reciperating"), listno);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getRecipeAdd2List(String listno) {
		String loc = String.format(pageProps.getString("recipecdp.get.lbl.add2list"), listno);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getRecipeAdd2RecipeBox(String listno) {
		String loc = String.format(pageProps.getString("recipecdp.get.lbl.add2recipebox"), listno);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getRecipeNameAlter(String listno) {
		String loc = String.format(pageProps.getString("recipecdp.get.lbl.recipenamealter"), listno);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getRecipeRatingAlter(String listno) {
		String loc = String.format(pageProps.getString("recipecdp.get.lbl.reciperatingalter"), listno);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getRecipeAdd2ListAlter(String listno) {
		String loc = String.format(pageProps.getString("recipecdp.get.lbl.add2listalter"), listno);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getRecipeAdd2RecipeBoxAlter(String listno) {
		String loc = String.format(pageProps.getString("recipecdp.get.lbl.add2recipeboxalter"), listno);
		return new QAFExtendedWebElement(loc);
	}

	public List<RecipeItems> getRecipecdpListRecipeitems() {
		return recipecdpListRecipeitems;
	}

	public QAFWebElement getRecipecdpLblRecipename() {
		return recipecdpLblRecipename;
	}
	public QAFWebElement getLblPageheader() {
		return recipecdpLblPageheader;
	}

	public QAFWebElement getLblRecipegridview() {
		return recipecdpLblRecipegridview;
	}

	public QAFWebElement getLblRecipelistview() {
		return recipecdpLblRecipelistview;
	}

	public QAFWebElement getLblSortby() {
		return recipecdpLblSortby;
	}

	public QAFWebElement getTxtSortbydropdown() {
		return recipecdpTxtSortbydropdown;
	}

	public QAFWebElement getLblResultcount() {
		return recipecdpLblResultcount;
	}

	public QAFWebElement getLblResults() {
		return recipecdpLblResults;
	}

	public QAFWebElement getLblFilterby() {
		return recipecdpLblFilterby;
	}

	public QAFWebElement getChkFilterbyoptionsdynamic() {
		return recipecdpChkFilterbyoptionsdynamic;
	}

	public List<QAFWebElement> getChkFilterbyoptionslist() {
		return recipecdpChkFilterbyoptionslist;
	}

	public List<QAFWebElement> getLblFilterbyoptionslist() {
		return recipecdpLblFilterbyoptionslist;
	}
	
	public QAFWebElement getBtnLoadmoreitems() {
		return recipecdpBtnLoadmoreitems;
	}
	
	public List<QAFWebElement> getLblTotalorcooktime() {
		return recipecdpLblTotalorcooktime;
	}

	
}
