package com.automation.web.pages.storelocator;

import java.util.List;

import com.automation.web.commonutils.PerfectoUtils;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class StoreLocatorTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "storelocator.lnk.findstore")
	private QAFWebElement LnkFindStore;
	@FindBy(locator = "storelocator.tbx.findstore")
	private QAFWebElement TbxFindStore;
	@FindBy(locator = "storelocator.btn.find")
	private QAFWebElement BtnFind;
	@FindBy(locator = "storelocator.txt.findastore")
	private QAFWebElement TxtFindAStore;
	@FindBy(locator = "storelocator.tbx.enterstore")
	private QAFWebElement TbxEnterStore;
	@FindBy(locator = "storelocator.txt.storeresult")
	private QAFWebElement TxtStoreResult;
	@FindBy(locator = "storelocator.cbx.firstcheckbox")
	private QAFWebElement CbxFirstCheckBox;
	@FindBy(locator = "storelocator.txt.storersname")
	private List<QAFWebElement> TxtStorersName;
	@FindBy(locator = "storelocator.cbx.lastcheckbox")
	private QAFWebElement CbxLastCheckBox;
	@FindBy(locator = "storelocator.btn.Search")
	private QAFWebElement BtnSearch;
	@FindBy(locator = "storelocator.txt.errmsg")
	private QAFWebElement TxtErrMsg;
	@FindBy(locator = "storelocator.txt.mainerrmsg")
	private QAFWebElement TxtMainErrmsg;
	@FindBy(locator = "storelocator.lnk.storedetails")
	private QAFWebElement LnkStoreDetails;
	@FindBy(locator = "storedetail.txt.storename")
	private QAFWebElement TxtStoreName;
	@FindBy(locator = "storedetail.txt.mainphone")
	private QAFWebElement TxtMainPhone;
	@FindBy(locator = "storedetail.txt.pharmacyphone")
	private QAFWebElement TxtPharmacyPhone;
	@FindBy(locator = "storedetail.txt.pharmacy")
	private QAFWebElement TxtPharmacy;
	@FindBy(locator = "storelocator.ddl.distance")
	private QAFWebElement DdlDistance;
	@FindBy(locator = "storelocator.btn.loadmorestores")
	private QAFWebElement BtnLoadMoreStores;
	@FindBy(locator = "storelocator.txt.updatedcount")
	private QAFWebElement TxtUpdatedCount;

	@FindBy(locator = "storelocator.lnk.changestore")
	private QAFWebElement LnkChangestore;
	
	@FindBy(locator = "storelocator.lnk.getdirections")
	private QAFWebElement LnkGetdirections;
	@FindBy(locator = "storelocator.lnk.viewstoread")
	private QAFWebElement LnkViewstoread;
	@FindBy(locator="storelocator.lbl.errorsection")
	private QAFWebElement lblErrorSection;
	@FindBy(locator="storelocator.lnk.changehomestore")
	private QAFWebElement lnkChangeHomeStore ;
	
	@FindBy(locator="storelocator.txt.findstoreaddress")
	private QAFWebElement TxtFindStoreAddress ;
	
	@FindBy(locator="storelocator.lbl.storeheadertxt")
	private QAFWebElement lblStoreHeaderTxt ;
	
	@FindBy(locator="storelocator.txt.findstoredropaddress")
	private QAFWebElement TxtFindStoreDropAddress ;
	@FindBy(locator="storelocator.txt.zipcodeunderresults")
	private QAFWebElement TxtZipcodeUnderResults ;
	@FindBy(locator="storelocator.txt.curbside")
	private QAFWebElement TxtCurbside ;
	
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}
	
	public QAFWebElement getTxtZipcodeUnderResults() {
		return TxtZipcodeUnderResults;
	}
	
	public QAFWebElement getLblStoreHeaderTxt() {
		return lblStoreHeaderTxt;
	}
	
	public QAFWebElement getTxtFindStoreDropAddress() {
		return TxtFindStoreDropAddress;
	}
	
	public QAFWebElement getTxtFindStoreAddress() {
		return TxtFindStoreAddress;
	}

	public QAFWebElement getLnkFindStore() {
		return LnkFindStore;
	}


	public QAFWebElement getTbxFindStore() {
		return TbxFindStore;
	}

	public QAFWebElement getBtnFind() {
		return BtnFind;
	}

	public QAFWebElement getTxtFindAStore() {
		return TxtFindAStore;
	}

	public QAFWebElement getTbxEnterStore() {
		return TbxEnterStore;
	}

	public QAFWebElement getTxtStoreResult() {
		return TxtStoreResult;
	}

	public List<QAFWebElement> getTxtStorersName() {
		return TxtStorersName;
	}

	public QAFWebElement getCbxFirstCheckBox() {
		return CbxFirstCheckBox;
	}

	public QAFWebElement getCbxLastCheckBox() {
		return CbxLastCheckBox;
	}

	public QAFWebElement getBtnSearch() {
		return BtnSearch;
	}

	public QAFWebElement getTxtErrMsg() {
		return TxtErrMsg;
	}

	public QAFWebElement getTxtMainErrmsg() {
		return TxtMainErrmsg;
	}

	public QAFWebElement getLnkStoreDetails() {
		return LnkStoreDetails;
	}

	public QAFWebElement getTxtStoreName() {
		return TxtStoreName;
	}

	public QAFWebElement getTxtMainPhone() {
		return TxtMainPhone;
	}

	public QAFWebElement getTxtPharmacyPhone() {
		return TxtPharmacyPhone;
	}

	public QAFWebElement getTxtPharmacy() {
		return TxtPharmacy;
	}

	public QAFWebElement getDdlDistance() {
		return DdlDistance;
	}

	public QAFWebElement getBtnLoadMoreStores() {
		return BtnLoadMoreStores;
	}

	public QAFWebElement getTxtUpdatedCount() {
		return TxtUpdatedCount;
	}
	public QAFWebElement getLnkChangestore() {
		return LnkChangestore;
	}

	public QAFWebElement getLnkGetdirections() {
		return LnkGetdirections;
	}

	public QAFWebElement getLnkViewstoread() {
		return LnkViewstoread;
	}
	public QAFWebElement getLblErrorSection() {
		return lblErrorSection;
	}
	
	public QAFWebElement getLnkChangeHomeStore() {
		return lnkChangeHomeStore;
	}

	/**
	 * @return the txtCurbside
	 */
	public QAFWebElement getTxtCurbside() {
		return TxtCurbside;
	}

	/**
	 * @param txtCurbside the txtCurbside to set
	 */
	public void setTxtCurbside(QAFWebElement txtCurbside) {
		TxtCurbside = txtCurbside;
	}
	
	public QAFWebElement getStoreResultsStoreName(String listnum, String storenum) {
		String reElm = String.format(pageProps.getString("storelocator.get.lbl.storeresultsstorename"), listnum, storenum);
		return new QAFExtendedWebElement(reElm);
	}
	
	public QAFWebElement getSelstoreGetBtnStoreselectwithstoreid(String item){ 
		String retElm = String.format(pageProps.getString("storelocator.get.btn.storeselectwithstoreid"), item, item);
	    return new QAFExtendedWebElement(retElm);
	}
	/**
	 * TextView for store name dynamic
	 */
	public QAFWebElement getSelstoreGetLblStorename(String item){ 
		String retElm = String.format(pageProps.getString("storelocator.get.lbl.storename"), item);
	    return new QAFExtendedWebElement(retElm);
	}
	
	/**
	 * TextView for ViewDetails
	 */
	public QAFWebElement getSelstoreGetLblStoreid(String item){ 
		String retElm = String.format(pageProps.getString("storelocator.get.lbl.storeid"), item);
	    return new QAFExtendedWebElement(retElm);
	}

}
