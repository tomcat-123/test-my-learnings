package com.automation.web.pages.cart;

import java.util.List;

import com.automation.web.components.Shoppingcart;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CartTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "cart.lbl.errormsg")
	private QAFWebElement cartLblErrormsg;
	
	@FindBy(locator = "cart.lbl.header")
	private QAFWebElement cartLblHeader;
	
	@FindBy(locator = "cart.img.logo")
	private QAFWebElement cartImgLogo;
	
	@FindBy(locator = "cart.img.footerlogo")
	private QAFWebElement cartImgFooterlogo;

	@FindBy(locator = "cart.li.lnk.remove")
	private List<QAFWebElement> cartLiLnkRemove;

	@FindBy(locator = "cart.lnk.remove")
	private QAFWebElement cartLnkRemove;

	@FindBy(locator = "cart.btn.yes")
	private QAFWebElement cartBtnYes;

	@FindBy(locator = "cart.btn.minus")
	private QAFWebElement cartBtnMinus;

	@FindBy(locator = "cart.btn.checkout")
	private QAFWebElement cartBtnCheckout;

	@FindBy(locator = "cart.lnk.continueshopping")
	private QAFWebElement cartLnkContinueshopping;

	@FindBy(locator = "cart.btn.apply")
	private QAFWebElement cartBtnApply;

	@FindBy(locator = "cart.box.cartproductblock")
	private QAFWebElement cartBoxCartproductblock;
	
	@FindBy(locator = "cart.box.cartproductblock")
	private List<Shoppingcart> cartBoxCartproductblockComp;

	@FindBy(locator = "cart.lbl.productname")
	private QAFWebElement cartLblProductname;

	@FindBy(locator = "cart.lbl.productinfo")
	private QAFWebElement cartLblProductinfo;

	@FindBy(locator = "cart.btn.update")
	private QAFWebElement cartBtnUpdate;

	@FindBy(locator = "cart.edt.qty")
	private QAFWebElement cartEdtQty;

	@FindBy(locator = "cart.lbl.subtotal")
	private QAFWebElement cartLblSubtotal;

	@FindBy(locator = "cart.lbl.itemtotal")
	private QAFWebElement cartLblItemtotal;
	
	@FindBy(locator = "cart.lbl.egiftcardname")
	private QAFWebElement cartLblEgiftcardname;

	@FindBy(locator = "cart.btn.egiftcardremove")
	private QAFWebElement cartBtnEgiftcardremove;

	@FindBy(locator = "cart.lbl.physicalgiftcardname")
	private QAFWebElement cartLblPhysicalgiftcardname;

	@FindBy(locator = "cart.btn.physicalgiftcardremove")
	private QAFWebElement cartBtnPhysicalgiftcardremove;

	@FindBy(locator = "cart.lbl.removeitempopuptitle")
	private QAFWebElement cartLblRemoveitempopuptitle;

	@FindBy(locator = "cart.btn.cancel")
	private QAFWebElement cartBtnCancel;
	
	@FindBy(locator = "cart.lnk.editdetails")
	private QAFWebElement cartLnkEditdetails;
	
	@FindBy(locator = "cart.lbl.editheader")
	private QAFWebElement cartLblEditheader;
	
	@FindBy(locator = "cart.edt.editqty")
	private QAFWebElement cartEdtEditqty;
	
	@FindBy(locator = "cart.btn.editupdate")
	private QAFWebElement cartBtnEditupdate;
	
	@FindBy(locator = "cart.lbl.discountvalue")
	private QAFWebElement cartLblDiscountvalue;

	@FindBy(locator = "cart.lbl.estimatedshipdate")
	private QAFWebElement cartLblEstimatedShipDate;
	
	@FindBy(locator = "cart.lbl.ordersubtotal")
	private QAFWebElement cartLblOrderSubtotal;  
	
	@FindBy(locator = "cart.lbl.discounts")
	private QAFWebElement cartLblDiscounts;
	
	@FindBy(locator = "cart.lbl.estimatedtax")
	private QAFWebElement cartLblEstimatedTax;
	
	@FindBy(locator = "cart.lbl.ordertotal")
	private QAFWebElement cartLblOrderTotal;
	
	@FindBy(locator = "cart.lbl.instorepickup")
	private QAFWebElement cartLblInstorePickup;
	
	@FindBy(locator = "cart.lbl.nospecialhandling")
	private QAFWebElement cartLblNospecialhandling;
	
	@FindBy(locator = "cart.lbl.specialhandling")
	private QAFWebElement cartLblSpecialhandling;
		
	@FindBy(locator = "cart.lbl.morediscounts")
	private QAFWebElement cartLblMoreDiscounts;
	
	@FindBy(locator = "cart.lbl.morediscountsvalue")
	private QAFWebElement cartLblMoreDiscountsValue;
	
	@FindBy(locator = "cart.lbl.taxvalue")
	private QAFWebElement cartLblTaxValue; 
	
	@FindBy(locator = "cart.lbl.ordertotalvalue")
	private QAFWebElement cartLblOrderTotalValue;
	
	@FindBy(locator = "cart.lbl.ordersubtotalvalue") 
	private QAFWebElement cartLblOrderSubtotalValue;
	
	@FindBy(locator = "cart.lbl.subtotalvalue")
	private QAFWebElement cartLblSubtotalvalue;
	
	@FindBy(locator = "cart.btn.editupdateegc")
	private QAFWebElement cartBtnEditupdateegc;
	
	@FindBy(locator = "cart.edt.physicalgiftcardqty")
	private QAFWebElement cartEdtPhysicalgiftcardqty; 

	@FindBy(locator = "cart.lbl.imageview")
	private QAFWebElement cartlblimageview;
	
	@FindBy(locator = "cart.lbl.minqty")
	private QAFWebElement lblminqty;
	
	@FindBy(locator = "cart.txt.promotionalcode")
	private QAFWebElement txtPromotionalcode;
	
	@FindBy(locator = "cart.lnk.removepromotionalcode")
	private QAFWebElement lnkRemovePromotionalcode;
	
	@FindBy(locator = "cart.lbl.shippingvalue")
	private QAFWebElement lblShippingvalue;
	
	@FindBy(locator = "cart.lnk.carticon")
	private QAFWebElement lnkCarticon;
	
	@FindBy(locator = "cart.lbl.cartitemname")
	private QAFWebElement lblCartItemName;
	
	/**
	 * Textview of SubTotal Value
	 */
	public QAFWebElement getCartLblSubtotalvalue() {
		return cartLblSubtotalvalue;
	}
	
	/**
	 * Textview of Shopping Cart
	 */
	public QAFWebElement getCartLblHeader(){ return cartLblHeader; }
	
	public QAFWebElement getCartLblCartItemName(){ return lblCartItemName; }
	
	public QAFWebElement getCartLblShippingvalue(){ return lblShippingvalue; }
	
	public QAFWebElement getCartLnkCarticon(){ return lnkCarticon; }
	
	public QAFWebElement getCartImgLogo(){ return cartImgLogo; }
	
	public QAFWebElement getCartImgFooterlogo(){ return cartImgFooterlogo; }
	
	public QAFWebElement getCartTxtPromotionalcode(){ return txtPromotionalcode; }
	
	public QAFWebElement getCartLnkRemovePromotionalcode(){ return lnkRemovePromotionalcode; }
	
	public QAFExtendedWebElement getCartTxtUpdate(int item) {
		String retElm = String.format(pageProps.getString("cart.txt.update"), item);
		return new QAFExtendedWebElement(retElm);
	}

	/**
	 * ListLinkView for Remove Item
	 */
	public List<QAFWebElement> getCartLiLnkRemove(){ return cartLiLnkRemove; }

	/**
	 * LinkView for Remove Item
	 */
	public QAFWebElement getCartLnkRemove(){ return cartLnkRemove; }

	/**
	 * ButtonView for Yes
	 */
	public QAFWebElement getCartBtnYes(){ return cartBtnYes; }

	/**
	 * ButtonView for Minus
	 */
	public QAFWebElement getCartBtnMinus(){ return cartBtnMinus; }

	/**
	 * ButtonView for Checkout
	 */
	public QAFWebElement getCartBtnCheckout(){ return cartBtnCheckout; }

	/**
	 * LinkView for Continue Shopping
	 */
	public QAFWebElement getCartLnkContinueshopping(){ return cartLnkContinueshopping; }

	/**
	 * ButtonView for Apply
	 */
	public QAFWebElement getCartBtnApply(){ return cartBtnApply; }

	/**
	 * ProductBlockView of Products
	 */
	public QAFWebElement getCartBoxCartproductblock(){ return cartBoxCartproductblock; }

	/**
	 * TextView for Product Name
	 */
	public QAFWebElement getCartLblProductname(){ return cartLblProductname; }

	/**
	 * TextView for Product Info
	 */
	public QAFWebElement getCartLblProductinfo(){ return cartLblProductinfo; }

	/**
	 * ButtonView for Update icon
	 */
	public QAFWebElement getCartBtnUpdate(){ return cartBtnUpdate; }

	/**
	 * EditTextView for Quantity
	 */
	public QAFWebElement getCartEdtQty(){ return cartEdtQty; }

	/**
	 * TextView for SubTotal
	 */
	public QAFWebElement getCartLblSubtotal(){ return cartLblSubtotal; }

	/**
	 * TextView for Item Total
	 */
	public QAFWebElement getCartLblItemtotal(){ return cartLblItemtotal; }
	
	public QAFWebElement getCartLblEgiftcardname() {
		return cartLblEgiftcardname;
	}


	public QAFWebElement getCartBtnEgiftcardremove() {
		return cartBtnEgiftcardremove;
	}


	public QAFWebElement getCartLblPhysicalgiftcardname() {
		return cartLblPhysicalgiftcardname;
	}


	public QAFWebElement getCartBtnPhysicalgiftcardremove() {
		return cartBtnPhysicalgiftcardremove;
	}


	public QAFWebElement getCartLblRemoveitempopuptitle() {
		return cartLblRemoveitempopuptitle;
	}


	public QAFWebElement getCartBtnCancel() {
		return cartBtnCancel;
	}
	
	public List<Shoppingcart> getCartBoxCartproductblockComp() {
		return cartBoxCartproductblockComp;
	}
	
	public QAFWebElement getCartLnkEditdetails() {
		return cartLnkEditdetails;
	}


	public QAFWebElement getCartLblEditheader() {
		return cartLblEditheader;
	}


	public QAFWebElement getCartEdtEditqty() {
		return cartEdtEditqty;
	}


	public QAFWebElement getCartBtnEditupdate() {
		return cartBtnEditupdate;
	}
	
	public QAFWebElement getCartLblDiscountvalue() {
		return cartLblDiscountvalue;
	}
	     
	public QAFWebElement getCartLblEstimatedShipDate() {
		return cartLblEstimatedShipDate;
	}
	
	public QAFWebElement getCartLblOrderSubtotal() {
		return cartLblOrderSubtotal;
	}
	
	public QAFWebElement getCartLblDiscounts() {
		return cartLblDiscounts;
	}
	
	public QAFWebElement getCartLblEstimatedTax() {
		return cartLblEstimatedTax;
	}
	
	public QAFWebElement getCartLblOrderTotal() {
		return cartLblOrderTotal;
	}
	
	public QAFWebElement getCartLblInstorePickup() {
		return cartLblInstorePickup;
	}
	
	public QAFWebElement getCartLblNospecialhandling() {
		return cartLblNospecialhandling;
	}
	
	public QAFWebElement getCartLblSpecialhandling() {
		return cartLblSpecialhandling;
	}
	 
	public QAFWebElement getCartLblMoreDiscounts() {
		return cartLblMoreDiscounts;
	}
	
	public QAFWebElement getCartLblMoreDiscountsValue() {
		return cartLblMoreDiscountsValue;
	}
	
	public QAFWebElement getCartLblTaxValue() {  
		return cartLblTaxValue;
	}

	public QAFWebElement getCartLblOrderSubtotalValue() {
		return cartLblOrderSubtotalValue;
	}
	
	public QAFWebElement getCartLblOrderTotalValue() {
		return cartLblOrderTotalValue;
	}
	
	public QAFWebElement getCartBtnEditupdateegc() {
		return cartBtnEditupdateegc;
	}
	
	public QAFWebElement getCartEdtPhysicalgiftcardqty() {
		return cartEdtPhysicalgiftcardqty;
	}

	public QAFWebElement getCartLblImageView() {
		return cartlblimageview;
	}
	
	public QAFWebElement getLblMinqty() {
		return lblminqty;
	}
	
	public QAFWebElement getCartLblErrormsg() {
		return cartLblErrormsg;
	}
}