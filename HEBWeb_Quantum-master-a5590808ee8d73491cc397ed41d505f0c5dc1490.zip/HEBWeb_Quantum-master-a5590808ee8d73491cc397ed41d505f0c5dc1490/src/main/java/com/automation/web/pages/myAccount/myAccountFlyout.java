package com.automation.web.pages.myAccount;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class myAccountFlyout extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "myaccflyout.lnk.myaccount")
	private QAFWebElement myaccflyoutLnkMyaccount;

	@FindBy(locator = "myaccflyout.lnk.logout")
	private QAFWebElement myaccflyoutLnkLogout;
	@FindBy(locator = "myaccflyout.lnk.changemystore")
	private QAFWebElement myaccflyoutLnkChangemystore;

	public QAFWebElement getMyaccflyoutLnkChangemystore() {
		return myaccflyoutLnkChangemystore;
	}


	/**
	 * Text view of email
	 */
	public QAFWebElement getLnkMyaccount(){ return myaccflyoutLnkMyaccount; }


	public QAFWebElement getMyaccflyoutLnkLogout() {
		return myaccflyoutLnkLogout;
	}


}