package com.automation.web.databean;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.qmetry.qaf.automation.data.BaseFormDataBean;
import com.qmetry.qaf.automation.ui.annotations.UiElement;
import com.qmetry.qaf.automation.util.RandomStringGenerator.RandomizerTypes;
import com.qmetry.qaf.automation.util.Randomizer;

public class CheckOutRegistrationBean extends BaseFormDataBean{

		@Randomizer(type=RandomizerTypes.LETTERS_ONLY, length = 4)
		@UiElement(fieldLoc = "checkout.edt.newuserfname",order = 1)
		private String firstName;
		
		@Randomizer(type=RandomizerTypes.LETTERS_ONLY, length = 4)
		@UiElement(fieldLoc = "checkout.edt.newuserlastname",order = 2)
		private String lastName;
		
		@Randomizer(type=RandomizerTypes.LETTERS_ONLY, length = 4, suffix = "@autoemail.com")
		@UiElement(fieldLoc = "checkout.edt.newuseremail",order = 3)
		private String email;

		@UiElement(fieldLoc = "checkout.edt.newuserpassword",order = 4)
		private String password;
		
		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}
		
}
