package com.automation.web.pages.weeklyads;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class WeeklyAdsAndCouponsPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "Wklyadscoupons.lbl.pageheader")
	private QAFWebElement lblPageheader;
	
	@FindBy(locator = "Wklyadscoupons.lnk.loginunderdigitalbanner")
	private QAFWebElement lnkLoginunderDigitalbanner;
	
	@FindBy(locator = "Wklyadscoupons.lnk.signupnow")
	private QAFWebElement lnkSignUpNow;
	
	@FindBy(locator = "Wklyadscoupons.lnk.learnmoreaboutdigitalcoupons")
	private QAFWebElement lnkLearnMoreaboutDigitalcoupons;

	@FindBy(locator = "Wklyadscoupons.lbl.yourwklyads")
	private QAFWebElement lblYourwklyads;

	@FindBy(locator = "Wklyadscoupons.lbl.couponscenter")
	private QAFWebElement lblCouponscenter;

	@FindBy(locator = "Wklyadscoupons.img.yourwklyadsimg")
	private QAFWebElement imgYourwklyadsimg;

	@FindBy(locator = "Wklyadscoupons.img.couponscenterimg")
	private QAFWebElement imgCouponscenterimg;

	@FindBy(locator = "Wklyadscoupons.txt.enterzipcode")
	private QAFWebElement txtEnterzipcode;

	@FindBy(locator = "Wklyadscoupons.btn.go")
	private QAFWebElement btnGo;

	@FindBy(locator = "Wklyadscoupons.lnk.logintoaccount")
	private QAFWebElement lnkLogintoaccount;

	@FindBy(locator = "Wklyadscoupons.btn.seedigitalcoupons")
	private QAFWebElement btnSeedigitalcoupons;
	
	@FindBy(locator = "Wklyadscoupons.lnk.viewdigitalcoupons")
	private QAFWebElement btnViewdigitalcoupons;

	@FindBy(locator = "Wklyadscoupons.lnk.learnmoreabtcoupons")
	private QAFWebElement lnkLearnmoreabtcoupons;

	@FindBy(locator = "Wklyadscoupons.lnk.checkoutmobapp")
	private QAFWebElement lnkCheckoutmobapp;

	@FindBy(locator = "Wklyadscoupons.lnk.digitalcouponsfaqs")
	private QAFWebElement lnkDigitalcouponsfaqs;

	@FindBy(locator = "Wklyadscoupons.lbl.digitalcoupons")
	private QAFWebElement lblDigitalcoupons;

	@FindBy(locator = "Wklyadscoupons.lbl.printablecoupons")
	private QAFWebElement lblPrintablecoupons;

	@FindBy(locator = "Wklyadscoupons.btn.seeandprintcoupons")
	private QAFWebElement btnSeeandprintcoupons;

	@FindBy(locator = "Wklyadscoupons.lnk.viewcouponspolicy")
	private QAFWebElement lnkViewcouponspolicy;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblPageheader() {
		return lblPageheader;
	}
	
	public QAFWebElement getLnkLoginunderDigitalbanner() {
		return lnkLoginunderDigitalbanner;
	}
	
	public QAFWebElement getLnkSignUpNow() {
		return lnkSignUpNow;
	}
	
	public QAFWebElement getLnkLearnMoreaboutDigitalcoupons() {
		return lnkLearnMoreaboutDigitalcoupons;
	}

	public QAFWebElement getLblYourwklyads() {
		return lblYourwklyads;
	}

	public QAFWebElement getLblCouponscenter() {
		return lblCouponscenter;
	}

	public QAFWebElement getImgYourwklyadsimg() {
		return imgYourwklyadsimg;
	}

	public QAFWebElement getImgCouponscenterimg() {
		return imgCouponscenterimg;
	}

	public QAFWebElement getTxtEnterzipcode() {
		return txtEnterzipcode;
	}

	public QAFWebElement getBtnGo() {
		return btnGo;
	}

	public QAFWebElement getLnkLogintoaccount() {
		return lnkLogintoaccount;
	}

	public QAFWebElement getBtnSeedigitalcoupons() {
		return btnSeedigitalcoupons;
	}
	
	public QAFWebElement getBtnViewdigitalcoupons() {
		return btnViewdigitalcoupons;
	}

	public QAFWebElement getLnkLearnmoreabtcoupons() {
		return lnkLearnmoreabtcoupons;
	}

	public QAFWebElement getLnkCheckoutmobapp() {
		return lnkCheckoutmobapp;
	}

	public QAFWebElement getLnkDigitalcouponsfaqs() {
		return lnkDigitalcouponsfaqs;
	}

	public QAFWebElement getLblDigitalcoupons() {
		return lblDigitalcoupons;
	}

	public QAFWebElement getLblPrintablecoupons() {
		return lblPrintablecoupons;
	}

	public QAFWebElement getBtnSeeandprintcoupons() {
		return btnSeeandprintcoupons;
	}

	public QAFWebElement getLnkViewcouponspolicy() {
		return lnkViewcouponspolicy;
	}

}
