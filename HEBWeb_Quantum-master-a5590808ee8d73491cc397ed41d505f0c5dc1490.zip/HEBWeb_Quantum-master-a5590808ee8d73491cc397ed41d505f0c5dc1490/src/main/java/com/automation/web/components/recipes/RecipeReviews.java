package com.automation.web.components.recipes;

import java.util.List;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RecipeReviews extends QAFWebComponent {

	@FindBy(locator = "recipedetail.li.img.reviewlabels")
	private List<QAFWebElement> recipedetailLiImgReviewlabels;

	public RecipeReviews(String locator) {
		super(locator);
	}

	public List<QAFWebElement> getRecipedetailLiImgReviewlabels() {
		return recipedetailLiImgReviewlabels;
	}
	
}
