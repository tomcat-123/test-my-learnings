package com.automation.web.pages.myAccount;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class profileInformationTestpage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}
	@FindBy(locator = "profile.lbl.profileinfotitle")
	private QAFWebElement profileLblProfileinfotitle;
	@FindBy(locator = "profile.icon.profileinfobullet")
	private QAFWebElement profileIconProfileinfobullet;
	@FindBy(locator = "profile.icon.changepwdbullet")
	private QAFWebElement profileIconChangepwdbullet;
	@FindBy(locator = "profile.lbl.myhebstore")
	private QAFWebElement profileLblMyyhebstore;
	@FindBy(locator = "profile.lbl.myhebstorebanner")
	private QAFWebElement profileLblMyhebstorebanner;
	@FindBy(locator = "profile.lnk.editstore")
	private QAFWebElement profileLnkEditstore;
	@FindBy(locator = "profile.lbl.myhebstorename")
	private QAFWebElement profileLblMyhebstorename;
	@FindBy(locator = "profile.lnk.getdirection")
	private QAFWebElement profileLnkGetdirection;
	@FindBy(locator = "profile.lnk.seestoredetail")
	private QAFWebElement profileLnkSeestoredetail;
	@FindBy(locator = "profile.lbl.mapview")
	private QAFWebElement profileLblMapview;
	@FindBy(locator = "profile.lbl.storeselector")
	private QAFWebElement profileLblStoreselector;
	@FindBy(locator = "profile.txt.zipcode")
	private QAFWebElement profileTxtZipcode;
	@FindBy(locator = "profile.btn.go")
	private QAFWebElement profileBtnGo;
	@FindBy(locator = "profile.lbl.storenamelist")
	private List<QAFWebElement> profileLblStorenamelist;
	@FindBy(locator = "profile.lbl.selectbuttonlist")
	private List<QAFWebElement> profileLblSelectbuttonlist;
	@FindBy(locator = "profile.lbl.storeselectorclose")
	private QAFWebElement profileLblStoreselectorclose;
	@FindBy(locator = "profile.txt.currentpwd")
	private QAFWebElement profileTxtCurrentpwd;
	@FindBy(locator = "profile.txt.newpwd")
	private QAFWebElement profileTxtNewpwd;
	@FindBy(locator = "profile.txt.confirmnewpwd")
	private QAFWebElement profileTxtConfirmnewpwd;
	@FindBy(locator = "profile.btn.savepwd")
	private QAFWebElement profileBtnSavePwd;
	@FindBy(locator = "profile.icon.pwdtickmark")
	private QAFWebElement profileIconPwdtickmark;
	@FindBy(locator = "profile.txt.firstname")
	private QAFWebElement profileTxtFirstName;
	@FindBy(locator = "profile.txt.lastname")
	private QAFWebElement profileTxtLastName;
	@FindBy(locator = "profile.btn.saveprofile")
	private QAFWebElement profileBtnSaveprofile;
	@FindBy(locator = "profile.txt.screenname")
	private QAFWebElement profileTxtScreenname;
	@FindBy(locator = "profile.txt.streetaddress")
	private QAFWebElement profileTxtStreetaddress;
	@FindBy(locator = "profile.txt.streetaddress2")
	private QAFWebElement profileTxtStreetaddress2;
	@FindBy(locator = "profile.txt.city")
	private QAFWebElement profileTxtCity;
	@FindBy(locator = "profile.txt.profzipcode")
	private QAFWebElement profileTxtprofZipcode;
	@FindBy(locator = "profile.lbl.state")
	private QAFWebElement profileLblState;
	
	
	public QAFWebElement getProfileTxtScreenname() {
		return profileTxtScreenname;
	}


	public QAFWebElement getProfileTxtStreetaddress() {
		return profileTxtStreetaddress;
	}


	public QAFWebElement getProfileTxtStreetaddress2() {
		return profileTxtStreetaddress2;
	}


	public QAFWebElement getProfileTxtCity() {
		return profileTxtCity;
	}


	public QAFWebElement getProfileTxtprofZipcode() {
		return profileTxtprofZipcode;
	}


	public QAFWebElement getProfileLblState() {
		return profileLblState;
	}


	public QAFWebElement getProfileTxtFirstName() {
		return profileTxtFirstName;
	}


	public QAFWebElement getProfileTxtLastName() {
		return profileTxtLastName;
	}


	public QAFWebElement getProfileBtnSaveprofile() {
		return profileBtnSaveprofile;
	}


	public QAFWebElement getProfileTxtEmail() {
		return profileTxtEmail;
	}
	@FindBy(locator = "profile.txt.email")
	private QAFWebElement profileTxtEmail;
	
	public QAFWebElement getProfileTxtCurrentpwd() {
		return profileTxtCurrentpwd;
	}


	public QAFWebElement getProfileTxtNewpwd() {
		return profileTxtNewpwd;
	}


	public QAFWebElement getProfileTxtConfirmnewpwd() {
		return profileTxtConfirmnewpwd;
	}


	public QAFWebElement getProfileBtnSavePwd() {
		return profileBtnSavePwd;
	}


	public QAFWebElement getProfileIconPwdtickmark() {
		return profileIconPwdtickmark;
	}


	
	public QAFWebElement getProfileLblProfileinfotitle() {
		return profileLblProfileinfotitle;
	}
	
	public QAFWebElement getProfileIconProfileinfobullet() {
		return profileIconProfileinfobullet;
	}
	
	public QAFWebElement getProfileIconChangepwdbullet() {
		return profileIconChangepwdbullet;
	}
	
	public QAFWebElement getProfileLblMyyhebstore() {
		return profileLblMyyhebstore;
	}


	public QAFWebElement getProfileLblMyhebstorebanner() {
		return profileLblMyhebstorebanner;
	}


	public QAFWebElement getProfileLnkEditstore() {
		return profileLnkEditstore;
	}


	public QAFWebElement getProfileLblMyhebstorename() {
		return profileLblMyhebstorename;
	}


	public QAFWebElement getProfileLnkGetdirection() {
		return profileLnkGetdirection;
	}


	public QAFWebElement getProfileLnkSeestoredetail() {
		return profileLnkSeestoredetail;
	}


	public QAFWebElement getProfileLblMapview() {
		return profileLblMapview;
	}


	public QAFWebElement getProfileLblStoreselector() {
		return profileLblStoreselector;
	}


	public QAFWebElement getProfileTxtZipcode() {
		return profileTxtZipcode;
	}


	public QAFWebElement getProfileBtnGo() {
		return profileBtnGo;
	}


	public List<QAFWebElement> getProfileLblStorenamelist() {
		return profileLblStorenamelist;
	}


	public List<QAFWebElement> getProfileLblSelectbuttonlist() {
		return profileLblSelectbuttonlist;
	}


	public QAFWebElement getProfileLblStoreselectorclose() {
		return profileLblStoreselectorclose;
	}
	
	public QAFWebElement getProfileGetBtnSelectWithStoreId(String storeId) {
		String rtnEle = String.format(pageProps.getString("profile.get.btn.selectwithstoreid"), storeId);
		return new QAFExtendedWebElement(rtnEle);
	}

	public QAFWebElement getProfileGetLblStoreNameWithStoreId(String storeId) {
		String rtnEle = String.format(pageProps.getString("profile.get.lbl.storenamewithstoreid"), storeId);
		return new QAFExtendedWebElement(rtnEle);
	}
	
	




}