package com.automation.web.pages.coupons;

import java.util.List;

import com.automation.web.components.coupons.DigitalCouponBlocks;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class DigitalCouponsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "digcoupons.lbl.digcouponsheader")
	private QAFWebElement lblDigcouponsheader;
	@FindBy(locator = "digcoupons.img.digcoupons")
	private QAFWebElement imgDigcoupons;
	@FindBy(locator = "digcoupons.lnk.login")
	private QAFWebElement lnkLogin;
	@FindBy(locator = "digcoupons.lnk.signup")
	private QAFWebElement lnkSignup;
	@FindBy(locator = "digcoupons.txt.searchcoupons")
	private QAFWebElement txtSearchcoupons;
	@FindBy(locator = "digcoupons.btn.searchicon")
	private QAFWebElement btnSearchicon;
	@FindBy(locator = "digcoupons.lbl.sortby")
	private QAFWebElement lblSortby;
	@FindBy(locator = "digcoupons.li.sortoptions")
	private List<QAFWebElement> liSortoptions;
	@FindBy(locator = "digcoupons.lbl.resultscount")
	private QAFWebElement lblResultscount;
	@FindBy(locator = "digcoupons.lbl.bycategory")
	private QAFWebElement lblBycategory;
	@FindBy(locator = "digcoupons.img.totalcouponsave")
	private QAFWebElement imgTotalcouponsave;
	@FindBy(locator = "digcoupons.li.leftnavoptions")
	private List<QAFWebElement> liLeftnavoptions;
	@FindBy(locator = "digcoupons.li.couponblocks")
	private List<DigitalCouponBlocks> liCouponblocks;
	@FindBy(locator = "digcoupons.lbl.loadmoreitems")
	private QAFWebElement lblLoadmoreitems;
	@FindBy(locator = "digcoupons.lbl.availablesection")
	private QAFWebElement lblAvailablesection;
	@FindBy(locator = "digcoupons.lbl.selectedsection")
	private QAFWebElement lblSelectedsection;
	@FindBy(locator = "digcoupons.lbl.redeemedsection")
	private QAFWebElement lblRedeemedsection;
	@FindBy(locator = "digcoupons.lbl.sortoptionnewest")
	private QAFWebElement lblSortoptionnewest;
	@FindBy(locator = "digcoupons.lbl.sortoptionhighestvalue")
	private QAFWebElement lblSortoptionhighestvalue;
	@FindBy(locator = "digcoupons.lbl.sortoptionexpdate")
	private QAFWebElement lblSortoptionexpdate;
	@FindBy(locator = "digcoupons.lbl.sortoptionpopularity")
	private QAFWebElement lblSortoptionpopularity;
	@FindBy(locator = "digcoupons.lbl.selectedsectioncouponnames")
	private List<QAFWebElement> lblSelectedsectioncouponnames;	
	@FindBy(locator = "digcoupons.lbl.avlsavingsamount")
	private QAFWebElement lblAvlSavingsAmount;
	@FindBy(locator = "digcoupons.lbl.selectedsavingsamount")
	private QAFWebElement lblSelectedSavingsAmount;
	@FindBy(locator = "digcoupons.lnk.updatesavings")
	private QAFWebElement LnkUpdateSavings;
	@FindBy(locator = "digcoupons.img.specialOffers")
	private QAFWebElement imgSpecialOffers;
	@FindBy(locator = "digcoupons.lbl.availablecouponsqty")
	private QAFWebElement LblAvailableCouponsQty;	
	@FindBy(locator = "digcoupons.lbl.selectedcouponsqty")
	private QAFWebElement LblSelectedCouponsQty;
	@FindBy(locator = "digcoupons.lnk.myselectedlogin")
	private QAFWebElement LnkMyselectedLogin;
	@FindBy(locator = "digcoupons.lnk.savingtodatelogin")
	private QAFWebElement LnkSavingtodateLogin;
	
	@FindBy(locator = "digcoupons.lbl.savingtodatesection")
	private QAFWebElement LblSavingtoDateSection;
	@FindBy(locator = "digcoupons.lbl.savingtodatecouponsqty")
	private QAFWebElement LblSavingtoDateCouponsQty;
	@FindBy(locator = "digcoupons.lbl.savingtodateamount")
	private QAFWebElement LblSavingtoDateAmount;
	@FindBy(locator = "digcoupons.img.banner")
	private QAFWebElement imgBanner;
	@FindBy(locator = "digcoupons.lnk.learnmore")
	private QAFWebElement lnkLearnmore;
	@FindBy(locator = "digcoupons.lbl.couponsresult")
	private QAFWebElement lblCouponsresult;
	@FindBy(locator = "digcoupons.drpdwn.filterby")
	private QAFWebElement drpdwnFilterby;
	@FindBy(locator = "digcoupons.li.lbl.filteroptions")
	private List<QAFWebElement> liLblFilteroptions;
	@FindBy(locator = "digcoupons.lbl.showingofqty")
	private QAFWebElement lblShowingofqty;
	@FindBy(locator = "digcoupons.lnk.clear")
	private QAFWebElement lnkClear;
	
	
	
	public List<QAFWebElement> getLblSelectedsectioncouponnames() {
		return lblSelectedsectioncouponnames;
	}

	public QAFWebElement getLblSortoptionnewest() {
		return lblSortoptionnewest;
	}

	public QAFWebElement getLblSortoptionhighestvalue() {
		return lblSortoptionhighestvalue;
	}

	public QAFWebElement getLblSortoptionexpdate() {
		return lblSortoptionexpdate;
	}

	public QAFWebElement getLblSortoptionpopularity() {
		return lblSortoptionpopularity;
	}

	public QAFWebElement getLblAvailablesection() {
		return lblAvailablesection;
	}

	public QAFWebElement getLblSelectedsection() {
		return lblSelectedsection;
	}

	public QAFWebElement getLblRedeemedsection() {
		return lblRedeemedsection;
	}

	public QAFWebElement getLblDigcouponsheader() {
		return lblDigcouponsheader;
	}

	public QAFWebElement getImgDigcoupons() {
		return imgDigcoupons;
	}

	public QAFWebElement getLnkLogin() {
		return lnkLogin;
	}

	public QAFWebElement getLnkSignup() {
		return lnkSignup;
	}

	public QAFWebElement getTxtSearchcoupons() {
		return txtSearchcoupons;
	}

	public QAFWebElement getBtnSearchicon() {
		return btnSearchicon;
	}

	public QAFWebElement getLblSortby() {
		return lblSortby;
	}

	public List<QAFWebElement> getLiSortoptions() {
		return liSortoptions;
	}

	public QAFWebElement getLblResultscount() {
		return lblResultscount;
	}

	public QAFWebElement getLblBycategory() {
		return lblBycategory;
	}

	public QAFWebElement getImgTotalcouponsave() {
		return imgTotalcouponsave;
	}

	public List<QAFWebElement> getLiLeftnavoptions() {
		return liLeftnavoptions;
	}

	public List<DigitalCouponBlocks> getLiCouponblocks() {
		return liCouponblocks;
	}

	public QAFWebElement getLblLoadmoreitems() {
		return lblLoadmoreitems;
	}

	public QAFWebElement getLblAvlSavingsAmount() {
		return lblAvlSavingsAmount;
	}
	
	public QAFWebElement getLblSelectedSavingsAmount() {
		return lblSelectedSavingsAmount;
	}
	
	public QAFWebElement getLnkUpdateSavings() {
		return LnkUpdateSavings;
	}
	
	public QAFWebElement getImgSpecialOffers() {
		return imgSpecialOffers;
	}	   
	
	public QAFWebElement getLblAvailableCouponsQty() {
		return LblAvailableCouponsQty;
	}
	
	public QAFWebElement getLnkSavingtodateLogin() {   
		return LnkSavingtodateLogin;
	}
	    
	public QAFWebElement getLnkMyselectedLogin() {
		return LnkMyselectedLogin;
	}
	
	public QAFWebElement getLblSavingtoDateSection() {
		return LblSavingtoDateSection;
	}
	
	public QAFWebElement getLblSavingtoDateCouponsQty() {
		return LblSavingtoDateCouponsQty;
	}
	
	public QAFWebElement getLblSavingtoDateAmount() {
		return LblSavingtoDateAmount;
	}
	
	public QAFWebElement getLblSelectedCouponsQty() {
		return LblSelectedCouponsQty;
	}
	
	public QAFWebElement getImgBanner() {
		return imgBanner;
	}
	public QAFWebElement getLnkLearnmore() {
		return lnkLearnmore;
	}
	
	public QAFWebElement getLblCouponsresult() {
		return lblCouponsresult;
	}
	
	public QAFWebElement getDrpdwnFilterby() {
		return drpdwnFilterby;
	}
	
	public List<QAFWebElement> getLiLblFilteroptions() {
		return liLblFilteroptions;
	}
	
	public QAFWebElement getLblShowingofqty() {
		return lblShowingofqty;
	}
	
	public QAFWebElement getLnkClear() {
		return lnkClear;
	}
	
}