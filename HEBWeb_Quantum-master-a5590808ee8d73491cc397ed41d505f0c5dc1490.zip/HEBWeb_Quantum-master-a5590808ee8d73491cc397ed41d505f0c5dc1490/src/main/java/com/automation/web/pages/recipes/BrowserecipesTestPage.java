package com.automation.web.pages.recipes;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class BrowserecipesTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "browserecipes.lbl.pagetitle")
	private QAFWebElement lblPagetitle;
	@FindBy(locator = "browserecipes.lbl.firstcategoryname")
	private List<QAFWebElement> lblFirstcategoryname;
	@FindBy(locator = "browserecipes.lbl.bycookingmethod")
	private QAFWebElement lblBycookingmethod;
	@FindBy(locator = "browserecipes.img.bycookingmethod")
	private QAFWebElement imgBycookingmethod;
	@FindBy(locator = "browserecipes.lbl.bycuisinetype")
	private QAFWebElement lblBycuisinetype;
	@FindBy(locator = "browserecipes.lbl.bydiet")
	private QAFWebElement lblBydiet;
	@FindBy(locator = "browserecipes.lbl.bymealtype")
	private QAFWebElement lblBymealtype;
	@FindBy(locator = "browserecipes.lbl.bynutrition")
	private QAFWebElement lblBynutrition;
	@FindBy(locator = "browserecipes.lnk.lowsaturatedfat")
	private QAFWebElement lnkLowsaturatedfat;
	@FindBy(locator = "browserecipes.lbl.bypopularcategory")
	private QAFWebElement lblBypopularcategory;
	@FindBy(locator = "browserecipes.lbl.byprimaryingredient")
	private QAFWebElement lblByprimaryingredient;
	@FindBy(locator = "browserecipes.lbl.byseasonorholiday")
	private QAFWebElement lblByseasonorholiday;
	@FindBy(locator = "browserecipes.lbl.bysource")
	private QAFWebElement lblBysource;
	@FindBy(locator = "browserecipes.img.bycuisinetype")
	private QAFWebElement imgBycuisinetype;
	@FindBy(locator = "browserecipes.img.bydiet")
	private QAFWebElement imgBydiet;
	@FindBy(locator = "browserecipes.img.bymealtype")
	private QAFWebElement imgBymealtype;
	@FindBy(locator = "browserecipes.img.bynutrition")
	private QAFWebElement imgBynutrition;
	@FindBy(locator = "browserecipes.img.bypopularcategory")
	private QAFWebElement imgBypopularcategory;
	@FindBy(locator = "browserecipes.img.byprimaryingredient")
	private QAFWebElement imgByprimaryingredient;
	@FindBy(locator = "browserecipes.img.byseasonorholiday")
	private QAFWebElement imgByseasonorholiday;
	@FindBy(locator = "browserecipes.img.bysource")
	private QAFWebElement imgBysource;
	@FindBy(locator = "browserecipes.lbl.moreitemsheading")
	private List<QAFWebElement> lblMoreitemsheading;

	@FindBy(locator = "browserecipes.lbl.recipecategoriestitle")
	private List<QAFWebElement> lblRecipecategoriestitle;
	
	@FindBy(locator = "browserecipes.lbl.bycookingmethodsub")
	private List<QAFWebElement> lblByCookingMethodSub;
	
	@FindBy(locator = "browserecipes.lbl.bycuisinetypesub")
	private List<QAFWebElement> lblByCuisineTypeSub;
	
	@FindBy(locator = "browserecipes.lbl.bydietsub")
	private List<QAFWebElement> lblByDietSub;
	
	@FindBy(locator = "browserecipes.lbl.bymealtypesub")
	private List<QAFWebElement> lblByMealTypeSub;
	
	@FindBy(locator = "browserecipes.lbl.bynutritionsub")
	private List<QAFWebElement> lblByNutritionSub;
	
	@FindBy(locator = "browserecipes.lbl.bypopularcategorysub")
	private List<QAFWebElement> lblByPopularCategorySub;
	
	@FindBy(locator = "browserecipes.lbl.byprimaryingredientsub")
	private List<QAFWebElement> lblByPrimaryIngredientSub;
	
	@FindBy(locator = "browserecipes.lbl.byseasonorholidaysub")
	private List<QAFWebElement> lblBySeasonorHolidaySub;
	
	@FindBy(locator = "browserecipes.lbl.bysourcesub")
	private List<QAFWebElement> lblBySourceSub;
	
	@FindBy(locator = "browserecipes.lbl.topratedrecipes")
	private QAFWebElement lblTopRatedRecipes;
	
	@FindBy(locator = "browserecipes.lbl.chickenrecipes")
	private QAFWebElement lblChickenRecipes;
	
	@FindBy(locator = "browserecipes.lbl.sidesandsaladsrecipes")
	private QAFWebElement lblSidesandsaladsRecipes;
	
	@FindBy(locator = "browserecipes.lbl.holidaycookiesrecipes")
	private QAFWebElement lblHolidaycookiesRecipes;
	
	@FindBy(locator = "browserecipes.lbl.sec2")
	private QAFWebElement lblSec2;
	
	@FindBy(locator = "browserecipes.lbl.sec3")
	private QAFWebElement lblSec3;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}
	
	public QAFWebElement getTopratedRecipesProductImage(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.topratedrecipesproductimage"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getTopratedRecipesTitle(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.topratedrecipestitle"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getTopratedRecipesSpecs(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.topratedrecipesspecs"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getTopratedAddtoList(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.topratedaddtolist"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getTopratedAddtoRecipebox(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.topratedaddtorecipebox"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getTopratedAddedtoRecipebox(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.topratedaddedtorecipebox"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getChickenRecipesProductImage(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.chickenrecipesproductimage"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getChickenRecipesTitle(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.chickenrecipestitle"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getChickenRecipesSpecs(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.chickenrecipesspecs"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getChickenAddtoList(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.chickenaddtolist"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getChickenAddtoRecipebox(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.chickenaddtorecipebox"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getChickenAddedtoRecipebox(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.chickenaddedtorecipebox"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getSeafoodRecipesProductImage(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.seafoodrecipesproductimage"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getSeafoodRecipesTitle(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.seafoodrecipestitle"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getSeafoodRecipesSpecs(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.seafoodrecipesspecs"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getSeafoodAddtoList(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.seafoodaddtolist"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getSeafoodAddtoRecipebox(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.seafoodaddtorecipebox"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getSeafoodAddedtoRecipebox(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lbl.seafoodaddedtorecipebox"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getRecipeNameUnderSubheader(String linktext) {
		String loc = String.format(pageProps.getString("browserecipes.get.lnk.recipeitem"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getLblTopRatedRecipes() {
		return lblTopRatedRecipes;
	}
	
	public QAFWebElement getLblChickenRecipes() {
		return lblChickenRecipes;
	}
	
	public QAFWebElement getLblSidesandsaladsRecipes() {
		return lblSidesandsaladsRecipes;
	}
	
	public QAFWebElement getLblHolidaycookiesRecipes() {
		return lblHolidaycookiesRecipes;
	}
	
	public QAFWebElement getLblSec2() {
		return lblSec2;
	}
	
	public QAFWebElement getLblSec3() {
		return lblSec3;
	}

	public QAFWebElement getLblPagetitle() {
		return lblPagetitle;
	}
	
	public List<QAFWebElement> getLblByCookingMethodSub() {
		return lblByCookingMethodSub;
	}
	
	public List<QAFWebElement> getLblByCuisineTypeSub() {
		return lblByCuisineTypeSub;
	}
	
	public List<QAFWebElement> getLblByDietSub() {
		return lblByDietSub;
	}
	
	public List<QAFWebElement> getLblByMealTypeSub() {
		return lblByMealTypeSub;
	}
	
	public List<QAFWebElement> getLblByNutritionSub() {
		return lblByNutritionSub;
	}
	
	public List<QAFWebElement> getLblByPopularCategorySub() {
		return lblByPopularCategorySub;
	}
	
	public List<QAFWebElement> getLblByPrimaryIngredientSub() {
		return lblByPrimaryIngredientSub;
	}
	
	public List<QAFWebElement> getLblBySeasonorHolidaySub() {
		return lblBySeasonorHolidaySub;
	}
	
	public List<QAFWebElement> getLblBySourceSub() {
		return lblBySourceSub;
	}

	public List<QAFWebElement> getLblFirstcategoryname() {
		return lblFirstcategoryname;
	}

	public QAFWebElement getLblBycookingmethod() {
		return lblBycookingmethod;
	}

	public QAFWebElement getImgBycookingmethod() {
		return imgBycookingmethod;
	}

	public QAFWebElement getLblBycuisinetype() {
		return lblBycuisinetype;
	}

	public QAFWebElement getLblBydiet() {
		return lblBydiet;
	}

	public QAFWebElement getLblBymealtype() {
		return lblBymealtype;
	}

	public QAFWebElement getLblBynutrition() {
		return lblBynutrition;
	}
	
	public QAFWebElement getLnkLowsaturatedfat() {
		return lnkLowsaturatedfat;
	}

	public QAFWebElement getLblBypopularcategory() {
		return lblBypopularcategory;
	}

	public QAFWebElement getLblByprimaryingredient() {
		return lblByprimaryingredient;
	}

	public QAFWebElement getLblByseasonorholiday() {
		return lblByseasonorholiday;
	}

	public QAFWebElement getLblBysource() {
		return lblBysource;
	}

	public QAFWebElement getImgBycuisinetype() {
		return imgBycuisinetype;
	}

	public QAFWebElement getImgBydiet() {
		return imgBydiet;
	}

	public QAFWebElement getImgBymealtype() {
		return imgBymealtype;
	}

	public QAFWebElement getImgBynutrition() {
		return imgBynutrition;
	}

	public QAFWebElement getImgBypopularcategory() {
		return imgBypopularcategory;
	}

	public QAFWebElement getImgByprimaryingredient() {
		return imgByprimaryingredient;
	}

	public QAFWebElement getImgByseasonorholiday() {
		return imgByseasonorholiday;
	}

	public QAFWebElement getImgBysource() {
		return imgBysource;
	}

	public List<QAFWebElement> getLblMoreitemsheading() {
		return lblMoreitemsheading;
	}

	public List<QAFWebElement> getLblRecipecategoriestitle() {
		return lblRecipecategoriestitle;
	}

}
