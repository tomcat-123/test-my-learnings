package com.automation.web.steps.Aboutus;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.aboutus.ContactUsTestPage;
import com.automation.web.pages.homepage.FooterTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

public class ContactUsStepDef {

	@QAFTestStep(description = "I navigate to Contact Us page")
	public void iNavigateToContactUsPage() {
		FooterTestPage footer = new FooterTestPage();
		
		PerfectoUtils.scrolltoelement(footer.getFooterLnkContactus());
		footer.getFooterLnkContactus().click();
	}
	
	@QAFTestStep(description = "I verify whether Select button gets displayed as Selected")
	public void iVerifySelectbtnDisplayedasSelected() {
		ContactUsTestPage contact = new ContactUsTestPage();
		
		contact.getBtnSelected("1").verifyPresent();
		String color = contact.getBtnSelected("1").getCssValue("background-color");  
		if(color.equals("rgba(0, 128, 0, 1)")){
			PerfectoUtils.reportMessage("Background color of selected button is green", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Background color of selected button is not green", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I enter zipcode {0} and select the store in Contact Us page")
	public void iEnterZipCodeAndSelecttheStore(String zipcode) {
		ContactUsTestPage contact = new ContactUsTestPage();
		
		PerfectoUtils.getDriver().switchTo().frame(1);
		PerfectoUtils.getDriver().switchTo().frame(contact.getFrameZip());
		contact.getTxtZipcode().clear();
		contact.getTxtZipcode().sendKeys(zipcode);
		contact.getBtnGo().click();
		contact.getBtnSelect("1").waitForPresent(5000);
		contact.getBtnSelect("1").click();
	}
	
	@QAFTestStep(description = "I enter zipcode {0} in Contact Us page")
	public void iEnterZipCodeinContactUsPage(String zipcode) {
		ContactUsTestPage contact = new ContactUsTestPage();
		
		PerfectoUtils.getDriver().switchTo().frame(1);
		PerfectoUtils.getDriver().switchTo().frame(contact.getFrameZip());
		contact.getTxtZipcode().clear();
		contact.getTxtZipcode().sendKeys(zipcode);
		contact.getBtnGo().click();
	}
	
	@QAFTestStep(description = "I verify whether the stores are selectable in Contact us page")
	public void iVerifyStoresareSelectable() {
		ContactUsTestPage contact = new ContactUsTestPage();
		
		contact.getBtnSelected("1").verifyPresent();
	}
	
	@QAFTestStep(description = "I verify Load more feature on the store selection")
	public void iVerifyLoadmorefeature() {
		ContactUsTestPage contact = new ContactUsTestPage();
		
		PerfectoUtils.scrolltoelement(contact.getBtnLoadmorestores());
		contact.getBtnLoadmorestores().verifyPresent();
		contact.getBtnLoadmorestores().click();
		String showCountAfterLoad = contact.getLblShowing().getText();
		if(showCountAfterLoad.contains("Showing 6")){
			PerfectoUtils.reportMessage("Load more button loads the stores", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Load more button does not loaded the stores", MessageTypes.Fail);
		}
		
		contact.getBtnSelect("6").waitForPresent(5000);
		contact.getBtnSelect("6").click();
		contact.getBtnSelected("6").verifyPresent();
	}
	
}