package com.automation.web.steps.Aboutus;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.aboutus.AboutUsTestPage;
import com.automation.web.pages.aboutus.EnvironmentTestPage;
import com.automation.web.pages.aboutus.SustainableSeafoodTestPage;
import com.automation.web.pages.aboutus.TraceMycatchTestPage;
import com.automation.web.pages.homepage.FooterTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of steps in AboutUsStepDef
 
	* Navigate to About Us page
	* Navigate to Environment page
	* Navigate to Seafoods Sustainability page
	* Navigate to Trace My Catch page
	* Enter Invalid tuna product code and select Find button
	* Verify the No results found error message in Trace My Catch page
	* Enter Valid tuna product code and select Find button
	* Verify the result for Valid Pdt code in Trace My Catch page
	
	*/

public class AboutUsStepDef {

	@QAFTestStep(description = "Navigate to About Us page")
	public void navigateToAboutUsPage() {
		FooterTestPage footer = new FooterTestPage();

		PerfectoUtils.scrolltoelement(footer.getFooterLnkAboutus());
		footer.getFooterLnkAboutus().waitForPresent(3000);
		footer.getFooterLnkAboutus().click();
	}

	@QAFTestStep(description = "Navigate to Environment page")
	public void navigateToEnvironmentPage() {
		AboutUsTestPage abtus = new AboutUsTestPage();

		abtus.getLnkEnvironment().waitForPresent(5000);
		abtus.getLnkEnvironment().click();
	}

	@QAFTestStep(description = "Navigate to Seafoods Sustainability page")
	public void navigateToSeafoodsSustainabilityPage() {
		EnvironmentTestPage envmnt = new EnvironmentTestPage();

		envmnt.getLnkSeafoodsustainablility().waitForPresent(5000);
		envmnt.getLnkSeafoodsustainablility().click();

	}

	@QAFTestStep(description = "Navigate to Trace My Catch page")
	public void navigateToTraceMyCatchPage() {
		SustainableSeafoodTestPage ssfood = new SustainableSeafoodTestPage();

		ssfood.getLnkEntertunacode().waitForPresent(5000);
		ssfood.getLnkEntertunacode().click();
	}

	@QAFTestStep(description = "Enter Invalid tuna product code and select Find button")
	public void enterInvalidTunaProductCodeAndSelectFindButton() {
		TraceMycatchTestPage tmcatch = new TraceMycatchTestPage();

		String Invalidtunacode = ConfigurationManager.getBundle().getString("products.invalidtunepdtcode");
		PerfectoUtils.scrolltoelement(tmcatch.getTxtEntertunacode());
		tmcatch.getTxtEntertunacode().sendKeys(Invalidtunacode);
		tmcatch.waitForAjaxToComplete();
		PerfectoUtils.scrolltoelement(tmcatch.getBtnFind());
		tmcatch.getBtnFind().waitForPresent(10000);
		tmcatch.getBtnFind().click();
		tmcatch.waitForAjaxToComplete();
	}

	@QAFTestStep(description = "Verify the No results found error message in Trace My Catch page")
	public void verifyTheNoResultsFoundErrorMessageInTraceMyCatchPage() {
		TraceMycatchTestPage tmcatch = new TraceMycatchTestPage();

		if (tmcatch.getLblNoresultsfounderrormsg().isPresent()) {
			PerfectoUtils.reportMessage("Error message found as expected..", MessageTypes.Pass);
			PerfectoUtils.reportMessage(tmcatch.getLblNoresultsfounderrormsg().getText(), MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("No error message found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Enter Valid tuna product code and select Find button")
	public void enterValidTunaProductCodeAndSelectFindButton() {
		TraceMycatchTestPage tmcatch = new TraceMycatchTestPage();

		String Validtunacode = ConfigurationManager.getBundle().getString("products.validtunepdtcode");
		PerfectoUtils.scrolltoelement(tmcatch.getTxtEntertunacode());
		tmcatch.getTxtEntertunacode().sendKeys(Validtunacode);
		tmcatch.waitForAjaxToComplete();
		tmcatch.getBtnFind().click();
		tmcatch.waitForAjaxToComplete();
	}
	
	@QAFTestStep(description = "Verify the result for Valid Pdt code in Trace My Catch page")
	public void verifyTheResultForValidPdtCodeInTraceMyCatchPage() {
		TraceMycatchTestPage tmcatch = new TraceMycatchTestPage();

		tmcatch.getLblPdtseatchresults().verifyPresent();
		tmcatch.getLblPdtnameheader().verifyPresent();
		tmcatch.getLblPdtcodelabel().verifyPresent();
		tmcatch.getLblPdtcodevalue().verifyPresent();
		tmcatch.getLblPdtdescription().verifyPresent();
		tmcatch.getLblSorcinginfo().verifyPresent();
		tmcatch.getLblCertifications().verifyPresent();
	}
	
}
