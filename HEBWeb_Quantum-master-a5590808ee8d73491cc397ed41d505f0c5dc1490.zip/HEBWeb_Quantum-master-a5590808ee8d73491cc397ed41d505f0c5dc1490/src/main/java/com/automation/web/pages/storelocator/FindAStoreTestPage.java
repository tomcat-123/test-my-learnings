package com.automation.web.pages.storelocator;

import java.util.List;

import com.automation.web.components.CDPProductBlocks;
import com.automation.web.components.ChoosingStore;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class FindAStoreTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "findstore.lbl.pagetitle")
	private QAFWebElement findstoreLblPagetitle;

	@FindBy(locator = "findstore.txt.enterzipcode")
	private QAFWebElement findstoreTxtEnterzipcode;

	@FindBy(locator = "findstore.btn.search")
	private QAFWebElement findstoreBtnSearch;

	@FindBy(locator = "findstore.li.storenameslist")
	private List<QAFWebElement> findstoreLiStorenameslist;

	@FindBy(locator = "findstore.btn.select")
	private List<QAFWebElement> findstoreBtnSelect;
	
	@FindBy(locator = "findstore.ddl.distanceoptions")
	private QAFWebElement DdlDistanceOptions;
	
	@FindBy(locator = "findstore.btn.loadnext")
	private QAFWebElement BtnLoadNext;
	
	@FindBy(locator = "findstore.lbl.pagestorecount")
	private QAFWebElement LblPageStoreCount;
	
	@FindBy(locator = "findstore.lbl.pageinitialcount")
	private QAFWebElement LblPageInitialCount;
	
	@FindBy(locator = "findstore.table.storeresults")
	private List<ChoosingStore> StoreResults;
	
	@FindBy(locator = "findstore.img.map")
	private QAFWebElement findstoreImgMap;
	
	@FindBy(locator = "findstore.img.refineyourresults")
	private QAFWebElement findstoreImgRefineyourresults;
	
	@FindBy(locator = "findstore.li.chk.refinecheckboxes")
	private List<QAFWebElement> findstoreLiChkRefinecheckboxes;
	
	@FindBy(locator = "findstore.li.lnk.seemore")
	private List<QAFWebElement> findstoreLiLnkSeemore;
	
	@FindBy(locator = "findstore.lnk.centralmarket")
	private QAFWebElement findstoreLnkCentralmarket;
	
	@FindBy(locator = "findstore.lbl.breadcrumb")
	private QAFWebElement findstoreLblBreadcrumb;
	
	@FindBy(locator = "findstore.lbl.storeresults")
	private QAFWebElement findstoreLblStoreResults;
	
	@FindBy(locator = "findstore.lbl.errormsg")
	private QAFWebElement findstoreLblErrormsg;
	
	@FindBy(locator = "findstore.li.displayedstores")
	private List<QAFWebElement> findstoreListDisplayedstores;
	
	@FindBy(locator = "findstore.li.showedfeauture")
	private List<QAFWebElement> findstoreListShowedFeauture;
	
	@FindBy(locator = "findstore.lnk.seemore")
	private QAFWebElement findstoreLnkSeeMore;
	
	@FindBy(locator = "findstore.lnk.showless")
	private QAFWebElement findstoreLnkShowLess;
	
	@FindBy(locator = "findstore.lbl.showedfeautureexpand")
	private QAFWebElement findstoreLblShowedfeautureExpand;
	
	@FindBy(locator = "findstore.lnk.homebreadcrumb")
	private QAFWebElement findstoreLnkHomeBreadcrumb;
	
	@FindBy(locator = "findstore.lst.refineresultsarealist")
	private List<QAFWebElement> findstoreListRefineResultsAreaList;
	
	public List<QAFWebElement> getFindstoreLiRefineResultsAreaList(){
		return findstoreListRefineResultsAreaList;
	}
	
	public QAFWebElement getLnkHomeBreadcrumb(){ return findstoreLnkHomeBreadcrumb; }
	
	public QAFWebElement getLnkSeeMore(){ return findstoreLnkSeeMore; }
	
	public QAFWebElement getLnkShowLess(){ return findstoreLnkShowLess; }
	
	public QAFWebElement getLblShowedfeautureExpand(){ return findstoreLblShowedfeautureExpand; }
	
	public List<QAFWebElement> getFindstoreLiShowedFeauture(){
		return findstoreListShowedFeauture;
	}
	
	public List<QAFWebElement> getFindstoreLiDisplayedstores(){
		return findstoreListDisplayedstores;
	}
	
	//public List<CDPProductBlocks> getCdpLiProductblock(){ return cdpLiProductblock; }
	
	public QAFWebElement getLblStoreResults(){ return findstoreLblStoreResults; }
	
	public QAFWebElement getLblErrormsg(){ return findstoreLblErrormsg; }
	
	public QAFWebElement getChkRefineResultsArea1stCheck(int count) {
		String reElm = String.format(pageProps.getString("findstore.get.chk.refineresultsarea1stcheck"), count);
		return new QAFExtendedWebElement(reElm);
	}
	
	public QAFWebElement getLblRefineResultsArea(String count) {
		String reElm = String.format(pageProps.getString("findstore.get.lbl.refineresultsarea"), count);
		return new QAFExtendedWebElement(reElm);
	}
	
	public QAFWebElement getLblRefineResultsEachAreaList(String count) {
		String reElm = String.format(pageProps.getString("findstore.get.lst.refineresultseacharealist"), count);
		return new QAFExtendedWebElement(reElm);
	}
	
	public QAFWebElement getLblRefineResultsEachAreaCheckBoxList(String count) {
		String reElm = String.format(pageProps.getString("findstore.get.lst.refineresultseachareacheckboxlist"), count);
		return new QAFExtendedWebElement(reElm);
	}
	
	public QAFWebElement getLblRefineResultsEachAreaSeeMoreCheckBoxList(int count) {
		String reElm = String.format(pageProps.getString("findstore.get.lst.refineresultseachareaseemorecheckboxlist"), count);
		return new QAFExtendedWebElement(reElm);
	}

	public QAFWebElement getBtnStoreforSelect(int count) {
		String reElm = String.format(pageProps.getString("findstore.get.btn.maxstoreforselect"), count);
		return new QAFExtendedWebElement(reElm);
	}	
	
	public QAFWebElement getLblStoreNameforSelect(int count) {
		String reElm = String.format(pageProps.getString("findstore.get.lbl.rndmstoreforstorename"), count);
		return new QAFExtendedWebElement(reElm);
	}	
	
	public QAFWebElement getMaxMilestoStore(String count) {
		String reElm = String.format(pageProps.getString("findstore.get.lbl.maxstoremiles"), count);
		return new QAFExtendedWebElement(reElm);
	}
	
	public List<ChoosingStore> getStoreResults() {
		return StoreResults;
	}


	public void setStoreResults(List<ChoosingStore> storeResults) {
		StoreResults = storeResults;
	}


	public QAFWebElement getLblPageInitialCount(){ return LblPageInitialCount; }
	public QAFWebElement getLblPageStoreCount(){ return LblPageStoreCount; }
	public QAFWebElement getBtnLoadNext(){ return BtnLoadNext; }
	public QAFWebElement getDdlDistanceOptions(){ return DdlDistanceOptions; }

	/**
	 * TextView for page title
	 */
	public QAFWebElement getFindstoreLblPagetitle(){ return findstoreLblPagetitle; }

	/**
	 * EditView for Zip code text field
	 */
	public QAFWebElement getFindstoreTxtEnterzipcode(){ return findstoreTxtEnterzipcode; }

	/**
	 * ButtonView for Search
	 */
	public QAFWebElement getFindstoreBtnSearch(){ return findstoreBtnSearch; }

	/**
	 * ListView for Store Names
	 */
	public List<QAFWebElement> getFindstoreLiStorenameslist(){ return findstoreLiStorenameslist; }

	/**
	 * ButtonView for Select
	 */
	public List<QAFWebElement> getFindstoreBtnSelect(){ return findstoreBtnSelect; }
	
	public void clickLoadMoreStoresuntilVisible(){
		do{
			getBtnLoadNext().click();
		}while(getBtnLoadNext().isPresent());
	}

	public QAFWebElement getFindstoreImgMap(){
		return findstoreImgMap;
	}
	
	public QAFWebElement getFindstoreImgRefineyourresults(){
		return findstoreImgRefineyourresults;
	}
	
	public List<QAFWebElement> getFindstoreLiChkRefinecheckboxes(){
		return findstoreLiChkRefinecheckboxes;
	}
	
	public List<QAFWebElement> getFindstoreLiLnkSeemore(){
		return findstoreLiLnkSeemore;
	}
	
	public QAFWebElement getFindstoreLnkCentralmarket(){
		return findstoreLnkCentralmarket;
	}
	
	public QAFWebElement getFindstoreLblBreadcrumb(){
		return findstoreLblBreadcrumb;
	}
	
	
}