package com.automation.web.pages.storelocator;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SelectStoreTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "selstore.lbl.title")
	private QAFWebElement selstoreLblTitle;

	@FindBy(locator = "selstore.txt.zipcode")
	private QAFWebElement selstoreTxtZipcode;

	@FindBy(locator = "selstore.btn.go")
	private QAFWebElement selstoreBtnGo;

	@FindBy(locator = "selstore.get.btn.storeselect")
	private QAFWebElement selstoreGetBtnStoreselect;

	@FindBy(locator = "selstore.get.lbl.storename")
	private QAFWebElement selstoreGetLblStorename;

	@FindBy(locator = "selstore.li.storeselectcolduser")
	private List<QAFWebElement> selstoreLiStoreselectcolduser;

	@FindBy(locator = "selstore.li.storenamecolduser")
	private List<QAFWebElement> selstoreLiStorenamecolduser;

	@FindBy(locator = "selstore.lbl.titlecolduser")
	private QAFWebElement selstoreLblTitlecolduser;

	@FindBy(locator = "selstore.btn.gocolduser")
	private QAFWebElement selstoreBtnGocolduser;

	@FindBy(locator = "selstore.lbl.displayedstore")
	private QAFWebElement selstoreLblDisplayedstore;

	@FindBy(locator = "selstore.link.editstore")
	private QAFWebElement selstoreLinkEditstore;

	@FindBy(locator = "selstore.lbl.pickupstoretitle")
	private QAFWebElement selstoreLblPickupstoretitle;

	@FindBy(locator = "selstore.lbl.selectastore")
	private QAFWebElement selstoreLblSelectastore;

	@FindBy(locator = "selstore.get.btn.storeselectwithstoreid")
	private QAFWebElement selstoreGetBtnStoreselectwithstoreid;

	@FindBy(locator = "selstore.get.lbl.storeid")
	private QAFWebElement selstoreGetLblStoreid;

	@FindBy(locator = "selstore.lbl.results")
	private QAFWebElement selstoreLblResults;
	
	@FindBy(locator = "selstore.btn.close")
	private QAFWebElement selstoreBtnClose;

	/**
	 * TextView for Select Store page title
	 */
	public QAFWebElement getSelstoreLblTitle(){ return selstoreLblTitle; }

	/**
	 * TextView for Zip code
	 */
	public QAFWebElement getSelstoreTxtZipcode(){ return selstoreTxtZipcode; }

	/**
	 * ButtonView for Go
	 */
	public QAFWebElement getSelstoreBtnGo(){ return selstoreBtnGo; }

	/**
	 * ButtonView for Select dynamic
	 */
	public QAFWebElement getSelstoreGetBtnStoreselect(String item){ 
		String retElm = String.format(pageProps.getString("selstore.get.btn.storeselect"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * TextView for store name dynamic
	 */
	public QAFWebElement getSelstoreGetLblStorename(String item){ 
		String retElm = String.format(pageProps.getString("selstore.get.lbl.storename"), item);
	    return new QAFExtendedWebElement(retElm);
	}
	
	public QAFWebElement getSelstoreGetLblPickUpStorename(String item){ 
		String retElm = String.format(pageProps.getString("selstore.get.lbl.pickupstorename"), item);
	    return new QAFExtendedWebElement(retElm);
	}
	
	/**
	 * TextView for InMyStore name dynamic
	 */
	public QAFWebElement getSelstoreGetLblInMYStorename(String item){ 
		String retElm = String.format(pageProps.getString("selstore.get.lbl.inmystorename"), item);
	    return new QAFExtendedWebElement(retElm);
	}
	

	/**
	 * ButtonView for Select list
	 */
	public List<QAFWebElement> getSelstoreLiStoreselectcolduser(){ return selstoreLiStoreselectcolduser; }

	/**
	 * TextView for store name list
	 */
	public List<QAFWebElement> getSelstoreLiStorenamecolduser(){ return selstoreLiStorenamecolduser; }

	/**
	 * TextView for Select Store page title cold user
	 */
	public QAFWebElement getSelstoreLblTitlecolduser(){ return selstoreLblTitlecolduser; }

	/**
	 * ButtonView for Go
	 */
	public QAFWebElement getSelstoreBtnGocolduser(){ return selstoreBtnGocolduser; }

	/**
	 * TextView for existing store
	 */
	public QAFWebElement getSelstoreLblDisplayedstore(){ return selstoreLblDisplayedstore; }

	/**
	 * ButtonView for select store
	 */
	public QAFWebElement getSelstoreLinkEditstore(){ return selstoreLinkEditstore; }

	/**
	 * TextView for Select pickup Store page title
	 */
	public QAFWebElement getSelstoreLblPickupstoretitle(){ return selstoreLblPickupstoretitle; }

	/**
	 * TextView For Select a store
	 */
	public QAFWebElement getSelstoreLblSelectastore(){ return selstoreLblSelectastore; }

	/**
	 * ButtonView for Select button with respect to Store id
	 */
	public QAFWebElement getSelstoreGetBtnStoreselectwithstoreid(String item){ 
		String retElm = String.format(pageProps.getString("selstore.get.btn.storeselectwithstoreid"), item, item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * TextView for Store id
	 */
	public QAFWebElement getSelstoreGetLblStoreid(String item){ 
		String retElm = String.format(pageProps.getString("selstore.get.lbl.storeid"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * TextView for select store results
	 */
	public QAFWebElement getSelstoreLblResults(){ return selstoreLblResults; }
	
	public QAFWebElement getSelstoreBtnClose(){ return selstoreBtnClose; }
	

}