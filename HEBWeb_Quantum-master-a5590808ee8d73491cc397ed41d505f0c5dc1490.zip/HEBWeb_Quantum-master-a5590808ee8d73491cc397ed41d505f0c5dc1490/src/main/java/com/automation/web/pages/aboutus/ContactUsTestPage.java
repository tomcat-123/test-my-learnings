package com.automation.web.pages.aboutus;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ContactUsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "contactus.txt.zipcode")
	private QAFWebElement txtZipcode;

	@FindBy(locator = "contactus.btn.go")
	private QAFWebElement btnGo;
	
	@FindBy(locator = "contactus.btn.loadmorestores")
	private QAFWebElement btnLoadmorestores;
	
	@FindBy(locator = "contactus.lbl.showing")
	private QAFWebElement lblShowing;
	
	@FindBy(locator = "contactus.frame.zipframe")
	private QAFWebElement frameZip;

	public QAFWebElement getTxtZipcode() {
		return txtZipcode;
	}
	
	public QAFWebElement getFrameZip() {
		return frameZip;
	}

	public QAFWebElement getBtnGo() {
		return btnGo;
	}
	
	public QAFWebElement getBtnSelect(String linktext) {
		String loc = String.format(pageProps.getString("contactus.btn.select"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getBtnSelected(String linktext) {
		String loc = String.format(pageProps.getString("contactus.btn.selected"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getBtnLoadmorestores() {
		return btnLoadmorestores;
	}
	
	public QAFWebElement getLblShowing() {
		return lblShowing;
	}

}