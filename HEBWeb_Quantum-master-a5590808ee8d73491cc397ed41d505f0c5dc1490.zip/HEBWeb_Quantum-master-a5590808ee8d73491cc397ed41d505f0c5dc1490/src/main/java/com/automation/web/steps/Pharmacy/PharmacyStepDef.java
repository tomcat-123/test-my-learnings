package com.automation.web.steps.Pharmacy;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.pharmacy.PatienInformationTestPage;
import com.automation.web.pages.pharmacy.PharmacyLandingTestPage;
import com.automation.web.pages.pharmacy.PrescriptionInformationTestPage;
import com.automation.web.pages.pharmacy.SetupAutoRefillTestPage;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import org.openqa.selenium.interactions.SendKeysAction;

import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of steps in PharmacyStepDef

* Navigate to Pharmacy page
* Navigate to Transfer prescription page
* Enter all required fields in Patient information page
* Select Continue button from transfer prescription page
* Verify navigated to Prescription Information tab
* Verify able to enter only {0} characters in Prescription number field
* Validate delivery content for auto refill enrolled user

*/

public class PharmacyStepDef {

	@QAFTestStep(description = "Navigate to Pharmacy page")
	public void navigateToPharmacyPage() {
		InStoreHomePage homepage = new InStoreHomePage();

		homepage.getHomeLnkPharmacy().waitForPresent(1000);
		homepage.getHomeLnkPharmacy().click();
		PerfectoUtils.reportMessage("Clicked on Pharmacy..");
	}

	@QAFTestStep(description = "Navigate to Transfer prescription page")
	public void navigateToTransferPrescriptionPage() {
		PharmacyLandingTestPage pharmacylanding = new PharmacyLandingTestPage();

		pharmacylanding.getPharmacyLblTransferprescription().waitForPresent(1000);
		pharmacylanding.getPharmacyLblTransferprescription().click();
		PerfectoUtils.reportMessage("Clicked on Transfer prescription..");
	}

	@QAFTestStep(description = "Enter all required fields in Patient information page")
	public void enterAllRequiredFieldsInPatientInformationPage() {
		PatienInformationTestPage patientinfo = new PatienInformationTestPage();

		String firstname = getBundle().getString("pharmacy.patientinfo.firstname");
		String lastname = getBundle().getString("pharmacy.patientinfo.lastname");
		String address1 = getBundle().getString("pharmacy.patientinfo.address1");
		String city = getBundle().getString("pharmacy.patientinfo.city");
		String dobmonth = getBundle().getString("pharmacy.patientinfo.dob.month");
		String dobdate = getBundle().getString("pharmacy.patientinfo.dob.date");
		String dobyear = getBundle().getString("pharmacy.patientinfo.dob.year");
		String phNumField1 = getBundle().getString("pharmacy.patientinfo.phonenumber.field1");
		String phNumField2 = getBundle().getString("pharmacy.patientinfo.phonenumber.field2");
		String phNumField3 = getBundle().getString("pharmacy.patientinfo.phonenumber.field3");

		PerfectoUtils.scrolltoelement(patientinfo.getTxtFirstname());
		patientinfo.getTxtFirstname().waitForPresent(1000);
		patientinfo.getTxtFirstname().sendKeys(firstname);

		patientinfo.getTxtLastname().click();
		patientinfo.getTxtLastname().sendKeys(lastname);

		patientinfo.getTxtAddress1().click();
		patientinfo.getTxtAddress1().sendKeys(address1);

		patientinfo.getTxtCity().click();
		patientinfo.getTxtCity().sendKeys(city);

		PerfectoUtils.scrolltoelement(patientinfo.getTxtDobmonth());
		patientinfo.getTxtDobmonth().click();
		patientinfo.getTxtDobmonth().sendKeys(dobmonth);

		patientinfo.getTxtDobdate().click();
		patientinfo.getTxtDobdate().sendKeys(dobdate);

		patientinfo.getTxtDobyear().click();
		patientinfo.getTxtDobyear().sendKeys(dobyear);

		patientinfo.getTxtPhonenumber1().click();
		patientinfo.getTxtPhonenumber1().sendKeys(phNumField1);

		patientinfo.getTxtPhonenumber2().click();
		patientinfo.getTxtPhonenumber2().sendKeys(phNumField2);

		patientinfo.getTxtPhonenumber3().click();
		patientinfo.getTxtPhonenumber3().sendKeys(phNumField3);

		PerfectoUtils.reportMessage("Entered all required fields in Patient information page..");

	}

	@QAFTestStep(description = "Select Continue button from transfer prescription page")
	public void selectContinueButtonFromTransferPrescriptionPage() {
		PatienInformationTestPage patientinfo = new PatienInformationTestPage();

		patientinfo.getBtnContinue().waitForPresent(1000);
		patientinfo.getBtnContinue().click();
		PerfectoUtils.reportMessage("Selected Continue button..");

	}

	@QAFTestStep(description = "Verify navigated to Prescription Information tab")
	public void verifyNavigatedToPrescriptionInformationTab() {
		PrescriptionInformationTestPage prescriptioninfo = new PrescriptionInformationTestPage();

		if (prescriptioninfo.getTxtPharmacyname().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Prescription Information page..");
		} else {
			PerfectoUtils.reportMessage("Not navigated to Prescription Information page..");
		}
	}

	@QAFTestStep(description = "Verify able to enter only {0} characters in Prescription number field")
	public void verifyAbleToEnterOnlyCharactersInPrescriptionNumberField(long l0) {
		PrescriptionInformationTestPage prescriptioninfo = new PrescriptionInformationTestPage();
		SetupAutoRefillTestPage autorefill = new SetupAutoRefillTestPage();

		enterAllRequiredFieldsInPrescriptionInfoPage();

		// Clicking the Continue button
		prescriptioninfo.getBtnContinue().waitForPresent(1000);
		prescriptioninfo.getBtnContinue().click();
		PerfectoUtils.reportMessage("Clicked Continue button..");

		try {
			autorefill.getLblPagetitle().waitForPresent(50000);
			if (autorefill.getLblPagetitle().isPresent()) {
				PerfectoUtils.reportMessage("Able to enter 20 chars in the Prescription number field..", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Error occured on entering 20 chars in the prescription number field..",
						MessageTypes.Fail);
			}
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Wait timeout for navigating to the next page..", MessageTypes.Fail);
		}

	}

	public void enterAllRequiredFieldsInPrescriptionInfoPage() {
		PrescriptionInformationTestPage prescriptioninfo = new PrescriptionInformationTestPage();

		String pharmacyname = getBundle().getString("pharmacy.prescriptioninfo.pharmacyname");
		String phNumField1 = getBundle().getString("pharmacy.prescriptioninfo.pharmacyphnum.field1");
		String phNumField2 = getBundle().getString("pharmacy.prescriptioninfo.pharmacyphnum.field2");
		String phNumField3 = getBundle().getString("pharmacy.prescriptioninfo.pharmacyphnum.field3");
		String drugname = getBundle().getString("pharmacy.prescriptioninfo.drugname");
		String prescriptionNumber = getBundle().getString("pharmacy.prescriptioninfo.prescriptionNumber");

		PerfectoUtils.scrolltoelement(prescriptioninfo.getTxtPharmacyname());
		prescriptioninfo.getTxtPharmacyname().waitForPresent(1000);
		prescriptioninfo.getTxtPharmacyname().sendKeys(pharmacyname);
		prescriptioninfo.getTxtPhonePart1().sendKeys(phNumField1);
		prescriptioninfo.getTxtPhonePart2().sendKeys(phNumField2);
		prescriptioninfo.getTxtPhonePart3().sendKeys(phNumField3);

		PerfectoUtils.scrolltoelement(prescriptioninfo.getTxtDrugname());
		prescriptioninfo.getTxtDrugname().waitForPresent(1000);
		prescriptioninfo.getTxtDrugname().sendKeys(drugname);
		prescriptioninfo.getTxtPrescriptionnumber().sendKeys(prescriptionNumber);

		PerfectoUtils.reportMessage("Entered all the mandatory fields in Prescription details page..");
	}
	
	@QAFTestStep(description = "Validate delivery content for auto refill enrolled user")
	public void validateDeliveryContentForAutoRefillEnrolledUser() {
		PharmacyLandingTestPage pharmacy = new PharmacyLandingTestPage();
		
		pharmacy.getPharmacyBockDelivery().verifyPresent();
		pharmacy.getPharmacyImgDelivery().verifyPresent();
		pharmacy.getPharmacyTxtDelivery().verifyPresent();
		pharmacy.getPharmacyBlockRefillexpress().verifyNotPresent();
		pharmacy.getPharmacyLblSignupforautorefill().verifyNotPresent();
	}
	
	@QAFTestStep(description = "I Validate Google play store is displayed on clicking Google play button")
	public void IValidateGooglePlayStoreIsDisplayedOnClickingGooglePlayButton() {
		PharmacyLandingTestPage pharmacy = new PharmacyLandingTestPage();
		
		String parent = PerfectoUtils.getDriver().getWindowHandle();
		pharmacy.getPharmacyBtnGoogleplay().verifyPresent();
		pharmacy.getPharmacyBtnGoogleplay().click();
		
		for(String window : PerfectoUtils.getDriver().getWindowHandles()){
			if(!window.equals(parent))
				PerfectoUtils.getDriver().switchTo().window(window);
		}
		
		String URL = PerfectoUtils.getDriver().getCurrentUrl();
		String expURL = getBundle().getString("browse.googlePlayStore");
		
		if(URL.equals(expURL))
			PerfectoUtils.reportMessage("Google Play store is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Google Play store is not displayed", MessageTypes.Fail);
		
	}

}
