package com.automation.web.pages.myAccount;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class TaxExemptionTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}
	@FindBy(locator = "taxexemption.txt.taxexemptionheader")
	private QAFWebElement taxexemptionTxtTaxexemptionheader;
	@FindBy(locator = "taxexemption.lbl.register")
	private QAFWebElement taxexemptionLblRegister;	
	@FindBy(locator = "taxexemption.lbl.printform")
	private QAFWebElement taxexemptionLblPrintform;
	@FindBy(locator = "taxexemption.lnk.breadcrumb")
	private QAFWebElement taxexemptionLnkBreadcrumbr;	
	@FindBy(locator = "taxexemption.lnk.myaccbreadcrumb")
	private QAFWebElement taxexemptionLnkMyAccBreadcrumbr;
	@FindBy(locator = "taxexemption.lnk.homebreadcrumb")
	private QAFWebElement taxexemptionLnkHomebreadcrumb;
	@FindBy(locator = "taxexemption.lnk.imagingservice")
	private QAFWebElement taxexemptionLnkImagingService;	
	@FindBy(locator = "taxexemption.lbl.requirednote")
	private QAFWebElement taxexemptionLblRequirednote;
	@FindBy(locator = "taxexemption.lbl.id")
	private QAFWebElement taxexemptionLblID;	
	@FindBy(locator = "taxexemption.txt.id")
	private QAFWebElement taxexemptionTxtID;
	@FindBy(locator = "taxexemption.lbl.orgname")
	private QAFWebElement taxexemptionLblOrgName;
	@FindBy(locator = "taxexemption.lbl.taxexemptionstate")
	private QAFWebElement taxexemptionLblTaxexemptionstate;	
	@FindBy(locator = "taxexemption.dd.taxexemptionstate ")
	private QAFWebElement taxexemptionDDTaxexemptionstate;
	@FindBy(locator = "taxexemption.lbl.contactemail")
	private QAFWebElement taxexemptionLblContactEmail;	
	@FindBy(locator = "taxexemption.lbl.contactname")
	private QAFWebElement taxexemptionLblContactName;
	@FindBy(locator = "taxexemption.lbl.title")
	private QAFWebElement taxexemptionLblTitle;
	@FindBy(locator = "taxexemption.lbl.phoneno")
	private QAFWebElement taxexemptionLblPhoneNo;	
	@FindBy(locator = "taxexemption.lbl.registeras")
	private QAFWebElement taxexemptionLblRegisteras;
	@FindBy(locator = "taxexemption.dd.registeras")
	private QAFWebElement taxexemptionDDRegisteras;	
	@FindBy(locator = "taxexemption.lbl.businessdesc")
	private QAFWebElement taxexemptionLblBusinessdesc;
	@FindBy(locator = "taxexemption.lbl.generaldesc")
	private QAFWebElement taxexemptionLblGeneraldesc;
	@FindBy(locator = "taxexemption.txt.generaldesc")
	private QAFWebElement taxexemptionTxtGeneraldesc;
	@FindBy(locator = "taxexemption.lbl.orgaddress1")
	private QAFWebElement taxexemptionLblOrgaddress1;
	@FindBy(locator = "taxexemption.lbl.orgaddress2")
	private QAFWebElement taxexemptionLblOrgaddress2;	
	@FindBy(locator = "taxexemption.lbl.city")
	private QAFWebElement taxexemptionLblCity;
	@FindBy(locator = "taxexemption.lbl.state")
	private QAFWebElement taxexemptionLblState;
	@FindBy(locator = "taxexemption.dd.state")
	private QAFWebElement taxexemptionDDState;
	@FindBy(locator = "taxexemption.lbl.zip")
	private QAFWebElement taxexemptionLblZip;
	@FindBy(locator = "taxexemption.chk.iverify")
	private QAFWebElement taxexemptionChkIverify;	
	@FindBy(locator = "taxexemption.lbl.iverify")
	private QAFWebElement taxexemptionLblIverify;
	@FindBy(locator = "taxexemption.btn.continue")
	private QAFWebElement taxexemptionBtnContinue;	
	@FindBy(locator = "taxexemption.lnk.cancel")
	private QAFWebElement taxexemptionLnkCancel;
	@FindBy(locator = "taxexemption.lnk.couponsbreadcrumb")
	private QAFWebElement taxexemptionLnkCouponsBreadcrumb;
	@FindBy(locator = "taxexemption.lnk.digitalcouponsbreadcrumb")
	private QAFWebElement taxexemptionLnkDigitalCouponsBreadcrumb;
	@FindBy(locator = "taxexemption.lnk.printablecouponsbreadcrumb")
	private QAFWebElement taxexemptionLnkPrintableCouponsBreadcrumb;
	
	public QAFWebElement getTaxExemptionLnkCouponsBreadcrumb() {
		return taxexemptionLnkCouponsBreadcrumb;
	}
	public QAFWebElement getTaxExemptionLnkDigitalCouponsBreadcrumb() {
		return taxexemptionLnkDigitalCouponsBreadcrumb;
	}
	public QAFWebElement getTaxExemptionLnkPrintableCouponsBreadcrumb() {
		return taxexemptionLnkPrintableCouponsBreadcrumb;
	}
	public QAFWebElement getTaxExemptionLnkCancel() {
		return taxexemptionLnkCancel;
	}
	public QAFWebElement getTaxExemptionBtnContinue() {
		return taxexemptionBtnContinue;
	}
	public QAFWebElement getTaxExemptionLblIverify() {
		return taxexemptionLblIverify;
	}
	public QAFWebElement getTaxExemptionChkIverify() {
		return taxexemptionChkIverify;
	}
	public QAFWebElement getTaxExemptionLblZip() {
		return taxexemptionLblZip;
	}
	public QAFWebElement getTaxExemptionDDState() {
		return taxexemptionDDState;
	}
	public QAFWebElement getTaxExemptionLblState() {
		return taxexemptionLblState;
	}
	public QAFWebElement getTaxExemptionLblCity() {
		return taxexemptionLblCity;
	}
	public QAFWebElement getTaxExemptionLblOrgaddress2() {
		return taxexemptionLblOrgaddress2;
	}
	public QAFWebElement getTaxExemptionLblOrgaddress1() {
		return taxexemptionLblOrgaddress1;
	}
	public QAFWebElement getTaxExemptionTxtGeneraldesc() {
		return taxexemptionTxtGeneraldesc;
	}
	public QAFWebElement getTaxExemptionLblGeneraldesc() {
		return taxexemptionLblGeneraldesc;
	}
	public QAFWebElement getTaxExemptionLblBusinessdesc() {
		return taxexemptionLblBusinessdesc;
	}
	public QAFWebElement getTaxExemptionDDRegisteras() {
		return taxexemptionDDRegisteras;
	}
	public QAFWebElement getTaxExemptionLblRegisteras() {
		return taxexemptionLblRegisteras;
	}
	public QAFWebElement getTaxExemptionLblPhoneNo() {
		return taxexemptionLblPhoneNo;
	}
	public QAFWebElement getTaxExemptionLblTitle() {
		return taxexemptionLblTitle;
	}
	public QAFWebElement getTaxExemptionLblContactName() {
		return taxexemptionLblContactName;
	}
	public QAFWebElement getTaxExemptionLblContactEmail() {
		return taxexemptionLblContactEmail;
	}
	public QAFWebElement getTaxExemptionDDTaxexemptionstate() {
		return taxexemptionDDTaxexemptionstate;
	}
	public QAFWebElement getTaxExemptionLblTaxexemptionstate() {
		return taxexemptionLblTaxexemptionstate;
	}
	public QAFWebElement getTaxExemptionLblOrgName() {
		return taxexemptionLblOrgName;
	}
	public QAFWebElement getTaxExemptionTxtID() {
		return taxexemptionTxtID;
	}
	public QAFWebElement getTaxExemptionLblRequirednote() {
		return taxexemptionLblRequirednote;
	}
	public QAFWebElement getTaxExemptionLnkImagingService() {
		return taxexemptionLnkImagingService;
	}
	public QAFWebElement getTaxExemptionLblID() {
		return taxexemptionLblID;
	}
	public QAFWebElement getTaxExemptionLnkHomebreadcrumb() {
		return taxexemptionLnkHomebreadcrumb;
	}
	public QAFWebElement getTaxExemptionLnkMyAccBreadcrumbr() {
		return taxexemptionLnkMyAccBreadcrumbr;
	}
	public QAFWebElement getTaxExemptiontaxexemptionLnkBreadcrumbr() {
		return taxexemptionLnkBreadcrumbr;
	}
	public QAFWebElement getTaxExemptionLblPrintform() {
		return taxexemptionLblPrintform;
	}
	public QAFWebElement getTaxExemptionLblRegister() {
		return taxexemptionLblRegister;
	}
	public QAFWebElement getTaxExemptionTxtheader() {
		return taxexemptionTxtTaxexemptionheader;
	}

}