package com.automation.web.steps.weeklyads;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.components.MiniListPdtBlocks;
import com.automation.web.components.weeklyads.WeeklyAdsFromDealsPage;
import com.automation.web.pages.homepage.FrontdoorTestPage;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.myAccount.profileInformationTestpage;
import com.automation.web.pages.storelocator.FindAStoreTestPage;
import com.automation.web.pages.storelocator.StoreLocatorTestPage;
import com.automation.web.pages.storelocator.UpdateStoreTestPage;
import com.automation.web.pages.weeklyads.MapsAndDirectionsTestPage;
import com.automation.web.pages.weeklyads.MiniListTestPage;
import com.automation.web.pages.weeklyads.SelectstoretoviewadsTestPage;
import com.automation.web.pages.weeklyads.WeeklyAdsAndCouponsPage;
import com.automation.web.pages.weeklyads.WeeklyaddealsTestPage;
import com.automation.web.pages.weeklyads.WeeklyadprintversionTestPage;
import com.automation.web.pages.weeklyads.Weeklyadsdealsmodel;
import com.automation.web.steps.storelocator.StoreLocatorPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of steps in WeeklyAdsStepDef

* Navigate to Weeklyads page
* Click on Weekly ads from front door page
* Search for weeklyads using the zip code
* Select a store from the select a store to view ads page
* I should see the weekly ads for the selected store
* Navigate to print version of weekly ads
* Hover over a single product
* Verify single hover state appears with a dashed boarder
* Verify the properties of print version of weekly ad page
* Select Print option from the Print Version page
* Validate the Print options from Print Version page
* Click on Weekly ads from Instore homepage
* Click on Weekly ads from Instore homepage for mobile
* Click on Weekly ads from frontdoor homepage for mobile
* Click on Weekly ads from Instore homepage without selecting store
* Verify navigated to Weekly ads print view page
* Verify the properties of Weekly ad print view page
* Verify the properties of Weekly ad grid view page
* Enter a valid zipcode in select a store page
* Select a store from select a store page results
* Verify the selected store is updated in Weekly ads deals page
* Verify Navigated to maps and Directions page
* Select Category from the leftnav options
* Verify the category changed successfully
* Select Add to list from Weekly ads deals page
* Verify the Selected Pdt available in the Mini shopping list
* Verify the elements in Mini shopping list
* I navigate to print version of weekly ad
* Select Weekly ads tile from Instore homepage
* Verify navigated to Weekly ads and coupons page
* Verify the properties of Weekly ads and Coupons page
* Set a Store using the Set location flyout in the top section
* Change my preferred store via mouse hover on HEB online in the top section
* Select Weekly ads from Instore Homepage
* Verify directly lands in Weekly ads deals page
* Verify the user lands in Select a Store page
* Navigate to Weekly ad grid view page
* Navigate to url {0}
* MouseOver on weekly ad deal from printview page
* Validate weekly ad deal model is displayed from Grid View
* Validate weekly ad deal model is displayed from Print View
* Select weekly ad deal image from Grid view page
* Select weekly ad deal more details link from Grid view page
* Validate whether Make this my store link is under the store name & address of the store
* Validate on clicking Make this my store whether that store become thier profile store
* Validate whether Make this my store turn green and display as My HEB Store
* Validate My HEB Store is displayed when customer selects store from Store Locator
* Validate default zipcode {0} when the user is out of market
* Verify a customer can click the Add to List button on the weekly ad grid view
* Verify in WeeklyAds on clicking Add to List button gets greyed out disabled and changed to Added
* Verify Added button is not displayed on Weeklyads page refresh
* Validate zipcode {0} when the user is in market
* Sets mock location as {0} {1}
* Validate whether weeklyAds,name and address is displayed for the corresponding store selected
* Validate the same cookie store details are displayed in invalid weekly ad page
* Validate whether user gets nearby stores after choosing a specific store
* Verify user able to enter zip code for nearby store and corresponding stores are displayed
* Verify user able to enter zip code using enter key for nearby store and corresponding stores are displayed
* Validate user able to see List of stores in scroll list
* Validate user able to see list the Store name and address in the scroll list
* Validate user able to navigate back and forth on nearby store locator tool
* Validate user with store selecting another store to view ads already choosen store should not changed
* Validate error message under weeklyAds for stores with No weeklyAds
* Adding weekly ad to list from Print View model
* Validate default zipcode {0} in weekly ads page for {1} storeId
* Verify GRID View is displayed on clicking Weekly Ad links in Mobile size view
* Validate the featured deals drop down is hidden
* Validate whether WeeklyAd Header white Spaces are reduced

*/

public class WeeklyAdsStepDef {

	@QAFTestStep(description = "Navigate to Weeklyads page")
	public void navigateToWeeklyadsPage() {
		FrontdoorTestPage frontdoortestpage = new FrontdoorTestPage();
		SelectstoretoviewadsTestPage selectstore_weeklyads = new SelectstoretoviewadsTestPage();

		frontdoortestpage.getFrontImgWeeklyad().waitForPresent(10000);
		frontdoortestpage.getFrontImgWeeklyad().click();
		PerfectoUtils.reportMessage("Clicked on Weekly ads from front door page..");

		try {
			selectstore_weeklyads.getLblPageheader().waitForPresent(3000);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Store already selected..", MessageTypes.Pass);
		}

		if (selectstore_weeklyads.getLblPageheader().isPresent()) {
			enterZipcodeAndSelectStore();
		}

	}

	@QAFTestStep(description = "Click on Weekly ads from front door page")
	public void clickOnWeeklyAdsFromFrontDoorPage() {
		navigateToWeeklyadsPage();
	}

	public static void enterZipcodeAndSelectStore() {
		SelectstoretoviewadsTestPage selectstore_weeklyads = new SelectstoretoviewadsTestPage();

		if (selectstore_weeklyads.getLblPageheader().isPresent()) {
			searchForWeeklyadsUsingTheZipCode();
			selectAStoreFromTheSelectAStoreToViewAdsPage();
			iShouldSeeTheWeeklyAdsForTheSelectedStore();
		} else {
			PerfectoUtils.reportMessage("Error occured while navigating to weekly ads.".trim(), MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Search for weeklyads using the zip code")
	public static void searchForWeeklyadsUsingTheZipCode() {

		SelectstoretoviewadsTestPage selectstoretoviewads = new SelectstoretoviewadsTestPage();

		if (selectstoretoviewads.getTxtZipcode().isPresent()) {
			PerfectoUtils.scrolltoelement(selectstoretoviewads.getTxtZipcode());

			String strZipcode = getBundle().getString("selectStore.zipCode");
			selectstoretoviewads.getTxtZipcode().clear();
			selectstoretoviewads.getTxtZipcode().sendKeys(strZipcode);
			selectstoretoviewads.getBtnStorego().click();

		} else {
			PerfectoUtils.reportMessage("Zipcode field not found.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Select a store from the select a store to view ads page")
	public static void selectAStoreFromTheSelectAStoreToViewAdsPage() {
		SelectstoretoviewadsTestPage selectstoretoviewads = new SelectstoretoviewadsTestPage();
		WeeklyaddealsTestPage weeklyaddeals = new WeeklyaddealsTestPage();

		try {
			selectstoretoviewads.getLblStorenamelist().get(0).waitForPresent(30000);
		} catch (Exception e1) {
			selectstoretoviewads.getBtnStorego().click();
			selectstoretoviewads.getLblStorenamelist().get(0).waitForPresent(30000);
		}

		getBundle().setProperty("selectedStore", selectstoretoviewads.getLblStorenamelist().get(0).getText());
		selectstoretoviewads.getBtnViewadslist().get(0).click();

		PerfectoUtils.reportMessage("Selected the store: " + getBundle().getString("selectedStore"), MessageTypes.Pass);

		try {
			weeklyaddeals.getLblPageheader().waitForPresent(15000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@QAFTestStep(description = "I should see the weekly ads for the selected store")
	public static void iShouldSeeTheWeeklyAdsForTheSelectedStore() {
		WeeklyaddealsTestPage weeklyaddeals = new WeeklyaddealsTestPage();

		if (weeklyaddeals.getLblPageheader().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Weekly ads deals page.", MessageTypes.Pass);
			String strSelectedStore = getBundle().getString("selectedStore");
			String strStorenameInDealsPage = weeklyaddeals.getLblStorename().getText();

			PerfectoUtils.reportMessage("Selected store: " + strSelectedStore);
			PerfectoUtils.reportMessage("Store name in Weekly ad deals page: " + strStorenameInDealsPage);

		} else {
			PerfectoUtils.reportMessage("Not navigated to Weekly ad deals page.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Navigate to print version of weekly ads")
	public void navigateToPrintVersionOfWeeklyAd() {
		WeeklyaddealsTestPage weeklyaddeals = new WeeklyaddealsTestPage();
		WeeklyadprintversionTestPage printversion = new WeeklyadprintversionTestPage();

		if (weeklyaddeals.getLblViewprintversion().isPresent()) {
			PerfectoUtils.navigateToPage(weeklyaddeals.getLblViewprintversion(), printversion.getLblPageheader(),
					"View print version of weekly ad page");
		} else {
			PerfectoUtils.reportMessage("View print version of weekly ad option not found.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Hover over a single product")
	public void hoverOverASingleProduct() {

		verifyThePropertiesOfPrintVersionOfWeeklyAdPage();

	}

	@QAFTestStep(description = "Verify single hover state appears with a dashed boarder")
	public void verifySingleHoverStateAppearsWithADashedBoarder() {

	}

	@QAFTestStep(description = "Verify the properties of print version of weekly ad page")
	public void verifyThePropertiesOfPrintVersionOfWeeklyAdPage() {
		WeeklyadprintversionTestPage printversion = new WeeklyadprintversionTestPage();

		try {
			QAFWebElement QAFParentFrame = printversion.getIframeParent();
			PerfectoUtils.getDriver().switchTo().frame(QAFParentFrame);

			WebElement firstChildFrame = PerfectoUtils.getDriver().findElement(By.xpath("//iframe[@title='menus']"));
			PerfectoUtils.getDriver().switchTo().frame(firstChildFrame);

			// Checking whether the Tutorial pop up is present and clicking the
			// close button

			if (printversion.getLblTutorial().isPresent()) {
				PerfectoUtils.scrolltoelement(printversion.getLblTutorial());
				PerfectoUtils.reportMessage("Tutorial pop up found.", MessageTypes.Pass);
				printversion.getBtnTutorialclose().click();
				PerfectoUtils.reportMessage("Clicked on Tutorial pop up close button.", MessageTypes.Pass);
			}

			WebElement secondChildFrame = PerfectoUtils.getDriver()
					.findElement(By.xpath("//iframe[@title='Main Content']"));
			PerfectoUtils.getDriver().switchTo().frame(secondChildFrame);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Frames are not available. Server might Hanged up. Check the screen shots!",
					MessageTypes.Fail);
		}
		printversion.getImgIframeitems().verifyPresent();

		// PerfectoUtils.getDriver().switchTo().defaultContent();

	}

	@QAFTestStep(description = "Select Print option from the Print Version page")
	public void selectPrintOptionFromThePrintVersionPage() {
		WeeklyadprintversionTestPage printversiontestpage = new WeeklyadprintversionTestPage();

		// PerfectoUtils.getDriver().switchTo().parentFrame();
		/*
		 * WebElement firstChildFrame =
		 * PerfectoUtils.getDriver().findElement(By.xpath(
		 * "//iframe[@title='menus']"));
		 * PerfectoUtils.getDriver().switchTo().frame(firstChildFrame);
		 */
		// PerfectoUtils.getDriver().switchTo().defaultContent();

		try {
			PerfectoUtils.scrolltoelement(printversiontestpage.getLblMore());
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured while scrolling to More button.", MessageTypes.Fail);
		}
		printversiontestpage.getLblMore().waitForPresent(1000);
		printversiontestpage.getLblMore().click();

		printversiontestpage.getLnkPrint().waitForPresent(1000);
		printversiontestpage.getLnkPrint().click();

	}

	@QAFTestStep(description = "Validate the Print options from Print Version page")
	public void validateThePrintOptionsFromPrintVersionPage() {
		WeeklyadprintversionTestPage printversiontestpage = new WeeklyadprintversionTestPage();

		printversiontestpage.getLblPrinttitle().waitForPresent(1000);
		printversiontestpage.getLblPrinttitle().verifyPresent();
		printversiontestpage.getLblPrintall().verifyPresent();
		printversiontestpage.getLblPrintcurrent().verifyPresent();
		printversiontestpage.getLblPrintrange().verifyPresent();
		printversiontestpage.getBtnPrintsubmit().verifyPresent();
		printversiontestpage.getImgCloseprint().verifyPresent();

	}

	@QAFTestStep(description = "Click on Weekly ads from Instore homepage")
	public void clickOnWeeklyAdsFromInstoreHomepage() {
		InStoreHomePage instorehomepahe = new InStoreHomePage();
		SelectstoretoviewadsTestPage selectstore_weeklyads = new SelectstoretoviewadsTestPage();
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		
		instorehomepahe.getHomeLblHeaderweeklyad().waitForPresent(3000);
		instorehomepahe.getHomeLblHeaderweeklyad().click();
		PerfectoUtils.reportMessage("Clicked on Weekly ads from Instore header..");
		frontdoor.getFrontImgFav().verifyPresent();

		if (selectstore_weeklyads.getLblPageheader().isPresent()) {
			enterZipcodeAndSelectStore();
		}
	}

	@QAFTestStep(description = "Click on Weekly ads from Instore homepage for mobile")
	public void clickOnWeeklyAdsFromInstoreHomepageformobile() {
		InStoreHomePage instorehomepahe = new InStoreHomePage();

		instorehomepahe.getHomeLnkWeeklyadmobile().waitForPresent(3000);
		instorehomepahe.getHomeLnkWeeklyadmobile().click();
		PerfectoUtils.reportMessage("Clicked on Weekly ads from Instore header..");

	}

	@QAFTestStep(description = "Click on Weekly ads from frontdoor homepage for mobile")
	public void clickOnWeeklyAdsFromFrontDoorHomepageformobile() {
		FrontdoorTestPage front = new FrontdoorTestPage();

		front.getFrontImgWeeklyadmobile().waitForPresent(3000);
		front.getFrontImgWeeklyadmobile().click();
		PerfectoUtils.reportMessage("Clicked on Weekly ads from Frontdoor page..");

	}

	@QAFTestStep(description = "Click on Weekly ads from Instore homepage without selecting store")
	public void clickOnWeeklyAdsFromInstoreHomepagewithoutselectingstore() {
		InStoreHomePage instorehomepahe = new InStoreHomePage();

		instorehomepahe.getHomeLblHeaderweeklyad().waitForPresent(3000);
		instorehomepahe.getHomeLblHeaderweeklyad().click();
		PerfectoUtils.reportMessage("Clicked on Weekly ads from Instore header..");
	}

	@QAFTestStep(description = "Verify navigated to Weekly ads print view page")
	public void verifyNavigatedToWeeklyAdsPage() {
		WeeklyadprintversionTestPage weeklyadprint = new WeeklyadprintversionTestPage();

		weeklyadprint.getLblBreadcrumb().verifyPresent();

		if (weeklyadprint.getLblBreadcrumb().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Weekly ads Print view page..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not Navigated to Weekly ads Print view page..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the properties of Weekly ad print view page")
	public void verifyThePropertiesOfWeeklyAdPrintViewPage() {
		WeeklyadprintversionTestPage weeklyadprint = new WeeklyadprintversionTestPage();

		weeklyadprint.getLblPageheader().waitForPresent(5000);
		weeklyadprint.getBtnCategoryview().verifyPresent();
		weeklyadprint.getLblBreadcrumb().verifyPresent();

		if (weeklyadprint.getImgMenu().isPresent()) {
			PerfectoUtils.reportMessage("Weekly ads available in weekly ads page", MessageTypes.Pass);
			weeklyadprint.getLiImgWeeklyadproducts().get(0).verifyPresent();
			PerfectoUtils.reportMessage("Weekly ads available: " + weeklyadprint.getLiImgWeeklyadproducts().size(), MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("Weekly ads are not available in weekly ads page", MessageTypes.Info);
		}
	}

	@QAFTestStep(description = "Verify the properties of Weekly ad grid view page")
	public void verifyThePropertiesOfWeeklyAdGridViewPage() {
		WeeklyaddealsTestPage weeklyadsdealspage = new WeeklyaddealsTestPage();
		SelectstoretoviewadsTestPage store = new SelectstoretoviewadsTestPage();
		List<String> leftNavOption = new ArrayList<String>();

		weeklyadsdealspage.getWklyadLblFeatureddeals().waitForPresent(5000);

		store.getLblStoreName().verifyPresent();
		getBundle().setProperty("weeklyAdStore", store.getLblStoreName().getText());

		weeklyadsdealspage.getLblPageheader().verifyPresent();
		weeklyadsdealspage.getLblStorename().verifyPresent();
		weeklyadsdealspage.getWklyadLblStoreaddress().verifyPresent();
		weeklyadsdealspage.getLblViewprintversion().verifyPresent();
		weeklyadsdealspage.getWklyadImgLeftnavbar().verifyPresent();
		weeklyadsdealspage.getWklyadLblBycategory().verifyPresent();
		weeklyadsdealspage.getWklyadLblBreadcrumblast().verifyPresent();

		if (weeklyadsdealspage.getWklyadLiLeftnavoptions().size() > 0) {
			PerfectoUtils.reportMessage("Available weekly ads leftnav option By category:", MessageTypes.Pass);
			for (QAFWebElement ele : weeklyadsdealspage.getWklyadLiLeftnavoptions()) {
				leftNavOption.add(ele.getText());
			}
			PerfectoUtils.reportMessage(leftNavOption.toString());
		} else {
			PerfectoUtils.reportMessage("No options found in leftnav bar..", MessageTypes.Fail);
		}

		PerfectoUtils.scrolltoelement(weeklyadsdealspage.getWklyadLblFeatureddeals());
		weeklyadsdealspage.getWklyadLblFeatureddeals().verifyPresent();
		weeklyadsdealspage.getWklyadLblPricesvalid().verifyPresent();

		int weeklyadsSize = weeklyadsdealspage.getWklyadLiWeeklyadslist().size();
		if (weeklyadsSize > 0) {
			PerfectoUtils.reportMessage(weeklyadsSize + " Weekly ads found..", MessageTypes.Pass);
			for (WeeklyAdsFromDealsPage ele : weeklyadsdealspage.getWklyadLiWeeklyadslist()) {
				ele.getImgWeeklyadimage().verifyPresent();
				ele.getLblWeeklyadtitle().verifyPresent();
				ele.getLblWeeklyaditemprice().verifyPresent();
				ele.getBtnWeeklyadaddtolist().verifyPresent();
				break;
			}

		} else {
			PerfectoUtils.reportMessage("No Weeklyads found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Enter a valid zipcode in select a store page")
	public void enterAValidZipcodeInSelectAStorePage() {
		searchForWeeklyadsUsingTheZipCode();

	}

	@QAFTestStep(description = "Select a store from select a store page results")
	public void selectAStoreFromSelectAStorePageResults() {
		selectAStoreFromTheSelectAStoreToViewAdsPage();

	}

	@QAFTestStep(description = "Verify the selected store is updated in Weekly ads deals page")
	public void verifyTheSelectedStoreIsUpdatedInWeeklyAdsDealsPage() {
		iShouldSeeTheWeeklyAdsForTheSelectedStore();

	}

	@QAFTestStep(description = "Verify Navigated to maps and Directions page")
	public void verifyNavigatedToMapsAndDirectionsPage() throws Exception {
		MapsAndDirectionsTestPage mapsanddir = new MapsAndDirectionsTestPage();

		Thread.sleep(2000);
		mapsanddir.getLblAvaildepandservices().waitForPresent(20000);
		mapsanddir.getLblAvaildepandservices().verifyPresent();
		if (mapsanddir.getLblAvaildepandservices().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Maps and Services page..");
		} else {
			PerfectoUtils.reportMessage("Not navigated to Maps and Services page..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Select Category from the leftnav options")
	public void selectCategoryFromTheLeftnavOptions() {
		WeeklyaddealsTestPage deals = new WeeklyaddealsTestPage();

		deals.getWklyadLiLeftnavoptions().get(0).waitForPresent(5000);
		String categoryname = deals.getWklyadLiLeftnavoptions().get(0).getText();
		getBundle().setProperty("CategoryName", categoryname);
		deals.getWklyadLiLeftnavoptions().get(0).click();
		PerfectoUtils.reportMessage("Selected Category: " + categoryname);

	}

	@QAFTestStep(description = "Verify the category changed successfully")
	public void verifyTheCategoryChangedSuccessfully() {
		WeeklyaddealsTestPage deals = new WeeklyaddealsTestPage();

		String[] categoryname = getBundle().getString("CategoryName").split(" ");
		deals.getLblCategorytitledynamic(categoryname[0]).waitForPresent(5000);

		if (deals.getLblCategorytitledynamic(categoryname[0]).isPresent()) {
			PerfectoUtils.reportMessage("Category Changed successfully..");
		} else {
			PerfectoUtils.reportMessage("Error occured while changing Category..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Select Add to list from Weekly ads deals page")
	public void selectAddToListFromWeeklyAdsDealsPage() {
		WeeklyaddealsTestPage weeklyadsdealspage = new WeeklyaddealsTestPage();

		weeklyadsdealspage.getWklyadLiWeeklyadslist().get(0).waitForPresent(5000);
		int weeklyadsSize = weeklyadsdealspage.getWklyadLiWeeklyadslist().size();
		if (weeklyadsSize > 0) {
			PerfectoUtils.reportMessage(weeklyadsSize + " Weekly ads found..", MessageTypes.Pass);
			for (WeeklyAdsFromDealsPage ele : weeklyadsdealspage.getWklyadLiWeeklyadslist()) {

				PerfectoUtils.scrolltoelement(ele.getLblWeeklyadtitle());
				String pdtName = ele.getLblWeeklyadtitle().getText();
				ele.getBtnWeeklyadaddtolist().click();
				getBundle().setProperty("ProductName", pdtName);
				break;
			}

		} else {
			PerfectoUtils.reportMessage("No Weeklyads found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Selected Pdt available in the Mini shopping list")
	public void verifyTheSelectedPdtAvailableInTheMiniShoppingList() {
		MiniListTestPage minilist = new MiniListTestPage();

		boolean isPresent = false;
		String SelectedPdt = getBundle().getString("ProductName");
		minilist.getLblPagetitle().waitForPresent(10000);
		int pdtSize = minilist.getLiItemsegments().size();

		if (pdtSize > 0) {

			for (MiniListPdtBlocks ele : minilist.getLiItemsegments()) {

				String pdtname = ele.getLblItemdescriptions().getText();

				if (pdtname.equalsIgnoreCase(SelectedPdt)) {
					isPresent = true;
					break;
				}
			}

			if (isPresent)
				PerfectoUtils.reportMessage("Selected Pdt available in Mini shoppinglist..");
			else
				PerfectoUtils.reportMessage("Selected Pdt not available in Mini shoppinglist..", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("No Pdts found in mini shoppinglist..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the elements in Mini shopping list")
	public void verifyTheElementsInMiniShoppingList() {
		MiniListTestPage minilist = new MiniListTestPage();

		minilist.getLblPagetitle().waitForPresent(10000);
		minilist.getLblPagetitle().verifyPresent();
		minilist.getLblGotofulllist().verifyPresent();
		int pdtSize = minilist.getLiItemsegments().size();

		if (pdtSize > 0) {

			for (MiniListPdtBlocks ele : minilist.getLiItemsegments()) {
				ele.getLiItemimage().verifyPresent();
				ele.getLblItemdescriptions().verifyPresent();
				break;
			}
		} else {
			PerfectoUtils.reportMessage("No Pdts found in mini shoppinglist..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I navigate to print version of weekly ad")
	public void iNavigateToPrintVersionOfWeeklyAd() {
		WeeklyaddealsTestPage weeklyaddeals = new WeeklyaddealsTestPage();
		WeeklyadprintversionTestPage printversion = new WeeklyadprintversionTestPage();

		if (weeklyaddeals.getLblViewprintversion().isPresent()) {
			PerfectoUtils.navigateToPage(weeklyaddeals.getLblViewprintversion(), printversion.getLblPageheader(),
					"View print version of weekly ad page");
		} else {
			PerfectoUtils.reportMessage("View print version of weekly ad option not found.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Select Weekly ads tile from Instore homepage")
	public void selectWeeklyAdsTileFromInstoreHomepage() {
		InStoreHomePage instore = new InStoreHomePage();

		instore.getHomeLblWeeklyadandcoupons().waitForPresent(10000);
		instore.getHomeLblWeeklyadandcoupons().click();
		PerfectoUtils.reportMessage("Clicked on weekly ads tile..");
	}

	@QAFTestStep(description = "Verify navigated to Weekly ads and coupons page")
	public void verifyNavigatedToWeeklyAdsAndCouponsPage() {
		WeeklyAdsAndCouponsPage wklyadsandcoupons = new WeeklyAdsAndCouponsPage();

		wklyadsandcoupons.getLblPageheader().waitForPresent(10000);
		if (wklyadsandcoupons.getLblPageheader().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Weekly ads and Coupons page..");
		} else {
			PerfectoUtils.reportMessage("Error occured while navigating to Weekly ads and Coupons page..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the properties of Weekly ads and Coupons page")
	public void verifyThePropertiesOfWeeklyAdsAndCouponsPage() {
		WeeklyAdsAndCouponsPage wklyadsandcoupons = new WeeklyAdsAndCouponsPage();

		wklyadsandcoupons.getLblPageheader().waitForPresent(3000);
		wklyadsandcoupons.getLblPageheader().verifyPresent();
		wklyadsandcoupons.getLblYourwklyads().verifyPresent();
		wklyadsandcoupons.getImgYourwklyadsimg().verifyPresent();
		wklyadsandcoupons.getLblCouponscenter().verifyPresent();
		wklyadsandcoupons.getImgCouponscenterimg().verifyPresent();
		wklyadsandcoupons.getTxtEnterzipcode().verifyPresent();
		wklyadsandcoupons.getBtnGo().verifyPresent();
		wklyadsandcoupons.getLnkLogintoaccount().verifyPresent();
		wklyadsandcoupons.getLblDigitalcoupons().verifyPresent();
		wklyadsandcoupons.getBtnSeedigitalcoupons().verifyPresent();
		wklyadsandcoupons.getLnkLearnmoreabtcoupons().verifyPresent();
		wklyadsandcoupons.getLnkLearnmoreabtcoupons().verifyPresent();
		wklyadsandcoupons.getLnkCheckoutmobapp().verifyPresent();
		wklyadsandcoupons.getLnkDigitalcouponsfaqs().verifyPresent();
		wklyadsandcoupons.getLblPrintablecoupons().verifyPresent();
		wklyadsandcoupons.getBtnSeeandprintcoupons().verifyPresent();
		wklyadsandcoupons.getLnkViewcouponspolicy().verifyPresent();
	}

	@QAFTestStep(description = "Set a Store using the Set location flyout in the top section")
	public void setAStoreUsingTheSetLocationFlyoutInTheTopSection() {

		String zipcode = getBundle().getString("zip.validzip");
		StoreLocatorPage.iEnterAValidZipcodeClickFindButton(zipcode);
		StoreLocatorPage.iEnterAValidZipcodeClickFindButton(zipcode);
		selectAStoreFromFindAStorePage();
	}

	public void selectAStoreFromFindAStorePage() {
		FindAStoreTestPage findastore = new FindAStoreTestPage();

		findastore.getFindstoreLiStorenameslist().get(0).waitForPresent(5000);
		PerfectoUtils.scrolltoelement(findastore.getFindstoreLiStorenameslist().get(0));
		String selectedStore = findastore.getFindstoreLiStorenameslist().get(0).getText();
		getBundle().setProperty("selectedStore", selectedStore);
		findastore.getFindstoreBtnSelect().get(0).click();
		PerfectoUtils.reportMessage("Selected Store: " + selectedStore);
	}

	@QAFTestStep(description = "Change my preferred store via mouse hover on HEB online in the top section")
	public void changeMyPreferredStoreViaMouseHoverOnHEBOnlineInTheTopSection() {
		InStoreHomePage instore = new InStoreHomePage();
		profileInformationTestpage profileinfo = new profileInformationTestpage();
		UpdateStoreTestPage updatestore = new UpdateStoreTestPage();

		PerfectoUtils.mouseoverandclick(instore.getLnkHebonline(), instore.getLnkChangemypreferredstore());

		profileinfo.getProfileLnkEditstore().waitForPresent(10000);
		profileinfo.getProfileLnkEditstore().click();
		PerfectoUtils.reportMessage("Clicked on Edit Store option in Profile Information page..");

		updatestore.getLblPageheader().waitForPresent(10000);
		enterValidZipcodeAndSelectAStoreFromUpdateStorePage();
	}

	public void enterValidZipcodeAndSelectAStoreFromUpdateStorePage() {
		UpdateStoreTestPage updatestore = new UpdateStoreTestPage();

		String zipcode = getBundle().getString("zip.validzip");

		updatestore.getTxtEnterzipcode().clear();
		updatestore.getTxtEnterzipcode().sendKeys(zipcode);

		updatestore.getBtnGo().waitForPresent(1000);
		updatestore.getBtnGo().click();
		PerfectoUtils.reportMessage("Entered valid zipcode: " + zipcode + " and selected Go button..", MessageTypes.Pass);

		updatestore.getLiStorenameslist().get(0).waitForPresent(30000);
		String selectedStore = updatestore.getLiStorenameslist().get(0).getText();
		getBundle().setProperty("selectedStore", selectedStore);

		updatestore.getBtnSelect().get(0).click();
		PerfectoUtils.reportMessage("Selected Store " + selectedStore, MessageTypes.Pass);
	}

	@QAFTestStep(description = "Select Weekly ads from Instore Homepage")
	public void selectWeeklyAdsFromInstoreHomepage() {
		InStoreHomePage instorehomepahe = new InStoreHomePage();

		instorehomepahe.getHomeLblHeaderweeklyad().waitForPresent(3000);
		instorehomepahe.getHomeLblHeaderweeklyad().click();
		PerfectoUtils.reportMessage("Clicked on Weekly ads from Instore header..");
	}

	@QAFTestStep(description = "Verify directly lands in Weekly ads deals page")
	public void verifyDirectlyLandsInWeeklyAdsDealsPage() {
		verifyNavigatedToWeeklyAdsPage();
	}

	@QAFTestStep(description = "Verify the user lands in Select a Store page")
	public void verifyTheUserLandsInSelectAStorePage() {
		SelectstoretoviewadsTestPage selectstore_weeklyads = new SelectstoretoviewadsTestPage();

		if (selectstore_weeklyads.getLblPageheader().isPresent()) {
			PerfectoUtils.reportMessage("In Select a Store page..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not in Select a store page..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Navigate to Weekly ad grid view page")
	public void navigateToWeeklyAdGridViewPage() {
		WeeklyadprintversionTestPage printversion = new WeeklyadprintversionTestPage();

		printversion.getBtnCategoryview().verifyPresent();
		printversion.getBtnCategoryview().click();
	}

	@QAFTestStep(description = "Navigate to url {0}")
	public void navigateToWeeklyAdsCategoryPageUrl(String url) {
		PerfectoUtils.getDriver().get(url);
	}

	@QAFTestStep(description = "MouseOver on weekly ad deal from printview page")
	public void mouseOverOnWeeklyAdDealFromPrintviewPage() {
		WeeklyadprintversionTestPage printversion = new WeeklyadprintversionTestPage();
		Weeklyadsdealsmodel model = new Weeklyadsdealsmodel();

		printversion.waitForAjaxToComplete();
		PerfectoUtils.getDriver().switchTo().frame(printversion.getIframeParent());
		PerfectoUtils.getDriver().switchTo().frame(printversion.getIframeFirstchild());
		PerfectoUtils.getDriver().switchTo().frame(printversion.getIframeSecondchild());
		
		if(printversion.getPrintversionLiImgWeeklyads().size()>0){
		printversion.getPrintversionLiImgWeeklyads().get(0).verifyPresent();
		printversion.getPrintversionLiImgWeeklyads().get(0).click();
		}

		PerfectoUtils.getDriver().waitForAjax(50000);

		printversion.getPrintversionLiImgWeeklyaddeals().get(0).waitForPresent(60000);

		for (int i = 0; i < printversion.getPrintversionLiImgWeeklyaddeals().size(); i++) {

			printversion.getPrintversionLiImgWeeklyaddeals().get(i).waitForPresent(5000);

			if (printversion.getPrintversionLiImgWeeklyaddeals().get(i).getAttribute("title").contains("heb.com")) {
				continue;
			} else {
				PerfectoUtils.scrolltoelement(printversion.getPrintversionLiImgWeeklyaddeals().get(i));
				PerfectoUtils.mousehover(printversion.getPrintversionLiImgWeeklyaddeals().get(i));
				PerfectoUtils.mousehover(printversion.getPrintversionLiImgWeeklyaddeals().get(i));
				PerfectoUtils.waitForJSandJQueryToLoad(50000);
//				printversion.getPrintversionImgSelectedweeklyaddeals().waitForPresent(50000);
//				PerfectoUtils.mousehover(printversion.getPrintversionImgSelectedweeklyaddeals());
//				printversion.getPrintversionLiImgWeeklyaddeals().get(i).click();
				break;
			}
		}

		printversion.waitForAjaxToComplete();
		PerfectoUtils.getDriver().switchTo().defaultContent();
		printversion.waitForAjaxToComplete();
		PerfectoUtils.getDriver().switchTo().activeElement();
		model.getWeeklyadmodelPrintLblHeader().waitForPresent(50000);
		
	}

	@QAFTestStep(description = "Validate weekly ad deal model is displayed from Grid View")
	public void validateWeeklyAdDealModelIsDisplayedFromGridView() {
		Weeklyadsdealsmodel model = new Weeklyadsdealsmodel();

		model.getWeeklyadmodelGridLblHeader().verifyPresent();
		model.getWeeklyadmodelGridBtnAddtolist().verifyPresent();
		model.getWeeklyadmodelGridLblDescription().verifyPresent();
		model.getWeeklyadmodelGridLblValiddate().verifyPresent();
		model.getWeeklyadmodelGridBtnCollpase().verifyPresent();
		model.getWeeklyadmodelGridBtnCollpase().click();
	}

	@QAFTestStep(description = "Validate weekly ad deal model is displayed from Print View")
	public void validateWeeklyAdDealModelIsDisplayedFromPrintView() {
		Weeklyadsdealsmodel model = new Weeklyadsdealsmodel();

		model.getWeeklyadmodelPrintLblHeader().verifyPresent();
		model.getWeeklyadmodelPrintBtnAddtolist().verifyPresent();
		model.getWeeklyadmodelPrintLblDescription().verifyPresent();
		model.getWeeklyadmodelPrintLblValiddate().verifyPresent();
		model.getWeeklyadmodelPrintBtnCollpase().verifyPresent();
		model.getWeeklyadmodelPrintBtnCollpase().click();
	}

	@QAFTestStep(description = "Select weekly ad deal image from Grid view page")
	public void selectWeeklyAdDealImageFromGridViewPage() {
		WeeklyaddealsTestPage gridview = new WeeklyaddealsTestPage();

		int weeklyAdSize = gridview.getWklyadLiWeeklyadslist().size();
		PerfectoUtils.reportMessage(weeklyAdSize + " Weekly ads are displaying");

		gridview.getWklyadLiWeeklyadslist().get(0).getImgWeeklyadimage().verifyPresent();
		gridview.getWklyadLiWeeklyadslist().get(0).getImgWeeklyadimage().click();
	}

	@QAFTestStep(description = "Select weekly ad deal more details link from Grid view page")
	public void selectWeeklyAdDealMoreDetailsLinkFromGridViewPage() {
		WeeklyaddealsTestPage gridview = new WeeklyaddealsTestPage();

		int weeklyAdSize = gridview.getWklyadLiWeeklyadslist().size();
		PerfectoUtils.reportMessage(weeklyAdSize + " Weekly ads are displaying");

		gridview.getWklyadLiWeeklyadslist().get(0).getLnkMoredetails().verifyPresent();
		gridview.getWklyadLiWeeklyadslist().get(0).getLnkMoredetails().click();
	}

	@QAFTestStep(description = "Validate whether Make this my store link is under the store name & address of the store")
	public void validateMakethismystoreLink() {
		SelectstoretoviewadsTestPage makethismystore = new SelectstoretoviewadsTestPage();

		makethismystore.getLblStoreNameUnderDeals().verifyPresent();
		makethismystore.getLblMakeThisMyStoreUnderStoreName().verifyPresent();
		makethismystore.getLnkMakeThisMyStore().verifyPresent();
	}

	@QAFTestStep(description = "Validate on clicking Make this my store whether that store become thier profile store")
	public void validateStoreBecomeProfileStoreOnClickMakethismystoreLink() {
		SelectstoretoviewadsTestPage makethismystore = new SelectstoretoviewadsTestPage();
		makethismystore.getLnkMakeThisMyStore().click();
		makethismystore.waitForPageToLoad();
		makethismystore.waitForAjaxToComplete();

		String storeNameunderDeals = makethismystore.getLblStoreName().getText();
		String storeNameinTop = makethismystore.getLblStoreNameintop().getText();
		getBundle().setProperty("selectedStrName", storeNameunderDeals);
		
		if (storeNameunderDeals.equals(storeNameinTop))
			PerfectoUtils.reportMessage("Store has been successfully become thier profile store on clicking Make this my store",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Store has not become thier profile store on clicking Make this my store", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Validate whether Make this my store turn green and display as My HEB Store")
	public void validateMakethismystoreturngreenanddisplayasMyHEBStore() {
		SelectstoretoviewadsTestPage makethismystore = new SelectstoretoviewadsTestPage();
		String colourGreen = ConfigurationManager.getBundle().getString("weeklyads.myHEBStore.rgbaColourCode.green");

		makethismystore.getLnkMakeThisMyStore().click();
		makethismystore.waitForAjaxToComplete();
		makethismystore.waitForPageToLoad();
		makethismystore.waitForAjaxToComplete();

		if (makethismystore.getLblMyHebStoreGreen().getCssValue("color").equalsIgnoreCase(colourGreen)) {
			PerfectoUtils.reportMessage("Make this my store turns green on clicking Make this my store", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Make this my store does not turn green on clicking Make this my store", MessageTypes.Fail);
		}

		if (makethismystore.getIcnMyHebStoreTick().isPresent())
			PerfectoUtils.reportMessage("Tick Mark Icon is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Tick Mark Icon is not displayed", MessageTypes.Fail);

		if (PerfectoUtils.removeSpecialCharacters(makethismystore.getLblMyHebStoreGreen().getText())
				.equalsIgnoreCase("MyHEBStore"))
			PerfectoUtils.reportMessage("Make this my store displayed as My HEB Store", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Make this my store not displayed as My HEB Store", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Validate My HEB Store is displayed when customer selects store from Store Locator")
	public void validateMyHEBStoreisdisplayed_SelectsStorefromStoreLocator() {
		SelectstoretoviewadsTestPage makethismystore = new SelectstoretoviewadsTestPage();
		StoreLocatorTestPage storelocator = new StoreLocatorTestPage();
		FindAStoreTestPage findastore = new FindAStoreTestPage();

		String zipCode = makethismystore.getTxtChangeZipcode().getText();
		storelocator.getLnkFindStore().click();
		storelocator.getTbxEnterStore().click();
		storelocator.getTbxEnterStore().sendKeys(zipCode);
		storelocator.getBtnSearch().click();
		PerfectoUtils.scrolltoelement(findastore.getLblPageInitialCount());
		String storeCounttxt = findastore.getLblPageInitialCount().getText();

		PerfectoUtils.scrolltoelement(findastore.getLblStoreNameforSelect(1));
		String storeName = findastore.getLblStoreNameforSelect(1).getText().trim();
		PerfectoUtils.scrolltoelement(findastore.getBtnStoreforSelect(1));
		findastore.getBtnStoreforSelect(1).click();

		makethismystore.waitForPageToLoad();
		makethismystore.waitForAjaxToComplete();
		makethismystore.getLblStoreName().waitForPresent(5000);
		String storeNameunderDeals = makethismystore.getLblStoreName().getText();

		if (makethismystore.getLblMyHebStoreGreen().verifyPresent())
			PerfectoUtils.reportMessage("Make this my store turns green on clicking Make this my store", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Make this my store does not turn green on clicking Make this my store", MessageTypes.Fail);

		if (makethismystore.getIcnMyHebStoreTick().verifyPresent())
			PerfectoUtils.reportMessage("Tick Mark Icon is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Tick Mark Icon is not displayed", MessageTypes.Fail);

		if (PerfectoUtils.removeSpecialCharacters(makethismystore.getLblMyHebStoreGreen().getText())
				.equalsIgnoreCase("MyHEBStore"))
			PerfectoUtils.reportMessage("Make this my store is displayed as My HEB Store", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Make this my store is not displayed as My HEB Store", MessageTypes.Fail);

		if (storeName.equals(storeNameunderDeals))
			PerfectoUtils.reportMessage("My HEB Store is displayed when customer selects store from Store Locator", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("My HEB Store is not displayed when customer selects store from Store Locator",
					MessageTypes.Fail);
	}

	@QAFTestStep(description = "Validate default zipcode {0} when the user is out of market")
	public void validateDefaultZipcodeWhenTheUserIsOutOfMarket(String defaultZipCode) {
		SelectstoretoviewadsTestPage weeklyadstore = new SelectstoretoviewadsTestPage();

		weeklyadstore.getLblStoreNameintop().verifyPresent();

		if (weeklyadstore.getLblStoreNameintop().getText().equalsIgnoreCase("Find Your Store")
				|| weeklyadstore.getLblStoreNameintop().getText().equalsIgnoreCase("H‑E‑B Online")) {
			PerfectoUtils.reportMessage("User is out of market", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User is in market", MessageTypes.Fail);
		}

		weeklyadstore.getTxtChangeZipcode().verifyPresent();
		String actZipCode = weeklyadstore.getTxtChangeZipcode().getText();

		if (actZipCode.equalsIgnoreCase(defaultZipCode)) {
			PerfectoUtils.reportMessage("Default zipcode is displayed correctly as " + actZipCode, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Default zipcode is not displayed correctly. Actual zipCode displaying is " + actZipCode,
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify a customer can click the Add to List button on the weekly ad grid view")
	public void verifyCustomerClickAddtoListbuttonontheweeklyadgridview() {
		WeeklyaddealsTestPage gridview = new WeeklyaddealsTestPage();
		MiniListTestPage minilist = new MiniListTestPage();

		gridview.getWklyadLiWeeklyadslist().get(0).getBtnWeeklyadaddtolist().verifyPresent();
		gridview.getWklyadLiWeeklyadslist().get(0).getBtnWeeklyadaddtolist().click();
		minilist.getImgClosewindow().waitForVisible(50000);
		minilist.getLblPagetitle().verifyPresent();
		minilist.getImgClosewindow().click();
	}

	@QAFTestStep(description = "Verify in WeeklyAds on clicking Add to List button gets greyed out disabled and changed to Added")
	public void verifyClickAddtoListbuttonchangedtoAdded() {
		WeeklyaddealsTestPage gridview = new WeeklyaddealsTestPage();
		MiniListTestPage minilist = new MiniListTestPage();

		gridview.getWklyadLiWeeklyadslist().get(0).getBtnWeeklyadaddtolist().click();
		minilist.getImgClosewindow().waitForVisible(50000);
		minilist.getLblPagetitle().verifyPresent();
		minilist.getImgClosewindow().click();

		if (gridview.getLnkAdded().verifyPresent())
			PerfectoUtils.reportMessage("Add to List button circle tick mark is dispalyed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Add to List button tick mark is not dispalyed", MessageTypes.Fail);

		if (gridview.getLblAdded().getText().trim().equals("Added"))
			PerfectoUtils.reportMessage("Add to List button changed to Added", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Add to List button is not changed to Added", MessageTypes.Fail);

		if (gridview.getLblAdded().getCssValue("background-color")
				.equals(ConfigurationManager.getBundle().getString("weeklyads.addedBtn.rgbaColourCode.grey")))
			PerfectoUtils.reportMessage("Add to List button gets greyed out disabled", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Add to List button not greyed out", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Verify Added button is not displayed on Weeklyads page refresh")
	public void verifyAddedNotDisplayedonRefresh() {
		WeeklyaddealsTestPage gridview = new WeeklyaddealsTestPage();
		MiniListTestPage minilist = new MiniListTestPage();

		gridview.getWklyadLiWeeklyadslist().get(0).getBtnWeeklyadaddtolist().click();
		minilist.getImgClosewindow().waitForVisible(50000);
		minilist.getLblPagetitle().verifyPresent();
		minilist.getImgClosewindow().click();

		if (gridview.getLblAdded().getText().trim().equals(ConfigurationManager.getBundle().getString("Added")))
			PerfectoUtils.reportMessage("Add to List button changed to Added", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Add to List button is not changed to Added", MessageTypes.Fail);

		PerfectoUtils.getDriver().navigate().refresh();

		gridview.getLblAdded().verifyNotPresent();
	}

	@QAFTestStep(description = "Validate zipcode {0} when the user is in market")
	public void validateZipcodeWhenTheUserIsInMarket(String ZipCode) {
		SelectstoretoviewadsTestPage weeklyadstore = new SelectstoretoviewadsTestPage();

		weeklyadstore.getLblStoreNameintop().verifyPresent();

		PerfectoUtils.reportMessage(
				"User is in market and store displays on the top is " + weeklyadstore.getLblStoreNameintop().getText(),
				MessageTypes.Pass);

		weeklyadstore.getTxtChangeZipcode().verifyPresent();
		String actZipCode = weeklyadstore.getTxtChangeZipcode().getText();

		if (actZipCode.equalsIgnoreCase(ZipCode)) {
			PerfectoUtils.reportMessage("Zipcode is displayed correctly as " + actZipCode, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Zipcode is not displayed correctly. Actual zipCode displaying is " + actZipCode,
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Sets mock location as {0} {1}")
	public void SetsMockLocationAs(String latitude, String longitude) {

		PerfectoUtils.setMockLocation(latitude, longitude);
		PerfectoUtils.getDriver().navigate().refresh();
	}

	// Clarification Pending for address to be displayed for the corresponding
	// store selected
	@QAFTestStep(description = "Validate whether weeklyAds,name and address is displayed for the corresponding store selected")
	public void validateWeeklyAds_Name_Address_displayedforcorrespondingstoreselected() {
		WeeklyaddealsTestPage gridview = new WeeklyaddealsTestPage();
		SelectstoretoviewadsTestPage makethismystore = new SelectstoretoviewadsTestPage();

		String storeNamewithWeeklyAd = ConfigurationManager.getBundle().getString("weeklyads.WeeklyAdstore");
		int flag = 0;

		for (int storelistcount = 1; storelistcount <= 9; storelistcount++) {
			if (makethismystore.getNearbyStoresName(storelistcount).equals(storeNamewithWeeklyAd)) {
				makethismystore.getNearbyStoresName(storelistcount).click();
				break;
			}
		}
		String storeNameunderDeals = makethismystore.getLblStoreName().getText();

		if (storeNameunderDeals.equals(storeNamewithWeeklyAd))
			PerfectoUtils.reportMessage("StoreName displayed successfully for the corresponding store selected", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("StoreName is not displayed for the corresponding store selected", MessageTypes.Fail);

		if (gridview.getWklyadLiWeeklyadslist().size() != 0)
			PerfectoUtils.reportMessage("WeeklyAds is getting displayed successfully for the corresponding store selected",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("WeeklyAds is not displayed for the corresponding store selected", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Validate the same cookie store details are displayed in invalid weekly ad page")
	public void validateTheSameCookieStoreDetailsAreDisplayedInInvalidWeeklyAdPage() {
		WeeklyaddealsTestPage weeklyadsdealspage = new WeeklyaddealsTestPage();
		SelectstoretoviewadsTestPage store = new SelectstoretoviewadsTestPage();

		weeklyadsdealspage.getWklyadLblFeatureddeals().waitForPresent(5000);
		weeklyadsdealspage.getLblPageheader().verifyPresent();
		String expWeeklyAdStore = getBundle().getString("weeklyAdStore");
		String actWeeklyAdStore = store.getLblStoreName().getText();

		if (expWeeklyAdStore.equalsIgnoreCase(actWeeklyAdStore)) {
			PerfectoUtils.reportMessage("Same Cookie store name is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Same Cookie store name is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate whether user gets nearby stores after choosing a specific store")
	public void validateUserGetsNearbyStoresAfterChoosingaSpecificStore() {
		SelectstoretoviewadsTestPage makethismystore = new SelectstoretoviewadsTestPage();
		StoreLocatorTestPage getLnkFindStore = new StoreLocatorTestPage();
		FindAStoreTestPage findstore = new FindAStoreTestPage();

		makethismystore.getTxtChangeZipcode().click();
		makethismystore.getEdtZipcode().clear();
		makethismystore.getEdtZipcode()
				.sendKeys(ConfigurationManager.getBundle().getString("weeklyads.zipcode.changezipcode"));
		makethismystore.getLblFeatureddeals().click();

		makethismystore.waitForPageToLoad();
		makethismystore.waitForAjaxToComplete();
		String storenameselectedWeeklyAds = makethismystore.getLblStoreName().getText();
		makethismystore.getNearbyStoresName(1).waitForVisible(5000);
		String firstWeeklyAdStore = makethismystore.getNearbyStoresName(1).getText();
		if (PerfectoUtils.removeSpecialCharacters(storenameselectedWeeklyAds).equals(PerfectoUtils.removeSpecialCharacters(firstWeeklyAdStore)))
			PerfectoUtils.reportMessage("WeeklyAds store selected is getting displayed in the first nearby stores list successfully",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("WeeklyAds store selected is not displayed in the first nearby stores list",
					MessageTypes.Fail);

		List<String> weeklyAdStoreNames = new ArrayList<>();
		List<String> storeresultsStoreNames = new ArrayList<>();

		for (int count = 1; count <= 9; count++) {
			weeklyAdStoreNames.add(makethismystore.getNearbyStoresName(count).getText());
			System.out.println(weeklyAdStoreNames);
		}

		getLnkFindStore.getLnkFindStore().click();
		getLnkFindStore.getTbxEnterStore().click();
		getLnkFindStore.getTbxEnterStore().clear();
		getLnkFindStore.getTbxEnterStore()
				.sendKeys(ConfigurationManager.getBundle().getString("weeklyads.zipcode.changezipcode"));
		getLnkFindStore.getBtnSearch().click();
		getLnkFindStore.getStoreResultsStoreName("1", "1").waitForVisible(50000);

		for (int count = 1; count <= 4; count++) {
			storeresultsStoreNames
					.add(getLnkFindStore.getStoreResultsStoreName("1", Integer.toString(count)).getText());
			System.out.println(storeresultsStoreNames);
		}

		for (int count = 5; count <= 8; count++) {
			storeresultsStoreNames
					.add(getLnkFindStore.getStoreResultsStoreName("2", Integer.toString(count)).getText());
			System.out.println(storeresultsStoreNames);
		}

		findstore.getBtnLoadNext().click();
		getLnkFindStore.getStoreResultsStoreName("3", "9").waitForVisible(50000);

		storeresultsStoreNames.add(getLnkFindStore.getStoreResultsStoreName("3", "9").getText());
		System.out.println(storeresultsStoreNames);

		for (int i = 0; i < 9; i++) {
			if (weeklyAdStoreNames.get(i).equals(storeresultsStoreNames.get(i)))
				PerfectoUtils.reportMessage(
						weeklyAdStoreNames.get(i)
								+ " store name in WeeklyAds is nearer as equal to the store results in the find a store",
						MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage(weeklyAdStoreNames.get(i)
						+ " store name in WeeklyAds is not nearer as equal to the store results in the find a store "
						+ storeresultsStoreNames.get(i), MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify user able to enter zip code for nearby store and corresponding stores are displayed")
	public void verifyUserabletoenterzipcodefornearbystoreandcorrespondingstoresdisplayed() {
		SelectstoretoviewadsTestPage makethismystore = new SelectstoretoviewadsTestPage();
		StoreLocatorTestPage storeloc = new StoreLocatorTestPage();

		makethismystore.getTxtChangeZipcode().click();
		makethismystore.getEdtZipcode().clear();
		makethismystore.getEdtZipcode()
				.sendKeys(ConfigurationManager.getBundle().getString("weeklyads.zipcode.changezipcode"));
		makethismystore.getLblFeatureddeals().click();

		String storenameselectedWeeklyAds = makethismystore.getLblStoreName().getText();
		String firstWeeklyAdStore = makethismystore.getNearbyStoresName(1).getText();
		
		if (storenameselectedWeeklyAds.equals(firstWeeklyAdStore))
			PerfectoUtils.reportMessage("WeeklyAds store selected is getting displayed in the first nearby stores list successfully",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("WeeklyAds store selected is not displayed in the first nearby stores list",
					MessageTypes.Fail);

		List<String> weeklyAdStoreNames = new ArrayList<>();
		List<String> storeresultsStoreNames = new ArrayList<>();

		for (int count = 1; count < 10; count++) {
			weeklyAdStoreNames.add(makethismystore.getNearbyStoresName(count).getText().trim());
			System.out.println(weeklyAdStoreNames);
		}
		storeloc.getLnkFindStore().click();
		storeloc.getTbxEnterStore().click();
		storeloc.getTbxEnterStore().clear();
		storeloc.getTbxEnterStore()
				.sendKeys(ConfigurationManager.getBundle().getString("weeklyads.zipcode.changezipcode"));
		storeloc.getBtnSearch().click();
		storeloc.waitForAjaxToComplete();
		storeloc.getBtnLoadMoreStores().click();
		storeloc.waitForAjaxToComplete();
		
		storeloc.getTxtStorersName().get(0).waitForPresent(5000);
		for (int i = 0; i < 9; i++) {
			storeresultsStoreNames.add(storeloc.getTxtStorersName().get(i).getText().trim());
		}
		System.out.println(storeresultsStoreNames);

		for (int i = 0; i < 9; i++) {
			if (weeklyAdStoreNames.get(i).equalsIgnoreCase(storeresultsStoreNames.get(i))) {
				PerfectoUtils.reportMessage(storeresultsStoreNames.get(i) + " corresponding stores are displayed", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage(storeresultsStoreNames.get(i) + " corresponding store " + weeklyAdStoreNames.get(i)+ " is not displayed", MessageTypes.Fail);
			}
		}

	}
	
	@QAFTestStep(description = "Verify user able to enter zip code using enter key for nearby store and corresponding stores are displayed")
	public void verifyUserAbleToEnterZipCodeUsingEnterKeyForNearbyStoreAndCorrespondingStoresAreDisplayed() {
		SelectstoretoviewadsTestPage makethismystore = new SelectstoretoviewadsTestPage();
		StoreLocatorTestPage storeloc = new StoreLocatorTestPage();

		makethismystore.getTxtChangeZipcode().click();
		makethismystore.getEdtZipcode().clear();
		makethismystore.getEdtZipcode()
				.sendKeys(ConfigurationManager.getBundle().getString("weeklyads.zipcode.changezipcode"));
		
		// Clicking enter key
		PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.ENTER);

		String storenameselectedWeeklyAds = makethismystore.getLblStoreName().getText();
		String firstWeeklyAdStore = makethismystore.getNearbyStoresName(1).getText();
		
		if (storenameselectedWeeklyAds.equals(firstWeeklyAdStore))
			PerfectoUtils.reportMessage("WeeklyAds store selected is getting displayed in the first nearby stores list successfully",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("WeeklyAds store selected is not displayed in the first nearby stores list",
					MessageTypes.Fail);

		List<String> weeklyAdStoreNames = new ArrayList<>();
		List<String> storeresultsStoreNames = new ArrayList<>();

		for (int count = 1; count < 10; count++) {
			weeklyAdStoreNames.add(makethismystore.getNearbyStoresName(count).getText().trim());
			System.out.println(weeklyAdStoreNames);
		}
		storeloc.getLnkFindStore().click();
		storeloc.getTbxEnterStore().click();
		storeloc.getTbxEnterStore().clear();
		storeloc.getTbxEnterStore()
				.sendKeys(ConfigurationManager.getBundle().getString("weeklyads.zipcode.changezipcode"));
		storeloc.getBtnSearch().click();
		storeloc.waitForAjaxToComplete();
		storeloc.getBtnLoadMoreStores().click();
		storeloc.waitForAjaxToComplete();
		
		storeloc.getTxtStorersName().get(0).waitForPresent(5000);
		for (int i = 0; i < 9; i++) {
			storeresultsStoreNames.add(storeloc.getTxtStorersName().get(i).getText().trim());
		}
		System.out.println(storeresultsStoreNames);

		for (int i = 0; i < 9; i++) {
			if (weeklyAdStoreNames.get(i).equalsIgnoreCase(storeresultsStoreNames.get(i))) {
				PerfectoUtils.reportMessage(storeresultsStoreNames.get(i) + " corresponding stores are displayed", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage(storeresultsStoreNames.get(i) + " corresponding store " + weeklyAdStoreNames.get(i)+ " is not displayed", MessageTypes.Fail);
			}
		}

	}

	@QAFTestStep(description = "Validate user able to see List of stores in scroll list")
	public void validateUserabletoseeListofstoresinscrolllist() {
		SelectstoretoviewadsTestPage makethismystore = new SelectstoretoviewadsTestPage();

		int numofStoresListed = makethismystore.getLstNearbystorescount().size();
		String expectedNumofListedStore = ConfigurationManager.getBundle().getString("weeklyads.listofstores");
		String expectedNumofStoreListatTime = ConfigurationManager.getBundle().getString("weeklyads.listofstores");

		if (Integer.toString(numofStoresListed).equals(expectedNumofListedStore))
			PerfectoUtils.reportMessage(numofStoresListed + " stores are displayed as expected", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage(numofStoresListed + " stores are displayed but it does not meet the expected list "
					+ expectedNumofListedStore, MessageTypes.Fail);

		if (makethismystore.getNearbyStoresName(Integer.parseInt(expectedNumofStoreListatTime)).isDisplayed())
			PerfectoUtils.reportMessage(expectedNumofStoreListatTime + " stores are displayed at a time as expected",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage(expectedNumofStoreListatTime + " stores are not displayed at a time as expected",
					MessageTypes.Fail);
	}

	@QAFTestStep(description = "Validate user able to see list the Store name and address in the scroll list")
	public void validateUserabletoseeListStorenameandaddressinscrolllist() {
		SelectstoretoviewadsTestPage makethismystore = new SelectstoretoviewadsTestPage();

		List<String> weeklyAdStoreNames = new ArrayList<>();
		List<String> weeklyAdStoreAddress = new ArrayList<>();

		for (int i = 1; i <= 9; i++) {
			if (!(makethismystore.getNearbyStoresName(i).getText().isEmpty())) {
				weeklyAdStoreNames.add(makethismystore.getNearbyStoresName(i).getText());
				PerfectoUtils.reportMessage(
						makethismystore.getNearbyStoresName(i).getText() + " store name is displayed",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Store names are not displayed at " + i + " th position in the list", MessageTypes.Fail);
			}
		}

		for (int j = 1; j <= 9; j++) {
			if (!(makethismystore.getNearbyStoresAddress(Integer.toString(j)).getText().isEmpty())) {
				weeklyAdStoreAddress.add(makethismystore.getNearbyStoresAddress(Integer.toString(j)).getText());
				PerfectoUtils.reportMessage(makethismystore.getNearbyStoresAddress(Integer.toString(j)).getText()
						+ " store address is displayed", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Store address are not displayed at " + j + " th position in the list", MessageTypes.Fail);
			}
		}

	}

	@QAFTestStep(description = "Validate user able to navigate back and forth on nearby store locator tool")
	public void validateUserabletonavigatebackandforthonnearbystorelocatortool() {
		SelectstoretoviewadsTestPage makethismystore = new SelectstoretoviewadsTestPage();

		makethismystore.waitForPageToLoad();
		makethismystore.waitForAjaxToComplete();

		makethismystore.getLnkLeftscroll().verifyNotVisible();
		makethismystore.getLnkRightscroll().verifyVisible();

		for (int i = 1; i <= 3; i++) {
			if (makethismystore.getNearbyStoresName(i).isDisplayed()) {
				PerfectoUtils.reportMessage(
						makethismystore.getNearbyStoresName(i).getText() + " store name is displayed",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Store names are not displayed at " + i + " th position in the list", MessageTypes.Fail);
			}
		}

		makethismystore.getLnkRightscroll().click();
		makethismystore.getLnkLeftscroll().waitForVisible(5000);
		makethismystore.getLnkLeftscroll().verifyVisible();
//		makethismystore.getNearbyStoresName("1").verifyNotVisible();

		for (int i = 2; i <= 4; i++) {
			if (makethismystore.getNearbyStoresName(i).isDisplayed()) {
				PerfectoUtils.reportMessage(
						makethismystore.getNearbyStoresName(i).getText() + " store name is displayed",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Store names are not displayed at " + i + " th position in the list", MessageTypes.Fail);
			}
		}

		// Click five times right scroll to view last nearby store name in the
		// list
		while (makethismystore.getLnkRightscroll().isDisplayed()) {

			makethismystore.getLnkRightscroll().click();
			PerfectoUtils.reportMessage("Right scroll is clicked..", MessageTypes.Info);
		}

		if (makethismystore.getLnkLeftscroll().verifyVisible())
			PerfectoUtils.reportMessage("Left Scroll is displayed on viewing last item", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Left Scroll is not displayed on viewing last item", MessageTypes.Fail);

		if (makethismystore.getLnkRightscroll().verifyNotVisible())
			PerfectoUtils.reportMessage("Right Scroll is not displayed on viewing last item", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Right Scroll is displayed on viewing last item", MessageTypes.Fail);

		// Click five times right scroll to view last nearby store name in the
		// list
		while (makethismystore.getLnkLeftscroll().isDisplayed()) {

			makethismystore.getLnkLeftscroll().click();
			PerfectoUtils.reportMessage("Left scroll is clicked..", MessageTypes.Info);
		}

		if (makethismystore.getLnkLeftscroll().verifyNotVisible())
			PerfectoUtils.reportMessage("Left Scroll is not displayed while viewing first store in the list", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Left Scroll is displayed while viewing first store in the list", MessageTypes.Fail);

		if (makethismystore.getLnkRightscroll().verifyVisible())
			PerfectoUtils.reportMessage("Right Scroll is displayed while viewing first store in the list", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Right Scroll is not displayed while viewing first store in the list", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Validate user with store selecting another store to view ads already choosen store should not changed")
	public void validateUserwithStoreSelectingStoretoViewAdsalreadychoosenstorenotchanged() {
		SelectstoretoviewadsTestPage makethismystore = new SelectstoretoviewadsTestPage();
		StoreLocatorTestPage storeloc = new StoreLocatorTestPage();

		String storeNameAlreadyChoosed = storeloc.getLblStoreHeaderTxt().getText();
		// selecting another store to view ads
		makethismystore.getNearbyStoresName(2).click();

		if (!(makethismystore.getNearbyStoresName(2).getText().equals(storeNameAlreadyChoosed)))
			PerfectoUtils.reportMessage("User with store selecting another store to view ads already choosen store not gets changed",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("User with store selecting another store to view ads already choosen store got changed",
					MessageTypes.Fail);

	}

	@QAFTestStep(description = "Validate error message under weeklyAds for stores with No weeklyAds")
	public void validateerrormessageunderweeklyAdsforstoreswithNoweeklyAds() {
		SelectstoretoviewadsTestPage makethismystore = new SelectstoretoviewadsTestPage();

		String storeNamewithNoWeeklyAd = ConfigurationManager.getBundle().getString("weeklyads.noWeeklyAdstore");
		int flag = 0;

		for (int storelistcount = 1; storelistcount <= 9; storelistcount++) {
			if (makethismystore.getNearbyStoresName(storelistcount).getText()
					.equals(storeNamewithNoWeeklyAd)) {
				makethismystore.getNearbyStoresName(storelistcount).click();
				PerfectoUtils.reportMessage(storeNamewithNoWeeklyAd + " Storename with no weeklyAds is clicked", MessageTypes.Pass);
				flag = 1;
				break;
			}
		}

		if (flag == 0) {
			PerfectoUtils.reportMessage(
					storeNamewithNoWeeklyAd
							+ " Storename with no weeklyAds is not available in the list and hence not clicked",
					MessageTypes.Fail);
		}

		String errormsgNoWeeklyAds = makethismystore.getLblNoWeeklyAdMsg().getText();
		String expectedErrormsgNoWeeklyAds = ConfigurationManager.getBundle().getString("weeklyads.TBDerrormsg");

		if (PerfectoUtils.removeSpecialCharacters(errormsgNoWeeklyAds).toLowerCase().contains(PerfectoUtils.removeSpecialCharacters(expectedErrormsgNoWeeklyAds).toLowerCase()))
			PerfectoUtils.reportMessage(
					errormsgNoWeeklyAds + " Error message under weeklyAds for stores with No weeklyAds is displayed",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Expected Error message '" + expectedErrormsgNoWeeklyAds
					+ "' under weeklyAds for stores with No weeklyAds is not displayed. Actual error message displayed is '"
					+ errormsgNoWeeklyAds + "'", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Adding weekly ad to list from Print View model")
	public void addingWeeklyAdToListFromPrintViewModel() {
		Weeklyadsdealsmodel model = new Weeklyadsdealsmodel();

		model.getWeeklyadmodelPrintLblHeader().verifyPresent();
		model.getWeeklyadmodelPrintBtnAddtolist().verifyPresent();
		model.getWeeklyadmodelPrintBtnAddtolist().click();
		model.waitForAjaxToComplete();

	}

	@QAFTestStep(description = "Validate default zipcode {0} in weekly ads page for {1} storeId")
	public void validateDefaultZipcodeInWeeklyAdsPageForStoreId(String defaultZipCode, int storeId) {
		SelectstoretoviewadsTestPage weeklyadstore = new SelectstoretoviewadsTestPage();

		weeklyadstore.getLblStoreNameintop().verifyPresent();
		weeklyadstore.getLblStoreName().verifyPresent();
		String storeName = weeklyadstore.getLblStoreName().getText();
		weeklyadstore.getTxtChangeZipcode().verifyPresent();
		String actZipCode = weeklyadstore.getTxtChangeZipcode().getText();

		if (actZipCode.equalsIgnoreCase(defaultZipCode)) {
			PerfectoUtils.reportMessage("Default zipcode is displayed correctly as " + actZipCode + " for StoreId: " + storeId,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Default zipcode is not displayed correctly. Actual zipCode displaying is " + actZipCode
					+ " for StoreId: " + storeId, MessageTypes.Fail);
		}

		PerfectoUtils.reportMessage("Store taken for displaying for weekly ads: " + storeName);

	}

	@QAFTestStep(description = "Verify GRID View is displayed on clicking Weekly Ad links in Mobile size view")
	public void verifyWeeklyAdGridViewPageDisplayedDefault() {
		WeeklyadprintversionTestPage printversion = new WeeklyadprintversionTestPage();

		if (printversion.getBtnCategoryview().verifyPresent())
			PerfectoUtils.reportMessage("GRID View is displayed on clicking Weekly Ad links in Mobile size view", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("GRID View is not displayed on clicking Weekly Ad links in Mobile size view",
					MessageTypes.Fail);
	}
	
	@QAFTestStep(description = "Validate the featured deals drop down is hidden")
	public void validateTheFeaturedDealsDropDownIsHidden() {
		SelectstoretoviewadsTestPage weeklyadstore = new SelectstoretoviewadsTestPage();
		
		weeklyadstore.getLblFeatureddeals().verifyVisible();
		weeklyadstore.getLblFeatureddealsdropdown().verifyPresent();
		weeklyadstore.getLblFeatureddealsdropdown().verifyNotVisible();
	
	}
	
	@QAFTestStep(description = "Validate whether WeeklyAd Header white Spaces are reduced")
	public void validateWeeklyAdHeaderwhiteSpacesarereduced() {
		WeeklyaddealsTestPage weeklyads = new WeeklyaddealsTestPage();
		
		String weeklyAdHeaderName = weeklyads.getLblPageheader().getText();
		int headerLength = weeklyAdHeaderName.length();
		
        if(!(Character.isWhitespace(weeklyAdHeaderName.charAt(0))))
        	PerfectoUtils.reportMessage("No white Spaces prefixed in the string", MessageTypes.Pass);
    	else
    		PerfectoUtils.reportMessage("White Spaces prefixed in the string", MessageTypes.Fail);
        
        if(!(Character.isWhitespace(weeklyAdHeaderName.charAt(headerLength-1))))
        	PerfectoUtils.reportMessage("No white Spaces suffixed in the string", MessageTypes.Pass);
    	else
    		PerfectoUtils.reportMessage("White Spaces suffixed in the string", MessageTypes.Fail);
			
	}

}
