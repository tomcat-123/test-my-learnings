package com.automation.web.pages.products;

import java.util.List;

import com.automation.web.components.CDPProductBlocks;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CDPTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "cdp.li.Eachproductblock")
	private List<CDPProductBlocks> cdpLiProductblock;
	
	@FindBy(locator = "cdp.li.Eachproductblock")
	private CDPProductBlocks cdpLiProductblock1;
	
	@FindBy(locator = "cdp.lnk.productTitle2subscription")
	private CDPProductBlocks cdpLnkProductTitle2Subscription;

	@FindBy(locator = "cdp.img.feature")
	private QAFWebElement cdpImgFeature;

	@FindBy(locator = "cdp.txt.productTitle")
	private QAFWebElement cdpLblProductname;

	@FindBy(locator = "cdp.img.product")
	private QAFWebElement cdpImgProduct;
	
	@FindBy(locator = "cdp.lbl.pagetitle")
	private QAFWebElement cdpLblPagetitle;

	@FindBy(locator = "cdp.lbl.subcategorytitle")
	private QAFWebElement cdpLblSubcategorytitle;

	@FindBy(locator = "cdp.lbl.sortby")
	private QAFWebElement cdpLblSortby;

	@FindBy(locator = "cdp.lbl.sortoptions")
	private QAFWebElement cdpLblSortoptions;
	
	@FindBy(locator = "cdp.lbl.sortoptionslist")
	private List<QAFWebElement> cdpLblSortoptionslist;

	@FindBy(locator = "cdp.img.leftnav")
	private QAFWebElement cdpImgLeftnav;

	@FindBy(locator = "cdp.lbl.refineresults")
	private QAFWebElement cdpLblRefineresults;

	@FindBy(locator = "cdp.lbl.pricerange")
	private QAFWebElement cdpLblPricerange;

	@FindBy(locator = "cdp.img.pricerangeslider")
	private QAFWebElement cdpImgPricerangeslider;
	
	@FindBy(locator = "cdp.lnk.findyourstore")
	private QAFWebElement cdpLnkFindyourstore;
	
	@FindBy(locator = "cdp.lnk.mystorename")
	private QAFWebElement cdpLnkMystorename;

	@FindBy(locator = "cdp.txt.enterzipcodemousehover")
	private QAFWebElement cdpTxtEnterzipcodemousehover;
	
	@FindBy(locator = "cdp.btn.findmousehover")
	private QAFWebElement cdpBtnFindmousehover;
	
	@FindBy(locator = "cdp.txt.enterzipcode")
	private QAFWebElement cdpTxtEnterzipcode;
	
	@FindBy(locator = "cdp.btn.go")
	private QAFWebElement cdpBtnGo;
	
	@FindBy(locator = "cdp.btn.selectstoreslist")
	private List<QAFWebElement> cdpBtnSelectstoreslist;
	
	@FindBy(locator = "cdp.lbl.storesnameslist")
	private List<QAFWebElement> cdpLblStoresnameslist;
	
	@FindBy(locator = "cdp.lbl.filterbyavailability")
	private QAFWebElement cdpLblFilterbyavailability;
	
	@FindBy(locator = "cdp.table.filterbyavailabilitytypes")
	private List<QAFWebElement> cdpLblFilterbyavailabilityTypes;
	
	
	@FindBy(locator = "cdp.lbl.inmystore")
	private QAFWebElement cdpLblInmystore;
	
	@FindBy(locator = "cdp.btn.customize")
	private List<QAFWebElement> cdpBtnCustomize;
	

	@FindBy(locator = "cdp.lbl.orderqtylimiterror")
	private QAFWebElement cdpLblOrderqtylimiterror;
	
	@FindBy(locator = "cdp.lbl.resultfound")
	private QAFWebElement cdpLblResultFound;
	
	@FindBy(locator = "cdp.lbl.soldonline")
	private QAFWebElement cdpLblSoldOnline;
	
	@FindBy(locator = "cdp.btn.addtocartdisabled")
	private QAFWebElement cdpBtnAddtocartDisabled;
	
	@FindBy(locator = "cdp.lis.bycategory")
	private List<QAFWebElement> cdpLisByCategory;
	
	@FindBy(locator = "cdp.li.lnk.cdpsidecategories")
	private List<QAFWebElement> cdpLiLnkCdpsidecategories;
	
	/**
	 * ListView of product block
	 */
	
	public List<CDPProductBlocks> getCdpLiProductblock(){ return cdpLiProductblock; }

	public CDPProductBlocks getProductList() {
		return cdpLiProductblock1; 
	}
	
	
	public CDPProductBlocks getProductTitle2Subscription() {
		return cdpLnkProductTitle2Subscription; 
	}
			
	/**
	 * ImageView of product feature icon
	 */
	
	public QAFWebElement getBtnAddtocartDisabled() {
		return cdpBtnAddtocartDisabled; 
	}
	
	public QAFWebElement getCdpImgFeature(){ return cdpImgFeature; }
	
	public QAFWebElement getCdpLblSoldOnline(){ return cdpLblSoldOnline; }

	/**
	 * TextView of product name
	 */
	public QAFWebElement getCdpLblProductname(){ return cdpLblProductname; }
	
	/**
	 * ImageView of product name
	 */
	public QAFWebElement getCdpImgProduct(){ return cdpImgProduct; }

	/**
	 * TextView of PageTitle
	 */
	public QAFWebElement getCdpLblPagetitle(){ return cdpLblPagetitle; }

	/**
	 * TextView of Subcategory title
	 */
	public QAFWebElement getCdpLblSubcategorytitle(){ return cdpLblSubcategorytitle; }

	/**
	 * TextView of Sort by
	 */
	public QAFWebElement getCdpLblSortby(){ return cdpLblSortby; }

	/**
	 * TextView of sortoptions
	 */
	public QAFWebElement getCdpLblSortoptions(){ return cdpLblSortoptions; }

	/**
	 * ImageView for leftnav bar
	 */
	public QAFWebElement getCdpImgLeftnav(){ return cdpImgLeftnav; }

	/**
	 * TextView of Refine your results
	 */
	public QAFWebElement getCdpLblRefineresults(){ return cdpLblRefineresults; }

	/**
	 * TextView of Price range
	 */
	public QAFWebElement getCdpLblPricerange(){ return cdpLblPricerange; }

	/**
	 * ImageView for Price range slider
	 */
	public QAFWebElement getCdpImgPricerangeslider(){ return cdpImgPricerangeslider; }

	public QAFWebElement getCdpLnkFindyourstore() {
		return cdpLnkFindyourstore;
	}

	public QAFWebElement getCdpLnkMystorename() {
		return cdpLnkMystorename;
	}
	
	public QAFWebElement getCdpTxtEnterzipcodemousehover() {
		return cdpTxtEnterzipcodemousehover;
	}

	public QAFWebElement getCdpBtnFindmousehover() {
		return cdpBtnFindmousehover;
	}
	
	public QAFWebElement getCdpTxtEnterzipcode() {
		return cdpTxtEnterzipcode;
	}

	public QAFWebElement getCdpBtnGo() {
		return cdpBtnGo;
	}

	public List<QAFWebElement> getCdpBtnSelectstoreslist() {
		return cdpBtnSelectstoreslist;
	}

	public List<QAFWebElement> getCdpLblStoresnameslist() {
		return cdpLblStoresnameslist;
	}

	public QAFWebElement getCdpLblFilterbyavailability() {
		return cdpLblFilterbyavailability;
	}

	
	public List<QAFWebElement> getCdpLblFilterbyavailabilityTypes() {
		return cdpLblFilterbyavailabilityTypes;
	}


	public List<QAFWebElement> getCdpBtnCustomize() {
		return cdpBtnCustomize;
	}


	public QAFWebElement getCdpLblInmystore() {
		return cdpLblInmystore;
	}
	
	public List<QAFWebElement> getcdpBtnCustomize() {
		return cdpBtnCustomize;
	}
	public QAFWebElement getCdpLblOrderqtylimiterror() {
		return cdpLblOrderqtylimiterror;
	}
	
	public List<QAFWebElement> getCdpLblSortoptionslist() {
		return cdpLblSortoptionslist;
	}
	
	public QAFWebElement getCdpLblResultFound() {
		return cdpLblResultFound;
	}
	
	public List<QAFWebElement> getCdpLisByCategory() {
		return cdpLisByCategory;
	}
	
	public QAFWebElement getLnkCategories(int i) {
		String category = String.format(pageProps.getString("cdp.lnk.categories"),i);
		return new QAFExtendedWebElement(category);
	}
	
	public List<QAFWebElement> getCdpLiLnkCdpsidecategories() {
		return cdpLiLnkCdpsidecategories;
	}
	
	public QAFWebElement getCdpChkRefineOptionByName(String name){
		String loc = String.format(pageProps.getString("cdp.get.chk.refineoptions"), name);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getCdpLblRefineOptionByName(String name){
		String loc = String.format(pageProps.getString("cdp.get.lbl.refineoptions"), name);
		return new QAFExtendedWebElement(loc);
	}
}