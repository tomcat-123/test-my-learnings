package com.automation.web.steps.search;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static com.automation.web.commonutils.PerfectoUtils.reportMessage;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.components.CDPProductBlocks;
import com.automation.web.pages.cart.CartTestPage;
import com.automation.web.pages.checkout.DeliveryTestPage;
import com.automation.web.pages.checkout.PaymentTestPage;
import com.automation.web.pages.email.EmailTemplateTestPage;
import com.automation.web.pages.homepage.FooterTestPage;
import com.automation.web.pages.homepage.FrontdoorTestPage;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.homepage.STHHomePage;
import com.automation.web.pages.login.LoginTestPage;
import com.automation.web.pages.make_ready.MakeReadyTestPage;
import com.automation.web.pages.myList.MyListTestPage;
import com.automation.web.pages.homepage.FrontdoorTestPage;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.products.CDPTestPage;
import com.automation.web.pages.products.CustomizeTestPage;
import com.automation.web.pages.products.CustomizebakeryTestPage;
import com.automation.web.pages.products.PDPTestPage;
import com.automation.web.pages.products.ShopTestPage;
import com.automation.web.pages.recipes.RecipeBoxTestpage;
import com.automation.web.pages.recipes.RecipedetailTestpage;
import com.automation.web.pages.search.PdtsearchresultTestPage;
import com.automation.web.pages.storelocator.FindAStoreTestPage;
import com.automation.web.pages.storelocator.SelectStoreTestPage;
import com.automation.web.pages.weeklyads.MiniListTestPage;
import com.automation.web.steps.CommonStepDef;
import com.automation.web.steps.Registration.Registration;
import com.automation.web.steps.cartAndCheckout.CartAndCheckout;
import com.automation.web.steps.homepage.HomePage;
import com.automation.web.steps.myaccount.myaccountpage;
import com.automation.web.steps.storelocator.StoreLocatorPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of steps in PdtsearchresultPage

* I Enter valid search term {0} and select Search button
* I see search results page
* I verify Add to cart button is green if in stock
* Navigate to CDP page by navigating {0} items
* Navigate to CDP by navigating {0} {1} items
* Navigate to Ship to Home page
* I am a hot user with {0} {1} credentials in Ship To Home Page
* I should see the search result page
* I verify Add to cart button is gray if out-of-stock
* I verify that add to cart button says 'add x to cart'
* I add item to cart
* I add another item {0} to cart
* I see Red Cart button updated with the new quantity
* I verify mini cart button changed from Start Shopping to View Cart
* I remove all items from cart
* I search {0} in Search Bar of Ship To Home Page
* I see search result page with Sold Online tag
* I see search result page with In My Store tag
* I see search result page with All Stores tag
* Verify the Search results context is in Instore view
* Click on minus button
* I Should See the Quantity of that item in the Cart reduced by one
* I verify blue star rating up to (999) is present
* I verify Maximum one marketing flag will present
* I click add to list button
* I verify the item in mini list
* Click minus button to below minimum-order-quantity
* I see product is removed from the cart entirely
* Remove all items from cart
* Verify the Cart button displays Start Shopping
* I navigate to cart page
* I verify product photo show up to four Product feature icons
* I navigated to product detail page
* I verify rest of them will be on the product detail page
* I verify product photo show up to four Product feature icons in cdp page
* I navigate to PDP by clicking on the product
* I verify the PDP
* I enter quantity more than 99
* I verify the snipes in the PDP
* I verify the minimum order quantity error message
* I verify searched Products {0} available in the list
* I verify the text each for Delivery or Free Store Pickup
* I verify no message box is present in email to a friend page
* I verify Search Products, Recipes and Contents
* I see ahead/Indexed terms of Search text
* I Enter valid search half term {0}
* I verify no search results page
* I click on InMyStore Radio button
* I Verify Error Message during store selection in In MyStore option
* I mouseover on Find your store and click on Find
* I Verify Error Message during store selection in FindaStore page
* I verify left navigation link and filters in Search Results Page
* I verify filters in Search Results Page
* I verify filters in Search Results Page for Hot User {0}
* I verify the marketing Bugs in the PDP
* I submit my review
* Verify the Digital coupons are available in PDP
* Verify No results found message in Search results page
* I validate valid search term is persistented in the search bar {0}
* I validate corrected search term is persistented in the search bar {0} {0}
* I validate invalid search term is persistented in the search bar {0}
* I navigate to Bakery
* I validate rating in CDP PDP page of Products
* I add item to cart from PDP
* Validate search ahead section properties with valid search term {0}
* I add product to cart and validate Select a store overlay is displayed
* I validate whether redirect page url is displayed with search term {0}

*/

public class PdtsearchresultPage {

	@QAFTestStep(description = "I Enter valid search term {0} and select Search button")
	public static void ienterValidSearchTermAndSelectSearchButton(String searchtext) {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();

		frontdoor.waitForPageToLoad();
		PerfectoUtils.scrolltoelement(instorehome.getTxtSearchField());
		instorehome.getTxtSearchField().clear();
		CommonStepDef.entervalueintothetextbox(instorehome.getTxtSearchField(), searchtext);
		frontdoor.getFrontBtnSearch().click();
	}
	
	@QAFTestStep(description = "I click on view all product results")
	public static void iClickViewallproductresults() {
		PdtsearchresultTestPage search = new PdtsearchresultTestPage();
		
		search.getLblViewallproducts().click();
	}
	
	@QAFTestStep(description = "I verify whether pagination is displayed")
	public static void iVerifyPagination() {
		PdtsearchresultTestPage search = new PdtsearchresultTestPage();
		
		PerfectoUtils.scrolltoelement(search.getLblShowing());
		String initialShowing = search.getLblShowing().getText();
		if(initialShowing.contains("Showing 1 - 32 of")){
			PerfectoUtils.reportMessage("32 products are listed in first page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("32 products are not listed in first page", MessageTypes.Fail);
		}
		if(Integer.parseInt(search.getLblLastpage().getText()) > 0){
			PerfectoUtils.reportMessage(search.getLblLastpage().getText()+" is the last page link displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Last page link is not displayed", MessageTypes.Fail);
		}
		
		search.getLnkPages("1").verifyPresent();
		search.getLnkPages("2").click();
		PerfectoUtils.scrolltoelement(search.getLblShowing());
		search.getLnkPrevpage().verifyPresent();
		search.getLnkNextpage().verifyPresent();
	}
	
	@QAFTestStep(description = "I verify HTTPS protocol")
	public static void iVerifyHTTPSProtocol() {
		String url = PerfectoUtils.getDriver().getCurrentUrl();
		if(url.contains("https")){
			PerfectoUtils.reportMessage("HTTPS protocol is present in the url", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("HTTPS protocol is not present in the url", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I order {0} with Sold Online tag and checkout as hot user")
	public void iOrderWithSoldOnlineTagandCheckoutasHotUser(String searchtext) throws Exception {
		CartAndCheckout checkout = new CartAndCheckout();

		ienterValidSearchTermAndSelectSearchButton(searchtext);
		iSeeSearchResultsPage();
		iSeeSearchResultPageWithSoldOnlineTag();
		iAddItemToCart();
		iNavigateToCartPage();
		checkout.iCheckOutTheProduct();
		checkout.iCheckoutTheItemsAsAHotUser();
		checkout.iMakeThePaymentsWithGiftCardandCreditCard();
		checkout.iVerifyTheOrderConfirmationPage();
	}

	@QAFTestStep(description = "I order {0} with Sold Online tag and checkout as hot user with payments GC and CC")
	public void iOrderWithSoldOnlineTagandCheckoutasHotUserpaymentsGCandCC(String searchtext) throws Exception {
		CartAndCheckout checkout = new CartAndCheckout();

		ienterValidSearchTermAndSelectSearchButton(searchtext);
		iSeeSearchResultsPage();
		iSeeSearchResultPageWithSoldOnlineTag();
		iAddItemToCart();
		iNavigateToCartPage();
		checkout.iCheckOutTheProduct();
		checkout.iCheckoutTheItemsAsAHotUser();
		checkout.iMakeThePaymentsWithCreditCard();
		checkout.iVerifyTheOrderConfirmationPage();
	}

	@QAFTestStep(description = "I see search results page")
	public static void iSeeSearchResultsPage() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		pdtsearchresult.getLblSearchresult().waitForPresent(50000);
		if (pdtsearchresult.getLblSearchresult().isPresent()) {
			PerfectoUtils.reportMessage("Search Result page is visible", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Search Result page is not visible", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify Add to cart button is green if in stock")
	public void iVerifyAddToCartButtonIsGreenIfInStock() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		PerfectoUtils.scrolltoelement(pdtsearchresult.getBtnAddToCart().get(0));
		String color = pdtsearchresult.getBtnAddToCart().get(0).getCssValue("background-color");
		PerfectoUtils.reportMessage(color);
		String rgbaColourCode = getBundle().getString("products.rgbaColourCode.green");

		if (color.equalsIgnoreCase(rgbaColourCode)) {
			PerfectoUtils.reportMessage("Add to Cart button is in green color", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Add to Cart button is not in green color", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Navigate to CDP page by navigating {0} items")
	public void navigateToCDPPageByNavigatingItems(List<String> subCat) {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		ShopTestPage shoptestpage = new ShopTestPage();

		PerfectoUtils.mouseoverandclick(instorehome.getHomeImgCart(), instorehome.getHomeBtnCartstartshopping());
		pdtsearchresult.getTxtShop().waitForPresent(3000);
		PerfectoUtils.reportMessage("user is in shop page", MessageTypes.Pass);
		pdtsearchresult.getTxtFirstProduct().verifyPresent();
		pdtsearchresult.getTxtFirstProduct().click();

		for (String tempCat : subCat) {
			QAFWebElement eleSubCategory = shoptestpage.getGetCdpcategories(tempCat);
			eleSubCategory.click();
		}

	}

	@QAFTestStep(description = "Navigate to CDP by navigating {0} {1} items")
	public void navigateToCDPByNavigatingItems(String mainCategory, List<String> subCategories) {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		ShopTestPage shoptestpage = new ShopTestPage();

		// PerfectoUtils.scrolltoelement(instorehome.getHomeImgCart());
		PerfectoUtils.mouseover(instorehome.getHomeImgCart());
		try {
			if (instorehome.getHomeBtnCartstartshopping().isPresent()) {
				instorehome.getHomeBtnCartstartshopping().click();
			} else {
				PerfectoUtils.mouseover(instorehome.getHomeImgCart());
				for (QAFWebElement temp : instorehome.getHomeBtnCartitem()) {
					if ((!temp.getText().contains("Gift Card")) || (!temp.getText().contains("Test Donation"))) {
						temp.click();
						QAFWebElement eleBreadCrumbShop = instorehome.getHomeBtnBreadcrumbshop();
						eleBreadCrumbShop.waitForPresent(3000);
						eleBreadCrumbShop.click();
						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// PerfectoUtils.mouseoverandclick(instorehome.getHomeImgCart(),instorehome.getHomeBtnCartstartshopping());
		pdtsearchresult.getTxtShop().waitForPresent(3000);
		PerfectoUtils.reportMessage("user is in shop page", MessageTypes.Pass);
		PerfectoUtils.scrolltoelement(shoptestpage.getMainCategory(mainCategory));
		shoptestpage.getMainCategory(mainCategory).waitForPresent(1000);
		shoptestpage.getMainCategory(mainCategory).click();
		PerfectoUtils.reportMessage("Clicked on " + mainCategory);

		for (String temp : subCategories) {
			QAFWebElement eleSubCategory = shoptestpage.getGetCdpcategories(temp);
			eleSubCategory.click();
		}

	}
	
	@QAFTestStep(description = "Navigate to CDP by navigating {0} {1} item")
	public void navigateToCDPByNavigatingItem(String mainCategory, String subCategories) {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		ShopTestPage shoptestpage = new ShopTestPage();

		// PerfectoUtils.scrolltoelement(instorehome.getHomeImgCart());
		PerfectoUtils.mouseover(instorehome.getHomeImgCart());
		try {
			if (instorehome.getHomeBtnCartstartshopping().isPresent()) {
				instorehome.getHomeBtnCartstartshopping().click();
			} else {
				PerfectoUtils.mouseover(instorehome.getHomeImgCart());
				for (QAFWebElement temp : instorehome.getHomeBtnCartitem()) {
					if ((!temp.getText().contains("Gift Card")) || (!temp.getText().contains("Test Donation"))) {
						temp.click();
						QAFWebElement eleBreadCrumbShop = instorehome.getHomeBtnBreadcrumbshop();
						eleBreadCrumbShop.waitForPresent(3000);
						eleBreadCrumbShop.click();
						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// PerfectoUtils.mouseoverandclick(instorehome.getHomeImgCart(),instorehome.getHomeBtnCartstartshopping());
		pdtsearchresult.getTxtShop().waitForPresent(3000);
		PerfectoUtils.reportMessage("user is in shop page", MessageTypes.Pass);
		PerfectoUtils.scrolltoelement(shoptestpage.getMainCategory(mainCategory));
		shoptestpage.getMainCategory(mainCategory).waitForPresent(1000);
		shoptestpage.getMainCategory(mainCategory).click();
		PerfectoUtils.reportMessage("Clicked on " + mainCategory);

			QAFWebElement eleSubCategory = shoptestpage.getGetCdpcategories(subCategories);
			eleSubCategory.click();

	}

	@QAFTestStep(description = "Navigate to Ship to Home page")
	public void navigateToShipToHomePage() {
		FooterTestPage footer = new FooterTestPage();
		STHHomePage sthhome = new STHHomePage();
		FrontdoorTestPage front = new FrontdoorTestPage();

		PerfectoUtils.scrolltoelement(footer.getFooterLnkShiptohome());
		footer.getFooterLnkShiptohome().waitForPresent(3000);

		try {
			footer.getFooterLnkShiptohome().verifyPresent();
			footer.getFooterLnkShiptohome().click();
			sthhome.waitForPageToLoad();
			sthhome.waitForAjaxToComplete();
			sthhome.getSthhomeLblYourfirstorder().waitForPresent(2000);
			front.getFrontImgFav().verifyPresent();
			if (sthhome.getSthhomeLblYourfirstorder().isPresent()) {
				PerfectoUtils.reportMessage("Navigated to Ship to Home page", MessageTypes.Pass);
			}
		} catch (Exception e) {
			PerfectoUtils.reportMessage("user still is in home page", MessageTypes.Fail);
		}

	}
	
	@QAFTestStep(description = "I verify the functionality of Home Page Header links")
	public void functionalityOfHomePageHeaderLinks() {
		STHHomePage sth = new STHHomePage();
		
		sth.getSthhomeLnkDeals().verifyPresent();
		sth.getSthhomeLnkHelp().verifyPresent();
		sth.getSthhomeLnkDeals().click();
		sth.getSthhomeLblOnlineDeals().verifyPresent();
		PerfectoUtils.getDriver().navigate().back();
		sth.getSthhomeLnkHelp().click();
		sth.getSthhomeLblHelpHeader().verifyPresent();
	}
	
	/**
	 * Verify the user login functionality
	 */
	@QAFTestStep(description = "I am a hot user with {0} {1} credentials in Ship To Home Page")
	public void iAmAHotUserWithCredentials_ShipToHomePage(String str0, String str1) {
		myaccountpage myAcc = new myaccountpage();
		myAcc.iClickonLoginlink();
		myAcc.iEnteremailandpassword(str0, str1);
		myAcc.iClickonLoginbutton();
		myAcc.iSeetheuserisloggedin();

	}

	@QAFTestStep(description = "I should see the search result page")
	public void iShouldSeeTheSearchResultPage() {
		PdtsearchresultTestPage pdtSearchresult = new PdtsearchresultTestPage();
		String title;

		pdtSearchresult.waitForPageToLoad();
		title = pdtSearchresult.getLblPageheader().getText();
		if (title.contains("Filter Products by Availability")) {
			PerfectoUtils.reportMessage("search result page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("search result page is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify Add to cart button is gray if out-of-stock")
	public void iVerifyAddToCartButtonIsGrayIfOutOfStock() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		int AddtocartSize = pdtsearchresult.getBtnAddToCart().size();

		if (AddtocartSize > 0) {

			PerfectoUtils.scrolltoelement(pdtsearchresult.getBtnAddToCart().get(0));
			String color = pdtsearchresult.getBtnAddToCart().get(0).getCssValue("background-color");
			String rgbaColourCode = getBundle().getString("products.rgbaColourCode.grey");

			if (color.equalsIgnoreCase(rgbaColourCode)) {
				PerfectoUtils.reportMessage("Add to Cart button is in gray color", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Add to Cart button is not in gray color", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("Add to Cart button not found.", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I verify that add to cart button says 'add x to cart'")
	public void iVerifyThatAddToCartButtonSaysAddXToCart() {
		CDPTestPage cdp = new CDPTestPage();
		boolean isMOQPrdtFound = false;

		for (CDPProductBlocks cdpproducts : cdp.getCdpLiProductblock()) {

			if (cdpproducts.getCdpBtnAddtoCart().isPresent()) {

				PerfectoUtils.scrolltoelement(cdpproducts.getCdpBtnAddtoCart());
				cdpproducts.getCdpBtnAddtoCart().waitForPresent(2000);
				String actualText = cdpproducts.getCdpBtnAddtoCart().getText();
				boolean expectedText = false;
				String expected = null;
				PerfectoUtils.scrolltoelement(cdpproducts.getCdpBtnAddtoCart());
				cdpproducts.getCdpBtnAddtoCart().waitForPresent(2000);

				if (cdpproducts.getCdpLblMinimumquantity().isPresent()) {
					if (cdpproducts.getCdpLblMinimumquantity().getText().trim().equalsIgnoreCase("")) {
						expectedText = true;
						isMOQPrdtFound = false;

					} else {
						isMOQPrdtFound = true;
						int minQty = Integer
								.parseInt(cdpproducts.getCdpLblMinimumquantity().getText().substring(18, 20).trim());
						if (minQty > 1) {
							expected = "ADD " + minQty + " TO CART";
						} else {
							expectedText = false;
							PerfectoUtils.reportMessage("Quantity is less than one", MessageTypes.Fail);
						}
					}

				} else {
					isMOQPrdtFound = false;
				}

				if (!isMOQPrdtFound) {
					continue;
				} else {
					PerfectoUtils.reportMessage("MOQ product Found!");
				}

				if (actualText.equalsIgnoreCase(expected)) {
					PerfectoUtils.reportMessage("Add to Cart Text is present as " + actualText, MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Add to Cart Text is not present as " + actualText, MessageTypes.Fail);
				}
				break;

			} else {
				PerfectoUtils.reportMessage("Add to cart button not found.", MessageTypes.Info);
			}

		}

		if (!isMOQPrdtFound)
			PerfectoUtils.reportMessage("MOQ product not found!", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I add item to cart")
	public static void iAddItemToCart() throws Exception {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		CDPTestPage cdp = new CDPTestPage();
		boolean isCartButtonFound = true;
		int qty = 0;

		for (CDPProductBlocks cdpproducts : cdp.getCdpLiProductblock()) {

			pdtsearchresult.waitForPageToLoad();
			pdtsearchresult.waitForAjaxToComplete();

			if (cdpproducts.getCdpBtnAddtoCart().isPresent()) {

				String addingItemName = cdpproducts.getCdpTxtProductname().getText();
				getBundle().setProperty("addingItemName", addingItemName);

				PerfectoUtils.scrolltoelement(cdpproducts.getCdpBtnAddtoCart());

				cdpproducts.getCdpBtnAddtoCart().waitForPresent(2000);
				cdpproducts.getCdpBtnAddtoCart().verifyPresent();

				String cartQty = pdtsearchresult.getTxtCartQuantity().getText();
				if (!cartQty.equals(""))
					qty = Integer.parseInt(cartQty);
				getBundle().setProperty("cartQuantity", qty);
				getBundle().setProperty("cartTotalPrice", pdtsearchresult.getTxtCartPrice().getText());

				cdpproducts.getCdpBtnAddtoCart().click();

				pdtsearchresult.waitForPageToLoad();
				pdtsearchresult.waitForAjaxToComplete();
				cdpproducts.getCdpBtnMinusaddtocart().waitForPresent(5000);

				pdtsearchresult.getTxtCartQuantity().waitForPresent(10000);
				PerfectoUtils.scrolltoelement(pdtsearchresult.getTxtCartQuantity());
				pdtsearchresult.waitForAjaxToComplete();
				int quantity = Integer.parseInt(pdtsearchresult.getTxtCartQuantity().getText());
				getBundle().setProperty("QuantityBeforeMinus", quantity);

				if (cdpproducts.getCdpLblMinimumquantity().isPresent()) {
					if (cdpproducts.getCdpLblMinimumquantity().getText().trim().equalsIgnoreCase("")
							|| cdpproducts.getCdpLblMinimumquantity().getText().trim().equalsIgnoreCase(null)) {
						getBundle().setProperty("MinQuantity", 1);
					} else {
						int minQty = Integer
								.parseInt(cdpproducts.getCdpLblMinimumquantity().getText().substring(18, 20).trim());
						getBundle().setProperty("MinQuantity", minQty);
					}

				} else {
					getBundle().setProperty("MinQuantity", 1);
				}
				isCartButtonFound = true;
				break;
			} else {
				isCartButtonFound = false;
			}
		}

		if (!isCartButtonFound)
			PerfectoUtils.reportMessage("Add to cart not found.", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I add another item {0} to cart")
	public static void iAddAnotherItemToCart(String searchtext) throws Exception {
		ienterValidSearchTermAndSelectSearchButton(searchtext);
		iSeeSearchResultsPage();
		iAddItemToCart();
	}

	@QAFTestStep(description = "I see Red Cart button updated with the new quantity")
	public void iSeeRedCartButtonUpdatedWithTheNewQuantity() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		String price = pdtsearchresult.getTxtCartPrice().getText();
		String quantity = pdtsearchresult.getTxtCartQuantity().getText();

		PerfectoUtils.reportMessage("The new price and quantity is: " + price + "" + quantity, MessageTypes.Info);
		System.out.println("Price " + price + " Quantity " + quantity);
	}

	@QAFTestStep(description = "I verify mini cart button changed from Start Shopping to View Cart")
	public void iVerifyMiniCartButtonChangedFromStartShoppingToViewCart() {
		InStoreHomePage instorehome = new InStoreHomePage();
		// WebDriver driver = new ChromeDriver();
		//
		// Actions act = new Actions(driver);
		// act.moveToElement(instorehome.getHomeImgCart()).moveToElement(instorehome.getHomeBtnCartstartshopping()).build()
		// .perform();
		// String text =
		// instorehome.getHomeBtnCartstartshopping().getAttribute("title");

		PerfectoUtils.mousehover(instorehome.getHomeImgCart());
		instorehome.getHomeBtnCartviewcart().waitForPresent(50000);
		String viewCart = instorehome.getHomeBtnCartviewcart().getText();

		if (viewCart.equalsIgnoreCase("View Cart")) {
			PerfectoUtils.reportMessage("cart button changed from Start Shopping to View Cart", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("cart button not changed from Start Shopping to View Cart", MessageTypes.Pass);
		}

	}

	@QAFTestStep(description = "I remove all items from cart")
	public void iRemoveAllItemsFromCart() {
		InStoreHomePage instorehome = new InStoreHomePage();

		instorehome.getHomeImgCart().click();

	}

	/**
	 * Validate Front door page is displayed
	 */
	@QAFTestStep(description = "I search {0} in Search Bar of Ship To Home Page")
	public void iSearchInSearchBarOfShipToHomePage(String STHProduct) {
		STHHomePage sthhome = new STHHomePage();

		sthhome.getSthhomeEdtSearchbar().waitForPresent(3000);
		sthhome.getSthhomeEdtSearchbar().click();
		sthhome.getSthhomeEdtSearchbar().sendKeys(STHProduct);
		sthhome.getSthhomeBtnSearch().click();
	}

	/**
	 * Validate Search result page with Sold Online tag
	 */
	@QAFTestStep(description = "I see search result page with Sold Online tag")
	public void iSeeSearchResultPageWithSoldOnlineTag() {
		CDPTestPage cdpPage = new CDPTestPage();

		cdpPage.getCdpLblFilterbyavailabilityTypes().get(2).waitForPresent(50000);
		PerfectoUtils.scrolltoelement(cdpPage.getCdpLblFilterbyavailabilityTypes().get(2));
		PerfectoUtils.ClickContainsTEXTas(cdpPage.getCdpLblFilterbyavailabilityTypes(), "Sold Online");
	}

	@QAFTestStep(description = "I see search result page with In My Store tag")
	public void iSeeSearchResultPageWithInMyStoreTag() {
		CDPTestPage cdpPage = new CDPTestPage();

		PerfectoUtils.ClickContainsTEXTas(cdpPage.getCdpLblFilterbyavailabilityTypes(), "In My Store");
	}

	@QAFTestStep(description = "I see search result page with All Stores tag")
	public void iSeeSearchResultPageWithAllStoresTag() {
		CDPTestPage cdpPage = new CDPTestPage();

		PerfectoUtils.ClickContainsTEXTas(cdpPage.getCdpLblFilterbyavailabilityTypes(), "All Stores");
	}

	@QAFTestStep(description = "Verify the Search results context is in Instore view")
	public void verifyTheSearchResultsContextIsInInstoreView() {
		InStoreHomePage instore = new InStoreHomePage();

		instore.getHomeLblHeaderweeklyad().verifyPresent();
		instore.getHomeLblHeaderrecipe().verifyPresent();
		instore.getHomeLblHeaderpharmacy().verifyPresent();
	}

	@QAFTestStep(description = "Click on minus button")
	public void clickOnMinusButton() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		int qty = Integer.parseInt(pdtsearchresult.getTxtCartQuantity().getText());
		getBundle().setProperty("cartQuantity", qty);
		getBundle().setProperty("cartTotalPrice", pdtsearchresult.getTxtCartPrice().getText());

		int minusSize = pdtsearchresult.getBtnMinusaddtocart().size();

		if (minusSize > 0) {
			if (pdtsearchresult.getBtnMinusaddtocart().get(0).isPresent()) {
				pdtsearchresult.getBtnMinusaddtocart().get(0).verifyPresent();
				pdtsearchresult.getBtnMinusaddtocart().get(0).click();
			} else {
				PerfectoUtils.reportMessage("Minus Image in Add to Cart button not found.", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("Minus Icon not found.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I Should See the Quantity of that item in the Cart reduced by one")
	public void iShouldSeeTheQuantityOfThatItemInTheCartReducedByOne() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		int minQty = getBundle().getInt("MinQuantity");
		int quantitybeforeMinus = getBundle().getInt("QuantityBeforeMinus");

		int expectedQty = quantitybeforeMinus - minQty;
		PerfectoUtils.scrolltoelement(pdtsearchresult.getTxtCartQuantity());
		pdtsearchresult.getTxtCartQuantity().waitForText(Integer.toString(expectedQty), 50000);
		int quantityAfterMinus = Integer.parseInt(pdtsearchresult.getTxtCartQuantity().getText());

		if (quantityAfterMinus < quantitybeforeMinus) {
			PerfectoUtils.reportMessage("Quantity of that item in the Cart reduced by one.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Quantity of that item in the Cart not reduced by one.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify blue star rating up to (999) is present")
	public void iVerifyBlueStarRatingUpTo999IsPresent() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		PerfectoUtils.scrolltoelement(pdtsearchresult.getLblRatings());
		pdtsearchresult.getLblRatings().waitForPresent(3000);
		int ratings = Integer.parseInt(pdtsearchresult.getLblRatings().getText().replace("(", "").replace(")", ""));

		if (ratings <= 999) {
			PerfectoUtils.reportMessage("Ratings is upto 999.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Ratings is more than 999.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify Maximum one marketing flag will present")
	public void iVerifyMaximumOneMarketingFlagWillPresent() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		try {
			if (pdtsearchresult.getImgPrimoPick().isPresent()) {
				PerfectoUtils.reportMessage("One PrimoPick is present", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("No PrimoPock is present", MessageTypes.Info);
			}
		} catch (Exception e) {
			PerfectoUtils.scrolltoelement(pdtsearchresult.getImgPrimoPick());
			if (pdtsearchresult.getImgPrimoPick().isPresent()) {
				PerfectoUtils.reportMessage("One PrimoPick is present", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("No PrimoPock is present", MessageTypes.Info);
			}
		}
	}

	@QAFTestStep(description = "I click add to list button")
	public void IClickAddToListButton() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		MiniListTestPage minilist = new MiniListTestPage();

		PerfectoUtils.scrolltoelement(pdtsearchresult.getLnkAddtoList());
		pdtsearchresult.getLnkAddtoList().waitForPresent(3000);
		String productName = pdtsearchresult.getLblProductname().getText();
		ConfigurationManager.getBundle().setProperty("ProductName", productName);
		System.out.println(productName);

		pdtsearchresult.getLnkAddtoList().click();
		minilist.waitForAjaxToComplete();
		minilist.getLblPagetitle().waitForPresent(40000);

		if (minilist.getLiItemsegments().get(0).isDisplayed()) {
			PerfectoUtils.reportMessage("Product add to list is successful", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Product add to list is not successful", MessageTypes.Fail);
		}
		minilist.getLblGotofulllist().click();
	}

	@QAFTestStep(description = "I click add to list button from PDP")
	public void IClickAddToListButtonfromPDP() {
		PDPTestPage pdp = new PDPTestPage();
		MiniListTestPage minilist = new MiniListTestPage();

		PerfectoUtils.scrolltoelement(pdp.getLbladdtolist());
		pdp.getLbladdtolist().waitForPresent(3000);
		String productName = pdp.getPdpLblProductname().getText();
		ConfigurationManager.getBundle().setProperty("ProductName", productName);
		System.out.println(productName);

		pdp.getLbladdtolist().click();
		PerfectoUtils.mouseover(pdp.getLbladdtolist());
		pdp.getPdpLnkMyList().click();
		minilist.waitForAjaxToComplete();
	}

	@QAFTestStep(description = "I verify the item in mini list")
	public void iVerifyTheItemInMiniList() {
		MyListTestPage mylist = new MyListTestPage();

		boolean isItemPresent = false;
		String productName = null;
		int itemCnt = 0;

		mylist.waitForPageToLoad();
		mylist.waitForAjaxToComplete();

		mylist.getMylistLblMylist().verifyPresent();
		if (mylist.getMylistLblMinilist().isPresent())
			PerfectoUtils.reportMessage("Mini Shopping list is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Mini Shopping list is not displayed", MessageTypes.Fail);

		productName = ConfigurationManager.getBundle().getString("ProductName");
		if (productName.contains(","))
			productName = productName.substring(0, productName.indexOf(","));

		productName = PerfectoUtils.removeSpecialCharacters(productName);

		itemCnt = mylist.getMylistLiLblMinilistitemnamedynamic().size();

		for (int i = 0; i < itemCnt; i++) {
			String temp = mylist.getMylistLiLblMinilistitemnamedynamic().get(i).getText();
			temp = PerfectoUtils.removeSpecialCharacters(temp);

			if (temp.contains(productName)) {
				isItemPresent = true;
				break;
			} else
				isItemPresent = false;
		}

		if (isItemPresent) {
			PerfectoUtils.reportMessage("Item name matches in mini shopping list", MessageTypes.Pass);
		} else
			PerfectoUtils.reportMessage("Item name not matches in mini shopping list", MessageTypes.Fail);
	}

	@QAFTestStep(description = "Click minus button to below minimum-order-quantity")
	public void clickMinusButtonToBelowMinimumOrderQuantity() throws Exception {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		CartTestPage cartpage = new CartTestPage();

		// if (pdtsearchresult.getLblMinimumquantity().get(0).isPresent()) {

		// String minQuantityEntireLine =
		// pdtsearchresult.getLblMinimumquantity().get(0).getText();
		// int minQuantity =
		// Integer.parseInt(PerfectoUtils.getIntCharacters(minQuantityEntireLine));

		int minQuantity = getBundle().getInt("MinQuantity");
		System.out.println(minQuantity);
		PerfectoUtils.reportMessage(
				"Minimum Quantity option not found in the product Hece MinQuantity Considered as 1 ",
				MessageTypes.Info);

		PerfectoUtils.scrolltoelement(pdtsearchresult.getTxtCartQuantity());
		int cartQuantity = Integer.parseInt(pdtsearchresult.getTxtCartQuantity().getText());
		System.out.println(cartQuantity);

		if (cartQuantity == minQuantity) {
			PerfectoUtils.reportMessage("cart Quantiry euals minimum quantity. Clicking on Minus button..");
			if (pdtsearchresult.getBtnMinusaddtocart().get(0).isPresent()) {
				pdtsearchresult.getBtnMinusaddtocart().get(0).click();
				PerfectoUtils.reportMessage("Clicked on Minus button.");
				Thread.sleep(3000);
			} else {
				PerfectoUtils.reportMessage("Minus Image in Add to Cart button not found.", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("Cart Quantity doesn't match with the minimum quantity.", MessageTypes.Fail);
		}

		// cartpage.getCartBtnUpdate().click();
		// PerfectoUtils.reportMessage("Clicked on Update button.");
		// cartpage.getCartLblHeader().waitForPresent(3000);

	}

	@QAFTestStep(description = "I see product is removed from the cart entirely")
	public void iSeeProductIsRemovedFromTheCartEntirely() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		PerfectoUtils.scrolltoelement(pdtsearchresult.getTxtCartQuantity());
		int cartQuantity = Integer.parseInt(pdtsearchresult.getTxtCartQuantity().getText());

		if (cartQuantity == 0) {
			PerfectoUtils.reportMessage("Cart Quantity changed to zero.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cart Quantity doesn't changes to zero.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Remove all items from cart")
	public void removeAllItemsFromCart() {
		InStoreHomePage instorehome = new InStoreHomePage();
		CartTestPage cartpage = new CartTestPage();

		// Navigating to the cart Page
		instorehome.getHomeImgCart().waitForPresent(1000);
		instorehome.getHomeImgCart().click();
		PerfectoUtils.reportMessage("Clicked on Cart Icon..");

		cartpage.getCartLblHeader().waitForPresent(1000);
		if (cartpage.getCartLblHeader().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Cart page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Cart page", MessageTypes.Fail);
		}

		// Removing all the items
		int RemoveItemsSize = cartpage.getCartLiLnkRemove().size();

		int i = 0;
		if (RemoveItemsSize > 0) {

			for (QAFWebElement removeitem : cartpage.getCartLiLnkRemove()) {
				PerfectoUtils.scrolltoelement(removeitem);
				removeitem.click();
				PerfectoUtils.reportMessage("Clicked on Remove Item " + i);

				cartpage.getCartBtnYes().waitForPresent(50000);
				if (cartpage.getCartBtnYes().isPresent()) {
					cartpage.getCartBtnYes().click();
					i++;
					continue;
				} else {
					PerfectoUtils.reportMessage("Remove Item Popup not found.", MessageTypes.Fail);
				}
			}

			PerfectoUtils.reportMessage("Removed all the Items in the Cart");

		} else {
			PerfectoUtils.reportMessage("No Items found in the Cart.");
		}

	}

	@QAFTestStep(description = "Verify the Cart button displays Start Shopping")
	public void verifyTheCartButtonDisplaysStartShopping() {
		InStoreHomePage instorehome = new InStoreHomePage();

		PerfectoUtils.mousehover(instorehome.getHomeImgCart());

		if (instorehome.getHomeBtnCartstartshopping().isPresent()) {
			PerfectoUtils.reportMessage("Start Shopping is visible.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Start Shopping is not visible.", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I navigate to cart page")
	public void iNavigateToCartPage() throws Exception {
		InStoreHomePage instorehome = new InStoreHomePage();
		CartTestPage cartpage = new CartTestPage();

		PerfectoUtils.scrolltoelement(instorehome.getHomeBtnCart());
		instorehome.getHomeBtnCart().click();
		cartpage.getCartLblHeader().waitForPresent(5000);
	}

	@QAFTestStep(description = "I navigate to cart page and validate tax is applied")
	public void iNavigateToCartPageandValidateTaxisApplied() throws Exception {
		InStoreHomePage instorehome = new InStoreHomePage();
		CartTestPage cartpage = new CartTestPage();

		PerfectoUtils.scrolltoelement(instorehome.getHomeBtnCart());
		instorehome.getHomeBtnCart().click();
		cartpage.getCartLblHeader().waitForPresent(5000);

		String tax = cartpage.getCartLblTaxValue().getText();
		if (tax.contains("$0.00")) {
			PerfectoUtils.reportMessage("Tax is not applied for taxable product", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("Tax is applied for taxable product", MessageTypes.Pass);
		}

		cartpage.getCartLnkRemove().click();
		cartpage.getCartBtnYes().waitForPresent(5000);
		cartpage.getCartBtnYes().click();
	}

	@QAFTestStep(description = "I navigate to cart page and validate tax is not applied")
	public void iNavigateToCartPageandValidateTaxisnotApplied() throws Exception {
		InStoreHomePage instorehome = new InStoreHomePage();
		CartTestPage cartpage = new CartTestPage();

		PerfectoUtils.scrolltoelement(instorehome.getHomeBtnCart());
		instorehome.getHomeBtnCart().click();
		cartpage.getCartLblHeader().waitForPresent(5000);

		String tax = cartpage.getCartLblTaxValue().getText();
		if (tax.contains("$0.00")) {
			PerfectoUtils.reportMessage("Tax is not applied for non taxable product", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Tax is applied for non taxable product", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I update quantity {0} in cart page")
	public void iUpdateQuantityinCartPage(String quantity, int item) throws Exception {
		CartTestPage cartpage = new CartTestPage();

		cartpage.getCartTxtUpdate(item).clear();
		cartpage.getCartTxtUpdate(item).sendKeys(quantity);
		cartpage.getCartBtnUpdate().click();
	}

	@QAFTestStep(description = "I verify product photo show up to four Product feature icons")
	public void iVerifyProductPhotoShowUpToFourProductFeatureIcons() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		int featureicons = pdtsearchresult.getListFeatureIcons().size();
		String productName = pdtsearchresult.getLblProductname().getText();
		ConfigurationManager.getBundle().setProperty("ProductName", productName);

		if (featureicons <= 4) {
			PerfectoUtils.reportMessage("Maximum four Product feature icons are available ", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("More than four Product feature icons are available ", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I navigated to product detail page")
	public void iNavigatedToProductDetailPage() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		PDPTestPage pdpPage = new PDPTestPage();

		pdtsearchresult.getLblProductname().click();
		pdpPage.waitForPageToLoad();
		pdpPage.getPdpLblProductname().verifyPresent();
		String featurepdt = pdpPage.getPdpLblProductname().getText();
		System.out.println(featurepdt);

	}

	@QAFTestStep(description = "I verify rest of them will be on the product detail page")
	public void iVerifyRestOfThemWillBeOnTheProductDetailPage() {
		PDPTestPage pdpPage = new PDPTestPage();

		int pdpfeatureicons = pdpPage.getPdpListFeatureicons().size() - 1;
		if (pdpfeatureicons >= 4) {
			PerfectoUtils.reportMessage(pdpfeatureicons + " Product feature icons are available in PDP.",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(pdpfeatureicons + " Product feature icons are available in PDP.",
					MessageTypes.Info);
		}
	}

	@QAFTestStep(description = "I verify product photo show up to four Product feature icons in cdp page")
	public void iVerifyProductPhotoShowUpToFourProductFeatureIconsInCDPPage() {
		CDPTestPage cdppage = new CDPTestPage();
		boolean MoreThan4Feature = false;

		for (CDPProductBlocks singleBlock : cdppage.getCdpLiProductblock()) {
			int FeatureImgPresent = singleBlock.getCdpImgFeature().size();
			if (FeatureImgPresent != 0) {
				int featureicons = singleBlock.getCdpImgFeature().size();
				String productName = singleBlock.getCdpTxtProductname().getText();
				ConfigurationManager.getBundle().setProperty("ProductName", productName);
				if (featureicons > 4) {
					PerfectoUtils.reportMessage(
							"More than four Product feature icons are available for product: " + productName,
							MessageTypes.Fail);
					MoreThan4Feature = true;
					break;
				} else {
					MoreThan4Feature = false;
				}
			}
		}

		if (!MoreThan4Feature) {
			PerfectoUtils.reportMessage("Validated the CDP page for feature icons. None are having more than 4 icons",
					MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I navigate to PDP by clicking on the product")
	public static void iNavigateToPDPByClickingOnTheProduct() {
		CDPTestPage cdp = new CDPTestPage();
		FrontdoorTestPage front = new FrontdoorTestPage();

		front.getFrontImgFav().verifyPresent();
		int Size = cdp.getCdpLiProductblock().size();

		for (CDPProductBlocks ChooseProduct : cdp.getCdpLiProductblock()) {
			getBundle().setProperty("addingItemName", ChooseProduct.getCdpTxtProductname().getText());
			ChooseProduct.getCdpTxtProductname().click();
			break;
		}
	}

	@QAFTestStep(description = "I verify Preparation Instructions are not displayed")
	public void iVerifyPreparationInstructionsarenotdisplayed() {
		PDPTestPage pdp = new PDPTestPage();

		pdp.getPdpLblPreparationInstruction().verifyNotPresent();
	}

	@QAFTestStep(description = "I verify marketing bugs Primo pick is displayed in search results page")
	public void iVerifyMarketingbugsPrimopickaredisplayedSearchresults() {
		PdtsearchresultTestPage primo = new PdtsearchresultTestPage();

		primo.getImgMarketingbugPrimopick().verifyPresent();
		PerfectoUtils.reportMessage("Marketing bugs Primo pick is displayed in search results page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I verify marketing bugs {0} is displayed in search results page")
	public void iVerifyMarketingbugsisdisplayedSearchresults(String marketingBug) {
		PdtsearchresultTestPage primo = new PdtsearchresultTestPage();

		primo.getImgMarketingBug(marketingBug).verifyPresent();
		PerfectoUtils.reportMessage("Marketing bugs " + marketingBug + " is displayed in search results page",
				MessageTypes.Pass);
	}

	@QAFTestStep(description = "I verify marketing bugs Primo pick is displayed in PDP")
	public void iVerifyMarketingbugsPrimopickaredisplayedPDP() {
		PDPTestPage pdp = new PDPTestPage();

		pdp.getImgMarketingbugPrimopick().verifyPresent();
		PerfectoUtils.reportMessage("Marketing bugs Primo pick is displayed in PDP", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I verify marketing bugs {0} is displayed in PDP")
	public void iVerifyMarketingbugsisdisplayedPDP(String marketingBug) {
		PDPTestPage pdp = new PDPTestPage();

		pdp.getImgMarketingBug(marketingBug).verifyPresent();
		PerfectoUtils.reportMessage("Marketing bugs " + marketingBug + " Primo pick is displayed in PDP",
				MessageTypes.Pass);
	}

	@QAFTestStep(description = "I verify image scrolls down in PDP when the user scrolls down the PDP")
	public void iVerifyImageScrollDownPDP() {
		PDPTestPage pdp = new PDPTestPage();
		CustomizebakeryTestPage customBakery = new CustomizebakeryTestPage();

		PerfectoUtils.getDriver().switchTo().frame(1);
		pdp.getImgProductImageArea().verifyPresent();
		int[] initialImagePosition = PerfectoUtils.isWebElementVisible(pdp.getImgProductImageArea());
		PerfectoUtils.scrolltoelement(customBakery.getCustomcakeListChoicestitleFrame().get(5));
		int[] firstScrollImagePosition = PerfectoUtils.isWebElementVisible(pdp.getImgProductImageArea());
		PerfectoUtils.scrolltoelement(customBakery.getCustomcakeListChoicestitleFrame().get(7));
		int[] secondScrollImagePosition = PerfectoUtils.isWebElementVisible(pdp.getImgProductImageArea());
		if ((initialImagePosition[1] < firstScrollImagePosition[1])
				&& (firstScrollImagePosition[1] < secondScrollImagePosition[1]))
			PerfectoUtils.reportMessage("Image scrolls down in PDP when the user scrolls down the PDP",
					MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Image does not get scrolled down in PDP when the user scrolls down the PDP",
					MessageTypes.Fail);
	}

	@QAFTestStep(description = "I navigate back and change store")
	public void iNavigateBackandChangeStore() {
		StoreLocatorPage storeLoc = new StoreLocatorPage();

		PerfectoUtils.getDriver().navigate().back();
		storeLoc.selectaStoreFromZipcodeWithStoreId(getBundle().getString("products.instore.zipcode"),
				getBundle().getString("products.instore.storeid"));
		PerfectoUtils.reportMessage("Changed Store", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I click on Add to Cart in we recommend section from PDP")
	public static void iClickonAddtoCartinwerecommendsectionfromPDP() {
		PDPTestPage pdp = new PDPTestPage();

		PerfectoUtils.scrolltoelement(pdp.getBtnWeRecommendAddtocart());
		getBundle().setProperty("addingWeRecommendItemName", pdp.getLblWeRecommendItemname().getText());
		pdp.getBtnWeRecommendAddtocart().click();
		pdp.getLblWRAddtocart1Added().waitForPresent(5000);
		PerfectoUtils.reportMessage("Clicked on Add to Cart button in We recommend section", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I verify the margin for a product in we recommend section")
	public static void iVerifyMarginforaproductinwerecommendsection() {
		PDPTestPage pdp = new PDPTestPage();

		PerfectoUtils.scrolltoelement(pdp.getBtnWeRecommendAddtocart());
		int weRecommendPdts = pdp.getLstWeRecommendPdts().size();
		for (int i = 0; i < weRecommendPdts; i++) {
			String marginTop = pdp.getLstWeRecommendPdts().get(i).getCssValue("margin-top").replaceAll("[^0-9]", "");
			String marginBottom = pdp.getLstWeRecommendPdts().get(i).getCssValue("margin-bottom").replaceAll("[^0-9]",
					"");
			String marginLeft = pdp.getLstWeRecommendPdts().get(i).getCssValue("margin-left").replaceAll("[^0-9]", "");
			String marginRight = pdp.getLstWeRecommendPdts().get(i).getCssValue("margin-right").replaceAll("[^0-9]",
					"");
			if (marginTop != "0" && marginBottom != "0" && marginLeft != "0" && marginRight != "0") {
				PerfectoUtils.reportMessage("Margin for a product are displayed in We recommend section",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Margin for a product are not displayed in We recommend section",
						MessageTypes.Fail);
			}
		}
	}

	@QAFTestStep(description = "I verify nutrition facts panel gets displayed")
	public static void iVerifyNutritionFactsPanelgetsdisplayed() {
		PDPTestPage pdp = new PDPTestPage();

		pdp.getLblnutritionfact().verifyPresent();
	}

	@QAFTestStep(description = "I verify user able to Add we recommend product to cart and verify item in cart")
	public void iVerifyUserabletoAddWeRecommendProducttoCartandVerifyItemincart() throws Exception {
		PdtsearchresultTestPage pdp = new PdtsearchresultTestPage();

		pdp.getLblWeRecommend().verifyPresent();
		pdp.getLnkWeRecommendAddtocart().verifyPresent();
		pdp.getLnkWeRecommendAddtocart().click();
		iNavigateToCartPage();
	}

	@QAFTestStep(description = "I verify the PDP")
	public void iverifythePDP() {
		PDPTestPage pdp = new PDPTestPage();
		if (pdp.getPdpLblProductname().verifyPresent()) {
			PerfectoUtils.reportMessage("Navigated the PDP page", MessageTypes.Info);
			pdp.getPdpLblProductname().verifyPresent();
			pdp.getPdpLblProductprice().verifyPresent();
			pdp.getPdpLblProductdesc().verifyPresent();
			pdp.getPdpEdtQuantity().verifyPresent();
			pdp.getLblsocialblock().verifyPresent();
			pdp.getLbladdtolist().verifyPresent();
			pdp.getLblemail().verifyPresent();
			pdp.getLblnutritionfact().verifyPresent();
			pdp.getLblprint().verifyPresent();

			pdp.getLblwhatuthink().verifyPresent();
			pdp.getLblwrtreview().verifyPresent();
			PerfectoUtils.reportMessage("Validated the PDP page", MessageTypes.Pass);

		} else {
			PerfectoUtils.reportMessage("Not navigated to PDP page ", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I enter quantity more than 99")
	public void ienterquantitymorethan99() {
		PDPTestPage pdp = new PDPTestPage();
		if (pdp.getPdpEdtQuantity().verifyPresent()) {
			pdp.getPdpEdtQuantity().click();
			pdp.getPdpEdtQuantity().sendKeys("999");
			String Digit = pdp.getPdpEdtQuantity().getAttribute("value");
			System.out.println(Digit);
			int i = Integer.parseInt(Digit);
			Pattern p = Pattern.compile("^[0-9]{1,2}");
			Matcher m = p.matcher(Digit);
			if (m.matches()) {
				PerfectoUtils.reportMessage("Cannot add more than 99 quantity", MessageTypes.Pass);

			} else {

				PerfectoUtils.reportMessage("Can add more than 99 quantity", MessageTypes.Fail);
			}
		}

	}

	@QAFTestStep(description = "I verify the snipes in the PDP")
	public void iverifythesnipesinthePDP() {
		PDPTestPage pdp = new PDPTestPage();
		pdp.getPdpLblProductname().verifyPresent();

		if (pdp.getLblwhatdoesthismean().verifyPresent()) {

			int Size = pdp.getPdpListFeatureicons().size();
			System.out.println(Size);

			pdp.getLblnutritionfact().verifyPresent();
			PerfectoUtils.reportMessage(Size - 1 + " Snipes are displayed in PDP", MessageTypes.Pass);

		} else {
			PerfectoUtils.reportMessage("Snipes are not displayed in PDP", MessageTypes.Fail);

		}
	}

	@QAFTestStep(description = "I verify the minimum order quantity error message")
	public void iverifytheminimumorderquantityerrormessage() {
		PDPTestPage pdp = new PDPTestPage();
		pdp.getPdpLblMinquantity().verifyPresent();

		String MOQ = pdp.getPdpEdtQuantity().getAttribute("data-minstock");

		int Count = Integer.parseInt(MOQ);

		int qty = Count - 1;

		pdp.getPdpEdtQuantity().clear();
		pdp.getPdpEdtQuantity().sendKeys(Integer.toString(qty));
		pdp.getPdpBtnAddtocart().click();
		pdp.getLblErrorBlock().waitForPresent(2000);
		pdp.getLblErrorBlock().isDisplayed();
		pdp.geTxtMinimumQtyError().verifyPresent();
	}

	@QAFTestStep(description = "I verify searched Products {0} available in the list")
	public void iVerifySearchedProductsinthelist(String searchedProducts) {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		pdtsearchresult.getLblProductname().equals(searchedProducts);

	}

	@QAFTestStep(description = "I verify the text each for Delivery or Free Store Pickup")
	public void iVerifyTheTextEachForDeliveryOrFreeStorePickup() {
		CustomizeTestPage customizepage = new CustomizeTestPage();

		customizepage.getCustomizeTxtZipcode().verifyPresent();
		customizepage.getCustomizeTxtZipcode().click();
		customizepage.getCustomizeTxtZipcode().sendKeys(getBundle().getString("selectStore.zipCode"));
		PerfectoUtils.reportMessage("Delivery Zipcode is Entered", MessageTypes.Pass);

		customizepage.getCustomizeBtnDelivery().verifyPresent();
		customizepage.getCustomizeBtnDelivery().click();

		customizepage.getTxtPriceLabel().waitForPresent(2000);
		String pricelabel = customizepage.getTxtPriceLabel().getText();
		if (pricelabel.contains("each")) {
			PerfectoUtils.reportMessage("PriceLabel contains 'each' text", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("PriceLabel does not contains 'each' text", MessageTypes.Pass);
		}

		customizepage.getCustomizeBtnStorepickup().verifyPresent();
		customizepage.getCustomizeBtnStorepickup().click();
		if (pricelabel.contains("each")) {
			PerfectoUtils.reportMessage("PriceLabel contains 'each' text", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("PriceLabel does not contains 'each' text", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I verify no message box is present in email to a friend page")
	public void iVerifyNoMessageBoxIsPresentInEmailToAFriendPage() {
		PDPTestPage pdp = new PDPTestPage();

		pdp.waitForPageToLoad();
		pdp.getLblemail().verifyPresent();
		pdp.getLblemail().click();
		pdp.getlblEmailtoFriend().waitForPresent(2000);
		PerfectoUtils.reportMessage("Email to a Friend page opened", MessageTypes.Pass);
		pdp.getlblRecipientEmails().verifyPresent();
		pdp.getLblYourName().verifyPresent();
		pdp.getLblYourEmail().verifyPresent();
		pdp.getLblRecaptcha().verifyPresent();
		pdp.getBtnSendEmail().verifyPresent();
		pdp.getBtnCancel().verifyPresent();

		PerfectoUtils.reportMessage("Message Box is not present", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I verify friend email address allows hypens before the at the rate symbol")
	public void iVerifyHypensAllowedforEmailInEmailToAFriendPage() {
		PDPTestPage pdp = new PDPTestPage();
		EmailTemplateTestPage email = new EmailTemplateTestPage();

		pdp.waitForPageToLoad();
		pdp.getLblemail().verifyPresent();
		pdp.getLblemail().click();
		pdp.getlblEmailtoFriend().waitForPresent(2000);
		PerfectoUtils.reportMessage("Email to a Friend page opened", MessageTypes.Pass);
		email.getEmailEdtRecipentemails().verifyPresent();
		email.getEmailEdtRecipentemails().sendKeys(getBundle().getString("products.emailwithHypen"));
		email.getEmailEdtYouremail().click();
		PerfectoUtils.reportMessage("Friend email address allows hypens before the at the rate symbol",
				MessageTypes.Pass);
	}

	@QAFTestStep(description = "I verify Search Products, Recipes and Contents")
	public void iVerifySearchProductRecipesContents() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		pdtsearchresult.getTxtViewProducts().verifyPresent();
		pdtsearchresult.getTxtViewRecipes().verifyPresent();
		pdtsearchresult.getTxtViewContents().verifyPresent();

		pdtsearchresult.getTxtAllproductsheader().verifyPresent();
		pdtsearchresult.getTxtRecipesheader().verifyPresent();
		pdtsearchresult.getTxtContentsheader().verifyPresent();

		pdtsearchresult.getLnkPdtGridView().verifyPresent();
		pdtsearchresult.getLnkRecipeGridView().verifyPresent();
		pdtsearchresult.getLnkContentView().verifyPresent();

		pdtsearchresult.getTxtViewProducts().click();
		pdtsearchresult.getTxtAllproductsheader().verifyPresent();
		pdtsearchresult.getTxtRecipesheader().verifyNotPresent();
		pdtsearchresult.getTxtContentsheader().verifyNotPresent();
		pdtsearchresult.getLnkPdtGridView().verifyPresent();
		pdtsearchresult.getLnkRecipeGridView().verifyNotPresent();
		pdtsearchresult.getLnkContentView().verifyNotPresent();

		pdtsearchresult.getTxtViewRecipes().click();
		pdtsearchresult.getTxtAllproductsheader().verifyNotPresent();
		pdtsearchresult.getTxtRecipesheader().verifyPresent();
		pdtsearchresult.getTxtContentsheader().verifyNotPresent();
		pdtsearchresult.getLnkPdtGridView().verifyNotPresent();
		pdtsearchresult.getLnkRecipeGridView().verifyPresent();
		pdtsearchresult.getLnkContentView().verifyNotPresent();

		pdtsearchresult.getTxtViewContents().click();
		pdtsearchresult.getTxtAllproductsheader().verifyNotPresent();
		pdtsearchresult.getTxtRecipesheader().verifyNotPresent();
		pdtsearchresult.getTxtContentsheader().verifyPresent();
		pdtsearchresult.getLnkPdtGridView().verifyNotPresent();
		pdtsearchresult.getLnkRecipeGridView().verifyNotPresent();
		pdtsearchresult.getLnkContentView().verifyPresent();

	}
	
	@QAFTestStep(description = "I click on Content link and verify Contents")
	public static void iClickonContentlinkandVerifyContents() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		
		pdtsearchresult.getTxtViewContents().click();
		PerfectoUtils.scrolltoelement(pdtsearchresult.getLnkViewallcontent());
		pdtsearchresult.getLnkViewallcontent().click();
		if(pdtsearchresult.getLblViewOnColor().getCssValue("color").equals(getBundle().getString("products.rgbaColourCode.red"))){
			PerfectoUtils.reportMessage("Contents link is highlighted in red", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Contents link is not highlighted in red", MessageTypes.Fail);
		}
		int contentTitleList = pdtsearchresult.getLstContentsTitle().size();
		if(contentTitleList > 0){
			PerfectoUtils.reportMessage("Content Title name is displayed for each content", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Content Title name is not displayed", MessageTypes.Fail);
		}
		int contentDescList = pdtsearchresult.getLstContentsDesc().size();
		if(contentDescList > 0){
			PerfectoUtils.reportMessage("Content Description or Summary is displayed for each content", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Content Description or Summary is not displayed", MessageTypes.Fail);
		}
		int contentDescReadmoreList = pdtsearchresult.getLstContentsDescReadMore().size();
		if(contentDescReadmoreList > 0){
			PerfectoUtils.reportMessage("Content Description Read more link is displayed for each content", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Content Description Read more link is not displayed", MessageTypes.Fail);
		}
		
		pdtsearchresult.getLstContentsDescReadMore().get(0).click();
		String title = pdtsearchresult.getLblContentsReadmorePage().getText();
		if(title.contains(getBundle().getString("searchproducts.contents.contentsTitle"))){
			PerfectoUtils.reportMessage("Full content area is displayed", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Full content area is not displayed", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I click on Recipes link and validate Add to Recipe box for cold users")
	public static void iClickonRecipeslinkandValidateAddtoRecipeboxforcoldusers() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		myaccountpage myacc = new myaccountpage();
		
		pdtsearchresult.getTxtViewRecipes().click();
		PerfectoUtils.scrolltoelement(pdtsearchresult.getLnkViewallrecipe());
		pdtsearchresult.getLnkViewallrecipe().click();
		if(pdtsearchresult.getLblViewOnColor().getCssValue("color").equals(getBundle().getString("products.rgbaColourCode.red"))){
			PerfectoUtils.reportMessage("Recipes link is highlighted in red", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Recipes link is not highlighted in red", MessageTypes.Fail);
		}
		pdtsearchresult.getLnkListViewRecipes().click();
		pdtsearchresult.getLnkAddtorecipeboxListView().click();
		myacc.iEnteremailandpassword(getBundle().getString("myEmail"),getBundle().getString("register.defaultPassword"));
		myacc.iClickonLoginbutton();
		myacc.iSeetheuserisloggedin();
		pdtsearchresult.getLblAddedtoRecipebox(1).verifyPresent();
	}
	
	@QAFTestStep(description = "I validate Add to Recipe box dropdown in the search results page")
	public static void iValidateAddtoRecipeboxdropdowninthesearchresultspage() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		myaccountpage myacc = new myaccountpage();
		RecipeBoxTestpage recipeBox = new RecipeBoxTestpage();
		
		PerfectoUtils.scrolltoelement(pdtsearchresult.getLnkAddToRecipeBox());
		pdtsearchresult.getLnkAddToRecipeBox().click();
		int noOfFolders = pdtsearchresult.getLstAddtofolder().size();
		if(noOfFolders <= 30){
			PerfectoUtils.reportMessage(noOfFolders+" number of folders is displayed", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Folders displayed is greater than 30", MessageTypes.Fail);
		}
		pdtsearchresult.getLnkAddtofolderBreakfast(1).verifyPresent();
		pdtsearchresult.getLnkAddtofolderBreakfast(1).click();
		myacc.mouseoverUserName();
		pdtsearchresult.getLnkMyrecipebox().verifyPresent();
		pdtsearchresult.getLnkMyrecipebox().click();
		if(recipeBox.getRecipeBoxLnkAllfolder().getText().contains("(1)") && recipeBox.getRecipeBoxLnkBreakfastfolder().getText().contains("(1)")){
			PerfectoUtils.reportMessage("Added the recipe to the All Folder automatically as well as the folder selected by user", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Not Added the recipe to the All Folder as well as the folder selected by user", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I see ahead/Indexed terms of Search text")
	public void iSeeAheadIndexedTermsOfSearchText() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		List<String> megamenuname = new ArrayList<>();
		List<QAFWebElement> hovertext = pdtsearchresult.getLstSearchresultsAheadTerms();
		int hovertextCount = hovertext.size();
		for (QAFWebElement temp : hovertext) {
			megamenuname.add(temp.getText());
			System.out.println(megamenuname);
		}
		for (int i = 1; i <= hovertextCount; i++) {
			PerfectoUtils
					.mousehoverusingActions(pdtsearchresult.getEachLstSearchresultsAheadTerms(Integer.toString(i)));
			// pdtsearchresult.getAheadRightcontainer().verifyPresent();
			PerfectoUtils.reportMessage("Mouseover on the Search Terms " + megamenuname.get(i - 1), MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I Enter valid search half term {0}")
	public void iEnterValidSearchTermHalf(String searchtext) {

		// Enter product name in search field
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();

		frontdoor.waitForPageToLoad();
		PerfectoUtils.scrolltoelement(instorehome.getTxtSearchField());

		CommonStepDef.entervalueintothetextbox(instorehome.getTxtSearchField(), searchtext);
	}

	@QAFTestStep(description = "I verify no search results page")
	public void iVerifyNoSearchResultsPage() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		pdtsearchresult.waitForPageToLoad();
		pdtsearchresult.getLblSearchresult().waitForPresent(30000);
		if (pdtsearchresult.getTxtZerosearchresult().isPresent()) {
			PerfectoUtils.reportMessage("Zero Search Result Message is visible", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Zero Search Result Message is not visible", MessageTypes.Fail);
		}
		
		pdtsearchresult.getTxtViewProducts().verifyNotPresent();
		pdtsearchresult.getTxtViewRecipes().verifyNotPresent();
		pdtsearchresult.getTxtViewContents().verifyNotPresent();
	}
	
	@QAFTestStep(description = "I verify the alternate message if there is no results for erred search term")
	public void iVerifyAlternateMessageifErredSearchTerm() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		
		pdtsearchresult.getLblSearchresult().waitForPresent(30000);
		pdtsearchresult.getTxtZeroresultIncorrect().verifyPresent();
		String incorrectPdtMsg = pdtsearchresult.getTxtZeroresultIncorrect().getText();
		if(incorrectPdtMsg.contains(getBundle().getString("searchproducts.product.incorrectproductname"))){
			PerfectoUtils.reportMessage("Incorrect Product name message is displayed '"+incorrectPdtMsg+"'", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Incorrect Product name message is not displayed '"+incorrectPdtMsg+"'", MessageTypes.Fail);
		}
		pdtsearchresult.getDidYouMeanCorrectedSearchText(getBundle().getString("searchproducts.product.productname")).verifyPresent();
		pdtsearchresult.getLblAlternateMessage().verifyPresent();
		String alternateMsg = pdtsearchresult.getLblAlternateMessage().getText();
		if(alternateMsg.contains(getBundle().getString("searchproducts.product.productname").toLowerCase())){
			PerfectoUtils.reportMessage("Alternate message is displayed '"+alternateMsg+"'", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Alternate message is not displayed '"+alternateMsg+"'", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I click on InMyStore Radio button")
	public void iClickonInMyStoreRadiobutton() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		pdtsearchresult.getRdbInMyStore().click();
		PerfectoUtils.reportMessage("Clicked on InMyStore Radio button", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I Verify Error Message during store selection in In MyStore option")
	public void iVerifyErrorMessage() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		String USNonTexas = getBundle().getString("zip.USNonTexas");
		String errorMsg1 = getBundle().getString("inmystore.NoStoresFound");
		String invalidzip = getBundle().getString("zip.invalidzip");
		String errorMsg2 = getBundle().getString("inmystore.AddressNotRecognized");
		String errorMsg3 = getBundle().getString("inmystore.NoAddress");
		String nonuszip = getBundle().getString("zip.Foreignzip");
		String errorMsg4 = getBundle().getString("inmystore.ForeignAddress");

		pdtsearchresult.getTxtZipcodetext().clear();
		pdtsearchresult.getTxtZipcodetext().sendKeys(USNonTexas);
		pdtsearchresult.getBtnGoInMyStore().click();
		String actualerrorMsg1 = pdtsearchresult.getTxtInMyStoreErrorMsg().getText();
		if (actualerrorMsg1.equals(errorMsg1)) {
			PerfectoUtils.reportMessage("Actual Error message '" + actualerrorMsg1 + " is matched with '" + errorMsg1,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Actual Error message '" + actualerrorMsg1 + " is not matched with '" + errorMsg1,
					MessageTypes.Fail);
		}
		pdtsearchresult.getTxtZipcodetext().sendKeys(invalidzip);
		pdtsearchresult.getBtnGoInMyStore().click();
		PerfectoUtils.reportMessage("Clicked on Go with Invalid zip code In My Store", MessageTypes.Pass);
		String actualerrorMsg2 = pdtsearchresult.getTxtInMyStoreErrorMsg().getText();
		if (actualerrorMsg2.equals(errorMsg2)) {
			PerfectoUtils.reportMessage("Actual Error message '" + actualerrorMsg2 + " is matched with '" + errorMsg2,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Actual Error message '" + actualerrorMsg2 + " is not matched with '" + errorMsg2,
					MessageTypes.Fail);
		}
		pdtsearchresult.getTxtZipcodetext().clear();
		pdtsearchresult.getTxtZipcodetext().sendKeys("");
		pdtsearchresult.getBtnGoInMyStore().click();
		PerfectoUtils.reportMessage("Clicked on Go for the empty zip code InMyStore button", MessageTypes.Pass);
		String actualerrorMsg3 = pdtsearchresult.getTxtInMyStoreErrorMsg().getText();
		if (actualerrorMsg3.equals(errorMsg3)) {
			PerfectoUtils.reportMessage("Actual Error message '" + actualerrorMsg3 + " is matched with '" + errorMsg3,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Actual Error message '" + actualerrorMsg3 + " is not matched with '" + errorMsg3,
					MessageTypes.Fail);
		}
		pdtsearchresult.getTxtZipcodetext().clear();
		pdtsearchresult.getTxtZipcodetext().sendKeys(nonuszip);
		pdtsearchresult.getBtnGoInMyStore().click();
		PerfectoUtils.reportMessage("Clicked on Go with nonus zip code InMyStore button", MessageTypes.Pass);
		String actualerrorMsg4 = pdtsearchresult.getTxtInMyStoreErrorMsg().getText();
		if (actualerrorMsg4.equals(errorMsg4)) {
			PerfectoUtils.reportMessage("Actual Error message '" + actualerrorMsg4 + " is matched with '" + errorMsg4,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Actual Error message '" + actualerrorMsg4 + " is not matched with '" + errorMsg4,
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I mouseover on Find your store and click on Find")
	public void iMouseoveronFindyourstoreandclickonFind() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		PerfectoUtils.mouseover(pdtsearchresult.getLnkFindyourstore());
		pdtsearchresult.getBtnFindyourstore().click();
		PerfectoUtils.reportMessage("Clicked on Find", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I Verify Error Message during store selection in FindaStore page")
	public void iVerifyErrorMessageonFindaStore() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		String USNonTexas = getBundle().getString("zip.USNonTexas");
		String errorMsg1 = getBundle().getString("findastore.NoStoresFound");
		String nonuszip = getBundle().getString("zip.Foreignzip");
		String errorMsg2 = getBundle().getString("findastore.ForeignAddress");
		String invalidzip = getBundle().getString("zip.invalidzip");
		String errorMsg3 = getBundle().getString("findastore.AddressNotRecognized");
		String errorMsg4 = getBundle().getString("findastore.NoAddress");

		pdtsearchresult.getTxtFindyourstore().clear();
		pdtsearchresult.getTxtFindyourstore().sendKeys(USNonTexas);
		pdtsearchresult.getBtnSearchFindyourstore().click();
		pdtsearchresult.waitForAjaxToComplete();

		String actualerrorMsg1 = pdtsearchresult.getTxtFindastoreErrormsg().getText();
		if (actualerrorMsg1.equals(errorMsg1)) {
			PerfectoUtils.reportMessage("Actual Error message '" + actualerrorMsg1 + " is matched with '" + errorMsg1,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Actual Error message '" + actualerrorMsg1 + " is not matched with '" + errorMsg1,
					MessageTypes.Fail);
		}
		pdtsearchresult.getTxtFindyourstore().clear();
		pdtsearchresult.getTxtFindyourstore().sendKeys(nonuszip);
		pdtsearchresult.getBtnSearchFindyourstore().click();
		PerfectoUtils.reportMessage("Clicked on Search for nonus zip code Find a Store", MessageTypes.Pass);

		String actualerrorMsg2 = pdtsearchresult.getTxtFindastoreErrormsg().getText();
		if (actualerrorMsg2.equals(errorMsg2)) {
			PerfectoUtils.reportMessage("Actual Error message '" + actualerrorMsg2 + " is matched with '" + errorMsg2,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Actual Error message '" + actualerrorMsg2 + " is not matched with '" + errorMsg2,
					MessageTypes.Fail);
		}

		pdtsearchresult.getTxtFindyourstore().sendKeys(invalidzip);
		pdtsearchresult.getBtnSearchFindyourstore().click();
		PerfectoUtils.reportMessage("Clicked on Search for the invalid zip code Find a Store", MessageTypes.Pass);

		String actualerrorMsg3 = pdtsearchresult.getTxtFindastoreErrormsg().getText();
		if (actualerrorMsg3.equals(errorMsg3)) {
			PerfectoUtils.reportMessage("Actual Error message '" + actualerrorMsg3 + " is matched with '" + errorMsg3,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Actual Error message '" + actualerrorMsg3 + " is not matched with '" + errorMsg3,
					MessageTypes.Fail);
		}

		pdtsearchresult.getTxtFindyourstore().clear();
		pdtsearchresult.getTxtFindyourstore().sendKeys("");
		pdtsearchresult.getBtnSearchFindyourstore().click();
		PerfectoUtils.reportMessage("Clicked on Search for the empty zip code Find a Store", MessageTypes.Pass);

		String actualerrorMsg4 = pdtsearchresult.getTxtFindastoreErrormsg().getText();
		if (actualerrorMsg4.equals(errorMsg4)) {
			PerfectoUtils.reportMessage("Actual Error message '" + actualerrorMsg4 + " is matched with '" + errorMsg4,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Actual Error message '" + actualerrorMsg4 + " is not matched with '" + errorMsg4,
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify left navigation link and filters in Search Results Page")
	public void iVerifyLeftNavigationLinkinSearchResultsPage() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		pdtsearchresult.getRdbFilterAll().click();
		pdtsearchresult.getLblAllProducts().verifyPresent();
		pdtsearchresult.getLnkFood().verifyPresent();
		pdtsearchresult.getLnkHome().verifyPresent();
		pdtsearchresult.getLnkHealth().verifyPresent();
		pdtsearchresult.getLnkBaby().verifyPresent();
		pdtsearchresult.getLnkOutdoor().verifyPresent();
		pdtsearchresult.getLnkOffice().verifyPresent();
		pdtsearchresult.getLnkFood().click();
		pdtsearchresult.getLnkSubBakery().verifyPresent();
		pdtsearchresult.getLnkHome().click();
		pdtsearchresult.getLnkKitchentoolssub().verifyPresent();
		pdtsearchresult.getLnkHealth().click();
		pdtsearchresult.getLnkMakeupsub().verifyPresent();
		pdtsearchresult.getLnkBaby().click();
		pdtsearchresult.getLnkBabySub().verifyPresent();
		pdtsearchresult.getLnkOutdoor().click();
		pdtsearchresult.getLnkOutdoorSub().verifyPresent();
		pdtsearchresult.getLnkOffice().click();
		pdtsearchresult.getLnkOfficeSub().verifyPresent();

		pdtsearchresult.getRdbFilterinmystore().click();
		pdtsearchresult.getLblHebStore().verifyPresent();
		pdtsearchresult.getLnkFood().verifyPresent();
		pdtsearchresult.getLnkHome().verifyPresent();
		pdtsearchresult.getLnkHealth().verifyPresent();
		pdtsearchresult.getLnkBaby().verifyPresent();
		pdtsearchresult.getLnkOutdoor().verifyPresent();
		pdtsearchresult.getLnkOffice().verifyPresent();
		pdtsearchresult.getLnkFood().click();
		pdtsearchresult.getLnkSubBakery().verifyPresent();
		pdtsearchresult.getLnkHome().click();
		pdtsearchresult.getLnkKitchentoolssub().verifyPresent();
		pdtsearchresult.getLnkHealth().click();
		pdtsearchresult.getLnkMakeupsub().verifyPresent();
		pdtsearchresult.getLnkBaby().click();
		pdtsearchresult.getLnkBabySub().verifyPresent();
		pdtsearchresult.getLnkOutdoor().click();
		// pdtsearchresult.getLnkOutdoorSub().verifyPresent();
		pdtsearchresult.getLnkOffice().click();
		pdtsearchresult.getLnkOfficeSub().verifyPresent();

		pdtsearchresult.getRdbFilterSoldOnline().click();
		pdtsearchresult.getLblSoldOnline().verifyPresent();
		pdtsearchresult.getLnkFood().verifyPresent();
		pdtsearchresult.getLnkHome().verifyPresent();
		pdtsearchresult.getLnkHealth().verifyPresent();
		pdtsearchresult.getLnkFood().click();
		pdtsearchresult.getLnkGrocerysub().verifyPresent();
		pdtsearchresult.getLnkHome().click();
		pdtsearchresult.getLnkKitchentoolssub().verifyPresent();
		pdtsearchresult.getLnkHealth().click();
		pdtsearchresult.getLnkMakeupsub().verifyPresent();
	}

	@QAFTestStep(description = "I verify filters in Search Results Page")
	public void iVerifyfiltersinSearchResultsPage() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		SelectStoreTestPage selectstorepage = new SelectStoreTestPage();
		pdtsearchresult.getRdbFilterAll().click();
		pdtsearchresult.getLblAllProducts().verifyPresent();
		pdtsearchresult.getRdbFilterinmystore().click();
		selectstorepage.getSelstoreLblTitlecolduser().verifyPresent();
		pdtsearchresult.getRdbFilterSoldOnline().click();
		pdtsearchresult.getLblSoldOnline().verifyPresent();
	}

	@QAFTestStep(description = "I verify filters in Search Results Page for Hot User {0}")
	public void iVerifyfiltersinSearchResultsPageforHotUser(String storename) {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		SelectStoreTestPage selectstorepage = new SelectStoreTestPage();
		pdtsearchresult.getRdbFilterAll().click();
		pdtsearchresult.getLblAllProducts().verifyPresent();
		pdtsearchresult.getRdbFilterinmystore().click();
		selectstorepage.getSelstoreGetLblInMYStorename(storename).verifyPresent();
		pdtsearchresult.getRdbFilterSoldOnline().click();
		pdtsearchresult.getLblSoldOnline().verifyPresent();
	}

	@QAFTestStep(description = "I verify the marketing Bugs in the PDP")
	public void iverifythemarketingBugsinthePDP() {

		PDPTestPage pdp = new PDPTestPage();
		pdp.getPdpLblProductname().verifyPresent();

		if (pdp.getLblwhatdoesthismean().verifyPresent()) {

			int size = pdp.getLblmarketingbug().size();
			System.out.println(size);

			pdp.getLblwhatdoesthismean().click();
			pdp.getLblnutritionfact().verifyPresent();
			PerfectoUtils.reportMessage("Marketting bugs are displayed in PDP", MessageTypes.Pass);

		}

		else {
			PerfectoUtils.reportMessage("Marketting bugs are not displayed in PDP", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I submit my review")
	public void isubmitmyreview() {

		PDPTestPage pdp = new PDPTestPage();
		pdp.getPdpLblProductname().verifyPresent();

		if (pdp.getLblreviewmenu().verifyPresent()) {

			pdp.getLblreviewtitle().sendKeys("awesome");

			pdp.getLblreviewcomment().sendKeys("must try it");

			pdp.getLblstar4().click();

			pdp.getBtnsubmit().click();

			if (pdp.getLblreviewerror().verifyPresent()) {
				PerfectoUtils.reportMessage("Not able to submit review system error", MessageTypes.Info);
			} else {
				PerfectoUtils.reportMessage("Able to submit review", MessageTypes.Pass);
			}

		} else {

			PerfectoUtils.reportMessage("Review section is not displayed correctly", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Digital coupons are available in PDP")
	public static void verifyThDigitalCouponsAreAvailableInPDP() {
		PDPTestPage pdp = new PDPTestPage();

		pdp.getLblDigitalcouponsname().waitForPresent(10000);
		pdp.getLblDigitalcouponsname().verifyPresent();
		pdp.getImgDigitalcoupons().verifyPresent();
		pdp.getBtnSelectcoupons().verifyPresent();
	}

	@QAFTestStep(description = "Verify No results found message in Search results page")
	public static void verifyNoResultsFundMessageInSearchResultsPage() {
		PdtsearchresultTestPage pdtsearchresults = new PdtsearchresultTestPage();

		pdtsearchresults.getLblNoresultfounderrormessage().waitForPresent(3000);
		pdtsearchresults.getLblNoresultfounderrormessage().verifyPresent();
	}

	@QAFTestStep(description = "I validate valid search term is persistented in the search bar {0}")
	public static void iValidateSearchTermPersistentedInTheSearchBar(String searchText) {
		PdtsearchresultTestPage pdtsearchresults = new PdtsearchresultTestPage();

		String retainedSeachText = pdtsearchresults.getTxtSearchtext().getAttribute("value");
		if (retainedSeachText.equals(searchText)) {
			PerfectoUtils.reportMessage("Valid search term '" + searchText
					+ "' is persistented in the search bar in the Search Results Page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Valid search term '" + searchText
					+ "' is not persistented in the search bar in the Search Results Page. The Search Text field displays '"
					+ retainedSeachText + "'", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I validate corrected search term is persistented in the search bar {0} {0}")
	public static void iValidateCorrectedSearchTermPersistentedInTheSearchBar(String incorrectSearchText,
			String correctedSearchText) {
		PdtsearchresultTestPage pdtsearchresults = new PdtsearchresultTestPage();

		String retainedCorrectedSeachText = pdtsearchresults.getTxtSearchtext().getAttribute("value");
		if (retainedCorrectedSeachText.equals(correctedSearchText.toLowerCase())) {
			PerfectoUtils.reportMessage("Corrected search term '" + correctedSearchText
					+ "' is persistented in the search bar in the Search Results Page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Corrected search term '" + correctedSearchText
					+ "' is not persistented in the search bar in the Search Results Page. The Search Text field displays '"
					+ retainedCorrectedSeachText + "'", MessageTypes.Fail);
		}

		pdtsearchresults.getDidYouMeanCorrectedSearchText(correctedSearchText).verifyPresent();
		pdtsearchresults.getZeroResultIncorrectSearchText(incorrectSearchText).verifyPresent();
	}

	@QAFTestStep(description = "I validate invalid search term is persistented in the search bar {0}")
	public static void iValidateInvalidSearchTermPersistentedInTheSearchBar(String invalidSearchText) {
		PdtsearchresultTestPage pdtsearchresults = new PdtsearchresultTestPage();

		String retainedInvalidSeachText = pdtsearchresults.getTxtSearchtext().getAttribute("value");
		if (retainedInvalidSeachText.equals(invalidSearchText)) {
			PerfectoUtils.reportMessage("Invalid search term '" + invalidSearchText
					+ "' is persistented in the search bar in the Search Results Page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Invalid search term '" + invalidSearchText
					+ "' is not persistented in the search bar in the Search Results Page. The Search Text field displays '"
					+ retainedInvalidSeachText + "'", MessageTypes.Fail);
		}

		pdtsearchresults.getTxtZeroResultInvalid().verifyPresent();
	}

	@QAFTestStep(description = "I navigate to Bakery")
	public static void iNavigateToBakery() {
		PdtsearchresultTestPage pdtsearchresults = new PdtsearchresultTestPage();

		pdtsearchresults.getLnkFood().click();
		pdtsearchresults.getLnkSubBakery().click();
	}

	@QAFTestStep(description = "I validate rating in CDP PDP page of Products")
	public static void iValidateRatinginCDPpageofProducts() {
		PdtsearchresultTestPage pdtsearchresults = new PdtsearchresultTestPage();

		Select oSelect = new Select(pdtsearchresults.getDDProdSortBySelect());
		oSelect.selectByVisibleText("Ratings");
		pdtsearchresults.getLblRatingContainer().waitForPresent(5000);
		PerfectoUtils.scrolltoelement(pdtsearchresults.getLblRatingContainer());
		pdtsearchresults.getLblRatingContainer().verifyPresent();
		int ratingCountCDP = pdtsearchresults.getLstRatingContainer().size();
		pdtsearchresults.getLblCDPFirstProductTitle().click();
		pdtsearchresults.getLblPDPRatingContainer().verifyPresent();
		int ratingCountPDP = pdtsearchresults.getLstPDPRatingContainer().size();
		if (ratingCountPDP == ratingCountCDP) {
			PerfectoUtils.reportMessage("Rating Count from PDP'" + ratingCountPDP + "' matches the Rating Count of CDP",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Rating Count from PDP'" + ratingCountPDP
					+ "' does not matches the Rating Count of CDP " + ratingCountCDP, MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I add item to cart from PDP")
	public static void iAddItemToCartFromPDP() throws Exception {
		PDPTestPage pdp = new PDPTestPage();

		if (pdp.getPdpBtnAddtocart().isPresent()) {

			getBundle().setProperty("AddedProduct", pdp.getPdpLblProductname().getText());
			pdp.getPdpBtnAddtocart().click();
			pdp.waitForPageToLoad();
			PerfectoUtils.reportMessage("Added to cart.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Add to cart not found.", MessageTypes.Fail);
		}

		if (pdp.getPdpLblMinquantity().isPresent()) {
			String[] minQty = pdp.getPdpLblMinquantity().getText().trim().split(" ");
			if (minQty[2].equals("") || minQty[2].equals(null)) {
				getBundle().setProperty("MinQuantity", Integer.parseInt(minQty[3]));
			} else {
				getBundle().setProperty("MinQuantity", Integer.parseInt(minQty[2]));
			}

		}

	}

	@QAFTestStep(description = "Validate search ahead section properties with valid search term {0}")
	public static void validateSearchAheadSectionPropertiesWithValidSearchTerm(String searchtext) {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		PdtsearchresultTestPage search = new PdtsearchresultTestPage();

		frontdoor.waitForPageToLoad();
		PerfectoUtils.scrolltoelement(instorehome.getTxtSearchFieldSmall());
		instorehome.getTxtSearchFieldSmall().clear();
		CommonStepDef.entervalueintothetextbox(instorehome.getTxtSearchFieldSmall(), searchtext);
		search.getAheadRightcontainer().verifyPresent();
		search.getLstSearchresultsAheadTerms().size();
		search.getLstSearchresultsAheadTerms().get(0).verifyPresent();
		search.getBoxAheadsearch().verifyPresent();

		String actBackgrndColor = search.getBoxAheadsearch().getCssValue("background-color");
		String expBackgrndColor = getBundle().getString("products.rgbaColourCode.white");

		if (actBackgrndColor.equals(expBackgrndColor)) {
			PerfectoUtils.reportMessage("Ahead search section background is verified as White color",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Ahead search section background is not in White color", MessageTypes.Fail);
		}

		String actWidth = search.getBoxAheadsearch().getCssValue("max-width");
		String expWidth = getBundle().getString("searchproducts.aheadSearch.width");

		if (actWidth.equals(expWidth)) {
			PerfectoUtils.reportMessage("Width of Ahead Search Autocomplete is correct" + expWidth, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Width of Ahead Search Autocomplete is incorrect " + actWidth,
					MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I add product to cart and validate Select a store overlay is displayed")
	public static void iAddProductToCartAndValidateSelectAStorePopUpIsDisplayed() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		SelectStoreTestPage selectstore = new SelectStoreTestPage();
		CDPTestPage cdp = new CDPTestPage();
		boolean isCartButtonFound = true;

		for (CDPProductBlocks cdpproducts : cdp.getCdpLiProductblock()) {

			pdtsearchresult.waitForPageToLoad();
			pdtsearchresult.waitForAjaxToComplete();

			if (cdpproducts.getCdpBtnAddtoCart().isPresent()) {

				PerfectoUtils.scrolltoelement(cdpproducts.getCdpBtnAddtoCart());
				cdpproducts.getCdpBtnAddtoCart().waitForPresent(2000);
				cdpproducts.getCdpBtnAddtoCart().verifyPresent();
				cdpproducts.getCdpBtnAddtoCart().click();
				pdtsearchresult.waitForPageToLoad();
				pdtsearchresult.waitForAjaxToComplete();
			} else {
				isCartButtonFound = false;
			}
		}

		if (!isCartButtonFound)
			PerfectoUtils.reportMessage("Cart button is not found for none of the products", MessageTypes.Fail);

		selectstore.getSelstoreLblPickupstoretitle().waitForPresent(10000);
		selectstore.getSelstoreLblPickupstoretitle().verifyPresent();
	}

	@QAFTestStep(description = "I validate whether redirect page url is displayed with search term {0}")
	public static void iValidateWhetherRedirectPageUrlIsDisplayedWithSearchTerm(String searchTerm) {
		String url = PerfectoUtils.getDriver().getCurrentUrl();
		String redirectContent = "urlredirect=" + searchTerm;
		if (url.contains(redirectContent)) {
			PerfectoUtils.reportMessage("Redirect url page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Redirect url page is not displayed", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I validate refine your results for product {0}")
	public static void iValidateRefineyourresultsforproduct(String productName) {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		
		switch(productName.toLowerCase()){
		case "sugar":
			pdtsearchresult.getLblRefineAcorelle().verifyPresent();
			pdtsearchresult.getLblRefineAlmond().verifyNotPresent();
			break;
		case "milk":
			pdtsearchresult.getLblRefineAlmond().verifyPresent();
			pdtsearchresult.getLblRefineAcorelle().verifyNotPresent();
			break;
		}
	}
	
	@QAFTestStep(description = "I click on Home bread crumb and verify whether Home page is displayed")
	public static void iClickonHomebreadcrumbandVerifywhetherHomepageIsDisplayed() {
		FindAStoreTestPage findAStore = new FindAStoreTestPage();
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		
		findAStore.getLnkHomeBreadcrumb().click();
		frontdoor.getFrontImgExploremystore().verifyPresent();
	}

	@QAFTestStep(description = "I add MOQ product to cart")
	public static void iAddMOQProductToCart() throws Exception {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		CDPTestPage cdp = new CDPTestPage();
		boolean isCartButtonFound = false;
		boolean isMOQProductFound = false;
		int qty = 0;

		for (CDPProductBlocks cdpproducts : cdp.getCdpLiProductblock()) {

			pdtsearchresult.waitForPageToLoad();
			pdtsearchresult.waitForAjaxToComplete();

			if (cdpproducts.getCdpLblMinimumquantity().isPresent()) {
				if (cdpproducts.getCdpLblMinimumquantity().getText().trim().equalsIgnoreCase("")
						|| cdpproducts.getCdpLblMinimumquantity().getText().trim().equalsIgnoreCase(null)) {
					getBundle().setProperty("MinQuantity", 1);
				} else {
					cdpproducts.getCdpLblMinimumquantity().verifyPresent();

					if (cdpproducts.getCdpLblMinimumquantity().getText().contains("Minimum Quantity")) {
						PerfectoUtils.reportMessage("Minimum Quantity text is displayed", MessageTypes.Pass);
					} else {
						PerfectoUtils.reportMessage("Minimum Quantity text is not displayed", MessageTypes.Fail);
					}

					String[] strMinQty = cdpproducts.getCdpLblMinimumquantity().getText().trim().split(" ");
					int minQty = Integer.parseInt(strMinQty[2]);
					getBundle().setProperty("MinQuantity", minQty);
					isMOQProductFound = true;
					if (cdpproducts.getCdpBtnAddtoCart().isPresent()) {
						String addingItemName = cdpproducts.getCdpTxtProductname().getText();
						getBundle().setProperty("addingItemName", addingItemName);

						String cartQty = pdtsearchresult.getTxtCartQuantity().getText();
						if (!cartQty.equals(""))
							qty = Integer.parseInt(cartQty);
						getBundle().setProperty("cartQuantity", qty);
						getBundle().setProperty("cartTotalPrice", pdtsearchresult.getTxtCartPrice().getText());

						cdpproducts.getCdpBtnAddtoCart().click();
						isCartButtonFound = true;
						break;
					}

				}

			}
		}

		if (!isMOQProductFound)
			reportMessage("MOQ products are not found.", MessageTypes.Fail);

		if (!isCartButtonFound)
			reportMessage("Add to cart not found", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I see product without Add to Cart button")
	public void iSeeProductWithoutAddToCartButton() {
		STHHomePage sth = new STHHomePage();

		sth.getSthHomeTxtSoldOnline().waitForPresent(2000);
		String soldonline = sth.getSthHomeTxtSoldOnline().getText();

		if (soldonline.contains("0")) {
			sth.getSthHomeBtnAllStores().click();
		} else {
			PerfectoUtils.reportMessage("Non selable itmem found in Sold online", MessageTypes.Fail);
		}

		if (!sth.getSthHomeBtnAddToCart().isPresent()) {
			PerfectoUtils.reportMessage("Add to Cart button is not present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Add to Cart button is present", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the PDP of Make Ready product")
	public void iverifythePDPOfMakeReadyProduct() {
		PDPTestPage pdp = new PDPTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		MakeReadyTestPage makeready = new MakeReadyTestPage();

		if (pdp.getPdpLblProductname().verifyPresent()) {
			PerfectoUtils.reportMessage("Navigated the PDP page", MessageTypes.Info);
			pdp.getPdpLblProductname().verifyPresent();
			pdp.getPdpLblProductprice().verifyPresent();
			pdp.getPdpLblProductdesc().verifyPresent();
			pdp.getPdpEdtQuantity().verifyPresent();
			pdp.getLblsocialblock().verifyPresent();
			pdp.getLbladdtolist().verifyPresent();
			pdp.getLblemail().verifyPresent();
			pdp.getLblprint().verifyPresent();
			pdp.getLblwhatuthink().verifyPresent();
			pdp.getLblwrtreview().verifyPresent();

			// Make Ready product functionalities
			instorehome.getHomeBtnBreadcrumbshop().verifyNotPresent();
			makeready.getMakeLiLblTabs().get(0).verifyPresent();
			makeready.getMakeLiLblTabs().get(1).verifyPresent();
			makeready.getMakeLiLblTabs().get(2).verifyPresent();
			PerfectoUtils.reportMessage("Validated the PDP page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to PDP page ", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I Add Qty {0} to shopping list")
	public static void iAddQtyToShoppingList(int count) {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		String value = Integer.toString(count);

		PerfectoUtils.scrolltoelement(pdtsearchresult.getboxProductQuantity().get(0));
		pdtsearchresult.getboxProductQuantity().get(0).waitForPresent(3000);
		pdtsearchresult.getboxProductQuantity().get(0).click();
		pdtsearchresult.getboxProductQuantity().get(0).clear();
		pdtsearchresult.getboxProductQuantity().get(0).sendKeys(value);

	}

	@QAFTestStep(description = "I Add Qty {0} to shopping list from PDP")
	public static void iAddQtyToShoppingListfromPDP(int count) {
		PDPTestPage pdp = new PDPTestPage();
		String value = Integer.toString(count);

		PerfectoUtils.scrolltoelement(pdp.getPdpEdtQuantity());
		pdp.getPdpEdtQuantity().waitForPresent(3000);
		pdp.getPdpEdtQuantity().click();
		pdp.getPdpEdtQuantity().clear();
		pdp.getPdpEdtQuantity().sendKeys(value);

	}

	@QAFTestStep(description = "I verify Add to Cart is disabled")
	public static void iVerifyAddtoCartisdisabled() {
		PDPTestPage pdp = new PDPTestPage();

		pdp.getPdpBtnAddtocart().verifyDisabled();
	}

	@QAFTestStep(description = "I add a product with quantity {0} to cart")
	public static void iAddAProductWithQuantityToCart(String count) {

		iNavigateToPDPByClickingOnTheProduct();
		iEditQuantityAsInPDPPage(count);
		try {
			iAddItemToCartFromPDP();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@QAFTestStep(description = "I add a product with quantity {0} to cart from Search Page")
	public static void iAddaProductWitQuantityToCartFromSearchPage(String qty) {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		CDPTestPage cdp = new CDPTestPage();
		// pdtsearchresult.getEdtInputQty().clear();
		// pdtsearchresult.getEdtInputQty().sendKeys(qty);
		// pdtsearchresult.getBtnAddToCart().get(0).click();

		for (CDPProductBlocks cdpproducts : cdp.getCdpLiProductblock()) {

			if (cdpproducts.getCdpBtnAddtoCart().isPresent()) {
				PerfectoUtils.scrolltoelement(cdpproducts.getCdpBtnAddtoCart());
				cdpproducts.getCdpBtnAddtoCart().waitForPresent(2000);
				cdpproducts.getEdtInputQty().clear();
				cdpproducts.getEdtInputQty().sendKeys(qty);
				getBundle().setProperty("AddedProduct", cdpproducts.getCdpTxtProductname().getText());
				cdpproducts.getCdpBtnAddtoCart().click();
				break;
			}
		}
	}

	@QAFTestStep(description = "I edit quantity as {0} in PDP page")
	public static void iEditQuantityAsInPDPPage(String qty) {
		PDPTestPage pdp = new PDPTestPage();

		pdp.getPdpEdtQuantity().verifyPresent();
		pdp.getPdpEdtQuantity().click();
		pdp.getPdpEdtQuantity().sendKeys(qty);
		pdp.getPdpLblProductname().click();
		pdp.waitForAjaxToComplete();
		String Digit = pdp.getPdpEdtQuantity().getAttribute("value");

		if (Digit.equals(qty))
			PerfectoUtils.reportMessage("Updated quantity as " + qty, MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not Updated quantity as " + qty, MessageTypes.Fail);

	}

	@QAFTestStep(description = "I Click on plus button")
	public void iClickOnPlusButton() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		CartTestPage cartpage = new CartTestPage();

		PerfectoUtils.scrolltoelement(pdtsearchresult.getTxtCartQuantity());
		int qty = Integer.parseInt(pdtsearchresult.getTxtCartQuantity().getText());
		getBundle().setProperty("QuantityBeforePlus", qty);

		int plusSize = pdtsearchresult.getBtnPlusAddtoCart().size();

		if (plusSize > 0) {
			if (pdtsearchresult.getBtnPlusAddtoCart().get(0).isPresent()) {
				pdtsearchresult.getBtnPlusAddtoCart().get(0).click();
				cartpage.getCartBtnUpdate().click();
				cartpage.waitForPageToLoad();
			} else {
				PerfectoUtils.reportMessage("Plus Image in Add to Cart button not found.", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("Plus Icon not found.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I Should See the Quantity of that item in the Cart increased by one")
	public void iShouldSeeTheQuantityOfThatItemInTheCartIncreasedByOne() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		int quantitybeforePlus = getBundle().getInt("QuantityBeforePlus");

		PerfectoUtils.scrolltoelement(pdtsearchresult.getTxtCartQuantity());
		int quantityAfterPlus = Integer.parseInt(pdtsearchresult.getTxtCartQuantity().getText());

		if (quantityAfterPlus > quantitybeforePlus) {
			PerfectoUtils.reportMessage("Quantity of that item in the Cart increased by one.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Quantity of that item in the Cart not increased by one.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I Click on minus button on PDP page")
	public void iClickOnMinusButtonOnPDPPage() {
		PDPTestPage pdppage = new PDPTestPage();

		PerfectoUtils.scrolltoelement(pdppage.getPdpEdtQuantity());
		int qtybeforeminus = Integer.parseInt(pdppage.getPdpEdtQuantity().getAttribute("value"));
		getBundle().setProperty("QuantityBeforeMinus", qtybeforeminus);

		if (pdppage.getBtnMinusQty().isPresent()) {
			pdppage.getBtnMinusQty().click();
		} else {
			PerfectoUtils.reportMessage("Minus Icon not found.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I Should See the Quantity of that item in the PDP reduced by one")
	public void iShouldSeeTheQuantityOfThatItemInThePDPReducedByOne() {
		PDPTestPage pdppage = new PDPTestPage();

		int quantitybeforeMinus = getBundle().getInt("QuantityBeforeMinus");

		PerfectoUtils.scrolltoelement(pdppage.getPdpEdtQuantity());
		int quantityAfterMinus = Integer.parseInt(pdppage.getPdpEdtQuantity().getAttribute("value"));

		if (quantitybeforeMinus > quantityAfterMinus) {
			PerfectoUtils.reportMessage("Quantity of that item in the PDP reduced by one.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Quantity of that item in the PDP not reduced by one.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I Click on plus button on PDP page")
	public void iClickOnPlusButtonOnPDPPage() {
		PDPTestPage pdppage = new PDPTestPage();

		PerfectoUtils.scrolltoelement(pdppage.getPdpEdtQuantity());
		int qtybeforeplus = Integer.parseInt(pdppage.getPdpEdtQuantity().getAttribute("value"));
		getBundle().setProperty("QuantityBeforePlus", qtybeforeplus);

		if (pdppage.getBtnPlusQty().isPresent()) {
			pdppage.getBtnPlusQty().click();
		} else {
			PerfectoUtils.reportMessage("Plus Icon not found.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I Should See the Quantity of that item in the PDP increased by one")
	public void iShouldSeeTheQuantityOfThatItemInThePDPIncreasedByOne() {
		PDPTestPage pdppage = new PDPTestPage();

		int quantitybeforePlus = getBundle().getInt("QuantityBeforePlus");

		PerfectoUtils.scrolltoelement(pdppage.getPdpEdtQuantity());
		int quantityAfterPlus = Integer.parseInt(pdppage.getPdpEdtQuantity().getAttribute("value"));

		if (quantityAfterPlus > quantitybeforePlus) {
			PerfectoUtils.reportMessage("Quantity of that item in the PDP increased by one.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Quantity of that item in the PDP not increased by one.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I add item to cart lesser than MOQ and verify error message")
	public void iAddItemToCartLesserThanMOQAndVerifyErrorMessage() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		pdtsearchresult.getBtnMinusaddtocart().get(0).click();
		pdtsearchresult.getBtnAddToCart().get(0).click();
		String aTocrterr = pdtsearchresult.getLblAddToCrtError().getText();

		if (aTocrterr.equalsIgnoreCase(
				"We're sorry, an error occurred while adding the item to your cart. Please try again."))
			PerfectoUtils.reportMessage("Error message is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Error message is not displayed", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I add item to cart and checkout as guest")
	public void iAddItemtoCartandCheckoutasGuest() throws Exception {
		CartAndCheckout checkout = new CartAndCheckout();

		iSeeSearchResultsPage();
		iSeeSearchResultPageWithSoldOnlineTag();
		iAddItemToCart();
		iNavigateToCartPage();
		checkout.iCheckOutTheProduct();
		checkout.iSelectGuestCheckoutInCheckOutPage();
	}

	@QAFTestStep(description = "I add item to cart and increase quantity {0} and checkout as guest")
	public void iAddItemtoCartandincreasequantityCheckoutasGuest(String quantity) throws Exception {
		CartAndCheckout checkout = new CartAndCheckout();

		iSeeSearchResultsPage();
		iSeeSearchResultPageWithSoldOnlineTag();
		iAddItemToCart();
		iNavigateToCartPage();
		iUpdateQuantityinCartPage(quantity, 3);
		checkout.iApplyPromotionalCodeInCartPage(getBundle().getString("cartAndChkOut.promotionalcode"));
		checkout.iRemovePromotionalCodeInCartPage();
		checkout.iCheckOutTheProduct();
		checkout.iCheckoutTheItemsAsAGuestUser();
	}

	@QAFTestStep(description = "I add item to cart and increase quantity {0} {0}")
	public void iAddItemtoCartandincreasequantity(String quantity, int itemno) throws Exception {
		iAddItemToCart();
		iNavigateToCartPage();
		iUpdateQuantityinCartPage(quantity, itemno);
	}

	@QAFTestStep(description = "I verify that user is able to apply a promotion from payment page and remove")
	public void iVerifyUserApplyPromotionCodePaymentPage() throws Exception {
		CartAndCheckout checkout = new CartAndCheckout();

		checkout.iApplyPromotionalCodeInCartPage(getBundle().getString("cartAndChkOut.promotionalcode"));
		checkout.iRemovePromotionalCodeInCartPage();
	}

	@QAFTestStep(description = "I add item to cart and verify shipping fees")
	public void iAddItemtoCartandverifyshippingfees() throws Exception {
		iAddItemToCart();
		iNavigateToCartPage();
		iVerifyNoShippingFees();
	}

	@QAFTestStep(description = "I navigate to cart and verify shipping fees")
	public void iNavigatetoCartandverifyshippingfees() throws Exception {
		iNavigateToCartPage();
		iVerifyNoShippingFees();
	}

	@QAFTestStep(description = "I verify no shipping fees")
	public void iVerifyNoShippingFees() throws Exception {
		CartTestPage cart = new CartTestPage();

		String shippingFees = cart.getCartLblShippingvalue().getText();
		if (shippingFees.contains("$0.00")) {
			PerfectoUtils.reportMessage("Shipping Cost is not applied for the first time", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Shipping Cost is applied for the first time", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify shipping fees")
	public void iVerifyShippingFees() throws Exception {
		CartTestPage cart = new CartTestPage();

		String shippingFees = cart.getCartLblShippingvalue().getText();
		if (shippingFees.contains("$0.00")) {
			PerfectoUtils.reportMessage("Shipping Cost is not applied", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("Shipping Cost is applied", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I navigate to payments and verify shipping fees")
	public void iNavigatetoPaymentsandverifyshippingfees() throws Exception {
		PaymentTestPage payment = new PaymentTestPage();

		if (payment.getPaymentLblPaymentmethod().isPresent()) {
			iVerifyShippingFees();
		} else {
			PerfectoUtils.reportMessage("Not navigated to Payments section.", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I navigate to cart page and verify shipping fees")
	public void iNavigatetoCartPageandverifyshippingfees() throws Exception {
		CartTestPage cart = new CartTestPage();

		cart.getCartLnkCarticon().click();
		iVerifyShippingFees();
	}

	@QAFTestStep(description = "Verify that added product is available in cart")
	public void VerifyThatAddedProductIsAvailableInCart() {
		InStoreHomePage instorehome = new InStoreHomePage();
		CartTestPage cartpage = new CartTestPage();

		cartpage.getCartLblProductname().verifyPresent();
		String actPrduct = cartpage.getCartLblProductname().getText();
		String expPrduct = getBundle().getString("AddedProduct");
		boolean isPrdtAvail = false;

		for (String singleActPrdt : actPrduct.split(" ")) {
			if (expPrduct.contains(singleActPrdt)) {
				PerfectoUtils.reportMessage("Added product is available in cart", MessageTypes.Pass);
				isPrdtAvail = true;
				break;
			}
		}

		if (!isPrdtAvail) {
			PerfectoUtils.reportMessage("Added product is not available in cart", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify pickers for customize button")
	public static void iVerifyPickersForCustomizeButton() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		CustomizebakeryTestPage cusbaktest = new CustomizebakeryTestPage();

		pdtsearchresult.getBtnCustomize().waitForPresent(5000);
		String button = pdtsearchresult.getBtnCustomize().getText();

		if (button.equals("CUSTOMIZE")) {
			pdtsearchresult.getBtnCustomize().click();
			cusbaktest.getCustomcakeLblSheetsize().waitForPresent(50000);
			cusbaktest.getCustomcakeLblSheetsize().verifyPresent();
			PerfectoUtils.reportMessage("chosen Picker is present", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("Customize aption is not displayed", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I add to cart without entering information")
	public static void iAddtoCartwithoutEnteringInfo() {
		PDPTestPage pdpPage = new PDPTestPage();

		pdpPage.getPdpBtnAddtocart().click();
		String actualErrorMsg = pdpPage.getLblErrorblockMissinginfo().getText();
		if(actualErrorMsg.equals(getBundle().getString("products.customizemissinginfo"))){
			PerfectoUtils.reportMessage("Missing Information error message is displayed", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Missing Information error message is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify no pickers for customize button")
	public static void iVerifyNoPickerForCustomizeButton() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		CustomizebakeryTestPage cusbaktest = new CustomizebakeryTestPage();

		pdtsearchresult.getBtnAddToCart().get(0).waitForPresent(5000);
		String button = pdtsearchresult.getBtnAddToCart().get(0).getText();

		if (button.equals("ADD TO CART")) {
			pdtsearchresult.getLblProductname().click();
			cusbaktest.getCustomcakeLblSheetsize().verifyNotPresent();
			PerfectoUtils.reportMessage("chosen Picker is not present", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("Add to Cart aption is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I navigate to Shopping list page by clicking Goto full list from Mini list popup")
	public void iNavigateToShoppingListPageByClickingGotoFullListFromMiniListPopup() {
		MiniListTestPage minilist = new MiniListTestPage();
		MyListTestPage mylist = new MyListTestPage();

		int itemCnt = 0;
		int expItemCnt = ConfigurationManager.getBundle().getInt("ingList");

		mylist.waitForPageToLoad();
		mylist.waitForAjaxToComplete();

		minilist.getLblPagetitle().verifyPresent();
		itemCnt = minilist.getLiItemsegments().size();

		if (expItemCnt == itemCnt)
			PerfectoUtils.reportMessage("Mini Shopping list is displayed with added items", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Mini Shopping list is not displayed with added items", MessageTypes.Info);
		// Above command needs to be changed with MessageTypes.Fail

		minilist.getLblGotofulllist().verifyPresent();
		minilist.getLblGotofulllist().click();

		mylist.getMylistLblMylist().waitForPresent(50000);
	}

	@QAFTestStep(description = "I validate the hyperlinks and mouse over texts in CDP page")
	public void iValidateTheHyperlinksAndMouseOverTextsInCDPPage() {
		CDPTestPage cdp = new CDPTestPage();

		PerfectoUtils.reportMessage(
				"Total links available in CDP page are " + cdp.getCdpLiLnkCdpsidecategories().size(),
				MessageTypes.Pass);

		for (QAFWebElement link : cdp.getCdpLiLnkCdpsidecategories()) {
			String href = link.getAttribute("href");
			if (!href.equals("#")) {
				String title = link.getAttribute("title");
				PerfectoUtils.reportMessage("Href : " + href + "; Title: " + title);

			}

		}
	}

	@QAFTestStep(description = "I validate the hyperlinks and mouse over texts in Search page")
	public void iValidateTheHyperlinksAndMouseOverTextsInSearchPage() {
		CDPTestPage cdp = new CDPTestPage();
		PdtsearchresultTestPage searchresult = new PdtsearchresultTestPage();

		PerfectoUtils.reportMessage(
				"Total links available in search page are " + cdp.getCdpLiLnkCdpsidecategories().size(),
				MessageTypes.Pass);

		for (QAFWebElement link : cdp.getCdpLiLnkCdpsidecategories()) {
			String href = link.getAttribute("href");
			if (!href.equals("#")) {
				String title = link.getAttribute("title");
				PerfectoUtils.reportMessage("Href : " + href + "; Title: " + title);
			}
		}

		PerfectoUtils.reportMessage("Href : " + searchresult.getLnkViewallrecipe().getAttribute("href") + "; Title: "
				+ searchresult.getLnkViewallrecipe().getAttribute("title"));

		PerfectoUtils.reportMessage("Href : " + searchresult.getLnkViewallcontent().getAttribute("href") + "; Title: "
				+ searchresult.getLnkViewallcontent().getAttribute("title"));

		for (QAFWebElement link : searchresult.getLiLnkSearchresulttypes()) {
			String href = link.getAttribute("href");
			if (!href.equals("#")) {
				String title = link.getAttribute("title");
				PerfectoUtils.reportMessage("Href : " + href + "; Title: " + title);
			}
		}
	}

	@QAFTestStep(description = "I validate the hyperlinks and mouse over texts in Search Carousels")
	public void iValidateTheHyperlinksAndMouseOverTextsInSearchCarousels() {
		PdtsearchresultTestPage searchresult = new PdtsearchresultTestPage();

		PerfectoUtils.reportMessage("Total Recipe carousel images available in search page are "
				+ searchresult.getLiImgRecipeimages().size(), MessageTypes.Pass);

		for (QAFWebElement link : searchresult.getLiImgRecipeimages()) {
			String href = link.getAttribute("src");
			if (!href.equals("#")) {
				String title = link.getAttribute("alt");
				PerfectoUtils.reportMessage("Src : " + href + "; Alt: " + title);
			}
		}

		for (QAFWebElement link : searchresult.getLiLnkAddtorecipebox()) {
			String href = link.getAttribute("href");
			if (!href.equals("#")) {
				String title = link.getAttribute("title");
				PerfectoUtils.reportMessage("Href : " + href + "; Title: " + title);
			}
		}

	}

	@QAFTestStep(description = "I validate the Star ratings, Price and Minimum Order Quantity")
	public static void iValidateTheStarRatingsPriceAndMinimumOrderQuantity() throws Exception {
		CDPTestPage cdp = new CDPTestPage();
		boolean isMOQProductFound = false;

		for (CDPProductBlocks cdpproducts : cdp.getCdpLiProductblock()) {

			cdp.waitForPageToLoad();
			cdp.waitForAjaxToComplete();

			PerfectoUtils.reportMessage("Validating for product: " + cdpproducts.getCdpTxtProductname().getText());
			cdpproducts.getCdpTxtProductPrice().verifyPresent();
			if (cdpproducts.getCdpLblRatings().isPresent()) {
				PerfectoUtils.reportMessage(
						"Blue Star Ratings are displayed as " + cdpproducts.getCdpLblRatings().getText(),
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Star Rating were not given ", MessageTypes.Info);
			}

			if (cdpproducts.getCdpLblMinimumquantity().isPresent()) {
				if (cdpproducts.getCdpLblMinimumquantity().getText().trim().equalsIgnoreCase("")
						|| cdpproducts.getCdpLblMinimumquantity().getText().trim().equalsIgnoreCase(null)) {
					getBundle().setProperty("MinQuantity", 1);
				} else {
					cdpproducts.getCdpLblMinimumquantity().verifyPresent();

					if (cdpproducts.getCdpLblMinimumquantity().getText().contains("Minimum Quantity")) {
						PerfectoUtils.reportMessage("Minimum Quantity text is displayed", MessageTypes.Pass);
					} else {
						PerfectoUtils.reportMessage("Minimum Quantity text is not displayed", MessageTypes.Fail);
					}

					isMOQProductFound = true;

				}

			}
		}

		if (!isMOQProductFound)
			reportMessage("MOQ products are not found.", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I verify the cart icon in header updated with decreased quantity and total")
	public void iVerifyTheCartIconInHeaderUpdatedWithDecreasedQuantityAndTotal() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		pdtsearchresult.waitForPageToLoad();
		pdtsearchresult.waitForAjaxToComplete();

		int cartQuantityBefore = getBundle().getInt("cartQuantity");
		double cartTotalBefore = Double.parseDouble(getBundle().getString("cartTotalPrice").replace("$", ""));

		int cartQuantity = Integer.parseInt(pdtsearchresult.getTxtCartQuantity().getText());
		double cartTotal = Double.parseDouble(pdtsearchresult.getTxtCartPrice().getText().replace("$", ""));

		if (cartQuantity < cartQuantityBefore) {
			PerfectoUtils.reportMessage("Cart Quantity is reduced from " + cartQuantityBefore + " to " + cartQuantity,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cart Quantity is n't decreased", MessageTypes.Fail);
		}

		if (cartTotal < cartTotalBefore) {
			PerfectoUtils.reportMessage("Cart Total price is reduced from " + cartTotalBefore + " to " + cartTotal,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cart Total price is n't decreased", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the cart icon in header updated with increased quantity and total")
	public void iVerifyTheCartIconInHeaderUpdatedWithIncreasedQuantityAndTotal() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		int cartQuantityBefore = getBundle().getInt("cartQuantity");
		double cartTotalBefore = Double.parseDouble(getBundle().getString("cartTotalPrice").replace("$", ""));

		PerfectoUtils.scrolltoelement(pdtsearchresult.getTxtCartQuantity());
		int cartQuantity = Integer.parseInt(pdtsearchresult.getTxtCartQuantity().getText());
		double cartTotal = Double.parseDouble(pdtsearchresult.getTxtCartPrice().getText().replace("$", ""));

		if (cartQuantity > cartQuantityBefore) {
			PerfectoUtils.reportMessage("Cart Quantity is increased from " + cartQuantityBefore + " to " + cartQuantity,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cart Quantity is n't increased", MessageTypes.Fail);
		}

		if (cartTotal > cartTotalBefore) {
			PerfectoUtils.reportMessage("Cart Total price is increased from " + cartTotalBefore + " to " + cartTotal,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cart Total price is n't increased", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the cart icon in header updated with increased quantity and total for MOQ product")
	public void iVerifyTheCartIconInHeaderUpdatedWithIncreasedQuantityAndTotalForMOQProduct() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();

		int cartQuantityBefore = getBundle().getInt("cartQuantity");
		double cartTotalBefore = Double.parseDouble(getBundle().getString("cartTotalPrice").replace("$", ""));
		int MinQuantity = getBundle().getInt("MinQuantity");

		PerfectoUtils.scrolltoelement(pdtsearchresult.getTxtCartQuantity());
		int cartQuantity = Integer.parseInt(pdtsearchresult.getTxtCartQuantity().getText());
		double cartTotal = Double.parseDouble(pdtsearchresult.getTxtCartPrice().getText().replace("$", ""));

		if (cartQuantity == cartQuantityBefore + MinQuantity) {
			PerfectoUtils.reportMessage("Cart Quantity is increased from " + cartQuantityBefore + " to " + cartQuantity
					+ " Added the MOQ quantity", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cart Quantity is n't increased", MessageTypes.Fail);
		}

		if (cartTotal > cartTotalBefore) {
			PerfectoUtils.reportMessage("Cart Total price is increased from " + cartTotalBefore + " to " + cartTotal,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cart Total price is n't increased", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I validate the Review section for Hotuser")
	public static void iValidateTheReviewSectionForHotuser() {
		RecipedetailTestpage recipedetails = new RecipedetailTestpage();

		recipedetails.getRecipedetailLblBethefirst().verifyPresent();
		recipedetails.getRecipedetailLnkTermsandconditions().verifyPresent();
		recipedetails.getRecipedetailLnkReviewguidelines().verifyPresent();
		recipedetails.getRecipedetailLblEditNickname().verifyPresent();
		recipedetails.getRecipedetailLblRatethisrecipe().verifyPresent();

		String parent = PerfectoUtils.getDriver().getWindowHandle();

		recipedetails.getRecipedetailLnkTermsandconditions().click();

		for (String window : PerfectoUtils.getDriver().getWindowHandles()) {
			if (!window.equals(parent)) {
				PerfectoUtils.getDriver().switchTo().window(window);
			}
		}

		if (PerfectoUtils.getDriver().getCurrentUrl().equals(getBundle().getString("products.reviews.termslink"))) {
			PerfectoUtils.reportMessage(
					"Terms and conditions static page is opened on clicking Terms and conditions link",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Terms and conditions static page is not opened on clicking Terms and conditions link",
					MessageTypes.Fail);
		}

		PerfectoUtils.getDriver().switchTo().window(parent);

		recipedetails.getRecipedetailLnkReviewguidelines().click();

		for (String window : PerfectoUtils.getDriver().getWindowHandles()) {
			if (!window.equals(parent)) {
				PerfectoUtils.getDriver().switchTo().window(window);
			}
		}

		if (PerfectoUtils.getDriver().getCurrentUrl()
				.equals(getBundle().getString("products.reviews.reviewguildlines"))) {
			PerfectoUtils.reportMessage("Review guildlines static page is opened on clicking Terms and conditions link",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Review guildlines static page is not opened on clicking Terms and conditions link",
					MessageTypes.Fail);
		}

		PerfectoUtils.getDriver().close();

	}
	
	@QAFTestStep(description = "I verify Add to cart Button is gray if disabled")
	public static void iVerifyAddtoCartButtonisGreyifDisabledinCDP() {
		CDPTestPage cdp = new CDPTestPage();
		
		String actualColor = cdp.getBtnAddtocartDisabled().getCssValue("background-color");
		String expectedColor = getBundle().getString("products.rgbaColourCode.grey");
		
		if(actualColor.equals(expectedColor)){
			PerfectoUtils.reportMessage("Add to cart Button is gray if disabled in CDP", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Add to cart Button is not gray if disabled in CDP", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I click on {0} refine your results")
	public static void iClickonRefineyourResults(String refineTerm) {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		
		pdtsearchresult.getLblRefineTerm(refineTerm).verifyPresent();
		pdtsearchresult.getLblRefineTerm(refineTerm).click();
		PerfectoUtils.reportMessage("Clicked on refine by "+refineTerm, MessageTypes.Pass);
	}
	
	@QAFTestStep(description = "I verify refined products related to {0}")
	public static void iVerifyRefinedProducts(String refineTerm) {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		
		pdtsearchresult.getLblProductNameDynamic(1).verifyPresent();
		String productName = pdtsearchresult.getLblProductNameDynamic(1).getText();
		if(productName.contains(refineTerm)){
			PerfectoUtils.reportMessage("Search results are refined by "+refineTerm, MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Search results are not refined by "+refineTerm, MessageTypes.Fail);
		}
		
	}
	
	@QAFTestStep(description = "I verify valid message is displayed when there is no product found in the Online store")
	public void iVerifyValidMessageisdisplayedwhenthereisnoproduct() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		CDPTestPage cdpPage = new CDPTestPage();

		PerfectoUtils.ClickContainsTEXTas(cdpPage.getCdpLblFilterbyavailabilityTypes(), "Sold Online");
		String errorMsg = pdtsearchresult.getTxtInMyStoreErrorMsg().getText();
		if(errorMsg.equals(getBundle().getString("products.errorMsg.noproductsonline"))){
			PerfectoUtils.reportMessage("Valid message is displayed when there is no product found in the Online store: "+errorMsg, MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Valid message is not displayed when there is no product found in the Online store: "+errorMsg, MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I click on In My store and select the store and add to cart")
	public void iClickonInMyStoreandSelectthestoreaddtocart() {
		PdtsearchresultTestPage pdtsearchresult = new PdtsearchresultTestPage();
		SelectStoreTestPage store = new SelectStoreTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();
		CartTestPage cart = new CartTestPage();
		
		pdtsearchresult.getRdbInMyStore().click();
		store.getSelstoreTxtZipcode().clear();
		store.getSelstoreTxtZipcode().sendKeys(getBundle().getString("store.zipCodeforStoreId"));
		store.getSelstoreBtnGocolduser().click();
		store.getSelstoreLiStoreselectcolduser().get(2).click();
		String iteminCart = pdtsearchresult.getLblProductname().getText();
		pdtsearchresult.getBtnAddToCart().get(0).click();
		PerfectoUtils.mousehoverusingActions(instorehome.getHomeBtnCart());
		String actualIteminCart = cart.getCartLblCartItemName().getText();
		
		if(iteminCart.contains(actualIteminCart)){
			PerfectoUtils.reportMessage("Added Item displayed in the cart flyout", MessageTypes.Pass);
		} else{
			PerfectoUtils.reportMessage("Added Item is not displayed in the cart flyout", MessageTypes.Fail);
		}
	}
	
}