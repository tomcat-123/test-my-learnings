package com.automation.web.pages.recipes;

import java.util.List;

import com.automation.web.components.recipes.RecipeReviews;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RecipedetailTestpage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}
	
	@FindBy(locator = "recipedetail.lnk.editnickname")
	private QAFWebElement recipedetailLnkEditNickname;
	
	@FindBy(locator = "recipedetail.txt.editnickname")
	private QAFWebElement recipedetailTxtEditNickname;
	
	@FindBy(locator = "recipedetail.btn.editnicknamesave")
	private QAFWebElement recipedetailBtnEditNicknameSave;
	
	@FindBy(locator = "recipedetail.lbl.editnickname")
	private QAFWebElement recipedetailLblEditNickname;
	
	@FindBy(locator = "recipedetail.lbl.cooktimevalue")
	private QAFWebElement recipedetailLblCooktimevalue;
	
	@FindBy(locator = "recipedetail.btn.pinit")
	private QAFWebElement recipedetailBtnPinit;
	
	@FindBy(locator = "recipedetail.btn.tweet")
	private QAFWebElement recipedetailBtnTweet;
	
	@FindBy(locator = "recipedetail.lbl.recipename")
	private QAFWebElement recipedetailLblRecipename;

	@FindBy(locator = "recipedetail.lbl.ingredientstitle")
	private QAFWebElement recipedetailLblIngredientstitle;

	@FindBy(locator = "recipedetail.lbl.instructionstitle")
	private QAFWebElement recipedetailLblInstructionstitle;

	@FindBy(locator = "recipedetail.lbl.recipespagetitle")
	private QAFWebElement recipedetailLblRecipespagetitle;

	@FindBy(locator = "recipedetail.lbl.cookingtips")
	private QAFWebElement recipedetailLblCookingtips;

	@FindBy(locator = "recipedetail.lbl.cookingtipstitle")
	private QAFWebElement recipedetailLblCookingtipstitle;

	@FindBy(locator = "recipedetail.lbl.cookingarticles")
	private QAFWebElement recipedetailLblCookingarticles;

	@FindBy(locator = "recipedetail.lbl.firstcookingarticle")
	private QAFWebElement recipedetailLblFirstcookingarticle;

	@FindBy(locator = "recipedetail.lbl.cookingarticleheader")
	private QAFWebElement recipedetailLblCookingarticleheader;

	@FindBy(locator = "recipedetail.get.lnk.recipeadd2list")
	private QAFWebElement recipedetailGetLnkRecipeadd2list;

	@FindBy(locator = "recipedetail.ddl.mylist")
	private QAFWebElement recipedetailDdlMylist;

	@FindBy(locator = "recipedetail.btn.checkall")
	private QAFWebElement recipedetailBtnCheckall;

	@FindBy(locator = "recipedetail.btn.addtolist")
	private QAFWebElement recipedetailBtnAddtolist;

	@FindBy(locator = "recipedetail.get.chk.chkbox")
	private QAFWebElement recipedetailGetChkChkbox;

	@FindBy(locator = "recipedetail.get.lbl.chkboxtext")
	private QAFWebElement recipedetailGetLblChkboxtext;

	@FindBy(locator = "recipedetail.get.lbl.chkboxmylist")
	private QAFWebElement recipedetailGetLblChkboxmylist;

	@FindBy(locator = "recipedetail.get.lbl.selectedchkboxmylist")
	private QAFWebElement recipedetailGetLblSelectedchkboxmylist;

	@FindBy(locator = "recipedetail.lnk.recipeoftheday")
	private QAFWebElement recipedetailLnkRecipeoftheday;

	@FindBy(locator = "recipedetail.lbl.pagetitle")
	private QAFWebElement recipedetailLblPagetitle;

	@FindBy(locator = "recipedetail.lbl.addtorecipebox")
	private QAFWebElement recipedetailLblAddtorecipebox;

	@FindBy(locator = "recipedetail.li.lbl.recipeboxnames")
	private List<QAFWebElement> recipedetailLiLblRecipeboxnames;

	@FindBy(locator = "recipedetail.lbl.addedtorecipebox")
	private QAFWebElement recipedetailLblAddedtorecipebox;

	@FindBy(locator = "recipedetail.lbl.recipebox")
	private QAFWebElement recipedetailLblRecipebox;

	@FindBy(locator = "recipedetail.lbl.werecommend")
	private QAFWebElement recipedetailLblWerecommend;

	@FindBy(locator = "recipedetail.lbl.recipes")
	private QAFWebElement recipedetailLblRecipes;

	@FindBy(locator = "recipedetail.lbl.preptime")
	private QAFWebElement recipedetailLblPreptime;

	@FindBy(locator = "recipedetail.lbl.cooktime")
	private QAFWebElement recipedetailLblCooktime;

	@FindBy(locator = "recipedetail.lbl.totaltime")
	private QAFWebElement recipedetailLblTotaltime;

	@FindBy(locator = "recipedetail.lbl.serves")
	private QAFWebElement recipedetailLblServes;

	@FindBy(locator = "recipedetail.lbl.addtolistfromrightside")
	private QAFWebElement recipedetailLblAddtolistfromrightside;

	@FindBy(locator = "recipedetail.lbl.email")
	private QAFWebElement recipedetailLblEmail;
	
	@FindBy(locator = "recipedetail.lbl.emailtofriend")
	private QAFWebElement recipedetailLblEmailtofriend;
	
	@FindBy(locator = "recipedetail.txt.recipientemail")
	private QAFWebElement recipedetailTxtRecipientEmail;
	
	@FindBy(locator = "recipedetail.btn.sendemail")
	private QAFWebElement recipedetailBtnSendEmail;
	
	@FindBy(locator = "recipedetail.lnk.emailclose")
	private QAFWebElement recipedetailLnkEmailClose;

	@FindBy(locator = "recipedetail.lbl.print")
	private QAFWebElement recipedetailLblPrint;

	@FindBy(locator = "recipedetail.lbl.nutritionfacts")
	private QAFWebElement recipedetailLblNutritionfacts;

	@FindBy(locator = "recipedetail.lbl.recentlyviewedrecipes")
	private QAFWebElement recipedetailLblRecentlyviewedrecipes;

	@FindBy(locator = "recipedetail.lbl.ratethisrecipe")
	private QAFWebElement recipedetailLblRatethisrecipe;

	@FindBy(locator = "recipedetail.icon.ratingstar4")
	private QAFWebElement recipedetailIconRatingstar4;

	@FindBy(locator = "recipedetail.txt.reviewtitle")
	private QAFWebElement recipedetailTxtReviewtitle;

	@FindBy(locator = "recipedetail.txt.reviewcomments")
	private QAFWebElement recipedetailTxtReviewcomments;

	@FindBy(locator = "recipedetail.btn.submit")
	private QAFWebElement recipedetailBtnSubmit;

	@FindBy(locator = "recipedetail.lbl.thankyou")
	private QAFWebElement recipedetailLblThankyou;

	@FindBy(locator = "recipedetail.lbl.thankyoucommnets")
	private QAFWebElement recipedetailLblThankyoucommnets;

	@FindBy(locator = "recipedetail.btn.loadmorerecipes")
	private QAFWebElement recipedetailBtnLoadmorerecipes;
	
	@FindBy(locator = "recipedetail.btn.hideloadmorerecipes")
	private QAFWebElement recipedetailBtnHideLoadmorerecipes;
	
	@FindBy(locator = "recipedetail.btn.hideloadmorerecipesnotpresent")
	private QAFWebElement recipedetailBtnHideLoadmorerecipesNotPresent;

	@FindBy(locator = "recipedetail.lbl.showing")
	private QAFWebElement recipedetailLblShowing;

	@FindBy(locator = "recipedetail.lbl.mylist")
	private QAFWebElement recipedetailLblMylist;

	@FindBy(locator = "recipedetail.lbl.noofreviews")
	private QAFWebElement recipedetailLblNoofreviews;

	@FindBy(locator = "recipedetail.btn.sortby")
	private QAFWebElement recipedetailBtnSortby;

	@FindBy(locator = "recipedetail.box.reviewblocks")
	private QAFWebElement recipedetailBoxReviewblocks;

	@FindBy(locator = "recipedetail.btn.loadmorereviews")
	private QAFWebElement recipedetailBtnLoadmorereviews;
	
	@FindBy(locator = "recipedetail.txt.firstwerecommendquantitypicker")
	private QAFWebElement recipedetailTxtFirstWeRecommendQuantitypicker;
	
	@FindBy(locator = "recipedetail.lnk.firstwerecommendaddtolist")
	private QAFWebElement recipedetailLnkFirstWeRecommendAddtolist;

	@FindBy(locator = "recipedetail.li.img.reviewlabels")
	private List<QAFWebElement> recipedetailLiImgReviewlabels;
	
	@FindBy(locator = "recipedetail.box.reviewblocks")
	private List<RecipeReviews> recipedetailLiBoxReviewblocks;
	
	@FindBy(locator = "recipedetail.li.addtolists")
	private List<QAFWebElement> liAddtolists;
	
	@FindBy(locator = "recipedetail.li.lbl.ingredients")
	private List<QAFWebElement> recipedetailLiLblIngredients;
	
	@FindBy(locator = "recipedetail.lbl.bethefirst")
	private QAFWebElement recipedetailLblBethefirst;
	
	@FindBy(locator = "recipedetail.lnk.termsandconditions")
	private QAFWebElement recipedetailLnkTermsandconditions;
	
	@FindBy(locator = "recipedetail.lnk.reviewguidelines")
	private QAFWebElement recipedetailLnkReviewguidelines;

	/**
	 * TextView of Recipe name
	 */
	public QAFWebElement getRecipedetailLblRecipename(){ return recipedetailLblRecipename; }

	/**
	 * TextView of Recipe Ingredients title
	 */
	public QAFWebElement getRecipedetailLblIngredientstitle(){ return recipedetailLblIngredientstitle; }

	/**
	 * TextView of Recipe Instructions title
	 */
	public QAFWebElement getRecipedetailLblInstructionstitle(){ return recipedetailLblInstructionstitle; }

	/**
	 * TextView of Page Title
	 */
	public QAFWebElement getRecipedetailLblRecipespagetitle(){ return recipedetailLblRecipespagetitle; }

	/**
	 * TextView of Cooking Tips
	 */
	public QAFWebElement getRecipedetailLblCookingtips(){ return recipedetailLblCookingtips; }

	/**
	 * PageTitle of Cooking Tips
	 */
	public QAFWebElement getRecipedetailLblCookingtipstitle(){ return recipedetailLblCookingtipstitle; }

	/**
	 * TextView of Cooking Articles
	 */
	public QAFWebElement getRecipedetailLblCookingarticles(){ return recipedetailLblCookingarticles; }

	/**
	 * TextView First Cooking Article
	 */
	public QAFWebElement getRecipedetailLblFirstcookingarticle(){ return recipedetailLblFirstcookingarticle; }

	/**
	 * Page Header of Cooking Article
	 */
	public QAFWebElement getRecipedetailLblCookingarticleheader(){ return recipedetailLblCookingarticleheader; }

	/**
	 * LinkView of Recipe Add to List
	 */
	public QAFWebElement getRecipedetailGetLnkRecipeadd2list(String item){ 
		String retElm = String.format(pageProps.getString("recipedetail.get.lnk.recipeadd2list"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Dropdown listView of mylist
	 */
	public QAFWebElement getRecipedetailDdlMylist(){ return recipedetailDdlMylist; }

	/**
	 * ButtonView of CheckAll
	 */
	public QAFWebElement getRecipedetailBtnCheckall(){ return recipedetailBtnCheckall; }

	/**
	 * ButtonView of Add to list
	 */
	public QAFWebElement getRecipedetailBtnAddtolist(){ return recipedetailBtnAddtolist; }

	/**
	 * CheckBoxView of item
	 */
	public QAFWebElement getRecipedetailGetChkChkbox(String item){ 
		String retElm = String.format(pageProps.getString("recipedetail.get.chk.chkbox"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * TextView of CheckBoxitem
	 */
	public QAFWebElement getRecipedetailGetLblChkboxtext(String item){ 
		String retElm = String.format(pageProps.getString("recipedetail.get.lbl.chkboxtext"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * TextView of check box item in My list
	 */
	public QAFWebElement getRecipedetailGetLblChkboxmylist(String item){ 
		String retElm = String.format(pageProps.getString("recipedetail.get.lbl.chkboxmylist"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * TextView of check box item in My list
	 */
	public QAFWebElement getRecipedetailGetLblSelectedchkboxmylist(String item){ 
		String retElm = String.format(pageProps.getString("recipedetail.get.lbl.selectedchkboxmylist"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * LinkView for recipe of the day
	 */
	public QAFWebElement getRecipedetailLnkRecipeoftheday(){ return recipedetailLnkRecipeoftheday; }

	/**
	 * TextView for Recipes Detail pagetitle
	 */
	public QAFWebElement getRecipedetailLblPagetitle(){ return recipedetailLblPagetitle; }

	/**
	 * TextView for add to recipe box
	 */
	public QAFWebElement getRecipedetailLblAddtorecipebox(){ return recipedetailLblAddtorecipebox; }

	/**
	 * ListView for recipe box names
	 */
	public List<QAFWebElement> getRecipedetailLiLblRecipeboxnames(){ return recipedetailLiLblRecipeboxnames; }

	/**
	 * TextView for added to recipe box
	 */
	public QAFWebElement getRecipedetailLblAddedtorecipebox(){ return recipedetailLblAddedtorecipebox; }

	/**
	 * TextView for recipe box in the top
	 */
	public QAFWebElement getRecipedetailLblRecipebox(){ return recipedetailLblRecipebox; }

	/**
	 * TextView for we recommend section header
	 */
	public QAFWebElement getRecipedetailLblWerecommend(){ return recipedetailLblWerecommend; }

	/**
	 * TextView of Recipes
	 */
	public QAFWebElement getRecipedetailLblRecipes(){ return recipedetailLblRecipes; }

	/**
	 * TextView for preptime
	 */
	public QAFWebElement getRecipedetailLblPreptime(){ return recipedetailLblPreptime; }

	/**
	 * TextView for cooktime
	 */
	public QAFWebElement getRecipedetailLblCooktime(){ return recipedetailLblCooktime; }

	/**
	 * TextView for totaltime
	 */
	public QAFWebElement getRecipedetailLblTotaltime(){ return recipedetailLblTotaltime; }

	/**
	 * TextView for serves
	 */
	public QAFWebElement getRecipedetailLblServes(){ return recipedetailLblServes; }

	/**
	 * TextView for add to list from right side
	 */
	public QAFWebElement getRecipedetailLblAddtolistfromrightside(){ return recipedetailLblAddtolistfromrightside; }

	/**
	 * TextView for email
	 */
	public QAFWebElement getRecipedetailLblEmail(){ return recipedetailLblEmail; }
	
	public QAFWebElement getRecipedetailLblEmailtofriend(){ return recipedetailLblEmailtofriend; }
	
	public QAFWebElement getRecipedetailTxtRecipientEmail(){ return recipedetailTxtRecipientEmail; }
	
	public QAFWebElement getRecipedetailBtnSendEmail(){ return recipedetailBtnSendEmail; }
	
	public QAFWebElement getRecipedetailLnkEmailClose(){ return recipedetailLnkEmailClose; }

	/**
	 * TextView for print
	 */
	public QAFWebElement getRecipedetailLblPrint(){ return recipedetailLblPrint; }

	/**
	 * TextView for nutrition facts
	 */
	public QAFWebElement getRecipedetailLblNutritionfacts(){ return recipedetailLblNutritionfacts; }

	/**
	 * TextView for Recently Viewed Recipes
	 */
	public QAFWebElement getRecipedetailLblRecentlyviewedrecipes(){ return recipedetailLblRecentlyviewedrecipes; }

	/**
	 * TextView for rate this recipe
	 */
	public QAFWebElement getRecipedetailLblRatethisrecipe(){ return recipedetailLblRatethisrecipe; }

	/**
	 * IconView for rating star4
	 */
	public QAFWebElement getRecipedetailIconRatingstar4(){ return recipedetailIconRatingstar4; }

	/**
	 * EditView for review title
	 */
	public QAFWebElement getRecipedetailTxtReviewtitle(){ return recipedetailTxtReviewtitle; }

	/**
	 * EditView for review commnets text field
	 */
	public QAFWebElement getRecipedetailTxtReviewcomments(){ return recipedetailTxtReviewcomments; }

	/**
	 * ButtonView for submit
	 */
	public QAFWebElement getRecipedetailBtnSubmit(){ return recipedetailBtnSubmit; }

	/**
	 * TextView for thank you
	 */
	public QAFWebElement getRecipedetailLblThankyou(){ return recipedetailLblThankyou; }

	/**
	 * TextView for thank you comments
	 */
	public QAFWebElement getRecipedetailLblThankyoucommnets(){ return recipedetailLblThankyoucommnets; }

	/**
	 * Buttonview of Recipes
	 */
	public QAFWebElement getRecipedetailBtnLoadmorerecipes(){ return recipedetailBtnLoadmorerecipes; }

	/**
	 * TextView of Showing number of Recipes
	 */
	public QAFWebElement getRecipedetailLblShowing(){ return recipedetailLblShowing; }

	/**
	 * TextView of My List
	 */
	public QAFWebElement getRecipedetailLblMylist(){ return recipedetailLblMylist; }

	/**
	 * TextView of No of reviews available
	 */
	public QAFWebElement getRecipedetailLblNoofreviews(){ return recipedetailLblNoofreviews; }

	/**
	 * DropdownView of Sort by
	 */
	public QAFWebElement getRecipedetailBtnSortby(){ return recipedetailBtnSortby; }

	/**
	 * Blockview of Review blocks
	 */
	public QAFWebElement getRecipedetailBoxReviewblocks(){ return recipedetailBoxReviewblocks; }

	/**
	 * Buttonview of Load more Reviews
	 */
	public QAFWebElement getRecipedetailBtnLoadmorereviews(){ return recipedetailBtnLoadmorereviews; }
	
	public QAFWebElement getRecipedetailTxtFirstWeRecommendQuantitypicker(){ return recipedetailTxtFirstWeRecommendQuantitypicker; }

	public QAFWebElement getRecipedetailLnkFirstWeRecommendAddtolist(){ return recipedetailLnkFirstWeRecommendAddtolist; }

	/**
	 * Imageview of Review labels
	 */
	public List<QAFWebElement> getRecipedetailLiImgReviewlabels(){ return recipedetailLiImgReviewlabels; }
	

	public List<RecipeReviews> getRecipedetailLiBoxReviewblocks(){ return recipedetailLiBoxReviewblocks; }
	
	public QAFWebElement getRecipedetailBtnHideLoadmorerecipes(){ return recipedetailBtnHideLoadmorerecipes; }
	
	public QAFWebElement getRecipedetailBtnHideLoadmorerecipesNotPresent(){ return recipedetailBtnHideLoadmorerecipesNotPresent; }

	public List<QAFWebElement> getLiAddtolists() {
		return liAddtolists;
	}
	
	public List<QAFWebElement> getLiLblIngredients() {
		return recipedetailLiLblIngredients;
	}
	
	public QAFWebElement getRecipedetailBtnPinit(){ return recipedetailBtnPinit; }
	
	public QAFWebElement getRecipedetailBtnTweet(){ return recipedetailBtnTweet; }
	
	public QAFWebElement getRecipedetailLblCooktimevalue(){ return recipedetailLblCooktimevalue; }
	
	public QAFWebElement getRecipedetailLnkEditNickname(){ return recipedetailLnkEditNickname; }
	public QAFWebElement getRecipedetailTxtEditNickname(){ return recipedetailTxtEditNickname; }
	public QAFWebElement getRecipedetailBtnEditNicknameSave(){ return recipedetailBtnEditNicknameSave; }
	public QAFWebElement getRecipedetailLblEditNickname(){ return recipedetailLblEditNickname; }

	public QAFWebElement getRecipedetailLblBethefirst(){ return recipedetailLblBethefirst; }
	
	public QAFWebElement getRecipedetailLnkTermsandconditions(){ return recipedetailLnkTermsandconditions; }
	
	public QAFWebElement getRecipedetailLnkReviewguidelines(){ return recipedetailLnkReviewguidelines; }
	
}