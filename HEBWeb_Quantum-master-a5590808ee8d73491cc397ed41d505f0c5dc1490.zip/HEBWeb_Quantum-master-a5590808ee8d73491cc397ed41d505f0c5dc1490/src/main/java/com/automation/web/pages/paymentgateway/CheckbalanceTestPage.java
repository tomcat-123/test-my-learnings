package com.automation.web.pages.paymentgateway;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CheckbalanceTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "cb.lbl.pageheader")
	private QAFWebElement lblPageheader;
	@FindBy(locator = "cb.lbl.checkgiftcardbalanceheader")
	private QAFWebElement lblCheckgiftcardbalanceheader;
	@FindBy(locator = "cb.lbl.entergiftcardnumber")
	private QAFWebElement lblEntergiftcardnumber;
	@FindBy(locator = "cb.lnk.whereismygiftcardnumber")
	private QAFWebElement lnkWhereismygiftcardnumber;
	@FindBy(locator = "cb.txt.entergiftcardnumber")
	private QAFWebElement txtEntergiftcardnumber;
	@FindBy(locator = "cb.lbl.image")
	private QAFWebElement lblImage;
	@FindBy(locator = "cb.img.captchaimage")
	private QAFWebElement cbImgCaptchaimage;
	@FindBy(locator = "cb.img.tryadifferentimage")
	private QAFWebElement cbImgTryadifferentimage;
	@FindBy(locator = "cb.lbl.clicktoresettheimage")
	private QAFWebElement lblClicktoresettheimage;
	@FindBy(locator = "cb.lbl.typecharactersshownabove")
	private QAFWebElement lblTypecharactersshownabove;
	@FindBy(locator = "cb.lbl.typethecharactersyouseeinimage")
	private QAFWebElement lblTypethecharactersyouseeinimage;
	@FindBy(locator = "cb.txt.typecharactersshownabove")
	private QAFWebElement txtTypecharactersshownabove;
	@FindBy(locator = "cb.btn.checkbalance")
	private QAFWebElement cbBtnCheckbalance;
	@FindBy(locator = "cb.lbl.enterpin")
	private QAFWebElement lblEnterpin;
	@FindBy(locator = "cb.lnk.enterpin")
	private QAFWebElement lnkEnterpin;
	@FindBy(locator = "cb.txt.enterpin")
	private QAFWebElement txtEnterpin;
	@FindBy(locator = "cb.img.captchasection")
	private QAFWebElement imgCaptchasection;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblPageheader() {
		return lblPageheader;
	}

	public QAFWebElement getLblCheckgiftcardbalanceheader() {
		return lblCheckgiftcardbalanceheader;
	}

	public QAFWebElement getLblEntergiftcardnumber() {
		return lblEntergiftcardnumber;
	}

	public QAFWebElement getLnkWhereismygiftcardnumber() {
		return lnkWhereismygiftcardnumber;
	}

	public QAFWebElement getTxtEntergiftcardnumber() {
		return txtEntergiftcardnumber;
	}

	public QAFWebElement getLblImage() {
		return lblImage;
	}

	public QAFWebElement getImgCaptchaimage() {
		return cbImgCaptchaimage;
	}

	public QAFWebElement getImgTryadifferentimage() {
		return cbImgTryadifferentimage;
	}

	public QAFWebElement getLblClicktoresettheimage() {
		return lblClicktoresettheimage;
	}

	public QAFWebElement getLblTypecharactersshownabove() {
		return lblTypecharactersshownabove;
	}

	public QAFWebElement getLblTypethecharactersyouseeinimage() {
		return lblTypethecharactersyouseeinimage;
	}

	public QAFWebElement getTxtTypecharactersshownabove() {
		return txtTypecharactersshownabove;
	}

	public QAFWebElement getBtnCheckbalance() {
		return cbBtnCheckbalance;
	}

	public QAFWebElement getLblEnterpin() {
		return lblEnterpin;
	}

	public QAFWebElement getLnkEnterpin() {
		return lnkEnterpin;
	}

	public QAFWebElement getTxtEnterpin() {
		return txtEnterpin;
	}
	
	public QAFWebElement getImgCaptchasection() {
		return imgCaptchasection;
	}

}
