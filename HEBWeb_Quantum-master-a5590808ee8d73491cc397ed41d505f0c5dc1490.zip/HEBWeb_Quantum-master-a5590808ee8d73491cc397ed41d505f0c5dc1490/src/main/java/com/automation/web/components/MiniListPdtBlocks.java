package com.automation.web.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MiniListPdtBlocks extends QAFWebComponent {

	public MiniListPdtBlocks(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}

	@FindBy(locator = "minilist.li.itemimage")
	private QAFWebElement liItemimage;

	@FindBy(locator = "minilist.lbl.itemdescriptions")
	private QAFWebElement lblItemdescriptions;

	public QAFWebElement getLiItemimage() {
		return liItemimage;
	}

	public QAFWebElement getLblItemdescriptions() {
		return lblItemdescriptions;
	}

}
