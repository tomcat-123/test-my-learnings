package com.automation.web.listener;

import org.openqa.selenium.remote.DriverCommand;

import com.automation.web.commonutils.PerfectoUtils;
import com.qmetry.qaf.automation.ui.webdriver.CommandTracker;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElementCommandAdapter;

public class SeleniumWebEleListener extends QAFWebElementCommandAdapter {
	
	@Override
	public void beforeCommand(QAFExtendedWebElement element, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.CLICK) || commandTracker.getCommand().equalsIgnoreCase(DriverCommand.CLICK_ELEMENT)) {
			PerfectoUtils.scrolltoelement(element);
		}
	}
}