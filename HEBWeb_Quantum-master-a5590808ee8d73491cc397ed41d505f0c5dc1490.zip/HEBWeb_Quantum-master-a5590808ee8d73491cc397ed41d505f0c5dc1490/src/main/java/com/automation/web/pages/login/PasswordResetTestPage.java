package com.automation.web.pages.login;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class PasswordResetTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "passreset.txt.forgotemail")
	private QAFWebElement txtForgotemail;

	@FindBy(locator = "passreset.btn.sendemail")
	private QAFWebElement btnSendemail;

	@FindBy(locator = "passreset.lnk.logintoaccessaccount")
	private QAFWebElement lnkLogintoaccessaccount;

	public QAFWebElement getTxtForgotemail() {
		return txtForgotemail;
	}

	public QAFWebElement getBtnSendemail() {
		return btnSendemail;
	}

	public QAFWebElement getLnkLogintoaccessaccount() {
		return lnkLogintoaccessaccount;
	}

}