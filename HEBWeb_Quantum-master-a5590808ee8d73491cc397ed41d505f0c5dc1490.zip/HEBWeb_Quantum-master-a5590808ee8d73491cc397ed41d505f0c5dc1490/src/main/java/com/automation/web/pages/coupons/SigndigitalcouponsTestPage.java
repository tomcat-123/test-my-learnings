package com.automation.web.pages.coupons;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SigndigitalcouponsTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {@FindBy(locator = "signup.txt.mobilenumone")
private QAFWebElement signupTxtMobilenumone;
@FindBy(locator = "signup.txt.mobilenumtwo")
private QAFWebElement signupTxtMobilenumtwo;
@FindBy(locator = "signup.txt.mobilenumthree")
private QAFWebElement signupTxtMobilenumthree;
@FindBy(locator = "signup.txt.pin")
private QAFWebElement signupTxtPin;
@FindBy(locator = "signup.chk.iagree")
private QAFWebElement signupChkIagree;
@FindBy(locator = "signup.chk.iwantdeals")
private QAFWebElement signupChkIwantdeals;
@FindBy(locator = "signup.btn.submit")
private QAFWebElement signupBtnSubmit;
@FindBy(locator = "signup.lbl.chechyourph")
private QAFWebElement signupLblChechyourph;
@FindBy(locator = "signup.btn.startsaving")
private QAFWebElement signupBtnStartsaving;
@FindBy(locator = "signup.lbl.signupmessage")
private QAFWebElement signupLblSignupmessage;
@FindBy(locator = "signup.lbl.pagetitle")
private QAFWebElement lblPagetitle;

@Override
protected void openPage(PageLocator pageLocator, Object... args) {
}

public QAFWebElement getSignupTxtMobilenumone() {
	return signupTxtMobilenumone;
}

public QAFWebElement getSignupTxtMobilenumtwo() {
	return signupTxtMobilenumtwo;
}

public QAFWebElement getSignupTxtMobilenumthree() {
	return signupTxtMobilenumthree;
}

public QAFWebElement getSignupTxtPin() {
	return signupTxtPin;
}

public QAFWebElement getSignupChkIagree() {
	return signupChkIagree;
}

public QAFWebElement getSignupChkIwantdeals() {
	return signupChkIwantdeals;
}

public QAFWebElement getSignupBtnSubmit() {
	return signupBtnSubmit;
}

public QAFWebElement getSignupLblChechyourph() {
	return signupLblChechyourph;
}

public QAFWebElement getSignupBtnStartsaving() {
	return signupBtnStartsaving;
}

public QAFWebElement getSignupLblSignupmessage() {
	return signupLblSignupmessage;
}

public QAFWebElement getLblPagetitle() {
	return lblPagetitle;
}
}