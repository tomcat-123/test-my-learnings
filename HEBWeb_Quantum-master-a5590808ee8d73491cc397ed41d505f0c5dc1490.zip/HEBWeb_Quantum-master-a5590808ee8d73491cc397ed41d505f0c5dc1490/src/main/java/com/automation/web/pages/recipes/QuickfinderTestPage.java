package com.automation.web.pages.recipes;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class QuickfinderTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "quickfinder.txt.optiontwo")
	private QAFWebElement quickfinderTxtOptiontwo;
	@FindBy(locator = "quickfinder.txt.optionone")
	private QAFWebElement quickfinderTxtOptionone;
	@FindBy(locator = "quickfinder.btn.search")
	private QAFWebElement quickfinderBtnSearch;
	@FindBy(locator = "quickfinder.lbl.quickrecipefinder")
	private QAFWebElement quickfinderlblquickrecipefinder;
	@FindBy(locator = "quickfinder.lbl.searchresults")
	private QAFWebElement quickfinderlblsearchresults;
	@FindBy(locator = "quickfinder.lbl.recipescount")
	private QAFWebElement quickfinderlblrecipescount;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}
	
	public QAFWebElement getQuickFinderRecipesProductImage(String linktext) {
		String loc = String.format(pageProps.getString("quickfinder.get.lbl.quickfinderrecipesproductimage"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getQuickFinderRecipesTitle(String linktext) {
		String loc = String.format(pageProps.getString("quickfinder.get.lbl.quickfinderrecipestitle"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getQuickFinderRecipesSpecs(String linktext) {
		String loc = String.format(pageProps.getString("quickfinder.get.lbl.quickfinderrecipesspecs"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getQuickFinderAddedtoRecipebox(String linktext) {
		String loc = String.format(pageProps.getString("quickfinder.get.lbl.quickfinderaddedtorecipebox"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getQuickFinderAddtoRecipeboxAllOption(String linktext) {
		String loc = String.format(pageProps.getString("quickfinder.get.lbl.addtorecipeboxalloption"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getQuickFinderAddtoList(String linktext) {
		String loc = String.format(pageProps.getString("quickfinder.get.lbl.quickfinderaddtolist"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getQuickFinderAddtoRecipebox(String linktext) {
		String loc = String.format(pageProps.getString("quickfinder.get.lbl.quickfinderaddtorecipebox"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getQuickfinderLblRecipesCount() {
		return quickfinderlblrecipescount;
	}

	public QAFWebElement getQuickfinderTxtOptiontwo() {
		return quickfinderTxtOptiontwo;
	}

	public QAFWebElement getQuickfinderTxtOptionone() {
		return quickfinderTxtOptionone;
	}

	public QAFWebElement getQuickfinderBtnSearch() {
		return quickfinderBtnSearch;
	}

	public QAFWebElement getQuickfinderlblQuickRecipeFinder() {
		return quickfinderlblquickrecipefinder;
	}

	public QAFWebElement getQuickfinderLblSearchResults() {
		return quickfinderlblsearchresults;
	}
	
}
