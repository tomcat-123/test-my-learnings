package com.automation.web.steps.STH;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.components.CDPProductBlocks;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.products.CDPTestPage;
import com.automation.web.pages.search.PdtsearchresultTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of steps in STHStepDef

* Check whether on selecting Ship to Home context shifts to STH view
* Search {0} product through search bar in Products CDP
* Check whether all the Product result has Add to Cart button
* Verify the Add to list button is not present in the STH view CDP
* Validate whether Recipes and Content is not available in the STH search result page
* Verify the Add to cart button is not present in the In Store view CDP

*/

public class STHStepDef {

	@QAFTestStep(description = "Check whether on selecting Ship to Home context shifts to STH view")
	public void checkWhetherOnSelectingShipToHomeContextShiftsToSTHView() {
		CDPTestPage cdpPage = new CDPTestPage();
		cdpPage.getProductList().waitForPresent(5000);

		for (CDPProductBlocks ChooseProduct : cdpPage.getCdpLiProductblock()) {

			if (ChooseProduct.getCdpBtnAddtoCart().isPresent()) {
				PerfectoUtils.reportMessage("STH is displayed", MessageTypes.Pass);
				break;
			} else {
				PerfectoUtils.reportMessage("STH is Not - displayed", MessageTypes.Fail);
				break;
			}
		}
	}

	@QAFTestStep(description = "Search {0} product through search bar in Products CDP")
	public void searchProductThroughSearchBarInProductsCDP(String searchTerm) {
		PdtsearchresultTestPage pdtsearchresults = new PdtsearchresultTestPage();

		pdtsearchresults.getTxtSearchtext().waitForPresent(3000);
		pdtsearchresults.getTxtSearchtext().clear();
		pdtsearchresults.getTxtSearchtext().sendKeys(searchTerm);

		pdtsearchresults.getBtnSearchsubmit().click();
		PerfectoUtils.reportMessage("Entered search term " + searchTerm + " and clicked search icon..");
	}

	@QAFTestStep(description = "Check whether all the Product result has Add to Cart button")
	public void checkWhetherAllTheProductResultHasAddToCartButton() {
		CDPTestPage cdp = new CDPTestPage();

		int addtocartCount = 0;
		int pdtsSize = cdp.getCdpLiProductblock().size();

		if (pdtsSize > 0) {
			PerfectoUtils.reportMessage(pdtsSize + " Search results found..");

			for (CDPProductBlocks ele : cdp.getCdpLiProductblock()) {

				if (ele.getCdpBtnAddtoCart().isPresent()) {
					addtocartCount++;
				}
			}

			if (pdtsSize == addtocartCount) {
				PerfectoUtils.reportMessage("All Pdts are having Add to cart button..", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("All Pdts are not having Add to cart button..", MessageTypes.Fail);
				PerfectoUtils.reportMessage("Pdts count: " + pdtsSize);
				PerfectoUtils.reportMessage("Add to cart count: " + addtocartCount);
			}
		} else {
			PerfectoUtils.reportMessage("No Search results found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Add to list button is not present in the STH view CDP")
	public void verifyTheAddToListButtonIsNotPresentInTheSTHViewCDP() {
		CDPTestPage cdp = new CDPTestPage();

		boolean ispresent = false;
		int pdtsSize = cdp.getCdpLiProductblock().size();

		if (pdtsSize > 0) {
			PerfectoUtils.reportMessage(pdtsSize + " Search results found..");

			for (CDPProductBlocks ele : cdp.getCdpLiProductblock()) {

				if (ele.getCdpBtnAddtoList().isPresent()) {
					ispresent = true;
					break;
				}
			}

			if (!ispresent) {
				PerfectoUtils.reportMessage("Add to list button is not present in the STH view CDP..", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Add to list button is present in the STH view CDP..", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("No Search results found..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate whether Recipes and Content is not available in the STH search result page")
	public void validateWhetherRecipesAndContentIsNotAvailableInTheSTHSearchResultPage() {
		InStoreHomePage instore = new InStoreHomePage();

		instore.getHomeLblHeaderweeklyad().verifyNotPresent();
		instore.getHomeLblHeaderrecipe().verifyNotPresent();
		instore.getHomeLblHeaderpharmacy().verifyNotPresent();
	}

	@QAFTestStep(description = "Verify the Add to cart button is not present in the In Store view CDP")
	public void verifyTheAddToCartButtonIsNotPresentInTheInStoreviewCDP() {
		CDPTestPage cdp = new CDPTestPage();

		boolean ispresent = false;
		int pdtsSize = cdp.getCdpLiProductblock().size();

		if (pdtsSize > 0) {
			PerfectoUtils.reportMessage(pdtsSize + " Search results found..");

			for (CDPProductBlocks ele : cdp.getCdpLiProductblock()) {

				if (ele.getCdpBtnAddtoCart().isPresent()) {
					ispresent = true;
					break;
				}
			}

			if (!ispresent) {
				PerfectoUtils.reportMessage("Add to Cart button is not present in the In store view CDP..", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Add to Cart button is present in the In store view CDP..", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("No Search results found..", MessageTypes.Fail);
		}
	}

}
