package com.automation.web.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MakeReadyProducts extends QAFWebComponent{

	public MakeReadyProducts(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(locator = "make.img.product")
	private QAFWebElement makeImgProduct;

	@FindBy(locator = "make.lbl.productname")
	private QAFWebElement makeLblProductname;

	@FindBy(locator = "make.img.productrating")
	private QAFWebElement makeImgProductrating;

	@FindBy(locator = "make.lbl.productprice")
	private QAFWebElement makeLblProductprice;

	@FindBy(locator = "make.btn.addtocart")
	private QAFWebElement makeBtnAddtocart;

	@FindBy(locator = "make.btn.customize")
	private QAFWebElement makeBtnCustomize;
	
	/**
	 * TextView of product image
	 */
	public QAFWebElement getMakeImgProduct(){ return makeImgProduct; }

	/**
	 * TextView of product name
	 */
	public QAFWebElement getMakeLblProductname(){ return makeLblProductname; }

	/**
	 * ImageView of rating
	 */
	public QAFWebElement getMakeImgProductrating(){ return makeImgProductrating; }

	/**
	 * TextView of price
	 */
	public QAFWebElement getMakeLblProductprice(){ return makeLblProductprice; }

	/**
	 * ButtonView Add to cart
	 */
	public QAFWebElement getMakeBtnAddtocart(){ return makeBtnAddtocart; }

	/**
	 * ButtonView of Customize
	 */
	public QAFWebElement getMakeBtnCustomize(){ return makeBtnCustomize; }

}
