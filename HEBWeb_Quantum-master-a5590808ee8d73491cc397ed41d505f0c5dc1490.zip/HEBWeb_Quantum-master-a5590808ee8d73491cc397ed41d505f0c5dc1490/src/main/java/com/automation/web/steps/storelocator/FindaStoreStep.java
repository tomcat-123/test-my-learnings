package com.automation.web.steps.storelocator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.components.CDPProductBlocks;
import com.automation.web.components.ChoosingStore;
import com.automation.web.pages.homepage.FrontdoorTestPage;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.products.CDPTestPage;
import com.automation.web.pages.products.CustomizeTestPage;
import com.automation.web.pages.storelocator.FindAStoreTestPage;
import com.automation.web.pages.storelocator.StoreDetailsTestPage;
import com.automation.web.pages.storelocator.StoreLocatorTestPage;
import com.automation.web.pages.weeklyads.SelectstoretoviewadsTestPage;
import com.automation.web.pages.weeklyads.WeeklyaddealsTestPage;
import com.automation.web.steps.search.PdtsearchresultPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of steps in FindaStoreStep

* User Choose a store with No Curbside
* User Choose a store with Curbside
* Verify user is able to select the store from the link find other stores
* I verify Default Layout of Find a Store Page
* I Verify there are no stores found with zip code and miles combination
* I Validate the Load More Stores or Stores button and Pagination Displayed
* I Validate See More and Show Less links
* I navigate to Store Details page
* I validate Get Directions to this Store link
* I validate Central Market hyperlink

*/

public class FindaStoreStep{
	StoreLocatorPage store = new StoreLocatorPage();
	
	@QAFTestStep(description="User Choose a store with No Curbside")
	public void userChooseAStoreWithNoCurbside(){
		store.userClickOnStoreFinderIcon();
		FindAStoreTestPage findstore = new FindAStoreTestPage();
		findstore.getFindstoreTxtEnterzipcode().sendKeys("78229");
		findstore.getFindstoreBtnSearch().click();
		int TotalStores = findstore.getStoreResults().size();
		System.out.println("Total stores  " + TotalStores);
		int i = 0;
		
		for (ChoosingStore chooseStore : findstore.getStoreResults()) {
			System.out.println("Total size" + chooseStore.getSize());
			String StoreName = chooseStore.getStoreName().get(i).getText();
			if(chooseStore.getStoreName().get(i).getText().contains("Marketplace")) {
				PerfectoUtils.scrolltoelement(chooseStore.getStoreName().get(i));
				chooseStore.getStoreName().get(i).click();
				break;
			}
					i ++ ;
		}
		}	
	
	@QAFTestStep(description="User Choose a store with Curbside")
	public void userChooseAStoreWithCurbside(){
		store.userClickOnStoreFinderIcon();
		FindAStoreTestPage findstore = new FindAStoreTestPage();
		findstore.getFindstoreTxtEnterzipcode().sendKeys("78229");
		findstore.getFindstoreBtnSearch().click();
		int TotalStores = findstore.getStoreResults().size();
		System.out.println("Total stores  " + TotalStores);
		int i = 0;
		for (ChoosingStore chooseStore : findstore.getStoreResults()) {
			System.out.println("Total size" + chooseStore.getSize());
			String StoreName = chooseStore.getStoreName().get(i).getText();
			if(chooseStore.getStoreName().get(i).getText().contains("I10 and Wurzbach")) {
				PerfectoUtils.scrolltoelement(chooseStore.getStoreName().get(i));
				chooseStore.getStoreName().get(i).click();
				break;
			}
					i ++ ;
		}
	}
	
	@QAFTestStep(description = "Verify user is able to select the store from the link find other stores")
	public void iSelectProductsFromFlowersMegamenu() {
		InStoreHomePage instore = new InStoreHomePage();
		CDPTestPage cdp = new CDPTestPage();
		SelectstoretoviewadsTestPage storename = new SelectstoretoviewadsTestPage();
		CustomizeTestPage custom = new CustomizeTestPage();

		//PdtsearchresultPage.validateEditDetailsAndUpdateFunctionalityInCart();
		
		custom.getLnkFindotherstores().waitForVisible(50000);
		custom.getLnkFindotherstores().click();
		custom.getTxtFindotherstoresZip().waitForVisible(50000);
		custom.getTxtFindotherstoresZip().click();
		custom.getTxtFindotherstoresZip().clear();
		custom.getTxtFindotherstoresZip().sendKeys(ConfigurationManager.getBundle().getString("findotherstoreZip"));
		custom.getBtnFindotherstoresGo().click();
		custom.waitForAjaxToComplete();
		
		custom.getCustomizeBtnFindotherstoresZipSelect().get(1).waitForVisible(50000);
		custom.getCustomizeBtnFindotherstoresZipSelect().get(1).verifyPresent();
		String storeNameInFindotherstores = custom.getLblStoreNamefromFindotherstores(Integer.toString(2)).getText();
		custom.getCustomizeBtnFindotherstoresZipSelect().get(1).click();
		
		custom.waitForAjaxToComplete();
		String storeNameinTop = storename.getLblStoreNameintop().getText();
		if(PerfectoUtils.removeSpecialCharacters(storeNameinTop).equals(PerfectoUtils.removeSpecialCharacters(storeNameInFindotherstores)))
			PerfectoUtils.reportMessage("StoreName updated successfully for the preferred store for all make ready products", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("StoreName is not updated from 'find other stores' link for the preferred store for all make ready products", MessageTypes.Fail);
	}
	
	@QAFTestStep(description = "I verify Default Layout of Find a Store Page")
	public void iVerifyDefaultLayoutFindAStorePage() {
		FindAStoreTestPage findAStore = new FindAStoreTestPage();
		
		findAStore.getFindstoreImgRefineyourresults().verifyPresent();
		String defaultMilesSelected = PerfectoUtils.dropdownGetFirstSelectedOption(findAStore.getDdlDistanceOptions());
		if(defaultMilesSelected.equals(ConfigurationManager.getBundle().getString("storelocator.defaultmiles"))){
			PerfectoUtils.reportMessage("Mileage default to 100 miles", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Mileage is not set as default to 100 miles", MessageTypes.Fail);
		}
		findAStore.getLblStoreResults().verifyNotPresent();
	}
	
	@QAFTestStep(description = "I Verify there are no stores found with zip code and miles combination")
	public void iVerifyNoStoresFoundFindAStorePage() {
		FindAStoreTestPage findAStore = new FindAStoreTestPage();
		
		findAStore.getFindstoreTxtEnterzipcode().sendKeys(ConfigurationManager.getBundle().getString("storelocator.nostoresfoundzip"));
		PerfectoUtils.dropdownSelectByValue(findAStore.getDdlDistanceOptions(), ConfigurationManager.getBundle().getString("miles.seventyfive"));
		findAStore.getFindstoreBtnSearch().click();
		String actualErrorMsg = findAStore.getLblErrormsg().getText();
		if(actualErrorMsg.contains(ConfigurationManager.getBundle().getString("storelocator.nostoreerrmsg1")) && actualErrorMsg.contains(ConfigurationManager.getBundle().getString("storelocator.nostoreerrmsg2"))){
			PerfectoUtils.reportMessage("No stores found error message is displayed", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("No stores found error message is not displayed", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I Validate the Load More Stores or Stores button and Pagination Displayed")
	public void iValidateLoadMoreStoresandPaginationinFindAStorePage() {
		FindAStoreTestPage findAStore = new FindAStoreTestPage();
		
		findAStore.getFindstoreTxtEnterzipcode().sendKeys(ConfigurationManager.getBundle().getString("store.zipCodeforStoreId"));
		findAStore.getFindstoreBtnSearch().click();
		int noOfStoresDisplayedInitially = findAStore.getFindstoreLiDisplayedstores().size();
		if(noOfStoresDisplayedInitially == 8){
			PerfectoUtils.reportMessage("8 stores were initially displayed in the search results", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("8 stores are not initially displayed in the search results", MessageTypes.Fail);
		}
		String noOfStoresXOutOfY = findAStore.getLblPageInitialCount().getText();
		if(noOfStoresXOutOfY.contains(ConfigurationManager.getBundle().getString("storelocator.showingxofyinitial"))){
			PerfectoUtils.reportMessage("Initial pagination information is displayed as expected "+noOfStoresXOutOfY, MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Initial pagination information is not displayed as expected.Actual: "+noOfStoresXOutOfY, MessageTypes.Fail);
		}
		findAStore.getBtnLoadNext().click();
		String noOfStoresXOutOfYUpdated = findAStore.getLblPageStoreCount().getText();
		if(noOfStoresXOutOfYUpdated.contains(ConfigurationManager.getBundle().getString("storelocator.showingxofy1stupdate"))){
			PerfectoUtils.reportMessage("Updated pagination information is displayed as expected "+noOfStoresXOutOfYUpdated, MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Updated pagination information is not displayed as expected.Actual: "+noOfStoresXOutOfYUpdated, MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I Validate See More and Show Less links")
	public void iValidateSeeMoreandShowLesslinks() {
		FindAStoreTestPage findAStore = new FindAStoreTestPage();
		
		int showedFeatures = findAStore.getFindstoreLiShowedFeauture().size();
		if(showedFeatures == 3){
			PerfectoUtils.reportMessage("Top 3 Features for each Area displayed under the refine your results column", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Top 3 Features for each Area is not displayed under the refine your results column", MessageTypes.Fail);
		}
		
		findAStore.getLnkSeeMore().verifyPresent();
		findAStore.getLnkShowLess().verifyNotPresent();
		findAStore.getLblShowedfeautureExpand().verifyNotPresent();
		
		findAStore.getLnkSeeMore().click();
		findAStore.getLnkSeeMore().verifyNotPresent();
		findAStore.getLnkShowLess().verifyPresent();
		findAStore.getLblShowedfeautureExpand().verifyPresent();
		
		findAStore.getLnkShowLess().click();
		

		findAStore.getLnkSeeMore().verifyPresent();
		findAStore.getLnkShowLess().verifyNotPresent();
		findAStore.getLblShowedfeautureExpand().verifyNotPresent();
	}
	
	@QAFTestStep(description = "I navigate to Store Details page")
	public void iNavigateToStoreDetailPage() {
		StoreLocatorTestPage storeloc = new StoreLocatorTestPage();
		
		PerfectoUtils.scrolltoelement(storeloc.getStoreResultsStoreName("1", "1"));
		storeloc.getLnkStoreDetails().click();
	}
	
	@QAFTestStep(description = "I validate Get Directions to this Store link")
	public void iValidateGetDirectionstothisStoreLink() {
		StoreDetailsTestPage storedetails = new StoreDetailsTestPage();
		
		storedetails.getLnkDirectiontostore().click();
		ArrayList<String> tabs = new ArrayList<String> (PerfectoUtils.getDriver().getWindowHandles());
        PerfectoUtils.getDriver().switchTo().window(tabs.get(1));
		String url = PerfectoUtils.getDriver().getCurrentUrl();
		PerfectoUtils.reportMessage(url,MessageTypes.Info);
		if(url.contains(ConfigurationManager.getBundle().getString("storelocator.getdirectiontostoreurl"))){
			PerfectoUtils.reportMessage("Get Directions to this Store link navigates to Bing maps",MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Get Directions to this Store link does not navigates to Bing maps",MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I validate Central Market hyperlink")
	public void iValidateCentralMarkethyperlink() {
		FindAStoreTestPage findAStore = new FindAStoreTestPage();
		
		PerfectoUtils.scrolltoelement(findAStore.getFindstoreLnkCentralmarket());
		findAStore.getFindstoreLnkCentralmarket().click();
		ArrayList<String> tabs = new ArrayList<String> (PerfectoUtils.getDriver().getWindowHandles());
        PerfectoUtils.getDriver().switchTo().window(tabs.get(1));
		String url = PerfectoUtils.getDriver().getCurrentUrl();
		PerfectoUtils.reportMessage(url,MessageTypes.Info);
		if(url.contains(ConfigurationManager.getBundle().getString("storelocator.centralmarketurl"))){
			PerfectoUtils.reportMessage("Central Market hyperlink opens new tab with url "+ConfigurationManager.getBundle().getString("storelocator.centralmarketurl"),MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Central Market hyperlink does not opens new tab with url "+ConfigurationManager.getBundle().getString("storelocator.centralmarketurl"),MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I validate the actions of the Home and Find a Store links in breadcrumb trail")
	public void iValidateHomeFindaStoreLinksinbreadcrumb() {
		FindAStoreTestPage findAStore = new FindAStoreTestPage();
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		StoreLocatorPage store = new StoreLocatorPage();
		
		findAStore.getLnkHomeBreadcrumb().click();
		frontdoor.getFrontImgExploremystore().verifyPresent();
		store.iClickFindyourstoreinfrontdoorpage();
		findAStore.getFindstoreLblBreadcrumb().click();
		findAStore.getFindstoreLblPagetitle().verifyPresent();
	}
	
	@QAFTestStep(description = "I verify the store name is retained")
	public void iVerifyStoreNameisRetained() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		
		String storeName = PerfectoUtils.removeSpecialCharacters(frontdoor.getFrontLnkFindyourstore().getText());
		PerfectoUtils.reportMessage("Expected Store Name: "+ConfigurationManager.getBundle().getString("selectedStrName"), MessageTypes.Info);
		String expectedStoreName = PerfectoUtils.removeSpecialCharacters(ConfigurationManager.getBundle().getString("selectedStrName"));
		if(storeName.equals(expectedStoreName)){
			PerfectoUtils.reportMessage("Store name is retained",MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Store name is not retained",MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I Validate display of data with refine results by selecting and deselecting each area box")
	public void iValidateDisplayofDatawithrefineresults() {
		FindAStoreTestPage findAStore = new FindAStoreTestPage();
		
		int noOfRefineTitle = findAStore.getFindstoreLiRefineResultsAreaList().size();
		PerfectoUtils.reportMessage("Total number of refine results area: "+noOfRefineTitle,MessageTypes.Info);
		String firstRefineTitle = findAStore.getLblRefineResultsArea("0").getText();
		if(firstRefineTitle.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.pharmacy.title"))){
			PerfectoUtils.reportMessage("Pharmacy is listed first",MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Pharmacy is not listed first",MessageTypes.Fail);
		}
		String refineTitle2 = findAStore.getLblRefineResultsArea("1").getText().trim();
		String refineTitle3 = findAStore.getLblRefineResultsArea("2").getText().trim();
		String refineTitle4 = findAStore.getLblRefineResultsArea("3").getText().trim();
		String refineTitle5 = findAStore.getLblRefineResultsArea("4").getText().trim();
		String refineTitle6 = findAStore.getLblRefineResultsArea("5").getText().trim();
		String refineTitle7 = findAStore.getLblRefineResultsArea("6").getText().trim();
		String refineTitle8 = findAStore.getLblRefineResultsArea("7").getText().trim();
		String refineTitle9 = findAStore.getLblRefineResultsArea("8").getText().trim();
		String refineTitle10 = findAStore.getLblRefineResultsArea("9").getText().trim();
		String refineTitle11 = findAStore.getLblRefineResultsArea("10").getText().trim();
		String refineTitle12 = findAStore.getLblRefineResultsArea("11").getText().trim();
		String refineTitle13 = findAStore.getLblRefineResultsArea("12").getText().trim();
		String refineTitle14 = findAStore.getLblRefineResultsArea("13").getText().trim();
		String refineTitle15 = findAStore.getLblRefineResultsArea("14").getText().trim();
		String refineTitle16 = findAStore.getLblRefineResultsArea("15").getText().trim();
		String refineTitle17 = findAStore.getLblRefineResultsArea("16").getText().trim();
		String refineTitle18 = findAStore.getLblRefineResultsArea("17 last").getText().trim();
		
		if(refineTitle2.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.BAkery.title")) &&
		refineTitle3.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.bakery.title")) &&
		refineTitle4.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.deli.title")) &&
		refineTitle5.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.drug.title")) &&
		refineTitle6.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.flower.title")) &&
		refineTitle7.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.food.title")) &&
		refineTitle8.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.grocery.title")) &&
		refineTitle9.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.heb.title")) &&
		refineTitle10.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.healthyliving.title")) &&
		refineTitle11.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.lease.title")) &&
		refineTitle12.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.market.title")) &&
		refineTitle13.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.online.title")) &&
		refineTitle14.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.optical.title")) &&
		refineTitle15.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.produce.title")) &&
		refineTitle16.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.seafood.title")) &&
		refineTitle17.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.storeservice.title")) &&
		refineTitle18.equals(ConfigurationManager.getBundle().getString("storelocator.refineresults.testing.title"))){
			PerfectoUtils.reportMessage("Areas other than Pharmacy are displayed and listed in alphabetical order",MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Areas other than Pharmacy are not listed in alphabetical order",MessageTypes.Fail);
		}
		
		/*if((findAStore.getLblRefineResultsEachAreaList("0").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("0").size() &&
		(findAStore.getLblRefineResultsEachAreaList("1").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("1").size() &&
		(findAStore.getLblRefineResultsEachAreaList("2").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("2").size() &&
		(findAStore.getLblRefineResultsEachAreaList("3").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("3").size() &&
		(findAStore.getLblRefineResultsEachAreaList("4").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("4").size() &&
		(findAStore.getLblRefineResultsEachAreaList("5").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("5").size() &&
		(findAStore.getLblRefineResultsEachAreaList("6").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("6").size() &&
		(findAStore.getLblRefineResultsEachAreaList("7").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("7").size() &&
		(findAStore.getLblRefineResultsEachAreaList("9").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("9").size() &&
		(findAStore.getLblRefineResultsEachAreaList("11").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("11").size() &&
		(findAStore.getLblRefineResultsEachAreaList("12").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("12").size() &&
		(findAStore.getLblRefineResultsEachAreaList("13").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("13").size() &&
		(findAStore.getLblRefineResultsEachAreaList("14").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("14").size() &&
		(findAStore.getLblRefineResultsEachAreaList("15").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("15").size() &&
		(findAStore.getLblRefineResultsEachAreaList("16").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("16").size() &&
		(findAStore.getLblRefineResultsEachAreaList("17 last").size() - 1) == findAStore.getLblRefineResultsEachAreaCheckBoxList("17 last").size()){
			PerfectoUtils.reportMessage("Each Feature has check box in front of it",MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Each Feature do not have check box in front of it",MessageTypes.Fail);
		}
		
		findAStore.getLnkSeeMore().click();
		if(findAStore.getLblRefineResultsEachAreaSeeMoreCheckBoxList(2).size() > 0){
			PerfectoUtils.reportMessage("Each Feature has check box in front of it after clicking see more link",MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("Each Feature do not have check box in front of it after clicking see more link",MessageTypes.Fail);
		}*/
		
		String beforeFiltration = findAStore.getLblPageInitialCount().getText();
		PerfectoUtils.reportMessage("Initial Search Results "+beforeFiltration,MessageTypes.Info);
		
		findAStore.getChkRefineResultsArea1stCheck(0).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Pharmacy filtration selection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		findAStore.getChkRefineResultsArea1stCheck(0).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Pharmacy filtration deselection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		
		findAStore.getChkRefineResultsArea1stCheck(2).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Bakery filtration selection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		findAStore.getChkRefineResultsArea1stCheck(2).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Bakery filtration deselection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		
		findAStore.getChkRefineResultsArea1stCheck(3).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Deli filtration selection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		findAStore.getChkRefineResultsArea1stCheck(3).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Deli filtration deselection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		
		findAStore.getChkRefineResultsArea1stCheck(4).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Drugstore & GM filtration selection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		findAStore.getChkRefineResultsArea1stCheck(4).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Drugstore & GM filtration deselection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		
		findAStore.getChkRefineResultsArea1stCheck(5).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Flower Shop filtration selection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		findAStore.getChkRefineResultsArea1stCheck(5).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Flower Shop filtration deselection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		
		findAStore.getChkRefineResultsArea1stCheck(6).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Food Services filtration selection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		findAStore.getChkRefineResultsArea1stCheck(6).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Food Services filtration deselection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		
		findAStore.getChkRefineResultsArea1stCheck(7).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Grocery filtration selection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		findAStore.getChkRefineResultsArea1stCheck(7).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Grocery filtration deselection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		
		findAStore.getChkRefineResultsArea1stCheck(11).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Market filtration selection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		findAStore.getChkRefineResultsArea1stCheck(11).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Market filtration deselection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		
		findAStore.getChkRefineResultsArea1stCheck(14).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Produce filtration selection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		findAStore.getChkRefineResultsArea1stCheck(14).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Produce filtration deselection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		
		findAStore.getChkRefineResultsArea1stCheck(15).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Seafood filtration selection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		findAStore.getChkRefineResultsArea1stCheck(15).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Seafood filtration deselection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		
		findAStore.getChkRefineResultsArea1stCheck(16).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Store Services filtration selection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
		findAStore.getChkRefineResultsArea1stCheck(16).click();
		findAStore.waitForAjaxToComplete();
		PerfectoUtils.reportMessage("After Store Services filtration deselection "+findAStore.getLblPageInitialCount().getText(),MessageTypes.Info);
	}
	
}