package com.automation.web.components.ShoppingLists;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ManageListsBlocks extends QAFWebComponent {

	public ManageListsBlocks(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}

	@FindBy(locator = "mylist.li.manageliststimestamp")
	private QAFWebElement liManageliststimestamp;

	public QAFWebElement getLiManageliststimestamp() {
		return liManageliststimestamp;
	}

}
