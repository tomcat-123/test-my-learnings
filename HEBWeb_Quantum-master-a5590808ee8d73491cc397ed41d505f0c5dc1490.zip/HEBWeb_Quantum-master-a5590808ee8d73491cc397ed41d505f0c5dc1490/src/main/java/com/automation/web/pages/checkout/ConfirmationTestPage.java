package com.automation.web.pages.checkout;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ConfirmationTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "confirm.lbl.activetitle")
	private QAFWebElement confirmLblActivetitle;

	@FindBy(locator = "confirm.btn.continueshopping")
	private QAFWebElement confirmBtnContinueshopping;

	@FindBy(locator = "confirm.lbl.thankyou")
	private QAFWebElement confirmLblThankyou;

	@FindBy(locator = "confirm.lbl.ordernum")
	private QAFWebElement confirmLblOrdernum;

	@FindBy(locator = "confirm.lbl.emailid")
	private QAFWebElement confirmLblEmailid;

	@FindBy(locator = "confirm.lbl.shiptohome")
	private QAFWebElement confirmLblShiptohome;

	@FindBy(locator = "confirm.lbl.delivery")
	private QAFWebElement confirmLblDelivery;

	@FindBy(locator = "confirm.lbl.instorepickup")
	private QAFWebElement confirmLblInstorepickup;

	@FindBy(locator = "confirm.li.sthproducts")
	private List<QAFWebElement> confirmLiSthproducts;

	@FindBy(locator = "confirm.lbl.itemstotal")
	private QAFWebElement confirmLblItemstotal;

	@FindBy(locator = "confirm.lbl.ordertotalamt")
	private QAFWebElement confirmLblOrdertotalamt;

	@FindBy(locator = "confirm.lbl.ordersubtotalamt")
	private QAFWebElement confirmLblOrdersubtotalamt;

	@FindBy(locator = "confirm.lbl.shippingamt")
	private QAFWebElement confirmLblShippingamt;

	@FindBy(locator = "confirm.lbl.discountamt")
	private QAFWebElement confirmLblDiscountamt;

	@FindBy(locator = "confirm.lbl.estimatedtaxamt")
	private QAFWebElement confirmLblEstimatedtaxamt;

	@FindBy(locator = "confirm.lbl.deliveryfeeamt")
	private QAFWebElement confirmLblDeliveryfeeamt;

	@FindBy(locator = "confirm.li.itemtotal")
	private List<QAFWebElement> confirmLiItemtotal;

	@FindBy(locator = "confirm.lbl.quantity")
	private QAFWebElement confirmLblQuantity;

	@FindBy(locator = "confirm.li.instoreproducts")
	private List<QAFWebElement> confirmLiInstoreproducts;

	@FindBy(locator = "confirm.li.deliveryproducts")
	private List<QAFWebElement> confirmLiDeliveryproducts;

	@FindBy(locator = "confirm.lbl.giftcardamt")
	private QAFWebElement confirmLblGiftcardamt;

	@FindBy(locator = "confirm.txt.passwordsignup")
	private QAFWebElement confirmTxtPasswordsignup;

	@FindBy(locator = "confirm.txt.confirmpasswordsignup")
	private QAFWebElement confirmTxtConfirmpasswordsignup;

	@FindBy(locator = "confirm.btn.signup")
	private QAFWebElement confirmBtnSignup;
	
	@FindBy(locator = "confirm.lbl.signuperror")
	private QAFWebElement confirmLblSignuperror;
	
	@FindBy(locator = "confirm.txt.specialhandlingamount")
	private QAFWebElement confirmTxtSpecialhandlingamount;
	
	@FindBy(locator = "confirm.chk.savepaymentinfo")
	private QAFWebElement confirmChkSavepaymentinfo;

	/**
	 * TextView for confimation active title
	 */
	public QAFWebElement getConfirmLblActivetitle(){ return confirmLblActivetitle; }

	/**
	 * ButtonView for Continue Shopping
	 */
	public QAFWebElement getConfirmBtnContinueshopping(){ return confirmBtnContinueshopping; }

	/**
	 * TextView for Thank You
	 */
	public QAFWebElement getConfirmLblThankyou(){ return confirmLblThankyou; }

	/**
	 * TextView for Order Number
	 */
	public QAFWebElement getConfirmLblOrdernum(){ return confirmLblOrdernum; }

	/**
	 * TextView for Email id
	 */
	public QAFWebElement getConfirmLblEmailid(){ return confirmLblEmailid; }

	/**
	 * TextView for Check Out Title Ship To Home
	 */
	public QAFWebElement getConfirmLblShiptohome(){ return confirmLblShiptohome; }

	/**
	 * TextView for Check Out Title Delivery
	 */
	public QAFWebElement getConfirmLblDelivery(){ return confirmLblDelivery; }

	/**
	 * TextView for Check Out Title In Store Pick up
	 */
	public QAFWebElement getConfirmLblInstorepickup(){ return confirmLblInstorepickup; }

	/**
	 * ListView for products under Ship To Home
	 */
	public List<QAFWebElement> getConfirmLiSthproducts(){ return confirmLiSthproducts; }

	/**
	 * TextView for Items total under Ship to Home
	 */
	public QAFWebElement getConfirmLblItemstotal(){ return confirmLblItemstotal; }

	/**
	 * TextView for Order total amount
	 */
	public QAFWebElement getConfirmLblOrdertotalamt(){ return confirmLblOrdertotalamt; }

	/**
	 * TextView for Order Sub total amount
	 */
	public QAFWebElement getConfirmLblOrdersubtotalamt(){ return confirmLblOrdersubtotalamt; }

	/**
	 * TextView for Shipping amount
	 */
	public QAFWebElement getConfirmLblShippingamt(){ return confirmLblShippingamt; }

	/**
	 * TextView for Discount amount
	 */
	public QAFWebElement getConfirmLblDiscountamt(){ return confirmLblDiscountamt; }

	/**
	 * TextView for Estimated Tax amount
	 */
	public QAFWebElement getConfirmLblEstimatedtaxamt(){ return confirmLblEstimatedtaxamt; }

	/**
	 * TextView for Delivery fee amount
	 */
	public QAFWebElement getConfirmLblDeliveryfeeamt(){ return confirmLblDeliveryfeeamt; }

	/**
	 * ListView for Item total amount
	 */
	public List<QAFWebElement> getConfirmLiItemtotal(){ return confirmLiItemtotal; }

	/**
	 * TextView for total quantity
	 */
	public QAFWebElement getConfirmLblQuantity(){ return confirmLblQuantity; }

	/**
	 * ListView for products under In Store Pickup
	 */
	public List<QAFWebElement> getConfirmLiInstoreproducts(){ return confirmLiInstoreproducts; }

	/**
	 * ListView for products under Delivery
	 */
	public List<QAFWebElement> getConfirmLiDeliveryproducts(){ return confirmLiDeliveryproducts; }

	/**
	 * TextView for giftcard amount
	 */
	public QAFWebElement getConfirmLblGiftcardamt(){ return confirmLblGiftcardamt; }

	/**
	 * EditView for password for signup
	 */
	public QAFWebElement getConfirmTxtPasswordsignup(){ return confirmTxtPasswordsignup; }

	/**
	 * EditView for confirm password for signup
	 */
	public QAFWebElement getConfirmTxtConfirmpasswordsignup(){ return confirmTxtConfirmpasswordsignup; }

	/**
	 * ButtonView for signup
	 */
	public QAFWebElement getConfirmBtnSignup(){ return confirmBtnSignup; }
	
	public QAFWebElement getConfirmLblSignuperror(){ return confirmLblSignuperror; }
	
	public QAFWebElement getConfirmTxtSpecialhandlingamount(){ return confirmTxtSpecialhandlingamount; }
	
	public QAFWebElement getConfirmChkSavepaymentinfo(){ return confirmChkSavepaymentinfo; }
	
	

}