package com.automation.web.components;

import java.util.List;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MyRecipeboxItems extends QAFWebComponent {

	@FindBy(locator = "myrecipebox.lbl.recipenameslist")
	private QAFWebElement myrecipeboxLblRecipenameslist;
	@FindBy(locator = "myrecipebox.lbl.moreoptionslist")
	private QAFWebElement myrecipeboxLblMoreoptionslist;
	@FindBy(locator = "myrecipebox.lbl.deleterecipelist")
	private QAFWebElement myrecipeboxLblDeleterecipelist;

	@FindBy(locator = "myrecipebox.img.recipeimagelist")
	private QAFWebElement myrecipeboxImgRecipeimagelist;
	@FindBy(locator = "myrecipebox.img.recipestarslist")
	private QAFWebElement myrecipeboxImgRecipestarslist;
	@FindBy(locator = "myrecipebox.lnk.addtolist")
	private QAFWebElement myrecipeboxLnkAddtolist;
	@FindBy(locator = "myrecipebox.lnk.printrecipelist")
	private QAFWebElement myrecipeboxLnkPrintrecipelist;

	@FindBy(locator = "myrecipebox.lbl.moverecipeslist")
	private QAFWebElement lblMoverecipeslist;

	@FindBy(locator = "myrecipebox.lbl.moverecipeboxnameslist")
	private List<QAFWebElement> lblMoverecipeboxnameslist;

	@FindBy(locator = "myrecipebox.lbl.moverecipeboxdessert")
	private QAFWebElement lblMoverecipeboxdessert;

	public MyRecipeboxItems(String locator) {
		super(locator);
	}

	public QAFWebElement getLblRecipenameslist() {
		return myrecipeboxLblRecipenameslist;
	}

	public QAFWebElement getLblMoreoptionslist() {
		return myrecipeboxLblMoreoptionslist;
	}

	public QAFWebElement getLblDeleterecipelist() {
		return myrecipeboxLblDeleterecipelist;
	}

	public QAFWebElement getImgRecipeimagelist() {
		return myrecipeboxImgRecipeimagelist;
	}

	public QAFWebElement getImgRecipestarslist() {
		return myrecipeboxImgRecipestarslist;
	}

	public QAFWebElement getLnkAddtolist() {
		return myrecipeboxLnkAddtolist;
	}

	public QAFWebElement getLnkPrintrecipelist() {
		return myrecipeboxLnkPrintrecipelist;
	}

	public QAFWebElement getLblMoverecipeslist() {
		return lblMoverecipeslist;
	}

	public List<QAFWebElement> getLblMoverecipeboxnameslist() {
		return lblMoverecipeboxnameslist;
	}

	public QAFWebElement getLblMoverecipeboxdessert() {
		return lblMoverecipeboxdessert;
	}

}
