package com.automation.web.pages.checkout;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class PickupdetailsTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "pickupdetails.lbl.pickupdetailsheader")
	private QAFWebElement pickupdetailsLblPickupdetailsheader;

	@FindBy(locator = "pickupdetails.lbl.pickuplocation")
	private QAFWebElement pickupdetailsLblPickuplocation;

	@FindBy(locator = "pickupdetails.lbl.enterpickupdetails")
	private QAFWebElement pickupdetailsLblEnterpickupdetails;

	@FindBy(locator = "pickupdetails.lbl.pickuplocationname")
	private QAFWebElement pickupdetailsLblPickuplocationname;

	@FindBy(locator = "pickupdetails.lbl.selectdatevalue")
	private QAFWebElement pickupdetailsLblSelectdatevalue;

	@FindBy(locator = "pickupdetails.img.selectdate")
	private QAFWebElement pickupdetailsImgSelectdate;

	@FindBy(locator = "pickupdetails.txt.selectdate")
	private QAFWebElement pickupdetailsTxtSelectdate;

	@FindBy(locator = "pickupdetails.get.txt.selecttimevaluedynamic")
	private QAFWebElement pickupdetailsGetTxtSelecttimevaluedynamic;

	@FindBy(locator = "pickupdetails.btn.continue")
	private QAFWebElement pickupdetailsBtnContinue;

	@FindBy(locator = "pickupdetails.lbl.instorepickup")
	private QAFWebElement pickupdetailsLblInstorepickup;

	@FindBy(locator = "pickupdetails.lbl.instorepickupqty")
	private QAFWebElement pickupdetailsLblInstorepickupqty;

	@FindBy(locator = "pickupdetails.lbl.nextmonthcalendar")
	private QAFWebElement pickupdetailsLblNextmonthcalendar;

	/**
	 * TextView for pickup details tab header
	 */
	public QAFWebElement getPickupdetailsLblPickupdetailsheader(){ return pickupdetailsLblPickupdetailsheader; }

	/**
	 * TextView for pickup location
	 */
	public QAFWebElement getPickupdetailsLblPickuplocation(){ return pickupdetailsLblPickuplocation; }

	/**
	 * TextView for please enter pickup details
	 */
	public QAFWebElement getPickupdetailsLblEnterpickupdetails(){ return pickupdetailsLblEnterpickupdetails; }

	/**
	 * TextView for pickup location name
	 */
	public QAFWebElement getPickupdetailsLblPickuplocationname(){ return pickupdetailsLblPickuplocationname; }

	/**
	 * TextView for select date value
	 */
	public QAFWebElement getPickupdetailsLblSelectdatevalue(){ return pickupdetailsLblSelectdatevalue; }

	/**
	 * ImageView for select date
	 */
	public QAFWebElement getPickupdetailsImgSelectdate(){ return pickupdetailsImgSelectdate; }

	/**
	 * EditView for select date
	 */
	public QAFWebElement getPickupdetailsTxtSelectdate(){ return pickupdetailsTxtSelectdate; }

	/**
	 * TextView for select time value
	 */
	public QAFWebElement getPickupdetailsGetTxtSelecttimevaluedynamic(String item){ 
		String retElm = String.format(pageProps.getString("pickupdetails.get.txt.selecttimevaluedynamic"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * ButtonView for continue
	 */
	public QAFWebElement getPickupdetailsBtnContinue(){ return pickupdetailsBtnContinue; }

	/**
	 * TextView for in-store pickup
	 */
	public QAFWebElement getPickupdetailsLblInstorepickup(){ return pickupdetailsLblInstorepickup; }

	/**
	 * TextView for in-store pickup items quantity
	 */
	public QAFWebElement getPickupdetailsLblInstorepickupqty(){ return pickupdetailsLblInstorepickupqty; }

	/**
	 * TextView for next month
	 */
	public QAFWebElement getPickupdetailsLblNextmonthcalendar(){ return pickupdetailsLblNextmonthcalendar; }

}