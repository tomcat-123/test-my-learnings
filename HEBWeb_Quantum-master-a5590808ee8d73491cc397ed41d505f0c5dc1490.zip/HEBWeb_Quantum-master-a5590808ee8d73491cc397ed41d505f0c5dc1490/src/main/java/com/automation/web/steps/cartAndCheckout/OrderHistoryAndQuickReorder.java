package com.automation.web.steps.cartAndCheckout;

import java.util.List;

import org.openqa.selenium.Alert;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.components.QuickReorderProducts;
import com.automation.web.pages.cart.CartTestPage;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.orderhistory.OrderhistoryTestPage;
import com.automation.web.pages.orderhistory.OrderstatusTestPage;
import com.automation.web.pages.quickreorder.QuickReorderTestPage;
import com.automation.web.steps.cartAndCheckout.CartAndCheckout;
import com.automation.web.steps.homepage.HomePage;
import com.automation.web.steps.myaccount.myaccountpage;
import com.automation.web.steps.paymentgateway.PaymentGatewayStepdef;
import com.automation.web.steps.search.PdtsearchresultPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

/*List of steps in OrderHistoryAndQuickReorder

* Remove all the PGCs from cart page
* Navigate to order history page by mouse hover on Cart Icon
* I add PGC to Cart from order history page
* Verify the added PGC available in Cart page
* Navigate to Quick reorder page by mouse over on Cart icon
* I add PGC to Cart from reorder page
* I verify user is able to enter four digits in quantity box of gift cards
* I verify whether system throws an error when user give zero as the quantity
* I verify user able to add to the cart with min order quantity
* I Verify Cake and Gift Card Items in Quick reorder page
* I verify Floral Items not displayed in quick reorder page

*/

public class OrderHistoryAndQuickReorder {

	@QAFTestStep(description = "Remove all the PGCs from cart page")
	public void removeAllThePGCsFromCartPage() {
		OrderhistoryTestPage orderhistory = new OrderhistoryTestPage();

		CartAndCheckout.iNavigateToCartBySelectingViewCartInCartMouseoverOption();

		List<QAFWebElement> allLinks = orderhistory.getLnkRemove();
		int linkCount = allLinks.size();
		System.out.println(linkCount);
		for (QAFWebElement elmLink : allLinks) {
			elmLink.waitForPresent(5000);
			elmLink.click();
			PerfectoUtils.reportMessage("Clicked on Remove link..", MessageTypes.Pass);
			if (orderhistory.getLblYesrmvprodalert().isPresent()) {
				PerfectoUtils.reportMessage("Alert YES is present..", MessageTypes.Pass);
				orderhistory.getLblYesrmvprodalert().click();
			} else {
				PerfectoUtils.reportMessage("Alert YES is not present..", MessageTypes.Fail);
			}
		}

	}

	@QAFTestStep(description = "Navigate to order history page by mouse hover on Cart Icon")
	public void navigateToOrderHistoryPageByMouseHoverOnCartIcon() {
		InStoreHomePage instore = new InStoreHomePage();

		try {
			PerfectoUtils.mouseoverandclick(instore.getHomeImgCart(), instore.getBtnCartorderhistory());
			PerfectoUtils.reportMessage("Clicked on Order history..", MessageTypes.Pass);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured while clicking on Order history..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I add PGC to Cart from order history page")
	public void iAddPGCToCartFromOrderHistoryPage() {
		OrderhistoryTestPage orderhistory = new OrderhistoryTestPage();

		int viewDetailsSize = orderhistory.getLnkViewdetailswithaddtocart().size();

		if (viewDetailsSize > 0) {
			PerfectoUtils.reportMessage(viewDetailsSize + " Orders found with Add to Cart button..", MessageTypes.Pass);

			// Clicking on View details
			PerfectoUtils.scrolltoelement(orderhistory.getLnkViewdetailswithaddtocart().get(0));
			orderhistory.getLnkViewdetailswithaddtocart().get(0).click();
			PerfectoUtils.reportMessage("Clicked on View details..", MessageTypes.Pass);

			// CLicking on Add to cart button
			PerfectoUtils.scrolltoelement(orderhistory.getBtnAddtocartinsideviewdetails().get(0));
			orderhistory.getBtnAddtocartinsideviewdetails().get(0).click();
			PerfectoUtils.reportMessage("Clicked on Add to cart button..", MessageTypes.Pass);

		} else {
			PerfectoUtils.reportMessage("No Order found with Add to Cart button..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify the added PGC available in Cart page")
	public void verifyTheAddedPGCAvailableInCartPage() {
		CartTestPage cart = new CartTestPage();

		CartAndCheckout.iNavigateToCartBySelectingViewCartInCartMouseoverOption();

		if (cart.getCartLblPhysicalgiftcardname().isPresent())
			PerfectoUtils.reportMessage("PGC is available in Cart..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("PGC is not available in Cart..", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I navigate to Quick reorder page by mouse over on cart icon")
	public void navigateToQuickReorderPageByMouseOverOnCartIcon() {
		QuickReorderTestPage quickreorder = new QuickReorderTestPage();
		InStoreHomePage homepage = new InStoreHomePage();

		try {
			PerfectoUtils.mouseoverandclick(homepage.getHomeImgCart(), quickreorder.getQuickreorderBtnCart());
			PerfectoUtils.reportMessage("Clicked on Quick Reorder..", MessageTypes.Pass);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured while clicking on Quick Reorder..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I add PGC to Cart from reorder page")
	public void iaddPGCToCartFromReorderPage() {
		QuickReorderTestPage quickreorder = new QuickReorderTestPage();

		quickreorder.getBtnaddtocart().waitForPresent(5000);
		PerfectoUtils.scrolltoelement(quickreorder.getBtnaddtocart());

		// Clicking on Add to cart button
		if (quickreorder.getBtnaddtocart().isPresent()) {
			quickreorder.getBtnaddtocart().click();
			PerfectoUtils.reportMessage("Clicked on Add to cart button..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("No Order found with Add to Cart button..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I add MOQ products from Quick reorder page")
	public void iAddMOQProductsFromQuickReorderPage() {
		QuickReorderTestPage quickreorder = new QuickReorderTestPage();
		String addedItem = getBundle().getString("addedItem");
		boolean isProductFound = false;

		for (QuickReorderProducts quickreoderProd : quickreorder.getQuickreorderBoxProduct()) {

			quickreoderProd.getQuickreorderLblProductname().verifyPresent();

			if (PerfectoUtils.removeSpecialCharacters(addedItem).contains(
					PerfectoUtils.removeSpecialCharacters(quickreoderProd.getQuickreorderLblProductname().getText()))) {
				if (quickreoderProd.getQuickreorderLblCartblock().getText().contains("Minimum")) {
					quickreoderProd.getQuickreorderLblAddtocart().verifyPresent();
					quickreoderProd.getQuickreorderLblAddtocart().click();
				}
				isProductFound = true;
			} else {
				isProductFound = true;
			}

		}

		if (!isProductFound)
			PerfectoUtils.reportMessage("Product is not found in Quick reorder page", MessageTypes.Fail);
	}

	
	@QAFTestStep(description = "I verify user is able to enter four digits in quantity box of gift cards")
	public void iVerifyUserabletoenter4digitsinquantityboxofgiftcards() {
		QuickReorderTestPage quickreorder = new QuickReorderTestPage();
		
		if(quickreorder.getLblProductName().getText().contains(ConfigurationManager.getBundle().getString("quickreorder.PGCproductname"))){
			PerfectoUtils.reportMessage("PGC is getting displayed in the quick reorder section", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("PGC is not getting displayed in the quick reorder section", MessageTypes.Fail);
		}
		
		quickreorder.getTxtQuantity().verifyPresent();
		quickreorder.getTxtQuantity().sendKeys("1000");
		quickreorder.getBtnaddtocart().click();
		PerfectoUtils.reportMessage("Clicked on Add to cart button..", MessageTypes.Pass);
		if(quickreorder.getLblItemqty().getText().equals("1000")){
			PerfectoUtils.reportMessage("User able to add to the cart with 4 digit order quantity", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("User not able to add to the cart with 4 digit order quantity", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I verify whether system throws an error when user give zero as the quantity")
	public void iVerifysystemthrowserrorwhenuserenter0inquantityboxofgiftcards() {
		QuickReorderTestPage quickreorder = new QuickReorderTestPage();
		
		if(quickreorder.getLblProductName().getText().contains(ConfigurationManager.getBundle().getString("quickreorder.PGCproductname"))){
			PerfectoUtils.reportMessage("PGC is getting displayed in the quick reorder section", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("PGC is not getting displayed in the quick reorder section", MessageTypes.Fail);
		}
		
		quickreorder.getTxtQuantity().verifyPresent();
		quickreorder.getTxtQuantity().clear();
		quickreorder.getTxtQuantity().sendKeys("0");
		quickreorder.getBtnaddtocart().click();
		Alert alert = PerfectoUtils.getDriver().switchTo().alert();
		String errormsg = alert.getText();
		if(errormsg.equals(ConfigurationManager.getBundle().getString("quickreorder.quantity0errormsg"))){
			PerfectoUtils.reportMessage("System throws an error message when user give zero as the quantity", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("System not throws an error message when user give zero as the quantity", MessageTypes.Fail);
		}
		
		alert.accept();
	}
	
	@QAFTestStep(description = "I verify user able to add to the cart with min order quantity")
	public void iVerifyuseraddtothecartwithminquantity() {
		QuickReorderTestPage quickreorder = new QuickReorderTestPage();
		
		quickreorder.getTxtQuantity().verifyPresent();
		quickreorder.getTxtQuantity().sendKeys("1");
		quickreorder.getBtnaddtocart().click();
		PerfectoUtils.reportMessage("Clicked on Add to cart button..", MessageTypes.Pass);
		if(quickreorder.getLblItemqty().getText().equals("1")){
			PerfectoUtils.reportMessage("User able to add to the cart with min order quantity", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("User not able to add to the cart with min order quantity", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I Verify Cake and Gift Card Items in Quick reorder page")
	public void iVerifyCakeandGiftCardItemsinQuickreorderpage() {
		QuickReorderTestPage quickreorder = new QuickReorderTestPage();
		
		quickreorder.getLblSTH().verifyPresent();
		quickreorder.getLblPGC().verifyPresent();
		quickreorder.getLblCake().verifyPresent();
	}
	
	@QAFTestStep(description = "I verify Floral Items not displayed in quick reorder page")
	public void iVerifyFloralItemsnotDisplayedinquickreorderpage() throws Exception {
		QuickReorderTestPage quickreorder = new QuickReorderTestPage();
		PdtsearchresultPage pdp = new PdtsearchresultPage();
		CartAndCheckout cart = new CartAndCheckout();
		PaymentGatewayStepdef pay = new PaymentGatewayStepdef();
		HomePage homepage = new HomePage();
		myaccountpage acc = new myaccountpage();
		
		pdp.iNavigateToCartPage();
		cart.iCheckOutTheProduct();
		cart.iCheckoutTheItemsAsAHotUser();
		cart.iMakeThePaymentsWithCreditCard();
		cart.iVerifyTheOrderConfirmationPage();
		pay.selectContinueShoppingOptionFromOrderConfirmationPage();
		homepage.iNavigateToInstoreHomePage();
		acc.iNavigatetoQuickReorderpage();
		if (quickreorder.getLblProductName().isPresent()) {
			PerfectoUtils.reportMessage("User able to reorder delivery and in store pickup Floral Items",
					MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("User cannot able to reorder delivery and in store pickup Floral Items",
					MessageTypes.Pass);
		}
	}
	
	@QAFTestStep(description = "I add MOQ product to cart from Order History page")
	public void iAddMOQProductToCartFromOrderHistoryPage() {
		OrderhistoryTestPage orderhistory = new OrderhistoryTestPage();
		CartTestPage cartpage = new CartTestPage();

		orderhistory.getLnkViewDetails().waitForPresent(5000);
	    orderhistory.getLnkViewDetails().click();
	    orderhistory.getLnkReorderItm().click();
	    cartpage.getLblMinqty().waitForPresent(5000);
	    cartpage.getLblMinqty().verifyPresent();
	}	
	
	@QAFTestStep(description = "I verify user is able to cancel the products")
	public synchronized void iVerifyUserabletocanceltheproducts() {
		OrderhistoryTestPage orderhistory = new OrderhistoryTestPage();
		
		orderhistory.getOdrhistoryBtnCancelproducts().click();
		orderhistory.getOdrhistoryTxtCancelorderpopup().waitForPresent(5000);
		orderhistory.getOdrhistoryBtnYescancelorder().click();
	}
	
	@QAFTestStep(description = "I add product to cart from Quick reorder page")
	public void iAddProductToCartFromQuickReorderPage() {
		QuickReorderTestPage quickreorder = new QuickReorderTestPage();
		
		quickreorder.getBtnaddtocart().verifyPresent();
		getBundle().setProperty("AddedProduct", quickreorder.getLblProductName().getText());
		quickreorder.getBtnaddtocart().click();
	}
	
	@QAFTestStep(description = "I add product to cart from Order History page")
	public void iAddProductToCartFromOrderHistoryPage() {
		OrderhistoryTestPage orderhistory = new OrderhistoryTestPage();
		
		orderhistory.getLnkViewDetails().verifyPresent();
		orderhistory.getLnkViewDetails().click();
		orderhistory.getOdrhistoryLnkItemname1().verifyPresent();
		orderhistory.getOdrhistoryBtnAddtocart().verifyPresent();
		getBundle().setProperty("AddedProduct", orderhistory.getOdrhistoryLnkItemname1().getText());
		orderhistory.getOdrhistoryBtnAddtocart().click();
	}
	
	@QAFTestStep(description = "I validate the order status page properties")
	public void iValidateTheOrderStatusPageProperties () {
		OrderstatusTestPage orderstatus = new OrderstatusTestPage();
		
		orderstatus.getOrderstatusLblBreadcrumb().verifyPresent();
		orderstatus.getOrderstatusLblHeader().verifyPresent();
		orderstatus.getOrderstatusEdtEmailaddress().verifyPresent();
		orderstatus.getOrderstatusEdtOrderConfirNum().verifyPresent();
		orderstatus.getOrderstatusLnkWhereismyorderconfi().verifyPresent();
		orderstatus.getOrderstatusBtnSubmit().verifyPresent();
		orderstatus.getOrderstatusLnkCancel().verifyPresent();
	}
}
