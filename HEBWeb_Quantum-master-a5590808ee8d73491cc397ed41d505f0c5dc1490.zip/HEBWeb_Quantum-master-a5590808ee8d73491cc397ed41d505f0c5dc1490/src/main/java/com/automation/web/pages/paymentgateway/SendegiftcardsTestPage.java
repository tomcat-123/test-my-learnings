package com.automation.web.pages.paymentgateway;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SendegiftcardsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "sendegiftcards.lbl.pageheader")
	private QAFWebElement lblPageheader;
	@FindBy(locator = "sendegiftcards.lbl.sendegiftcard")
	private QAFWebElement lblSendegiftcard;
	@FindBy(locator = "sendegiftcards.lbl.requiredfields")
	private QAFWebElement lblRequiredfields;
	@FindBy(locator = "sendegiftcards.lbl.brand")
	private QAFWebElement lblBrand;
	@FindBy(locator = "sendegiftcards.txt.brand")
	private QAFWebElement txtBrand;
	@FindBy(locator = "sendegiftcards.lbl.to")
	private QAFWebElement lblTo;
	@FindBy(locator = "sendegiftcards.txt.to")
	private QAFWebElement txtTo;
	@FindBy(locator = "sendegiftcards.lbl.recipientemail")
	private QAFWebElement lblRecipientemail;
	@FindBy(locator = "sendegiftcards.txt.recipientemail")
	private QAFWebElement txtRecipientemail;
	@FindBy(locator = "sendegiftcards.lbl.from")
	private QAFWebElement lblFrom;
	@FindBy(locator = "sendegiftcards.txt.from")
	private QAFWebElement txtFrom;
	@FindBy(locator = "sendegiftcards.lbl.amount")
	private QAFWebElement lblAmount;
	@FindBy(locator = "sendegiftcards.txt.amount")
	private QAFWebElement txtAmount;
	@FindBy(locator = "sendegiftcards.txt.amountvalues")
	private List<QAFWebElement> txtAmountvalues;
	@FindBy(locator = "sendegiftcards.lbl.message")
	private QAFWebElement lblMessage;
	@FindBy(locator = "sendegiftcards.txt.message")
	private QAFWebElement txtMessage;
	@FindBy(locator = "sendegiftcards.lnk.termsandconditions")
	private QAFWebElement lnkTermsandconditions;
	@FindBy(locator = "sendegiftcards.btn.addtocart")
	private QAFWebElement sendegiftcardsBtnAddtocart;
	@FindBy(locator = "sendegiftcards.lbl.reenterrecipientemail")
	private QAFWebElement lblReenterrecipientemail;
	@FindBy(locator = "sendegiftcards.txt.reenterrecipientemail")
	private QAFWebElement txtReenterrecipientemail;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblPageheader() {
		return lblPageheader;
	}

	public QAFWebElement getLblSendegiftcard() {
		return lblSendegiftcard;
	}

	public QAFWebElement getLblRequiredfields() {
		return lblRequiredfields;
	}

	public QAFWebElement getLblBrand() {
		return lblBrand;
	}

	public QAFWebElement getTxtBrand() {
		return txtBrand;
	}

	public QAFWebElement getLblTo() {
		return lblTo;
	}

	public QAFWebElement getTxtTo() {
		return txtTo;
	}

	public QAFWebElement getLblRecipientemail() {
		return lblRecipientemail;
	}

	public QAFWebElement getTxtRecipientemail() {
		return txtRecipientemail;
	}

	public QAFWebElement getLblFrom() {
		return lblFrom;
	}

	public QAFWebElement getTxtFrom() {
		return txtFrom;
	}

	public QAFWebElement getLblAmount() {
		return lblAmount;
	}

	public QAFWebElement getTxtAmount() {
		return txtAmount;
	}

	public List<QAFWebElement> getTxtAmountvalues() {
		return txtAmountvalues;
	}

	public QAFWebElement getLblMessage() {
		return lblMessage;
	}

	public QAFWebElement getTxtMessage() {
		return txtMessage;
	}

	public QAFWebElement getLnkTermsandconditions() {
		return lnkTermsandconditions;
	}

	public QAFWebElement getBtnAddtocart() {
		return sendegiftcardsBtnAddtocart;
	}

	public QAFWebElement getLblReenterrecipientemail() {
		return lblReenterrecipientemail;
	}

	public QAFWebElement getTxtReenterrecipientemail() {
		return txtReenterrecipientemail;
	}

}
