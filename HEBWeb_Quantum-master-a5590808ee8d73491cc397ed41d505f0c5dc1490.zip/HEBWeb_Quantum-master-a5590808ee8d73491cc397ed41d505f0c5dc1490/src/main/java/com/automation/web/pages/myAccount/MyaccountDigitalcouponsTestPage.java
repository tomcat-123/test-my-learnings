package com.automation.web.pages.myAccount;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MyaccountDigitalcouponsTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "myacccoup.lbl.header")
	private QAFWebElement myacccoupLblHeader;

	@FindBy(locator = "myacccoup.lbl.mobilestatus")
	private QAFWebElement myacccoupLblMobilestatus;

	@FindBy(locator = "myacccoup.edt.mobileno1")
	private QAFWebElement myacccoupEdtMobileno1;

	@FindBy(locator = "myacccoup.edt.mobileno2")
	private QAFWebElement myacccoupEdtMobileno2;

	@FindBy(locator = "myacccoup.edt.mobileno3")
	private QAFWebElement myacccoupEdtMobileno3;

	@FindBy(locator = "myacccoup.lbl.getoffersbytext")
	private QAFWebElement myacccoupLblGetoffersbytext;

	@FindBy(locator = "myacccoup.chk.getoffersbytext")
	private QAFWebElement myacccoupChkGetoffersbytext;

	@FindBy(locator = "myacccoup.lbl.createaltid")
	private QAFWebElement myacccoupLblCreatealtid;

	@FindBy(locator = "myacccoup.chk.createaltid")
	private QAFWebElement myacccoupChkCreatealtid;

	@FindBy(locator = "myacccoup.btn.save")
	private QAFWebElement myacccoupBtnSave;

	@FindBy(locator = "myacccoup.edt.pin")
	private QAFWebElement myacccoupEdtPin;

	/**
	 * Text Header Digital coupons
	 */
	public QAFWebElement getMyacccoupLblHeader(){ return myacccoupLblHeader; }

	/**
	 * Text of Mobile status
	 */
	public QAFWebElement getMyacccoupLblMobilestatus(){ return myacccoupLblMobilestatus; }

	/**
	 * EditText of Mobile Number 1
	 */
	public QAFWebElement getMyacccoupEdtMobileno1(){ return myacccoupEdtMobileno1; }

	/**
	 * EditText of Mobile Number 2
	 */
	public QAFWebElement getMyacccoupEdtMobileno2(){ return myacccoupEdtMobileno2; }

	/**
	 * EditText of Mobile Number 3
	 */
	public QAFWebElement getMyacccoupEdtMobileno3(){ return myacccoupEdtMobileno3; }

	/**
	 * TextView of Get offers by Text
	 */
	public QAFWebElement getMyacccoupLblGetoffersbytext(){ return myacccoupLblGetoffersbytext; }

	/**
	 * CheckBoxView of Get offers by Text
	 */
	public QAFWebElement getMyacccoupChkGetoffersbytext(){ return myacccoupChkGetoffersbytext; }

	/**
	 * TextView of Create Alternate id
	 */
	public QAFWebElement getMyacccoupLblCreatealtid(){ return myacccoupLblCreatealtid; }

	/**
	 * CheckBoxView of Create Alternate id
	 */
	public QAFWebElement getMyacccoupChkCreatealtid(){ return myacccoupChkCreatealtid; }

	/**
	 * ButtonView of Save
	 */
	public QAFWebElement getMyacccoupBtnSave(){ return myacccoupBtnSave; }

	/**
	 * EditText of 4 digit pin
	 */
	public QAFWebElement getMyacccoupEdtPin(){ return myacccoupEdtPin; }

}