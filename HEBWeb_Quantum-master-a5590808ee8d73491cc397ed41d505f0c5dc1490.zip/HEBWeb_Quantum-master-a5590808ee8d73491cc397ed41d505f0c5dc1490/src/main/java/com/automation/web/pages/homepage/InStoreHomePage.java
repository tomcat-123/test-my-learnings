package com.automation.web.pages.homepage;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class InStoreHomePage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "home.lnk.login")
	private QAFWebElement homeLblLogin;

	@FindBy(locator = "home.lnk.loginmobile")
	private QAFWebElement homeLblLoginMobile;

	@FindBy(locator = "home.btn.logoutmobile")
	private QAFWebElement homeBtnLogoutmobile;

	@FindBy(locator = "home.lnk.humburgermobile")
	private QAFWebElement homeLnkHumburgermobile;

	@FindBy(locator = "home.lbl.userdetail")
	private QAFWebElement homeLblUserdetail;

	@FindBy(locator = "home.lbl.userdetailmobile")
	private QAFWebElement homeLblUserdetailmobile;

	@FindBy(locator = "home.lbl.foodndrinks")
	private QAFWebElement homeLblFoodndrinks;

	@FindBy(locator = "home.lbl.homenkitchen")
	private QAFWebElement homeLblHomenkitchen;

	@FindBy(locator = "home.lbl.megamenubar")
	private QAFWebElement homeLblMegamenubar;

	@FindBy(locator = "home.li.megamenulbl")
	private List<QAFWebElement> homeListMegamenulbl;

	@FindBy(locator = "home.lbl.megamenutitle")
	private QAFWebElement homeLblMegamenutitle;

	@FindBy(locator = "home.lbl.foodndrinksubmenu")
	private List<QAFWebElement> homeLblFoodndrinksubmenu;

	@FindBy(locator = "home.img.rightarrow")
	private QAFWebElement homeImgRightarrow;

	@FindBy(locator = "home.img.leftarrow")
	private QAFWebElement homeImgLeftarrow;

	@FindBy(locator = "home.lbl.coruselbox")
	private QAFWebElement homeLblCoruselbox;

	@FindBy(locator = "home.lbl.homenkitchenmenu")
	private List<QAFWebElement> homeLblHomenkitchenmenu;

	@FindBy(locator = "home.lbl.baby")
	private QAFWebElement homeLblBaby;

	@FindBy(locator = "home.lbl.babyntoy")
	private List<QAFWebElement> homeLblBabyntoy;

	@FindBy(locator = "home.lbl.healthnbeauty")
	private List<QAFWebElement> homeLblHealthnbeauty;

	@FindBy(locator = "home.lbl.outdoornsports")
	private List<QAFWebElement> homeLblOutdoornSports;

	@FindBy(locator = "home.lbl.officeandschool")
	private List<QAFWebElement> homeLblOfficeandschool;

	@FindBy(locator = "home.lbl.flowers")
	private List<QAFWebElement> homeLblFlowers;

	@FindBy(locator = "home.lbl.more")
	private List<QAFWebElement> homeLblMore;

	@FindBy(locator = "home.lbl.petsubmenu")
	private List<QAFWebElement> homeLblPetsubmenu;

	@FindBy(locator = "home.lbl.headerpharmacy")
	private QAFWebElement homeLblHeaderpharmacy;

	@FindBy(locator = "home.lbl.headerweeklyad")
	private QAFWebElement homeLblHeaderweeklyad;

	@FindBy(locator = "home.lnk.weeklyadmobile")
	private QAFWebElement homeLnkWeeklyadmobile;

	@FindBy(locator = "home.lbl.headerrecipe")
	private QAFWebElement homeLblHeaderrecipe;

	@FindBy(locator = "home.lbl.mystore")
	private QAFWebElement homeLblMystore;

	@FindBy(locator = "home.lbl.myaccount")
	private QAFWebElement homeLblMyaccount;

	@FindBy(locator = "home.lbl.giftcard")
	private QAFWebElement homeLblGiftcard;

	@FindBy(locator = "home.lbl.moreoption")
	private QAFWebElement homeLblMoreoption;

	@FindBy(locator = "home.lbl.orderstatus")
	private QAFWebElement homeLblOrderstatus;

	@FindBy(locator = "home.lbl.weeklyadandcoupons")
	private QAFWebElement homeLblWeeklyadandcoupons;

	@FindBy(locator = "home.lbl.digitalcoupons")
	private QAFWebElement homeLblDigitalcoupons;

	@FindBy(locator = "home.lnk.mylist")
	private QAFWebElement homeLnkMylist;

	@FindBy(locator = "home.img.cart")
	private QAFWebElement homeImgCart;

	@FindBy(locator = "home.lis.onlinecoruselname")
	private List<QAFWebElement> homeListOnlinecoruselname;

	@FindBy(locator = "home.img.rightarrowonline")
	private QAFWebElement homeImgRightarrowonline;

	@FindBy(locator = "home.lbl.orderonline")
	private QAFWebElement homeLblOrderonline;

	@FindBy(locator = "home.btn.selectdigitalcoupons")
	private QAFWebElement homeBtnSelectdigitalcoupons;

	@FindBy(locator = "home.lbl.digitalcouponsname")
	private QAFWebElement homeLblDigitalcouponsname;

	@FindBy(locator = "home.lbl.watchvideocoupins")
	private QAFWebElement homeLblWatchvideocoupins;

	@FindBy(locator = "home.lbl.loadmorerecipe")
	private QAFWebElement homeLblLoadmorerecipe;

	@FindBy(locator = "home.li.receipename")
	private List<QAFWebElement> homeLiReceipename;

	@FindBy(locator = "home.lbl.username")
	private QAFWebElement homeLblUsername;

	@FindBy(locator = "home.edt.searchtext")
	private QAFWebElement homeEdtSearchtext;

	@FindBy(locator = "home.btn.search")
	private QAFWebElement homeBtnSearch;

	@FindBy(locator = "home.lbl.register")
	private QAFWebElement homeLblRegister;

	@FindBy(locator = "home.btn.cart")
	private QAFWebElement homeBtnCart;

	@FindBy(locator = "home.btn.cartmobile")
	private QAFWebElement homeBtnCartMobile;

	@FindBy(locator = "home.btn.cartstartshopping")
	private QAFWebElement homeBtnCartstartshopping;

	@FindBy(locator = "home.btn.cartitem")
	private List<QAFWebElement> homeBtnCartitem;

	@FindBy(locator = "home.btn.cartviewcart")
	private QAFWebElement homeBtnCartviewcart;

	@FindBy(locator = "home.btn.breadcrumbshop")
	private QAFWebElement homeBtnBreadcrumbshop;

	@FindBy(locator = "home.lbl.storename")
	private QAFWebElement homeLblStorename;

	@FindBy(locator = "home.logo")
	private QAFWebElement homeLogo;

	@FindBy(locator = "home.lbl.shoppinglistfromheader")
	private QAFWebElement homeLblShoppinglistfromheader;

	@FindBy(locator = "home.lnk.createaccountfromshoppinglist")
	private QAFWebElement homeLnkCreateaccountfromshoppinglist;

	
	
	@FindBy(locator = "home.lnk.ialreadyhaveaccount")
	private QAFWebElement homeLnkIalreadyhaveaccount;
	
	@FindBy(locator = "home.lnk.createanewlist")
	private QAFWebElement homeLnkCreateanewlist;
	
	@FindBy(locator = "home.lnk.mylists")
	private QAFWebElement homeLnkMylists;
			
	

	@FindBy(locator = "home.lnk.healthnwellness")
	private QAFWebElement homeLnkHealthnwellness;

	@FindBy(locator = "home.lnk.pharmacy")
	private QAFWebElement homeLnkPharmacy;

	@FindBy(locator = "home.btn.cartquickreorder")
	private QAFWebElement homeBtnCartquickreorder;

	@FindBy(locator = "home.btn.breadcrumbcustomcakes")
	private QAFWebElement homeBtnBreadcrumbcustomcakes;

	@FindBy(locator = "home.ourbrand.lnk.shohebselectingredients")
	private QAFWebElement homeOurbrandLnkShohebselectingredients;

	@FindBy(locator = "home.lnk.ourbrands")
	private QAFWebElement homeLnkOurbrands;

	@FindBy(locator = "home.ourbrand.lbl.pagetitle")
	private QAFWebElement homeOurbrandLblPagetitle;

	@FindBy(locator = "home.lnk.changeshopping")
	private QAFWebElement homeLnkChangeshopping;

	@FindBy(locator = "home.img.myaccount")
	private QAFWebElement homeImgMyaccount;
	
	@FindBy(locator = "home.txt.searchField")
	private QAFWebElement txtSearchField;

	@FindBy(locator = "home.lis.submenu")
	private List<QAFWebElement> homeListSubmenu;

	@FindBy(locator = "home.txt.orderstatus")
	private QAFWebElement TxtOrderStatus;

	@FindBy(locator = "home.edt.ordernumber")
	private QAFWebElement EdtOrderNumber;

	@FindBy(locator = "home.edt.emailaddress")
	private QAFWebElement EdtEmailAddress;

	@FindBy(locator = "home.btn.ordersubmit")
	private QAFWebElement BtnOrderSubmit;

	@FindBy(locator = "home.txt.orderstatuserror")
	private QAFWebElement TxtOrderStatusError;

	@FindBy(locator = "home.lnk.myaddedlist")
	private List<QAFWebElement> homelnkmyaddedlist;

	@FindBy(locator = "home.lnk.hebonline")
	private QAFWebElement lnkHebonline;

	@FindBy(locator = "home.lnk.changemypreferredstore")
	private QAFWebElement lnkChangemypreferredstore;

	@FindBy(locator = "home.lnk.flowersmegamenu")
	private QAFWebElement lnkFlowersMegamenu;

	@FindBy(locator = "home.txt.searchFieldSmall")
	private QAFWebElement txtSearchFieldSmall;

	@FindBy(locator = "home.btn.cartorderhistory")
	private QAFWebElement btnCartorderhistory;

	@FindBy(locator = "home.li.cartflyoutitemslist")
	private List<QAFWebElement> liCartflyoutitemslist;
	
	@FindBy(locator = "home.li.cartflyoutitemscountlist")
	private List<QAFWebElement> liCartflyoutitemsCountlist;
	
	@FindBy(locator = "home.lbl.cartzeroitem")
	private QAFWebElement lblCartZeroItem;
	
	@FindBy(locator = "home.lbl.cartnoitems")
	private QAFWebElement lblCartNoItems;
	
	@FindBy(locator = "home.lbl.cartflyoutitemstotalcountlist")
	private QAFWebElement lblCartflyoutitemstotalcountlist;
	
	@FindBy(locator = "home.lbl.searchresultsfound")
	private QAFWebElement lblSearchresultsfound;
	
	public QAFWebElement getHomeLnkMylists() {
		return homeLnkMylists;
	}
	
	public QAFWebElement getHomeLblSearchresultsfound() {
		return lblSearchresultsfound;
	}
	
	public QAFWebElement getHomeLblCartZeroItem() {
		return lblCartZeroItem;
	}
	
	public QAFWebElement getHomeLblCartNoItems() {
		return lblCartNoItems;
	}
	
	public QAFWebElement getHomeLnkCreateanewlist() {
		return homeLnkCreateanewlist;
	}
	/**
	 * TextView for user logged in
	 */
	public QAFWebElement getHomeLblUserdetail() {
		return homeLblUserdetail;
	}

	public QAFWebElement getHomeLblUserdetailmobile() {
		return homeLblUserdetailmobile;
	}

	/**
	 * TextView for food n drinks
	 */
	public QAFWebElement getHomeLblFoodndrinks() {
		return homeLblFoodndrinks;
	}

	/**
	 * TextView for home and kitchen
	 */
	public QAFWebElement getHomeLblHomenkitchen() {
		return homeLblHomenkitchen;
	}

	/**
	 * TextView for Megamenu bar
	 */
	public QAFWebElement getHomeLblMegamenubar() {
		return homeLblMegamenubar;
	}

	/**
	 * TextView for MegaMenu name
	 */
	// public QAFWebElement getHomeListMegamenulbl(String item) {
	// String retElm = String.format(pageProps.getString("home.li.megamenulbl"),
	// item);
	// return new QAFExtendedWebElement(retElm);
	// }

	// public List<QAFWebElement> getHomeListMegamenu() {
	// return homeListMegamenulbl;
	// }

	public QAFWebElement getHomeListMegamenulbl(String item) {
		String items = String.format(pageProps.getString("home.li.megamenulbl"), item);
		return new QAFExtendedWebElement(items);
	}

	/**
	 * TextView for Megamenu title
	 */
	public QAFWebElement getHomeLblMegamenutitle() {
		return homeLblMegamenutitle;
	}

	/**
	 * ListView for submenu for food and drinks
	 */
	public List<QAFWebElement> getHomeLblFoodndrinksubmenu() {
		return homeLblFoodndrinksubmenu;
	}

	/**
	 * ImageView for Right arrow
	 */
	public QAFWebElement getHomeImgRightarrow() {
		return homeImgRightarrow;
	}

	/**
	 * ImageView for Left arrow
	 */
	public QAFWebElement getHomeImgLeftarrow() {
		return homeImgLeftarrow;
	}

	/**
	 * ImageView for all corusels display
	 */
	public QAFWebElement getHomeLblCoruselbox() {
		return homeLblCoruselbox;
	}

	/**
	 * ListView for home and kitchen
	 */
	public List<QAFWebElement> getHomeLblHomenkitchenmenu() {
		return homeLblHomenkitchenmenu;
	}

	/**
	 * ListView for baby and toy
	 */
	public QAFWebElement getHomeLblBaby() {
		return homeLblBaby;
	}

	public List<QAFWebElement> getHomeLblBabyntoy() {
		return homeLblBabyntoy;
	}

	/**
	 * ListView for health and beauty
	 */
	public List<QAFWebElement> getHomeLblHealthnbeauty() {
		return homeLblHealthnbeauty;
	}

	/**
	 * ListView for activities and toy
	 */
	public List<QAFWebElement> getHomeLblOutdoornSports() {
		return homeLblOutdoornSports;
	}

	/**
	 * ListView for office and school
	 */
	public List<QAFWebElement> getHomeLblOfficeandschool() {
		return homeLblOfficeandschool;
	}

	/**
	 * ListView for flowers
	 */
	public List<QAFWebElement> getHomeLblFlowers() {
		return homeLblFlowers;
	}

	/**
	 * ListView for more
	 */
	public List<QAFWebElement> getHomeLblMore() {
		return homeLblMore;
	}

	/**
	 * ListView for pet
	 */
	public List<QAFWebElement> getHomeLblPetsubmenu() {
		return homeLblPetsubmenu;
	}

	/**
	 * TextView for Pharmacy
	 */
	public QAFWebElement getHomeLblHeaderpharmacy() {
		return homeLblHeaderpharmacy;
	}

	/**
	 * TextView for Weekly Ad & Coupons
	 */
	public QAFWebElement getHomeLblHeaderweeklyad() {
		return homeLblHeaderweeklyad;
	}

	public QAFWebElement getHomeLnkWeeklyadmobile() {
		return homeLnkWeeklyadmobile;
	}

	/**
	 * TextView for Weekly Ad & Coupons
	 */
	public QAFWebElement getHomeLblHeaderrecipe() {
		return homeLblHeaderrecipe;
	}

	/**
	 * TextView for My Store
	 */
	public QAFWebElement getHomeLblMystore() {
		return homeLblMystore;
	}

	/**
	 * TextView for My Account
	 */
	public QAFWebElement getHomeLblMyaccount() {
		return homeLblMyaccount;
	}

	/**
	 * TextView for Gift Card
	 */
	public QAFWebElement getHomeLblGiftcard() {
		return homeLblGiftcard;
	}

	/**
	 * TextView for More option
	 */
	public QAFWebElement getHomeLblMoreoption() {
		return homeLblMoreoption;
	}

	/**
	 * TextView for order status
	 */
	public QAFWebElement getHomeLblOrderstatus() {
		return homeLblOrderstatus;
	}

	/**
	 * TextView for weekly ad and coupons page
	 */
	public QAFWebElement getHomeLblWeeklyadandcoupons() {
		return homeLblWeeklyadandcoupons;
	}

	/**
	 * TextView for Digital Coupons from home page
	 */
	public QAFWebElement getHomeLblDigitalcoupons() {
		return homeLblDigitalcoupons;
	}

	/**
	 * TextView for shopping list page
	 */
	public QAFWebElement getHomeLnkMylist() {
		return homeLnkMylist;
	}

	/**
	 * ImageView for Mini Cart logo
	 */
	public QAFWebElement getHomeImgCart() {
		return homeImgCart;
	}

	/**
	 * TextView for Online corusels text
	 */
	public List<QAFWebElement> getHomeListOnlinecoruselname() {
		return homeListOnlinecoruselname;
	}

	/**
	 * ImageView for Right Arrow Online Corusuels orders
	 */
	public QAFWebElement getHomeImgRightarrowonline() {
		return homeImgRightarrowonline;
	}

	/**
	 * TextView for Order Online title
	 */
	public QAFWebElement getHomeLblOrderonline() {
		return homeLblOrderonline;
	}

	/**
	 * ButtonView for Select
	 */
	public QAFWebElement getHomeBtnSelectdigitalcoupons() {
		return homeBtnSelectdigitalcoupons;
	}

	/**
	 * TextView for Digital coupons
	 */
	public QAFWebElement getHomeLblDigitalcouponsname() {
		return homeLblDigitalcouponsname;
	}

	/**
	 * TextView for Watch video in digital coupons
	 */
	public QAFWebElement getHomeLblWatchvideocoupins() {
		return homeLblWatchvideocoupins;
	}

	/**
	 * LinkView for Load More Receipe
	 */
	public QAFWebElement getHomeLblLoadmorerecipe() {
		return homeLblLoadmorerecipe;
	}

	/**
	 * ListView for receipe name
	 */
	public List<QAFWebElement> getHomeLiReceipename() {
		return homeLiReceipename;
	}

	/**
	 * Textview for UserName
	 */
	public QAFWebElement getHomeLblUsername() {
		return homeLblUsername;
	}

	/**
	 * Editview for searchText
	 */
	public QAFWebElement getHomeEdtSearchtext() {
		return homeEdtSearchtext;
	}

	/**
	 * Imageview for Search Button
	 */
	public QAFWebElement getHomeBtnSearch() {
		return homeBtnSearch;
	}

	/**
	 * Textview for Register Link
	 */
	public QAFWebElement getHomeLblRegister() {
		return homeLblRegister;
	}

	/**
	 * ButtonView for Cart
	 */
	public QAFWebElement getHomeBtnCart() {
		return homeBtnCart;
	}

	public QAFWebElement getHomeBtnCartMobile() {
		return homeBtnCartMobile;
	}

	/**
	 * ButtonView for Start Shopping under Cart
	 */
	public QAFWebElement getHomeBtnCartstartshopping() {
		return homeBtnCartstartshopping;
	}

	/**
	 * TextView for Cart Item
	 */
	public List<QAFWebElement> getHomeBtnCartitem() {
		return homeBtnCartitem;
	}

	/**
	 * ButtonView for View Cart under Cart
	 */
	public QAFWebElement getHomeBtnCartviewcart() {
		return homeBtnCartviewcart;
	}

	/**
	 * LinkTextView for BreadCrumb Shop
	 */
	public QAFWebElement getHomeBtnBreadcrumbshop() {
		return homeBtnBreadcrumbshop;
	}

	/**
	 * TextView for StoreName
	 */
	public QAFWebElement getHomeLblStorename() {
		return homeLblStorename;
	}

	/**
	 * H-E-B logo
	 */
	public QAFWebElement getHomeLogo() {
		return homeLogo;
	}

	/**
	 * TextView for shoppinglist from page hedaer
	 */
	public QAFWebElement getHomeLblShoppinglistfromheader() {
		return homeLblShoppinglistfromheader;
	}

	/**
	 * LinkView for create account from shopping list mouse over
	 */
	public QAFWebElement getHomeLnkCreateaccountfromshoppinglist() {
		return homeLnkCreateaccountfromshoppinglist;
	}

	/**
	 * LinkView for i already have an account
	 */
	public QAFWebElement getHomeLnkIalreadyhaveaccount() {
		return homeLnkIalreadyhaveaccount;
	}

	/**
	 * LinkView for Health & Wellness
	 */
	public QAFWebElement getHomeLnkHealthnwellness() {
		return homeLnkHealthnwellness;
	}

	/**
	 * LinkView for Pharmacy
	 */
	public QAFWebElement getHomeLnkPharmacy() {
		return homeLnkPharmacy;
	}

	/**
	 * ButtonView for Quick Reorder
	 */
	public QAFWebElement getHomeBtnCartquickreorder() {
		return homeBtnCartquickreorder;
	}

	/**
	 * LinkTextView for BreadCrumb Custom cakes
	 */
	public QAFWebElement getHomeBtnBreadcrumbcustomcakes() {
		return homeBtnBreadcrumbcustomcakes;
	}

	/**
	 * Link view to shop heb select ingredients
	 */
	public QAFWebElement getHomeOurbrandLnkShohebselectingredients() {
		return homeOurbrandLnkShohebselectingredients;
	}

	/**
	 * LinkView for our brands
	 */
	public QAFWebElement getHomeLnkOurbrands() {
		return homeLnkOurbrands;
	}

	/**
	 * TextVeiw for page title
	 */
	public QAFWebElement getHomeOurbrandLblPagetitle() {
		return homeOurbrandLblPagetitle;
	}

	/**
	 * Textview for LogIn Link
	 */
	public QAFWebElement getHomeLnkChangeshopping() {
		return homeLnkChangeshopping;
	}

	/**
	 * Iamgeview for MyAccount dashboard
	 */
	public QAFWebElement getHomeImgMyaccount() {
		return homeImgMyaccount;
	}

	public QAFWebElement getTxtSearchField() {
		return txtSearchField;
	}

	public List<QAFWebElement> getHomeListSubmenu() {
		return homeListSubmenu;
	}

	public QAFWebElement getTxtOrderStatus() {
		return TxtOrderStatus;
	}

	public QAFWebElement getEdtOrderNumber() {
		return EdtOrderNumber;
	}

	public QAFWebElement getEdtEmailAddress() {
		return EdtEmailAddress;
	}

	public QAFWebElement getBtnOrderSubmit() {
		return BtnOrderSubmit;
	}

	public QAFWebElement getTxtOrderStatusError() {
		return TxtOrderStatusError;
	}

	/**
	 * Link view of My Added List from My Shopping List
	 */
	public List<QAFWebElement> getHomeLnkMyAddedList() {
		return homelnkmyaddedlist;
	}

	public QAFWebElement getLnkHebonline() {
		return lnkHebonline;
	}

	public QAFWebElement getLnkChangemypreferredstore() {
		return lnkChangemypreferredstore;
	}

	public QAFWebElement getHomeLblLogin() {
		return homeLblLogin;
	}

	public QAFWebElement getHomeLblLoginMobile() {
		return homeLblLoginMobile;
	}

	public QAFWebElement getHomeLnkHumburgermobile() {
		return homeLnkHumburgermobile;
	}

	public QAFWebElement getHomeLnkFlowersMegamenu() {
		return lnkFlowersMegamenu;
	}

	public QAFWebElement getHomeLnkFlowersSubmenu(String item) {
		String items = String.format(pageProps.getString("home.get.lnk.flowerssubmenu"), item);
		return new QAFExtendedWebElement(items);
	}

	public QAFWebElement getTxtSearchFieldSmall() {
		return txtSearchFieldSmall;
	}

	public QAFWebElement getHomeBtnLogoutmobile() {
		return homeBtnLogoutmobile;
	}

	public QAFWebElement getBtnCartorderhistory() {
		return btnCartorderhistory;
	}

	public List<QAFWebElement> getLiCartflyoutitemslist() {
		return liCartflyoutitemslist;
	}
	
	public List<QAFWebElement> getLiCartflyoutitemsCountlist() {
		return liCartflyoutitemsCountlist;
	}
	
	public QAFWebElement getLblCartflyoutitemstotalcountlist() {
		return lblCartflyoutitemstotalcountlist;
	}

}