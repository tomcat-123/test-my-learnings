package com.automation.web.steps.Recipes;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.components.MiniListPdtBlocks;
import com.automation.web.components.MyRecipeboxItems;
import com.automation.web.components.RecipeItems;
import com.automation.web.components.recipes.RecipeReviews;
import com.automation.web.pages.email.EmailTemplateTestPage;
import com.automation.web.pages.homepage.FrontdoorTestPage;
import com.automation.web.pages.homepage.InStoreHomePage;
import com.automation.web.pages.login.LoginTestPage;
import com.automation.web.pages.myList.MyListTestPage;
import com.automation.web.pages.recipes.RecipelandingTestPage;
import com.automation.web.pages.registration.RegistrationTestPage;
import com.automation.web.pages.registration.ThankYouTestPage;
import com.automation.web.pages.search.PdtsearchresultTestPage;
import com.automation.web.pages.weeklyads.MiniListTestPage;
import com.automation.web.steps.homepage.HomePage;
import com.automation.web.steps.myaccount.myaccountpage;
import com.automation.web.pages.recipes.BrowserecipesTestPage;
import com.automation.web.pages.recipes.CookingVideodetailsTestPage;
import com.automation.web.pages.recipes.CookingconnectionTestPage;
import com.automation.web.pages.recipes.CookingtipsTestPage;
import com.automation.web.pages.recipes.QuickfinderTestPage;
import com.automation.web.pages.recipes.RecipeBoxTestpage;
import com.automation.web.pages.recipes.RecipecategorydetailaTestPage;
import com.automation.web.pages.recipes.RecipedetailTestpage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.quantum.listerners.PerfectoDriverListener;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.commons.lang.WordUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.Select;

import com.qmetry.qaf.automation.core.ConfigurationManager;

/*List of steps in Recipes

* I navigate to recipe landing page
* I navigate to Cooking tips page
* I check all sections in Cooking tips page
* I select a cooking article
* I verify the user navigated to article template page
* I Add and Verify First Recipe to Shopping list {0}
* I Add and Verify Random Recipe to Shopping list
* I Add and Verify Last Recipe to Shopping list
* I click Add to recipe box in Recipe landing page as Cold User for Registration
* I click Add to recipe box in Recipe landing page
* I add a recipe to recipe box
* I navigate to my recipe box page
* I verify the added recipe is available in the recipe box
* I delete the added recipe from the recipe box
* I click on View All option
* I select a category from Browse recipes page
* I navigate to Recipe CDP page {0}
* I check all sections in Recipe CDP page
* I add recipe to list from Recipe CDP page
* I should see the recipe details page
* I select a recipe from recipe CDP
* I verify the we recommend section is available
* I verify the primo picks recipes are available
* I should see the recipe in the recently viewed recipes section
* I navigate to Cooking connection page
* I check all sections in Cooking connection page
* I navigate to Cooking Video details page {0}
* I check all sections in Cooking Video details page {0}
* I verify the featured cooking video is available
* I verify the user navigated to Cooking tips page
* I navigate to Browse recipes page
* I verify the user navigated to Browse recipes page
* I check all sections in Browse Recipes page
* I verify the recipe categories in Browse Recipes page
* I select recipe of the day
* I verify the properties of recipe details page
* I verify whether the rate recipe section is displayed
* I submit the recipe review
* I click on Add to Recipe box
* Verify the login page is displayed
* I validate the properties of recipe landing page
* I select Breakfast or Brunch with Fruit
* I click on search button
* I see search result page
* I select any search attributes
* I verify search recipes using quick recipe finder
* I click Add to recipe box from Quick Recipe finder search results page
* I Add and Verify Add to Recipe Box from Quick Recipe finder search results page
* I click Add to List from Quick Recipe finder search results page
* I Login with {0} {1} credentials
* I verify Registration Completed
* I click Log in button under Create a RecipeBox tag with {0} {1} credentials
* I click Create An Account button under Create a RecipeBox tag
* I validate rating in CDP PDP page of Recipes
* I validate the reviews of recipe/products in details page
* Adding more than {0} different recipe ingredient items to list

*/

public class Recipes {

	@QAFTestStep(description = "I navigate to recipe landing page")
	public void iNavigateToRecipeLandingPage() {
		FrontdoorTestPage frontdoor = new FrontdoorTestPage();
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();
		RecipelandingTestPage recipelanding = new RecipelandingTestPage();

		if (recipedetail.getRecipedetailLblRecipes().isPresent()) {
			recipedetail.getRecipedetailLblRecipes().click();
		} else {
			PerfectoUtils.scrolltoelement(frontdoor.getFrontBtnExplorerecipes());
			frontdoor.getFrontBtnExplorerecipes().waitForPresent();
			frontdoor.getFrontBtnExplorerecipes().verifyPresent();
			frontdoor.getFrontBtnExplorerecipes().click();
		}
		if (recipelanding.getRecipeLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to recipe landing page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to recipe landing page", MessageTypes.Fail);
		}
		frontdoor.getFrontImgFav().verifyPresent();
	}

	@QAFTestStep(description = "I navigate to Cooking tips page")
	public void iNavigateToCookingTipsPage() {
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();

		recipedetail.getRecipedetailLblCookingtips().waitForPresent(5000);
		recipedetail.getRecipedetailLblCookingtips().click();

		if (recipedetail.getRecipedetailLblCookingtipstitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to cooking tips.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to cooking tips.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I check all sections in Cooking tips page")
	public void iCheckAllSectionsInCookingTipsPage() {
		CookingtipsTestPage cookingtipspage = new CookingtipsTestPage();
		cookingtipspage.getLblCookinghowtoheader().verifyPresent();
		cookingtipspage.getLblCookingarticles().verifyPresent();
		cookingtipspage.getLblCategoriesheader().verifyPresent();
		int howtoItemsList = cookingtipspage.getLblCookinghowtoitemslist().size();
		if (howtoItemsList > 0) {
			PerfectoUtils.reportMessage(
					"Cooking How To list displayed successfully. Number of Items listed: " + howtoItemsList,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cooking How To list is not displayed.", MessageTypes.Fail);
		}
		cookingtipspage.getLblCookingguides().verifyPresent();
		cookingtipspage.getLnkRecipeVideos().verifyPresent();
		cookingtipspage.getLnkBarbecueAndBrisket().verifyPresent();
		cookingtipspage.getLnkGrilling().verifyPresent();
		cookingtipspage.getLnkHealthierCooking().verifyPresent();
		cookingtipspage.getLnkMeatAndPoultry().verifyPresent();
		cookingtipspage.getLnkSeafood().verifyPresent();
		cookingtipspage.getLnkProduce().verifyPresent();
		cookingtipspage.getLnkFoodSafety().verifyPresent();
		cookingtipspage.getLblCookingguides().click();
		cookingtipspage.getLblCookingGuidesHeader().verifyPresent();
		cookingtipspage.getLnkRecipeVideos().click();
		cookingtipspage.getLblRecipeVideosHeader().verifyPresent();
		cookingtipspage.getLnkBarbecueAndBrisket().click();
		cookingtipspage.getLblBarbecueAndBrisketHeader().verifyPresent();
		cookingtipspage.getLnkGrilling().click();
		cookingtipspage.getLblGrillingHeader().verifyPresent();
		cookingtipspage.getLnkHealthierCooking().click();
		cookingtipspage.getLblHealthierCookingHeader().verifyPresent();
		cookingtipspage.getLnkMeatAndPoultry().click();
		cookingtipspage.getLblMeatAndPoultryHeader().verifyPresent();
		cookingtipspage.getLnkSeafood().click();
		cookingtipspage.getLblSeafoodHeader().verifyPresent();
		cookingtipspage.getLnkProduce().click();
		cookingtipspage.getLblProduceHeader().verifyPresent();
		cookingtipspage.getLnkFoodSafety().click();
		cookingtipspage.getLblFoodSafetyHeader().verifyPresent();
	}

	@QAFTestStep(description = "I verify Cooking articles and videos x of y")
	public void iVerifyCookingArticlesandVideosxofy() {
		CookingtipsTestPage cookingtipspage = new CookingtipsTestPage();

		PerfectoUtils.scrolltoelement(cookingtipspage.getLblCookingarticles());
		cookingtipspage.getLblCookingarticles().verifyPresent();
		cookingtipspage.getLblCookingGuidesHeader().verifyPresent();
		String cookingGuideShowing = cookingtipspage.getLblShowing().getText();
		if (cookingGuideShowing.contains(getBundle().getString("recipes.cookingarticles.cookingguide"))) {
			PerfectoUtils.reportMessage("By default, 9 articles are displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("By default, 9 articles are not displayed", MessageTypes.Fail);
		}
		cookingtipspage.getLnkRecipeVideos().click();
		cookingtipspage.getLblRecipeVideosHeader().verifyPresent();
		String recipeVideosShowing = cookingtipspage.getLblShowing().getText();
		if (recipeVideosShowing.contains(getBundle().getString("recipes.cookingarticles.recipevideos"))) {
			PerfectoUtils.reportMessage("System displays the number of vidoes out of the total available.",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("System does not display the number of vidoes out of the total available.",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I select a cooking article")
	public void iSelectACookingArticle() {
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();

		// Scrolling down to Cooking articles
		PerfectoUtils.scrolltoelement(recipedetail.getRecipedetailLblCookingarticles());

		if (recipedetail.getRecipedetailLblCookingarticles().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Cooking articles section.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Cooking articles section.", MessageTypes.Fail);
		}

		recipedetail.getRecipedetailLblFirstcookingarticle().waitForPresent(5000);
		recipedetail.getRecipedetailLblFirstcookingarticle().click();
	}

	@QAFTestStep(description = "I verify the user navigated to article template page")
	public void iVerifyTheUserNavigatedToArticleTemplatePage() {
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();

		recipedetail.getRecipedetailLblCookingarticleheader().waitForPresent(10000);
		if (recipedetail.getRecipedetailLblCookingarticleheader().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to article template page.", MessageTypes.Pass);
			PerfectoUtils.reportMessage(
					"Page header: " + recipedetail.getRecipedetailLblCookingarticleheader().getText(),
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to article template page.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I Add and Verify First Recipe to Shopping list {0}")
	public void iAddVerifyFirstRecipetoShoppinglist(String myItemList) {
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();
		MiniListTestPage minilist = new MiniListTestPage();

		PerfectoUtils.scrolltoelement(recipedetail.getRecipedetailGetLnkRecipeadd2list("1"));
		recipedetail.getRecipedetailGetLnkRecipeadd2list("1").waitForPresent(5000);
		recipedetail.getRecipedetailGetLnkRecipeadd2list("1").verifyPresent();
		recipedetail.getRecipedetailGetLnkRecipeadd2list("1").click();
		recipedetail.getRecipedetailBtnCheckall().waitForPresent(20000);
		recipedetail.getRecipedetailBtnCheckall().verifyPresent();
		recipedetail.getRecipedetailGetChkChkbox("1").click();
		String strIngredient = recipedetail.getRecipedetailGetLblChkboxtext("1").getText();
		recipedetail.getRecipedetailBtnAddtolist().click();

		minilist.getLblPagetitle().waitForPresent(50000);

		verifyItemsInMiniList("First Recipes");
		getBundle().setProperty("strIngredient1", strIngredient);
	}

	@QAFTestStep(description = "I Click on Go to full list view page")
	public void iClickOnGoToFullListViewPage() {
		MyListTestPage mylistTest = new MyListTestPage();

		mylistTest.getMylistLnkGotofullList().waitForPresent(5000);
		if (mylistTest.getMylistLnkGotofullList().isPresent()) {
			mylistTest.getMylistLnkGotofullList().click();
			PerfectoUtils.reportMessage("Go to Full List Link is successfully clicked", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Go to Full List Link is not clicked", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify Items added in Catalogue and Recipes in this list respectively")
	public void verifyItemsAddedInCatalogueAndRecipesInThisListRespectively() {

		String LastItem = getBundle().getString("strIngredient1");
		List<WebElement> CatalogSelection = PerfectoUtils.getDriver().findElements(By.tagName("a"));
		int CatalogCount = CatalogSelection.size();
		System.out.println(CatalogCount);
		for (WebElement Catalog : CatalogSelection) {
			((QAFExtendedWebElement) Catalog).waitForPresent(5000);
			if (Catalog.getText().equals(LastItem)) {
				if (Catalog.isDisplayed()) {
					PerfectoUtils.reportMessage("Catalog Items found in the Full List", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Catalog Items not found in the Full List", MessageTypes.Fail);
				}
				break;
			}
		}
	}

	public void verifyItemsInMiniList(String itemDescription) {
		MiniListTestPage minilist = new MiniListTestPage();

		int ItemCount = Integer.parseInt(PerfectoUtils.getIntCharacters(minilist.getLblItemcount().getText()));

		if (ItemCount > 0) {
			PerfectoUtils.reportMessage(itemDescription + " added successfully to the Shopping list",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(itemDescription + " not added to the Shopping list", MessageTypes.Fail);
		}
	}

	public static boolean checkinMiniShoppingList(String selectedItem) {
		MiniListTestPage minilist = new MiniListTestPage();
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();

		boolean isAvailable = false;

		for (MiniListPdtBlocks minilistProducts : minilist.getLiItemsegments()) {
			String availItem = minilistProducts.getLblItemdescriptions().getText();

			if (selectedItem.contains(availItem)) {
				isAvailable = true;
				break;
			}
		}

		if (!isAvailable) {
			String[] selectedChkBoxSplit = selectedItem.split(" ");
			int splitUbound = selectedChkBoxSplit.length - 1;
			if (recipedetail.getRecipedetailGetLblSelectedchkboxmylist(selectedChkBoxSplit[splitUbound]).isPresent()
					|| recipedetail.getRecipedetailGetLblSelectedchkboxmylist(selectedChkBoxSplit[splitUbound - 1])
							.isPresent()
					|| recipedetail.getRecipedetailGetLblSelectedchkboxmylist(selectedChkBoxSplit[splitUbound - 2])
							.isPresent()
					|| recipedetail.getRecipedetailGetLblSelectedchkboxmylist(
							WordUtils.capitalize(selectedChkBoxSplit[splitUbound])).isPresent()) {
				isAvailable = true;
			}
		}

		return isAvailable;
	}

	@QAFTestStep(description = "I Add and Verify Random Recipe to Shopping list")
	public void iAddVerifyRandomRecipetoShoppinglist() {
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();
		PerfectoUtils.scrolltoelement(recipedetail.getRecipedetailLblShowing());
		String recipeShowingCount = recipedetail.getRecipedetailLblShowing().getText();
		String[] recipeShowingCountSplit = recipeShowingCount.split("of ");
		String maxrecipeCount = recipeShowingCountSplit[1];
		Random rand = new Random(System.currentTimeMillis());
		int num = rand.nextInt(Integer.parseInt(maxrecipeCount));
		if (num > 12) {
			do {
				PerfectoUtils.scrolltoelement(recipedetail.getRecipedetailBtnLoadmorerecipes());
				recipedetail.getRecipedetailBtnLoadmorerecipes().click();
				String recipeShowingCountafterclick;
				do {
					PerfectoUtils.sleep(30);
					recipeShowingCountafterclick = recipedetail.getRecipedetailLblShowing().getText();
				} while (recipeShowingCountafterclick.equalsIgnoreCase(recipeShowingCount));
			} while (!(recipedetail.getRecipedetailGetLnkRecipeadd2list(Integer.toString(num)).isPresent()));
		}
		PerfectoUtils.scrolltoelement(recipedetail.getRecipedetailGetLnkRecipeadd2list(Integer.toString(num)));
		recipedetail.getRecipedetailGetLnkRecipeadd2list(Integer.toString(num)).verifyPresent();
		recipedetail.getRecipedetailGetLnkRecipeadd2list(Integer.toString(num)).click();
		recipedetail.getRecipedetailBtnCheckall().waitForPresent(60000);
		recipedetail.getRecipedetailBtnCheckall().verifyPresent();
		recipedetail.getRecipedetailGetChkChkbox("1").click();

		recipedetail.getRecipedetailBtnAddtolist().click();
		recipedetail.getRecipedetailLblMylist().waitForPresent(50000);

		// Verify the Items in Mini list
		verifyItemsInMiniList("Random Recipe");
	}

	@QAFTestStep(description = "I Add and Verify Last Recipe to Shopping list")
	public void iAddVerifyLastRecipetoShoppinglist() {
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();

		PerfectoUtils.scrolltoelement(recipedetail.getRecipedetailLblShowing());
		String recipeShowingCount = recipedetail.getRecipedetailLblShowing().getText();
		String[] recipeShowingCountSplit = recipeShowingCount.split("of ");
		String maxrecipeCount = recipeShowingCountSplit[1];
		if (recipedetail.getRecipedetailBtnLoadmorerecipes().isPresent()) {
			PerfectoUtils.scrolltoelement(recipedetail.getRecipedetailBtnLoadmorerecipes());
			recipedetail.getRecipedetailBtnLoadmorerecipes().click();
			String recipeShowingCountafterclick;
			do {
				PerfectoUtils.sleep(30);
				recipeShowingCountafterclick = recipedetail.getRecipedetailLblShowing().getText();
			} while (recipeShowingCountafterclick.equalsIgnoreCase(recipeShowingCount));
			while (!(recipedetail.getRecipedetailBtnHideLoadmorerecipesNotPresent().isPresent())) {
				PerfectoUtils.scrolltoelement(recipedetail.getRecipedetailBtnHideLoadmorerecipes());
				recipedetail.getRecipedetailBtnHideLoadmorerecipes().click();
				do {
					PerfectoUtils.sleep(30);
					recipeShowingCountafterclick = recipedetail.getRecipedetailLblShowing().getText();
				} while (recipeShowingCountafterclick.equalsIgnoreCase(recipeShowingCount));
			}
		}

		PerfectoUtils.scrolltoelement(recipedetail.getRecipedetailGetLnkRecipeadd2list(maxrecipeCount));
		recipedetail.getRecipedetailGetLnkRecipeadd2list(maxrecipeCount).verifyPresent();
		recipedetail.getRecipedetailGetLnkRecipeadd2list(maxrecipeCount).click();
		recipedetail.getRecipedetailBtnCheckall().waitForPresent(60000);
		recipedetail.getRecipedetailBtnCheckall().verifyPresent();
		recipedetail.getRecipedetailGetChkChkbox("1").click();
		String selectedChkBox = recipedetail.getRecipedetailGetLblChkboxtext("1").getText();
		String[] selectedChkBoxSplit = selectedChkBox.split(" ");
		int splitUbound = selectedChkBoxSplit.length - 1;
		recipedetail.getRecipedetailBtnAddtolist().click();
		recipedetail.getRecipedetailLblMylist().waitForPresent(50000);

		// Verify the Items in Mini list
		verifyItemsInMiniList("Last Recipe");

		/*
		 * if (recipedetail.getRecipedetailGetLblSelectedchkboxmylist(
		 * selectedChkBoxSplit[splitUbound]).isPresent() ||
		 * recipedetail.getRecipedetailGetLblSelectedchkboxmylist(
		 * selectedChkBoxSplit[splitUbound - 1]) .isPresent() ||
		 * recipedetail.getRecipedetailGetLblSelectedchkboxmylist(
		 * WordUtils.capitalize(selectedChkBoxSplit[splitUbound])).isPresent())
		 * { PerfectoUtils.reportMessage(
		 * "Recipes added successfully to the Shopping list",
		 * MessageTypes.Pass); } else { PerfectoUtils.reportMessage(
		 * "Recipe is not added to the Shopping list", MessageTypes.Fail); }
		 */
	}

	@QAFTestStep(description = "I click Add to recipe box in Recipe landing page as Cold User for Registration")
	public void iClickAddtoRecipeBoxinRecipelandingpageasColdUserforReg() {
		RecipelandingTestPage recipelandingpage = new RecipelandingTestPage();
		LoginTestPage loginpage = new LoginTestPage();
		RegistrationTestPage registration = new RegistrationTestPage();
		recipelandingpage.getRecipeLinkRecipebox().isPresent();
		recipelandingpage.getRecipeLinkRecipebox().click();
		PerfectoUtils.reportMessage("Clicked 'Add to recipe box' in Recipe landing page", MessageTypes.Info);
		loginpage.getLoginLnkCreateOne().waitForPresent(50000);
		loginpage.getLoginLnkCreateOne().click();
		registration.getRgstrEdtFirstname().waitForPresent(30000);
	}

	@QAFTestStep(description = "I click Add to recipe box in Recipe landing page")
	public void iClickAddtoRecipeBoxinRecipelandingpage() {
		RecipelandingTestPage recipelandingpage = new RecipelandingTestPage();
		PerfectoUtils.scrolltoelement(recipelandingpage.getRecipeLinkRecipebox());
		recipelandingpage.getRecipeLinkRecipebox().isPresent();
		recipelandingpage.getRecipeLinkRecipebox().click();
		PerfectoUtils.reportMessage("Clicked 'Add to recipe box' in Recipe landing page", MessageTypes.Info);
	}

	@QAFTestStep(description = "I add a recipe to recipe box")
	public void iAddARecipeToRecipeBox() {
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();

		// Navigating to RDP by via recipe of the day
		recipedetail.getRecipedetailLnkRecipeoftheday().waitForPresent(5000);
		recipedetail.getRecipedetailLnkRecipeoftheday().click();

		// Storing the recipe name in a variable
		String recipename = recipedetail.getRecipedetailLblPagetitle().getText();
		ConfigurationManager.getBundle().setProperty("AddedRecipeNameToBox", recipename);

		// Selecting add to recipe box button
		if (recipedetail.getRecipedetailLblAddtorecipebox().isPresent()) {
			recipedetail.getRecipedetailLblAddtorecipebox().click();

			// Selecting the recipe box and adding the recipe
			int recipeboxSize = recipedetail.getRecipedetailLiLblRecipeboxnames().size();
			if (recipeboxSize > 0) {
				ConfigurationManager.getBundle().setProperty("AddedRecipeBox",
						recipedetail.getRecipedetailLiLblRecipeboxnames().get(1).getText());
				recipedetail.getRecipedetailLiLblRecipeboxnames().get(1).click();
				PerfectoUtils.reportMessage("Added the recipe: "
						+ ConfigurationManager.getBundle().getString("AddedRecipeNameToBox") + " to the recipe box: "
						+ ConfigurationManager.getBundle().getString("AddedRecipeBox"));
			} else {
				PerfectoUtils.reportMessage("No recipe boxes found!", MessageTypes.Fail);
			}

		} else if (recipedetail.getRecipedetailLblAddedtorecipebox().isPresent()) {
			PerfectoUtils.reportMessage("Recipe already added to receipe box.", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I navigate to my recipe box page")
	public void iNavigateToMyRecipeBoxPage() {
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();
		RecipeBoxTestpage myrecipebox = new RecipeBoxTestpage();

		recipedetail.getRecipedetailLblRecipebox().waitForPresent(5000);
		recipedetail.getRecipedetailLblRecipebox().click();

		if (myrecipebox.getRecipeBoxLblHeader().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to My recipe box page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to My recipe box page.", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I validate move to other folder option {0}")
	public void iValidateMovetoOtherFolderOption(String foldername) {
		RecipeBoxTestpage myrecipebox = new RecipeBoxTestpage();

		PerfectoUtils.scrolltoelement(myrecipebox.getRecipeBoxLnkMoreOptions());
		myrecipebox.getRecipeBoxLnkMoreOptions().click();
		myrecipebox.getRecipeBoxLnkMovetoOtherFolder().verifyPresent();
		myrecipebox.getRecipeBoxLnkMovetoOtherFolder().click();
		myrecipebox.getRecipeBoxLnkMovetoOtherFolderDesserts().verifyPresent();
		myrecipebox.getRecipeBoxLnkMovetoOtherFolderDesserts().click();
		myrecipebox.getRecipeBoxLnkMovetoOtherFolderSuccess().waitForPresent(5000);
		String moveToFolderSuccessMsg = myrecipebox.getRecipeBoxLnkMovetoOtherFolderSuccess().getText();
		if (moveToFolderSuccessMsg.contains(foldername)) {
			PerfectoUtils.reportMessage("Moved to Folder "+moveToFolderSuccessMsg, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Failed to Move to Folder "+moveToFolderSuccessMsg, MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I verify the content area in my recipe box")
	public void iVerifyContentAreainMyRecipeBox() {
		RecipelandingTestPage recipe = new RecipelandingTestPage();

		recipe.getLblRecipeboxIconStarCreate().verifyPresent();
		recipe.getLblRecipeBoxContainer().verifyPresent();
		recipe.getLblTitleRecipeBox().verifyPresent();
		recipe.getLblEmptyRecipeBox().verifyPresent();
		recipe.getBtnCreateAnAccUnderCreateRecipeBox().verifyPresent();
		recipe.getLnkLoginUnderCreateRecipeBox().verifyPresent();

	}

	@QAFTestStep(description = "I verify the ellipsis view when the folder name is more than {0} characters")
	public void iVerifyEllipsisViewwhenthefoldernameismorethancharacters(int numOfChar) {
		RecipeBoxTestpage myrecipebox = new RecipeBoxTestpage();

		myrecipebox.getRecipeBoxLnkCreateFolder().click();
		myrecipebox.getRecipeBoxTxtFolderName().sendKeys(getBundle().getString("recipes.foldername"));
		myrecipebox.getRecipeBoxBtnSave().click();
		myrecipebox.getRecipeBoxLblEllipsis().verifyPresent();
		String folderName = myrecipebox.getRecipeBoxLblEllipsis().getText();
		String[] folderNameSplit = folderName.split("\\.");
		int folderName13Char = folderNameSplit[0].length();
		if (folderName13Char == numOfChar) {
			PerfectoUtils.reportMessage(
					"Folder name lenght without ellipsis is " + numOfChar + " characters in My recipe box page",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Folder name lenght without ellipsis is not " + numOfChar + " characters in My recipe box page",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the added recipe is available in the recipe box")
	public void iVerifyTheAddedRecipeIsAvailableInTheRecipeBox() {
		RecipeBoxTestpage myrecipebox = new RecipeBoxTestpage();

		String strAddedRecipeNameToBox = getBundle().getString("AddedRecipeNameToBox");

		try {
			PerfectoUtils.scrolltoelement(myrecipebox.getRecipeBoxLblRecipeName());

			if (myrecipebox.getRecipeBoxLblRecipeName().getText().equalsIgnoreCase(strAddedRecipeNameToBox)) {
				PerfectoUtils.reportMessage("Added recipe available in the recipe box.", MessageTypes.Pass);
				PerfectoUtils.reportMessage("Recipe name: " + myrecipebox.getRecipeBoxLblRecipeName().getText(),
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Added recipe not available in the recipe box.", MessageTypes.Fail);
			}
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Added recipe not available in the recipe box.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I delete the added recipe from the recipe box")
	public void iDeleteTheAddedRecipeFromTheRecipeBox() {
		RecipeBoxTestpage myrecipebox = new RecipeBoxTestpage();

		int flag = 0;
		String strAddedRecipeNameToBox = getBundle().getString("AddedRecipeNameToBox");

		int size = myrecipebox.getRecipeBoxLblRecipeItemsList().size();
		for (int i = 0; i < size; i++) {
			if (myrecipebox.getRecipeBoxLblRecipeNamesList().get(i).getText()
					.equalsIgnoreCase(strAddedRecipeNameToBox)) {
				PerfectoUtils.scrolltoelement(myrecipebox.getRecipeBoxLblMoreOptionsList().get(i));
				myrecipebox.getRecipeBoxLblMoreOptionsList().get(i).click();
				myrecipebox.getRecipeBoxLblDeleteRecipeList().get(i).waitForPresent(2000);
				myrecipebox.getRecipeBoxLblDeleteRecipeList().get(i).click();
				PerfectoUtils.reportMessage("Deleting recipe " + strAddedRecipeNameToBox, MessageTypes.Pass);
				break;
			}
		}
		try {

			// Verifying whether the recipe has been deleted
			if (myrecipebox.getRecipeBoxLblRecipeItemsList().size() == 0) {
				PerfectoUtils.reportMessage(
						"Deleted the added recipe: " + strAddedRecipeNameToBox + " from the recipe box.",
						MessageTypes.Pass);
			} else {
				for (int i = 0; i < size; i++) {
					if (myrecipebox.getRecipeBoxLblRecipeNamesList().get(i).getText()
							.equalsIgnoreCase(strAddedRecipeNameToBox)) {
						flag = 1;
						break;
					}
				}

				if (flag == 0) {
					PerfectoUtils.reportMessage(
							"Deleted the added recipe: " + strAddedRecipeNameToBox + " from the recipe box.",
							MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage(strAddedRecipeNameToBox + " not deleted.", MessageTypes.Fail);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage(strAddedRecipeNameToBox + " not deleted.", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I click on View All option")
	public void iClickOnViewAllOption() {
		RecipelandingTestPage recipelanding = new RecipelandingTestPage();

		if (recipelanding.getRecipeLinkViewall().isPresent()) {
			recipelanding.getRecipeLinkViewall().click();
			PerfectoUtils.reportMessage("Clicked in View all option", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("View all option not found!", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I select a category from Browse recipes page")
	public void iSelectACategoryFromBrowseRecipesPage() {
		BrowserecipesTestPage browserecipes = new BrowserecipesTestPage();

		// Verifying whether navigated to Browse recipes page
		if (browserecipes.getLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Browse recipe page.", MessageTypes.Pass);
			PerfectoUtils.reportMessage("Page title: " + browserecipes.getLblPagetitle().getText());

			// Clicking on the 1st category in the column-1
			browserecipes.getLblFirstcategoryname().get(0).click();
		} else {
			PerfectoUtils.reportMessage("Not navigated to Browse recipe page.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I navigate to Recipe CDP page {0}")
	public void iNavigateToRecipeCDPPage(String RecipeItemLink) {
		BrowserecipesTestPage browserecipes = new BrowserecipesTestPage();
		RecipecategorydetailaTestPage recipeCDP = new RecipecategorydetailaTestPage();

		// Clicking on the sub category items in the category
		browserecipes.getRecipeNameUnderSubheader(RecipeItemLink).click();

		// Verifying whether navigated to Recipe CDP page
		if (recipeCDP.getLblPageheader().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Recipe CDP page.", MessageTypes.Pass);
			PerfectoUtils.reportMessage("Recipes Header title: " + recipeCDP.getLblPageheader().getText());
		} else {
			PerfectoUtils.reportMessage("Not navigated to Recipe CDP page.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I check all sections in Recipe CDP page")
	public void iCheckAllSectionsInRecipeCDPPage() {
		RecipecategorydetailaTestPage recipeCDP = new RecipecategorydetailaTestPage();
		recipeCDP.getLblRecipegridview().verifyPresent();
		recipeCDP.getLblRecipelistview().verifyPresent();
		recipeCDP.getLblSortby().verifyPresent();
		recipeCDP.getTxtSortbydropdown().verifyPresent();
		PerfectoUtils.reportMessage("Recipes Counts: " + recipeCDP.getLblResultcount().getText());
		recipeCDP.getLblResults().verifyPresent();
		recipeCDP.getLblFilterby().verifyPresent();
		int chkBoxFilterCount = recipeCDP.getChkFilterbyoptionslist().size();
		int chkBoxLabelFilterCount = recipeCDP.getLblFilterbyoptionslist().size();
		if (chkBoxFilterCount == chkBoxLabelFilterCount) {
			PerfectoUtils.reportMessage("Filter By Options are displayed correctly", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Filter By Options are not displayed correctly", MessageTypes.Fail);
		}

		PerfectoUtils
				.reportMessage("Recipes listed count in a page: " + recipeCDP.getRecipecdpListRecipeitems().size() + 1);

		recipeCDP.getRecipeImage("1").verifyPresent();
		try {
			recipeCDP.getRecipeName("1").verifyPresent();
		} catch (Exception e) {
			recipeCDP.getRecipeNameAlter("1").verifyPresent();
		}
		try {
			recipeCDP.getRecipeRating("1").verifyPresent();
		} catch (Exception e) {
			recipeCDP.getRecipeRatingAlter("1").verifyPresent();
		}
		try {
			recipeCDP.getRecipeAdd2List("1").verifyPresent();
		} catch (Exception e) {
			recipeCDP.getRecipeAdd2ListAlter("1").verifyPresent();
		}
		try {
			recipeCDP.getRecipeAdd2RecipeBox("1").verifyPresent();
		} catch (Exception e) {
			recipeCDP.getRecipeAdd2RecipeBoxAlter("1").verifyPresent();
		}
	}

	@QAFTestStep(description = "I add recipe to list from Recipe CDP page")
	public void iAddRecipetoListFromRecipeCDPPage() {
		RecipecategorydetailaTestPage recipeCDP = new RecipecategorydetailaTestPage();
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();
		try {
			PerfectoUtils.scrolltoelement(recipeCDP.getRecipeAdd2List("1"));
			recipeCDP.getRecipeAdd2List("1").verifyPresent();
			recipeCDP.getRecipeAdd2List("1").click();
		} catch (Exception e) {
			PerfectoUtils.scrolltoelement(recipeCDP.getRecipeAdd2ListAlter("1"));
			recipeCDP.getRecipeAdd2ListAlter("1").verifyPresent();
			recipeCDP.getRecipeAdd2ListAlter("1").click();
		}
		recipedetail.getRecipedetailBtnCheckall().waitForPresent(60000);
		recipedetail.getRecipedetailBtnCheckall().verifyPresent();
		recipedetail.getRecipedetailGetChkChkbox("1").click();
		String selectedChkBox = recipedetail.getRecipedetailGetLblChkboxtext("1").getText();
		String[] selectedChkBoxSplit = selectedChkBox.split(" ");
		int splitUbound = selectedChkBoxSplit.length - 1;
		recipedetail.getRecipedetailBtnAddtolist().click();
		recipedetail.getRecipedetailLblMylist().waitForPresent(50000);

		// Verify the recipes in Mini list
		verifyItemsInMiniList("Recipes");

	}

	@QAFTestStep(description = "I should see the recipe details page")
	public void iShouldSeeTheRecipeDetailsPage() {
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();

		if (recipedetail.getRecipedetailLblRecipename().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Recipe details page.", MessageTypes.Pass);
			PerfectoUtils.reportMessage("Page title: " + recipedetail.getRecipedetailLblRecipename().getText());
		} else {
			PerfectoUtils.reportMessage("Not navigated to RDP page.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I select a recipe from recipe CDP")
	public void iSelectARecipeFromRecipeCDP() {
		RecipecategorydetailaTestPage recipecdp = new RecipecategorydetailaTestPage();

		for (RecipeItems temp : recipecdp.getRecipecdpListRecipeitems()) {
			// PerfectoUtils.scrolltoelement(temp.getRecipecdpLblRecipename());
			PerfectoUtils.getDriver().getKeyboard().sendKeys(Keys.PAGE_DOWN);
			String selectedRecipename = temp.getRecipecdpLblRecipename().getText();
			getBundle().setProperty("selectedRecipe", selectedRecipename);
			PerfectoUtils.reportMessage("Selected recipe name: " + selectedRecipename, MessageTypes.Pass);
			temp.getRecipecdpLblRecipename().click();
			break;
		}
	}

	@QAFTestStep(description = "I click on first top rated recipes")
	public void iClickFirstTopratedRecipes() {
		RecipelandingTestPage recipes = new RecipelandingTestPage();

		PerfectoUtils.scrolltoelement(recipes.getLnkFirstTopratedRecipeTitle());
		recipes.getLnkFirstTopratedRecipeTitle().click();
	}

	@QAFTestStep(description = "I verify qty form field not accept the input as 0")
	public void iVerifyQtyformfieldnotacceptinputas0() {
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();

		recipedetail.getRecipedetailTxtFirstWeRecommendQuantitypicker().clear();
		recipedetail.getRecipedetailTxtFirstWeRecommendQuantitypicker().sendKeys("0");
		recipedetail.getRecipedetailLnkFirstWeRecommendAddtolist().click();
		PerfectoUtils.getDriver().switchTo().alert();
		String alertText = PerfectoUtils.getDriver().switchTo().alert().getText();
		if (alertText.equals(getBundle().getString("recipes.quantityAlertMsg"))) {
			PerfectoUtils.reportMessage("Quantity form field not accept the input as 0", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Quantity form field accepts the input as 0", MessageTypes.Fail);
		}
		PerfectoUtils.getDriver().switchTo().alert().accept();
	}

	@QAFTestStep(description = "I verify the we recommend section is available")
	public void iVerifyTheWeRecommendSectionIsAvailable() {
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();

		try {
			PerfectoUtils.scrolltoelement(recipedetail.getRecipedetailLblWerecommend());

			if (recipedetail.getRecipedetailLblWerecommend().isPresent()) {
				PerfectoUtils.reportMessage("We recommend section is available in RDP.", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("We recommend section is not available in RDP.", MessageTypes.Fail);
			}
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Unable to navigate to We recommend section in RDP.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the primo picks recipes are available")
	public void iVerifyThePrimoPicksRecipesAreAvailable() {
		RecipelandingTestPage recipelanding = new RecipelandingTestPage();

		List<String> primopicksrecipeslist = new ArrayList<>();

		if ((recipelanding.getLblPrimopicksrecipenames().size()) > 0) {
			for (QAFWebElement temp : recipelanding.getLblPrimopicksrecipenames()) {
				primopicksrecipeslist.add(temp.getText());
			}

			PerfectoUtils.reportMessage("Available Primo pick recipes.", MessageTypes.Pass);
			for (int i = 0; i < primopicksrecipeslist.size() - 1; i++) {
				System.out.println(primopicksrecipeslist.get(i));
				PerfectoUtils.reportMessage(primopicksrecipeslist.get(i));
			}
		} else {
			PerfectoUtils.reportMessage("No Primo picks found.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I should see the recipe in the recently viewed recipes section")
	public void iShouldSeeTheRecipeInTheRecentlyViewedRecipesSection() {
		RecipelandingTestPage recipelanding = new RecipelandingTestPage();

		String selectedRecipe = getBundle().getString("selectedRecipe");

		try {
			PerfectoUtils.scrolltoelement(recipelanding.getRecipeImgRecentlyviewed());

			if (recipelanding.getRecipenameBylabel(selectedRecipe).isPresent()) {
				PerfectoUtils.reportMessage("Selected recipe available in the Recently viewed section.",
						MessageTypes.Pass);
				PerfectoUtils.reportMessage("Selected recipe: " + selectedRecipe, MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Selected recipe not available in the Recently viewed section.",
						MessageTypes.Fail);
			}
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Unable to navigate to recently viewed section.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify that recently viewed recipe carousel is not displayed")
	public void iVerifyRecentlyViewedRecipecarouselisnotdisplayed() {
		RecipelandingTestPage recipelanding = new RecipelandingTestPage();

		recipelanding.getRecipeImgRecentlyviewed().verifyNotPresent();
	}

	@QAFTestStep(description = "I navigate to Cooking connection page")
	public void iNavigateToCookingConnectionPage() {
		RecipelandingTestPage recipelanding = new RecipelandingTestPage();
		CookingconnectionTestPage cookingconnection = new CookingconnectionTestPage();

		recipelanding.getLblCookingconnection().waitForPresent(5000);
		recipelanding.getLblCookingconnection().click();

		if (cookingconnection.getLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to cooking connection page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to cooking connection page.", MessageTypes.Fail);
		}

	}
	
	@QAFTestStep(description = "I verify recipes count present in cc page and cc friendly page match")
	public void iVerifyRecipescountpresentinccpageandccfriendlypagematch() {
		CookingconnectionTestPage cookingconnection = new CookingconnectionTestPage();

		String ccFriendlyPageResultCount = cookingconnection.getLblCCRecipesResultsCount().getText();
		PerfectoUtils.getDriver().get(getBundle().getString("recipes.cookingconnection.ccURL"));
		String ccPageResultCount = cookingconnection.getLblCCRecipesResultsCount().getText();
		if (ccFriendlyPageResultCount.equals(ccPageResultCount)) {
			PerfectoUtils.reportMessage("Recipes count present in cc page and cc friendly page are matched", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Recipes count present in cc page and cc friendly page are not matched", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I check all sections in Cooking connection page")
	public void iCheckAllSectionsInCookingConnectionPage() {
		CookingconnectionTestPage cookingconnection = new CookingconnectionTestPage();

		cookingconnection.getIconVideo().verifyPresent();
		cookingconnection.getLblFeaturedvideo().verifyPresent();
		cookingconnection.getLnkFeaturedVideoAdd2RecipeBox().verifyPresent();
		cookingconnection.getImgCookingConnectionImage().verifyPresent();
		cookingconnection.getLnkStoreLocation().verifyPresent();
		cookingconnection.getLblCookingconnectionvideos().verifyPresent();
		cookingconnection.getLblCookingconnectionrecipes().verifyPresent();
		PerfectoUtils.reportMessage("Cooking connection videos count listed in a page: "
				+ cookingconnection.getLblCookingconnectionvideosnamelist().size() + 1);
		cookingconnection.getLblCookingconnectionvideosnamelist().get(0).verifyPresent();
		iCheckAllSectionsInRecipeCDPPage();
	}
	
	@QAFTestStep(description = "I verify Cooking connection recipes filters x of y")
	public void iVerifyCookingconnectionrecipesfiltersxofy() {
		CookingconnectionTestPage cookingconnection = new CookingconnectionTestPage();
		
		Select sortBy = new Select(cookingconnection.getDDRecipesSort());
		PerfectoUtils.scrolltoelement(cookingconnection.getLblCookingconnectionrecipes());
		cookingconnection.getLblCookingconnectionrecipes().verifyPresent();
		cookingconnection.getChkFilterbyBread().click();
		cookingconnection.getChkFilterbyBurgers().click();
		cookingconnection.getChkFilterbyBreakfast().click();
		sortBy.selectByVisibleText("A-Z");
		String filterByShowing = cookingconnection.getLblShowingXofY().getText();
		if(filterByShowing.contains(getBundle().getString("recipes.cookingconnection.ccrecipesflterby"))){
			PerfectoUtils.reportMessage("By default, 16 recipes are displayed", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("By default, 16 recipes are not displayed", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I verify top rated recipes x of y")
	public void iVerifytopratedrecipesxofy() {
		RecipelandingTestPage recipe = new RecipelandingTestPage();
		CookingtipsTestPage showing = new CookingtipsTestPage();
		
		recipe.getRecipeLblTopratedrecipe().verifyPresent();
		String topratedShowing = showing.getLblShowing().getText();
		if(topratedShowing.contains(getBundle().getString("recipes.cookingarticles.recipevideos"))){
			PerfectoUtils.reportMessage("By default, 12 recipes are displayed", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("By default, 12 recipes are not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I navigate to Cooking Video details page {0}")
	public void iNavigateToCookingVideoDetailsPage(String videoname) {
		CookingconnectionTestPage cookingconnection = new CookingconnectionTestPage();
		CookingVideodetailsTestPage cookingvideodetails = new CookingVideodetailsTestPage();
		PerfectoUtils.scrolltoelement(cookingconnection.getCookingconnectionUniqueVideos(videoname));
		cookingconnection.getCookingconnectionUniqueVideos(videoname).waitForPresent(5000);

		getBundle().setProperty("cookingVideoLink",
				cookingconnection.getCookingconnectionUniqueVideos(videoname).getAttribute("href"));
		cookingconnection.getCookingconnectionUniqueVideos(videoname).click();

		if (cookingvideodetails.getCookingconnectionVideoHeader(videoname).isPresent()) {
			PerfectoUtils.reportMessage("Navigated to cooking video details page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to cooking video details page.", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I check all sections in Cooking Video details page {0}")
	public void iCheckAllSectionsInCookingVideoDetailsPage(String videoname) {
		CookingVideodetailsTestPage cookingvideodetails = new CookingVideodetailsTestPage();
		/*
		 * PerfectoUtils.getDriver().switchTo().frame(0);
		 * cookingvideodetails.getIconVideo().waitForPresent(30000);
		 * cookingvideodetails.getIconVideo().verifyPresent();
		 * PerfectoUtils.getDriver().switchTo().defaultContent();
		 */
		cookingvideodetails.getCookingconnectionVideoRecipeImage(videoname).verifyPresent();
		cookingvideodetails.getCookingconnectionVideoRecipeTitle(videoname).verifyPresent();
		cookingvideodetails.getLblPreptime().verifyPresent();
		PerfectoUtils.reportMessage(
				"Prep Time is displayed successfully " + cookingvideodetails.getLblPreptime().getText(),
				MessageTypes.Pass);
		cookingvideodetails.getLblTotaltime().verifyPresent();
		PerfectoUtils.reportMessage(
				"Total Time is displayed successfully " + cookingvideodetails.getLblTotaltime().getText(),
				MessageTypes.Pass);
		cookingvideodetails.getLblServes().verifyPresent();
		PerfectoUtils.reportMessage("Serves is displayed successfully " + cookingvideodetails.getLblServes().getText(),
				MessageTypes.Pass);
		cookingvideodetails.getLblRecipeRating().verifyPresent();
		cookingvideodetails.getLnkRecipeAddtoList().verifyPresent();
		cookingvideodetails.getLnkRecipeAddtoRecipeBox().verifyPresent();
		cookingvideodetails.getLblMoreVideos().verifyPresent();

		String url = PerfectoUtils.getDriver().getCurrentUrl();

		if (url.equalsIgnoreCase(getBundle().getString("recipes.cookingVideoLink")))
			PerfectoUtils.reportMessage("Cooking video link is verified " + url, MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Cooking video link is not correct " + url, MessageTypes.Fail);
	}
	
	@QAFTestStep(description = "I verify More Videos options {0}")
	public void iVerifyMoreVideoOption(String videoname) {
		CookingVideodetailsTestPage cookingvideodetails = new CookingVideodetailsTestPage();
		CookingtipsTestPage showing = new CookingtipsTestPage();
		
		cookingvideodetails.getLblMoreVideos().verifyPresent();
		String moreVideosShowing = showing.getLblShowing().getText();
		String[] videosShowingCountSplit = moreVideosShowing.split("of ");
		String maxVideosCount = videosShowingCountSplit[1];
		if(Integer.parseInt(maxVideosCount) > 0){
			PerfectoUtils.reportMessage("More videoes related to the viewed videos are displayed", MessageTypes.Pass);
		}else{
			PerfectoUtils.reportMessage("More videoes related to the viewed videos are not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the featured cooking video is available")
	public void iVerifyTheFeaturedCookingVideoIsAvailable() {
		CookingconnectionTestPage cookingconnection = new CookingconnectionTestPage();

		if (cookingconnection.getLblFeaturedvideo().isPresent()) {
			PerfectoUtils.reportMessage("Featured video is available in Cooking connection page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Featured video is not available in Cooking connection page",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the user navigated to Cooking tips page")
	public void iVerifyTheUserNavigatedToCookingTipsPage() {
		CookingtipsTestPage cookingtips = new CookingtipsTestPage();

		if (cookingtips.getLblPageheader().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to cooking tips page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to cooking tips page.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I navigate to Browse recipes page")
	public void iNavigateToBrowseRecipesPage() {
		RecipelandingTestPage recipelanding = new RecipelandingTestPage();

		recipelanding.getLblBrowserecipes().waitForPresent(5000);
		recipelanding.getLblBrowserecipes().click();
	}

	@QAFTestStep(description = "I verify the user navigated to Browse recipes page")
	public void iVerifyTheUserNavigatedToBrowseRecipesPage() {
		BrowserecipesTestPage browserecipes = new BrowserecipesTestPage();

		if (browserecipes.getLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to browse recipes page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to browse recipes page.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I check all sections in Browse Recipes page")
	public void iCheckAllSectionsinBrowseRecipesPage() {
		BrowserecipesTestPage browserecipes = new BrowserecipesTestPage();

		if (browserecipes.getLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to browse recipes page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to browse recipes page.", MessageTypes.Fail);
		}

		browserecipes.getLblBycookingmethod().verifyPresent();
		browserecipes.getImgBycookingmethod().verifyPresent();
		browserecipes.getLblByCookingMethodSub().get(2).verifyPresent();

		browserecipes.getLblBycuisinetype().verifyPresent();
		browserecipes.getImgBycuisinetype().verifyPresent();
		browserecipes.getLblByCuisineTypeSub().get(2).verifyPresent();

		browserecipes.getLblBydiet().verifyPresent();
		browserecipes.getImgBydiet().verifyPresent();
		browserecipes.getLblByDietSub().get(2).verifyPresent();

		browserecipes.getLblBymealtype().verifyPresent();
		browserecipes.getImgBymealtype().verifyPresent();
		browserecipes.getLblByMealTypeSub().get(2).verifyPresent();

		browserecipes.getLblBynutrition().verifyPresent();
		browserecipes.getImgBynutrition().verifyPresent();
		browserecipes.getLblByNutritionSub().get(2).verifyPresent();

		browserecipes.getLblBypopularcategory().verifyPresent();
		browserecipes.getImgBypopularcategory().verifyPresent();
		browserecipes.getLblByPopularCategorySub().get(2).verifyPresent();

		browserecipes.getLblByprimaryingredient().verifyPresent();
		browserecipes.getImgByprimaryingredient().verifyPresent();
		browserecipes.getLblByPrimaryIngredientSub().get(2).verifyPresent();

		browserecipes.getLblByseasonorholiday().verifyPresent();
		browserecipes.getImgByseasonorholiday().verifyPresent();
		browserecipes.getLblBySeasonorHolidaySub().get(2).verifyPresent();

		browserecipes.getLblBysource().verifyPresent();
		browserecipes.getImgBysource().verifyPresent();
		browserecipes.getLblBySourceSub().get(2).verifyPresent();
	}
	
	@QAFTestStep(description = "I navigate and verify Low saturated fat Nutrition type")
	public void iNavigateandVerifyLowsaturatedfatNutritiontype() {
		BrowserecipesTestPage browserecipes = new BrowserecipesTestPage();
		RecipecategorydetailaTestPage cdp = new RecipecategorydetailaTestPage();

		if (browserecipes.getLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to browse recipes page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to browse recipes page.", MessageTypes.Fail);
		}

		browserecipes.getLnkLowsaturatedfat().verifyPresent();
		browserecipes.getLnkLowsaturatedfat().click();
		PerfectoUtils.reportMessage("Clicked Low saturated fat Nutrition type", MessageTypes.Pass);

		cdp.getLblPageheader().verifyPresent();
		cdp.getLblFilterby().verifyPresent();
		int filterOptions = cdp.getChkFilterbyoptionslist().size();
		if (filterOptions > 0) {
			PerfectoUtils.reportMessage("Low saturated fat recipes are displayed with filter options", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Low saturated fat recipes are not displayed with filter options", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the recipe categories in Browse Recipes page")
	public void iVerifytheRecipeCategoriesinBrowseRecipesPage() {
		BrowserecipesTestPage browserecipes = new BrowserecipesTestPage();
		PerfectoUtils.scrolltoelement(browserecipes.getLblTopRatedRecipes());
		browserecipes.getLblTopRatedRecipes().verifyPresent();
		browserecipes.getTopratedRecipesProductImage("1").verifyPresent();
		browserecipes.getTopratedRecipesTitle("1").verifyPresent();
		browserecipes.getTopratedRecipesSpecs("1").verifyPresent();
		browserecipes.getTopratedAddtoList("1").verifyPresent();
		if (browserecipes.getTopratedAddtoRecipebox("1").isPresent()) {
			browserecipes.getTopratedAddtoRecipebox("1").verifyPresent();
		} else {
			browserecipes.getTopratedAddedtoRecipebox("1").verifyPresent();
		}
		browserecipes.getLblSec2().verifyPresent();
		browserecipes.getLblSec2().click();
		browserecipes.getChickenRecipesProductImage("1").verifyPresent();
		browserecipes.getChickenRecipesTitle("1").verifyPresent();
		browserecipes.getChickenRecipesSpecs("1").verifyPresent();
		browserecipes.getChickenAddtoList("1").verifyPresent();
		if (browserecipes.getChickenAddtoRecipebox("1").isPresent()) {
			browserecipes.getChickenAddtoRecipebox("1").verifyPresent();
		} else {
			browserecipes.getChickenAddedtoRecipebox("1").verifyPresent();
		}
		browserecipes.getLblSec3().verifyPresent();
		browserecipes.getLblSec3().click();
		browserecipes.getSeafoodRecipesProductImage("1").verifyPresent();
		browserecipes.getSeafoodRecipesTitle("1").verifyPresent();
		browserecipes.getSeafoodRecipesSpecs("1").verifyPresent();
		browserecipes.getSeafoodAddtoList("1").verifyPresent();
		if (browserecipes.getSeafoodAddtoRecipebox("1").isPresent()) {
			browserecipes.getSeafoodAddtoRecipebox("1").verifyPresent();
		} else {
			browserecipes.getSeafoodAddedtoRecipebox("1").verifyPresent();
		}
		browserecipes.getLblTopRatedRecipes().click();
		browserecipes.getTopratedRecipesProductImage("1").verifyPresent();
	}

	@QAFTestStep(description = "I select recipe of the day")
	public void iSelectRecipeOfTheDay() {
		RecipelandingTestPage recipelanding = new RecipelandingTestPage();

		PerfectoUtils.scrolltoelement(recipelanding.getRecipeLinkRecipeoftheday());
		recipelanding.getRecipeLinkRecipeoftheday().waitForPresent(5000);
		recipelanding.getRecipeLinkRecipeoftheday().click();
	}

	@QAFTestStep(description = "I verify One valid and one invalid email address")
	public void iVerifyOnevalidandoneinvalidemailaddress() {
		RecipedetailTestpage recipedetails = new RecipedetailTestpage();

		recipedetails.getRecipedetailLblEmail().verifyPresent();
		recipedetails.getRecipedetailLblEmail().click();
		recipedetails.getRecipedetailLblEmailtofriend().waitForPresent(5000);
		recipedetails.getRecipedetailTxtRecipientEmail().sendKeys(getBundle().getString("recipes.email.invalid"));
		recipedetails.getRecipedetailBtnSendEmail().verifyPresent();
		recipedetails.getRecipedetailTxtRecipientEmail().clear();
		recipedetails.getRecipedetailTxtRecipientEmail().sendKeys(getBundle().getString("recipes.email.valid"));
		recipedetails.getRecipedetailBtnSendEmail().verifyPresent();
		recipedetails.getRecipedetailLnkEmailClose().click();
	}

	@QAFTestStep(description = "I verify the properties of recipe details page")
	public void iVerifyThePropertiesOfRecipeDetailsPage() {
		RecipedetailTestpage recipedetails = new RecipedetailTestpage();

		recipedetails.getRecipedetailLblRecipename().verifyPresent();
		recipedetails.getRecipedetailLblPreptime().verifyPresent();
		recipedetails.getRecipedetailLblCooktime().verifyPresent();
		recipedetails.getRecipedetailLblTotaltime().verifyPresent();
		recipedetails.getRecipedetailLblServes().verifyPresent();

		recipedetails.getRecipedetailLblIngredientstitle().verifyPresent();

		if (recipedetails.getRecipedetailLblAddtorecipebox().isPresent())
			PerfectoUtils.reportMessage("Add to Recipe box link is available!");
		else if (recipedetails.getRecipedetailLblAddedtorecipebox().isPresent())
			PerfectoUtils.reportMessage("Added to Recipe box Already!");
		else
			PerfectoUtils.reportMessage("Neither Add to Recipe Box nor Added to Recipe Box is not available!",
					MessageTypes.Fail);

		recipedetails.getRecipedetailLblAddtolistfromrightside().verifyPresent();
		recipedetails.getRecipedetailLblEmail().verifyPresent();
		recipedetails.getRecipedetailLblPrint().verifyPresent();

		// Verify whether the "Check ALL" and "Add to list" buttons are present
		if (recipedetails.getRecipedetailBtnCheckall().isPresent()) {
			recipedetails.getRecipedetailBtnCheckall().verifyPresent();
			recipedetails.getRecipedetailBtnAddtolist().verifyPresent();
			PerfectoUtils.getDriver().getKeyboard().sendKeys(Keys.PAGE_DOWN);
		} else {
			try {
				PerfectoUtils.scrolltoelement(recipedetails.getRecipedetailBtnCheckall());
				if (recipedetails.getRecipedetailBtnCheckall().isPresent()) {
					recipedetails.getRecipedetailBtnCheckall().verifyPresent();
					recipedetails.getRecipedetailBtnAddtolist().verifyPresent();
					PerfectoUtils.getDriver().getKeyboard().sendKeys(Keys.PAGE_UP);
				} else {
					PerfectoUtils.reportMessage("Check All button not found!", MessageTypes.Fail);
				}

			} catch (Exception e) {
				e.printStackTrace();
				PerfectoUtils.reportMessage("Check All button not found!", MessageTypes.Fail);
			}
		}

		// Verify whether the "Nutrition facts" option is present
		if (recipedetails.getRecipedetailLblNutritionfacts().isPresent()) {
			recipedetails.getRecipedetailLblNutritionfacts().verifyPresent();
		} else {
			try {
				PerfectoUtils.scrolltoelement(recipedetails.getRecipedetailLblNutritionfacts());
				if (recipedetails.getRecipedetailLblNutritionfacts().isPresent()) {
					recipedetails.getRecipedetailLblNutritionfacts().verifyPresent();
					PerfectoUtils.getDriver().getKeyboard().sendKeys(Keys.PAGE_UP);
				} else {
					PerfectoUtils.reportMessage("Nutrition facts option not found!", MessageTypes.Fail);
				}
			} catch (Exception e) {
				e.printStackTrace();
				PerfectoUtils.reportMessage("Nutrition facts option not found!", MessageTypes.Fail);
			}
		}

		// Verify "View recipe box" option
		if (recipedetails.getRecipedetailLblRecentlyviewedrecipes().isPresent()) {
			recipedetails.getRecipedetailLblRecentlyviewedrecipes().verifyPresent();
		} else {
			try {
				PerfectoUtils.scrolltoelement(recipedetails.getRecipedetailLblRecentlyviewedrecipes());
				if (recipedetails.getRecipedetailLblRecentlyviewedrecipes().isPresent()) {
					recipedetails.getRecipedetailLblRecentlyviewedrecipes().verifyPresent();
					PerfectoUtils.getDriver().getKeyboard().sendKeys(Keys.PAGE_UP);
				} else {
					PerfectoUtils.reportMessage("View recipe box option not found!", MessageTypes.Info);
				}
			} catch (Exception e) {
				e.printStackTrace();
				PerfectoUtils.reportMessage("View recipe box option not found!", MessageTypes.Info);
			}
		}
	}

	@QAFTestStep(description = "I verify whether the rate recipe section is displayed")
	public void iVerifyWhetherTheRateRecipeSectionIsDisplayed() {
		RecipedetailTestpage recipedetails = new RecipedetailTestpage();

		try {
			PerfectoUtils.scrolltoelement(recipedetails.getRecipedetailLblRatethisrecipe());

			if (recipedetails.getRecipedetailLblRatethisrecipe().isPresent()) {
				PerfectoUtils.reportMessage("Rate this recipe section is available.", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Rate this recipe section is not available.", MessageTypes.Fail);
			}
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Rate this recipe section is not available.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I submit the recipe review")
	public void iSubmitTheRecipeReview() {
		RecipedetailTestpage recipedetails = new RecipedetailTestpage();

		String reviewTitle = getBundle().getString("recipes.reviews.reviewtitle");
		String reviewComments = getBundle().getString("recipes.reviews.reviewcommnets");

		recipedetails.getRecipedetailIconRatingstar4().click();
		recipedetails.getRecipedetailTxtReviewtitle().sendKeys(reviewTitle);
		recipedetails.getRecipedetailTxtReviewcomments().sendKeys(reviewComments);
		PerfectoUtils.reportMessage("Submitting the review comments..", MessageTypes.Pass);
		PerfectoUtils.scrolltoelement(recipedetails.getRecipedetailBtnSubmit());
		recipedetails.getRecipedetailBtnSubmit().click();

		try {
			recipedetails.getRecipedetailLblThankyou().waitForPresent(15000);
			if (recipedetails.getRecipedetailLblThankyou().isPresent()) {
				PerfectoUtils.reportMessage(
						"Submitted the review comments and navigated to confirmations page successfully.",
						MessageTypes.Pass);
				PerfectoUtils.reportMessage("Message: " + recipedetails.getRecipedetailLblThankyoucommnets().getText(),
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Not navigated to review comments confirmation page!", MessageTypes.Fail);
			}
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Not navigated to review comments confirmation page!", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I click on Add to Recipe box")
	public void iClickOnAddToRecipeBox() {
		RecipelandingTestPage recipe = new RecipelandingTestPage();

		PerfectoUtils.scrolltoelement(recipe.getRecipeLinkRecipebox());
		recipe.getRecipeLinkRecipebox().waitForPresent(3000);
		recipe.getRecipeLinkRecipebox().click();
	}

	@QAFTestStep(description = "Verify the login page is displayed")
	public void verifyTheLoginPageIsDisplayed() {
		LoginTestPage login = new LoginTestPage();

		login.getLoginBtnLogin().waitForPresent(3000);
		login.getLoginBtnLogin().verifyPresent();
		login.getLoginLnkCreateOne().verifyPresent();
	}

	@QAFTestStep(description = "I validate the properties of recipe landing page")
	public void iValidateThePropertiesOfRecipeLandingPage() {
		RecipelandingTestPage recipe = new RecipelandingTestPage();

		recipe.getRecipeLblPagetitle().verifyPresent();

		try {
			if (recipe.getRecipeLinkRecipeoftheday().isPresent()) {
				PerfectoUtils.reportMessage("Recipe of the day link available as expected.", MessageTypes.Pass);
			} else {
				// Navigating down to verify whether the Recipe of the day link-
				// is available.
				PerfectoUtils.getDriver().getKeyboard().sendKeys(Keys.PAGE_DOWN);
				if (recipe.getRecipeLinkRecipeoftheday().isPresent()) {
					PerfectoUtils.reportMessage("Recipe of the day link available as expected.", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Recipe of the day link not available.", MessageTypes.Fail);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@QAFTestStep(description = "I select Breakfast or Brunch with Fruit")
	public void iSelectBreakfastOrBrunchWithFruit() {
		QuickfinderTestPage quickfinder = new QuickfinderTestPage();

		PerfectoUtils.scrolltoelement(quickfinder.getQuickfinderTxtOptionone());
		Select sel1 = new Select(quickfinder.getQuickfinderTxtOptionone());
		Select sel2 = new Select(quickfinder.getQuickfinderTxtOptiontwo());

		quickfinder.getQuickfinderTxtOptionone().verifyPresent();
		sel1.selectByIndex(3);

		QAFWebElement option1 = (QAFWebElement) sel1.getFirstSelectedOption();
		System.out.println(option1.getText());

		String pickerName1 = option1.getText();
		getBundle().setProperty("recipename1", pickerName1);

		quickfinder.getQuickfinderTxtOptiontwo().verifyPresent();
		sel2.selectByIndex(5);

		WebElement option2 = sel2.getFirstSelectedOption();
		System.out.println(option2.getText());

		String pickerName2 = option2.getText();
		getBundle().setProperty("recipename2", pickerName2);

	}

	public void iSelectAppetizerOrSnackWithBeansOrLentils() {
		QuickfinderTestPage quickfinder = new QuickfinderTestPage();

		PerfectoUtils.scrolltoelement(quickfinder.getQuickfinderTxtOptionone());
		Select sel1 = new Select(quickfinder.getQuickfinderTxtOptionone());
		Select sel2 = new Select(quickfinder.getQuickfinderTxtOptiontwo());

		quickfinder.getQuickfinderTxtOptionone().verifyPresent();
		sel1.selectByIndex(1);

		QAFWebElement option1 = (QAFWebElement) sel1.getFirstSelectedOption();
		System.out.println(option1.getText());

		String pickerName1 = option1.getText();
		getBundle().setProperty("recipename1", pickerName1);

		quickfinder.getQuickfinderTxtOptiontwo().verifyPresent();
		sel2.selectByIndex(4);

		WebElement option2 = sel2.getFirstSelectedOption();
		System.out.println(option2.getText());

		String pickerName2 = option2.getText();
		getBundle().setProperty("recipename2", pickerName2);

	}

	@QAFTestStep(description = "I click on search button")
	public void iClickOnSearchButton() {
		QuickfinderTestPage quickfinder = new QuickfinderTestPage();

		quickfinder.getQuickfinderBtnSearch().verifyPresent();
		quickfinder.getQuickfinderBtnSearch().click();
	}

	@QAFTestStep(description = "I see search result page")
	public void iSeeSearchResultPage() {
		QuickfinderTestPage quickfinder = new QuickfinderTestPage();

		if (quickfinder.getQuickfinderLblSearchResults().verifyPresent()) {
			PerfectoUtils.reportMessage("Able to see Search Results page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not able to see Search Results page", MessageTypes.Fail);
		}
		String recipename1 = getBundle().getString("recipename1");
		String recipename2 = getBundle().getString("recipename2");
		System.out.println("we found search results for " + recipename1 + " and " + recipename2 + " in recipes");
	}

	@QAFTestStep(description = "I select any search attributes")
	public void iSelectAnySearchAttributes() {
		QuickfinderTestPage quickfinder = new QuickfinderTestPage();

		PerfectoUtils.scrolltoelement(quickfinder.getQuickfinderTxtOptionone());
		Select sel1 = new Select(quickfinder.getQuickfinderTxtOptionone());
		Select sel2 = new Select(quickfinder.getQuickfinderTxtOptiontwo());

		quickfinder.getQuickfinderTxtOptionone().verifyPresent();
		sel1.selectByIndex(1);

		quickfinder.getQuickfinderTxtOptiontwo().verifyPresent();
		sel2.selectByIndex(1);
	}

	@QAFTestStep(description = "I verify search recipes using quick recipe finder")
	public void iVerifySearchRecipesUsingQuickRecipeFinder() {
		iSelectBreakfastOrBrunchWithFruit();
		iClickOnSearchButton();
		iSeeSearchResultPage();
		QuickfinderTestPage quickfinder = new QuickfinderTestPage();
		String recipeCount = quickfinder.getQuickfinderLblRecipesCount().getText();
		PerfectoUtils.reportMessage("Search Results of Quick Recipe Finder contains " + recipeCount + " Recipes",
				MessageTypes.Info);
		quickfinder.getQuickFinderRecipesProductImage("1").verifyPresent();
		quickfinder.getQuickFinderRecipesTitle("1").verifyPresent();
		quickfinder.getQuickFinderRecipesSpecs("1").verifyPresent();
		quickfinder.getQuickFinderAddtoList("1").verifyPresent();
		if (quickfinder.getQuickFinderAddtoRecipebox("1").isPresent()) {
			quickfinder.getQuickFinderAddtoRecipebox("1").verifyPresent();
		} else {
			quickfinder.getQuickFinderAddedtoRecipebox("1").verifyPresent();
		}
	}

	@QAFTestStep(description = "I verify search recipes using quick recipe finder for primopicks")
	public void iverifySearchRecipesUsingQuickRecipeFinderForPrimopicks() {
		iSelectAppetizerOrSnackWithBeansOrLentils();
		iClickOnSearchButton();
		iSeeSearchResultPage();
		QuickfinderTestPage quickfinder = new QuickfinderTestPage();
		String recipeCount = quickfinder.getQuickfinderLblRecipesCount().getText();
		PerfectoUtils.reportMessage("Search Results of Quick Recipe Finder contains " + recipeCount + " Recipes",
				MessageTypes.Info);
		quickfinder.getQuickFinderRecipesProductImage("1").verifyPresent();
		quickfinder.getQuickFinderRecipesTitle("1").verifyPresent();
		quickfinder.getQuickFinderRecipesSpecs("1").verifyPresent();
		quickfinder.getQuickFinderAddtoList("1").verifyPresent();
		if (quickfinder.getQuickFinderAddtoRecipebox("1").isPresent()) {
			quickfinder.getQuickFinderAddtoRecipebox("1").verifyPresent();
		} else {
			quickfinder.getQuickFinderAddedtoRecipebox("1").verifyPresent();
		}
	}

	@QAFTestStep(description = "I add primo pick recipe ingredients to list")
	public void iCheckAndClickPrimoPicksRecipesAvailable() {
		MyListTestPage mylistTest = new MyListTestPage();
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();
		List<String> strIngList = new ArrayList<String>();

		mylistTest.getMylistLiImgPrimopicks().waitForPresent(5000);
		if (mylistTest.getMylistLiImgPrimopicks().isDisplayed()) {
			mylistTest.getMylistLiImgPrimopicks().click();
			PerfectoUtils.reportMessage("Primo Picks Add to list is Clicked", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Primo Picks Add to list is not Clicked", MessageTypes.Fail);
		}

		recipedetail.getRecipedetailBtnCheckall().waitForPresent(60000);
		recipedetail.getRecipedetailBtnCheckall().verifyPresent();
		recipedetail.getRecipedetailBtnCheckall().click();
		for (QAFWebElement element : recipedetail.getLiLblIngredients()) {
			strIngList.add(element.getText().trim());
		}

		getBundle().setProperty("strIngList", strIngList);
		getBundle().setProperty("ingList", recipedetail.getLiLblIngredients().size());

		recipedetail.getRecipedetailBtnAddtolist().click();
		recipedetail.getRecipedetailLblMylist().waitForPresent(50000);

	}

	@QAFTestStep(description = "I click Add to recipe box from Quick Recipe finder search results page")
	public void iClickAddtorecipeboxFromQuickRecipefinder_searchresultspage() {
		iSelectBreakfastOrBrunchWithFruit();
		iClickOnSearchButton();
		iSeeSearchResultPage();
		QuickfinderTestPage quickfinder = new QuickfinderTestPage();
		PerfectoUtils.scrolltoelement(quickfinder.getQuickFinderAddtoRecipebox("1"));
		quickfinder.getQuickFinderAddtoRecipebox("1").verifyPresent();
		quickfinder.getQuickFinderAddtoRecipebox("1").click();
		PerfectoUtils.reportMessage("Clicked 'Add to recipe box' from Quick Recipe finder search results page",
				MessageTypes.Info);
	}

	@QAFTestStep(description = "I Add and Verify Add to Recipe Box from Quick Recipe finder search results page")
	public void iAddandVerifyAddtorecipeboxFromQuickRecipefinder_searchresultspage() {
		QuickfinderTestPage quickfinder = new QuickfinderTestPage();
		String itemlistno = "1";
		for (int i = 1; i <= 32; i++) {
			if (quickfinder.getQuickFinderAddtoRecipebox(Integer.toString(i)).isPresent()) {
				itemlistno = Integer.toString(i);
				break;
			}
		}
		PerfectoUtils.scrolltoelement(quickfinder.getQuickFinderAddtoRecipebox(itemlistno));
		quickfinder.getQuickFinderAddtoRecipebox(itemlistno).verifyPresent();
		quickfinder.getQuickFinderAddtoRecipebox(itemlistno).click();
		PerfectoUtils.reportMessage("Clicked 'Add to recipe box' from Quick Recipe finder search results page",
				MessageTypes.Pass);
		quickfinder.getQuickFinderAddtoRecipeboxAllOption(itemlistno).click();
		if (quickfinder.getQuickFinderAddedtoRecipebox(itemlistno).isPresent()) {
			PerfectoUtils.reportMessage("Recipe got added to Recipe box", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Recipe not added to Recipe box", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I click Add to List from Quick Recipe finder search results page")
	public void iClickAddtoListFromQuickRecipefinder_searchresultspage() {
		QuickfinderTestPage quickfinder = new QuickfinderTestPage();
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();
		PerfectoUtils.scrolltoelement(quickfinder.getQuickFinderAddtoList("1"));
		quickfinder.getQuickFinderAddtoList("1").verifyPresent();
		quickfinder.getQuickFinderAddtoList("1").click();
		PerfectoUtils.reportMessage("Clicked 'Add to List' from Quick Recipe finder search results page",
				MessageTypes.Info);
		recipedetail.getRecipedetailBtnCheckall().waitForPresent(20000);
		recipedetail.getRecipedetailBtnCheckall().verifyPresent();
		PerfectoUtils.scrolltoelement(recipedetail.getRecipedetailGetChkChkbox("1"));
		recipedetail.getRecipedetailGetChkChkbox("1").click();
		String selectedChkBox = recipedetail.getRecipedetailGetLblChkboxtext("1").getText();
		String[] selectedChkBoxSplit = selectedChkBox.split(" ");
		int splitUbound = selectedChkBoxSplit.length - 1;
		PerfectoUtils.scrolltoelement(recipedetail.getRecipedetailBtnAddtolist());
		recipedetail.getRecipedetailBtnAddtolist().click();
		recipedetail.getRecipedetailLblMylist().waitForPresent(20000);

		verifyItemsInMiniList("Recipes");
	}

	@QAFTestStep(description = "I Login with {0} {1} credentials")
	public void iLoginWithCredentialsfromQuickRecipefinder_searchresultspage(String email, String password) {
		HomePage home = new HomePage();
		myaccountpage myAcc = new myaccountpage();

		myAcc.iEnteremailandpassword(email, password);
		myAcc.iClickonLoginbutton();
		myAcc.iSeetheuserisloggedin();
	}

	@QAFTestStep(description = "I verify Registration Completed")
	public void iVerifyRegistrationCompleted() {
		ThankYouTestPage thankYou = new ThankYouTestPage();
		InStoreHomePage inStoredoor = new InStoreHomePage();
		thankYou.getThnkuBtnSaveButton().waitForPresent(3000);
		thankYou.getThnkuBtnSaveButton().verifyPresent();
		thankYou.getThnkuBtnSaveButton().click();

		inStoredoor.getHomeLblUserdetail().waitForPresent(5000);
		String howdy = inStoredoor.getHomeLblUserdetail().getText();
		if (howdy.contains("Howdy")) {
			PerfectoUtils.reportMessage("User is sucessfully Registered", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User is not Registered", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I click Log in button under Create a RecipeBox tag with {0} {1} credentials")
	public void iLoginWithCredentialsUnderCreateARecipeBoxTag(String email, String password) {
		RecipelandingTestPage recipelandingpage = new RecipelandingTestPage();
		HomePage home = new HomePage();
		myaccountpage myAcc = new myaccountpage();
		recipelandingpage.getLnkLoginUnderCreateRecipeBox().verifyPresent();
		recipelandingpage.getLnkLoginUnderCreateRecipeBox().click();
		PerfectoUtils.reportMessage("Clicked 'LogIn' link under Create a RecipeBox tag", MessageTypes.Info);
		myAcc.iEnteremailandpassword(email, password);
		myAcc.iClickonLoginbutton();
		myAcc.iSeetheuserisloggedin();
	}

	@QAFTestStep(description = "I click Create An Account button under Create a RecipeBox tag")
	public void iClickCreateAnAccountButtonUnderCreateARecipeBoxTag() {
		RecipelandingTestPage recipelandingpage = new RecipelandingTestPage();
		LoginTestPage loginpage = new LoginTestPage();
		RegistrationTestPage registration = new RegistrationTestPage();
		recipelandingpage.getBtnCreateAnAccUnderCreateRecipeBox().verifyPresent();
		recipelandingpage.getBtnCreateAnAccUnderCreateRecipeBox().click();
		PerfectoUtils.reportMessage("Clicked 'Create An Account' button under Create a RecipeBox tag",
				MessageTypes.Info);
		registration.getRgstrEdtFirstname().waitForPresent(30000);
	}

	@QAFTestStep(description = "I validate rating in CDP PDP page of Recipes")
	public void iValidateRatinginCDPPDPpageofRecipes() {
		RecipelandingTestPage recipeCDP = new RecipelandingTestPage();
		PdtsearchresultTestPage pdtsearchresults = new PdtsearchresultTestPage();
		PerfectoUtils.scrolltoelement(recipeCDP.getLblRatingRecipeSpecs());
		recipeCDP.getLblRatingRecipeSpecs().verifyPresent();
		int recipeRatingCountCDP = recipeCDP.getLstRatingRecipeSpecs().size();
		recipeCDP.getRecipeLnkRecipename().click();
		pdtsearchresults.getLblPDPRatingContainer().verifyPresent();
		int ratingCountPDP = pdtsearchresults.getLstPDPRatingContainer().size();
		if (ratingCountPDP == recipeRatingCountCDP) {
			PerfectoUtils.reportMessage("Rating Count from PDP'" + ratingCountPDP + "' matches the Rating Count of CDP",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Rating Count from PDP'" + ratingCountPDP
					+ "' does not matches the Rating Count of CDP " + recipeRatingCountCDP, MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I validate the reviews of recipe/products in details page")
	public void iValidateTheReviewsOfRecipe() {
		RecipedetailTestpage recipedetails = new RecipedetailTestpage();

		recipedetails.getRecipedetailTxtReviewtitle().verifyPresent();
		PerfectoUtils.scrolltoelement(recipedetails.getRecipedetailTxtReviewtitle());

		int reviewBlockSize = recipedetails.getRecipedetailLiBoxReviewblocks().size();

		if (reviewBlockSize > 0) {
			PerfectoUtils.reportMessage(reviewBlockSize + " reviews found..", MessageTypes.Pass);

			boolean reviewLabelDisplayed = true;
			int reviewLabelSize = recipedetails.getRecipedetailLiImgReviewlabels().size();

			if (reviewLabelSize > 0) {
				reviewLabelDisplayed = true;
			} else {
				reviewLabelDisplayed = false;
				PerfectoUtils.reportMessage("Review label is not available, hence sorting");
				int reviews = Integer.parseInt(
						PerfectoUtils.getIntCharacters(recipedetails.getRecipedetailLblNoofreviews().getText()));
				if (reviews > 0) {
					PerfectoUtils.scrolltoelement(recipedetails.getRecipedetailBtnSortby());
					recipedetails.waitForPageToLoad();
					recipedetails.waitForAjaxToComplete();
					PerfectoUtils.dropdownSelectByIndex(recipedetails.getRecipedetailBtnSortby(), 2);
				}
				recipedetails.waitForAjaxToComplete();
				reviewLabelSize = recipedetails.getRecipedetailLiImgReviewlabels().size();

				if (reviewLabelSize > 0) {
					reviewLabelDisplayed = true;
				} else {
					PerfectoUtils.reportMessage("Review label is not availble after sorting too");
				}
			}

			if (reviewLabelDisplayed) {
				for (int i = 0; i < recipedetails.getRecipedetailLiBoxReviewblocks().size(); i++) {
					RecipeReviews review = recipedetails.getRecipedetailLiBoxReviewblocks().get(i);
					if (!(review.getRecipedetailLiImgReviewlabels().size() == 0)) {
						int labelSize = review.getRecipedetailLiImgReviewlabels().size();
						PerfectoUtils.reportMessage(
								"Review " + i + " contains " + labelSize + " Review labels such as: ",
								MessageTypes.Pass);

						for (int j = 0; j < labelSize; j++) {
							PerfectoUtils.reportMessage(review.getRecipedetailLiImgReviewlabels().get(j).getText());
						}
					}
				}
			}

		} else {
			PerfectoUtils.reportMessage("No reviews found..", MessageTypes.Fail);
		}

	}
	
	@QAFTestStep(description = "Verify Edit Nickname in reviews")
	public void iVerifyEditNicknameinreviews() {
		RecipedetailTestpage recipedetails = new RecipedetailTestpage();

		recipedetails.getRecipedetailTxtReviewtitle().verifyPresent();
		PerfectoUtils.scrolltoelement(recipedetails.getRecipedetailTxtReviewtitle());

		int reviewBlockSize = recipedetails.getRecipedetailLiBoxReviewblocks().size();

		if (reviewBlockSize > 0) {
			PerfectoUtils.reportMessage(reviewBlockSize + " reviews found..", MessageTypes.Pass);
			recipedetails.getRecipedetailLnkEditNickname().click();
			recipedetails.getRecipedetailTxtEditNickname().sendKeys(getBundle().getString("recipes.nickname"));
			recipedetails.getRecipedetailBtnEditNicknameSave().click();
			String actualNickname = recipedetails.getRecipedetailLblEditNickname().getText();
			if(actualNickname.equals(getBundle().getString("recipes.nickname"))){
				PerfectoUtils.reportMessage(actualNickname + " updated", MessageTypes.Pass);
			}else{
				PerfectoUtils.reportMessage(getBundle().getString("recipes.nickname") + " not updated", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("No reviews found..", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Adding more than {0} different recipe ingredient items to list")
	public void addingMoreThanDifferentRecipeIngredientItemsToList() {
		RecipelandingTestPage recipeCDP = new RecipelandingTestPage();
		MyListTestPage mylisttestpage = new MyListTestPage();
		InStoreHomePage instorehome = new InStoreHomePage();

		recipeCDP.getRecipeLblTopratedrecipe().verifyPresent();
		String listItemCount = "0";

		for (int i = 1; Integer.parseInt(listItemCount) <= 400 || i <= 3; i++) {

			// Navigate to next section
			recipeCDP.getBtnRecipesSectionWithId(i).verifyPresent();
			recipeCDP.getBtnRecipesSectionWithId(i).click();

			// recipeCDP.getBtnLoadmoreitems().verifyPresent();
			// recipeCDP.getBtnLoadmoreitems().click();

			int recipeCount = recipeCDP.getListAddtolist().size();

			for (int j = 0; j < recipeCount || Integer.parseInt(listItemCount) <= 400; j++) {

				recipeCDP.waitForAjaxToComplete();
				PerfectoUtils.scrolltoelement(recipeCDP.getListAddtolist().get(j));
				recipeCDP.getListAddtolist().get(j).verifyPresent();
				recipeCDP.getListAddtolist().get(j).click();

				recipeCDP.waitForAjaxToComplete();
				try {
					recipeCDP.getRecipesBtnCheckAll().click();
					recipeCDP.getRecipesBtnAddtoList().click();

					recipeCDP.waitForAjaxToComplete();
					recipeCDP.getRecipesLblMiniShoppingList().waitForPresent(3000);
					recipeCDP.getRecipesBtnAddtolistcollapse().click();
				} catch (Exception e) {
					recipeCDP.getRecipesBtnAddTolistCollapse1().click();
				}

				if (Integer.parseInt(listItemCount) > 390) {
					PerfectoUtils.reportMessage("List Item Count: " + listItemCount);
					// mylisttestpage.getLblExceedError().verifyPresent();
				}

				if (j == recipeCount - 1) {
					recipeCDP.getBtnLoadmoreitems().verifyPresent();
					recipeCDP.getBtnLoadmoreitems().click();
				}

				PerfectoUtils.scrolltoelement(instorehome.getHomeLblShoppinglistfromheader());
				PerfectoUtils.mouseover(instorehome.getHomeLblShoppinglistfromheader());
				listItemCount = mylisttestpage.getMylistLblItemcountmouseover().getText();
				PerfectoUtils.reportMessage("List Item Count: " + listItemCount);
			}

		}
	}

	@QAFTestStep(description = "I add recipe ingredients to shopping list from recipe detail page")
	public void iAddRecipeIngredientsToShoppingListFromRecipeDetailPage() {
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();
		List<String> strIngList = new ArrayList<String>();

		int ingList = recipedetail.getLiLblIngredients().size();
		getBundle().setProperty("ingList", ingList);

		for (QAFWebElement ingredients : recipedetail.getLiLblIngredients()) {
			strIngList.add(ingredients.getText().trim());
		}

		getBundle().setProperty("strIngList", strIngList);

		recipedetail.getRecipedetailBtnCheckall().verifyPresent();
		recipedetail.getRecipedetailBtnCheckall().click();
		recipedetail.getRecipedetailBtnAddtolist().verifyPresent();
		recipedetail.getRecipedetailBtnAddtolist().click();
		PerfectoUtils.reportMessage("Add to list button is clicked");

	}

	@QAFTestStep(description = "I add a recipe ingredient to shopping list from Search page")
	public void iAddARecipeIngredientsToShoppingListFromSearchPage() {
		RecipedetailTestpage recipedetail = new RecipedetailTestpage();
		PdtsearchresultTestPage search = new PdtsearchresultTestPage();
		MiniListTestPage minilist = new MiniListTestPage();
		List<String> strIngList = new ArrayList<String>();

		search.getLnkRcipeaddtolist().verifyPresent();
		search.getLnkRcipeaddtolist().click();

		recipedetail.getRecipedetailBtnCheckall().waitForPresent(60000);
		recipedetail.getRecipedetailBtnCheckall().verifyPresent();
		recipedetail.getRecipedetailGetChkChkbox("1").click();
		String selectedChkBox = recipedetail.getRecipedetailGetLblChkboxtext("1").getText();
		strIngList.add(selectedChkBox);
		getBundle().setProperty("strIngList", strIngList);
		getBundle().setProperty("ingList", 1);

		recipedetail.getRecipedetailBtnAddtolist().click();
		minilist.getLblPagetitle().waitForPresent(50000);

		// Verify the recipes in Mini list
		verifyItemsInMiniList("Recipes");

	}

	@QAFTestStep(description = "I click on print icon")
	public void iClickOnPrintIcon() {
		RecipedetailTestpage recipedetails = new RecipedetailTestpage();

		String parentWindow = PerfectoUtils.getDriver().getWindowHandle();
		getBundle().setProperty("parentWindow", parentWindow);

		String url = PerfectoUtils.getDriver().getCurrentUrl();
		String[] urlArray = url.split("/");
		getBundle().setProperty("recipes.print.recipeid", urlArray[urlArray.length - 1]);

		recipedetails.getRecipedetailLblPrint().verifyPresent();
		recipedetails.getRecipedetailLblPrint().click();
		PerfectoUtils.reportMessage("Clicked on print icon");
	}

	@QAFTestStep(description = "I verify print preview page is displayed")
	public void iVerifyPrintPreviewPageIsDisplayed() {

		String parentWindow = getBundle().getString("parentWindow");
		for (String window : PerfectoUtils.getDriver().getWindowHandles()) {
			if (!window.equalsIgnoreCase(parentWindow)) {
				PerfectoUtils.getDriver().switchTo().window(window);
			}
		}

		String url = PerfectoUtils.getDriver().getCurrentUrl();

		System.out.println(getBundle().getString("recipes.printpage"));

		if (url.equalsIgnoreCase(getBundle().getString("recipes.printpage"))) {
			PerfectoUtils.reportMessage("Print page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Print page is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I click on email icon")
	public void iClickOnEmailIcon() {
		RecipedetailTestpage recipedetails = new RecipedetailTestpage();

		recipedetails.getRecipedetailLblEmail().verifyPresent();
		recipedetails.getRecipedetailLblEmail().click();
		PerfectoUtils.reportMessage("Clicked on Email icon");
	}

	@QAFTestStep(description = "I verify email template is displayed")
	public void iVerifyEmailTemplateIsDisplayed() {
		EmailTemplateTestPage email = new EmailTemplateTestPage();

		email.getEmailLblHeader().waitForPresent(5000);
		email.getEmailLblHeader().verifyPresent();
		email.getEmailBtnSendemail().verifyPresent();
		email.getEmailEdtRecipentemails().verifyPresent();
		email.getEmailEdtYouremail().verifyPresent();
		email.getEmailEdtYourname().verifyPresent();
		email.getEmailChkSendmecopy().verifyPresent();
		PerfectoUtils.getDriver().switchTo().frame(email.getEmailIframeIamnotrobot());
		email.getEmailRbtIamnotrobot().verifyPresent();

	}

	@QAFTestStep(description = "I sort the recipes as {0} and Validate the recipes are sorted")
	public void iSortTheRecipesAsAndValidateTheRecipesAreSorted(String sortOrder) {
		RecipecategorydetailaTestPage recipeCDP = new RecipecategorydetailaTestPage();
		ArrayList<String> al = new ArrayList<String>();
		boolean isDecending = false;

		recipeCDP.getLblSortby().verifyPresent();
		PerfectoUtils.dropdownSelectByVisibleText(recipeCDP.getTxtSortbydropdown(), sortOrder);
		recipeCDP.waitForAjaxToComplete();

		for (RecipeItems recipes : recipeCDP.getRecipecdpListRecipeitems()) {
			al.add(recipes.getRecipecdpLblRecipename().getText());
		}

		for (int i = 0; i < al.size() - 1; i++) {
			if (al.get(i).compareTo(al.get(i + 1)) > 0) {
				System.out.println(al.get(i) + " ; " + al.get(i + 1) + " ; " + al.get(i).compareTo(al.get(i + 1)));
				isDecending = true;
			} else {
				isDecending = false;
				break;
			}
		}

		if (isDecending) {
			PerfectoUtils.reportMessage("Recipes are sorted in decending order", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Recipes are not sorted in decending order", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I navigate to Cooking Video details page {0} by clicking View Videos")
	public void iNavigateToCookingVideoDetailsPageByClickingViewVideos(String videoname) {
		CookingconnectionTestPage cookingconnection = new CookingconnectionTestPage();
		CookingVideodetailsTestPage cookingvideodetails = new CookingVideodetailsTestPage();
		PerfectoUtils.scrolltoelement(cookingconnection.getCookingconnectionViewVideos(videoname));
		cookingconnection.getCookingconnectionViewVideos(videoname).waitForPresent(5000);

		getBundle().setProperty("cookingVideoLink",
				cookingconnection.getCookingconnectionUniqueVideos(videoname).getAttribute("href"));
		cookingconnection.getCookingconnectionViewVideos(videoname).click();

		if (cookingvideodetails.getCookingconnectionVideoHeader(videoname).isPresent()) {
			PerfectoUtils.reportMessage("Navigated to cooking video details page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to cooking video details page.", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I validate the Meal type dropdown options")
	public void iValidateTheMealTypeDropdownOptions() {
		RecipelandingTestPage landing = new RecipelandingTestPage();
		List<String> setOptions = new ArrayList<String>();
		List<String> expOptions = getBundle().getList("recipes.mealtype.options");

		landing.getBtnMealtypedropdown().verifyPresent();

		Select select = new Select(landing.getBtnMealtypedropdown());

		for (WebElement options : select.getOptions()) {
			setOptions.add(options.getText());
		}

		if (expOptions.equals(setOptions)) {
			PerfectoUtils.reportMessage("All the options of MealType dropdown is present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("All the options of MealType dropdown is not present", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I click on social icons and validate the corresponding pages are displayed")
	public void iClickOnSocialIconsAndValidateTheCorrespondingPagesAreDisplayed() {
		RecipedetailTestpage recipedetails = new RecipedetailTestpage();

		recipedetails.getRecipedetailBtnPinit().verifyPresent();
		String parent = PerfectoUtils.getDriver().getWindowHandle();

		recipedetails.getRecipedetailBtnPinit().click();
		for (String windows : PerfectoUtils.getDriver().getWindowHandles()) {
			if (!windows.equals(parent)) {
				PerfectoUtils.getDriver().switchTo().window(windows);
				if (PerfectoUtils.getDriver().getCurrentUrl().contains("pinterest.com"))
					PerfectoUtils.reportMessage("Pinterest site is displayed", MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("Pinterest site is not displayed", MessageTypes.Fail);

				PerfectoUtils.getDriver().close();
				PerfectoUtils.getDriver().switchTo().window(parent);
				break;
			}
		}

		recipedetails.getRecipedetailBtnTweet().click();
		for (String windows : PerfectoUtils.getDriver().getWindowHandles()) {
			if (!windows.equals(parent)) {
				PerfectoUtils.getDriver().switchTo().window(windows);
				if (PerfectoUtils.getDriver().getCurrentUrl().contains("twitter.com"))
					PerfectoUtils.reportMessage("Twitter site is displayed", MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("Twitter site is not displayed", MessageTypes.Fail);

				PerfectoUtils.getDriver().close();
				PerfectoUtils.getDriver().switchTo().window(parent);
				break;
			}
		}
	}

	@QAFTestStep(description = "I validate the main ingredient dropdown options")
	public void iValidateTheMainIngredientDropdownOptions() {
		QuickfinderTestPage quickfinder = new QuickfinderTestPage();
		List<String> setOptions = new ArrayList<String>();
		List<String> expOptions = getBundle().getList("recipes.mainIngredient.options");

		quickfinder.getQuickfinderTxtOptiontwo().verifyPresent();

		Select select = new Select(quickfinder.getQuickfinderTxtOptiontwo());

		for (WebElement options : select.getOptions()) {
			setOptions.add(options.getText());
		}

		if (expOptions.equals(setOptions)) {
			PerfectoUtils.reportMessage("All the options of Main Ingredient dropdown is present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("All the options of  Main Ingredient dropdown is not present",
					MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I select a recipe and navigate to recipe detail page")
	public void iSelectARecipeAndNavigateToRecipeDetailPage() {
		PdtsearchresultTestPage search = new PdtsearchresultTestPage();
		RecipedetailTestpage recipedetails = new RecipedetailTestpage();

		search.getLnkFfirstRecipeItem().verifyPresent();
		search.getLnkFfirstRecipeItem().click();
		recipedetails.getRecipedetailLblRecipename().waitForPresent(5000);
		recipedetails.getRecipedetailLblPreptime().verifyPresent();
		recipedetails.getRecipedetailLblCooktime().verifyPresent();

	}

	@QAFTestStep(description = "I verify the Cook time in RDP is {0}")
	public void iVerifyTheCookTimeInRDPIs(String cookTime) {
		RecipedetailTestpage recipedetails = new RecipedetailTestpage();

		recipedetails.getRecipedetailLblCooktimevalue().verifyPresent();
		recipedetails.getRecipedetailLblCooktimevalue().verifyText(cookTime);
	}

	@QAFTestStep(description = "I navigate to List view page and validate the Total time format")
	public void iNavigateToListViewPageAndValidateTheTotalCookTimeFormat() {
		RecipecategorydetailaTestPage recipeCDP = new RecipecategorydetailaTestPage();
		boolean isCorrectFormat = false;

		recipeCDP.getLblRecipelistview().verifyPresent();
		recipeCDP.getLblRecipelistview().click();

		recipeCDP.getLblTotalorcooktime().get(0).verifyPresent();

		for (QAFWebElement element : recipeCDP.getLblTotalorcooktime()) {
			String cookTime = element.getText();

			if (cookTime.contains("Total Time:"))
				cookTime = cookTime.replace("Total Time:", "").trim();
			else if (cookTime.contains("Cook Time:"))
				cookTime = cookTime.replace("Cook Time:", "").trim();

			if (cookTime.contains("minutes")) {
				cookTime = cookTime.replace("minutes", "").trim();
				if (Integer.parseInt(cookTime) < 60)
					isCorrectFormat = true;
				else
					isCorrectFormat = false;
			} else if (cookTime.contains("N/A")) {
				isCorrectFormat = true;
			} else if (cookTime.contains("hour")) {
				isCorrectFormat = Pattern.matches("^\\d+\\shour(s)?", cookTime);
			} else {
				System.out.println(cookTime);
				isCorrectFormat = Pattern.matches("^\\d+\\sh\\s\\d+\\sm", cookTime);
				System.out.println(isCorrectFormat);
			}

			if (!isCorrectFormat)
				break;
		}

		if (isCorrectFormat)
			PerfectoUtils.reportMessage("Cook time format is validated for all listed recipes", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Cook time format is not validated for all listed recipes", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I navigate to List view page and validate the Cook time format")
	public void iNavigateToListViewPageAndValidateTheCookTimeFormat() {
		RecipecategorydetailaTestPage recipeCDP = new RecipecategorydetailaTestPage();
		boolean isCorrectFormat = false;

		recipeCDP.getLblRecipelistview().verifyPresent();
		recipeCDP.getLblRecipelistview().click();

		recipeCDP.getLblTotalorcooktime().get(0).verifyPresent();

		for (QAFWebElement element : recipeCDP.getLblTotalorcooktime()) {
			String cookTime = element.getText();

			cookTime = cookTime.substring(cookTime.indexOf("Cook Time:"), cookTime.indexOf("Serves"));
			System.out.println(cookTime);
			cookTime = cookTime.replace("Cook Time:", "").trim();

			if (cookTime.contains("minutes")) {
				isCorrectFormat = Pattern.matches("^\\d{2}\\sminute(s)?", cookTime);

				cookTime = cookTime.replace("minutes", "").trim();
				if (Integer.parseInt(cookTime) < 60)
					isCorrectFormat = true;
				else
					isCorrectFormat = false;
			} else if (cookTime.contains("minute")) {
				isCorrectFormat = Pattern.matches("^\\d{2}\\sminute", cookTime);

				cookTime = cookTime.replace("minute", "").trim();
				if (Integer.parseInt(cookTime) < 60)
					isCorrectFormat = true;
				else
					isCorrectFormat = false;
			} else if (cookTime.contains("N/A")) {
				isCorrectFormat = true;
			} else if (cookTime.contains("hours")) {
				isCorrectFormat = Pattern.matches("^\\d+\\shour(s)?", cookTime);
			} else if (cookTime.contains("hour")) {
				isCorrectFormat = Pattern.matches("^\\d+\\shour(s)?", cookTime);
			} else {
				System.out.println(cookTime);
				isCorrectFormat = Pattern.matches("^\\d+\\sh\\s\\d+\\sm", cookTime);
				System.out.println(isCorrectFormat);
			}

			if (!isCorrectFormat)
				break;
		}

		if (isCorrectFormat)
			PerfectoUtils.reportMessage("Cook time format is validated for all listed recipes", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Cook time format is not validated for all listed recipes", MessageTypes.Fail);
	}
}
