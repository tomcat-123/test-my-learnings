package com.automation.web.pages.aboutus;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class AboutUsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "abtus.lbl.pagetitle")
	private QAFWebElement lblPagetitle;

	@FindBy(locator = "abtus.lnk.environment")
	private QAFWebElement lnkEnvironment;

	public QAFWebElement getLblPagetitle() {
		return lblPagetitle;
	}

	public QAFWebElement getLnkEnvironment() {
		return lnkEnvironment;
	}

}