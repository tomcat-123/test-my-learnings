package com.automation.web.pages.myList;

import java.util.List;

import com.automation.web.components.ShoppingLists.ManageListsBlocks;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MyListTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "mylist.lbl.banner")
	private QAFWebElement mylistLblBanner;

	@FindBy(locator = "mylist.lnk.bannerclose")
	private QAFWebElement mylistLnkBannerclose;

	@FindBy(locator = "mylist.lnk.watchthehowtovideo")
	private QAFWebElement mylistLnkWatchthehowtovideo;

	@FindBy(locator = "mylist.img.watchthehowtovideoexpandedsection")
	private QAFWebElement mylistImgWatchthehowtovideoexpandedsection;

	@FindBy(locator = "mylist.lbl.totalitemcount")
	private QAFWebElement mylistLblTotalitemcount;

	@FindBy(locator = "mylist.li.img.listitemdelete")
	private List<QAFWebElement> mylistLiImgListitemdelete;

	@FindBy(locator = "mylist.li.lbl.listitems")
	private List<QAFWebElement> mylistLiLblListitems;

	@FindBy(locator = "mylist.lnk.print")
	private QAFWebElement mylistLnkPrint;

	@FindBy(locator = "mylist.lbl.liketoprint")
	private QAFWebElement mylistLblLikeToPrint;

	@FindBy(locator = "mylist.btn.print")
	private QAFWebElement mylistBtnPrint;

	@FindBy(locator = "mylist.lnk.close")
	private QAFWebElement mylistLnkClose;

	@FindBy(locator = "mylist.lbl.minilist")
	private QAFWebElement mylistLblMinilist;

	@FindBy(locator = "mylist.lnk.nextpage")
	private QAFWebElement mylistLnkNextPage;

	@FindBy(locator = "mylist.lbl.myshoppinglistcount")
	private QAFWebElement myShoppingListCount;

	@FindBy(locator = "mylist.lnk.viewallproductresults")
	private QAFWebElement lnkViewAllProductResults;

	@FindBy(locator = "mylist.lbl.mylist")
	private QAFWebElement mylistLblMylist;

	@FindBy(locator = "mylist.li.lbl.minilistitemnamedynamic")
	private List<QAFWebElement> mylistLiLblMinilistitemnamedynamic;

	@FindBy(locator = "mylist.edt.mylisttextbox")
	private QAFWebElement mylistEdtMylisttextbox;

	@FindBy(locator = "mylist.btn.mylistaddtolist")
	private QAFWebElement mylistBtnMylistaddtolist;

	@FindBy(locator = "mylist.lbl.mylistaddareceipt")
	private QAFWebElement mylistLblMylistaddareceipt;

	@FindBy(locator = "mylist.lbl.minilistitemdescription")
	private QAFWebElement mylistLblMinilistitemdescription;

	@FindBy(locator = "mylist.btn.minilistclosewindowbutton")
	private QAFWebElement mylistBtnMinilistclosewindowbutton;

	@FindBy(locator = "mylist.btn.savebuttontogologinpage")
	private QAFWebElement mylistBtnSavebuttontogologinpage;

	@FindBy(locator = "mylist.lnk.recommendedaddtolist")
	private QAFWebElement mylistLnkRecommendedaddtolist;

	@FindBy(locator = "mylist.lbl.recommendedproductname")
	private QAFWebElement mylistLblRecommendedproductname;

	@FindBy(locator = "mylist.lbl.productnamefromshoppinglist")
	private QAFWebElement mylistLblProductnamefromshoppinglist;

	@FindBy(locator = "mylist.li.lbl.addedlistfromdrpdown")
	private List<QAFWebElement> mylistLiLblAddedlistfromdrpdown;

	@FindBy(locator = "mylist.dpd.shoppinglist")
	private QAFWebElement mylistDpdShoppinglist;

	@FindBy(locator = "mylist.link.changeprofilestr")
	private QAFWebElement mylistLinkChangeprofilestr;

	@FindBy(locator = "mylist.lbl.changestroverlay")
	private QAFWebElement mylistLblChangestroverlay;

	@FindBy(locator = "mylist.lbl.zipcodeinput")
	private QAFWebElement mylistLblZipcodeinput;

	@FindBy(locator = "mylist.btn.gobtn")
	private QAFWebElement mylistBtnGobtn;

	@FindBy(locator = "mylist.btn.selectstr")
	private QAFWebElement mylistBtnSelectstr;

	@FindBy(locator = "mylist.lbl.strname")
	private QAFWebElement mylistLblStrname;

	@FindBy(locator = "mylist.lbl.myliststorename")
	private QAFWebElement mylistLblMyliststorename;

	@FindBy(locator = "mylist.lbl.productcatalog")
	private QAFWebElement mylistLblProductcatalog;

	@FindBy(locator = "mylist.lnk.category1")
	private QAFWebElement mylistLnkCategory1;

	@FindBy(locator = "mylist.btn.createnewlistbtn")
	private QAFWebElement mylistBtnCreatenewlistbtn;

	@FindBy(locator = "mylist.lbl.defaultlist")
	private QAFWebElement mylistLblDefaultlist;

	@FindBy(locator = "mylist.lbl.weeklyad")
	private QAFWebElement mylistLblWeeklyad;

	@FindBy(locator = "mylist.lbl.coupons")
	private QAFWebElement mylistLblCoupons;

	@FindBy(locator = "mylist.lbl.recipe")
	private QAFWebElement mylistLblRecipe;

	@FindBy(locator = "mylist.lbl.primopick")
	private QAFWebElement mylistLblPrimopick;

	@FindBy(locator = "mylist.lbl.primopicktitle")
	private QAFWebElement mylistLblPrimopicktitle;

	@FindBy(locator = "mylist.lnk.freeformitem")
	private QAFWebElement mylistLnkFreeformitem;

	@FindBy(locator = "mylist.lnk.upcitem")
	private QAFWebElement mylistLnkUpcitem;

	@FindBy(locator = "mylist.lbl.freeformitemname")
	private QAFWebElement mylistLblFreeformitemname;

	@FindBy(locator = "mylist.lbl.upcitemname")
	private QAFWebElement mylistLblUpcitemname;

	@FindBy(locator = "mylist.lbl.catalogitems")
	private QAFWebElement mylistLblCatalogitems;

	@FindBy(locator = "mylist.li.lbl.dynamicproduct")
	private List<QAFWebElement> mylistLiLblDynamicproduct;

	@FindBy(locator = "mylist.lbl.unknownlocationitmname")
	private QAFWebElement mylistLblUnknownlocationitmname;

	@FindBy(locator = "mylist.txt.receiptadd")
	private QAFWebElement mylistTxtReceiptadd;

	@FindBy(locator = "mylist.btn.addreceipttolist")
	private QAFWebElement mylistBtnAddreceipttolist;

	@FindBy(locator = "mylist.lnk.managelistmouseover")
	private QAFWebElement mylistLnkManagelistmouseover;

	@FindBy(locator = "mylist.lbl.usernamelist")
	private QAFWebElement mylistLblUsernamelist;

	@FindBy(locator = "mylist.lbl.managelistname1")
	private QAFWebElement mylistLblManagelistname1;

	@FindBy(locator = "mylist.chk.managelistcheckbox1")
	private QAFWebElement mylistChkManagelistcheckbox1;

	@FindBy(locator = "mylist.chk.managelistcheckbox2")
	private QAFWebElement mylistChkManagelistcheckbox2;

	@FindBy(locator = "mylist.chk.managelistcheckbox3")
	private QAFWebElement mylistChkManagelistcheckbox3;

	@FindBy(locator = "mylist.btn.saveacopy")
	private QAFWebElement mylistBtnSaveacopy;

	@FindBy(locator = "mylist.btn.combinelist")
	private QAFWebElement mylistBtnCombinelist;

	@FindBy(locator = "mylist.btn.deletelist")
	private QAFWebElement mylistBtnDeletelist;

	@FindBy(locator = "mylist.btn.deleteyes")
	private QAFWebElement mylistBtnDeleteyes;

	@FindBy(locator = "mylist.lbl.listflyout")
	private QAFWebElement mylistLblListflyout;

	@FindBy(locator = "mylist.lnk.seeallmouseover")
	private QAFWebElement mylistLnkSeeallmouseover;

	@FindBy(locator = "mylist.lnk.buyitagain")
	private QAFWebElement mylistLnkBuyitagain;

	@FindBy(locator = "mylist.lbl.quickreorder")
	private QAFWebElement mylistLblQuickreorder;

	@FindBy(locator = "mylist.lnk.createnewlistmouseover")
	private QAFWebElement mylistLnkCreatenewlistmouseover;

	@FindBy(locator = "mylist.li.lnk.mouseoverlist")
	private List<QAFWebElement> mylistLiLnkMouseoverlist;

	@FindBy(locator = "mylist.li.img.loadspinner")
	private List<QAFWebElement> mylistLiImgLoadspinner;

	@FindBy(locator = "mylist.lbl.exceederror")
	private QAFWebElement mylistLblExceedError;

	@FindBy(locator = "mylist.lnk.mylist1")
	private QAFWebElement mylistLnkMyList1;

	@FindBy(locator = "mylist.lnk.mylist1pdtdelete")
	private QAFWebElement mylistLnkMyList1PdtDelete;

	@FindBy(locator = "mylist.lbl.itemcountmouseover")
	private QAFWebElement mylistLblItemcountmouseover;

	@FindBy(locator = "mylist.li.box.allmylistitems")
	private List<QAFWebElement> mylistLiBoxAllmylistitems;

	@FindBy(locator = "mylist.lbl.allmylistitems")
	private QAFWebElement mylistLblAllmylistitems;

	@FindBy(locator = "mylist.lnk.gotofullList")
	private QAFWebElement mylistLnkGotofullList;

	@FindBy(locator = "mylist.li.img.primopicks")
	private QAFWebElement mylistLiImgPrimopicks;

	@FindBy(locator = "mylist.li.manageliststimestamp")
	private List<QAFWebElement> liManageliststimestamp;

	@FindBy(locator = "mylist.li.managelistblocks")
	private List<ManageListsBlocks> liManagelistblocks;

	@FindBy(locator = "mylist.lbl.managelistsaveacopyerrormessage")
	private QAFWebElement lblManagelistsaveacopyerrormessage;

	@FindBy(locator = "mylist.li.managelistscheckboxes")
	private List<QAFWebElement> liManagelistscheckboxes;

	@FindBy(locator = "mylist.lbl.itemsinyourlist")
	private QAFWebElement lblItemsinyourlist;

	@FindBy(locator = "mylist.icon.email")
	private QAFWebElement iconEmail;

	@FindBy(locator = "mylist.lbl.shoppingtimestamp")
	private QAFWebElement lblShoppingtimestamp;

	@FindBy(locator = "mylist.btn.savecurrentlistsection")
	private QAFWebElement btnSavecurrentlistsection;

	@FindBy(locator = "mylist.li.box.listitems")
	private List<QAFWebElement> liBoxListitems;

	@FindBy(locator = "mylist.li.lbl.items")
	private List<QAFWebElement> liLblItems;

	@FindBy(locator = "mylist.li.lbl.itemrecipeingredients")
	private List<QAFWebElement> liLblItemrecipeingredients;
	
	@FindBy(locator = "mylist.btn.findrecipesusingthislist")
	private QAFWebElement btnFindrecipesusingthislist;
	
	@FindBy(locator = "mylist.dd.sort")
	private QAFWebElement ddSort;

	public QAFWebElement getMylistLiImgPrimopicks() {
		return mylistLiImgPrimopicks;
	}

	public QAFWebElement getMylistLnkGotofullList() {
		return mylistLnkGotofullList;
	}
	
	public QAFWebElement getDDSort() {
		return ddSort;
	}
	
	public QAFWebElement getMylistBtnFindrecipesusingthislist() {
		return btnFindrecipesusingthislist;
	}

	/**
	 * Textview of Mini List
	 */
	public QAFWebElement getMylistLblMinilist() {
		return mylistLblMinilist;
	}

	/**
	 * Page title of My List
	 */
	public QAFWebElement getMylistLblMylist() {
		return mylistLblMylist;
	}

	/**
	 * TextView for Item name in mini list
	 */
	public List<QAFWebElement> getMylistLiLblMinilistitemnamedynamic() {
		return mylistLiLblMinilistitemnamedynamic;
	}

	/**
	 * Edit view of My List Text Box
	 */
	public QAFWebElement getMylistEdtMylisttextbox() {
		return mylistEdtMylisttextbox;
	}

	/**
	 * Button view of Add to List
	 */
	public QAFWebElement getMylistBtnMylistaddtolist() {
		return mylistBtnMylistaddtolist;
	}

	/**
	 * Text view of add to receipt section
	 */
	public QAFWebElement getMylistLblMylistaddareceipt() {
		return mylistLblMylistaddareceipt;
	}

	/**
	 * Text view for the item description in MiniList
	 */
	public QAFWebElement getMylistLblMinilistitemdescription() {
		return mylistLblMinilistitemdescription;
	}

	/**
	 * Button view of close window in MiniList
	 */
	public QAFWebElement getMylistBtnMinilistclosewindowbutton() {
		return mylistBtnMinilistclosewindowbutton;
	}

	/**
	 * Button view of save to go login page
	 */
	public QAFWebElement getMylistBtnSavebuttontogologinpage() {
		return mylistBtnSavebuttontogologinpage;
	}

	/**
	 * Link view of Add to list from recommended item list
	 */
	public QAFWebElement getMylistLnkRecommendedaddtolist() {
		return mylistLnkRecommendedaddtolist;
	}

	/**
	 * Text view of product name from recommended item list
	 */
	public QAFWebElement getMylistLblRecommendedproductname() {
		return mylistLblRecommendedproductname;
	}

	/**
	 * Text view of product name from shopping list
	 */
	public QAFWebElement getMylistLblProductnamefromshoppinglist() {
		return mylistLblProductnamefromshoppinglist;
	}

	/**
	 * Text view of added list from add to list drop down
	 */
	public List<QAFWebElement> getMylistLiLblAddedlistfromdrpdown() {
		return mylistLiLblAddedlistfromdrpdown;
	}

	/**
	 * Drop down view of shopping list
	 */
	public QAFWebElement getMylistDpdShoppinglist() {
		return mylistDpdShoppinglist;
	}

	/**
	 * LinkView for Change profile store
	 */
	public QAFWebElement getMylistLinkChangeprofilestr() {
		return mylistLinkChangeprofilestr;
	}

	/**
	 * TextView for Change store overlay
	 */
	public QAFWebElement getMylistLblChangestroverlay() {
		return mylistLblChangestroverlay;
	}

	/**
	 * TextBox for Zipcode
	 */
	public QAFWebElement getMylistLblZipcodeinput() {
		return mylistLblZipcodeinput;
	}

	/**
	 * ButtonView for Go
	 */
	public QAFWebElement getMylistBtnGobtn() {
		return mylistBtnGobtn;
	}

	/**
	 * ButtonView for Select store
	 */
	public QAFWebElement getMylistBtnSelectstr() {
		return mylistBtnSelectstr;
	}

	/**
	 * TextView for Store Name
	 */
	public QAFWebElement getMylistLblStrname() {
		return mylistLblStrname;
	}

	/**
	 * TextView for My list store name
	 */
	public QAFWebElement getMylistLblMyliststorename() {
		return mylistLblMyliststorename;
	}

	/**
	 * TextView for Product Catalog
	 */
	public QAFWebElement getMylistLblProductcatalog() {
		return mylistLblProductcatalog;
	}

	/**
	 * LinkView for first category
	 */
	public QAFWebElement getMylistLnkCategory1() {
		return mylistLnkCategory1;
	}

	/**
	 * Button for Create New List
	 */
	public QAFWebElement getMylistBtnCreatenewlistbtn() {
		return mylistBtnCreatenewlistbtn;
	}

	/**
	 * TextView for Default list
	 */
	public QAFWebElement getMylistLblDefaultlist() {
		return mylistLblDefaultlist;
	}

	/**
	 * TextView for Weekly Ad
	 */
	public QAFWebElement getMylistLblWeeklyad() {
		return mylistLblWeeklyad;
	}

	/**
	 * TextView for Coupons
	 */
	public QAFWebElement getMylistLblCoupons() {
		return mylistLblCoupons;
	}

	/**
	 * TextView for Recipe
	 */
	public QAFWebElement getMylistLblRecipe() {
		return mylistLblRecipe;
	}

	/**
	 * TextView for PrimoPick
	 */
	public QAFWebElement getMylistLblPrimopick() {
		return mylistLblPrimopick;
	}

	/**
	 * TextView for Primopick page title
	 */
	public QAFWebElement getMylistLblPrimopicktitle() {
		return mylistLblPrimopicktitle;
	}

	/**
	 * LinkView for Add to list freeform items
	 */
	public QAFWebElement getMylistLnkFreeformitem() {
		return mylistLnkFreeformitem;
	}

	/**
	 * LinkView for Add to list upc item
	 */
	public QAFWebElement getMylistLnkUpcitem() {
		return mylistLnkUpcitem;
	}

	/**
	 * TextView for FreeForm item
	 */
	public QAFWebElement getMylistLblFreeformitemname() {
		return mylistLblFreeformitemname;
	}

	/**
	 * TextView For upc item
	 */
	public QAFWebElement getMylistLblUpcitemname() {
		return mylistLblUpcitemname;
	}

	/**
	 * TextView for Catalog Items
	 */
	public QAFWebElement getMylistLblCatalogitems() {
		return mylistLblCatalogitems;
	}

	/**
	 * Textview for Product Name
	 */
	public List<QAFWebElement> getMylistLiLblDynamicproduct() {
		return mylistLiLblDynamicproduct;
	}

	/**
	 * TextView for unknownlocation item
	 */
	public QAFWebElement getMylistLblUnknownlocationitmname() {
		return mylistLblUnknownlocationitmname;
	}

	/**
	 * TextView for receipt upload
	 */
	public QAFWebElement getMylistTxtReceiptadd() {
		return mylistTxtReceiptadd;
	}

	/**
	 * ButtonView for receipt add to list
	 */
	public QAFWebElement getMylistBtnAddreceipttolist() {
		return mylistBtnAddreceipttolist;
	}

	/**
	 * LinkView for manage list
	 */
	public QAFWebElement getMylistLnkManagelistmouseover() {
		return mylistLnkManagelistmouseover;
	}

	/**
	 * TextView for user name
	 */
	public QAFWebElement getMylistLblUsernamelist() {
		return mylistLblUsernamelist;
	}

	/**
	 * TextView for list 1
	 */
	public QAFWebElement getMylistLblManagelistname1() {
		return mylistLblManagelistname1;
	}

	/**
	 * CheckBox1 view for managelist
	 */
	public QAFWebElement getMylistChkManagelistcheckbox1() {
		return mylistChkManagelistcheckbox1;
	}

	/**
	 * CheckBox2 view for managelist
	 */
	public QAFWebElement getMylistChkManagelistcheckbox2() {
		return mylistChkManagelistcheckbox2;
	}

	/**
	 * CheckBox3 view for managelist
	 */
	public QAFWebElement getMylistChkManagelistcheckbox3() {
		return mylistChkManagelistcheckbox3;
	}

	/**
	 * ButtonView for save a copy
	 */
	public QAFWebElement getMylistBtnSaveacopy() {
		return mylistBtnSaveacopy;
	}

	/**
	 * ButtonView for combine list
	 */
	public QAFWebElement getMylistBtnCombinelist() {
		return mylistBtnCombinelist;
	}

	/**
	 * ButtonView for delete list
	 */
	public QAFWebElement getMylistBtnDeletelist() {
		return mylistBtnDeletelist;
	}

	/**
	 * ButtonView for delete yes
	 */
	public QAFWebElement getMylistBtnDeleteyes() {
		return mylistBtnDeleteyes;
	}

	/**
	 * TextView for list flyout
	 */
	public QAFWebElement getMylistLblListflyout() {
		return mylistLblListflyout;
	}

	/**
	 * LinkView for see all
	 */
	public QAFWebElement getMylistLnkSeeallmouseover() {
		return mylistLnkSeeallmouseover;
	}

	/**
	 * LinkView for buy it again
	 */
	public QAFWebElement getMylistLnkBuyitagain() {
		return mylistLnkBuyitagain;
	}

	/**
	 * LinkView for buy it again
	 */
	public QAFWebElement getMylistLblQuickreorder() {
		return mylistLblQuickreorder;
	}

	/**
	 * LinkView for create new list mouse over
	 */
	public QAFWebElement getMylistLnkCreatenewlistmouseover() {
		return mylistLnkCreatenewlistmouseover;
	}

	/**
	 * LinkView for list mouse over
	 */
	public List<QAFWebElement> getMylistLiLnkMouseoverlist() {
		return mylistLiLnkMouseoverlist;
	}

	/**
	 * ImageView of loading
	 */
	public List<QAFWebElement> getMylistLiImgLoadspinner() {
		return mylistLiImgLoadspinner;
	}

	public QAFWebElement getMyShoppingListCount() {
		return myShoppingListCount;
	}

	public QAFWebElement getLnkViewAllProductResults() {
		return lnkViewAllProductResults;
	}

	public QAFWebElement getAddToList_Product(String linktext) {
		String loc = String.format(pageProps.getString("mylist.get.lnk.addtolist"), linktext);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getLnkNextPage() {
		return mylistLnkNextPage;
	}

	public QAFWebElement getLnkMyList1() {
		return mylistLnkMyList1;
	}

	public QAFWebElement getLblExceedError() {
		return mylistLblExceedError;
	}

	public QAFWebElement getLnkMyList1PdtDelete() {
		return mylistLnkMyList1PdtDelete;
	}

	public QAFWebElement getLnkPrint() {
		return mylistLnkPrint;
	}

	public QAFWebElement getLblLikeToPrint() {
		return mylistLblLikeToPrint;
	}

	public QAFWebElement getBtnPrint() {
		return mylistBtnPrint;
	}

	public QAFWebElement getLnkClose() {
		return mylistLnkClose;
	}

	public QAFWebElement getMylistLblItemcountmouseover() {
		return mylistLblItemcountmouseover;
	}

	public List<QAFWebElement> getMylistLiBoxAllmylistitems() {
		return mylistLiBoxAllmylistitems;
	}

	public QAFWebElement getMylistLblAllmylistitems() {
		return mylistLblAllmylistitems;
	}

	public List<QAFWebElement> getMylistLiLblListitems() {
		return mylistLiLblListitems;
	}

	public List<QAFWebElement> getMylistLiImgListitemdelete() {
		return mylistLiImgListitemdelete;
	}

	public List<QAFWebElement> getLiManageliststimestamp() {
		return liManageliststimestamp;
	}

	public List<ManageListsBlocks> getLiManagelistblocks() {
		return liManagelistblocks;
	}

	public QAFWebElement getLblManagelistsaveacopyerrormessage() {
		return lblManagelistsaveacopyerrormessage;
	}

	public List<QAFWebElement> getLiManagelistscheckboxes() {
		return liManagelistscheckboxes;
	}

	public QAFWebElement getLblItemsinyourlist() {
		return lblItemsinyourlist;
	}

	public QAFWebElement getIconEmail() {
		return iconEmail;
	}

	public QAFWebElement getLblShoppingtimestamp() {
		return lblShoppingtimestamp;
	}

	public QAFWebElement getBtnSavecurrentlistsection() {
		return btnSavecurrentlistsection;
	}

	public QAFWebElement getMylistLblBanner() {
		return mylistLblBanner;
	}

	public QAFWebElement getMylistLnkBannerclose() {
		return mylistLnkBannerclose;
	}

	public QAFWebElement getLnkWatchthehowtovideo() {
		return mylistLnkWatchthehowtovideo;
	}

	public QAFWebElement getImgWatchthehowtovideoexpandedsection() {
		return mylistImgWatchthehowtovideoexpandedsection;
	}

	public QAFWebElement getLblTotalitemcount() {
		return mylistLblTotalitemcount;
	}

	public List<QAFWebElement> getLiBoxListitems() {
		return liBoxListitems;
	}

	public List<QAFWebElement> getLiLblItems() {
		return liLblItems;
	}

	public List<QAFWebElement> getLiLblItemrecipeingredients() {
		return liLblItemrecipeingredients;
	}
	
	public QAFWebElement getListItemName(String lable) {
		String loc = String.format(pageProps.getString("mylist.lnk.listitem"), lable);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getListItemNameDepartment(String lable) {
		String loc = String.format(pageProps.getString("mylist.lnk.listitemdepartment"), lable);
		return new QAFExtendedWebElement(loc);
	}

}
