package com.automation.web.pages.recipes;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CookingconnectionTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "cc.lbl.pagetitle")
	private QAFWebElement lblPagetitle;
	@FindBy(locator = "cc.icon.video")
	private QAFWebElement iconVideo;
	@FindBy(locator = "cc.lbl.featuredvideo")
	private QAFWebElement lblFeaturedvideo;

	@FindBy(locator = "cc.lbl.cookingconnectionvideos")
	private QAFWebElement lblCookingconnectionvideos;
	@FindBy(locator = "cc.lbl.cookingconnectionrecipes")
	private QAFWebElement lblCookingconnectionrecipes;
	@FindBy(locator = "cc.lbl.cookingconnectionrecipesnamelist")
	private List<QAFWebElement> lblCookingconnectionrecipesnamelist;

	@FindBy(locator = "cc.lbl.cookingconnectionvideosnamelist")
	private List<QAFWebElement> lblCookingconnectionvideosnamelist;
	
	@FindBy(locator = "cc.lnk.featuredvideoAdd2RecipeBox")
	private QAFWebElement lnkFeaturedVideoAdd2RecipeBox;
	@FindBy(locator = "cc.img.cookingconnectionimage")
	private QAFWebElement imgCookingConnectionImage;
	@FindBy(locator = "cc.lnk.storelocation")
	private QAFWebElement lnkStoreLocation;
	@FindBy(locator = "cc.chk.ccrecipesfilterbybread")
	private QAFWebElement chkFilterbyBread;
	@FindBy(locator = "cc.chk.ccrecipesfilterbyburgers")
	private QAFWebElement chkFilterbyBurgers;
	@FindBy(locator = "cc.chk.ccrecipesfilterbybreakfast")
	private QAFWebElement chkFilterbyBreakfast;
	@FindBy(locator = "cc.dd.ccrecipessort")
	private QAFWebElement ddRecipesSort;
	@FindBy(locator = "cc.lbl.ccrecipesxofy")
	private QAFWebElement LblShowingXofY;
	@FindBy(locator = "cc.lbl.ccrecipesresultscount")
	private QAFWebElement LblCCRecipesResultsCount;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}
	
	public QAFWebElement getLblShowingXofY() {
		return LblShowingXofY;
	}
	
	public QAFWebElement getLblCCRecipesResultsCount() {
		return LblCCRecipesResultsCount;
	}
	
	public QAFWebElement getChkFilterbyBread() {
		return chkFilterbyBread;
	}
	
	public QAFWebElement getChkFilterbyBurgers() {
		return chkFilterbyBurgers;
	}
	
	public QAFWebElement getChkFilterbyBreakfast() {
		return chkFilterbyBreakfast;
	}
	
	public QAFWebElement getDDRecipesSort() {
		return ddRecipesSort;
	}
	
	public QAFWebElement getLnkFeaturedVideoAdd2RecipeBox() {
		return lnkFeaturedVideoAdd2RecipeBox;
	}
	
	public QAFWebElement getImgCookingConnectionImage() {
		return imgCookingConnectionImage;
	}
	
	public QAFWebElement getLnkStoreLocation() {
		return lnkStoreLocation;
	}

	public QAFWebElement getLblPagetitle() {
		return lblPagetitle;
	}

	public QAFWebElement getIconVideo() {
		return iconVideo;
	}

	public QAFWebElement getLblFeaturedvideo() {
		return lblFeaturedvideo;
	}

	public QAFWebElement getLblCookingconnectionvideos() {
		return lblCookingconnectionvideos;
	}

	public QAFWebElement getLblCookingconnectionrecipes() {
		return lblCookingconnectionrecipes;
	}

	public List<QAFWebElement> getLblCookingconnectionrecipesnamelist() {
		return lblCookingconnectionrecipesnamelist;
	}

	public List<QAFWebElement> getLblCookingconnectionvideosnamelist() {
		return lblCookingconnectionvideosnamelist;
	}
	
	public QAFWebElement getCookingconnectionUniqueVideos(String linktext) {
		String loc = String.format(pageProps.getString("cc.get.lnk.ccuniquevideos"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getCookingconnectionViewVideos(String linktext) {
		String loc = String.format(pageProps.getString("cc.get.lnk.viewvideo"), linktext);
		return new QAFExtendedWebElement(loc);
	}

}
