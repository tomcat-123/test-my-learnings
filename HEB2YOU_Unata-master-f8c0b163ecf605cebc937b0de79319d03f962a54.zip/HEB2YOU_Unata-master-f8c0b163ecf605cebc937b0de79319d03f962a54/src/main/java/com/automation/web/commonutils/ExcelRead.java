package com.automation.web.commonutils;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.DataProvider;

public class ExcelRead {
	 public static final String SAMPLE_XLSX_FILE_PATH = "resources\\testdata\\Store\\StoreDetails.xlsx";

	 
	 @DataProvider
	public Map<String,String> StoreData() {
		 Workbook workbook=null;
		 Map<String,String> storedata= new HashMap<String,String>();
		try {
			workbook = WorkbookFactory.create(new File(SAMPLE_XLSX_FILE_PATH));
			 Sheet sheet = workbook.getSheetAt(0);
			 
			 DataFormatter dataFormatter = new DataFormatter();	 
			 System.out.println("\n\nIterating over Rows and Columns using Iterator\n");
		        Iterator<Row> rowIterator = sheet.rowIterator();
		        while (rowIterator.hasNext()) {
		            Row row = rowIterator.next();
		            // Now let's iterate over the columns of the current row
		            Cell cell1 = row.getCell(0);
		            Cell cell2 = row.getCell(1);
		            String storeid = dataFormatter.formatCellValue(cell1);
		            String storename = dataFormatter.formatCellValue(cell2);
		            System.out.println(storeid +": "+ storename);
		            storedata.put(storeid, storename);
		       
		        }
		} catch (EncryptedDocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	finally{
			try {
				workbook.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return storedata;	
		}
		
	}

