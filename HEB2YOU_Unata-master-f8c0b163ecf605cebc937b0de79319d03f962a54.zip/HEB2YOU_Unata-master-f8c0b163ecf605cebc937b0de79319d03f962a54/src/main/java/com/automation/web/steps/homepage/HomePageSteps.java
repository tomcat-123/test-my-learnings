package com.automation.web.steps.homepage;

import static com.automation.web.commonutils.FunctionUtils.CART_UNIQUE_ITEM_CNT_KEY;
import static com.automation.web.commonutils.FunctionUtils.CUR_CHOOSEN_STORE_NAME_KEY;
import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NAME_KEY;
import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NUMBER_KEY;
import static com.automation.web.commonutils.FunctionUtils.FULFILLMENT_TYPE_KEY;
import static com.automation.web.commonutils.FunctionUtils.TAX_PERCENTAGE_KEY;
import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.PerfectoUtils.ReportMessage;
import static com.automation.web.commonutils.PerfectoUtils.getDriver;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.APIHub;
import com.automation.web.commonutils.FunctionUtils;
import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.cartandcheckout.CartTestPage;
import com.automation.web.pages.homepage.HomeTestPage;
import com.automation.web.pages.homepage.RegisterTestPage;
import com.automation.web.pages.homepage.ShopTestPage;
import com.automation.web.pages.searchandbrowse.SearchTestPage;
import com.automation.web.steps.curbside.CurbsideSteps;
import com.automation.web.steps.delivery.DeliverySteps;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

/*
 *   List of Step Definitions in HomePage file

User clicks login/Register button
User closes login popup
User on home page
User closes the banners
User clicks User Account tab
Hot user clicks logout tab
Verify home page footer links
Click home page footer links and verify the new page
Verify user name in home page after registeration/login
*/

public class HomePageSteps {

	private static final String [] CATEGORY_TYPES =
		{ "","Pantry", "Fruit & Vegetables"
		,"Meat & Seafood", "Dairy & Frozen","Prepared Meals"
		, "Drinks, Beer, & Wine"
		, "Baby & Toys", "Deli & Bakery"
		, "Household & Kitchen", "Health & Beauty"};


	PerfectoUtils util = new PerfectoUtils();
	Actions act = new Actions(PerfectoUtils.getDriver());

	@QAFTestStep(description = "User clicks Login/Register button")
	public void userClicksLoginRegisterButton() {
		
		
		HomeTestPage homeTestPage = new HomeTestPage();
		homeTestPage.waitForPageToLoad();
		/*if (homeTestPage.getContextSelectorCloseButton().isPresent())
		{
			ReportMessage("Clicked close button if context selector exists ", MessageTypes.Info);
			homeTestPage.getContextSelectorCloseButton().click();
			
		}commented for Safari Issue*/
		
		homeTestPage.waitForPageToLoad();
		//homeTestPage.getLblegister().waitForPresent(MAX_WAIT_TIME);
		homeTestPage.getHomeLblLogin().waitForEnabled(MAX_WAIT_TIME);
		PerfectoUtils.scrolltoelement(homeTestPage.getHomeLblLogin());
		
		homeTestPage.getHomeLblLogin().click();
		homeTestPage.loadPage();
		ReportMessage("Clicked Login/Register button", MessageTypes.Pass);
	}

	@QAFTestStep(description = "User closes login popup")
	public void userCloseLoginPopup() {
		HomeTestPage htp = new HomeTestPage();
		act.sendKeys(Keys.ESCAPE).perform();
		htp.loadPage();
		ReportMessage("Login window closed.", MessageTypes.Pass);
	}

	@QAFTestStep(description = "User on home page")
	public synchronized void userAmOnHomePage() {
		HomeTestPage homeTestPage = new HomeTestPage();
		
		String defaultStoreName = getBundle().getString("defaultStore.name");
		String defaultStoreNum = getBundle().getString("defaultStore.number");

		// Set property values: Item count, current store, current tax percent
		getBundle().setProperty(CART_UNIQUE_ITEM_CNT_KEY, 0);
		getBundle().setProperty(CUR_STORE_NAME_KEY, defaultStoreName);
		getBundle().setProperty(CUR_STORE_NUMBER_KEY, defaultStoreNum);
		getBundle().setProperty(TAX_PERCENTAGE_KEY, 0.0);
//		getTax(defaultStoreNum);

		System.out.println("Opening HEBToYou Application");
		homeTestPage.waitForPageToLoad();
		
		homeTestPage.getHomeImgHeblogo().waitForPresent(MAX_WAIT_TIME);
		
		if(homeTestPage.getHomeImgHeblogo().isPresent()) {
			
			ReportMessage("HEBToYou Home page is Displayed", MessageTypes.Pass);
		} else {
			
			ReportMessage("Home Page verification is Failed:  ", MessageTypes.Fail);
			
		
		}
		
		if (homeTestPage.getContextSelectorCloseButton().isDisplayed())
		{
			ReportMessage("HEBToYou Home page is Displayed with context selector and user click close button ", MessageTypes.Info);
			homeTestPage.getContextSelectorCloseButton().click();
			
		}
		
	}

	@QAFTestStep(description = "User closes the banners")
	public void destroyBanner() {
		HomeTestPage homepage = new HomeTestPage();

		List<QAFWebElement> banners = homepage.getHomeBtnBannerClose();
		Actions act = new Actions(PerfectoUtils.getDriver());
		int num = banners.size();
		if (num > 0) {
			try {
				act.moveToElement(banners.get(0));
			} catch (IndexOutOfBoundsException e) {
				return;
			}

			for (int i = 0; i < num; i++) {
				act.click();
				act.perform();
			}
		} else {
			ReportMessage("Banners not exist in Home page", MessageTypes.Info);
		}

	}

	@QAFTestStep(description = "User clicks User Account tab")
	public static void userClickYourAcctTab() {
		HomeTestPage htp = new HomeTestPage();
		htp.loadPage();
		htp.getHomeBtnYourAccount().waitForPresent(MAX_WAIT_TIME * 2);
		PerfectoUtils.scrolltoelement(htp.getHomeBtnYourAccount());
		htp.getHomeBtnYourAccount().click();
		htp.getHomeLnkLogout().waitForPresent(MAX_WAIT_TIME);

		ReportMessage("User options tab opened", MessageTypes.Pass);
	}

	@QAFTestStep(description = "User should be able to login successfully")
	public void userLoggedinSuccessfully() {
		HomeTestPage htp = new HomeTestPage();
		htp.loadPage();
		htp.getHomeBtnYourAccount().waitForPresent(MAX_WAIT_TIME * 2);
		ReportMessage("User Logged in Successfully", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Hot user clicks logout tab")
	public static void userClicksLogoutTab() {
		HomeTestPage htp = new HomeTestPage();

		htp.getHomeLnkLogout().click();
		ReportMessage("Logout clicked", MessageTypes.Info);
		htp.getHomeLblLogin().waitForPresent(MAX_WAIT_TIME);
		if (htp.getHomeLblLogin().isPresent()) {
			ReportMessage("User Successfully Logged Out", MessageTypes.Pass);
		} else {
			ReportMessage("User Failed to Logged Out the Account", MessageTypes.Fail);
		}
	}




	

	@QAFTestStep(description = "Verify user name in home page after registeration/login")
	public void verifyUserNameinHomepageAfterRegisterationLogin() {
		HomeTestPage htp = new HomeTestPage();

		if (!htp.getHomeLblLogin().isPresent()) {
			htp.getHomeBtnYourAccount().waitForPresent(MAX_WAIT_TIME);
			htp.getHomeBtnYourAccount().verifyPresent();
			ReportMessage("User Name in Home Page is:  " + htp.getHomeBtnYourAccount().getText(), MessageTypes.Info);
			ReportMessage("User Name is displayed after Registration/Login", MessageTypes.Pass);
		} else {
			htp.getHomeLblLogin().waitForPresent(MAX_WAIT_TIME);
			ReportMessage("User Name is not displayed after Registration/Login", MessageTypes.Fail);
		}
	}

/*	@QAFTestStep(description = "User clicks store name from curbside section")
	public void userClickStoreNameFromCurbsideSection() {
		HomeTestPage htp = new HomeTestPage();
		ShopAssistPickupTestPage curbPopup = new ShopAssistPickupTestPage();

		try {
			htp.get
			htp.getLnkStorename().waitForPresent(MAX_WAIT_TIME);
			String defaultStoreName = htp.getLnkStorename().getText();
			htp.getLnkStorename().click();
			ReportMessage("Clicked the Store Name Link:  ", MessageTypes.Info);
			ReportMessage("Deafault Store Name: " + defaultStoreName, MessageTypes.Info);
			curbPopup.getCurbsidePageLoadItem().waitForPresent(MAX_WAIT_TIME * 3);
			if (curbPopup.getBtnCloseCurbPopup().isPresent()) {
				ReportMessage("Curbside Pickup Popup is displayed", MessageTypes.Pass);
			}

		} catch (TimeoutException e) {
			ReportMessage("Curbside Pickup Popup is not displayed", MessageTypes.Fail);
		}

	}*/
	
	@QAFTestStep(description = "Verify cart value is updated each time product is added/removed")
	public void verifyCartValueIsUpdatedEachTimeProductIsAddedRemoved() {
		HomeTestPage htp = new HomeTestPage();
		CartTestPage cart= new CartTestPage();
			int CartIconQty=Integer.parseInt(ConfigurationManager.getBundle().getString("CartIconQty"));
			int currCartIconQty=Integer.parseInt(cart.getCartTxtBtnItemQty().getText());

		if (currCartIconQty>CartIconQty) {
			ReportMessage("Before Adding Qty:  " + CartIconQty, MessageTypes.Info);
			ReportMessage("After Adding Qty:  " + currCartIconQty, MessageTypes.Info);
			ReportMessage("Cart Value is updated successfully:  " + htp.getHomeBtnYourAccount().getText(), MessageTypes.Pass);
		} 
		if(currCartIconQty<CartIconQty){
			ReportMessage("Before Removing Qty:  " + CartIconQty, MessageTypes.Info);
			ReportMessage("After Removing Qty:  " + currCartIconQty, MessageTypes.Info);
			ReportMessage("Cart Value is updated successfully:  " + htp.getHomeBtnYourAccount().getText(), MessageTypes.Pass);
		}
		
		else {
			ReportMessage("Before Adding/Removing Qty:  " + CartIconQty, MessageTypes.Info);
			ReportMessage("After Adding/Removing Qty:  " + currCartIconQty, MessageTypes.Info);
			ReportMessage("Cart Value is not updated :  " + htp.getHomeBtnYourAccount().getText(), MessageTypes.Fail);

		}
	}
	
	@QAFTestStep(description = "User Navigate back to Home Page")
	public void navigateBackToHomePage() {
		HomeTestPage htp = new HomeTestPage();

		try {
			htp.getHomeImgHeblogo().click();
			userAmOnHomePage();
		} catch (TimeoutException e) {
			ReportMessage("Home Page is not displayed", MessageTypes.Fail);
		}
	}
	



	
	/**
	 * Unata eliminated the close button, so sending the "Escape" key now
	 */
	@QAFTestStep(description = "User closes login popup")
	public void iCloseLoginPopup() {
		HomeTestPage htp = new HomeTestPage();
		act.sendKeys(Keys.ESCAPE).perform();
		htp.loadPage();
		ReportMessage("Login window closed." ,MessageTypes.Fail);
	}
/*
	*//**
	 * Opens application and initializes cart count to zero
	 *//*
	@QAFTestStep(description = "User on home page")
	public synchronized void iAmOnHomePage() {
		HomeTestPage homeTestPage = new HomeTestPage();
		String defaultStoreName = getBundle().getString("defaultStore.name");
		String defaultStoreNum = getBundle().getString("defaultStore.number");

		// Set property values: Item count, current store, current tax percent
		getBundle().setProperty(CART_UNIQUE_ITEM_CNT_KEY, 0);
		getBundle().setProperty(CUR_STORE_NAME_KEY, defaultStoreName);
		getBundle().setProperty(CUR_STORE_NUMBER_KEY, defaultStoreNum);
		getBundle().setProperty(TAX_PERCENTAGE_KEY, 0.0);
//		getTax(defaultStoreNum);

		System.out.println("Opening Application");
		//reportiumclient.reportiumAssert("APplication launched successful as a cold user", true);
		homeTestPage.waitForPageToLoad();
		getBundle().setProperty("User", "Cold");
		getBundle().setProperty("myEmail", "Cold");
		destroyBanner();
		
	}*/



	/**
	 * If the user has anything in their cart, the sidecart will "jump" in front of tab just long enough
	 * to close out the options. The sleep call cancels this effect
	 */
	@QAFTestStep(description = "User clicks User Account tab")
	public void iClickYourAcctTab(){
		HomeTestPage htp = new HomeTestPage();
//		htp.loadPage();
		
		PerfectoUtils.scrolltoelement(htp.getHomeBtnYourAccount());
		
		htp.getHomeBtnYourAccount().click();
		ReportMessage("User options tab opened",MessageTypes.Pass);
	}

	@QAFTestStep(description = "User views profile information")
	public void iGetUserAccountInformation(){
		RegisterTestPage register = new RegisterTestPage();
		register.getRegisterEdtCiEmail().waitForEnabled(MAX_WAIT_TIME);

		ReportMessage("Navigated to My Profile",MessageTypes.Pass);
	}
	
	
	
	@QAFTestStep(description = "User logs out of account")
	public void userLogsOut(){
		iClickYourAcctTab();
		userClicksLogoutTab();
	}

	/**
	 * Will navigate to user's name link to create dropdown
	 */
	@QAFTestStep(description = "User clicks on My Profile")
	public void iClickOnMyAccountUser() {
		RegisterTestPage register = new RegisterTestPage();

	
		
		QAFWebElement profile = register.getRegisterLnkMyProfile(); 
		profile.click();

		try{
			register.getRegisterEdtCiEmail().waitForEnabled(MAX_WAIT_TIME*3);
		} catch (TimeoutException e){
			this.iClickYourAcctTab();
			register.getRegisterLnkMyProfile().click();
			profile.click();
		}
		register.getRegisterEdtCiEmail().waitForEnabled(MAX_WAIT_TIME);
		ReportMessage("My Profile clicked",MessageTypes.Pass);
	}
		
	@QAFTestStep(description = "Verify categories displayed in main content of categories page")
	public void catInMainContent(){
		SearchTestPage scp = new SearchTestPage();
		
		getDriver().get(getBundle().getString("env.baseurl") + "/shop/categories");
		QAFWebElement catImg = scp.getSearchLnkFisrtResultFromCdp();
		catImg.waitForEnabled(MAX_WAIT_TIME);
		ShopTestPage nav = new ShopTestPage();

		PerfectoUtils.scrolltoelement(nav.getNavLiMainCat().get(0));
		compareCategories(nav.getNavLiMainCat());
//		for(int i = 1; i < CATEGORY_TYPES.length; i++){
//			util.print(nav.getNavLiMainCat().get(i - 1).getText());
//			nav.getNavLiMainCat().get(i-1).waitForEnabled(MAX_WAIT_TIME);
//			if(nav.getNavLiMainCat().get(i - 1).getText().equals(CATEGORY_TYPES[i])){
//				ReportMessage("Nav Pane Category found: " + nav.getNavLiMainCat().get(i - 1).getText());
//			} else {
//				ReportMessage("Category found: + " + nav.getNavLiMainCat().get(i-1));
//				return;
//			}
//		}
//		ReportMessage("All categories match");
	}
	
	
	@QAFTestStep(description = "Verify aisle categories displayed")
	public void verifyAisleCategories(){
		ShopTestPage nav = new ShopTestPage();
		HomeTestPage homepage = new HomeTestPage();
		
		QAFWebElement catImg = homepage.getHomeTxtShopByAisle();
		catImg.waitForEnabled(MAX_WAIT_TIME);
		
		act.moveToElement(nav.getNavLiAislePane().get(nav.getNavLiAislePane().size() - 1));
		act.perform();
		compareCategories(nav.getNavLiAislePane());
	}
	
	
	@QAFTestStep(description = "Verify each category in the left nav pane on the categories page")
	public void verifyCategoriesInNavPane(){
		getDriver().get(getBundle().getString("env.baseurl") + "/shop/categories");
		ShopTestPage nav = new ShopTestPage(); 

		compareCategories(nav.getNavLiNavPaneCat());
	}

	/**
	 * Builds a hashmap of the elements found and expected elements, then generates a set
	 * to compare the two items. If the sets match, then all the categories are accounted for
	 * @param listFound Categories generated with XPath or .loc file
	 */
	private void compareCategories(List<QAFWebElement> listFound){
		HashMap<String, String> foundElements = new HashMap<>();
		HashMap<String, String> storedElements = new HashMap<>();

		for(int i = 1; i < CATEGORY_TYPES.length; i++){
			foundElements.put(listFound.get(i - 1).getText(), listFound.get(i - 1).getText());
			storedElements.put(CATEGORY_TYPES[i], CATEGORY_TYPES[i]);
			ReportMessage("Category found: " + listFound.get(i - 1).getText());
		}

		Set<String> set1 = foundElements.keySet();
		Set<String> set2 = storedElements.keySet();
		if(set1.equals(set2)){
			ReportMessage("All categories found",MessageTypes.Pass);
		} else {
			ReportMessage("Categories missing",MessageTypes.Fail);

		}
	}

	@QAFTestStep(description = "Verify each category in the header")
	public void iVerifyEachCategoryInTheHeader(){
		ShopTestPage navigation = new ShopTestPage();
		HomeTestPage htp = new HomeTestPage();

		// Click on header, verify, navigate home, and continue
		for(int i = 1; i < CATEGORY_TYPES.length; i++){
			navigation.getNavGetICatHeader(i+"").click();
			navigation.waitForPageToLoad();
			navigation.loadPage();
			if(navigation.getNavPageLoadItem().getText().equals(CATEGORY_TYPES[i]))
				ReportMessage("Successfully navigated to " + CATEGORY_TYPES[i]);
			else
				ReportMessage("Unable to navigate to " + CATEGORY_TYPES[i],MessageTypes.Fail);

			htp.getNavBtnToHome().click();
			htp.loadPage();
		}
		ReportMessage("All headers successfully navigated and verified",MessageTypes.Pass);
	}

	@QAFTestStep(description = "User clicks {category} in header")
	public void clickOnXInHeader(String categoryName){
		ShopTestPage navigation = new ShopTestPage();
		for(int i = 1; i < CATEGORY_TYPES.length; i++){
			if(CATEGORY_TYPES[i].toLowerCase().equals(categoryName.toLowerCase())){
				navigation.getNavGetICatHeader(i+"").click();
				
				navigation.loadPage();
				String header = navigation.getNavPageLoadItem().getText(); 
				ReportMessage(header + " has loaded",MessageTypes.Pass);
			}
		}
	}

	/**
	 * Checks for a single header page. NEEDS to be correct syntax used in array constant above
	 */
	@QAFTestStep(description = "Verify the landing page of {category}")
	public void verifyLandingPageOfX(String categoryName){
		ShopTestPage navigation = new ShopTestPage();
		for(int i = 1; i < CATEGORY_TYPES.length; i++){
			if(CATEGORY_TYPES[i].toLowerCase().equals(categoryName.toLowerCase())){
				String curPage = navigation.getNavPageLoadItem().getText();
				if(curPage.toLowerCase().equals(categoryName.toLowerCase())){
					ReportMessage(categoryName + " is verified",MessageTypes.Pass);
				}
			}
		}
		//util.fail(categoryName + " page not loaded correctly");
	}

/*	*//**
	 * Generates the min, max value, as well as whether or not a product is taxable
	 * by item number. Can be called independently
	 * @param productIdNum Product to gather information on. Can contain the leading
	 * zeroes
	 */
	@QAFTestStep(description = "Generate product info for {product ID Number}")
	public void getProduct(String productIdNum){
		APIHub hub = new APIHub();
		try {
			hub.genProductInfo(productIdNum);
		} catch (UnsupportedOperationException | IOException e) {
			ReportMessage("Product information not loaded for " + productIdNum,MessageTypes.Fail);
		}
	}

	/**
	 * Store to get the tax rate of. Can be called independently
	 * @param storeNum Store number to get the tax rate from
	 */
	@QAFTestStep(description = "Generate tax percentage for {Store Number}")
	public void getTax(String storeNum){
		APIHub hub = new APIHub();
		try {
			hub.genTaxInfo(storeNum);
			if(getBundle().getProperty(TAX_PERCENTAGE_KEY).equals("null")){
				getBundle().setProperty(TAX_PERCENTAGE_KEY, ".0825");
				ReportMessage("Tax not generated for store number " + storeNum + ", set to default percentage",MessageTypes.Fail);
			}
		} catch (UnsupportedOperationException | IOException e) {
			ReportMessage("Tax not generated for store number " + storeNum,MessageTypes.Fail);
		}
	}

/*	*//**
	 * Gets the sale and location price of an item. Assumes the store number has been populated in
	 * the bundle() hash map
	 * @param productIdNum Product to get information of
	 */
	@QAFTestStep(description = "Generate product price listing for {Product Number}")
	public void getListing(String productIdNum){
		APIHub hub = new APIHub();
		try {
			hub.genPriceLocation(productIdNum);
		} catch (UnsupportedOperationException | IOException e) {
			ReportMessage("Store information not generated for store number " 
					+ getBundle().getProperty(FunctionUtils.CUR_STORE_NUMBER_KEY)
					+ ", product num: " + productIdNum,MessageTypes.Fail);	
		}
	}
	
	@QAFTestStep(description = "Verify fulfillment type and store change to default")
	public void changeToDefault(){
		HomeTestPage htp = new HomeTestPage();
		
		if (htp.getContextSelectorCloseButton().verifyPresent())
		{
			htp.getContextSelectorCloseButton().click();
		}
		
		htp.getHomeTxtCurbOrDelVal().waitForEnabled(MAX_WAIT_TIME);
		
		if(htp.getHomeTxtCurbOrDelVal().getText().toLowerCase().equals("curbside pickup")){
			ReportMessage("Curbside Displayed!",MessageTypes.Pass);
		} else {
			ReportMessage("Curbside not displayed",MessageTypes.Fail);
		}
		String foundDisplay = htp.getHomeTxtCurCurbDisplay().getText().toLowerCase();

		String storedDisplay = getBundle().getString("defaultStore.name").toLowerCase();
		
		if(foundDisplay.equals(storedDisplay)){
			
			ReportMessage("Default store set to: " + getBundle().getString("defaultStore.name"),MessageTypes.Pass);
		} else {
			ReportMessage("Default store improperly set to: " + htp.getHomeTxtCurCurbDisplay().getText(),MessageTypes.Fail);
			//System.out.println("Default store improperly set to: " + htp.getHomeTxtCurCurbDisplay().getText(),MessageTypes.Fail);
		}
		
		if(htp.getHomeTxtReservedTime().getText().contains("RESERVE")){
			ReportMessage("Time slot set to default",MessageTypes.Pass);
		} else {
			ReportMessage("Timeslot not set to default. Displayed: " + htp.getHomeTxtReservedTime().getText(),MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "Verify store reverts to last store on logout")
	public void verifySameStore(){
		HomeTestPage htp = new HomeTestPage();
		String fulfillmentType = getBundle().getProperty(FULFILLMENT_TYPE_KEY) + "";
		String storeName = getBundle().getProperty(CUR_CHOOSEN_STORE_NAME_KEY) + "";
		if(htp.getHomeTxtCurbOrDelVal().getText().toLowerCase().equals(fulfillmentType.toLowerCase())){
			ReportMessage("Fulfillment type reverted correctly",MessageTypes.Pass);
		} else {
			ReportMessage("Displayed: " + htp.getHomeTxtCurbOrDelVal().getText());
			ReportMessage("Bundle: " + fulfillmentType);
			ReportMessage("Fulfillment types do not match",MessageTypes.Fail);
		}
		
		if(htp.getHomeTxtCurCurbDisplay().getText().toLowerCase().equals(storeName.toLowerCase())){
			ReportMessage("Store displayed correctly: " + storeName,MessageTypes.Pass);
		} else {
			ReportMessage("Store incorrectly set to: " + htp.getHomeTxtCurCurbDisplay().getText(),MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "Verify item check for availability on selecting {store}")
	public void verifyItemAvail(String storeName){
		ShopTestPage nav = new ShopTestPage();
		CurbsideSteps curbside = new CurbsideSteps();
		curbside.iOpenCurbisdeWindow();
		curbside.iSelectCSPickup();
		curbside.iChangeCurbside();
		curbside.choosesStoreByName(storeName);
		//need to be discussed with vijaybhaskar
		//nav.getNavBoxCompareCartModal().waitForVisible(MAX_WAIT_TIME);
		ReportMessage("Items checked",MessageTypes.Pass);
	}
	
	@QAFTestStep(description = "Verify item check switching from Curbside to Delivery")
	public void verifyCurbSwitch(){
		DeliverySteps delivery = new DeliverySteps();
		CurbsideSteps curbside = new CurbsideSteps();
		ShopTestPage nav = new ShopTestPage();
		curbside.iOpenCurbisdeWindow();
		//curbside.iSelectCSPickup();
		delivery.userSelectsDeliveryService();
		try{
			nav.getNavBoxCompareCartModal().waitForVisible(MAX_WAIT_TIME);
			ReportMessage("Cart availability checked",MessageTypes.Pass);
		} catch(TimeoutException e){
			ReportMessage("Warning module not activated.",MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "Navigate to Ways To Shop Page")
	public void navigateToWaysToShopPage() {
		HomeTestPage home = new HomeTestPage();
		ShopTestPage shop = new ShopTestPage();
		home.getLnkSeemorewaytoshop().waitForPresent(MAX_WAIT_TIME);
		if(PerfectoUtils.getDriver().getCapabilities().getBrowserName().toLowerCase().equals("internet explorer")){
			PerfectoUtils.scrolltoelement(home.getHomeListBanner().get(0));
			PerfectoUtils.JavaScriptClick(home.getLnkSeemorewaytoshop());
		}else{
			home.getLnkSeemorewaytoshop().click();
		}
		ReportMessage("Clicked on see more-way to shop link", MessageTypes.Pass);
		shop.gettxtHeader().waitForPresent(MAX_WAIT_TIME);
		if (shop.gettxtHeader().isPresent()) {
			ReportMessage("Successfully naviagted to WayToShop Page", MessageTypes.Pass);
		} else {
			ReportMessage("WayToShop Page is not displayed", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify ways to shop page left nav pane")
	public void verifyWaysToShopPageLeftNavPane() {
		ShopTestPage shop = new ShopTestPage();

		List<QAFWebElement> leftNav = shop.getLiLeftnavigations();

		List<String> leftNavFromPage = new ArrayList<String>();

		List<String> leftNavFromTestData = ConfigurationManager.getBundle().getList("wayToShop.leftNav.value");

		for (QAFWebElement ele : leftNav) {
			leftNavFromPage.add(ele.getText());
		}

		if (leftNavFromTestData.containsAll(leftNavFromPage)) {
			ReportMessage(
					"Successfully Verfied the WaysToShop Page left nav pane lists:  departments, previous purchases, weekly ad, collection ",
					MessageTypes.Pass);
		} else {
			ReportMessage(
					"Failed to verfiy the WaysToShop Page left nav pane lists:  departments, previous purchases, weekly ad, collection ",
					MessageTypes.Fail);
		}
	}
}


