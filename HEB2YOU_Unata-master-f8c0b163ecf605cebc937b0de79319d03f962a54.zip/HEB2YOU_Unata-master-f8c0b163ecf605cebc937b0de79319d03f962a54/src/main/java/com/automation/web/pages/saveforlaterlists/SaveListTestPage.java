package com.automation.web.pages.saveforlaterlists;

import java.util.List;
//import static common.CommonUtils.MAX_WAIT_TIME;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SaveListTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}

	@FindBy(locator = "saveFL.edit.newList")
	private QAFWebElement saveFLEditNewList;

	@FindBy(locator = "saveFL.btn.saveList")
	private QAFWebElement saveFLBtnSaveList;

	@FindBy(locator = "saveFL.btn.createNewList")
	private QAFWebElement saveFLBtnCreateNewList;

	@FindBy(locator = "saveFL.btn.deleteConfirm")
	private QAFWebElement saveFLBtnDeleteConfirm;

	@FindBy(locator = "saveFL.btn.print")
	private QAFWebElement saveFLBtnPrint;
	
	@FindBy(locator = "saveFL.li.listnames")
	private List<QAFWebElement> lilistnames;
	
	@FindBy(locator = "saveFL.li.img.savelistimg")
	private List<QAFWebElement> saveFLLiImgSavelistimg;
	
	@FindBy(locator = "saveFL.li.chkbox.delete")
	private List<QAFWebElement> LiChkboxDdelete;
	
	@FindBy(locator = "saveFL.lnk.firstsavelist")
	private QAFWebElement saveFLLnkFirstSaveList;
	
	public QAFWebElement getSaveFLLnkFirstSaveList(){ return saveFLLnkFirstSaveList; }
	
	/**
	 * List images
	 */
	public List<QAFWebElement> getLiChkboxDdelete(){ return LiChkboxDdelete; }

	/**
	 * List images
	 */
	public List<QAFWebElement> getsaveFLLiImgSavelistimg(){ return saveFLLiImgSavelistimg; }

	/**
	 * List name
	 */
	public List<QAFWebElement> getlilistnames(){ return lilistnames; }

	@FindBy(locator = "saveFL.lbl.viewdetail")
	private List<QAFWebElement> saveFLLblViewDetail;
	/**
	 * Input for new list
	 */
	public QAFWebElement getSaveFLEditNewList(){ return saveFLEditNewList; }

	/**
	 * Button to save new list
	 */
	public QAFWebElement getSaveFLBtnSaveList(){ return saveFLBtnSaveList; }

	/**
	 * Button to create new list
	 */
	public QAFWebElement getSaveFLBtnCreateNewList(){ return saveFLBtnCreateNewList; }

	/**
	 * Confirmation button for deletion
	 */
	public QAFWebElement getSaveFLBtnDeleteConfirm(){ return saveFLBtnDeleteConfirm; }

	/**
	 * Button to print saved list
	 */
	public QAFWebElement getSaveFLBtnPrint(){ return saveFLBtnPrint; }

	public List<QAFWebElement> getSaveFLLblViewDetail(){ return saveFLLblViewDetail; }

}