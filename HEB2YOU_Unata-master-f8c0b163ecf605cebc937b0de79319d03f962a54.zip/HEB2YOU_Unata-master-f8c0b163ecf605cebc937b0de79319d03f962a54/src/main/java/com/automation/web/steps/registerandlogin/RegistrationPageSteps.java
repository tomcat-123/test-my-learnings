package com.automation.web.steps.registerandlogin;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.PerfectoUtils.ReportMessage;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.databean.NewUserRegisterBean;
import com.automation.web.pages.homepage.HomeTestPage;
import com.automation.web.pages.homepage.RegisterTestPage;
import com.automation.web.steps.cartandcheckout.CartSteps;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;

/*
 * List of Step Definitions for Registration steps

User clicks registration tab
Enter valid phone number
Enter valid email id
User enters required fields in registration page
User sucessfully submits the registration form
Verify Registation Page/Popup
User verifies error messages for blank email and password
User verifies error messages for entering invalid email format and confirm password
User verifies error messages for password criteria check
User verifies error messages for invalid mobile number	
User verifies error messages for already exist emailId
*/

public class RegistrationPageSteps {
	Actions act = new Actions(PerfectoUtils.getDriver());
	PerfectoUtils util = new PerfectoUtils();

	@QAFTestStep(description = "User clicks registration tab")
	public void iClickRegistrationPage() {
		RegisterTestPage register = new RegisterTestPage();
		register.getRegisterTabNewUsrTab().waitForPresent(MAX_WAIT_TIME);
		register.getRegisterTabNewUsrTab().click();
		if (register.getRegisterEdtEmail().isPresent()) {
			ReportMessage("Navigated to register page.", MessageTypes.Pass);
		} else {
			ReportMessage("Not navigated to register page.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Enter valid phone number")
	public void enterValidPhoneNumber() {
		RegisterTestPage register = new RegisterTestPage();

		String mobileNum = getBundle().getString("hotuser1.mobile");
		register.getRegisterEdtMobileNum().waitForPresent(MAX_WAIT_TIME);
		util.enterValues(register.getRegisterEdtMobileNum(), mobileNum);
		ReportMessage("Mobile Number " + mobileNum + " entered", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Enter valid email id")
	public void enterValidEmailId() {
		NewUserRegisterBean registerBean = new NewUserRegisterBean();

		registerBean.fillRandomData();
		String email = registerBean.getEmail();
		RegisterTestPage register = new RegisterTestPage();
		register.getRegisterEdtEmail().waitForPresent(MAX_WAIT_TIME);
		util.enterValues(register.getRegisterEdtEmail(), email);
		ReportMessage("Email " + email + " entered", MessageTypes.Info);
	}

	@QAFTestStep(description = "User enters required fields in registration page")
	public void iEnterAllRequiredFieldsInregistrationPage() {
		NewUserRegisterBean registerBean = new NewUserRegisterBean();
		registerBean.fillRandomData();
		registerBean.fillUiElements();
		
		ReportMessage("Registration fields filled", MessageTypes.Pass);
	}
	
	
	@QAFTestStep(description = "User enters email and password {email} {password} {confpasswaord} {firstname} {lastname} fields in registration page")
	public void userEntersEmailAndPasswordFieldsInRegistrationPage(String email,String password,String confpassword,String firstname,String lastname) {
		
		RegisterTestPage register = new RegisterTestPage();
		register.getRegisterEdtEmail().waitForPresent(MAX_WAIT_TIME);
		util.enterValues(register.getRegisterEdtEmail(), email);
		ReportMessage("Email " + email + " entered", MessageTypes.Info);
		
		
		
		util.enterValues(register.getRegisterEdtPassword(), password);
		ReportMessage("Password " + password + " entered", MessageTypes.Info);
		
		util.enterValues(register.getRegisterEdtReenterpwd(), password);
		ReportMessage("confrim Password " + password + " entered", MessageTypes.Info);
		
		util.enterValues(register.getRegisterEdtfirstname(), firstname);
		ReportMessage(" first name " + firstname + " entered", MessageTypes.Info);
		
		util.enterValues(register.getRegisterEdtlastname() , lastname);
		ReportMessage(" last name " + firstname + " entered", MessageTypes.Info);

		String mobileNum = getBundle().getString("validPhoneNumbers.mobile");
		register.getRegisterEdtMobileNum().waitForPresent(MAX_WAIT_TIME);
		util.enterValues(register.getRegisterEdtMobileNum(), mobileNum);
		ReportMessage("Mobile Number " + mobileNum + " entered", MessageTypes.Pass);
		
		
		
		ReportMessage("Registration fields filled", MessageTypes.Pass);
	}
	

	@QAFTestStep(description = "User sucessfully submits the registration form")
	public void iSubmitTheregistrationForm() {
		RegisterTestPage register = new RegisterTestPage();
		HomeTestPage htp = new HomeTestPage();

		register.getRegisterBtnCreateNewAcc().click();
		
		/*util.doubleClick(register.getRegisterBtnCreateNewAcc());
		register.getRegisterBtnCreateNewAcc().click();*/
		
		htp.getHomeBtnYourAccount().waitForPresent(MAX_WAIT_TIME);
		if (register.getRegisterLblRegiFailed().isPresent()) {
			ReportMessage("Registration not accepted", MessageTypes.Info);
		} else {
			ReportMessage("Registration successful", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "Verify Registation Page/Popup")
	public void verifyRegistationPagePopup() {
		RegisterTestPage register = new RegisterTestPage();

		// Login Page verifications
		ReportMessage("Reistration Popup Fields are...", MessageTypes.Info);
		register.getRegisterTabNewUsrTab().verifyPresent();
		register.getRegisterEdtEmail().verifyPresent();
		register.getRegisterEdtPassword().verifyPresent();
		register.getRegisterEdtReenterpwd().verifyPresent();
		register.getRegisterBtnCreateNewAcc().verifyPresent();
		ReportMessage("Registration Popup Fields are Verified", MessageTypes.Pass);

	}

/*	@QAFTestStep(description = "User verifies error messages for blank email and password")
	public void userVerifiesErrorMessagesForBlankEmailAndPassword() {
		RegisterTestPage register = new RegisterTestPage();

		PerfectoUtils.scrolltoelement(register.getRegisterBtnCreateNewAcc());
		util.doubleClick(register.getRegisterBtnCreateNewAcc());
		register.getRegisterBtnCreateNewAcc().click();
		register.getLblErrmsgBlankEmail().verifyPresent();
		String errMsgEmail = register.getLblErrmsgBlankEmail().getAttribute("id");
		String errMsgPass = register.getLblErrmsgBlankPass().getAttribute("id");
		String errMsgConfPass = register.getLblErrmsgBlankConfpass().getAttribute("id");
		String errMsgEmailXml = getBundle().getString("errorMessage.email");
		String errMsgPassXml = getBundle().getString("errorMessage.password");
		String errMsgConfPassXml = getBundle().getString("errorMessage.confPassword");

		// blank email and password
		ReportMessage("Registration Page-Passing Blank Email and Password", MessageTypes.Info);
		if (errMsgEmail.equals(errMsgEmailXml) && errMsgPass.equals(errMsgPassXml)
				&& errMsgConfPass.equals(errMsgConfPassXml)) {
			ReportMessage("Registration Page-Error Message-Email: " + register.getLblErrmsgBlankEmail().getText(),
					MessageTypes.Info);
			ReportMessage("Registration Page-Error Message-Password: " + register.getLblErrmsgBlankPass().getText(),
					MessageTypes.Info);
			ReportMessage("Registration Page-Error Message-Confirm Password: "
					+ register.getLblErrmsgBlankConfpass().getText(), MessageTypes.Info);
			ReportMessage("Registration Page-Error Message is Displayed while passing Blank Email and Password",
					MessageTypes.Pass);
		} else {
			ReportMessage("Failed to validate error message for Blank Email and Password", MessageTypes.Fail);
		}

	}*/





	
	@QAFTestStep(description = "User creates new account after Reviewing Cart")
	public void createAcctAfterCart(){
		CartSteps cart = new CartSteps();
		cart.continueFromReviewCartPg();
		this.iClickRegistrationPage();
		this.iEnterAllRequiredFieldsInregistrationPage();
		this.iSubmitTheregistrationForm();
		cart.continueFromReviewCartPg();
	}




@QAFTestStep(description = "User enters invalid email id in register")
public void iSubmitBadEmail(){
	RegisterTestPage register = new RegisterTestPage();
	NewUserRegisterBean registerBean = new NewUserRegisterBean();
	registerBean.fillRandomData();
	registerBean.setEmail("ggtest2gmail.com");
	registerBean.setMobileNum(getBundle().getString("hotuser1.mobile"));
	registerBean.fillUiElements();
	util.pass("Registration fields filled");
	Actions act = new Actions(PerfectoUtils.getDriver());
	act.moveToElement(register.getRegisterBtnCreateNewAcc());
	act.perform();
	if(register.getRegisteremailinvalid().isPresent()){
		util.pass("Registration not successful");
	} else {
		util.fail("Registration successful");
	}
}

@QAFTestStep(description = "User enters invalid password in register")
public void submitBadFirstPass(){
	RegisterTestPage register = new RegisterTestPage();

	NewUserRegisterBean registerBean = new NewUserRegisterBean();
	registerBean.fillRandomData();
	registerBean.setPassword("1234");
	registerBean.fillUiElements();

	PerfectoUtils.scrolltoelement(register.getRegisterBtnCreateNewAcc());
	register.getRegisterBtnCreateNewAcc().click();

	if(register.getRegisterPasswordComplexityRequiremenrsError().verifyEnabled())
		ReportMessage("Invalid Password Label is diaplayed ",MessageTypes.Pass);
	else
		util.fail("Registration successful");
}


@QAFTestStep(description = "Enter wrong confirm password in register")
public void iSubmitBadPasswords(){
	RegisterTestPage register = new RegisterTestPage();
	NewUserRegisterBean registerBean = new NewUserRegisterBean();
	registerBean.fillRandomData();
	registerBean.setConfPassword("ClearlyWrongPassword");
	registerBean.fillUiElements();
	util.pass("Registration fields filled");

	PerfectoUtils.scrolltoelement(register.getRegisterBtnCreateNewAcc());
	register.getRegisterBtnCreateNewAcc().click();

	if(register.getRegisterPassworddidNotmatchError().verifyEnabled())
		ReportMessage("Invalid Confrim Password Label is diaplayed ",MessageTypes.Pass);
	else
		util.fail("Registration successful");

}

}