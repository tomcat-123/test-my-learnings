package com.automation.web.pages.extras;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class GmailTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}

	public synchronized void loadPage(){
		gmailPageLoadItem.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}

	@FindBy(locator = "gmail.pageLoadItem")
	private QAFWebElement gmailPageLoadItem;

	@FindBy(locator = "gmail.edt.emailInput")
	private QAFWebElement gmailEdtEmailInput;

	/**
	 * Page load item
	 */
	public QAFWebElement getGmailPageLoadItem(){ return gmailPageLoadItem; }

	/**
	 * Email input on mainpage for gmail
	 */
	public QAFWebElement getGmailEdtEmailInput(){ return gmailEdtEmailInput; }

}