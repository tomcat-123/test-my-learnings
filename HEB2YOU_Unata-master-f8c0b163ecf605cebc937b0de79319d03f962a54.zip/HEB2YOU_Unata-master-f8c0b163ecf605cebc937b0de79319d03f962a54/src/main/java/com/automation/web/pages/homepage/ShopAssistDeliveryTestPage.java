package com.automation.web.pages.homepage;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ShopAssistDeliveryTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void loadPage() {
		lblHeader.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}

	@FindBy(locator = "curbsidedelivery.lbl.header")
	private QAFWebElement lblHeader;

	@FindBy(locator = "curbsidedelivery.txt.zipcode")
	private QAFWebElement txtZipcode;
	
	@FindBy(locator = "curbsidedelivery.img.iconnearzipcode")
	private QAFWebElement imgIconNearZipcode;
	
	@FindBy(locator = "curbsidedelivery.btn.startshopping")
	private QAFWebElement btnStartShopping;
	
	@FindBy(locator = "curbsidedelivery.lbl.errorinvalidzipcode")
	private QAFWebElement lblErrorInvalidZipcode;

	public QAFWebElement getLblHeader() {
		return lblHeader;
	}

	public QAFWebElement getTxtZipcode() {
		return txtZipcode;
	}

	public QAFWebElement getImgIconNearZipcode() {
		return imgIconNearZipcode;
	}

	public QAFWebElement getBtnStartShopping() {
		return btnStartShopping;
	}

	public QAFWebElement getLblErrorInvalidZipcode() {
		return lblErrorInvalidZipcode;
	}

}