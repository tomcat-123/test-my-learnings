package com.automation.web.pages.searchandbrowse;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;

import java.util.List;
//import static common.CommonUtils.MAX_WAIT_TIME;

import com.automation.web.components.searchandbrowse.ProductBlocks;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CategoryTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void loadPage() {
		navPageLoadItem.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}

	@FindBy(locator = "category.pageLoadItem")
	private QAFWebElement navPageLoadItem;

	@FindBy(locator = "category.li.headerlevelonecategory")
	private List<QAFWebElement> liLeftnavLOneCategory;

	@FindBy(locator = "category.li.leftnavltwocategory")
	private List<QAFWebElement> liLeftnavLTwoCategory;

	@FindBy(locator = "category.btn.addtocart")
	private List<QAFWebElement> btnAddtocart;

	@FindBy(locator = "category.btn.addedtocart")
	private QAFWebElement btnAddedtocart;

	@FindBy(locator = "category.lbl.errmsgnoitem")
	private QAFWebElement lblErrmsgnoitem;

	@FindBy(locator = "category.lbl.txtheaderpage")
	private QAFWebElement lblTxtHeaderpage;

	@FindBy(locator = "category.li.catbreadcrumps")
	private List<QAFWebElement> liCatbreadcrumps;

	@FindBy(locator = "category.lbl.addedproductname")
	private QAFWebElement lblAddedProductname;

	@FindBy(locator = "category.lbl.addedproductmsgheader")
	private QAFWebElement lblAddedProductMsgHeader;

	@FindBy(locator = "category.li.catproductimage")
	private List<QAFWebElement> liCatProductImage;

	@FindBy(locator = "category.lbl.overlaymodalitmtitle")
	private QAFWebElement lblOverlayModalItmTitle;

	@FindBy(locator = "category.btn.overlaymodalprimaryitmaddtocart")
	private QAFWebElement btnOverlaymodalPrimaryItmAddtocart;

	@FindBy(locator = "category.btn.overlaymodalprimaryitmaddedtocart")
	private QAFWebElement btnOverlaymodalPrimaryItmAddedtocart;

	@FindBy(locator = "category.btn.overlaymodalprimaryitmreducecart")
	private QAFWebElement btnOverlaymodalPrimaryItmReducecart;

	@FindBy(locator = "category.lnk.overlaymodalbreadcrumblink")
	private QAFWebElement lnkOverlayModalBreadcrumbLink;
	
	@FindBy(locator = "category.li.mainleveltwocategory")
	private List<QAFWebElement> liMainLevelTwoCategory;
	
	@FindBy(locator = "category.li.mainlevelthreecategory")
	private List<QAFWebElement> liMainLevelThreeCategory;
	
	@FindBy(locator = "product.li.productblock")
	private List<ProductBlocks> liProductBlock;
	
	@FindBy(locator = "category.lnk.currentcategory")
	private QAFWebElement lnkCurrentCategory;
	
	@FindBy(locator = "category.li.category")
	private List<QAFWebElement> liCategory;
	
	@FindBy(locator = "category.lnk.leftprevcategory")
	private QAFWebElement lnkLeftprevcategory;
	
	@FindBy(locator = "category.lnk.rightnextcategory")
	private QAFWebElement lnkRightnextcategory;
	
	public QAFWebElement getLnkLeftprevcategory() {
		return lnkLeftprevcategory;
	}
	
	public QAFWebElement getLnkRightnextcategory() {
		return lnkRightnextcategory;
	}

	public List<QAFWebElement> getLiCategory() {
		return liCategory;
	}
	
	public QAFWebElement getLnkCurrentCategory() {
		return lnkCurrentCategory;
	}
	
	public List<ProductBlocks> getLiProductBlock() {
		return liProductBlock;
	}

	public QAFWebElement getLnkOverlayModalBreadcrumbLink() {
		return lnkOverlayModalBreadcrumbLink;
	}

	public QAFWebElement getLblOverlayModalItmTitle() {
		return lblOverlayModalItmTitle;
	}

	public QAFWebElement getBtnOverlaymodalPrimaryItmAddtocart() {
		return btnOverlaymodalPrimaryItmAddtocart;
	}

	public QAFWebElement getBtnOverlaymodalPrimaryItmAddedtocart() {
		return btnOverlaymodalPrimaryItmAddedtocart;
	}

	public QAFWebElement getBtnOverlaymodalPrimaryItmReducecart() {
		return btnOverlaymodalPrimaryItmReducecart;
	}

	public List<QAFWebElement> getliCatProductImage() {
		return liCatProductImage;
	}

	public QAFWebElement getLblAddedProductname() {
		return lblAddedProductname;
	}

	public QAFWebElement getLblAddedProductMsgHeader() {
		return lblAddedProductMsgHeader;
	}

	public List<QAFWebElement> getLiCatbreadcrumpse() {
		return liCatbreadcrumps;
	}

	public QAFWebElement getLblTxtHeaderpage() {
		return lblTxtHeaderpage;
	}

	public QAFWebElement getLblErrmsgnoitem() {
		return lblErrmsgnoitem;
	}

	public QAFWebElement getBtnAddedtocart() {
		return btnAddedtocart;
	}

	public List<QAFWebElement> getLiLeftnavLOneCategory() {
		return liLeftnavLOneCategory;
	}

	public List<QAFWebElement> getLiLeftnavLTwoCategory() {
		return liLeftnavLTwoCategory;
	}

	public List<QAFWebElement> getBtnAddtocart() {
		return btnAddtocart;
	}
	
	public List<QAFWebElement> getLiMainLevelTwoCategory() {
		return liMainLevelTwoCategory;
	}
	
	public List<QAFWebElement> getLiMainLevelThreeCategory() {
		return liMainLevelThreeCategory;
	}
	
	public QAFWebElement getChildCategory(int linkno) {
		String loc = String.format(pageProps.getString("category.get.lbl.childcategory"), linkno);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getLnkChildCategory(int linkno) {
		String loc = String.format(pageProps.getString("category.get.lnk.childcategory"), linkno);
		return new QAFExtendedWebElement(loc);
	}

}