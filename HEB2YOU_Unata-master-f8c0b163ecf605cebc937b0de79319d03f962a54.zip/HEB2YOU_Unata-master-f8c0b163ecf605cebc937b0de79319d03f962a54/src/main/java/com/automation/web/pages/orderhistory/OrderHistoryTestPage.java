package com.automation.web.pages.orderhistory;

import java.util.List;
//import static common.CommonUtils.MAX_WAIT_TIME;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class OrderHistoryTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}

	@FindBy(locator = "orderhistory.sel.filterBy")
	private QAFWebElement acctSelFilterBy;
	
	@FindBy(locator = "orderhistory.btn.cancelOrder")
	private QAFWebElement acctBtnCancelOrder;
	
	@FindBy(locator = "orderhistory.txt.historyProdNotes")
	private QAFWebElement productTxtHistoryProdNotes;
	
	@FindBy(locator = "orderhistory.lis.itemimage")
	private List<QAFWebElement> orderhistoryListItemImage;
	
	@FindBy(locator = "orderhistory.lis.orderdetails")
	private List <QAFWebElement> orderhistoryListOrderDetails;
	
	@FindBy(locator = "orderhistory.li.curbsideDates")
	private List<QAFWebElement> liCurbsideDates;
	
	@FindBy(locator = "orderhistory.lbl.subHeaderbanner")
	private QAFWebElement lblSubHeaderbanner;
	
	@FindBy(locator = "orderhistory.lbl.noorderFound")
	private QAFWebElement lblNoOrderFound;
	
	@FindBy(locator = "orderhistory.li.orderedproducts")
	private List<QAFWebElement>  liOrderedProducts ;
	
	@FindBy(locator = "orderhistory.lbl.allowsubs")
	private List<QAFWebElement>  lblAllowSubs ;
	
	@FindBy(locator = "orderhistory.lbl.allowsubsyes")
	private List<QAFWebElement>  lblAllowSubsYes ;
	
	@FindBy(locator = "orderhistory.chkbox.addon")
	private List<QAFWebElement>  chkboxaddon;
	
	@FindBy(locator = "orderhistory.chkbox.selectallproduct")
	private QAFWebElement  chkboxSelectallProduct;
	
	@FindBy(locator = "orderhistory.btn.ordercancelyes")
	private QAFWebElement  btnOrderCancelYes;
	
	@FindBy(locator = "orderhistory.btn.ordercancelno")
	private QAFWebElement  btnOrderCancelNo;
	
	/**
	 * Cancel order Yes Btn
	 */
	public QAFWebElement getbtnOrderCancelYes() {
		return btnOrderCancelYes;
	}
	/**
	 * Cancel order No Btn
	 */
	public QAFWebElement getbtnOrderCancelNo() {
		return btnOrderCancelNo;
	}
	/**
	 * Select all checkbox on the order history page
	 */
	public QAFWebElement getchkboxSelectallProduct() {
		return chkboxSelectallProduct;
	}
	/**
	 * Lbl No Order Found on the order history page
	 */
	public List<QAFWebElement> getchkboxaddon() {
		return chkboxaddon;
	}

	/**
	 * Lbl Allow sub? Products on the order details page
	 */
	public List<QAFWebElement> getLblAllowSubs() {
		return lblAllowSubs;
	}
	/**
	 * Lbl Allow sub?Yes Products on the order details page
	 */

	public List<QAFWebElement> getLblAllowSubsYes() {
		return lblAllowSubsYes;
	}

	
	
	/**
	 * Lbl Products on the order history page
	 */
	public List<QAFWebElement>  getliOrderedProducts() {
		return liOrderedProducts;
	}


	/**
	 * Lbl No Order Found on the order history page
	 */
	public QAFWebElement getLblNoOrderFound() {
		return lblNoOrderFound;
	}


	/**
	 * Lbl banner(Date schedule,Total..etc) on the order history page
	 */
	public QAFWebElement getLblSubHeaderbanner() {
		return lblSubHeaderbanner;
	}


	/**
	 * Order pickup or delivery dates on the order history page
	 */
	
	public List<QAFWebElement> getliCurbsideDates() {
		return liCurbsideDates;
	}
	
	
	/**
	 * Product notes on the order history page
	 */
	public QAFWebElement getProductTxtHistoryProdNotes(){ return productTxtHistoryProdNotes; }

	/**
	 * Order history filters
	 */
	public QAFWebElement getAcctSelFilterBy(){ return acctSelFilterBy; }

	/**
	 * Button to cancel user's order
	 */
	public QAFWebElement getAcctBtnCancelOrder(){ return acctBtnCancelOrder; }

	public List<QAFWebElement> getOrderhistoryListItemImage(){ return orderhistoryListItemImage; }
	
	public List<QAFWebElement> getOrderhistoryListOrderDetails(){ return orderhistoryListOrderDetails; }

}