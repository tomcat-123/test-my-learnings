package com.automation.web.pages.cartandcheckout;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;

import java.util.List;

import com.automation.web.components.cart.CartItemBlocks;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CartTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void loadPage() {
		cartPageLoadItem.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}

	@FindBy(locator = "cart.pageLoadItem")
	private QAFWebElement cartPageLoadItem;

	@FindBy(locator = "cart.lnk.cartHeader")
	private QAFWebElement cartLnkCartHeader;

	@FindBy(locator = "cart.lnk.shoppingCart")
	private QAFWebElement cartLnkShoppingCart;

	@FindBy(locator = "cart.txt.btnCurrencyAmt")
	private QAFWebElement cartTxtBtnCurrencyAmt;

	@FindBy(locator = "cart.txt.btnItemQty")
	private QAFWebElement cartTxtBtnItemQty;

	@FindBy(locator = "cart.btn.checkOut")
	private QAFWebElement cartBtnCheckOut;

	@FindBy(locator = "cart.get.i.cartDec")
	private QAFWebElement cartGetICartDec;

	@FindBy(locator = "cart.get.i.cartAdd")
	private QAFWebElement cartGetICartAdd;

	@FindBy(locator = "cart.get.i.cartInput")
	private QAFWebElement cartGetICartInput;

	@FindBy(locator = "cart.get.i.cartRemove")
	private QAFWebElement cartGetICartRemove;

	@FindBy(locator = "cart.get.removeConf")
	private QAFWebElement cartGetRemoveConf;

	@FindBy(locator = "cart.get.i.cartAmt")
	private QAFWebElement cartGetICartAmt;

	@FindBy(locator = "cart.get.metaName")
	private QAFWebElement cartGetMetaName;

	@FindBy(locator = "cart.get.metaTotal")
	private QAFWebElement cartGetMetaTotal;

	@FindBy(locator = "cart.btn.mainCheckout")
	private QAFWebElement cartBtnMainCheckout;

	@FindBy(locator = "cart.txt.emptyCart")
	private QAFWebElement chkOutTxtEmptyCart;

	@FindBy(locator = "cart.hdr.reviewHeader")
	private QAFWebElement chkOutHdrReviewHeader;

	@FindBy(locator = "cart.btn.continue")
	private QAFWebElement chkOutBtnContinue;

	@FindBy(locator = "cart.btn.removeAll")
	private QAFWebElement chkOutBtnRemoveAll;

	@FindBy(locator = "cart.btn.confRemAll")
	private QAFWebElement chkOutBtnConfRemAll;

	@FindBy(locator = "cart.btn.cancelRemAll")
	private QAFWebElement chkOutBtnCancelRemAll;

	@FindBy(locator = "cart.btn.notFound")
	private QAFWebElement chkOutBtnNotFound;

	@FindBy(locator = "cart.btn.saveForLater")
	private QAFWebElement chckOutBtnSaveForLater;

	@FindBy(locator = "cart.list.defaultSFLList")
	private QAFWebElement chckOutListDefaultSFLList;

	@FindBy(locator = "cart.edt.newListBox")
	private QAFWebElement chckOutEdtNewListBox;

	@FindBy(locator = "cart.btn.reorderItems")
	private QAFWebElement chckOutBtnReorderItems;

	@FindBy(locator = "cart.txt.orderLevelNotes")
	private QAFWebElement chckOutTxtOrderLevelNotes;

	@FindBy(locator = "cart.btn.saveNotes")
	private QAFWebElement chckOutBtnSaveNotes;

	@FindBy(locator = "cart.btn.productNotes")
	private QAFWebElement productBtnProductNotes;

	@FindBy(locator = "cart.input.productNotes")
	private QAFWebElement productInputProductNotes;

	@FindBy(locator = "cart.txt.subtotal")
	private QAFWebElement ckconTxtSubtotal;

	@FindBy(locator = "cart.get.productMetaName")
	private QAFWebElement chkOutGetProductMetaName;

	@FindBy(locator = "cart.img.sidecartimg")
	private List<QAFWebElement> imgSidCartImg;

	@FindBy(locator = "cart.li.cartitemsblocks")
	private List<CartItemBlocks> liCartitemsblocks;

	/**
	 * Img Side Item cart images
	 */
	public List<QAFWebElement> getimgSidCartImg() {
		return imgSidCartImg;
	}

	/**
	 * Subtotal for ordered items
	 */
	public QAFWebElement getCkconTxtSubtotal() {
		return ckconTxtSubtotal;
	}

	/**
	 * Text box to add product notes
	 */
	public QAFWebElement getProductInputProductNotes() {
		return productInputProductNotes;
	}

	/**
	 * Notes to add product. Assumes Review Cart Page
	 */
	public QAFWebElement getProductBtnProductNotes() {
		return productBtnProductNotes;
	}

	/**
	 * Load item for cart
	 */
	public QAFWebElement getCartPageLoadItem() {
		return cartPageLoadItem;
	}

	/**
	 * Pop out header for shopping cart
	 */
	public QAFWebElement getCartLnkCartHeader() {
		return cartLnkCartHeader;
	}

	/**
	 * Shopping cart icon
	 */
	public QAFWebElement getCartLnkShoppingCart() {
		return cartLnkShoppingCart;
	}

	/**
	 * Text containing currency total for items in cart
	 */
	public QAFWebElement getCartTxtBtnCurrencyAmt() {
		return cartTxtBtnCurrencyAmt;
	}

	/**
	 * Quantity of items in cart
	 */
	public QAFWebElement getCartTxtBtnItemQty() {
		return cartTxtBtnItemQty;
	}

	/**
	 * Button to navigate to main checkout page
	 */
	public QAFWebElement getCartBtnCheckOut() {
		return cartBtnCheckOut;
	}

	/**
	 * Decrement button
	 */
	public QAFWebElement getCartGetICartDec(String item) {
		String retElm = String.format(pageProps.getString("cart.get.i.cartDec"), item);
		return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Add button
	 */
	public QAFWebElement getCartGetICartAdd(String item) {
		String retElm = String.format(pageProps.getString("cart.get.i.cartAdd"), item);
		return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Number input for item amount
	 */
	public QAFWebElement getCartGetICartInput(String item) {
		String retElm = String.format(pageProps.getString("cart.get.i.cartInput"), item);
		return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Removes item from cart completely
	 */
	public QAFWebElement getCartGetICartRemove(String item) {
		String retElm = String.format(pageProps.getString("cart.get.i.cartRemove"), item);
		return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Button to confirm removal from cart
	 */
	public QAFWebElement getCartGetRemoveConf(String item) {
		String retElm = String.format(pageProps.getString("cart.get.removeConf"), item);
		return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Price of item
	 */
	public QAFWebElement getCartGetICartAmt(String item) {
		String retElm = String.format(pageProps.getString("cart.get.i.cartAmt"), item);
		return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Data of item in cart
	 */
	public QAFWebElement getCartGetMetaName(String item) {
		String retElm = String.format(pageProps.getString("cart.get.metaName"), item);
		return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Total price of item in cart
	 */
	public QAFWebElement getCartGetMetaTotal(String item) {
		String retElm = String.format(pageProps.getString("cart.get.metaTotal"), item);
		return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Main checkout button
	 */
	public QAFWebElement getCartBtnMainCheckout() {
		return cartBtnMainCheckout;
	}

	/**
	 * Text displaying "There are no items in your cart"
	 */
	public QAFWebElement getChkOutTxtEmptyCart() {
		return chkOutTxtEmptyCart;
	}

	/**
	 * Review items checkout header
	 */
	public QAFWebElement getChkOutHdrReviewHeader() {
		return chkOutHdrReviewHeader;
	}

	/**
	 * Continue button
	 */
	public QAFWebElement getChkOutBtnContinue() {
		return chkOutBtnContinue;
	}

	/**
	 * Product name on checkout page
	 */
	public QAFWebElement getChkOutGetProductMetaName(String item) {
		String retElm = String.format(pageProps.getString("chkOut.get.productMetaName"), item);
		return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Removes all items from cart
	 */
	public QAFWebElement getChkOutBtnRemoveAll() {
		return chkOutBtnRemoveAll;
	}

	/**
	 * Button to confirm removing all items from cart
	 */
	public QAFWebElement getChkOutBtnConfRemAll() {
		return chkOutBtnConfRemAll;
	}

	/**
	 * Button to cancel removing all items from cart
	 */
	public QAFWebElement getChkOutBtnCancelRemAll() {
		return chkOutBtnCancelRemAll;
	}

	/**
	 * Button to continue shopping from 'No items found' pg
	 */
	public QAFWebElement getChkOutBtnNotFound() {
		return chkOutBtnNotFound;
	}

	/**
	 * Button to open up save for later lists popup
	 */
	public QAFWebElement getChckOutBtnSaveForLater() {
		return chckOutBtnSaveForLater;
	}

	/**
	 * Default save for later list on review page
	 */
	public QAFWebElement getChckOutListDefaultSFLList() {
		return chckOutListDefaultSFLList;
	}

	/**
	 * Input for new list
	 */
	public QAFWebElement getChckOutEdtNewListBox() {
		return chckOutEdtNewListBox;
	}

	/**
	 * Re-order button
	 */
	public QAFWebElement getChckOutBtnReorderItems() {
		return chckOutBtnReorderItems;
	}

	/**
	 * Area to add notes about order
	 */
	public QAFWebElement getChckOutTxtOrderLevelNotes() {
		return chckOutTxtOrderLevelNotes;
	}

	/**
	 * Button to save order notes
	 */
	public QAFWebElement getChckOutBtnSaveNotes() {
		return chckOutBtnSaveNotes;
	}

	public List<CartItemBlocks> getLiCartitemsblocks() {
		return liCartitemsblocks;
	}
}