package com.automation.web.listener;


import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryListener implements IRetryAnalyzer {

	private static int retryCount = 0;
	private static final int MAX_RETRY_CNT = 1;

	@Override
	public boolean retry(ITestResult result) {
		if (retryCount < MAX_RETRY_CNT) {
			clearItemKeys();
			retryCount += 1;
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Removes all keys that are not test steps
	 */
	private void clearItemKeys() {

//		getBundle().clearProperty("cityorzipcode");
//		getBundle().clearProperty("Address");
//		getBundle().clearProperty("Storename");


	}
}
