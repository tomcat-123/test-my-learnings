package com.automation.web.commonutils;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static org.testng.Assert.assertTrue;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.perfecto.reportium.client.ReportiumClient;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class PerfectoUtils implements JavascriptExecutor {

	public static QAFExtendedWebDriver getDriver() {
		return new WebDriverTestBase().getDriver();
	}

	public static final String PERFECTO_REPORT_CLIENT = "perfecto.report.client";

	// Constants for timing in Mili seconds
	public static final int MAX_WAIT_TIME = 50000;
	
	public static FluentWait<WebDriver> fluentwait = new FluentWait<WebDriver>(getDriver())
			.pollingEvery(5, TimeUnit.SECONDS).withTimeout(50, TimeUnit.SECONDS)
			.ignoring(NoSuchElementException.class);

	Actions action = new Actions(getDriver());

	public static void ReportMessage(String msg, MessageTypes result) {
		
		ReportiumClient reportClient = (ReportiumClient) getBundle().getObject(PERFECTO_REPORT_CLIENT);
		boolean asrtResult = false;

		if (result.equals(MessageTypes.Pass) || result.equals(MessageTypes.TestStepPass)) {
			asrtResult = true;
		} else if (result.equals(MessageTypes.Fail) || result.equals(MessageTypes.TestStepFail)) {
			asrtResult = false;
		} else if (result.equals(MessageTypes.Info) || result.equals(MessageTypes.TestStep)
				|| result.equals(MessageTypes.Warn)) {
			asrtResult = true;
		}
		System.out.println(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
		System.out.println(msg +" Result :   "+result);
		System.out.println(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
		reportClient.reportiumAssert(msg, asrtResult);
		Reporter.log(msg, result);
		assertTrue(asrtResult, msg);

	}
	
	public static void ReportMessage(String msg) {
		ReportMessage(msg, MessageTypes.Info);
	}

	
	public  void pass(String msg) {
		ReportMessage(msg,MessageTypes.Pass);
		
	}
	
	public  void fail(String msg) {
		ReportMessage(msg,MessageTypes.Fail);
		
	}
	/**
	 * Perfecto- Scrolls to specified element.
	 * 
	 * @param element
	 *            Element to scroll to
	 */
	public static void scrolltoelement(QAFWebElement qafelement) {

		try {
			qafelement.waitForPresent(MAX_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor) PerfectoUtils.getDriver();
			js.executeScript("arguments[0].scrollIntoView(true);", qafelement);

		} catch (Exception e) {
			PerfectoUtils.ReportMessage("Error occured while scrolling to the elemenet.");
			e.printStackTrace();
		}

	}

	public static void mouseover(QAFWebElement moveToElement) {
		// Java Script
		try {
			String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
			JavascriptExecutor js = (JavascriptExecutor) getDriver();
			WebElement element = (WebElement) moveToElement;
			js.executeScript(mouseOverScript, element);
		} catch (Exception e) {
			Actions action = new Actions(PerfectoUtils.getDriver());
			action.moveToElement(moveToElement).build().perform();
		}

	}

	public static void mousehoverusingActions(WebElement moveElement) {
		Actions action = new Actions(PerfectoUtils.getDriver());
		action.moveToElement(moveElement).build().perform();
	}

	public static void mouseoverandclick(QAFWebElement moveAndClickElement) {
		// Java Script
		String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		WebElement element = (WebElement) moveAndClickElement;
		js.executeScript(mouseOverScript, element);
		moveAndClickElement.click();

	}

	public static void mouseoverandclick(QAFWebElement moveElement, QAFWebElement clickElement) {
		// Actions class
		Actions act = new Actions(PerfectoUtils.getDriver());

		WebElement element1 = (WebElement) moveElement;
		WebElement element2 = (WebElement) clickElement;
		act.moveToElement(element1).click(element2).build().perform();

	}

	public static String removeSpecialCharacters(String value) {

		StringBuilder myNumbers = new StringBuilder();
		for (int i = 0; i < value.length(); i++) {
			if (Character.isDigit(value.charAt(i))) {
				myNumbers.append(value.charAt(i));
			} else if (Character.isLetter(value.charAt(i))) {
				myNumbers.append(value.charAt(i));
			} else {
				System.out.println(value.charAt(i) + " not a digit or Character.");
			}
		}
		return myNumbers.toString();

	}

	public static String getIntCharacters(String value) {

		StringBuilder myNumbers = new StringBuilder();
		for (int i = 0; i < value.length(); i++) {
			if (Character.isDigit(value.charAt(i))) {
				myNumbers.append(value.charAt(i));
			}
		}
		return myNumbers.toString();

	}

	public static String getOnlyChars(String value) {

		StringBuilder myNumbers = new StringBuilder();
		for (int i = 0; i < value.length(); i++) {
			if (Character.isLetter(value.charAt(i))) {
				myNumbers.append(value.charAt(i));
			} else {
				System.out.println(value.charAt(i) + " not a digit or Character.");
			}
		}
		return myNumbers.toString();
	}

	@Override
	public Object executeScript(String script, Object... args) {
		JavascriptExecutor js = (JavascriptExecutor) PerfectoUtils.getDriver();
		js.executeScript(script, args);
		return null;
	}

	@Override
	public Object executeAsyncScript(String script, Object... args) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void setMockLocation(String latitude, String longitude) {
		getDriver().executeScript(
				"window.navigator.geolocation.getCurrentPosition = function(success){var position = {'coords' : {'latitude': '"
						+ latitude + "','longitude': '" + longitude + "'}};success(position);}");
	}

	/**
	 * Sends specified credentials to web element given. Clears out any old
	 * values before sending new values to the area
	 * 
	 * @param elementName
	 *            Web element (button, label) to be entered into field
	 * @param elementValue
	 *            Value to enter
	 */
	public void enterValues(QAFWebElement elementName, String elementValue) {

		elementName.waitForPresent(MAX_WAIT_TIME);
		elementName.sendKeys(elementValue);
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}


	/**
	 * Sends specified credentials to web element given. Clears out any old
	 * values before sending new values to the area, and then sends the enter
	 * key
	 * 
	 * @param elementName
	 *            Web element (button, label) to be entered into field
	 * @param elementValue
	 *            Value to enter
	 */
	public void enterValueAndSendEnter(QAFWebElement elementName, String elementValue) {
		elementName.click();
		elementName.sendKeys(elementValue+Keys.ENTER);
	}

	public void moveToElement(QAFWebElement element) {
		action.moveToElement(element);
		action.build();
		action.perform();
	}

	/**
	 * Scrolls to specified element and clicks on it. Will sleep for half the
	 * time of SLEEP_TIME.
	 * 
	 * @param element
	 *            Element to scroll to
	 */
	public void scrollAndClick(QAFWebElement element) {

		element.waitForPresent(MAX_WAIT_TIME);
		PerfectoUtils.scrolltoelement(element);
		element.waitForPresent(MAX_WAIT_TIME);
		element.click();
	}

	/**
	 * Scrolls to specified element and clicks on it. Will sleep for half the
	 * time of SLEEP_TIME.
	 * 
	 * @param element
	 *            Element to scroll to
	 */
	public static void doubleClick(QAFWebElement element) {

		element.waitForPresent(MAX_WAIT_TIME);
		element.click();
		element.waitForPresent(MAX_WAIT_TIME);
		element.click();
	}

	/**
	 * Adds items to the cart
	 * 
	 * @param elementTo
	 *            Button for the elementTo.click()
	 * @param clickAmount
	 *            Amount of clicks requested
	 */
	public static int multiClick(QAFWebElement elementTo, int clickAmount) {
		int totalAdded = 0;
		for (int i = 0; i < clickAmount; i++) {
			elementTo.click();
			totalAdded += 1;
		}
		return totalAdded;
	}

	/**
	 * If passed a select box web element, can scroll through and select the
	 * given item based on the string. So, if given a State selection box with
	 * the String "Texas," it will go through the options until the greatest
	 * state in the union is selected
	 * 
	 * @param menu
	 *            Menu box to scroll through
	 * @param clickMe
	 *            Item to select
	 */
	public void selectBoxSelection(QAFWebElement menu, String clickMe) {
		// act.moveToElement(menu);
		// act.perform();
		moveToElement(menu);

		menu.click();
		Select clickThis = new Select(menu);
		clickThis.selectByVisibleText(clickMe);
	}
	
	public void selectBoxSelectionwithoutClick(QAFWebElement menu, String clickMe) {
		moveToElement(menu);

		Select clickThis = new Select(menu);
		clickThis.selectByVisibleText(clickMe);
	}

	public static void waitAngularHasFinishedProcessing() {
		WebDriverWait wait = new WebDriverWait(getDriver(), 35, 100);
		wait.until(angularHasFinishedProcessing());

	}

	public static ExpectedCondition<Boolean> angularHasFinishedProcessing() {
		return new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				return Boolean.valueOf(((JavascriptExecutor) driver)
						.executeScript(
								"return (window.angular !== undefined) && (angular.element(document).injector() !== undefined) && (angular.element(document).injector().get('$http').pendingRequests.length === 0)")
						.toString());
			}
		};
	}
	/**
	 * Retrieves a String stored in the bundle hashmap
	 * 
	 * @param name
	 *            Item to be retrieved
	 * @return Stored string
	 */
	public String storedString(String name) {
		return getBundle().getString(name);
	}

	/**
	 * Moves over the initial item given, sleeps for SLEEP_TIME, and then moves
	 * to the intended target.
	 * 
	 * @param hoverItem
	 *            Starting item to populate required tab
	 * @param itemToClick
	 *            Intended item to be clicked
	 */
	public void mouseoverAndClick(QAFWebElement hoverItem, QAFWebElement itemToClick) {
		action.moveToElement(hoverItem);
		action.perform();
		action.moveToElement(itemToClick);
		action.click();
		action.perform();
	}

	/**
	 * Returns a WebElement based on the given xpath
	 * 
	 * @param xpath
	 *            Xpath to the element to be created
	 * @return WebElement object
	 */
	public WebElement generateWebElement(String xpath) {
		return getDriver().findElement(By.xpath(xpath));
	}

	/**
	 * Returns a list of WebElements based on the given xpath
	 * 
	 * @param xpath
	 *            Xpath to the element to be created
	 * @return List of WebElements
	 */
	public List<WebElement> generateWebElementList(String xpath) {
		return getDriver().findElements(By.xpath(xpath));
	}
	
	public static void waitUntilVisibilityofElement(QAFWebElement Element) {

		try {
			fluentwait.until((ExpectedCondition<Boolean>) driver -> Element.isDisplayed());
		} catch (NoSuchElementException e) {
			// ignore
		}
	}
	
	public static void JavaScriptClick(QAFWebElement Element) {
        JavascriptExecutor javascriptexe = (JavascriptExecutor)PerfectoUtils.getDriver();
        javascriptexe.executeScript("arguments[0].click()", Element);
 }
	
	public static void JavaScriptSendKeys(QAFWebElement Element, String value) {
        JavascriptExecutor javascriptexe = (JavascriptExecutor)PerfectoUtils.getDriver();
        javascriptexe.executeScript("arguments[0].value='"+value+"';", Element);
 }
	
	public static void JavaScriptSelect(QAFWebElement Element, String value) {
        JavascriptExecutor javascriptexe = (JavascriptExecutor)PerfectoUtils.getDriver();
        javascriptexe.executeScript("var select = arguments[0]; for(var i = 0; i < select.options.length; i++){ if(select.options[i].text == arguments[1]){ select.options[i].selected = true; } }", Element, value);
}
	
}
