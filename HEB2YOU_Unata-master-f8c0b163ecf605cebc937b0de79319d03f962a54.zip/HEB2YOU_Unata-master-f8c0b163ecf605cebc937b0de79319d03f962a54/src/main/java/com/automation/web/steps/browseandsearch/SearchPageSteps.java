package com.automation.web.steps.browseandsearch;


import static com.automation.web.commonutils.FunctionUtils.CART_UNIQUE_ITEM_CNT_KEY;
import static com.automation.web.commonutils.FunctionUtils.CONSM_PRCH_CD_KEY;
import static com.automation.web.commonutils.FunctionUtils.ITEM_ID_KEY;
import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.PerfectoUtils.ReportMessage;
import static com.automation.web.commonutils.PerfectoUtils.multiClick;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.APIHub;
import com.automation.web.commonutils.FunctionUtils;
import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.searchandbrowse.SearchTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

/*
 * List of Step Definitions in SearchPage Steps file 
 * 

User searches for {search item}
User clicks on the search icon
Verify user is on the search page
Verify search data is correct

*/


public class SearchPageSteps {

	PerfectoUtils util = new PerfectoUtils();
	Actions act = new Actions(PerfectoUtils.getDriver());
	APIHub hub = new APIHub();
	
	private String [] WAYS_TO_SHOP = {"", "Products On Sale", 
			"Yellow Coupons", "Previously Purchased"
			 , "Organic Products", "Gluten Free Products"
			 , "Local Products", "New Products"};

	@QAFTestStep(description = "User searches for {search item}")
	public void userSearchForX(String searchItem) {
		SearchTestPage searchPg = new SearchTestPage();

		searchPg.getSearchEdtSearchBarInput().waitForEnabled(MAX_WAIT_TIME);
		try {
			act.moveToElement(searchPg.getSearchEdtSearchBarInput());
			act.click();
			act.perform();
		} catch (WebDriverException e) {

			searchPg.getSearchEdtSearchBarInput().waitForEnabled(MAX_WAIT_TIME);
			util.scrollAndClick(searchPg.getSearchEdtSearchBarInput());
		}
		util.enterValues(searchPg.getSearchEdtSearchBarInput(), searchItem);
		ReportMessage("Item " + searchItem + " entered into search bar", MessageTypes.Info);
	}

	@QAFTestStep(description = "User clicks on the search icon")
	public void iClickOnTheSearchIcon() {
		SearchTestPage searchPg = new SearchTestPage();

		searchPg.getSearchBtnSearchBtnConf().waitForPresent(MAX_WAIT_TIME*5);
		searchPg.getSearchBtnSearchBtnConf().click();
		searchPg.getSearchTxtResultsFound().waitForPresent(MAX_WAIT_TIME);
		ReportMessage("Search page loaded successfully", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify user is on the search page")
	public void verifySearchPage() {
		SearchTestPage searchPg = new SearchTestPage();

		PerfectoUtils.scrolltoelement(searchPg.getSearchPageLoadItem());
		searchPg.getSearchPageLoadItem().waitForEnabled(MAX_WAIT_TIME * 2);
		String[] resultHeaderM = searchPg.getSearchTxtResultsFound().getText().split(" ", 4);
		ReportMessage(resultHeaderM[0] + " items of " + resultHeaderM[3].replace("\"", "") + " found on search page");
		if (searchPg.getLblNoSearchResult().isPresent())
			ReportMessage("User on search result page and seach returned no results", MessageTypes.Fail);
		else
			ReportMessage("User on search result page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify search data is correct")
	public void verifyResultAmount() {
		SearchTestPage searchPg = new SearchTestPage();

		QAFWebElement nextPage;
		searchPg.loadPage();
		boolean hasNextPage = false;
		String[] resultHeaderM = searchPg.getSearchTxtResultsFound().getText().split(" ", 4);
		int itemsFound = Integer.parseInt(resultHeaderM[0]);
		int curSearchCnt = 0;

		do {
			for (WebElement row : searchPg.getSearchTxtSearchList()) {
				act.moveToElement(row);
				act.perform();
				curSearchCnt += 1;
			}

			try {
				nextPage = searchPg.getSearchTxtNextPageIcon();
				hasNextPage = nextPage.isPresent();
				if (hasNextPage == true) {
					PerfectoUtils.scrolltoelement(nextPage);
					nextPage.click();
				} else {
					ReportMessage("No next page from search result section", MessageTypes.Info);
				}
			} catch (NoSuchElementException e) {
				hasNextPage = false;
			}
		} while (hasNextPage);
		if (itemsFound == curSearchCnt) {
			ReportMessage("All items visible", MessageTypes.Pass);
		} else {
			ReportMessage("Total search items expected: " + itemsFound + ", items found: " + curSearchCnt,
					MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "User adds {itemAmt} of the {by each}(st|th|nd|rd) item")
	public void iAddXoftheYItem(String itemAmount, String listPosition){
	
		SearchTestPage searchPg = new SearchTestPage();
		FunctionUtils u = new FunctionUtils();
		String itemToAdd  = u.generateItemID(searchPg.getSearchGetAddItemPic(listPosition)
				.getAttribute("style"));

		String itemType = (String) getBundle().getProperty(CONSM_PRCH_CD_KEY + itemToAdd);
		int itemCnt = (int) getBundle().getProperty(CART_UNIQUE_ITEM_CNT_KEY);
		int clickCnt = 0;
		searchPg.getSearchGetBtnCurrentItemAdd(listPosition).waitForEnabled(MAX_WAIT_TIME*5);
	
		itemCnt += 1;
		
		if(! searchPg.getSearchGetBtnCurrentItemAdd(listPosition).isDisplayed()){
			PerfectoUtils.scrolltoelement(searchPg.getSearchGetBtnCurrentItemAdd(listPosition));
		}		
		
		if(itemType == null){
			itemType = "EACH";
		}

		if(! itemType.equals("\"WEIGH\"")){ 
			clickCnt = multiClick(searchPg.getSearchGetBtnCurrentItemAdd(listPosition)
					, Integer.parseInt(itemAmount));
			addCntToMap(itemToAdd, clickCnt, itemCnt); 
			util.pass(clickCnt + " of " + itemToAdd + " added to cart");
		} else {
			addXlbsOfTheYItem(itemAmount, listPosition);
		}
		
	}
	
	@QAFTestStep(description = "User adds {poundAmt} lbs of the {by each weight|weight}(st|th|nd) item")
	public void addXlbsOfTheYItem(String poundAmt, String listPosition){
		SearchTestPage searchPg = new SearchTestPage();
		FunctionUtils u = new FunctionUtils();
		String itemToAdd = u.generateItemID(searchPg.getSearchGetAddItemPic(listPosition)
				.getAttribute("style"));
		try {
			hub.genProductInfo(itemToAdd);
		} catch (UnsupportedOperationException | IOException e) {
			util.fail("Product information not generated for " + itemToAdd);
		}
		String itemType = (String) getBundle().getProperty(CONSM_PRCH_CD_KEY + itemToAdd);
//		int itemCnt = (int) getBundle().getProperty(CART_UNIQUE_ITEM_CNT_KEY);

		if(itemType.equals("null")){
			itemType = "\"WEIGH\"";
			getBundle().setProperty(CONSM_PRCH_CD_KEY + itemToAdd, "WEIGH");
		}
		if(itemType.equals("\"WEIGH\"")){ 
			String [] weight = searchPg.getSearchGetDdCurrentItemSelect(listPosition).getText().split(" ");
			weight = weight[1].split("\n"); 
			util.selectBoxSelection(searchPg.getSearchGetDdCurrentItemSelect(listPosition), poundAmt + " " + weight[0]); 
		} else {
			iAddXoftheYItem(poundAmt, listPosition);
		}
		util.pass("Item added to cart");
	}


	
	/**
	 * Adds the item and its current count to the hash map. If it exists, it will only 
	 * add to its current amount and not to the unique item count
	 * @param itemToAdd What item to add to the hash map
	 * @param itemAmnt Amount to add
	 * @param uniqueItemCnt Current unique item count
	 */
	private void addCntToMap(String itemToAdd, int itemAmnt, int uniqueItemCnt){
		// Check to see if property exists. If it doesn't, add it to the hash map
		if(! getBundle().containsKey(ITEM_ID_KEY + itemToAdd)){
			getBundle().setProperty(ITEM_ID_KEY + itemToAdd, itemAmnt);
			getBundle().setProperty(CART_UNIQUE_ITEM_CNT_KEY, uniqueItemCnt);
		} else {
			// Item exists. Add it onto current amount in the hash, but don't increment
			// unique item count
			int curCount =  (int) getBundle().getProperty(ITEM_ID_KEY + itemToAdd);
			getBundle().setProperty(ITEM_ID_KEY + itemToAdd, (itemAmnt + curCount));
		}
	}
	
	
	@QAFTestStep(description = "Verify ways to shop page lists")
	public void verifyMainWaysToShop(){
		SearchTestPage searchPg = new SearchTestPage();
		
		List<QAFWebElement> shopElements = searchPg.getSearchLnkWayToShopList();
		HashMap<String, String> foundElements = new HashMap<>();
		HashMap<String, String> storedElements = new HashMap<>();
		for(int i = 1; i < WAYS_TO_SHOP.length; i++){
			foundElements.put(shopElements.get(i -1).getText(), shopElements.get(i - 1).getText());
			storedElements.put(WAYS_TO_SHOP[i], WAYS_TO_SHOP[i]);
		}
		Set<String> set1 = foundElements.keySet();
		Set<String> set2 = storedElements.keySet();
		
		if(set1.equals(set2)){
			util.pass("Items match!");
		} else {
			util.fail("Sets do not match");
			return;
		}

		WebElement currentShopPage;
		for(int i = 1; i < WAYS_TO_SHOP.length; i++){
			currentShopPage = shopElements.get(i - 1);
			ReportMessage("ways to shop item to be clicked :   "+shopElements.get(i - 1).getText(), MessageTypes.Pass);
			currentShopPage.click();
			searchPg.getSearchlnkWaysToShoptoreturn().click();

		}
	}
}
