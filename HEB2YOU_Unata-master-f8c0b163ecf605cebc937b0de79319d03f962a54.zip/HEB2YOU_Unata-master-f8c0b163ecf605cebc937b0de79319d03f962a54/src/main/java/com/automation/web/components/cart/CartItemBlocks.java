package com.automation.web.components.cart;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CartItemBlocks extends QAFWebComponent {

	public CartItemBlocks(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}

	@FindBy(locator = "cart.li.cartitemsblockprice")
	private QAFWebElement liCartitemsblockprice;

	@FindBy(locator = "cart.li.cartitemsblockqty")
	private QAFWebElement liCartitemsblockqty;
	
	@FindBy(locator = "cart.li.cartitemsweight")
	private QAFWebElement liCartitemsweight;
	

	public QAFWebElement getLiCartitemsweight() {
		return liCartitemsweight;
	}

	public void setLiCartitemsweight(QAFWebElement liCartitemsweight) {
		this.liCartitemsweight = liCartitemsweight;
	}

	@FindBy(locator = "cart.li.cartitemsblockitemtotal")
	private QAFWebElement liCartitemsblockitemtotal;
	
	@FindBy(locator = "cart.btn.cartitemblockremove")
	private QAFWebElement btnCartItemBlockRemove;
	
	@FindBy(locator = "cart.btn.cartitemblockcancel")
	private QAFWebElement btnCartItemBlockcancel ;
	
	@FindBy(locator = "cart.btn.confRemoveAll")
	private QAFWebElement btnConfRemoveAll;
	
	@FindBy(locator = "cart.btn.incrementqty")
	private QAFWebElement btnIncrementQty;
	

	@FindBy(locator = "cart.txt.qtybox")
	private QAFWebElement txtQtyBox ;
	
	/**
	 * Btn for Increment the qty button
	 */
	
	public QAFWebElement getBtnIncrementQty() {
		return btnIncrementQty;
	}
	
	/**
	 * Text box for Qty box
	 */
	public QAFWebElement getTxtQtyBox() {
		return txtQtyBox;
	}

	
	/**
	 * Button to confirm removing all items from cart
	 */
	public QAFWebElement getbtnConfRemoveAll() {
		return btnConfRemoveAll;
	}
	/**
	 * Button to cancel removing all items from cart
	 */
	public QAFWebElement getbtnCartItemBlockcancel() {
		return btnCartItemBlockcancel;
	}

	/**
	 * Removes the items from cart
	 */
	public QAFWebElement getbtnCartItemBlockRemove() {
		return btnCartItemBlockRemove;
	}


	public QAFWebElement getLiCartitemsblockprice() {
		return liCartitemsblockprice;
	}

	public QAFWebElement getLiCartitemsblockqty() {
		return liCartitemsblockqty;
	}

	public QAFWebElement getLiCartitemsblockitemtotal() {
		return liCartitemsblockitemtotal;
	}

}
