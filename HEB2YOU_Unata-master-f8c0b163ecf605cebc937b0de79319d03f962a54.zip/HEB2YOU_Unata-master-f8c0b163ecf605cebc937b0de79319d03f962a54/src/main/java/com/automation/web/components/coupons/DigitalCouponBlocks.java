package com.automation.web.components.coupons;

import java.util.List;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class DigitalCouponBlocks extends QAFWebComponent {

	public DigitalCouponBlocks(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}

	@FindBy(locator = "digcoupons.img.couponblockamountslist")
	private QAFWebElement imgCouponblockamountslist;
	@FindBy(locator = "digcoupons.img.couponblockimageslist")
	private QAFWebElement imgCouponblockimageslist;
	@FindBy(locator = "digcoupons.lbl.couponblockdescriptionslist")
	private QAFWebElement lblCouponblockdescriptionslist;
	@FindBy(locator = "digcoupons.lbl.couponblockmorelist")
	private QAFWebElement lblCouponblockmorelist;
	@FindBy(locator = "digcoupons.lbl.couponblocklimitdeslist")
	private QAFWebElement lblCouponblocklimitdeslist;
	@FindBy(locator = "digcoupons.lbl.couponblockexpirydatelist")
	private QAFWebElement lblCouponblockexpirydatelist;
	@FindBy(locator = "digcoupons.btn.couponblockselectlist")
	private QAFWebElement btnCouponblockselectlist;
	@FindBy(locator = "digcoupons.btn.couponblockselectedlist")
	private QAFWebElement btnCouponblockselectedlist;
	@FindBy(locator = "digcoupons.lbl.selectedsectioncouponnames")
	private List<QAFWebElement> lblSelectedsectioncouponnames;

	public QAFWebElement getBtnCouponblockselectedlist() {
		return btnCouponblockselectedlist;
	}

	public QAFWebElement getImgCouponblockamountslist() {
		return imgCouponblockamountslist;
	}

	public QAFWebElement getImgCouponblockimageslist() {
		return imgCouponblockimageslist;
	}

	public QAFWebElement getLblCouponblockdescriptionslist() {
		return lblCouponblockdescriptionslist;
	}

	public QAFWebElement getLblCouponblockmorelist() {
		return lblCouponblockmorelist;
	}

	public QAFWebElement getLblCouponblocklimitdeslist() {
		return lblCouponblocklimitdeslist;
	}

	public QAFWebElement getLblCouponblockexpirydatelist() {
		return lblCouponblockexpirydatelist;
	}

	public QAFWebElement getBtnCouponblockselectlist() {
		return btnCouponblockselectlist;
	}

	public List<QAFWebElement> getLblSelectedsectioncouponnames() {
		return lblSelectedsectioncouponnames;
	}
}
