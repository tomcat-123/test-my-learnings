package com.automation.web.listener;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;

import org.openqa.selenium.remote.DriverCommand;

import com.qmetry.qaf.automation.ui.webdriver.CommandTracker;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElementCommandAdapter;

public class SeleniumWebEleListener extends QAFWebElementCommandAdapter {
	
	@Override
	public void beforeCommand(QAFExtendedWebElement element, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.CLICK) || commandTracker.getCommand().equalsIgnoreCase(DriverCommand.CLICK_ELEMENT)) {
			element.waitForEnabled(MAX_WAIT_TIME);
		}
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.SEND_KEYS_TO_ELEMENT) || commandTracker.getCommand().equalsIgnoreCase(DriverCommand.SEND_KEYS_TO_ACTIVE_ELEMENT)) {
			element.click();
			element.clear();
		}
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.GET_ELEMENT_TEXT)) {
			element.waitForEnabled(MAX_WAIT_TIME);
		}
	}
}