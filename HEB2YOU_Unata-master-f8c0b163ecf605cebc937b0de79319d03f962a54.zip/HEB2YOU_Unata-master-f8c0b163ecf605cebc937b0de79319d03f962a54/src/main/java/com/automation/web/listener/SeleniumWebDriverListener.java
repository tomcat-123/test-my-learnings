/**
 * 
 */
package com.automation.web.listener;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import org.openqa.selenium.Capabilities;

import com.automation.web.pages.homepage.HomeTestPage;
import com.automation.web.steps.homepage.HomePageSteps;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriverCommandAdapter;;

public class SeleniumWebDriverListener extends QAFWebDriverCommandAdapter {

	@Override
	public void onInitialize(QAFExtendedWebDriver driver) {

		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.get(getBundle().getString("env.baseurl"));
		System.out.println("SeleniumWebDriverListener : : :onInitialize");
	}


/*
	@Override
	public void beforeCommand(QAFExtendedWebDriver driver, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.QUIT)) {
			try {
				System.out.println("beforeCommand");
				closeApp();
				driver.close();
				if (driver != null) {
					driver.close();
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}*/

/*	@Override
	public void afterCommand(QAFExtendedWebDriver driver, CommandTracker commandTracker) {

		
		super.afterCommand(driver, commandTracker);
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.CLOSE)) {
			try {
				System.out.println("afterCommand");
			} catch (Exception e) {
				// ignore
				e.printStackTrace();
			}
		}
	}*/

	@Override
	public void beforeInitialize(Capabilities desiredCapabilities) {

		if (getBundle().getString("driver.name").equalsIgnoreCase("FirefoxDriver")) {
			System.setProperty("webdriver.gecko.driver", "lib\\geckodriver.exe");
		}
		
	}

	private void closeApp() {

			HomeTestPage htp = new HomeTestPage();

			htp.getHomeImgHeblogo().click();

			if (htp.getHomeBtnYourAccount().isPresent()) {
				HomePageSteps.userClickYourAcctTab();
				HomePageSteps.userClicksLogoutTab();
			}
		
	}

	public void giftCardCreation(QAFExtendedWebDriver driver) {
		driver.get("lib\\XMLTest.htm");
	}

}
