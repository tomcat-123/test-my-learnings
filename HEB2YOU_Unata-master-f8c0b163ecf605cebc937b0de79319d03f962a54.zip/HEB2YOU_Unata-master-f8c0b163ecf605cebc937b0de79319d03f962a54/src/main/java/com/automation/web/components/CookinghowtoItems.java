package com.automation.web.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CookinghowtoItems extends QAFWebComponent {

	@FindBy(locator = "cookingtips.lbl.cookinghowtoitemnamelist")
	private QAFWebElement cookingtipsLblCookinghowtoitemnamelist;
	@FindBy(locator = "cookingtips.lbl.cookinghowtoitemtextlist")
	private QAFWebElement cookingtipsLblCookinghowtoitemtextlist;
	@FindBy(locator = "cookingtips.lnk.cookinghowtoitemreadmorelist")
	private QAFWebElement cookingtipsLnkCookinghowtoitemreadmorelist;
	@FindBy(locator = "cookingtips.img.cookinghowtoitemimagelist")
	private QAFWebElement cookingtipsImgCookinghowtoitemimagelist;

	public CookinghowtoItems(String locator) {
		super(locator);
	}

	public QAFWebElement getLblCookinghowtoitemnamelist() {
		return cookingtipsLblCookinghowtoitemnamelist;
	}

	public QAFWebElement getLblCookinghowtoitemtextlist() {
		return cookingtipsLblCookinghowtoitemtextlist;
	}

	public QAFWebElement getLnkCookinghowtoitemreadmorelist() {
		return cookingtipsLnkCookinghowtoitemreadmorelist;
	}

	public QAFWebElement getImgCookinghowtoitemimagelist() {
		return cookingtipsImgCookinghowtoitemimagelist;
	}

}
