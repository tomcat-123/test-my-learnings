package com.automation.web.databean;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import org.openqa.selenium.support.ui.Select;

import com.automation.web.pages.cartandcheckout.PayTestPage;
import com.qmetry.qaf.automation.data.BaseFormDataBean;
import com.qmetry.qaf.automation.ui.annotations.UiElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
/**
 * Class to generate a random user information at checkout. @UiElement will populate
 * at whatever location is given, so different location names are important. Sample invocation
 * of UiElement will look like:
 * <code>
 * <p>{@literal @}Randomizer(type = RandomizerTypes.{@literal <}Type Style>, length = {@literal <}string length>, suffix = {@literal <}String addendum>")</p>
 * <p>{@literal @}UiElement(fieldLoc = {@literal <}.loc variable>, order = {@literal <}order of execution>)</p>
 * <p>private String stringName;</p>
 * </code>
 * <p>Note: Can also randomize buttons on whether or not they need to be clicked. 
 * @author Garrett Griffin
 *
 */
public class AddNewCardBean extends BaseFormDataBean  {
	// Card information
	@UiElement(fieldLoc = "pay.dd.cardType")
	String type;
	@UiElement(fieldLoc = "pay.edt.cardNumber", order = 1)
	String num;
	@UiElement(fieldLoc = "pay.edt.holderName", order = 2)
	String name;
	@UiElement(fieldLoc = "pay.edt.cvvNum", order = 3)
	String csv;
	@UiElement(fieldLoc = "pay.edt.zipcode", order = 4)
	String cardZip;
	@UiElement(fieldLoc = "pay.edt.description", order = 5)
	String description;
	
	public AddNewCardBean(String cardType){
		String location = "creditCards." + cardType;

		this.num = getBundle().getString(location + ".num");
		this.csv = getBundle().getString(location + ".csv");
		this.name = getBundle().getString("creditCards.name");
		this.description = getBundle().getString(location + ".description");
		
		this.cardZip = getBundle().getString("creditCards.cardZip");
	}
	
	@Override
	public void fillRandomData() { 
		PayTestPage checkout = new PayTestPage();
		checkout.getCardSelDdExpMon().waitForPresent(50000);
//		String expMonth = getBundle().getString("creditCards.exp.month");
//		String expYear = getBundle().getString("creditCards.exp.year");
//		comUtil.enterValues(checkout.getCardSelDdExpMon(), expMonth);
//		comUtil.enterValues(checkout.getCardSelDdExpYear(), expYear);
		selectFromVisibleText(checkout.getCardSelDdExpMon(), getBundle().getString("creditCards.exp.month"));
		selectFromVisibleText(checkout.getCardSelDdExpYear(), getBundle().getString("creditCards.exp.year"));
		
		super.fillRandomData();
		
	}
	
	public void selectFromVisibleText(QAFWebElement menu, String clickMe){
		Select clickThis = new Select(menu);
		clickThis.selectByVisibleText(clickMe);
	}
	
	public void selectFromValue(QAFWebElement menu, String clickMe){
		Select clickThis = new Select(menu);
		clickThis.selectByValue(clickMe);
	}

	public String getType() {
		return type;
	}

	public String getNum() {
		return num;
	}

	public String getName() {
		return name;
	}

	public String getCsv() {
		return csv;
	}

	public String getCardZip() {
		return cardZip;
	}

	public String getDescription() {
		return description;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setNum(String num) {
		this.num = num;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setCsv(String csv) {
		this.csv = csv;
	}

	public void setCardZip(String cardZip) {
		this.cardZip = cardZip;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
