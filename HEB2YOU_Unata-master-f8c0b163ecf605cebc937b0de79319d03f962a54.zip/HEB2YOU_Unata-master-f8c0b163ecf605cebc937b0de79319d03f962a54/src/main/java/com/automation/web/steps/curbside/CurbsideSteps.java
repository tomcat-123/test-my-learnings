package com.automation.web.steps.curbside;

import static com.automation.web.commonutils.FunctionUtils.CURBSIDE_SET;
import static com.automation.web.commonutils.FunctionUtils.CUR_CHOOSEN_STORE_NAME_KEY;
import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NAME_KEY;
import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NUMBER_KEY;
import static com.automation.web.commonutils.FunctionUtils.FULFILLMENT_TYPE_KEY;
import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.PerfectoUtils.ReportMessage;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.APIHub;
import com.automation.web.commonutils.FunctionUtils;
import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.cartandcheckout.CartTestPage;
import com.automation.web.pages.cartandcheckout.CurbsideTestPage;
import com.automation.web.pages.homepage.HomeTestPage;
import com.automation.web.pages.homepage.ShopTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;


public class CurbsideSteps{
	
	
	PerfectoUtils util = new PerfectoUtils();
	Actions act = new Actions(PerfectoUtils.getDriver());

	/**
	 * Needs to wait for the pop up to be fully opened for the test to pass.
	 * All future curbside tests using this case can assume window populated
	 */
	@QAFTestStep(description = "User opens curbside window")
	public void iOpenCurbisdeWindow(){
		CurbsideTestPage curbsideTest = new CurbsideTestPage();
		CartTestPage testcart = new CartTestPage();
		
		testcart.waitForPageToLoad();
		curbsideTest.waitForPageToLoad();
		curbsideTest.getCurbBtnHdrChooseCurb().waitForEnabled(MAX_WAIT_TIME);
		if(PerfectoUtils.getDriver().getCapabilities().getBrowserName().toLowerCase().equals("safari")){
			PerfectoUtils.JavaScriptClick(curbsideTest.getCurbBtnHdrChooseCurb());
		}else{
			curbsideTest.getCurbBtnHdrChooseCurb().click();
		}
		//PerfectoUtils.waitAngularHasFinishedProcessing();
		ReportMessage("Curbside service selected", MessageTypes.Info);
		//reportiumClient.reportiumAssert("sdsdsdsd", false);
	}

	/**
	 * Unata eliminated the close button. Sending escape key now
	 */
	@QAFTestStep(description = "User closes curbside window")
	public void iCloseCurbsideWindow(){
		act.sendKeys(Keys.ESCAPE).perform();
		ReportMessage("Closed curbside window",MessageTypes.Pass);
	}

	/**
	 * Awesome thing that's been happening on the website lately. They can't decide whether or not they
	 * want the curbside button to REALLY be a button, or if they just want it as an "a" element. 
	 * The try catch will attempt to handle this
	 */
	@QAFTestStep(description = "User selects curbside pickup")
	public void iSelectCSPickup(){
		CurbsideTestPage csTest = new CurbsideTestPage();
		try{
			csTest.getCurbBtnChangeCurb().waitForEnabled(MAX_WAIT_TIME); 
			csTest.getCurbBtnChangeCurb().click();
			
			
		} catch (NoSuchElementException | TimeoutException e){ 
			QAFWebElement changeCurb = csTest.getCurbLnkChageFromWindow();
			util.mouseoverAndClick(changeCurb, changeCurb); 
		} finally {
			getBundle().setProperty("selnium.wait.timeout", "20000");
			PerfectoUtils.waitAngularHasFinishedProcessing();
		} 
		getBundle().setProperty(FULFILLMENT_TYPE_KEY, CURBSIDE_SET);
		util.pass("Curbside clicked");
	}

	@QAFTestStep(description = "User changes to curbside")
	public void iChangeCurbside(){
		CurbsideTestPage csTest = new CurbsideTestPage();
		//PerfectoUtils.waitAngularHasFinishedProcessing();
		//PerfectoUtils.waitForElement(csTest.getCurbBtnSelectCurb());
		//csTest.getCurbBtnSelectCurb().click();
		//PerfectoUtils.waitAngularHasFinishedProcessing();
		//csTest.getCurbHdrMapLoadItem().waitForEnabled(MAX_WAIT_TIME*10);
		csTest.getCurbTxtStoreFromwndow().get(0).waitForEnabled(MAX_WAIT_TIME*30);
		util.pass("Curbside changed");
	}

	/**
	 * Because of the fact they keep changing whether or not the names are passed
	 * in all caps or mixed case, toLower() is called for both the cmp name and store name
	 * @param storeName Store to search for
	 */
	@QAFTestStep(description = "User chooses {storeName}")
	public void choosesStoreByName(String storeName){
		CurbsideTestPage csTest = new CurbsideTestPage();
		csTest.getCurbTxtStoreFromwndow().get(0).waitForEnabled(MAX_WAIT_TIME*5);
		
		//APIHub hub = new APIHub();
		String cmpName = "";
		storeName = storeName.trim();
		QAFWebElement retRow = null;
		String storeNum = "";
		FunctionUtils u = new FunctionUtils();
		csTest.getCurbEdtEnterZip().clear();
		csTest.getCurbEdtEnterZip().sendKeys(storeName+Keys.ENTER);	
		List<QAFWebElement> table_element = csTest.getCurbTxtStoreFromwndow(); 
		table_element.get(0).waitForEnabled(MAX_WAIT_TIME);
		table_element = csTest.getCurbTxtStoreFromwndow(); 
		System.out.println("Store List Size "+ table_element.size());
		for(QAFWebElement row : table_element ){			
			cmpName = row.findElement(By.className("name")).getText().toLowerCase();
			if(cmpName.equals(storeName.toLowerCase())){		
				retRow = (QAFWebElement) row.findElement(By.tagName("button"));
				getBundle().setProperty(CUR_STORE_NAME_KEY, cmpName); 	
				getBundle().setProperty(CUR_CHOOSEN_STORE_NAME_KEY, cmpName);
				storeNum = u.generateStoreNum(retRow.getAttribute("id")); 
				getBundle().setProperty(CUR_STORE_NUMBER_KEY, storeNum);
				retRow.click();
				System.out.println("Store Selected :"+ storeName);
				ReportMessage("Store Selected :"+ storeName, MessageTypes.Pass);
				break;
			}
		}
		

	}

	@QAFTestStep(description = "User inputs {zipcode} and selects closest store")
	public void chooseStoreByZip(String zipcode){
		CurbsideTestPage csTest = new CurbsideTestPage();

		util.enterValueAndSendEnter(csTest.getCurbEdtEnterZip(), zipcode);
		
		//PerfectoUtils.waitForElement(csTest.getCurbBtnGetMapStoreSel(1 + ""));
		//util.mouseoverAndClick(csTest.getCurbBtnGetMapStoreSel(1 + ""), csTest.getCurbBtnGetMapStoreSel(1 + ""));
		getBundle().setProperty(CUR_STORE_NAME_KEY, csTest.getCurbGetSelectedStoreName(1 + "").getText());

		ReportMessage("Closest store selected!",MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify the user selected store is displaying on the home page")
	public void selectedStoreVerification(){
		HomeTestPage homepage = new HomeTestPage();
		ShopTestPage nav = new ShopTestPage();
		
		String cmpName = getBundle().getProperty(CUR_STORE_NAME_KEY) + "";
		cmpName = cmpName.replaceAll("[\"'\u2018\u2019\u201c\u201d]", "");
		try{
			homepage.getHomeTxtCurCurbDisplay().waitForText(cmpName.toUpperCase(), MAX_WAIT_TIME);
		} catch(Exception e){
			nav.getNavBoxCompareCartModal().waitForVisible(MAX_WAIT_TIME);
			nav.getNavBtnCompareCartModalContinue().click();
			ReportMessage("Warning module activated.",MessageTypes.Info);
		}
		
		ReportMessage("Store displayed " + cmpName + " as expected",MessageTypes.Pass);
	}
	
	@QAFTestStep(description = "Verify the user selected zipcode is displaying on the home page")
	public void selectedZipVerification(){
		HomeTestPage homepage = new HomeTestPage();
		String cmpName = getBundle().getProperty(CUR_STORE_NAME_KEY) + "";
		cmpName = cmpName.replaceAll("[\"'\u2018\u2019\u201c\u201d]", ""); 
		homepage.getHomeTxtCurDelDisplay().waitForText(cmpName, MAX_WAIT_TIME);
		ReportMessage("Store displayed " + cmpName + " as expected",MessageTypes.Pass);
	}

	@QAFTestStep(description = "User navigates to store selection from curbside window")
	public void navToStoreSelect(){
		CurbsideTestPage curbside = new CurbsideTestPage();
		curbside.getCurbBtnChooseStoreMain().click();
		//PerfectoUtils.waitForElement(curbside.getCurbBoxMapBox());
			ReportMessage("Navigated to store selection",MessageTypes.Pass);
	}

	@QAFTestStep(description = "User selects store based on {number}")
	public void storeSelectByNum(String storeNumber){
		CurbsideTestPage csTest = new CurbsideTestPage();
		APIHub hub = new APIHub();
		try {
			hub.getStoreName(storeNumber);
			hub.genTaxInfo(storeNumber);
		} catch (UnsupportedOperationException | IOException e) {
			ReportMessage("Store information not set for " + storeNumber,MessageTypes.Pass);
		}		
		
		String cmpName =  (String)getBundle().getProperty(CUR_STORE_NAME_KEY);
		
		util.enterValueAndSendEnter(csTest.getCurbEdtEnterZip(), cmpName.replaceAll("\"", ""));

		//PerfectoUtils.waitForElement(csTest.getCurbBtnGetMapStoreSel(1 + ""));
		//util.mouseoverAndClick(csTest.getCurbBtnGetMapStoreSel(1 + ""), csTest.getCurbBtnGetMapStoreSel(1 + ""));

		ReportMessage(cmpName.replaceAll("\"", "") + " selected!",MessageTypes.Pass);
	}
}
