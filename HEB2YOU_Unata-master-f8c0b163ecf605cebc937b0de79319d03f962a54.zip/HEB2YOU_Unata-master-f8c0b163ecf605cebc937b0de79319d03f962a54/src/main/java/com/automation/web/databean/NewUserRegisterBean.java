package com.automation.web.databean;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.qmetry.qaf.automation.data.BaseFormDataBean;
import com.qmetry.qaf.automation.ui.annotations.UiElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.RandomStringGenerator.RandomizerTypes;
import com.qmetry.qaf.automation.util.Randomizer;

/**
 * Class to generate a random user information at checkout. @UiElement will populate
 * at whatever location is given, so different location names are important. Sample invocation
 * of UiElement will look like:
 * <code>
 * <p>{@literal @}Randomizer(type = RandomizerTypes.{@literal <}Type Style>, length = {@literal <}string length>, suffix = {@literal <}String addendum>")</p>
 * <p>{@literal @}UiElement(fieldLoc = {@literal <}.loc variable>, order = {@literal <}order of execution>)</p>
 * <p>private String stringName;</p>
 * </code>
 * <p>Note: Can also randomize buttons on whether or not they need to be clicked. 
 * @author Garrett Griffin
 *
 */
public class NewUserRegisterBean extends BaseFormDataBean{
	
	@Randomizer(type = RandomizerTypes.MIXED, length = 5, suffix = "@mailnator.com")
	@UiElement(fieldLoc = "register.edt.email", order = 1)
	private String email;

	@Randomizer(type = RandomizerTypes.LETTERS_ONLY, length = 10)
	@UiElement(fieldLoc = "register.edt.password", order = 2)
	private String password;
	
	@Randomizer(type = RandomizerTypes.MIXED, length = 10)
	@UiElement(fieldLoc = "register.edt.reenterpwd", order = 3)
	private String confPassword;
	
	@UiElement(fieldLoc = "register.edt.mobileNum", order = 4)
	private String mobileNum;
	
	@Randomizer(type = RandomizerTypes.LETTERS_ONLY, length = 10)
	@UiElement(fieldLoc = "register.edt.firstname", order = 5)
	private String firstname;
	
	@Randomizer(type = RandomizerTypes.LETTERS_ONLY, length = 10)
	@UiElement(fieldLoc = "register.edt.lastname", order = 6)
	private String lastname;



	@Randomizer
	@UiElement(fieldLoc = "register.chk.promotions", order = 7)
	private Boolean optInPromos;
	
	/**
	 * Randomly clicks opt-in button. 
	 */
	public void clickOptInBtn() {
		QAFExtendedWebElement ele = new QAFExtendedWebElement("register.chk.promotions");
		boolean isSelected = ele.isSelected();
		if (!(optInPromos && isSelected)) {
			ele.click();
		}
	}
	
	@Override
	/**
	 * Fills in all data, and sets the passwords to match
	 */
	public void fillRandomData() {
		String salt = "1*";
		super.fillRandomData();
		this.mobileNum = getBundle().getString("validPhoneNumbers.mobile");
		this.setPassword(this.password + salt);
		setConfPassword(password);
	}
	

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}

	public String getConfPassword() {
		return confPassword;
	}

	public String getMobileNum() {
		return mobileNum;
	}

	public Boolean getOptInPromos() {
		return optInPromos;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setConfPassword(String confPassword) {
		this.confPassword = confPassword;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	public void setOptInPromos(Boolean optInPromos) {
		this.optInPromos = optInPromos;
	}
	
	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	
	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	
}
