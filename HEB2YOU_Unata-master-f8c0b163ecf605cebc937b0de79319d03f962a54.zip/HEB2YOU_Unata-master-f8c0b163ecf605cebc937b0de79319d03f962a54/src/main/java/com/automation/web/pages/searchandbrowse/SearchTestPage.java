package com.automation.web.pages.searchandbrowse;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SearchTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}

	public synchronized void loadPage(){
		searchPageLoadItem.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}

	@FindBy(locator = "search.box.navTab")
	private QAFWebElement searchBoxNavTab;

	@FindBy(locator = "search.txt.resultsFound")
	private QAFWebElement searchTxtResultsFound;

	@FindBy(locator = "search.get.pageResults")
	private QAFWebElement searchGetPageResults;

	@FindBy(locator = "search.get.s.pageItemPicture")
	private QAFWebElement searchGetSPageItemPicture;

	@FindBy(locator = "search.get.btn.currentItemAdd")
	private QAFWebElement searchGetBtnCurrentItemAdd;

	@FindBy(locator = "search.get.btn.currentItemDec")
	private QAFWebElement searchGetBtnCurrentItemDec;

	@FindBy(locator = "search.get.dd.currentItemSelect")
	private QAFWebElement searchGetDdCurrentItemSelect;

	@FindBy(locator = "search.edt.searchBarInput")
	private QAFWebElement searchEdtSearchBarInput;

	@FindBy(locator = "search.btn.searchBtnConf")
	private QAFWebElement searchBtnSearchBtnConf;

	@FindBy(locator = "search.txt.resultHeader")
	private QAFWebElement searchTxtResultHeader;

	@FindBy(locator = "search.pageLoadItem")
	private QAFWebElement searchPageLoadItem;

	@FindBy(locator = "search.get.addItemPic")
	private QAFWebElement searchGetAddItemPic;

	@FindBy(locator = "search.btn.nextPg")
	private QAFWebElement searchBtnNextPg;

	@FindBy(locator = "search.btn.prevPg")
	private QAFWebElement searchBtnPrevPg;

	@FindBy(locator = "search.get.pageNumber")
	private QAFWebElement searchGetPageNumber;

	@FindBy(locator = "search.get.selectWeight")
	private QAFWebElement searchGetSelectWeight;

	@FindBy(locator = "search.get.selectedItemTitle")
	private QAFWebElement searchGetSelectedItemTitle;

	@FindBy(locator = "search.get.prodType")
	private QAFWebElement searchGetProdType;
	
	@FindBy(locator = "search.txt.searchlist")
	private List<QAFWebElement> searchtxtsearchlist;
	
	@FindBy(locator = "search.txt.nextpageicon")
	private QAFWebElement searchtxtnextpageicon;
	
	@FindBy(locator = "search.lnk.waytoshoplist")
	private List<QAFWebElement> searchlnkwaytoshoplist;
	
	@FindBy(locator = "search.lnk.fisrtresultfromcdp")
	private QAFWebElement searchlnkfisrtresultfromcdp;
	
	@FindBy(locator = "search.lbl.nosearchresult")
	private QAFWebElement lblNoSearchResult;
	
	@FindBy(locator = "search.lnk.waystoshop")
	private QAFWebElement searchlnkWaysToShoptoreturn;
	

	public QAFWebElement getSearchlnkWaysToShoptoreturn() {
		return searchlnkWaysToShoptoreturn;
	}

	public void setSearchlnkWaysToShoptoreturn(QAFWebElement searchlnkWaysToShoptoreturn) {
		this.searchlnkWaysToShoptoreturn = searchlnkWaysToShoptoreturn;
	}

	public QAFWebElement getLblNoSearchResult() {
		return lblNoSearchResult;
	}

	public void setLblNoSearchResult(QAFWebElement lblNoSearchResult) {
		this.lblNoSearchResult = lblNoSearchResult;
	}

	/**
	 * First Search Result from CDP
	 */
	public QAFWebElement getSearchLnkFisrtResultFromCdp() {
		return searchlnkfisrtresultfromcdp;
	}

	/**
	 * List of way to shop List
	 */
	public List<QAFWebElement> getSearchLnkWayToShopList() {
		return searchlnkwaytoshoplist;
	}
		
	/**
	 * Navigation tab on next page
	 */
	public QAFWebElement getSearchTxtNextPageIcon(){ return searchtxtnextpageicon; }
	
	/**
	 * List of serach result from search Page
	 */
	public List<QAFWebElement> getSearchTxtSearchList() {
		return searchtxtsearchlist;
	}

	/**
	 * Navigation tab on sidebar on search page
	 */
	public QAFWebElement getSearchBoxNavTab(){ return searchBoxNavTab; }

	/**
	 * Number of results found for searched item
	 */
	public QAFWebElement getSearchTxtResultsFound(){ return searchTxtResultsFound; }

	/**
	 * List value of all results found
	 */
	public QAFWebElement getSearchGetPageResults(String item){ 
		String retElm = String.format(pageProps.getString("search.get.pageResults"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Page Item Picture Box
	 */
	public QAFWebElement getSearchGetSPageItemPicture(String item){ 
		String retElm = String.format(pageProps.getString("search.get.s.pageItemPicture"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Add button for current item
	 */
	public QAFWebElement getSearchGetBtnCurrentItemAdd(String item){ 
		String retElm = String.format(pageProps.getString("search.get.btn.currentItemAdd"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Subtract button for current item
	 */
	public QAFWebElement getSearchGetBtnCurrentItemDec(String item){ 
		String retElm = String.format(pageProps.getString("search.get.btn.currentItemDec"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Select drop down menu
	 */
	public QAFWebElement getSearchGetDdCurrentItemSelect(String item){ 
		String retElm = String.format(pageProps.getString("search.get.dd.currentItemSelect"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Input box to search for items
	 */
	public QAFWebElement getSearchEdtSearchBarInput(){ return searchEdtSearchBarInput; }

	/**
	 * Button to confirm search
	 */
	public QAFWebElement getSearchBtnSearchBtnConf(){ return searchBtnSearchBtnConf; }

	/**
	 * Header of results
	 */
	public QAFWebElement getSearchTxtResultHeader(){ return searchTxtResultHeader; }

	/**
	 * Search result with number of hits
	 */
	public QAFWebElement getSearchPageLoadItem(){ return searchPageLoadItem; }

	/**
	 * Picture of the item to be added to cart
	 */
	public QAFWebElement getSearchGetAddItemPic(String item){ 
		String retElm = String.format(pageProps.getString("search.get.addItemPic"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Next page Button
	 */
	public QAFWebElement getSearchBtnNextPg(){ return searchBtnNextPg; }

	/**
	 * Previous page Button
	 */
	public QAFWebElement getSearchBtnPrevPg(){ return searchBtnPrevPg; }

	/**
	 * Numbered buttons. List is one more then displayed button number
	 */
	public QAFWebElement getSearchGetPageNumber(String item){ 
		String retElm = String.format(pageProps.getString("search.get.pageNumber"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Activates drop down menu for weight selection
	 */
	public QAFWebElement getSearchGetSelectWeight(String item){ 
		String retElm = String.format(pageProps.getString("search.get.selectWeight"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Title of the item selected
	 */
	public QAFWebElement getSearchGetSelectedItemTitle(String item){ 
		String retElm = String.format(pageProps.getString("search.get.selectedItemTitle"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Display for if item type is 'each' or 'weight'
	 */
	public QAFWebElement getSearchGetProdType(String item){ 
		String retElm = String.format(pageProps.getString("search.get.prodType"), item);
	    return new QAFExtendedWebElement(retElm);
	}

}