package com.automation.web.steps.common;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.PerfectoUtils.ReportMessage;

import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.homepage.HomeTestPage;
import com.automation.web.steps.browseandsearch.SearchPageSteps;
import com.automation.web.steps.cartandcheckout.CartSteps;
import com.automation.web.steps.cartandcheckout.CheckoutSteps;
import com.automation.web.steps.curbside.CurbsideSteps;
import com.automation.web.steps.delivery.DeliverySteps;
import com.automation.web.steps.homepage.HomePageSteps;
import com.automation.web.steps.registerandlogin.LoginPageSteps;
import com.automation.web.steps.registerandlogin.RegistrationPageSteps;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;

/**
 * Clubbed versions of commonly used steps. Good starting point for figuring out
 * project/site functionality
 * 
 */






public class CommonSteps {
	PerfectoUtils util = new PerfectoUtils();
	Actions act = new Actions(PerfectoUtils.getDriver());

	/**
	 * Takes in search term, and adds pounds/each of the item specified.
	 * 
	 * @param searchItem
	 *            Term to search for
	 * @param itemAmount
	 *            Amount to add to cart
	 * @param listPosition
	 *            Position in search for item
	 */
	@QAFTestStep(description = "User searches for {searchItem}, and adds {itemAmount} of "
			+ "{listPosition}(st|nd|rd) item to cart")
	public static void userAddsItemX(String searchItem, String itemAmount, String listPosition) {
		SearchPageSteps searchPage = new SearchPageSteps();
		//searchPage.iSearchForX(searchItem);
		searchPage.userSearchForX(searchItem);
		searchPage.iClickOnTheSearchIcon();
		searchPage.verifySearchPage();
		
		searchPage.iAddXoftheYItem(itemAmount, listPosition);
		
		
		
	}

	@QAFTestStep(description = "From homepage, user searches for {searchItem}, adds {itemAmount} of {listPosition}(st|nd|rd|th) item, and navigates to checkout")
	public static void quickAdd(String searchItem, String itemAmount, String listPosition) {
		CheckoutSteps checkout = new CheckoutSteps();
		CartSteps cart = new CartSteps();
		HomePageSteps home = new HomePageSteps();

		home.userAmOnHomePage();
		userAddsItemX(searchItem, itemAmount, listPosition);
		checkout.iClickMainCheckout();
		cart.checkCartItems();
	}

	/**
	 * Clicks the timeslot button in the top header, and sets the reservation
	 * time to the provided day of the month, and timeslot
	 * 
	 * @param dayOfMonth
	 * @param startTime
	 * @param endTime
	 */
	@QAFTestStep(description = "User selects timeslot {dayOfMonth}(st|th) of the month, time range of {startTime}"
			+ " to {endTime}")
	public void timeSlotSelection(String dayOfMonth, String startTime, String endTime) {
		CheckoutSteps checkout = new CheckoutSteps();
		checkout.clickTimeslotButton();
		checkout.selectDayTS(dayOfMonth);
		checkout.selectTime(startTime, endTime);
		checkout.verifyTimeAndDate();
	}

	@QAFTestStep(description = "User registers new account while navigating to payment page to add a credit card")
	public static void navToPymtPage() {
		CheckoutSteps checkout = new CheckoutSteps();
		CartSteps cart = new CartSteps();
		HomePageSteps home = new HomePageSteps();
		home.userClicksLoginRegisterButton();
		newAcctRegi();
		cart.continueFromReviewCartPg();
		
		CheckoutSteps.selectTimeSlot();
		checkout.scheduleConf();
		
		checkout.delConfirmation();
		checkout.navToPaymentPage();
		checkout.clickCreditCardButton();
	}

	@QAFTestStep(description = "User navigates from main checkout to payment page")
	public void fromMChkoutToPymtPg() {
		CheckoutSteps checkout = new CheckoutSteps();
		CartSteps cart = new CartSteps();
		cart.continueFromReviewCartPg();
		checkout.scheduleConf();
		checkout.delConfirmation();
		checkout.navToPaymentPage();
	}

	@QAFTestStep(description = "User adds a new {creditCard}")
	public void generateNewCC(String creditCard) {
		CheckoutSteps checkout = new CheckoutSteps();
		checkout.createNewCreditCard(creditCard);
		checkout.addCreditCard();
		checkout.verifyCreditCard(creditCard);
	}

	@QAFTestStep(description = "User creates new {creditCard} and fills in valid billing information")
	public static void createNewCCWithBilling(String creditCardType) {
		CheckoutSteps checkout = new CheckoutSteps();
		
		// util.generateWebElement("//div[@class='payment-gateway']/div/div/button").click();
		//checkout.clickCreditCardButton();
		checkout.createNewCreditCard(creditCardType);
		checkout.verifyCreditCard(creditCardType);
		checkout.verifyBilling();
	}

	
	/**
	 * Clicks the header curbside button, then selects the given store name
	 * 
	 * @param storeName
	 */
	@QAFTestStep(description = "User selects curbside and selects {storeName}")
	public void curbStoreSelect(String storeName) {
		CurbsideSteps curbside = new CurbsideSteps();
		curbside.iOpenCurbisdeWindow();
		curbside.iSelectCSPickup();
		curbside.iChangeCurbside();
		curbside.choosesStoreByName(storeName);
		curbside.selectedStoreVerification();
	}

	@QAFTestStep(description = "User selects delivery and enters {zipcode}")
	public void deliveryQuickSelect(String zipcode) {
		DeliverySteps delivery = new DeliverySteps();
		CurbsideSteps curbside = new CurbsideSteps();
		curbside.iOpenCurbisdeWindow();
		delivery.userSelectsDeliveryService();
		delivery.validStoreByZip(zipcode);
		curbside.selectedZipVerification();
	}

	@QAFTestStep(description = "User enters {zipcode} for delivery, selects {dayOfMonth} timeslot from {startTime} to {endTime}")
	public void deliveryWithTimeslots(String zipcode, String dayOfMonth, String startTime, String endTime) {
		deliveryQuickSelect(zipcode);
		timeSlotSelection(dayOfMonth, startTime, endTime);
	}

	
	/*
	 * 
	 * Please use re-usable steps instead of new customized steps 
	 * 
	 **/
	@QAFTestStep(description = "User enters {zipcode} for delivery, selects first available timeslot")
	public void deliverWithFirstTS(String zipcode) {
		CheckoutSteps checkout = new CheckoutSteps();
		deliveryQuickSelect(zipcode);
		checkout.firstTimeSlot();
	}
	 

	/**
	 * A "Given" starting point. Starts on the homepage to establish baseline
	 * for all items (hot user, tax, etc.), then selects store and reservation
	 * times
	 * 
	 * @param storeName
	 * @param startTime
	 * @param endTime
	 * @param dayOfMonth
	 */
	@QAFTestStep(description = "User on homepage selects {storeName} for curbside, "
			+ "timeslot {startTime} to {endTime} on {dayOfMonth}")
	public void homePageCurbsideSet(String storeName, String startTime, String endTime, String dayOfMonth) {
		HomePageSteps homePg = new HomePageSteps();
		homePg.userAmOnHomePage();
		curbStoreSelect(storeName);
		timeSlotSelection(dayOfMonth, startTime, endTime);

	}
	
	@QAFTestStep(description = "Verify Store Categeries {storeid} {storeName}")
	  
	  // Please use re-usable steps instead of new customized steps 
	public void verifyStoreCategeries(String storeid,String storeName) { 
		
			HomePageSteps homePg = new HomePageSteps();
			HomeTestPage homeTestPage = new HomeTestPage();
			System.out.println("Store ID  : " + storeid + " storeName : " + storeName);
			ReportMessage("Store ID  : " + storeid + " storeName : " + storeName);
			String Url =new String("https://shop.hebtoyou.com/?shopping_context=pickup&store_id="+storeid);
			PerfectoUtils.getDriver().get(Url);
			homeTestPage.getHomeImgHeblogo().waitForPresent(MAX_WAIT_TIME);
			
			if(homeTestPage.getHomeImgHeblogo().isPresent()) {
				
				ReportMessage("HEBToYou Home page is Displayed", MessageTypes.Pass);
			} else {
				
				ReportMessage("Home Page verification is Failed:  ", MessageTypes.Fail);			
			
			}
			
			
			homePg.iVerifyEachCategoryInTheHeader();
			
			/*String itemToSearch=ConfigurationManager.getBundle().getString("ItemType.EachWeight.name");
			

			searchtestPage.getSearchEdtSearchBarInput().waitForEnabled(MAX_WAIT_TIME);
			try {
				act.moveToElement(searchtestPage.getSearchEdtSearchBarInput());
				act.click();
				act.perform();
			} catch (WebDriverException e) {

				searchtestPage.getSearchEdtSearchBarInput().waitForEnabled(MAX_WAIT_TIME);
				util.scrollAndClick(searchtestPage.getSearchEdtSearchBarInput());
			}
			util.enterValues(searchtestPage.getSearchEdtSearchBarInput(), itemToSearch);
			ReportMessage("Item " + itemToSearch + " entered into search bar", MessageTypes.Info);
			searchPageSteps.iClickOnTheSearchIcon();
		  */
		
		
		
	}
	
	  @QAFTestStep(description = "User on homepage selects {storeName} for curbside, and first timeslot")
	public void homePageFirstCurbSet(String storeName) {
		HomePageSteps homePg = new HomePageSteps();
		CheckoutSteps checkout = new CheckoutSteps();
		homePg.userAmOnHomePage();
		curbStoreSelect(storeName);
		checkout.firstTimeSlot();
	}

	@QAFTestStep(description = "User sucessfully registers new account")
	public static void newAcctRegi() {
		RegistrationPageSteps register = new RegistrationPageSteps();
		
		register.iClickRegistrationPage();
		register.iEnterAllRequiredFieldsInregistrationPage();
		
		register.iSubmitTheregistrationForm();
		PerfectoUtils.waitAngularHasFinishedProcessing();
	}

	@QAFTestStep(description = "User selects {store} for curbside, and registers new account")
	public void registerAndCurb(String storeName) {
		HomePageSteps homePg = new HomePageSteps();
		homePg.userAmOnHomePage();
		homePg.userClicksLoginRegisterButton();
		newAcctRegi();
		curbStoreSelect(storeName);
		CheckoutSteps.secondTimeSlot();
	}

	@QAFTestStep(description = "User logs into verified account with {email} {password}")
	public void loginToAcct(String email, String password) {
		HomePageSteps homePg = new HomePageSteps();
		LoginPageSteps login = new LoginPageSteps();
		homePg.userClicksLoginRegisterButton();
		login.iEnterValidEmailAndPassword(email, password);
	}

	@QAFTestStep(description = "User navigates from Review Cart and logs into account with {email} {password}")
	public void navFromReviewAndLogin(String email, String password) {
		CartSteps cart = new CartSteps();
		LoginPageSteps login = new LoginPageSteps();
		cart.continueFromReviewCartPg();
		
		login.iEnterValidEmailAndPassword(email, password);
		login.userSubmitsLoginForm();
		cart.continueFromReviewCartPg();
	}

	@QAFTestStep(description = "User logs in with {email} and {password} and selects {storeName} for curbside")
	public void loginAndSelectCurb(String email, String password, String storeName) {
		LoginPageSteps login = new LoginPageSteps();
		loginToAcct(email, password);
		login.userSubmitsLoginForm();
		curbStoreSelect(storeName);
	}

	@QAFTestStep(description = "User on homepage logs in with {email}{password}, selects {storeName} for curbside,"
			+ "timeslot {startTime} to {endTime} on {dayOfMonth}")
	public void hotUserCurbsideSet(String email, String password, String storeName, String startTime, String endTime,
			String dayOfMonth) {
		homePageCurbsideSet(storeName, startTime, endTime, dayOfMonth);
		loginToAcct(email, password);
	}

	@QAFTestStep(description = "Click on Heb to you logo and navigate to Homepage")
	public void clickOnHebToYouLogoAndNavigateToHomepage() {
		//OrderCompleteTestPage ordercomplete = new OrderCompleteTestPage();
		HomeTestPage ordercomplete =new HomeTestPage();
		ordercomplete.getHomeImgHeblogo().waitForPresent(MAX_WAIT_TIME);
		ordercomplete.getHomeImgHeblogo().click();
		ReportMessage("Clicked on HEB To You Logo..", MessageTypes.Pass);
	}
	
	public int mathRandom(int min, int max) {
		int range = (max - min) + 1;
		return (int) (Math.random() * range) + min;
	}

}
