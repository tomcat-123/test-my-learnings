package com.automation.web.components.shopassistpickup;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class StoreItemBlocks extends QAFWebComponent {

	public StoreItemBlocks(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}

	@FindBy(locator = "curbpickup.icon.storesearchmapicon")
	private QAFWebElement iconStoreSearchMapicon;
	
	@FindBy(locator = "curbpickup.lbl.storesearchname")
	private QAFWebElement lblStoreSearchName;
	
	@FindBy(locator = "curbpickup.lbl.storesearchaddress")
	private QAFWebElement lblStoreSearchAddress;
	
	@FindBy(locator = "curbpickup.btn.storesearchselect")
	private QAFWebElement btnStoreSearchSelect;

	public QAFWebElement getIconStoreSearchMapicon() {
		return iconStoreSearchMapicon;
	}


	public QAFWebElement getLblStoreSearchName() {
		return lblStoreSearchName;
	}


	public QAFWebElement getLblStoreSearchAddress() {
		return lblStoreSearchAddress;
	}


	public QAFWebElement getBtnStoreSearchSelect() {
		return btnStoreSearchSelect;
	}



}
