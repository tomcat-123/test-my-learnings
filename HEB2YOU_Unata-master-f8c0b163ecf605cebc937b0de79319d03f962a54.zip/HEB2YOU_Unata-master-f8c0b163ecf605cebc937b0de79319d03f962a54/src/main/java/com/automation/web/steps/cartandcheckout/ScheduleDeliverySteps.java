package com.automation.web.steps.cartandcheckout;

import static com.automation.web.commonutils.PerfectoUtils.ReportMessage;

import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.cartandcheckout.ScheduleDeliveryTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;

/* 
 * List of Step Definitions in Curbside Steps file
Validate user on pickup schedule page
*/

public class ScheduleDeliverySteps {

	PerfectoUtils util = new PerfectoUtils();
	Actions act = new Actions(PerfectoUtils.getDriver());

	@QAFTestStep(description = "Validate user on delivery schedule page")
	public void validateUserOnScheduleDeliveryPage() {
		ScheduleDeliveryTestPage ScheduleDelivery = new ScheduleDeliveryTestPage();
		
		ScheduleDelivery.waitForPageToLoad();
		ScheduleDelivery.getschdldeliveryLblHeader().verifyPresent();
		ReportMessage("Schedule for delivery page is displayed", MessageTypes.Pass);

	}
	


}
