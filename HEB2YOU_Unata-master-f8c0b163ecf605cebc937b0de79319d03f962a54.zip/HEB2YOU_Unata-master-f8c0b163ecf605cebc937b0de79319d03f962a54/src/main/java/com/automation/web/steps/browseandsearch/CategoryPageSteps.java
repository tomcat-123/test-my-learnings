package com.automation.web.steps.browseandsearch;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.PerfectoUtils.ReportMessage;
import static com.automation.web.commonutils.PerfectoUtils.doubleClick;
import static com.automation.web.commonutils.PerfectoUtils.mousehoverusingActions;

import java.util.ArrayList;
import java.util.List;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.searchandbrowse.CategoryTestPage;
import com.automation.web.steps.common.CommonSteps;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;

/*
 * List of Step Definitions in Categories Steps file 
 * 
Navigate to Random L1 Category
Navigate to Random L2 Category
Navigate to Random L3 Category

*/
public class CategoryPageSteps {
	CommonSteps common = new CommonSteps();
	boolean itemfoundL3 = false;
	boolean itemfoundL2 = false;

	@QAFTestStep(description = "Navigate to Random L1 Category")
	public synchronized void navigateToRandomL1Category() {
		CategoryTestPage category = new CategoryTestPage();
	

		boolean itemfound = false;

		int min = 1;
		int L1catcount = category.getLiLeftnavLOneCategory().size();
		int randomlevelCat = common.mathRandom(min, L1catcount - min);
		category.getLiLeftnavLOneCategory().get(randomlevelCat).verifyPresent();
		doubleClick(category.getLiLeftnavLOneCategory().get(randomlevelCat));
		category.getLblTxtHeaderpage().waitForPresent(MAX_WAIT_TIME);
		if (category.getLblErrmsgnoitem().isPresent()) {
			navigateToRandomL1Category();
		} else {

			category.getBtnAddtocart().get(min - 1).waitForPresent(MAX_WAIT_TIME);
			itemfound = category.getBtnAddtocart().get(min - 1).isPresent();
			if (itemfound) {
				category.getBtnAddtocart().get(min - 1).verifyPresent();
				ReportMessage("Random product is choosen from L1 category", MessageTypes.Pass);
			}

		}
	}

	@QAFTestStep(description = "Navigate to Random L2 Category")
	public synchronized void navigateToRandomL2Category() {
		CategoryTestPage category = new CategoryTestPage();
	

		boolean itemfound = false;

		int min = 1;
		int L1catcount = category.getLiLeftnavLOneCategory().size();
		int randomlevelCat = common.mathRandom(min, L1catcount - min);
		category.getLiLeftnavLOneCategory().get(randomlevelCat).verifyPresent();
		doubleClick(category.getLiLeftnavLOneCategory().get(randomlevelCat));
		category.getLblTxtHeaderpage().waitForPresent(MAX_WAIT_TIME);
		if (itemfoundL2) {
			// ignore
		} else {
			if (category.getLblErrmsgnoitem().isPresent()) {
				navigateToRandomL2Category();
			}

			if (itemfoundL2) {
				// ignore
			} else {

				// click L2 random child category
				int L2catcount = category.getLiLeftnavLTwoCategory().size();
				int level = 2;
				boolean itemfoundL2 = clickOnRandomL2_Category(itemfound, itemfoundL3, L2catcount, level);

				if (itemfoundL2) {
					category.getBtnAddtocart().get(min - 1).verifyPresent();
					ReportMessage("Random product is choosen from L2 category", MessageTypes.Pass);
				}

			}
		}

	}
	
	@QAFTestStep(description = "Navigate to Random L2 Category from main")
	public synchronized void navigateToRandomL2Categoryfrommain() {
		CategoryTestPage category = new CategoryTestPage();
	

		boolean itemfound = false;

		int min = 1;
		int L1catcount = category.getLiLeftnavLOneCategory().size();
		int randomlevelCat = common.mathRandom(min, L1catcount - min);
		category.getLiLeftnavLOneCategory().get(randomlevelCat).verifyPresent();
		doubleClick(category.getLiLeftnavLOneCategory().get(randomlevelCat));
		category.getLblTxtHeaderpage().waitForPresent(MAX_WAIT_TIME);
		if (itemfoundL2) {
			// ignore
		} else {
			if (category.getLblErrmsgnoitem().isPresent()) {
				navigateToRandomL2Categoryfrommain();
			}

			if (itemfoundL2) {
				// ignore
			} else {

				// click L2 random child category
				int L2catcount = category.getLiMainLevelTwoCategory().size();
				int level = 2;
				boolean itemfoundL2 = clickOnRandomL2_CategoryfromMain(itemfound, itemfoundL3, L2catcount, level);

				if (itemfoundL2) {
					category.getBtnAddtocart().get(min - 1).verifyPresent();
					ReportMessage("Random product is choosen from L2 category", MessageTypes.Pass);
				}

			}
		}

	}
	
	@QAFTestStep(description = "Navigate to Random L3 Category from main")
	public synchronized void navigateToRandomL3Categoryfrommain() {
		CategoryTestPage category = new CategoryTestPage();
		

		boolean itemfound = false;

		int min = 1;
		int L1catcount = category.getLiLeftnavLOneCategory().size();
		int randomlevelCat = common.mathRandom(min, L1catcount - min);
		category.getLiLeftnavLOneCategory().get(randomlevelCat).verifyPresent();
		mousehoverusingActions(category.getLiLeftnavLOneCategory().get(randomlevelCat));
		category.getLiLeftnavLOneCategory().get(randomlevelCat).click();
		category.getLblTxtHeaderpage().waitForPresent(MAX_WAIT_TIME);
		if (itemfoundL2) {
			// ignore
		} else {
			if (category.getLblErrmsgnoitem().isPresent()) {
				navigateToRandomL3Categoryfrommain();
			}

			if (itemfoundL2) {
				// ignore
			} else {

				// click L2 random child category
				category.waitForPageToLoad();
				int L3catcount = category.getLiMainLevelThreeCategory().size();
				int level = 2;
				boolean itemfoundL2 = clickOnRandomL3_CategoryfromMain(itemfound, itemfoundL3, L3catcount, level);

				if (itemfoundL2) {
					category.getBtnAddtocart().get(min - 1).verifyPresent();
					ReportMessage("Random product is choosen from L3 category", MessageTypes.Pass);
				}

			}
		}

	}

	public boolean clickOnRandomL2_Category(boolean itemfound, boolean itemfoundL3, int L2catcount, int level) {

		CategoryTestPage category = new CategoryTestPage();
		boolean itemfoundL2 = false;
		int temp = L2catcount;

		if (itemfoundL2) {
			// ignore
		} else {
			if (temp == 0) {
				navigateToRandomL2Category();
			}
			if (itemfoundL2) {
				// ignore
			} else {
				int min = 1;
				int randomlevelCat = common.mathRandom(min, L2catcount - min);
				PerfectoUtils.mousehoverusingActions(category.getLiLeftnavLTwoCategory().get(randomlevelCat - 1));
				category.getLiLeftnavLTwoCategory().get(randomlevelCat - 1).verifyPresent();
				category.getLiLeftnavLTwoCategory().get(randomlevelCat - 1).click();
				category.getLblTxtHeaderpage().waitForPresent(MAX_WAIT_TIME);
				if (category.getLblErrmsgnoitem().isPresent()) {
					category.getLiCatbreadcrumpse().get(level).waitForPresent(MAX_WAIT_TIME);
					category.getLiCatbreadcrumpse().get(level - 1).click();
					navigateToRandomL2Category();
				}
				if (itemfoundL2) {
					// ignore
				} else {

					category.getLblTxtHeaderpage().waitForPresent(MAX_WAIT_TIME);
					itemfoundL2 = category.getBtnAddtocart().get(min - 1).isPresent();

				}
			}
		}

		return itemfoundL2;

	}
	
	public boolean clickOnRandomL2_CategoryfromMain(boolean itemfound, boolean itemfoundL3, int L2catcount, int level) {

		CategoryTestPage category = new CategoryTestPage();
		boolean itemfoundL2 = false;
		int temp = L2catcount;

		if (itemfoundL2) {
			// ignore
		} else {
			if (temp == 0) {
				navigateToRandomL2Categoryfrommain();
			}
			if (itemfoundL2) {
				// ignore
			} else {
				int min = 1;
				int randomlevelCat = common.mathRandom(min, L2catcount - min);
				PerfectoUtils.mousehoverusingActions(category.getLiMainLevelTwoCategory().get(randomlevelCat - 1));
				category.getLiMainLevelTwoCategory().get(randomlevelCat - 1).verifyPresent();
				category.getLiMainLevelTwoCategory().get(randomlevelCat - 1).click();
				category.getLblTxtHeaderpage().waitForPresent(MAX_WAIT_TIME);
				if (category.getLblErrmsgnoitem().isPresent()) {
					category.getLiCatbreadcrumpse().get(level).waitForPresent(MAX_WAIT_TIME);
					category.getLiCatbreadcrumpse().get(level - 1).click();
					navigateToRandomL2Categoryfrommain();
				}
				if (itemfoundL2) {
					// ignore
				} else {

					category.getLblTxtHeaderpage().waitForPresent(MAX_WAIT_TIME);
					itemfoundL2 = category.getBtnAddtocart().get(min - 1).isPresent();

				}
			}
		}

		return itemfoundL2;

	}
	
	public boolean clickOnRandomL3_CategoryfromMain(boolean itemfound, boolean itemfoundL3, int L2catcount, int level) {

		CategoryTestPage category = new CategoryTestPage();
		boolean itemfoundL2 = false;
		int temp = L2catcount;

		if (itemfoundL2) {
			// ignore
		} else {
			if (temp == 0) {
				navigateToRandomL2Categoryfrommain();
			}
			if (itemfoundL2) {
				// ignore
			} else {
				int min = 1;
				int randomlevelCat = common.mathRandom(min, L2catcount - min);
				PerfectoUtils.mousehoverusingActions(category.getLiMainLevelThreeCategory().get(randomlevelCat - 1));
				category.getLiMainLevelThreeCategory().get(randomlevelCat - 1).verifyPresent();
				category.getLiMainLevelThreeCategory().get(randomlevelCat - 1).click();
				category.getLblTxtHeaderpage().waitForPresent(MAX_WAIT_TIME);
				if (category.getLblErrmsgnoitem().isPresent()) {
					category.getLiCatbreadcrumpse().get(level).waitForPresent(MAX_WAIT_TIME);
					category.getLiCatbreadcrumpse().get(level - 1).click();
					navigateToRandomL3Categoryfrommain();
				}
				if (itemfoundL2) {
					// ignore
				} else {

					category.getLblTxtHeaderpage().waitForPresent(MAX_WAIT_TIME);
					itemfoundL2 = category.getBtnAddtocart().get(min - 1).isPresent();

				}
			}
		}

		return itemfoundL2;

	}

	@QAFTestStep(description = "Navigate to Random L3 Category")
	public synchronized void navigateToRandomL3Category() {
		CategoryTestPage category = new CategoryTestPage();
		

		boolean itemfound = false;

		int min = 1;
		int L1catcount = category.getLiLeftnavLOneCategory().size();
		int randomlevelCat = common.mathRandom(min, L1catcount - min);
		category.getLiLeftnavLOneCategory().get(randomlevelCat).verifyPresent();
		doubleClick(category.getLiLeftnavLOneCategory().get(randomlevelCat));
		category.getLblTxtHeaderpage().waitForPresent(MAX_WAIT_TIME);
		if (itemfoundL3) {
			// ignore
		} else {
			if (category.getLblErrmsgnoitem().isPresent()) {
				navigateToRandomL3Category();
			}

			if (itemfoundL3) {
				// ignore
			} else {
				// click L2 random child category
				int L2catcount = category.getLiLeftnavLTwoCategory().size();
				int level = 2;
				boolean itemfoundL2 = clickOnRandomL2Category(itemfound, itemfoundL3, L2catcount, level);

				if (itemfoundL3) {
					// ignore
				} else {
					if (itemfoundL2 == true) {
						// click L3 category
						int L3catcount = category.getLiLeftnavLTwoCategory().size();
						level = 3;
						itemfoundL3 = clickOnRandomL2Category(itemfound, itemfoundL3, L3catcount, level);
						if (itemfoundL3) {
							category.getBtnAddtocart().get(min - 1).verifyPresent();
							ReportMessage("Random product is choosen from L3 category", MessageTypes.Pass);
						}
					}
				}
			}
		}

	}

	public boolean clickOnRandomL2Category(boolean itemfound, boolean itemfoundL3, int L2catcount, int level) {

		CategoryTestPage category = new CategoryTestPage();
		boolean itemfoundL2 = false;

		int temp = L2catcount;

		if (itemfoundL3) {
			// ignore
		} else {
			if (itemfoundL2) {
				// ignore
			} else {
				if (temp == 0) {
					navigateToRandomL3Category();
				}
				if (itemfoundL3) {
					// ignore
				} else {
					int min = 1;
					int randomlevelCat = common.mathRandom(min, L2catcount - min);
					PerfectoUtils.mousehoverusingActions(category.getLiLeftnavLTwoCategory().get(randomlevelCat - 1));
					category.getLiLeftnavLTwoCategory().get(randomlevelCat - 1).verifyPresent();
					category.getLiLeftnavLTwoCategory().get(randomlevelCat - 1).click();
					category.getLblTxtHeaderpage().waitForPresent(MAX_WAIT_TIME);
					if (category.getLblErrmsgnoitem().isPresent()) {
						category.getLiCatbreadcrumpse().get(level).waitForPresent(MAX_WAIT_TIME);
						category.getLiCatbreadcrumpse().get(level - 2).click();
						clickOnRandomL2Category(itemfound, itemfoundL3, temp - 1, level);
					}
					if (itemfoundL3) {
						// ignore
					} else {

						category.getLblTxtHeaderpage().waitForPresent(MAX_WAIT_TIME);
						itemfoundL2 = category.getBtnAddtocart().get(min - 1).isPresent();

					}
				}
			}
		}
		return itemfoundL2;
	}
	
	@QAFTestStep(description = "Verify current category the user is in is highlighted in the left nave pane")
	public synchronized void verifyCurrentCategorytheUserisinisHighlightedintheleftnavepane() {
		CategoryTestPage category = new CategoryTestPage();
		
		String actualColor = category.getLnkCurrentCategory().getCssValue("color");
		if(actualColor.equals(ConfigurationManager.getBundle().getString("categoryPage.childCategoryHighlightedColor"))){
			ReportMessage("Current category the user is in is highlighted in the left nave pane", MessageTypes.Pass);
		}else{
			ReportMessage("Current category the user is in is not highlighted in the left nave pane", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "Verify Link for navigating to next or previous category at the bottom of current category page")
	public synchronized void verifyLinkforNavigatingtoNextorPreviousCategoryatthebottomofcurrentcategorypage() {
		CategoryTestPage category = new CategoryTestPage();
		List<String> childCategory = new ArrayList<String>();
		
		int categoryList = category.getLiCategory().size();
		for(int i = 1; i <= categoryList; i++ ){
		 if(category.getChildCategory(i).getAttribute("class").equals("child") || category.getChildCategory(i).getAttribute("class").equals("child active")){
			 childCategory.add(category.getLnkChildCategory(i).getText());
		 }
		}
		System.out.println(childCategory);
		
		String currentCategoryText = category.getLnkCurrentCategory().getText();
		for(int i = 0; i < childCategory.size(); i++){
			if(currentCategoryText.equals(childCategory.get(i))){
				if(i==0){
					category.getLnkLeftprevcategory().verifyNotPresent();
					category.getLnkRightnextcategory().verifyPresent();
					getRightCategory(childCategory.get(i+1));
				}else if(i==(childCategory.size()-1)){
					category.getLnkLeftprevcategory().verifyPresent();
					category.getLnkRightnextcategory().verifyNotPresent();
					getPreviousCategory(childCategory.get(i-1));
				}else{
					getPreviousCategory(childCategory.get(i-1));
					getRightCategory(childCategory.get(i+1));
				}
			}
		}
	}
	
	private void getPreviousCategory(String expectedLeftCategory){
		CategoryTestPage category = new CategoryTestPage();
		
		String leftCategory = category.getLnkLeftprevcategory().getText().trim();
		if(leftCategory.equals(expectedLeftCategory)){
			ReportMessage("Previous category button points to "+leftCategory, MessageTypes.Pass);
		}else{
			ReportMessage("Previous category button mismatched. Actual: "+leftCategory+", Expected: "+expectedLeftCategory, MessageTypes.Fail);
		}
	}
	
	private void getRightCategory(String expectedRightCategory){
		CategoryTestPage category = new CategoryTestPage();
		
		String rightCategory = category.getLnkRightnextcategory().getText().trim();
		if(rightCategory.equals(expectedRightCategory)){
			ReportMessage("Next category button points to "+rightCategory, MessageTypes.Pass);
		}else{
			ReportMessage("Next category button mismatched. Actual: "+rightCategory+", Expected: "+expectedRightCategory, MessageTypes.Fail);
		}
	}

}
