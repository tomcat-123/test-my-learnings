package com.automation.web.steps.search;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.PerfectoUtils.ReportMessage;
import static com.automation.web.commonutils.PerfectoUtils.getDriver;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.APIHub;
import com.automation.web.commonutils.FunctionUtils;
import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.components.searchandbrowse.ProductBlocks;
import com.automation.web.pages.cartandcheckout.CartTestPage;
import com.automation.web.pages.homepage.ShopTestPage;
import com.automation.web.pages.searchandbrowse.ProductTestPage;
import com.automation.web.steps.accountoptions.HistorySteps;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ProductPageSteps {

	PerfectoUtils util = new PerfectoUtils();
	APIHub hub = new APIHub();
	
	Actions act = new Actions(PerfectoUtils.getDriver());
	
	@QAFTestStep(description = "User navigates to on sale page and saves first item to {listName}")
	public void navToSaleAndSave(String listName){
		ShopTestPage nav = new ShopTestPage();
		ProductTestPage product = new ProductTestPage();
		HistorySteps historyPg = new HistorySteps();
		String url = "/shop/categories?" + getBundle().getString("filter.sale");
		getDriver().get(url);
		nav.loadPage();
		double salePagePrice = 0.0;
		double listPagePrice = 0.0;
		product.getProductTxtSaveForLater().get(0).waitForEnabled(MAX_WAIT_TIME*5);
		QAFWebElement saveForLater = product.getProductTxtSaveForLater().get(0);
		salePagePrice = returnPrice(product.getProductTxtSalesPrice().get(0).getText());
		
		// Save list
		act.moveToElement(saveForLater);
		act.click();
		act.perform();
		util.enterValueAndSendEnter(product.getProductEdtEnterNewList(), listName);
		
		// Navigate to lists, click on first list
		historyPg.navToSavedListPage();
		product.getProductLnkFirstList().click();
		listPagePrice = returnPrice(product.getProductTxtListPagePrice().getText());
		
		if(listPagePrice == salePagePrice){
			util.pass("Prices match");
		} else {
			ReportMessage("Sale Page Price = " + salePagePrice);
			ReportMessage("List Page Price = " + listPagePrice);
			util.fail("Prices do not match");
		}
	}
	
	private double returnPrice(String Price){
		//WebElement listPrice = util.generateWebElement(xpathToPrice);
		String [] priceSplit = Price.split(" ");
		// Possible strings can be "5 for $5.55", so this will parse it down to "5.55"
		String value = priceSplit[priceSplit.length - 1].replaceAll("[^\\d\\.]", "");
		return Double.parseDouble(value);
	}

	/**
	 * Assumes the user is on the Review Cart Page
	 * @param notesToAdd Notes from the given user to add to product
	 */
	@QAFTestStep(description = "User adds {notes} to product")
	public void addNotes(String notesToAdd){
		CartTestPage product = new CartTestPage();
		
		product.getProductBtnProductNotes().click();
		util.enterValueAndSendEnter(product.getProductInputProductNotes(), notesToAdd);
		util.pass("Notes added to product!");
	}
	
		@QAFTestStep(description = "Filter to {tag} on search page, and verify items on {numberOfPages} page(s)")
		public void navigateToTagPage(String tagName, String numberOfPages){
			ShopTestPage nav = new ShopTestPage();
			FunctionUtils funUtil = new FunctionUtils();
		//	APIHub hub = new APIHub();
			ProductTestPage product = new ProductTestPage();
			
			String url = "/shop/categories?" + tagName;
			getDriver().get(url);
			nav.loadPage();
			
			QAFWebElement nextPage;
			
			int pagesToCheck = Integer.parseInt(numberOfPages);
			boolean hasNextPage = false;
			
			do{			
				for(ProductBlocks row : product.getProductTxtListElement()){
					act.moveToElement(row);
					act.perform();
					
					row.getImgItemPicture().verifyPresent();
								
				}
				
				pagesToCheck -= 1;
				if(pagesToCheck == 0){
					break; 
				}
				
				try{
					
					nextPage = product.getProductLnkNextPageIcon();
					hasNextPage = nextPage.isPresent();
					if (hasNextPage==true){
					PerfectoUtils.scrolltoelement(nextPage);
					nextPage.click();
					}
					else  {ReportMessage("Last page arrived");}
				} catch (NoSuchElementException e){
					hasNextPage = false;
				}
				
			} while(hasNextPage);
			
			ReportMessage("All items classified");
		}
}

