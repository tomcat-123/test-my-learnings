package com.automation.web.steps.cartandcheckout;

import static com.automation.web.commonutils.FunctionUtils.PICK_FEE_KEY;
import static com.automation.web.commonutils.FunctionUtils.TIME_BEGIN_KEY;
import static com.automation.web.commonutils.FunctionUtils.TIME_DATE_KEY;
import static com.automation.web.commonutils.FunctionUtils.TIME_END_KEY;
import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.PerfectoUtils.ReportMessage;
import static com.automation.web.commonutils.PerfectoUtils.doubleClick;
import static com.automation.web.commonutils.PerfectoUtils.getDriver;
import static com.automation.web.commonutils.PerfectoUtils.scrolltoelement;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.FunctionUtils;
import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.databean.AddNewCardBean;
import com.automation.web.databean.BillingInfoBean;
import com.automation.web.databean.CheckoutInfoBean;
import com.automation.web.pages.cartandcheckout.CartTestPage;
import com.automation.web.pages.cartandcheckout.GetMoreTestPage;
import com.automation.web.pages.cartandcheckout.OrderCompleteTestPage;
import com.automation.web.pages.cartandcheckout.PayTestPage;
import com.automation.web.pages.cartandcheckout.ScheduleTestPage;
import com.automation.web.pages.homepage.HomeTestPage;
import com.automation.web.pages.orderhistory.OrderDetailsTestPage;
import com.automation.web.pages.orderhistory.OrderHistoryTestPage;
import com.automation.web.pages.useraccountactions.AccountTestPages;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

/**
 * Note about credit cards: All population relies on the credit card data beans.
 * Any changes for how they are populated needs to happen in the bean
 *
 */

/*
 * All the steps definitions for CheckoutSteps
 * 
 * User clicks timeslot button User adds {orderNotes} to order User navigates to
 * Order History and verifies Order {Notes} User navigates to Order History and
 * verifies Product {Notes} User navigates to Order History and verifies Order
 * {Notes} User clicks main checkout User selects {date}(st|nd|th) of the month
 * for timeslot User selects timeslot starting at {startTime} to {endTime} User
 * selects first timeslot for today Verify the selected time and date for
 * reserved time User confirms they are on schedule page User verifies delivery
 * information User verifies prices on (Schedule|Payment) page User navigates to
 * payment page User clicks credit card button User creates new {credit card}
 * User adds credit card User verifies invalid card User verifies {credit card}
 * present User verifies billing information filled correctly User enters
 * invalid billing information User places order Hot user verifies {creditCard}
 * and billing information User navigates to order details User places order,
 * and verifies history data matches order Verify billing address required
 * fields are populated Verify earliest timeslot Verify Latest timeslot Verify
 * Pick Fee from Order Total section in All Checkout Pages
 * 
 * 
 */
public class CheckoutSteps {
	static PerfectoUtils util = new PerfectoUtils();
	Actions act = new Actions(getDriver());

	@QAFTestStep(description = "User clicks timeslot button")
	public static void clickTimeslotButton() {
		HomeTestPage htp = new HomeTestPage();
		htp.getHomeTxtReservedTime().waitForEnabled(MAX_WAIT_TIME * 2);
		PerfectoUtils.scrolltoelement(htp.getHomeHdrTimeslot());
		htp.getHomeHdrTimeslot().waitForEnabled(MAX_WAIT_TIME);
		if(PerfectoUtils.getDriver().getCapabilities().getBrowserName().toLowerCase().equals("safari")){
			PerfectoUtils.JavaScriptClick(htp.getHomeHdrTimeslot());
		}else{
			htp.getHomeHdrTimeslot().click();
		}
		PerfectoUtils.waitAngularHasFinishedProcessing();
		htp.waitForAjaxToComplete();
		// PerfectoUtils.sleep();
		// PerfectoUtils.sleep();

		ReportMessage("Reserve a timeslot window open", MessageTypes.Pass);
	}

	/**
	 * Assumes user on Review Cart Page
	 * 
	 * @param orderNotesToAdd
	 *            Notes to be added on the order level
	 */

	@QAFTestStep(description = "User adds {orderNotes} to order")
	public void addOrderNotes(String orderNotesToAdd) {
		CartTestPage cart = new CartTestPage();
		cart.getChckOutTxtOrderLevelNotes().clear();
		util.enterValues(cart.getChckOutTxtOrderLevelNotes(), orderNotesToAdd);

		doubleClick(cart.getChckOutTxtOrderLevelNotes());
		cart.getChckOutBtnSaveNotes().click();
		// cart.getChckOutBtnSaveNotes().waitForNotVisible(MAX_WAIT_TIME);
		ReportMessage("Order level notes added!", MessageTypes.Pass);
	}

	@QAFTestStep(description = "User navigates to Order History and verifies Order {Notes}")
	public void verifyOrderNotes(String orderNotes) {
		navToDetails();

	}

	@QAFTestStep(description = "User navigates to Order History and verifies Product {Notes}")
	public void verifyProdNotes(String productNotes) {
		OrderHistoryTestPage product = new OrderHistoryTestPage();
		OrderHistoryTestPage orderhistory = new OrderHistoryTestPage();

		String notesFound;
		navToDetails();

		// util.moveToElement(util.generateWebElement("//div[@class='item-image']"));
		scrolltoelement((orderhistory.getOrderhistoryListItemImage().get(0)));
		notesFound = product.getProductTxtHistoryProdNotes().getText();
		if (notesFound.equals(productNotes)) {
			ReportMessage("Product notes verified", MessageTypes.Pass);
		} else {
			ReportMessage("History product notes found: " + notesFound);
			ReportMessage("Notes to match: " + productNotes);
			ReportMessage("Notes do not match", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "User navigates to Order History and verifies Order {Notes}")
	public void verifyHisOrderNotes(String orderNotes) {
		OrderHistoryTestPage orderhistory = new OrderHistoryTestPage();
		String labelFound;
		String noteFound;

		navToDetails();

		List<QAFWebElement> orderDetails = orderhistory.getOrderhistoryListOrderDetails();
		PerfectoUtils.scrolltoelement(orderDetails.get(0));
		for (WebElement details : orderDetails) {
			labelFound = details.findElement(By.tagName("label")).getText();
			noteFound = details.findElement(By.className("data")).getText();
			if (labelFound.equals("Order Note") && noteFound.equals(orderNotes)) {
				ReportMessage("Order level note matches", MessageTypes.Pass);
				return;
			}
		}
		ReportMessage("Order notes not displayed", MessageTypes.Fail);
	}

	/**
	 * Will also check to make sure it's on checkout page
	 */
	@QAFTestStep(description = "User clicks main checkout")
	public void iClickMainCheckout() {
		CartTestPage cartTestPage = new CartTestPage();
		try {
			util.scrollAndClick(cartTestPage.getCartBtnMainCheckout());

			cartTestPage.getChkOutBtnContinue().waitForEnabled(MAX_WAIT_TIME * 5);
		} catch (TimeoutException e) {
			cartTestPage.getCartBtnMainCheckout().click();
			cartTestPage.getChkOutBtnContinue().waitForEnabled(MAX_WAIT_TIME * 5);
		}
		ReportMessage("Checkout button pressed", MessageTypes.Pass);
	}

	@QAFTestStep(description = "User selects {date}(st|nd|th) of the month for timeslot")
	public void selectDayTS(String dateSelected) {
		HomeTestPage htp = new HomeTestPage();
		boolean dateFound = false;
		String dateSet = "";
		if (!htp.getHomeTxtReservedTime().getText().toLowerCase().contains("reserve")) {
			String[] dateParse = htp.getHomeTxtReservedTime().getText().split(" ");
			getBundle().setProperty(TIME_DATE_KEY, dateParse[1].replaceAll(",", ""));
			ReportMessage("Timeslot already selected", MessageTypes.Pass);
			return;
		}

		ScheduleTestPage checkout = new ScheduleTestPage();

		checkout.getChkOutGetDateRange(1 + "").waitForVisible(MAX_WAIT_TIME);
		PerfectoUtils.scrolltoelement(checkout.getChkOutGetDateRange(1 + ""));

		for (int i = 1; i <= 7; i++) {
			if (checkout.getChkOutGetDateRange(i + "").getText().equals(dateSelected)) {

				PerfectoUtils.scrolltoelement(checkout.getChkOutGetDateRange(1 + ""));
				checkout.getChkOutGetDateRange(i + "").click();
				getBundle().setProperty(TIME_DATE_KEY, dateSelected);
				dateSet = dateSelected;
				dateFound = true;
				ReportMessage("Date set to: " + dateSet, MessageTypes.Pass);
				return;
			}
		}

		if (!dateFound) {
			checkout.getChkOutGetDateRange(1 + "").click();
			dateSet = checkout.getChkOutGetDateRange(1 + "").getText();
			getBundle().setProperty(TIME_DATE_KEY, dateSet);
			ReportMessage("Date specified not found. Date set to: " + dateSet, MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "User selects timeslot starting at {startTime} to {endTime}")
	public void selectTime(String timeBegin, String timeEnd) {
		HomeTestPage htp = new HomeTestPage();
		ScheduleTestPage checkout = new ScheduleTestPage();
		String reserveText = htp.getHomeTxtReservedTime().getText().toLowerCase();
		String[] splitTime = null;

		if (!reserveText.contains("reserve")) {
			ReportMessage("Timeslot already selected", MessageTypes.Pass);
			splitTime = reserveText.split(" ");
			splitTime = splitTime[2].split("-");
			getBundle().setProperty(TIME_BEGIN_KEY, splitTime[0].toUpperCase());
			getBundle().setProperty(TIME_END_KEY, splitTime[1].toUpperCase());
			return;
		}

		/*
		 * List<WebElement> table_element = PerfectoUtils.getDriver()
		 * .findElements(By.xpath(
		 * "//div[@class='timeslots slide-down-animation']//table/tbody/tr"));
		 * List<WebElement> selectButtons = PerfectoUtils.getDriver()
		 * .findElements(By.xpath("//div[@class='actions-content']/label"));
		 */

		List<QAFWebElement> table_element = checkout.getScheduleListTablelement();
		List<QAFWebElement> selectButtons = checkout.getScheduleListSelectButtons();

		int curIndex = 0;

		getBundle().setProperty(TIME_BEGIN_KEY, timeBegin);
		getBundle().setProperty(TIME_END_KEY, timeEnd);
		/*
		 * for (WebElement row : table_element) { util.moveToElement(row);
		 * splitTime = row.getText().split(" ");
		 * 
		 * // Checks the beginning time of each row. If it matches, sets the //
		 * time. If there's a pick fee, grabs it if
		 * (timeBegin.equals(splitTime[0])) {
		 * selectButtons.get(curIndex).click(); setPickFee(row.getText());
		 * ReportMessage("Time slot selected",MessageTypes.Pass);
		 * htp.getHomeBoxTimeslotSelector().waitForNotVisible(MAX_WAIT_TIME *
		 * 2); return; } curIndex += 1; } ReportMessage(
		 * "Last timeslot selected, specified timeslot not visible");
		 * getBundle().setProperty(TIME_BEGIN_KEY, splitTime[0]);
		 * getBundle().setProperty(TIME_END_KEY, splitTime[2]);
		 * selectButtons.get(curIndex - 1).click();
		 * setPickFee(table_element.get(curIndex - 1).getText());
		 */

		ReportMessage("Timeslot selected: " + splitTime[0] + " to " + splitTime[2], MessageTypes.Pass);
	}

	/**
	 * Sets the reserve time for the first available time and date
	 */
	@QAFTestStep(description = "User selects first timeslot for today")
	public static void firstTimeSlot() {
		ScheduleTestPage checkout = new ScheduleTestPage();

		HomeTestPage htp = new HomeTestPage();
		String dateSet;
		String[] dateRange;

		htp.getHomeTxtReservedTime().waitForEnabled(MAX_WAIT_TIME);
		String reserveText = htp.getHomeTxtReservedTime().getText().toLowerCase();
		if (!reserveText.contains("reserve")) {
			util.pass("Timeslot already selected");
			dateRange = reserveText.split(" ");
			getBundle().setProperty(TIME_DATE_KEY, dateRange[1].replaceAll(",", ""));
			dateRange = dateRange[2].split("-");
			getBundle().setProperty(TIME_BEGIN_KEY, dateRange[0].toUpperCase());
			getBundle().setProperty(TIME_END_KEY, dateRange[1].toUpperCase());
			// return;
		}

		else {
			clickTimeslotButton();
			checkout.getChkOutTxtCurrentDate().waitForPresent(MAX_WAIT_TIME);
			String CurentDate = checkout.getChkOutTxtCurrentDate().getText();
			String CurentMonth = checkout.getChkOutTxtCurrentMonth().getText();

			getBundle().setProperty("CurentDate", CurentDate);
			getBundle().setProperty("CurentMonth", CurentMonth);
			// Set date
			checkout.getChkOutGetDateRange(1 + "").click();
			// checkout.waitForAjaxToComplete();
			dateSet = checkout.getChkOutGetDateRange(1 + "").getText();
			getBundle().setProperty(TIME_DATE_KEY, dateSet);

			List<QAFWebElement> selectButtons = checkout.getScheduleListSelectButtons();
			selectButtons.get(0).click();
			PerfectoUtils.waitAngularHasFinishedProcessing();

			//checkout.getChkOuttxtpopuptxtselectTimeSlot().waitForNotPresent(MAX_WAIT_TIME * 5);

		}
	}

	/**
	 * Sets the reserve time for the second available time and date
	 */

	@QAFTestStep(description = "User selects second timeslot for today")
	public static void secondTimeSlot() {
		ScheduleTestPage checkout = new ScheduleTestPage();

		HomeTestPage htp = new HomeTestPage();
		String dateSet;

		String[] dateRange;
		clickTimeslotButton();

		String reserveText = htp.getHomeTxtReservedTime().getText().toLowerCase();
		if (!reserveText.contains("reserve")) {
			ReportMessage("Timeslot already selected");
			dateRange = reserveText.split(" ");
			getBundle().setProperty(TIME_DATE_KEY, dateRange[1].replaceAll(",", ""));
			dateRange = dateRange[2].split("-");
			getBundle().setProperty(TIME_BEGIN_KEY, dateRange[0].toUpperCase());
			getBundle().setProperty(TIME_END_KEY, dateRange[1].toUpperCase());
			return;
		}

		String CurentDate = checkout.getChkOutTxtCurrentDate().getText();
		String CurentMonth = checkout.getChkOutTxtCurrentMonth().getText();

		getBundle().setProperty("CurentDate", CurentDate);
		getBundle().setProperty("CurentMonth", CurentMonth);

		// Set date
		checkout.getChkOutGetDateRange(1 + "").click();
		checkout.waitForAjaxToComplete();
		dateSet = checkout.getChkOutGetDateRange(1 + "").getText();
		getBundle().setProperty(TIME_DATE_KEY, dateSet);
		List<QAFWebElement> selectButtons = checkout.getScheduleListSelectButtons();
		selectButtons.get(1).click();
		PerfectoUtils.waitAngularHasFinishedProcessing();

		checkout.getChkOuttxtpopuptxtselectTimeSlot().waitForNotPresent(MAX_WAIT_TIME * 5);
	}

	public static void selectTimeSlot() {
		ScheduleTestPage checkout = new ScheduleTestPage();
		HomeTestPage htp = new HomeTestPage();
		String dateSet;
		String[] dateRange;
		htp.getHomeTxtReservedTime().waitForPresent(MAX_WAIT_TIME * 2);

		String reserveText = htp.getHomeTxtReservedTime().getText().toLowerCase();

		if (!reserveText.contains("reserve")) {
			ReportMessage("Timeslot already selected");
			dateRange = reserveText.split(" ");
			getBundle().setProperty(TIME_DATE_KEY, dateRange[1].replaceAll(",", ""));
			dateRange = dateRange[2].split("-");
			getBundle().setProperty(TIME_BEGIN_KEY, dateRange[0].toUpperCase());
			getBundle().setProperty(TIME_END_KEY, dateRange[1].toUpperCase());
			return;
		} else {
			ReportMessage("Selecting the timeslot..", MessageTypes.Pass);

			htp.getHomeTxtReservedTime().waitForPresent(MAX_WAIT_TIME);
			htp.getHomeTxtReservedTime().click();
			checkout.getChkOutTxtCurrentDate().waitForPresent(MAX_WAIT_TIME);

			String CurentDate = checkout.getChkOutTxtCurrentDate().getText();
			String CurentMonth = checkout.getChkOutTxtCurrentMonth().getText();

			getBundle().setProperty("CurentDate", CurentDate);
			getBundle().setProperty("CurentMonth", CurentMonth);

			// Set date
			checkout.getChkOutGetDateRange(1 + "").click();
			checkout.waitForAjaxToComplete();
			dateSet = checkout.getChkOutGetDateRange(1 + "").getText();
			getBundle().setProperty(TIME_DATE_KEY, dateSet);
			// Set time, grab first range, and set bundle for verification

			/*
			 * List<WebElement> table_element = PerfectoUtils.getDriver()
			 * .findElements(By.xpath(
			 * "//div[@class='timeslots slide-down-animation']//table/tbody/tr"
			 * )); List<WebElement> selectButtons = PerfectoUtils.getDriver()
			 * .findElements(By.xpath("//div[@class='actions-content']/label"));
			 * List<WebElement> pickFees = util .generateWebElementList(
			 * "//td[@class='pickup-fee']//span[@class='fee-price']");
			 */

			List<QAFWebElement> table_element = checkout.getScheduleListTablelement();
			List<QAFWebElement> selectButtons = checkout.getScheduleListSelectButtons();
			List<QAFWebElement> pickFees = checkout.getScheduleListPickFees();

			selectButtons.get(0).click();
			checkout.waitForAjaxToComplete();
		}
	}

	@QAFTestStep(description = "Verify the selected time and date for reserved time")
	public void verifyTimeAndDate() {
		HomeTestPage htp = new HomeTestPage();
		String mappedTime = "";
		String mappedDay = "";
		String temp = "";
		String[] splitText;

		mappedDay = (String) getBundle().getProperty(TIME_DATE_KEY);
		mappedTime = (String) getBundle().getProperty(TIME_BEGIN_KEY) + "-";
		mappedTime += (String) getBundle().getProperty(TIME_END_KEY);

		htp.getHomeTxtReservedTime().waitForNotText("RESERVE A TIME SLOT", MAX_WAIT_TIME * 2);
		try {
			temp = htp.getHomeTxtReservedTime().getText();
		} catch (NullPointerException e) {

			temp = htp.getHomeTxtReservedTime().getText();
		}
		splitText = temp.split(" ");

		if (mappedTime.equals(splitText[2])) {
			ReportMessage("Times match");
		} else {
			ReportMessage("Times do not match. Provided on screen: " + splitText[2] + ", in bundle: "
					+ getBundle().getProperty(TIME_BEGIN_KEY), MessageTypes.Fail);

		}

		if (mappedDay.equals(splitText[1].replaceAll(",", ""))) {
			ReportMessage("Days match");
		} else {
			ReportMessage("Days do not match. Provided on screen: " + splitText[1].replaceAll(",", "") + ", in bundle: "
					+ getBundle().getProperty(TIME_DATE_KEY), MessageTypes.Fail);
		}

		ReportMessage("Time and date matches.");
	}

	@QAFTestStep(description = "User confirms they are on schedule page")
	public void scheduleConf() {

		GetMoreTestPage getmorepage = new GetMoreTestPage();

		try {
			getmorepage.getContinueCheckOut().waitForPresent(MAX_WAIT_TIME);
			if (getmorepage.getContinueCheckOut().isPresent()) {
				util.scrollAndClick(getmorepage.getContinueCheckOut());
				ReportMessage("Clicked Continue Checkout button on Get More page",MessageTypes.Pass);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		OrderCompleteTestPage confirm = new OrderCompleteTestPage();
		confirm.loadPage();
		ReportMessage("On schedule page");

	}

	@QAFTestStep(description = "User verifies delivery information")
	public void delConfirmation() {
		AccountTestPages confirm = new AccountTestPages();
		ScheduleTestPage schedule = new ScheduleTestPage();

		PerfectoUtils.waitUntilVisibilityofElement(schedule.getCkconEdtFirstName());

		schedule.getCkconEdtFirstName().sendKeys("SreeRam");
		schedule.getCkconEdtLastName().sendKeys("Arigela");

		confirm.getCkconTxtUserName().waitForPresent(5000);

		if (confirm.getCkconTxtUserName().getText().equals("Your Account")) {
			CheckoutInfoBean infoBean = new CheckoutInfoBean();
			infoBean.fillRandomData();
			infoBean.setHomeNum(getBundle().getString("validPhoneNumbers.home"));
			infoBean.setHomeNum(getBundle().getString("validPhoneNumbers.mobile"));
			infoBean.setHomeNum(getBundle().getString("validPhoneNumbers.work"));
			infoBean.setHomeNum(getBundle().getString("validPhoneNumbers.other"));
			infoBean.fillUiElements();

		}
		ReportMessage("Information entered on schedule page");
		schedule.getContinueBtn().click();

	}

	@QAFTestStep(description = "User verifies prices on (Schedule|Payment) page")
	public void verifySchedulePrice() {
		ScheduleTestPage checkout = new ScheduleTestPage();

		List<QAFWebElement> table_elements = checkout.getScheduleListPriceDetails();
		String[] subtotal;
		String[] splitRow;
		String roundedTotal;
		double runningTotal = 0.0;
		double displayedTotal = 0.0;

		for (QAFWebElement row : table_elements) {
			splitRow = row.getText().split(" ");
			switch (splitRow[0].toLowerCase()) {
			case "item":
				scrolltoelement(row);
				getBundle().setProperty("SUBTOTAL_KEY", splitRow[splitRow.length - 1]);
				System.out.println((String) getBundle().getProperty("SUBTOTAL_KEY"));
				runningTotal += calculateTotal((String) getBundle().getProperty("SUBTOTAL_KEY"),
						"Running total at item total: ");
				break;
			case "personal":
				getBundle().setProperty("PERSONAL_SHOPPER_FEE", splitRow[splitRow.length - 1]);
				runningTotal += calculateTotal((String) getBundle().getProperty("PERSONAL_SHOPPER_FEE"),
						"Running total at pick fee: ");
				break;
			// not implemented yet
			// case "credits":
			// runningTotal -=
			// calculateTotal((String)getBundle().getProperty(PICK_FEE_KEY)
			// , "Running total after Credits: ");
			// break;
			case "offer":
				getBundle().setProperty("OFFER", splitRow[splitRow.length - 1]);
				String offervalue=(String)getBundle().getProperty("OFFER");
				offervalue=offervalue.replaceAll("-", "");
				
			 runningTotal -=
			 calculateTotal(offervalue, "Running total after Offers: ");
			 break;
			case "tax":
				getBundle().setProperty("SAVED_TAX_KEY", splitRow[splitRow.length - 1]);
				runningTotal += calculateTotal((String) getBundle().getProperty("SAVED_TAX_KEY"),
						"Running total after taxes: ");
				break;
			case "est.":
				getBundle().setProperty("SAVED_TAX_KEY", splitRow[splitRow.length - 1]);
				displayedTotal = calculateTotal(splitRow[2], "Displayed total: ");
				break;
			}
		}
		roundedTotal = String.format("%.2f", runningTotal);
		runningTotal = Double.parseDouble(roundedTotal);

		if (displayedTotal == runningTotal) {
			ReportMessage("Totals match");
		} else {
			ReportMessage("Totals do not match. Displayed total: " + displayedTotal + ", Stored total: " + runningTotal,
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "User navigates to payment page")
	public void navToPaymentPage() {
		PayTestPage pay = new PayTestPage();
		ScheduleTestPage confirm = new ScheduleTestPage();

		// confirm.getCkconBtnSaveAddress().waitForPresent(MAX_WAIT_TIME);
		// util.moveToElement(confirm.getCkconBtnSaveAddress());
		// confirm.getCkconBtnSaveAddress().click();
		confirm.waitForPageToLoad();
		//scheduleConf();
		confirm.getCkconBtnNavigateToPymnt().waitForPresent(MAX_WAIT_TIME * 5);
		scrolltoelement(confirm.getCkconBtnNavigateToPymnt());
		confirm.getCkconBtnNavigateToPymnt().click();
		PerfectoUtils.waitAngularHasFinishedProcessing();
		// PerfectoUtils.sleep();
		// PerfectoUtils.sleep();
		// pay.getCkconTxtPaymentMethodBox().waitForPresent(MAX_WAIT_TIME*5);

		try {
			pay.getCkconTxtPaymentMethodBox().waitForEnabled(MAX_WAIT_TIME);
		} catch (TimeoutException e) {
			confirm.getCkconBtnNavigateToPymnt().click();

			pay.getCkconTxtPaymentMethodBox().waitForEnabled(MAX_WAIT_TIME);
		}
		ReportMessage("Navigated to payment page");
	}

	@QAFTestStep(description = "User clicks credit card button")
	public void clickCreditCardButton() {
		PayTestPage confirm = new PayTestPage();
		PerfectoUtils.scrolltoelement(confirm.getCardSelBtnSelectCC());
		confirm.getCardSelBtnSelectCC().click();

		ReportMessage("Add Credit Card Button pressed", MessageTypes.Pass);	
	}

	@QAFTestStep(description = "User creates new {credit card}")
	public void createNewCreditCard(String cardType) {
		AddNewCardBean newCard = new AddNewCardBean(cardType);
		PayTestPage checkout = new PayTestPage();
		CheckoutSteps addcard = new CheckoutSteps();
		
		if(PerfectoUtils.getDriver().getCapabilities().getBrowserName().toLowerCase().equals("internet explorer")){
			String location = "creditCards." + cardType;
			checkout.getCardSelDdCardType().waitForPresent(50000);
			newCard.selectFromValue(checkout.getCardSelDdCardType(),cardType.toLowerCase());
			newCard.selectFromVisibleText(checkout.getCardSelDdExpMon(), getBundle().getString("creditCards.exp.month"));
			newCard.selectFromVisibleText(checkout.getCardSelDdExpYear(), getBundle().getString("creditCards.exp.year"));
			PerfectoUtils.scrolltoelement(checkout.getCardSelBtnSelectCC());
			checkout.getCardSelEdtCardNumber().sendKeys(getBundle().getString(location + ".num"));
			PerfectoUtils.scrolltoelement(checkout.getCardSelBtnSelectCC());
			PerfectoUtils.JavaScriptSendKeys(checkout.getCardSelEdtHolderName(),getBundle().getString("creditCards.name"));
			PerfectoUtils.JavaScriptSendKeys(checkout.getCardSelEdtCvvNum(),getBundle().getString(location + ".csv"));
			PerfectoUtils.JavaScriptSendKeys(checkout.getCardSelEdtZipcode(),getBundle().getString("creditCards.cardZip"));
			checkout.getCardSelEdtDescription().sendKeys(getBundle().getString(location + ".description"));
		}else{
			newCard.fillRandomData();
			newCard.fillUiElements();
		}
		PerfectoUtils.scrolltoelement(checkout.getCardSelBtnSelectCC());
		checkout.getCardSelBtnAddCard().waitForEnabled(MAX_WAIT_TIME*2);
		if (checkout.getCardSelBtnAddCard().isEnabled())
			addcard.addCreditCard();

	}

	@QAFTestStep(description = "User adds credit card")
	public void addCreditCard() {
		PayTestPage confirm = new PayTestPage();
		//
		confirm.getCardSelBtnAddCard().waitForPresent(MAX_WAIT_TIME);
		confirm.getCardSelBtnAddCard().click();
		ReportMessage("Credit card added", MessageTypes.Pass);

	}

	@QAFTestStep(description = "User verifies invalid card")
	public void verifyInvalidCard() {
		PayTestPage confirm = new PayTestPage();
		if (!confirm.getCardSelBtnAddCard().isEnabled()) {
			ReportMessage("Invalid card provided.", MessageTypes.Pass);
		} else {
			ReportMessage("Card accepted", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "User verifies {credit card} present")
	public void verifyCreditCard(String cardType) {
		PayTestPage confirm = new PayTestPage();

		confirm.getCardSelTxtMainCard().get(0).waitForPresent(MAX_WAIT_TIME * 6);
		PerfectoUtils.scrolltoelement(confirm.getCardSelTxtMainCard().get(0));
		List<QAFWebElement> label_elements = confirm.getCardSelTxtMainCard();
		for (QAFWebElement label : label_elements) {
			if (label.getText().contains(getBundle().getString("creditCards." + cardType + ".description"))
					&& label.getText().contains(getBundle().getString("creditCards." + cardType + ".end"))) {
				PerfectoUtils.scrolltoelement(label);
				ReportMessage("Card verified", MessageTypes.Pass);
				return;
			}
		}

		ReportMessage("Card not present", MessageTypes.Fail);
	}

	@QAFTestStep(description = "User verifies billing information filled correctly")
	public void verifyBilling() {
		BillingInfoBean billingBean = new BillingInfoBean();
		PayTestPage confirm = new PayTestPage();

		if (confirm.getCardSelEdtBillingAddress().getAttribute("value").isEmpty()) {
			billingBean.fillRandomData();
			billingBean.fillUiElements();
		}
		confirm.getCardSelEdtBillingAddress().waitForPresent(MAX_WAIT_TIME * 3);

		ReportMessage("Billing information popluated", MessageTypes.Pass);
	}

	@QAFTestStep(description = "User enters invalid billing information")
	public void invalidBilling() {
		BillingInfoBean billingBean = new BillingInfoBean();
		PayTestPage confirm = new PayTestPage();
		if (confirm.getCardSelEdtBillingAddress().getAttribute("value").isEmpty()) {
			billingBean.fillRandomData();
			billingBean.fillUiElements();
		}

		confirm.getCardSelEdtBillingAddress().clear();
		confirm.getCkconBtnPlaceOrder().waitForPresent(MAX_WAIT_TIME * 3);

		// if
		// (confirm.getCkconBtnPlaceOrder().getAttribute("disabled").equals("disabled"))
		// {
		if (!confirm.getCkconBtnPlaceOrder().isEnabled()) {
			ReportMessage("Billing information not accepted", MessageTypes.Pass);
		} else {
			ReportMessage("Billing information accepted", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "User places order")
	public static void confirmPurchase() {
		PayTestPage pay = new PayTestPage();
		OrderCompleteTestPage confirm = new OrderCompleteTestPage();

		PerfectoUtils.scrolltoelement(pay.getCkconBtnPlaceOrder());
		pay.getCkconBtnPlaceOrder().click();
		PerfectoUtils.waitAngularHasFinishedProcessing();
		// confirm.getConfHdrThankYou().waitForVisible(MAX_WAIT_TIME * 5);
		ReportMessage("Order placed", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Hot user verifies {creditCard} and billing information")
	public void hotCreditCardVerify(String creditCard) {
		CheckoutSteps checkout = new CheckoutSteps();

		String creditCardType = getBundle().getString("creditCards.MasterCard.type");

		clickCreditCardButton();
		// checkout.createNewCreditCard(creditCardType);
		verifyCreditCard(creditCard);
		verifyBilling();
	}

	@QAFTestStep(description = "User navigates to order details")
	public void navToDetails() {
		OrderCompleteTestPage confirm = new OrderCompleteTestPage();
		OrderDetailsTestPage detail = new OrderDetailsTestPage();

		// QAFWebElement header;
		util.scrollAndClick(confirm.getConfBtnOrderDetails());
		PerfectoUtils.waitAngularHasFinishedProcessing();

		// detail.getLblHeaderordernumber().waitForPresent(MAX_WAIT_TIME);

		// header = (QAFWebElement)
		// util.generateWebElement("//h1[@class='label']");
		// header.waitForText("Order Details", MAX_WAIT_TIME);
		// PerfectoUtils.sleep();
		ReportMessage("Order details clicked", MessageTypes.Pass);
	}

	@QAFTestStep(description = "User places order, and verifies history data matches order")
	public void placeOrderAndVerify() {
		OrderHistoryTestPage orderhistory = new OrderHistoryTestPage();
		confirmPurchase();
		navToDetails();

		FunctionUtils funUtil = new FunctionUtils();
		String prodNum;
		List<QAFWebElement> orderImages = orderhistory.getOrderhistoryListItemImage();
		// List<WebElement> orderImages =
		// util.generateWebElementList("//tr[@class='parent']//div[@class='item-image']");
		for (WebElement image : orderImages) {
			prodNum = funUtil.generateItemID(image.getAttribute("style"));

			if (getBundle().getProperty(FunctionUtils.ITEM_ID_KEY + prodNum) == null) {
				ReportMessage("Item not in order history", MessageTypes.Fail);
			} else {
				ReportMessage("Item in order history", MessageTypes.Pass);
			}
		}
	}

	@QAFTestStep(description = "Verify billing address required fields are populated")
	public void VerifyBillingAddressRequiredFieldsArePopulated() {

		CheckoutSteps checkout = new CheckoutSteps();
		PayTestPage chckoutconfirm = new PayTestPage();
		checkout.clickCreditCardButton();

		// Billing Address
		if (!chckoutconfirm.getCardSelEdtBillingAddress().equals(null)) {
			ReportMessage("Billing Address field is populated successfullly", MessageTypes.Pass);
		} else {
			ReportMessage("Billing Address field is not populated", MessageTypes.Fail);
		}

		// City

		if (!chckoutconfirm.getCardSelEdtBillingCity().equals(null)) {
			ReportMessage("City field is populated successfullly", MessageTypes.Pass);
		} else {
			ReportMessage("City field is not populated", MessageTypes.Fail);
		}

		// State
		if (!chckoutconfirm.getCardSelDdStateSel().equals(null)) {
			ReportMessage("State field is populated successfullly", MessageTypes.Pass);
		} else {
			ReportMessage("State field is not populated", MessageTypes.Fail);
		}
		// Zipcode
		if (!chckoutconfirm.getCardSelEdtBillingZip().equals(null)) {
			ReportMessage("Zipcode field is populated successfullly", MessageTypes.Pass);
		} else {
			ReportMessage("Zipcode field is not populated", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify earliest timeslot")
	public void VerifyEarliestTimeslot() {

		ScheduleTestPage checkout = new ScheduleTestPage();
		clickTimeslotButton();

		List<QAFWebElement> fromTime = checkout.getChkOutTxtSelectFromTime();
		// int fromTimeSize = fromTime.size();
		int i = 1;
		List<QAFWebElement> toTime = checkout.getChkOutTxtSelectToTime();
		List<QAFWebElement> days = checkout.getChkOutTxtDays();
		int daysSize = days.size();

		String month = checkout.getLblMonthintimeslot().getText();
		String day = checkout.getChkOutTxtDays().get(0).getText();

		String earliestTimeslotInEarliestDay = "Earliest time stamp in First day of window period: " + month + " " + day
				+ ", " + fromTime.get(0).getText() + " until " + toTime.get(0).getText();
		ReportMessage(earliestTimeslotInEarliestDay);
		System.out.println(checkout.getChkOutBtnNextweek().getAttribute("disabled"));

		while (!isAttribtuePresent(checkout.getChkOutBtnNextweek(), "disabled") && (i < 3)) {// &&
																								// (i<3)
			checkout.getChkOutBtnNextweek().click();
			ReportMessage("Clicked on Next button..", MessageTypes.Pass);
			i++;
		}

		fromTime = checkout.getChkOutTxtSelectFromTime();
		toTime = checkout.getChkOutTxtSelectToTime();
		days = checkout.getChkOutTxtDays();

		month = checkout.getLblMonthintimeslot().getText();
		day = checkout.getChkOutTxtDays().get(daysSize - 1).getText();
		checkout.getChkOutTxtDays().get(daysSize - 1).click();
		String earliestTimeslotInLastDay = "Earliest time stamp in Last day of window period: " + month + " " + day
				+ ", " + fromTime.get(0).getText() + " until " + toTime.get(0).getText();
		ReportMessage(earliestTimeslotInLastDay);

	}

	@QAFTestStep(description = "Verify Latest timeslot")
	public void VerifyLatestTimeslot() {

		ScheduleTestPage checkout = new ScheduleTestPage();
		clickTimeslotButton();

		List<QAFWebElement> fromTime = checkout.getChkOutTxtSelectFromTime();
		int fromTimeSize = fromTime.size();
		int i = 1;
		List<QAFWebElement> toTime = checkout.getChkOutTxtSelectToTime();
		int toTimeSize = toTime.size();
		List<QAFWebElement> days = checkout.getChkOutTxtDays();
		int daysSize = days.size();

		String month = checkout.getLblMonthintimeslot().getText();
		String day = checkout.getChkOutTxtDays().get(0).getText();
		System.out.println(checkout.getChkOutTxtSelectFromTime().get(fromTimeSize - 1).getText());
		PerfectoUtils.scrolltoelement(checkout.getChkOutTxtSelectFromTime().get(fromTimeSize - 1));

		String latestTimeslotInearliestDay = "Latest time stamp in Earliest day of window period: " + month + " " + day
				+ ", " + fromTime.get(fromTimeSize - 1).getText() + " until " + toTime.get(toTimeSize - 1).getText();
		ReportMessage(latestTimeslotInearliestDay);
		System.out.println(checkout.getChkOutBtnNextweek().getAttribute("disabled"));

		while (!isAttribtuePresent(checkout.getChkOutBtnNextweek(), "disabled") && (i < 3)) {// &&
																								// (i<3)
			checkout.getChkOutBtnNextweek().click();
			ReportMessage("Clicked on Next button..", MessageTypes.Pass);
			i++;
		}

		fromTime = checkout.getChkOutTxtSelectFromTime();
		toTime = checkout.getChkOutTxtSelectToTime();
		days = checkout.getChkOutTxtDays();

		month = checkout.getLblMonthintimeslot().getText();
		day = checkout.getChkOutTxtDays().get(daysSize - 1).getText();
		checkout.getChkOutTxtDays().get(daysSize - 1).click();
		PerfectoUtils.scrolltoelement(checkout.getChkOutTxtSelectFromTime().get(fromTimeSize - 1));

		String latestTimeslotInLastDay = "Latest time stamp in Last day of window period: " + month + " " + day + ", "
				+ fromTime.get(fromTimeSize - 1).getText() + " until " + toTime.get(toTimeSize - 1).getText();
		ReportMessage(latestTimeslotInLastDay);

	}

	@QAFTestStep(description = "Verify Pick Fee from Order Total section in All Checkout Pages")
	public void VerifyPickFeefromOrderTotasectioninCheckoutPages() {

		PayTestPage checkout = new PayTestPage();
		ScheduleTestPage Schedule = new ScheduleTestPage();

		float pickfeeFromOrderTotal = Float
				.parseFloat(Schedule.getChkOutLblPickfeeintotalsec().getText().replace("$", ""));

		if (checkout.getChkOutLblPickfeeinheadersec().isPresent()) {
			float pickfeeFromPaymentPage = Float
					.parseFloat(checkout.getChkOutLblPickfeeinheadersec().getText().replace("$", ""));
			if (pickfeeFromPaymentPage > 0.00) {
				ReportMessage(
						"Succesfully Pick fee is applied for fifth (or) greater that 4th orders in Payment page Pick Fee Section",
						MessageTypes.Pass);
			} else {
				ReportMessage(
						"Pick fee is not applied for fifth (or) greater that 4th orders in Payment page Pick Fee Section",
						MessageTypes.Fail);
			}
		}
		if (pickfeeFromOrderTotal > 0.00) {
			ReportMessage("Succesfully Pick fee is applied  for fifth (or) greater that 4th orders in Checkout pages",
					MessageTypes.Pass);
		} else {
			ReportMessage("Pick fee is not applied for fifth (or) greater that 4th orders in Checkout pages",
					MessageTypes.Fail);
		}

	}

	private boolean isAttribtuePresent(QAFWebElement element, String attribute) {
		Boolean result = false;
		try {
			String value = element.getAttribute(attribute);
			if (value != null) {
				result = true;
			}
		} catch (Exception e) {
		}

		return result;
	}

	/**
	 * Parses given string into a double, and prints a message on what was done.
	 * 
	 * @param bundleProp
	 *            Property to parse
	 * @param msg
	 *            Message to display
	 * @return Parsed double
	 */
	private double calculateTotal(String bundleProp, String msg) {
		double retTotal = Double.parseDouble(bundleProp.replace('$', ' '));
		ReportMessage(msg + retTotal);
		return retTotal;
	}

	private void setPickFee(String timeContainer) {
		String[] splitFee;
		splitFee = timeContainer.split(" ");

		getBundle().setProperty(PICK_FEE_KEY, splitFee[5].replace('$', ' '));
		ReportMessage("Pick fee set: " + splitFee[5].replace('$', ' '));
	}
	
}
