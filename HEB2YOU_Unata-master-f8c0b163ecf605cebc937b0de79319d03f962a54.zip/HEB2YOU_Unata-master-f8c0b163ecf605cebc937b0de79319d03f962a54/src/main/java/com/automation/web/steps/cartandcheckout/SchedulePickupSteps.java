package com.automation.web.steps.cartandcheckout;

import static com.automation.web.commonutils.PerfectoUtils.ReportMessage;

import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.homepage.ShopAssistPickupTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;

/* 
 * List of Step Definitions in Curbside Steps file
Validate user on pickup schedule page
*/

public class SchedulePickupSteps {

	PerfectoUtils util = new PerfectoUtils();
	Actions act = new Actions(PerfectoUtils.getDriver());

	@QAFTestStep(description = "Validate user on pickup schedule page")
	public void validateUserOnSchedulePage() {
		ShopAssistPickupTestPage CurbsideTestPage = new ShopAssistPickupTestPage();

		CurbsideTestPage.getSchdlPickupLblHeader().verifyPresent();
		ReportMessage("Schedule for Pickup page is displayed", MessageTypes.Pass);

	}

}
