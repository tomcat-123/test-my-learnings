package com.automation.web.pages.homepage;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;

import java.util.List;

import com.automation.web.components.shopassistpickup.StoreItemBlocks;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ShopAssistPickupTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void loadPage() {
		curbsidePageLoadItem.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}

	@FindBy(locator = "curbside.pageLoadItem")
	private QAFWebElement curbsidePageLoadItem;

	@FindBy(locator = "curbpickup.lnk.storechange")
	private QAFWebElement lnkStoreChange;

	@FindBy(locator = "curbpickup.txt.storeentercityzip")
	private QAFWebElement txtStoreEnterCityZip;

	@FindBy(locator = "curbpickup.btn.storesearchicon")
	private QAFWebElement btnStoreSearchIcon;

	@FindBy(locator = "curbpickup.btn.closecurbpopup")
	private QAFWebElement btnCloseCurbPopup;

	@FindBy(locator = "curbpickup.lbl.nostorefoundpopup")
	private QAFWebElement lblNoStoreFoundpopup;

	@FindBy(locator = "curbpickup.li.storesearchitemblock")
	private List<StoreItemBlocks> liStoreSearchItemblock;

	@FindBy(locator = "curb.schdlpickup.lbl.header")
	private QAFWebElement schdlPickupLblHeader;
	


	@FindBy(locator = "curbside.lnk.change")
	private QAFWebElement lnkChange;
	
	@FindBy(locator = "curbside.lnk.header")
	private QAFWebElement lnkHeader;
	
	@FindBy(locator = "curbside.img.selectpickup")
	private QAFWebElement imgSelectPickup;
	
	@FindBy(locator = "curbside.img.selectdelivery")
	private QAFWebElement imgSelectDelivery;
	

	public QAFWebElement getLnkChange() {
		return lnkChange;
	}

	public QAFWebElement getLnkHeader() {
		return lnkHeader;
	}

	public QAFWebElement getImgSelectPickup() {
		return imgSelectPickup;
	}

	public QAFWebElement getImgSelectDelivery() {
		return imgSelectDelivery;
	}
	public QAFWebElement getSchdlPickupLblHeader() {
		return schdlPickupLblHeader;
	}

	public QAFWebElement getLblNoStoreFoundpopup() {
		return lblNoStoreFoundpopup;
	}

	public QAFWebElement getBtnCloseCurbPopup() {
		return btnCloseCurbPopup;
	}

	public QAFWebElement getCurbsidePageLoadItem() {
		return curbsidePageLoadItem;
	}

	public QAFWebElement getLnkStoreChange() {
		return lnkStoreChange;
	}

	public QAFWebElement getTxtStoreEnterCityZip() {
		return txtStoreEnterCityZip;
	}

	public QAFWebElement getBtnStoreSearchIcon() {
		return btnStoreSearchIcon;
	}

	public List<StoreItemBlocks> getLiStoreSearchItemblock() {
		return liStoreSearchItemblock;
	}

}