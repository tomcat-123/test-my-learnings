package com.automation.web.steps.accountoptions;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.PerfectoUtils.getDriver;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.databean.EditBillingInfoBean;
import com.automation.web.databean.EditContactInfoBean;
import com.automation.web.databean.EditDeliveryInformationBean;
import com.automation.web.databean.EditPersonalInfoBean;
import com.automation.web.pages.homepage.LoginTestPage;
import com.automation.web.pages.homepage.RegisterTestPage;
import com.automation.web.pages.useraccountactions.AccountTestPages;
import com.qmetry.qaf.automation.step.QAFTestStep;


/*
All the Step definitions under AccountSteps 
I confirm my profile information
User saves changes to profile
User edits all fields of their profile
User edits contact information
User edits billing information
User edits delivery information
User edits personal information
User navigates to information tab {tabCategory}
User edits their password: {oldPass}, {newPass}, {passConf}
Password change not successful
User confirms new password
User changes promotion settings
User clicks Allow Substitutions box
Verify the Criterias for Change Password


*/
public class AccountSteps {
	PerfectoUtils util = new PerfectoUtils();
	Actions act = new Actions(getDriver());
	
	@QAFTestStep(description = "I confirm my profile information")
	public void iConfirmMyProfileInformation(){
		RegisterTestPage register = new RegisterTestPage();
		PerfectoUtils.scrolltoelement(register.getRegisterBtnSaveChanges());
		register.getRegisterBtnSaveChanges().click();

		if(register.getRegisterLblProfileSaved().verifyEnabled())
			util.pass("Profile Changes saved!");
		else
			util.fail("Profile changes not saved");
	}

	@QAFTestStep(description = "User saves changes to profile")
	public void saveProfileChanges(){
		RegisterTestPage register = new RegisterTestPage();
		util.scrollAndClick(register.getRegisterBtnSaveChanges());
		util.pass("Information saved");
	}
	
	@QAFTestStep(description = "User edits all fields of their profile")
	public void editEverything(){
		editContactInfo();
		editPersonalInfo();
		editDeliveryInfo();
		util.pass("New information input");
	}
	
	@QAFTestStep(description = "User edits contact information")
	public void editContactInfo(){
		EditContactInfoBean contactBean = new EditContactInfoBean();
		contactBean.fillRandomData();
		contactBean.fillUiElements();
		util.pass("New information input");
	}
	
	@QAFTestStep(description = "User edits billing information")
	public void editBillingInfo(){
		EditBillingInfoBean billingBean = new EditBillingInfoBean();
		billingBean.fillRandomData();
		billingBean.fillUiElements();
		util.pass("New billing information input");
	}
	
	@QAFTestStep(description = "User edits delivery information")
	public void editDeliveryInfo(){
		EditDeliveryInformationBean delBean = new EditDeliveryInformationBean();
		RegisterTestPage register = new RegisterTestPage();
		
		delBean.fillRandomData();
		delBean.fillUiElements();
		PerfectoUtils.JavaScriptSendKeys(register.getRegisterEdtDaCity(),getBundle().getString("hotuser1.user.city"));
		PerfectoUtils.JavaScriptSendKeys(register.getRegisterEdtDaZip(),getBundle().getString("hotuser1.user.zipcode"));
		util.pass("Delivery information input");
	}
	
	@QAFTestStep(description = "User edits personal information")
	public void editPersonalInfo(){
		EditPersonalInfoBean personalBean = new EditPersonalInfoBean();
		RegisterTestPage register = new RegisterTestPage(); 
		personalBean.fillRandomData();
		
		if(personalBean.getGender().equals("male")){
			register.getRegisterBtnGenderM().click();
		} else {
			register.getRegisterBtnGenderF().click();
		}
		
		personalBean.fillUiElements();
		util.pass("Personal data filled");
	}
	
	@QAFTestStep(description = "User navigates to information tab {tabCategory}")
	public void userInfoCategory(String category){
		AccountTestPages account = new AccountTestPages();
		switch(category){
			case "Profile":
				account.getAcctTabProfile().click();
				break;
			case "Change Password":
				account.getAcctTabPassword().waitForEnabled(MAX_WAIT_TIME);
				account.getAcctTabPassword().click();
				account.getAcctEdtNewPass().waitForPresent(MAX_WAIT_TIME);
				break;
			case "Notification Preferences":
				account.getAcctTabNotifications().click();
				break;
			case "Order History":
				account.getAcctTabHistory().click();
				break;
			case "Substitution Preferences":
				account.getAcctTabSubstitutions().click();
				break;
			case "Later Lists":
				account.getAcctTabLists().click();
				break;
			case "Available Credits":
				account.getAcctTabCredits().click();
				break;
			default:
				util.fail("Unrecognized user tab");
		}
		util.pass(category + " clicked");
	}
	
	
	@QAFTestStep(description = "User edits their password: {oldPass}, {newPass}, {passConf}")
	public void passwordEdit(String oldPass, String newPass, String passConf){
		AccountTestPages account = new AccountTestPages();
		
		account.getAcctEdtOldPass().waitForEnabled(MAX_WAIT_TIME);
		util.enterValues(account.getAcctEdtOldPass(), oldPass);
		util.enterValues(account.getAcctEdtNewPass(), newPass);
		util.enterValues(account.getAcctEdtNewPassConf(), passConf);
		act.sendKeys(Keys.PAGE_DOWN);
		act.perform();
//		util.pass("Password changed!");
		util.pass("Passwords input");
	}
	
	@QAFTestStep(description = "Password change not successful")
	public void passChangeNotSuceessful(){
		AccountTestPages account = new AccountTestPages();
		
		account.getAcctBtnConfPass().click();
		account.getAcctBoxErrorMsg().waitForPresent(MAX_WAIT_TIME);

		util.pass("Password not changed");
	}
	
	@QAFTestStep(description = "Password change not successful for Invalid Current Password")
	public void passChangeNotSuceessfulforInvalidCurrentPassword(){
		AccountTestPages account = new AccountTestPages();
		LoginTestPage login = new LoginTestPage();
		
		account.getAcctBtnConfPass().click();
		login.getLoginTxtLoginFail().waitForPresent(MAX_WAIT_TIME);

		util.pass("Password not changed");
	}
	
	@QAFTestStep(description = "User confirms new password")
	public void confirmNewPass(){
		AccountTestPages account = new AccountTestPages();
		account.getAcctBtnConfPass().click();
		util.pass("Password change confirmed");
	}
	
	@QAFTestStep(description = "User changes promotion settings")
	public void promoSettings(){
		AccountTestPages account = new AccountTestPages();
		
		account.getAcctBtnEmailNotifications().click();
		account.getAcctBtnNotifConf().click();
		account.getAcctTxtPassChangeSuccess().waitForVisible(MAX_WAIT_TIME);
		
		util.pass("Notifications changed");
	}
	
	@QAFTestStep(description = "User clicks Allow Substitutions box")
	public void allowSubs(){
		AccountTestPages account = new AccountTestPages();
		account.getAcctBtnAllowSubstitution().click();
		util.pass("Changed allow substitutions settings");
	}
	
	@QAFTestStep(description = "Verify the Criterias for Change Password")
	public void verifyTheCriteriasForChangePassword(){
		AccountTestPages account = new AccountTestPages();
		
		String validOldPass =getBundle().getString("validUser.password");
		String invalidNewPass;
		
		// Criteria check for - Password must be between 8 to 64 characters.
		invalidNewPass = getBundle().getString("invalidPasswords.lesslength");
		passwordEdit(validOldPass,invalidNewPass,invalidNewPass);
		account.getAcctBtnConfPass().click();
		account.getAccttxterrmsgpasslesslength().waitForPresent(MAX_WAIT_TIME);
		VerifyLessPassError();
	
		
		// Check- Original password and new password are identical.
		passwordEdit(validOldPass,validOldPass,validOldPass);
		account.getAcctBtnConfPass().click();
		account.getAccttxterrmsgpassidentical().waitForPresent(MAX_WAIT_TIME);
		VerifyOldAndNewPassIdenticalError();
	
		
		// Password must be alphanumeric
		invalidNewPass = getBundle().getString("invalidPasswords.nonAlpha");
		passwordEdit(validOldPass,invalidNewPass,invalidNewPass);
		account.getAcctBtnConfPass().click();
		account.getAccttxterrmsgpassnonalpha().waitForPresent(MAX_WAIT_TIME);
		VerifyNonAlphaNumericChangePassError();

		
	}
	
	public void VerifyLessPassError(){
		AccountTestPages account = new AccountTestPages();
		account.getAccttxterrmsgpasslesslength().waitForVisible(MAX_WAIT_TIME);
		if(account.getAccttxterrmsgpasslesslength().isPresent()){
			util.pass("Successfully verified the error message: Password must be between 7 to 64 characters.");
		} else{
			util.fail("Failed to verify the error message: Password must be between 7 to 64 characters.");
		}
	}
	
	public void VerifyOldAndNewPassIdenticalError(){
		
		AccountTestPages account = new AccountTestPages();
		account.getAccttxterrmsgpassidentical().waitForVisible(MAX_WAIT_TIME);
		if(account.getAccttxterrmsgpassidentical().isPresent()){
			util.pass("Successfully verified the error message: Original password and new password are identical.");
		} else{
			util.fail("Failed to verify the error message: Original password and new password are identical.");
		}
	}
	
	public void VerifyNonAlphaNumericChangePassError(){
		
		AccountTestPages account = new AccountTestPages();
		account.getAccttxterrmsgpassnonalpha().waitForVisible(MAX_WAIT_TIME);
		if(account.getAccttxterrmsgpassnonalpha().isPresent()){
			util.pass("Successfully verified the error message: Password must be alphanumeric.");
		} else{
			util.fail("Failed to verify the error message: Password must be alphanumeric.");
		}
	}
}
