package com.automation.web.steps.delivery;


import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NAME_KEY;
import static com.automation.web.commonutils.FunctionUtils.DELIVERY_SET;
import static com.automation.web.commonutils.FunctionUtils.FULFILLMENT_TYPE_KEY;
import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.cartandcheckout.CurbsideTestPage;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;


public class DeliverySteps {
	
	PerfectoUtils util = new PerfectoUtils();
	
	@QAFTestStep(description = "User selects delivery service")
	public void userSelectsDeliveryService(){
		CurbsideTestPage csTest = new CurbsideTestPage();
		csTest.getCurbBtnSelectDelivery().click();
		//SreeRam This needs to be looked into 
		QAFWebElement header = (QAFWebElement)util.generateWebElement("//h1");
		if(header.isEnabled()){
			getBundle().setProperty(FULFILLMENT_TYPE_KEY, DELIVERY_SET);
			util.pass("Delivery selected");
		} else {
			util.fail("Delivery not selected");
		}
	}
	
	@QAFTestStep(description = "User changes to delivery")
	public void iChangeDelivery(){
		CurbsideTestPage csTest = new CurbsideTestPage();
		csTest.getCurbLblEnterDeliveryZip().waitForPresent(MAX_WAIT_TIME*2);
		util.pass("Delivery changed");
	}

	/**
	 * Even though the value of the fulfillment type changes, the time selection modal will not disappear completely.
	 * Needs to sleep to wait for it to fully vanish.
	 * @param zipcode
	 */
	@QAFTestStep(description = "User selects valid store by zipcode {valid zipcode}")
	public void validStoreByZip(String zipcode){
		CurbsideTestPage curbside = new CurbsideTestPage();   
		
		QAFWebElement enterZip = curbside.getCurbEdtEnterZipcode(); 
		QAFWebElement submitBtn = curbside.getCurbBtnSubmit(); 
		util.enterValues(enterZip, zipcode);
		submitBtn.click();
	
		getBundle().setProperty(CUR_STORE_NAME_KEY, zipcode);
		
		util.pass("Zipcode entered");
	}
}
