package com.automation.web.steps.accountoptions;

import static com.automation.web.commonutils.FunctionUtils.CONSM_PRCH_CD_KEY;
import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.PerfectoUtils.ReportMessage;
import static com.automation.web.commonutils.PerfectoUtils.getDriver;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.FunctionUtils;
import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.cartandcheckout.CartTestPage;
import com.automation.web.pages.homepage.HomeTestPage;
import com.automation.web.pages.orderhistory.OrderDetailsTestPage;
import com.automation.web.pages.orderhistory.OrderHistoryTestPage;
import com.automation.web.pages.saveforlaterlists.SaveListTestPage;
import com.automation.web.pages.searchandbrowse.ProductTestPage;
import com.automation.web.steps.cartandcheckout.CartSteps;
import com.automation.web.steps.cartandcheckout.CheckoutSteps;
import com.automation.web.steps.homepage.HomePageSteps;
import com.automation.web.steps.registerandlogin.LoginPageSteps;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

/*
All the Step definitions under HistorySteps 

User filters history to (last|year) {filterBy}
User re-orders items from order number {number}
User verifies substituted item in order {number}
User verifies add-on item in order number {number}
User re-orders items from order number {number}
User views history of order number {orderNumber}
Verify items unavailable for re-order
Verify user can cancel order
Verify user can not cancel order
User creates new shopping list named {listName}
User creates list on Saved List Page named {listName}
User creates new list and verifies list items
User deletes last list in saved lists
User adds items to existing shopping list named {listName}
User prints out list items
Verify base price has not changed from {list} to Main Product Page
Verify number of items on list matches
{User} {userPass} adds {qtyNum} to first {list} item, and verifies persistence
User navigates to list number {listNumber}
User views details of first list
User navigates to homepage and verifies Quick Order History
User navigates to homepage and verifies Save For Later Lists

*/
public class HistorySteps {
	PerfectoUtils util = new PerfectoUtils();
	FunctionUtils funUtil = new FunctionUtils();
	Actions act = new Actions(getDriver());

	/**
	 * Will filter the results by the given parameter. If no list can be
	 * generated, will do a check to see if that is because we're outside the
	 * year range, as it extends to before the site was in creation there would
	 * logically be no orders
	 * 
	 * @param filterBy
	 *            How to filter the history. Six month, year, etc.
	 */
	@QAFTestStep(description = "User filters history to (last|year) {filterBy}")
	public void filterByX(String filterBy) {
		OrderHistoryTestPage history = new OrderHistoryTestPage();
		List<QAFWebElement> orderDates = null;
		QAFWebElement header = null;
		Date startRange = setDateRange(filterBy, false);
		Date endRange = setDateRange(filterBy, true);
		Date inspectionDate;

		util.selectBoxSelectionwithoutClick(history.getAcctSelFilterBy(), filterBy);

		// Try to populate the table
		try {
			orderDates = history.getliCurbsideDates();
			header = history.getLblSubHeaderbanner();
			header.waitForEnabled(MAX_WAIT_TIME);
		} catch (Exception e) {
			int testYear = Integer.parseInt(filterBy);
			if (testYear < Calendar.getInstance().get(Calendar.YEAR)) {
				header = history.getLblNoOrderFound();
				header.waitForEnabled(MAX_WAIT_TIME);
				util.pass("No orders for year, but history filterable");
			} else {
				util.fail("Year should be populated");
			}
			return;
		}

		// Iterate through table and verify dates
		for (QAFWebElement row : orderDates) {
			PerfectoUtils.scrolltoelement(row);
			inspectionDate = setDate(row.getText());

			if (!(inspectionDate.before(startRange) || inspectionDate.after(endRange))) {
				util.fail("Bad date range on row: " + row.getText());
			} else {
				PerfectoUtils.ReportMessage("Order date in proper range");
			}
		}
		util.pass("Filtered by " + filterBy);
	}

	@SuppressWarnings("deprecation")
	private Date setDateRange(String filterBy, boolean endRange) {
		Date currentDate = new Date();
		Calendar cal = new GregorianCalendar();
		cal.setTime(currentDate);

		if (filterBy.equals(getBundle().getString("history.thirty"))) {
			if (endRange) {
				cal.add(Calendar.DAY_OF_MONTH, -30);
				return cal.getTime();
			} else {
				cal.add(Calendar.DAY_OF_MONTH, 1);
				return cal.getTime();
			}
		} else if (filterBy.equals(getBundle().getString("history.sixMon"))) {
			if (endRange) {
				cal.add(Calendar.MONTH, -6);
				return cal.getTime();
			} else {
				cal.add(Calendar.DAY_OF_MONTH, 1);
				return cal.getTime();
			}
		}

		int filterRange = Integer.parseInt(filterBy);

		if (endRange) {
			cal.set(Calendar.MONTH, 12);
			cal.set(Calendar.DAY_OF_MONTH, 31);
			cal.set(Calendar.YEAR, filterRange);
		} else {
			cal.set(Calendar.MONTH, 1);
			cal.set(Calendar.DAY_OF_MONTH, 1);
			cal.add(Calendar.YEAR, filterRange - currentDate.getYear());
		}

		return cal.getTime();
	}

	/**
	 * Per Kieth, this one is being momentarily abandoned due to site
	 * functionality. Everything is pretty set up for when the issue with QTY
	 * being updated for the cart, though. Grabs current cart amount, then
	 * parses through the history lines to grab the amounts, and creates a final
	 * total of what to add. From there, all that needs to be done is to compare
	 * the two numbers. A less robust version of this will be used in the mean
	 * time that will check to see if when re-order is clicked whether or not
	 * the line item is appended to the cart
	 * 
	 * @param orderNumber
	 */
	// @QAFTestStep(description = "User re-orders items from order number
	// {number}")
	public void reorderFromHistory(String orderNumber) {
		CartTestPage reorderBtn = new CartTestPage();
		OrderHistoryTestPage noOfProducts = new OrderHistoryTestPage();
		// APIHub hub = new APIHub();
		getDriver().get(getBundle().getString("history.hisURL") + orderNumber);
		WebElement imgEle;
		WebElement currentItemCnt = null;
		int currentCartAmt = 0;
		// Grabs the qty of items
		List<QAFWebElement> table_elements = noOfProducts.getliOrderedProducts();
		try {
			currentItemCnt = reorderBtn.getCartTxtBtnItemQty();
			currentCartAmt = Integer.parseInt(currentItemCnt.getText());
		} catch (NoSuchElementException e) {
			currentCartAmt = 0;
		}

		int qtyToAdd = 0;

		String[] rowText;
		String itemNum;
		String itemType = null;

		// Iterate through items and add to item count
		for (WebElement row : table_elements) {
			imgEle = row.findElement(By.className("item-image"));
			itemNum = funUtil.generateItemID(imgEle.getAttribute("style"));
			// util.print(itemNum);
			rowText = row.getText().split("\n");
			// try {
			// hub.genProductInfo(itemNum);
			// } catch (UnsupportedOperationException | IOException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// }

			itemType = getBundle().getProperty(CONSM_PRCH_CD_KEY + itemNum) + "";
			if (!itemType.equals("\"WEIGH\"") || itemType.isEmpty()) {
				qtyToAdd += Integer.parseInt(rowText[rowText.length - 2]);
			} else {
				qtyToAdd += 1;
			}
		}
		// util.print(qtyToAdd + " to add");
	}

	@QAFTestStep(description = "User verifies substituted item in order")
	public void verifySubs() {
		OrderHistoryTestPage subs = new OrderHistoryTestPage();
		
		String historyNum = "";
		if(PerfectoUtils.getDriver().getCurrentUrl().contains(getBundle().getString("uatURL"))){
			historyNum = getBundle().getString("hotuser1.orderHistory.uat.substitution");
		}else{
			historyNum = getBundle().getString("hotuser1.orderHistory.stage.substitution");
		}
		this.navToHistOrder(historyNum);
		//List<QAFWebElement> allsubText = subs.getLblAllowSubs();
		List<QAFWebElement> allsubYes = subs.getLblAllowSubsYes();
		if (allsubYes.get(0).isEnabled()) {
			util.pass("Item substituted");
		} else {
			util.fail("Items not substituted");
		}
	}

	/**
	 * Navigates to the history page of the item and assumes first item is the
	 * add on item
	 * 
	 * @param historyNum
	 */
	@QAFTestStep(description = "User verifies add-on item in order number {number}")
	public void verifyAddOn(String historyNum) {
		// getDriver().get(getBundle().getString("history.hisURL") +
		// historyNum);
		this.navToHistOrder(historyNum);
		OrderHistoryTestPage OrderHistory = new OrderHistoryTestPage();
		List<QAFWebElement> addProd = OrderHistory.getchkboxaddon();
		// QAFWebElement prodPicked = (QAFWebElement) util.
		// generateWebElement("//table/tbody[1]//div[@class='status icon
		// picked']");
		// String addprodUncheck =
		// getBundle().getString("hotuser1.orderHistory.stage.addonProductUnChk");
		String addprodcheck = getBundle().getString("hotuser1.orderHistory.stage.addonProductChk");
		// util.scrollToElement(addProd);
		if (addProd.get(0).getAttribute("background") == addprodcheck) {
			util.pass("Item added to the order");
		} else {
			util.fail("Label is clickable or item has not been picked");
		}
	}

	@QAFTestStep(description = "User re-orders items from order number")
	public void reorderCartCheck() {
		CartTestPage CartTestPage = new CartTestPage();
		OrderHistoryTestPage OrderHistory = new OrderHistoryTestPage();
		WebElement currentItemCnt = null;
		currentItemCnt = CartTestPage.getCartTxtBtnItemQty();
		
		String historyNum = "";
		if(PerfectoUtils.getDriver().getCurrentUrl().contains(getBundle().getString("uatURL"))){
			historyNum = getBundle().getString("history.uat.multiCat");
		}else{
			historyNum = getBundle().getString("history.stage.multiCat");
		}
		// WebElement currentItemCnt =
		// util.generateWebElement("//a[@id='nav-cart-main-checkout-cart']/div");
		// Checks if the cart is empty. If it isn't, empties it
		try {
			if (currentItemCnt.isDisplayed()) {
				CheckoutSteps checkout = new CheckoutSteps();
				CartSteps cart = new CartSteps();
				checkout.iClickMainCheckout();
				cart.removeAllItemsFromCart();
			}
		} catch (Exception e) {
			// Ignore
		}

		CartTestPage reorderBtn = new CartTestPage();
		// getDriver().get(getBundle().getString("history.hisURL") +
		// historyNum);
		this.navToHistOrder(historyNum);
		OrderHistoryTestPage noOfProducts = new OrderHistoryTestPage();
		WebElement imgEle;
		ArrayList<Integer> historyList = new ArrayList<>();
		ArrayList<Integer> sideCartList = new ArrayList<>();

		// Grabs the history items
		List<QAFWebElement> table_elements = noOfProducts.getliOrderedProducts();

		String itemNum;

		// Iterate through items and add them to a list
		for (WebElement row : table_elements) {
			imgEle = row.findElement(By.className("item-image"));
			itemNum = funUtil.generateItemID(imgEle.getAttribute("style"));
			historyList.add(Integer.parseInt(itemNum));
		}

		reorderBtn.getChckOutBtnReorderItems().click();

		// Side cart item images
		CartTestPage sidecartimg = new CartTestPage();
		sidecartimg.getimgSidCartImg().get(0).waitForPresent(MAX_WAIT_TIME);
		List<QAFWebElement> table_elements1 = sidecartimg.getimgSidCartImg();

		for (WebElement row : table_elements1) {
			itemNum = funUtil.generateItemID(row.getAttribute("style"));
			sideCartList.add(Integer.parseInt(itemNum));

		}

		Collections.sort(historyList);
		Collections.sort(sideCartList);

		if (historyList.equals(sideCartList)) {
			util.pass("Items re-ordered!");
		} else {
			util.fail("Items not re-ordered");
		}
	}

	@QAFTestStep(description = "User views history of order number {0}")
	public void navToOrder(String category) {
		OrderDetailsTestPage orderdetails = new OrderDetailsTestPage();

		String orderNumber = "";
		if(PerfectoUtils.getDriver().getCurrentUrl().contains(getBundle().getString("uatURL"))){
			orderNumber = getBundle().getString("hotuser1.orderHistory.uat."+category);
		}else{
			orderNumber = getBundle().getString("hotuser1.orderHistory.stage."+category);
		}
		this.navToHistOrder(orderNumber);
		orderdetails.getLblHeaderordernumber().waitForPresent(MAX_WAIT_TIME * 2);
		String displayedNum = PerfectoUtils.getIntCharacters(orderdetails.getLblHeaderordernumber().getText());
		// funUtil.generateOrderNumber(header.getText());
		if (displayedNum.equals(orderNumber)) {
			util.pass("Navigated to order number " + displayedNum);
		} else {
			util.fail("Navigated to incorrect order. Given: " + orderNumber + ", found: " + displayedNum);
		}
	}

	@QAFTestStep(description = "Verify items unavailable for re-order")
	public void unavailForReOrder() {
		// List<WebElement> inputCheck =
		// getDriver().findElements(By.xpath("//tr[@class='parent']/td"));
		// List<WebElement> disabledCheck =
		// getDriver().findElements(By.xpath("//tr[@class='parent']/td[@disabled='disabled']"));
		OrderHistoryTestPage OrderHistory = new OrderHistoryTestPage();
		List<QAFWebElement> inputCheck = OrderHistory.getchkboxaddon();

		// List<WebElement> inputCheck =
		// util.generateWebElementList("//tr[@class='parent']/td");
		// List<WebElement> disabledCheck =
		// util.generateWebElementList("//tr[@class='parent']/td[@disabled='disabled']");
		// act.moveToElement(inputCheck.get(inputCheck.size() - 1));
		// act.perform();
		util.moveToElement(inputCheck.get(inputCheck.size() - 1));
		String addprodUncheck = getBundle().getString("hotuser1.orderHistory.stage.addonProductUnChk");
		String addprodcheck = getBundle().getString("hotuser1.orderHistory.stage.addonProductChk");
		if (inputCheck.get(0).getAttribute("background") == addprodcheck) {
			OrderHistory.getchkboxSelectallProduct().click();

			if (inputCheck.get(0).getAttribute("background") == addprodUncheck) {
				util.pass("All items disabled");
			} else {
				util.fail("Items not disabled");
			}

		}

	}

	@QAFTestStep(description = "Verify user can cancel order")
	public void verifyCancelOrder() {
		OrderHistoryTestPage account = new OrderHistoryTestPage();
		OrderDetailsTestPage detail = new OrderDetailsTestPage();
		account.getAcctBtnCancelOrder().click();

		account.getbtnOrderCancelNo().waitForPresent(MAX_WAIT_TIME * 5);
		if (account.getbtnOrderCancelNo().isPresent()) {
			account.getbtnOrderCancelYes().click();
			ReportMessage("Yes button is clicked from order cancel popup");
			PerfectoUtils.waitAngularHasFinishedProcessing();
			// QAFWebElement cancelled = account.getbtnOrderCancelNo();
			// cancelled.waitForEnabled(MAX_WAIT_TIME);
		}
		detail.getLblCancelled().waitForPresent(MAX_WAIT_TIME * 5);
		if (detail.getLblCancelled().isPresent())
			util.pass("Order cancelled successfully");
		else
			util.pass("Order not cancelled ");
	}

	@QAFTestStep(description = "Verify user can not cancel order")
	public void verifyOrderNotCancelable() {
		OrderHistoryTestPage account = new OrderHistoryTestPage();

		if (!account.getAcctBtnCancelOrder().isDisplayed()) {
			util.pass("Cancel button is not displayed!");
		} else {
			PerfectoUtils.scrolltoelement(account.getAcctBtnCancelOrder());
			util.fail("Cancel button displayed!");
		}
	}

	@QAFTestStep(description = "User creates new shopping list named {listName}")
	public void createNewList(String listName) {
		ProductTestPage product = new ProductTestPage();
		SaveListTestPage saveList = new SaveListTestPage();

		int random = (int) (Math.random() * 99 + 1);
		listName = listName + random;

		try {
			product.getProductBtnSaveForLater().waitForPresent(MAX_WAIT_TIME);
			product.getProductBtnSaveForLater().click();
			ReportMessage("Clicked on Save for later button..", MessageTypes.Pass);
		} catch (Exception e1) {
			product.getBtnSaved().waitForPresent(MAX_WAIT_TIME);
			product.getBtnSaved().click();
			ReportMessage("Clicked on Saved button..", MessageTypes.Pass);
		}

		util.enterValueAndSendEnter(product.getProductEdtEnterNewList(), listName);
		navToSavedListPage();
		PerfectoUtils.waitAngularHasFinishedProcessing();
		saveList.getlilistnames().get(0).waitForPresent(MAX_WAIT_TIME);
		List<QAFWebElement> listCheck = saveList.getlilistnames();

		if (listCheck.get(0).getText().equals(listName)) {
			util.pass("List saved");
		} else {
			util.fail("List not created properly.");
		}
	}

	@QAFTestStep(description = "User creates list on Saved List Page named {listName}")
	public void newList(String listName) {
		SaveListTestPage nav = new SaveListTestPage();
		List<QAFWebElement> listCheck;
		navToSavedListPage();
		nav.getSaveFLBtnCreateNewList().click();
		nav.getSaveFLEditNewList().waitForEnabled(MAX_WAIT_TIME);
		util.enterValues(nav.getSaveFLEditNewList(), listName);
		nav.getSaveFLBtnSaveList().click();
		listCheck = nav.getlilistnames();
		/*
		 * try { listCheck.wait(MAX_WAIT_TIME * 3); } catch
		 * (InterruptedException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */
		if (listCheck.get(0).getText().equals(listName)) {
			util.pass("List saved");
		} else {
			util.fail("List not created properly.");
		}
	}

	@QAFTestStep(description = "User creates new list and verifies list items")
	public void createAndVerifySFLList() {
		SaveListTestPage list = new SaveListTestPage();

		list.getsaveFLLiImgSavelistimg().get(0).waitForPresent(MAX_WAIT_TIME * 5);
		List<QAFWebElement> itemImg = list.getsaveFLLiImgSavelistimg();
		ArrayList<String> itemIdsToAdd = new ArrayList<>();
		ArrayList<String> itemsToCompare = new ArrayList<>();
		for (QAFWebElement image : itemImg) {
			util.moveToElement(image);
			itemIdsToAdd.add(funUtil.generateItemID(image.getAttribute("style")));
		}

		// Verify new list has been created and navigate to the list details
		createNewList("List items List");
		util.generateWebElement("//table/tbody/tr[1]//a").click();

		// Verify correct items added to list

		for (QAFWebElement image : itemImg) {
			util.moveToElement(image);
			itemsToCompare.add(funUtil.generateItemID(image.getAttribute("style")));
		}

		if (itemIdsToAdd.containsAll(itemsToCompare)) {
			util.pass("List created correctly");
		} else {
			util.fail("List missing items");
		}
	}

	@QAFTestStep(description = "User deletes last list in saved lists")
	public void deleteLastList() {
		SaveListTestPage nav = new SaveListTestPage();
		navToSavedListPage();
		List<QAFWebElement> deleteButtons = nav.getLiChkboxDdelete();
		QAFWebElement lastButton = deleteButtons.get(deleteButtons.size() - 1);
		PerfectoUtils.scrolltoelement(lastButton);
		lastButton.click();
		PerfectoUtils.waitUntilVisibilityofElement(nav.getSaveFLBtnDeleteConfirm());
		nav.getSaveFLBtnDeleteConfirm().click();
		util.pass("Deleted last list");
	}

	@QAFTestStep(description = "User adds items to existing shopping list named {listName}")
	public void saveToList(String existingList) {
		ProductTestPage product = new ProductTestPage();
		OrderDetailsTestPage saveListsreorderbtn = new OrderDetailsTestPage();
		int flag = 0;
		int itemSize = saveListsreorderbtn.getLiItemName().size();
		try {
			product.getProductBtnSaveForLater().waitForPresent(MAX_WAIT_TIME);
			product.getProductBtnSaveForLater().click();
		} catch (Exception e1) {
			product.getBtnSaved().waitForPresent(MAX_WAIT_TIME);
			// util.scrollAndClick(product.getBtnSaved());
			// CommonUtils.scrolltoelement(saveListsreorderbtn.getBtnReorderselecteditems());
			product.getBtnSaved().click();
		}

		// List<WebElement> listsNames =
		// getDriver().findElements(By.className("link"));
		List<QAFWebElement> listsNames = saveListsreorderbtn.getLiSavedLists();
		QAFWebElement selectedList;
		for (QAFWebElement list : listsNames) {
			util.moveToElement(list);
			if (list.getText().equals(existingList)) {
				try{
				if (saveListsreorderbtn.getSavedListscheckmark(existingList).isDisplayed()) {
					util.pass("Already Added to list");
					list.click();
					util.pass("Removed Added to list for next time verification");
				}}catch(Exception e){
					list.click();
					util.pass("Added to Existing list");
					selectedList = (QAFWebElement) list;
				}
				flag = 1;
				// product.getProductBtnSaveForLater().waitForNotText("Save for
				// Later", MAX_WAIT_TIME);
				break;
			}
		}
		if (flag == 1) {
			util.pass("Existing list '"+existingList+"' is displayed");
		} else {
			util.fail("Fail to Add to the list. Existing list '"+existingList+"' is not displayed");
		}
	}

	@QAFTestStep(description = "User prints out list items")
	public void printListItems() {
		SaveListTestPage nav = new SaveListTestPage();
		navToSavedListPage();

		List<QAFWebElement> viewDetailsInList = nav.getSaveFLLblViewDetail();
		// List<WebElement> viewDetailsInList =
		// getDriver().findElements(By.xpath("//table//tbody/tr/td/a"));
		viewDetailsInList.get(0).click();
		nav.getSaveFLBtnPrint().click();

		try {
			// get window handlers as list
			List<String> browserTabs = new ArrayList<String>(getDriver().getWindowHandles());
			// switch to new tab
			getDriver().switchTo().window(browserTabs.get(1));
			util.pass("List printable");
		} catch (ArrayIndexOutOfBoundsException e) {
			util.fail("List not printable, tab not opened.");
		}
	}

	@QAFTestStep(description = "Verify base price has not changed in Main Product Page")
	public void verifyPriceHasNotChanged() {
		ProductTestPage product = new ProductTestPage();
		SaveListTestPage list = new SaveListTestPage();
		
		String listNumber = "";
		if(PerfectoUtils.getDriver().getCurrentUrl().contains(getBundle().getString("uatURL"))){
			listNumber = getBundle().getString("historyUser.shoppingList.uat");
		}else{
			listNumber = getBundle().getString("historyUser.shoppingList.stage");
		}
		
		QAFWebElement currentListPrice;
		String value;
		String listURL = getBundle().getString("env.baseurl") + getBundle().getString("history.listURL") + "/"
				+ listNumber;

		// util.print(listURL);
		double listPrice = 0.0;
		double productPrice = 0.0;

		// Get list pricing
		getDriver().get(listURL);
		list.getsaveFLLiImgSavelistimg().get(0).waitForPresent(MAX_WAIT_TIME);
		currentListPrice = (QAFWebElement) util.generateWebElement("//tr[@class='item']//span[@class='amount']");
		value = currentListPrice.getText().replace('$', ' ');
		listPrice = Double.parseDouble(value);

		// Get unata product id, navigate to product page, get the price
		list.getsaveFLLiImgSavelistimg().get(0).click();
		product.getProductImgProductId().waitForEnabled(MAX_WAIT_TIME);
		String prodId = product.getProductImgProductId().getAttribute("value");
		getDriver().get(getBundle().getString("env.baseurl") + "product/" + prodId);
		product.getProductTxtPrice().waitForEnabled(MAX_WAIT_TIME);

		productPrice = Double.parseDouble(product.getProductTxtPrice().getText().replace('$', ' '));

		// Compare the prices
		if (productPrice == listPrice) {
			util.pass("Prices match");
		} else {
			ReportMessage("List price = " + listPrice);
			ReportMessage("Product price = " + productPrice);
			util.fail("Prices do not match");
		}
	}

	/**
	 * Finds the item count on the main page for the first list in saved lists
	 * link. Then navigates into the list and counts the amount of items
	 * present. If they match, then the test passes
	 */
	@QAFTestStep(description = "Verify number of items on list matches")
	public void verifyListNumberMatch() {
		HomeTestPage htp = new HomeTestPage();
		navToSavedListPage();
		// Get count of first list
		List<QAFWebElement> itemAmountInList = htp.getHomeListItemAmount();
		List<QAFWebElement> viewDetailsInList = htp.getHomeListViewDetails();

		String[] itemCnt = itemAmountInList.get(0).getText().split(" ");
		int mainPageCnt = Integer.parseInt(itemCnt[0]);
		util.pass("Item count saved: " + mainPageCnt);

		// Navigate into the list, count the items present
		viewDetailsInList.get(0).click();
		ReportMessage("Clicked on Details..", MessageTypes.Pass);

		htp.getHomeListNewItemAmount().get(0).waitForPresent(MAX_WAIT_TIME * 5);
		List<QAFWebElement> newitemAmountInList = htp.getHomeListNewItemAmount();
		// itemAmountInList =
		// util.generateWebElementList("//table/tbody/tr[@class='item']");

		// Compare counts
		if (mainPageCnt == newitemAmountInList.size()) {
			util.pass("List size is the same");
		} else {
			util.fail("List sizes do no match. List size on main page: " + mainPageCnt + ", list details size: "
					+ newitemAmountInList.size());
		}
	}

	@QAFTestStep(description = "{User} {userPass} adds {qtyNum} to first {list} item, and verifies persistence")
	public void addInSFLAndVerify(String email, String password, int changeAmnt, String listNum) {
		HomePageSteps homePg = new HomePageSteps();
		HomeTestPage htp = new HomeTestPage();
		LoginPageSteps login = new LoginPageSteps();

		QAFWebElement itemQty = htp.getHomeLblItemQty();
		// WebElement itemQty =
		// util.generateWebElement("//table[@class='table']//div[@item='item']//input");
		int curAmount = Integer.parseInt(itemQty.getAttribute("value"));
		int newAmnt = curAmount + changeAmnt;
		// util.scrollToElement(itemQty);
		itemQty.clear();
		util.enterValueAndSendEnter((QAFWebElement) itemQty, newAmnt + "");

		homePg.iClickYourAcctTab();
		htp.getHomeLnkLogout().click();
		homePg.userAmOnHomePage();
		homePg.userClicksLoginRegisterButton();
		login.iEnterValidEmailAndPassword(email, password);
		login.userSubmitsLoginForm();
		viewFirstList();
		// itemQty =
		// util.generateWebElement("//table[@class='table']//div[@item='item']//input");
		PerfectoUtils.scrolltoelement(itemQty);
		if (Integer.parseInt(itemQty.getAttribute("value")) == newAmnt) {
			util.pass("Change amount persisted through log out.");
		} else {
			util.fail("Amount did not persist. Amount saved: " + itemQty.getAttribute("value"));
		}
	}

	/**
	 * Helper method to navigate to given Save for Later Lists
	 * 
	 * @param listNumber
	 *            List ID number to navigate to
	 */
	@QAFTestStep(description = "User navigates to list number {listNumber}")
	public void navToListNum(String listNumber) {
		getDriver().get(
				getBundle().getString("env.baseurl") + getBundle().getString("history.listURL") + "/" + listNumber);
	}

	@QAFTestStep(description = "User views details of first list")
	public void viewFirstList() {
		SaveListTestPage saveList = new SaveListTestPage();
		
		navToSavedListPage();
		saveList.getSaveFLLnkFirstSaveList().waitForEnabled(MAX_WAIT_TIME);
		saveList.getSaveFLLnkFirstSaveList().click();
	}

	@QAFTestStep(description = "User navigates to homepage and verifies Quick Order History")
	public void navToHPAndVerifyQOH() {
		HomeTestPage htp = new HomeTestPage();
		htp.getHomeImgHeblogo().click();

		htp.getHomeLnkQuickOrderHis().waitForEnabled(MAX_WAIT_TIME);
		util.pass("Quick Order History button enabled");
	}

	@QAFTestStep(description = "User navigates to homepage and verifies Save For Later Lists")
	public void navToHPAndVerifySFLL() {
		HomeTestPage htp = new HomeTestPage();
		htp.getHomeImgHeblogo().click();
		htp.getHomeLnkQuickSFLL().waitForEnabled(MAX_WAIT_TIME);
		util.pass("Quick Save for Later Lists button enabled");
	}

	/**
	 * Navigates to the saved lists page utilizing the url saved in the
	 * "userEditOptions.xml" file
	 */
	public void navToSavedListPage() {
		getDriver().get(getBundle().getString("env.baseurl") + getBundle().getString("history.listURL"));
	}

	private void navToHistOrder(String orderNum) {
		getDriver().get(getBundle().getString("history.hisURL") + orderNum);
	}

	/**
	 * Sets the date off given parameters. If unable to tell month, defaults to
	 * January
	 * 
	 * @param strDate
	 * @return
	 */
	private Date setDate(String strDate) {
		String[] parseDate = strDate.split(" ");
		String mon = parseDate[0];
		Calendar cal = new GregorianCalendar();
		int day = Integer.parseInt(parseDate[1].replaceAll("[^\\d]", ""));
		int year = Integer.parseInt(parseDate[2]);
		try {
			Date date = new SimpleDateFormat("MMM", Locale.ENGLISH).parse(mon);
			cal.setTime(date);
			cal.set(Calendar.DAY_OF_MONTH, day);
			cal.set(Calendar.YEAR, year);
		} catch (ParseException e) {
			cal.set(Calendar.DAY_OF_MONTH, day);
			cal.set(Calendar.YEAR, year);
			cal.set(Calendar.MONTH, 1);
			PerfectoUtils.ReportMessage("Unable to read Month provided, default to January");
		}
		return cal.getTime();
	}
}
