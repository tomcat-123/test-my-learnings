package com.automation.web.pages.cartandcheckout;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class OrderCompleteTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {
	
	public synchronized void loadPage(){
		ckconPageLoadItem.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}

	@FindBy(locator = "ordercomplete.txt.storename")
	private QAFWebElement TxtStorename;
	
	@FindBy(locator = "ordercomplete.txt.pickuptime")
	private QAFWebElement TxtPickUpTime;
	
	@FindBy(locator = "ordercomplete.lnk.orderdetails")
	private QAFWebElement LnkOrderDetails;
	
	@FindBy(locator = "ordercomplete.txt.orderdelheaerd")
	private QAFWebElement TxtorderdetHeaerd;
	
	@FindBy(locator = "ordercomplete.img.hebtoyoulogo")
	private QAFWebElement imgHebtoyoulogo;
	
	@FindBy(locator = "ordercomplete.txt.ordernumber")
	private QAFWebElement Txtordernumber;
	
	@FindBy(locator = "ordercomplete.hdr.thankYou")
	private QAFWebElement confHdrThankYou;

	@FindBy(locator = "ordercomplete.btn.orderDetails")
	private QAFWebElement confBtnOrderDetails;
	
	@FindBy(locator = "ordercomplete.pageLoadItem")
	private QAFWebElement ckconPageLoadItem;
	
	/**
	 * Header for the checkout confirmation page
	 */
	public QAFWebElement getCkconPageLoadItem(){ return ckconPageLoadItem; }


	/**
	 * Thank you message on confirmation page
	 */
	public QAFWebElement getConfHdrThankYou(){ return confHdrThankYou; }

	/**
	 * Order details link
	 */
	public QAFWebElement getConfBtnOrderDetails(){ return confBtnOrderDetails; }

	public QAFWebElement getTxtStorename(){ return TxtStorename; }
	
	public QAFWebElement getTxtPickUpTime(){ return TxtPickUpTime; }
	
	public QAFWebElement getLnkOrderDetails(){ return LnkOrderDetails; }
	
	public QAFWebElement getTxtorderdetHeaerd(){ return TxtorderdetHeaerd; }

	public QAFWebElement getImgHebtoyoulogo() {return imgHebtoyoulogo;
	}
	
	public QAFWebElement getTxtordernumber(){ return Txtordernumber; }
	
}