package com.automation.web.pages.homepage;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;

import java.util.List;
//import static common.CommonUtils.MAX_WAIT_TIME;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ShopTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}
	
	public synchronized void loadPage(){
		navPageLoadItem.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}


	@FindBy(locator = "waytoshop.li.leftnavigations")
	private List<QAFWebElement> liLeftnavigations;
	
	@FindBy(locator = "waytoshop.txt.header")
	private QAFWebElement txtHeader;


	@FindBy(locator = "waytoshop.pageLoadItem")
	private QAFWebElement navPageLoadItem;

	@FindBy(locator = "waytoshop.get.i.catHeader")
	private QAFWebElement navGetICatHeader;

	

	@FindBy(locator = "waytoshop.box.compareCartModal")
	private QAFWebElement navBoxCompareCartModal;

	@FindBy(locator = "waytoshop.li.aislePane")
	private List<QAFWebElement> navLiAislePane;

	@FindBy(locator = "waytoshop.li.navPaneCat")
	private List<QAFWebElement> navLiNavPaneCat;

	@FindBy(locator = "waytoshop.li.mainCat")
	private List<QAFWebElement> navLiMainCat;
	
	@FindBy(locator = "waytoshop.btn.compareCartModalcontinue")
	private QAFWebElement navBtnCompareCartModalContinue;
	
	public QAFWebElement getNavBtnCompareCartModalContinue(){ return navBtnCompareCartModalContinue; }

	/**
	 * Header for each category item
	 */
	public QAFWebElement getNavPageLoadItem(){ return navPageLoadItem; }

	/**
	 * Dynamic header for each category item
	 */
	public QAFWebElement getNavGetICatHeader(String item){ 
		String retElm = String.format(pageProps.getString("waytoshop.get.i.catHeader"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	

	/**
	 * Modal to compare items in cart
	 */
	public QAFWebElement getNavBoxCompareCartModal(){ return navBoxCompareCartModal; }

	/**
	 * List of Aisle pane categories
	 */
	public List<QAFWebElement> getNavLiAislePane(){ return navLiAislePane; }

	/**
	 * List of navigation pane categories
	 */
	public List<QAFWebElement> getNavLiNavPaneCat(){ return navLiNavPaneCat; }

	/**
	 * List of main categories
	 */
	public List<QAFWebElement> getNavLiMainCat(){ return navLiMainCat; }

/*
 * ListView for way to shop left navigations
 */
	public List<QAFWebElement> getLiLeftnavigations() {
		return liLeftnavigations;
	}	
/*
 * Header text of ways to shop page
 */
	public QAFWebElement gettxtHeader() {
		return txtHeader;
	}


	

	

}