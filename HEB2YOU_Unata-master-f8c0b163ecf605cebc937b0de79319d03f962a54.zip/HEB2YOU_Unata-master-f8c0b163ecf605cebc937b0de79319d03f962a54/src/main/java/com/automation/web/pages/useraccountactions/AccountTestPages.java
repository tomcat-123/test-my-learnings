package com.automation.web.pages.useraccountactions;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class AccountTestPages extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}

	public synchronized void loadPage(){
		acctPageLoadItem.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}

	@FindBy(locator = "acct.pageLoadItem")
	private QAFWebElement acctPageLoadItem;

	@FindBy(locator = "acct.tab.profile")
	private QAFWebElement acctTabProfile;

	@FindBy(locator = "acct.tab.password")
	private QAFWebElement acctTabPassword;

	@FindBy(locator = "acct.tab.notifications")
	private QAFWebElement acctTabNotifications;

	@FindBy(locator = "acct.tab.history")
	private QAFWebElement acctTabHistory;

	@FindBy(locator = "acct.tab.substitutions")
	private QAFWebElement acctTabSubstitutions;

	@FindBy(locator = "acct.tab.lists")
	private QAFWebElement acctTabLists;

	@FindBy(locator = "acct.tab.credits")
	private QAFWebElement acctTabCredits;

	@FindBy(locator = "acct.edt.oldPass")
	private QAFWebElement acctEdtOldPass;

	@FindBy(locator = "acct.edt.newPass")
	private QAFWebElement acctEdtNewPass;

	@FindBy(locator = "acct.edt.newPassConf")
	private QAFWebElement acctEdtNewPassConf;

	@FindBy(locator = "acct.btn.confPass")
	private QAFWebElement acctBtnConfPass;

	@FindBy(locator = "acct.txt.passChangeSuccess")
	private QAFWebElement acctTxtPassChangeSuccess;

	@FindBy(locator = "acct.btn.emailNotifications")
	private QAFWebElement acctBtnEmailNotifications;

	@FindBy(locator = "acct.btn.notifConf")
	private QAFWebElement acctBtnNotifConf;

	@FindBy(locator = "acct.btn.allowSubstitution")
	private QAFWebElement acctBtnAllowSubstitution;

	@FindBy(locator = "acct.box.errorMsg")
	private QAFWebElement acctBoxErrorMsg;

	@FindBy(locator = "acct.box.successMsg")
	private QAFWebElement acctBoxSuccessMsg;

	

	

	@FindBy(locator = "acct.txt.addr1")
	private QAFWebElement acctTxtAddr1;

	@FindBy(locator = "acct.txt.city")
	private QAFWebElement acctTxtCity;

	@FindBy(locator = "acct.sel.state")
	private QAFWebElement acctSelState;

	@FindBy(locator = "acct.txt.zipcode")
	private QAFWebElement acctTxtZipcode;
	
	@FindBy(locator = "acct.txt.errmsgpasslesslength")
	private QAFWebElement accttxterrmsgpasslesslength;
	
	@FindBy(locator = "acct.txt.errmsgpassidentical")
	private QAFWebElement accttxterrmsgpassidentical;
	
	@FindBy(locator = "acct.txt.errmsgpassnonalpha")
	private QAFWebElement accttxterrmsgpassnonalpha;
	
	@FindBy(locator = "acct.txt.userName")
	private QAFWebElement ckconTxtUserName;

	/**
	 * Text displaying User Name
	 */
	public QAFWebElement getCkconTxtUserName(){ return ckconTxtUserName; }
	/**
	 * Error Message Change Password
	 */
	public QAFWebElement getAccttxterrmsgpasslesslength() {
		return accttxterrmsgpasslesslength;
	}

	public QAFWebElement getAccttxterrmsgpassidentical() {
		return accttxterrmsgpassidentical;
	}

	public QAFWebElement getAccttxterrmsgpassnonalpha() {
		return accttxterrmsgpassnonalpha;
	}

	/**
	 * Page load item
	 */
	public QAFWebElement getAcctPageLoadItem(){ return acctPageLoadItem; }

	/**
	 * Tab for user profile
	 */
	public QAFWebElement getAcctTabProfile(){ return acctTabProfile; }

	/**
	 * Tab to change passwords
	 */
	public QAFWebElement getAcctTabPassword(){ return acctTabPassword; }

	/**
	 * Tab to change notifications
	 */
	public QAFWebElement getAcctTabNotifications(){ return acctTabNotifications; }

	/**
	 * Tab to change to order history
	 */
	public QAFWebElement getAcctTabHistory(){ return acctTabHistory; }

	/**
	 * Tab to change to substitutions preferences
	 */
	public QAFWebElement getAcctTabSubstitutions(){ return acctTabSubstitutions; }

	/**
	 * Tab to change to saved lists
	 */
	public QAFWebElement getAcctTabLists(){ return acctTabLists; }

	/**
	 * Tab to change to credits page
	 */
	public QAFWebElement getAcctTabCredits(){ return acctTabCredits; }

	/**
	 * Edit box for old password
	 */
	public QAFWebElement getAcctEdtOldPass(){ return acctEdtOldPass; }

	/**
	 * Edit box for new password
	 */
	public QAFWebElement getAcctEdtNewPass(){ return acctEdtNewPass; }

	/**
	 * Edit box for new password
	 */
	public QAFWebElement getAcctEdtNewPassConf(){ return acctEdtNewPassConf; }

	/**
	 * Confirm new password button
	 */
	public QAFWebElement getAcctBtnConfPass(){ return acctBtnConfPass; }

	/**
	 * Confirmation of password change
	 */
	public QAFWebElement getAcctTxtPassChangeSuccess(){ return acctTxtPassChangeSuccess; }

	/**
	 * Switchbox to activate email notifications
	 */
	public QAFWebElement getAcctBtnEmailNotifications(){ return acctBtnEmailNotifications; }

	/**
	 * Button to confirm changes to email notifications
	 */
	public QAFWebElement getAcctBtnNotifConf(){ return acctBtnNotifConf; }

	/**
	 * Button to allow substitutions
	 */
	public QAFWebElement getAcctBtnAllowSubstitution(){ return acctBtnAllowSubstitution; }

	/**
	 * Passwords do not match error box
	 */
	public QAFWebElement getAcctBoxErrorMsg(){ return acctBoxErrorMsg; }

	/**
	 * Passwords match box
	 */
	public QAFWebElement getAcctBoxSuccessMsg(){ return acctBoxSuccessMsg; }



	/**
	 * Address box one
	 */
	public QAFWebElement getAcctTxtAddr1(){ return acctTxtAddr1; }

	/**
	 * City box
	 */
	public QAFWebElement getAcctTxtCity(){ return acctTxtCity; }

	/**
	 * Select box for state
	 */
	public QAFWebElement getAcctSelState(){ return acctSelState; }

	/**
	 * Zipcode box
	 */
	public QAFWebElement getAcctTxtZipcode(){ return acctTxtZipcode; }

}