package com.automation.web.components.weeklyads;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class WeeklyAdsFromDealsPage extends QAFWebComponent {

	public WeeklyAdsFromDealsPage(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}

	@FindBy(locator = "wklyad.img.weeklyadimage")
	private QAFWebElement imgWeeklyadimage;

	@FindBy(locator = "wklyad.lbl.weeklyadtitle")
	private QAFWebElement lblWeeklyadtitle;

	@FindBy(locator = "wklyad.lbl.weeklyaditemprice")
	private QAFWebElement lblWeeklyaditemprice;

	@FindBy(locator = "wklyad.lbl.weeklyadexpirydate")
	private QAFWebElement lblWeeklyadexpirydate;

	@FindBy(locator = "wklyad.btn.weeklyadaddtolist")
	private QAFWebElement btnWeeklyadaddtolist;
	
	@FindBy(locator = "wklyad.lnk.moredetails")
	private QAFWebElement lnkMoredetails;

	public QAFWebElement getImgWeeklyadimage() {
		return imgWeeklyadimage;
	}

	public QAFWebElement getLblWeeklyadtitle() {
		return lblWeeklyadtitle;
	}

	public QAFWebElement getLblWeeklyaditemprice() {
		return lblWeeklyaditemprice;
	}

	public QAFWebElement getLblWeeklyadexpirydate() {
		return lblWeeklyadexpirydate;
	}

	public QAFWebElement getBtnWeeklyadaddtolist() {
		return btnWeeklyadaddtolist;
	}
	
	public QAFWebElement getLnkMoredetails() {
		return lnkMoredetails;
	}

}
