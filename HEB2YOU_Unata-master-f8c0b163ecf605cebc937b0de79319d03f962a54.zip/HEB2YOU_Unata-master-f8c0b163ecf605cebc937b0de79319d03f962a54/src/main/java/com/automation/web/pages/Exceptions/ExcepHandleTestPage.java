package com.automation.web.pages.Exceptions;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ExcepHandleTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "excep.lbl.continueform")
	private QAFWebElement excepLblContinueform;

	@FindBy(locator = "excep.rdb.business")
	private QAFWebElement excepRdbBusiness;

	@FindBy(locator = "excep.btn.continue")
	private QAFWebElement excepBtnContinue;

	@FindBy(locator = "excep.frame.blockcnt")
	private QAFWebElement excepFrameBlockcnt;

	/**
	 * ContentView of Continue form
	 */
	public QAFWebElement getExcepLblContinueform(){ return excepLblContinueform; }

	/**
	 * RadioButtonView of Business
	 */
	public QAFWebElement getExcepRdbBusiness(){ return excepRdbBusiness; }

	/**
	 * ButtonView of Continue
	 */
	public QAFWebElement getExcepBtnContinue(){ return excepBtnContinue; }

	/**
	 * Iframe view of blocked content
	 */
	public QAFWebElement getExcepFrameBlockcnt(){ return excepFrameBlockcnt; }

}