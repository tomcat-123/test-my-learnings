package com.automation.web.pages.cartandcheckout;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ScheduleDeliveryTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void loadPage() {
		schdldeliveryLblHeader.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}

	@FindBy(locator = "schdldelivery.lbl.header")
	private QAFWebElement schdldeliveryLblHeader;

	public QAFWebElement getschdldeliveryLblHeader() {
		return schdldeliveryLblHeader;
	}

}