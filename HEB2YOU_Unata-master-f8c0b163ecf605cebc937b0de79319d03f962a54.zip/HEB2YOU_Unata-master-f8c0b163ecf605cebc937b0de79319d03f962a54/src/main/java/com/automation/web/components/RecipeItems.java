package com.automation.web.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RecipeItems extends QAFWebComponent {

	@FindBy(locator = "recipecdp.li.lbl.recipename")
	private QAFWebElement recipecdpLblRecipename;

	public RecipeItems(String locator) {
		super(locator);
	}

	public QAFWebElement getRecipecdpLblRecipename() {
		return recipecdpLblRecipename;
	}

}
