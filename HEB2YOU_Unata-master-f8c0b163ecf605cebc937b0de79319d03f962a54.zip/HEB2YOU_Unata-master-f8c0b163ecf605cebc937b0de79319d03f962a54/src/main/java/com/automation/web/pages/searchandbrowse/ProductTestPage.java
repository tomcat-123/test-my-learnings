package com.automation.web.pages.searchandbrowse;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;

import java.util.List;

import com.automation.web.components.searchandbrowse.ProductBlocks;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ProductTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void loadPage() {
		productPageLoadItem.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}

	@FindBy(locator = "product.pageLoadItem")
	private QAFWebElement productPageLoadItem;

	@FindBy(locator = "product.txt.price")
	private QAFWebElement productTxtPrice;

	@FindBy(locator = "product.txt.unit")
	private QAFWebElement productTxtUnit;

	@FindBy(locator = "product.txt.unitPrice")
	private QAFWebElement productTxtUnitPrice;

	@FindBy(locator = "product.btn.decItem")
	private QAFWebElement productBtnDecItem;

	@FindBy(locator = "product.btn.incItem")
	private QAFWebElement productBtnIncItem;

	@FindBy(locator = "product.btn.saveForLater")
	private QAFWebElement productBtnSaveForLater;

	@FindBy(locator = "product.tab.firstSavedList")
	private QAFWebElement productTabFirstSavedList;

	@FindBy(locator = "product.edt.enterNewList")
	private QAFWebElement productEdtEnterNewList;

	@FindBy(locator = "product.btn.addNewList")
	private QAFWebElement productBtnAddNewList;

	@FindBy(locator = "product.btn.savedButton")
	private QAFWebElement productBtnSavedButton;

	@FindBy(locator = "product.img.productId")
	private QAFWebElement productImgProductId;

	@FindBy(locator = "product.txt.saveforlater")
	private List<QAFWebElement> producttxtsaveforlater;

	@FindBy(locator = "product.txt.salePageprice")
	private List<QAFWebElement> producttxtsalesprice;

	@FindBy(locator = "product.lnk.firstlist")
	private QAFWebElement productlnkfirstlist;

	@FindBy(locator = "product.txt.listPagePrice")
	private QAFWebElement producttxtlistPagePrice;

	@FindBy(locator = "product.txt.listelement")
	private List<ProductBlocks> producttxtlistelement;

	@FindBy(locator = "product.img.itemPicture")
	private QAFWebElement productimgitemPicture;

	@FindBy(locator = "product.lnk.nextpageicon")
	private QAFWebElement productlnknextpageicon;

	@FindBy(locator = "product.btn.saved")
	private QAFWebElement btnSaved;

	/**
	 * Next Page icon from Product Page
	 */
	public QAFWebElement getProductLnkNextPageIcon() {
		return productlnknextpageicon;
	}

	/**
	 * List of Element
	 */
	public List<ProductBlocks> getProductTxtListElement() {
		return producttxtlistelement;
	}

	/**
	 * Text view of List Page Price
	 */
	public QAFWebElement getProductTxtListPagePrice() {
		return producttxtlistPagePrice;
	}

	/**
	 * Link view of first result
	 */
	public QAFWebElement getProductLnkFirstList() {
		return productlnkfirstlist;
	}

	/**
	 * Text view of sales page price
	 */
	public List<QAFWebElement> getProductTxtSalesPrice() {
		return producttxtsalesprice;
	}

	/**
	 * Text view of save for later
	 */
	public List<QAFWebElement> getProductTxtSaveForLater() {
		return producttxtsaveforlater;
	}

	/**
	 * Page load item
	 */
	public QAFWebElement getProductPageLoadItem() {
		return productPageLoadItem;
	}

	/**
	 * Price of the displayed item
	 */
	public QAFWebElement getProductTxtPrice() {
		return productTxtPrice;
	}

	/**
	 * Pricing type(each, weight) of displayed item
	 */
	public QAFWebElement getProductTxtUnit() {
		return productTxtUnit;
	}

	/**
	 * Unit price of the displayed item
	 */
	public QAFWebElement getProductTxtUnitPrice() {
		return productTxtUnitPrice;
	}

	/**
	 * Button to decrement amount
	 */
	public QAFWebElement getProductBtnDecItem() {
		return productBtnDecItem;
	}

	/**
	 * Button to increment amount
	 */
	public QAFWebElement getProductBtnIncItem() {
		return productBtnIncItem;
	}

	/**
	 * Save for later button on Order Details page
	 */
	public QAFWebElement getProductBtnSaveForLater() {
		return productBtnSaveForLater;
	}

	/**
	 * First saved list
	 */
	public QAFWebElement getProductTabFirstSavedList() {
		return productTabFirstSavedList;
	}

	/**
	 * Input field for new list creation
	 */
	public QAFWebElement getProductEdtEnterNewList() {
		return productEdtEnterNewList;
	}

	/**
	 * New list adding button
	 */
	public QAFWebElement getProductBtnAddNewList() {
		return productBtnAddNewList;
	}

	/**
	 * Button containing text "saved"
	 */
	public QAFWebElement getProductBtnSavedButton() {
		return productBtnSavedButton;
	}

	/**
	 * Image containing Unata product Id for product
	 */
	public QAFWebElement getProductImgProductId() {
		return productImgProductId;
	}

	public QAFWebElement getBtnSaved() {
		return btnSaved;
	}

}