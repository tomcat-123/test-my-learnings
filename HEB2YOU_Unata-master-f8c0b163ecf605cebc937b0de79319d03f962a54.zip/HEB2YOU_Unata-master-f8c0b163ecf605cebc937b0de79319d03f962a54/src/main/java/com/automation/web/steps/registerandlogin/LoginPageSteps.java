package com.automation.web.steps.registerandlogin;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.PerfectoUtils.ReportMessage;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.homepage.HomeTestPage;
import com.automation.web.pages.homepage.LoginTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;

/*
 * List of Step Definitions in LoginPage steps  file

User enters email and password {email} {pass}
User submits Login form
Verify Login Page/Popup
User verifies error messages for invalid login
*/

public class LoginPageSteps {
	PerfectoUtils util = new PerfectoUtils();
	Actions action = new Actions(PerfectoUtils.getDriver());

	/**
	 * Login Popup
	 * 
	 */
	@QAFTestStep(description = "User enters email and password {email} {pass}")
	public void iEnterValidEmailAndPassword(String email, String password) {
		LoginTestPage loginpage = new LoginTestPage();

		loginpage.getLoginEdtEmail().waitForEnabled(MAX_WAIT_TIME * 3);
		util.enterValues(loginpage.getLoginEdtEmail(), email);
		util.enterValues(loginpage.getLoginEdtPassword(), password);
		ReportMessage("Credentials Entered: " + email + " " + password, MessageTypes.Info);
	}

	@QAFTestStep(description = "User submits Login form")
	public void userSubmitsLoginForm() {
		LoginTestPage loginpage = new LoginTestPage();
		HomeTestPage htp = new HomeTestPage();

		// Submit Login form
		PerfectoUtils.scrolltoelement(loginpage.getLoginBtnSubmit());
		//PerfectoUtils.getDriver().getKeyboard().sendKeys(Keys.ENTER);
		loginpage.getLoginBtnSubmit().click();
		loginpage.waitForPageToLoad();
		htp.getHomeBtnYourAccount().waitForPresent(MAX_WAIT_TIME * 2);
		
		if (htp.getHomeBtnYourAccount().isPresent()) {
			ReportMessage("Credentials accepted", MessageTypes.Pass);
		} else
			ReportMessage("Credentials not accepted and throwing error message", MessageTypes.Info);
	}

	@QAFTestStep(description = "Verify Login Page/Popup")
	public void verifyLoginPagePopup() {
		LoginTestPage loginpage = new LoginTestPage();

		// Login Page verifications
		ReportMessage("Login Popup Fields are...", MessageTypes.Info);
		loginpage.getLoginTabLogin().verifyPresent();
		loginpage.getLoginEdtEmail().verifyPresent();
		loginpage.getLoginEdtPassword().verifyPresent();
		loginpage.getLoginBtnSubmit().verifyPresent();
		loginpage.getLoginLnkForgotpwd().verifyPresent();
		ReportMessage("Login Popup Fields are Verified", MessageTypes.Pass);

	}

	@QAFTestStep(description = "User verifies error messages for invalid login")
	public void userVerifiesErrorMessages() {
		LoginTestPage loginpage = new LoginTestPage();
		String invalidEmail = ConfigurationManager.getBundle().getString("badUser.email");
		String password = ConfigurationManager.getBundle().getString("badUser.password");
		iEnterValidEmailAndPassword(invalidEmail, password);
		loginpage.getLoginBtnSubmit().click();
		loginpage.getLoginTxtLoginFail().verifyPresent();

		ReportMessage("Error message on Entering invalid Email or Password.", MessageTypes.Info);

		ReportMessage("Login Popup Error messages are verified", MessageTypes.Pass);

	}
	
	
	@QAFTestStep(description = "User enters invalid password")
	public void iEnterInvalidPassword() {
		LoginTestPage loginpage = new LoginTestPage();
		String password = getBundle().getString("badUser.password");
		String email = getBundle().getString("validUser.email");

	ReportMessage("Credentials Entered: " + email + " " + password);

		util.enterValues(loginpage.getLoginEdtEmail(), email);
		util.enterValues(loginpage.getLoginEdtPassword(), password);

		util.pass("Credentials not accepted");
	}

}
