package com.automation.web.pages.homepage;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class HomeTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}

	public synchronized void loadPage(){
		homePageLoadItem.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}

	@FindBy(locator = "home.pageLoadItem")
	private QAFWebElement homePageLoadItem;

	@FindBy(locator = "home.lbl.login")
	private QAFWebElement homeLblLogin;

	@FindBy(locator = "home.img.heblogo")
	private QAFWebElement homeImgHeblogo;

	@FindBy(locator = "home.logo")
	private QAFWebElement homeLogo;

	@FindBy(locator = "home.edt.searchtext")
	private QAFWebElement homeEdtSearchtext;

	@FindBy(locator = "home.btn.yourAccount")
	private QAFWebElement homeBtnYourAccount;

	@FindBy(locator = "home.tab.yourAccountBox")
	private QAFWebElement homeTabYourAccountBox;

	@FindBy(locator = "home.lnk.myProfile")
	private QAFWebElement homeLnkMyProfile;

	@FindBy(locator = "home.lnk.logout")
	private QAFWebElement homeLnkLogout;

	@FindBy(locator = "home.get.showItems")
	private QAFWebElement homeGetShowItems;

	@FindBy(locator = "home.get.itemByTitle")
	private QAFWebElement homeGetItemByTitle;

	@FindBy(locator = "home.txt.curbOrDelVal")
	private QAFWebElement homeTxtCurbOrDelVal;

	@FindBy(locator = "home.txt.curCurbDisplay")
	private QAFWebElement homeTxtCurCurbDisplay;

	@FindBy(locator = "home.txt.curDelDisplay")
	private QAFWebElement homeTxtCurDelDisplay;

	@FindBy(locator = "home.hdr.timeslot")
	private QAFWebElement homeHdrTimeslot;

	@FindBy(locator = "home.hdr.reserveTSBox")
	private QAFWebElement homeHdrReserveTSBox;

	@FindBy(locator = "home.txt.reservedTime")
	private QAFWebElement homeTxtReservedTime;

	@FindBy(locator = "home.box.timeslotSelector")
	private QAFWebElement homeBoxTimeslotSelector;

	@FindBy(locator = "home.box.curbDelSelector")
	private QAFWebElement homeBoxCurbDelSelector;

	@FindBy(locator = "home.box.loginBox")
	private QAFWebElement homeBoxLoginBox;

	@FindBy(locator = "home.button.mainCheckoutPrice")
	private QAFWebElement homeButtonMainCheckoutPrice;

	@FindBy(locator = "home.lnk.quickOrderHis")
	private QAFWebElement homeLnkQuickOrderHis;

	@FindBy(locator = "home.lnk.quickSFLL")
	private QAFWebElement homeLnkQuickSFLL;
	

	@FindBy(locator = "home.lnk.seemorewaytoshop")
	private QAFWebElement lnkSeemorewaytoshop;
	
	@FindBy(locator = "home.btn.toHome")
	private QAFWebElement navBtnToHome;
	
	@FindBy(locator = "home.lbl.itemqty")
	private QAFWebElement homeLblItemQty;
	
	@FindBy(locator = "home.lis.itemamount")
	private List<QAFWebElement> homeListItemAmount;
	
	@FindBy(locator = "home.lis.viewdetails")
	private List<QAFWebElement> homeListViewDetails; 
	
	@FindBy(locator = "home.lis.newitemamount")
	private List<QAFWebElement> homeListNewItemAmount; 
	
	@FindBy(locator = "home.btn.bannerclose")
	private List<QAFWebElement> homebtnbannerclose;
	
	@FindBy(locator = "home.txt.shopbyaisle")
	private QAFWebElement hometxtshopbyaisle;
	
	
	@FindBy(locator = "home.contextselect.closebutton")
	private QAFWebElement contextSelectorCloseButton;
	
	@FindBy(locator = "home.lst.banner")
	private List<QAFWebElement> homeListBanner; 
	
	public List<QAFWebElement> getHomeListBanner() {
		return homeListBanner;
	}
	
	public QAFWebElement getContextSelectorCloseButton() {
		return contextSelectorCloseButton;
	}

	public void setContextSelectorCloseButton(QAFWebElement contextSelectorCloseButton) {
		this.contextSelectorCloseButton = contextSelectorCloseButton;
	}
	
	/**
	 * Text view for Shop By Aisl 
	 */
	public QAFWebElement getHomeTxtShopByAisle(){ return hometxtshopbyaisle; }
	
	/**
	 * Button to close banner from HomePage
	 */
	public List<QAFWebElement> getHomeBtnBannerClose(){ return homebtnbannerclose; }
		
	/**
	 * Button to navigate home
	 */
	public QAFWebElement getNavBtnToHome(){ return navBtnToHome; }

	public QAFWebElement getHomeGetShowItems() {
		return homeGetShowItems;
	}

	public QAFWebElement getHomeGetItemByTitle() {
		return homeGetItemByTitle;
	}

	public QAFWebElement getLnkSeemorewaytoshop() {
		return lnkSeemorewaytoshop;
	}

	/**
	 * Main load item for the page
	 */
	public QAFWebElement getHomePageLoadItem(){ return homePageLoadItem; }

	/**
	 * Textview for LogIn Link
	 */
	public QAFWebElement getHomeLblLogin(){ return homeLblLogin; }

	/**
	 * ImageView for main Logo
	 */
	public QAFWebElement getHomeImgHeblogo(){ return homeImgHeblogo; }

	/**
	 * H-E-B logo
	 */
	public QAFWebElement getHomeLogo(){ return homeLogo; }

	/**
	 * Editview for searchText
	 */
	public QAFWebElement getHomeEdtSearchtext(){ return homeEdtSearchtext; }

	/**
	 * Tab to display user account options
	 */
	public QAFWebElement getHomeBtnYourAccount(){ return homeBtnYourAccount; }

	/**
	 * Box containing user options
	 */
	public QAFWebElement getHomeTabYourAccountBox(){ return homeTabYourAccountBox; }

	/**
	 * Link to user's profile
	 */
	public QAFWebElement getHomeLnkMyProfile(){ return homeLnkMyProfile; }

	/**
	 * Link to logout
	 */
	public QAFWebElement getHomeLnkLogout(){ return homeLnkLogout; }

	/**
	 * Link to logoutGrabs the current sponsored show items on homepage
	 */
	public QAFWebElement getHomeGetShowItems(String item){ 
		String retElm = String.format(pageProps.getString("home.get.showItems"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Finds item by a set title.
	 */
	public QAFWebElement getHomeGetItemByTitle(String item){ 
		String retElm = String.format(pageProps.getString("home.get.itemByTitle"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Displays whether fulfillment is curbside or delivery
	 */
	public QAFWebElement getHomeTxtCurbOrDelVal(){ return homeTxtCurbOrDelVal; }

	/**
	 * Text displaying current store for curbside
	 */
	public QAFWebElement getHomeTxtCurCurbDisplay(){ return homeTxtCurCurbDisplay; }

	/**
	 * Text for displaying current store for delivery
	 */
	public QAFWebElement getHomeTxtCurDelDisplay(){ return homeTxtCurDelDisplay; }

	/**
	 * Reserve a timeslot option
	 */
	public QAFWebElement getHomeHdrTimeslot(){ return homeHdrTimeslot; }

	/**
	 * Header displaying "Curbside Pickup"
	 */
	public QAFWebElement getHomeHdrReserveTSBox(){ return homeHdrReserveTSBox; }

	/**
	 * Timeslot that has been reserved for pickup
	 */
	public QAFWebElement getHomeTxtReservedTime(){ return homeTxtReservedTime; }

	/**
	 * Box containing timeslots
	 */
	public QAFWebElement getHomeBoxTimeslotSelector(){ return homeBoxTimeslotSelector; }

	/**
	 * Box containing curbside, store, timeslot options
	 */
	public QAFWebElement getHomeBoxCurbDelSelector(){ return homeBoxCurbDelSelector; }

	/**
	 * Box containing login information
	 */
	public QAFWebElement getHomeBoxLoginBox(){ return homeBoxLoginBox; }

	/**
	 * Price displayed on main checkout
	 */
	public QAFWebElement getHomeButtonMainCheckoutPrice(){ return homeButtonMainCheckoutPrice; }

	/**
	 * Quick link to Order History
	 */
	public QAFWebElement getHomeLnkQuickOrderHis(){ return homeLnkQuickOrderHis; }

	/**
	 * Quick link to Save For Later Lists
	 */
	public QAFWebElement getHomeLnkQuickSFLL(){ return homeLnkQuickSFLL; }
	
	public QAFWebElement getHomeLblItemQty(){ return homeLblItemQty; }  

	public List<QAFWebElement> getHomeListItemAmount(){ return homeListItemAmount; }
	
	public List<QAFWebElement> getHomeListViewDetails(){ return homeListViewDetails; }
	
	public List<QAFWebElement> getHomeListNewItemAmount(){ return homeListNewItemAmount; }
}