package com.automation.web.commonutils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FunctionUtils {
	
	
	// Bundle key constants
		// Note: Current unique item count will be appended to name and qty
		// 		 to keep keys unique
		public static final String CART_UNIQUE_ITEM_CNT_KEY = "uniqueItemCount";
		public static final String CUR_STORE_NAME_KEY = "Current_Store";
		public static final String CUR_STORE_NUMBER_KEY = "Current_Store_Num";
		public static final String FULFILLMENT_TYPE_KEY = "Fulfilment_Type";
		public static final String CURBSIDE_SET = "Curbside Pickup";
		public static final String DELIVERY_SET = "Delivery";
		public static final String ITEM_ID_KEY = "Item_Id";
		public static final String UAT_ITEM_ID_KEY = "uat_item_id";
		public static final String TIME_BEGIN_KEY = "TS_Begin_Key";
		public static final String TIME_END_KEY = "TS_End_Key";
		public static final String TIME_DATE_KEY = "TS_Date_Key";
		public static final String SUBTOTAL_KEY = "Subtotal_Amt";
		public static final String PICK_FEE_KEY = "Pick_Fee_Key";
		public static final String SAVED_TAX_KEY = "Tax_Amount_Saved";
		public static final String CUR_CHOOSEN_STORE_NAME_KEY = "Choosen_Store";
		
		// Keys pertaining to the hub
		public static final String AVG_WEIGHT_KEY = "averageWeight";
		public static final String MIN_ORDER_KEY = "minOrderValue";
		public static final String MAX_ORDER_KEY = "maxOrderValue";
		public static final String IS_TAXABLE_KEY = "isTaxable";
		public static final String CONSM_PRCH_CD_KEY = "consmPrchChcCd";
		public static final String GLUTEN_FREE_KEY = "GFV";
		public static final String ORGANIC_KEY = "O95";
		public static final String LIST_PRICE_KEY = "listPrice";
		public static final String SALE_PRICE_KEY = "salePrice";
		public static final String TAX_PERCENTAGE_KEY = "taxPercentage";
		public static final String ON_SALE_KEY = "onSale";
		public static final String IS_DEAL_KEY = "isDeal";
		public static final String SALE_WT_SW_KEY = "saleWeightSw";

	/**
	 * Currently, the meta data and the item name do not match. This method will
	 * grab the image attribute from an item's picture, parse the string, and return the
	 * unique item ID. That will be able to be compared across places such as in the item
	 * cart or in the final checkout cart
	 * <p>
	 * Note: Regex will match the following pattern, brought in from the attribute "style" 
	 * in the xpath</p>
	 * <p><code>background-image: url("https://s7d5.scene7.com/is/image/HEBGrocery/android-large/000320625.jpg");</code>
	 * <p>In this instance, "000320625" will be grabbed and returned. The leading zeroes are not necessary for
	 * the API Hub call, but they don't hurt either, so they are not dropped
	 * @param imgUrl URL to be parsed
	 * @return ID of the item as a String
	 */
	public String generateItemID(String imgUrl){
		String regex = "^.*/(.*)\\.jpg.*$";
		
		Pattern idPattern = Pattern.compile(regex);
		Matcher idMatch = idPattern.matcher(imgUrl);
		if(idMatch.matches())
			return idMatch.group(1);
		else
			return null;
	}
	
	/**
	 * On the order history page, will take the header stating 
	 * "Order # someNumber" and will return the order number after 
	 * the hashtag
	 * @param orderHistory Full text to parse
	 * @return Number at the end of the string
	 */
	public String generateOrderNumber(String orderHistory){
		String regex = "^.*\\s(\\d+)$";
		// Will match "Order # 123456 and keep 123456
		Pattern findNumber = Pattern.compile(regex);
		Matcher numMatch = findNumber.matcher(orderHistory);
		if(numMatch.find()){
			return numMatch.group(1);
		} else {
			return null;
		}
	}
	

	/**
	 * Generates the store ID number once a store has been searched. Currently, store numbers
	 * are stored in the button ID on the map page for store selection, after choosing
	 * the Curbside option
	 * <p>
	 * Regex will match the following: 
	 * <p><code>"shopping-selector-update-home-store-305-pickup"</code></p>
	 * <p>In this instance, "305" will be grabbed and returned 
	 *
	 * @param buttonID Id of the button to grab the store number. 
	 * @return Number of the store
	 */
	public String generateStoreNum(String buttonID){
		String regex = "^.*-(.*)-[a-zA-Z]+$";
		
		Pattern idPattern = Pattern.compile(regex);
		Matcher idMatch = idPattern.matcher(buttonID);
		if(idMatch.matches()){
			return idMatch.group(1);
		}
		else{
			return null;
		}
	}

	/**
	 * Generates the unata product id for the given URL.
	 * <p>
	 * Regex will match the following: 
	 * <p><code>"https://dashboard-heb-uat.unata.com/#/products/8748/info"</code></p>
	 * <p>In this instance, "8748" will be grabbed and returned 
	 *
	 * @param prodUrl of the product to grab
	 * @return Unata item id
	 */
	public String genUnataItemID(String prodUrl){
		String regex = "^.*/(.*)/info$";
		
		Pattern idPattern = Pattern.compile(regex);
		Matcher idMatch = idPattern.matcher(prodUrl);
		if(idMatch.matches()){
			return idMatch.group(1);
		}
		else{
			return null;
		}
	}
}
