package com.automation.web.steps.ordercomplete;

import static com.automation.web.commonutils.PerfectoUtils.ReportMessage;
import static com.automation.web.commonutils.PerfectoUtils.getDriver;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.cartandcheckout.OrderCompleteTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;

/**
 * Note about credit cards: All population relies on the credit card data beans.
 * Any changes for how they are populated needs to happen in the bean
 *
 */
public class OrderCompleteSteps {
	PerfectoUtils util = new PerfectoUtils();
	Actions act = new Actions(getDriver());

	@QAFTestStep(description = "Verify order details in order complete page")
	public void verifyOrderDetailsInOrderCompletePage() {
		OrderCompleteTestPage ordercom = new OrderCompleteTestPage();

		ordercom.getTxtStorename().waitForPresent(5000);
		String strName = ordercom.getTxtStorename().getText();
		
		System.out.println(strName + "  " +getBundle().getString("defaultStore.name"));

		if (strName.equalsIgnoreCase(getBundle().getString("defaultStore.name"))) {
			ReportMessage("Stor Name matecs in Order Complete Page", MessageTypes.Pass);
		} else {
			ReportMessage("Stor Name not matecs in Order Complete Page", MessageTypes.Fail);
		}

		String pickupTime = ordercom.getTxtPickUpTime().getText();

		if (pickupTime.contains(getBundle().getString("CurentDate"))) {
			ReportMessage("CurentDate matecs in Order Complete Page", MessageTypes.Pass);
		} else {
			ReportMessage("CurentDate not matecs in Order Complete Page", MessageTypes.Fail);
		}
		
	}
	
	@QAFTestStep(description = "Verify order details link navigates to order history")
	public void VerifyOrderDetailsLinkNavigatesToOrderHistory() {
		OrderCompleteTestPage ordercom = new OrderCompleteTestPage();

		ordercom.getLnkOrderDetails().waitForPresent(50000);
		ordercom.getLnkOrderDetails().click();
		ordercom.getTxtorderdetHeaerd().waitForPresent(50000);
		ordercom.getTxtorderdetHeaerd().verifyPresent();
	}
	
	@QAFTestStep(description = "Verify order number in orde complete")
	public void verifyOrderNumberInOrdeComplete() {
		OrderCompleteTestPage ordercom = new OrderCompleteTestPage();

		ordercom.getLnkOrderDetails().waitForPresent(50000);
		String orderNum = ordercom.getTxtordernumber().getText();
		String OrderNum1 = orderNum.replace("Order # ","");
		getBundle().setProperty("OrderNum",OrderNum1);
		System.out.println(OrderNum1);
	}
		
}
