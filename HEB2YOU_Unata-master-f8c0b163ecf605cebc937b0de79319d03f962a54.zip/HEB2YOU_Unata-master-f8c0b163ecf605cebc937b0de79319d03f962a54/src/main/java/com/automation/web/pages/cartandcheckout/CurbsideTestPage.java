package com.automation.web.pages.cartandcheckout;

import static com.automation.web.commonutils.PerfectoUtils.MAX_WAIT_TIME;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CurbsideTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}

	public synchronized void loadPage(){
		curbPageLoadItem.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}

	@FindBy(locator = "curb.pageLoadItem")
	private QAFWebElement curbPageLoadItem;

	@FindBy(locator = "curb.btn.hdrChooseCurb")
	private QAFWebElement curbBtnHdrChooseCurb;

	@FindBy(locator = "curb.hdr.selectorService")
	private QAFWebElement curbHdrSelectorService;

	@FindBy(locator = "curb.btn.closeBtn")
	private QAFWebElement cartBtnCloseBtn;

	@FindBy(locator = "curb.lbl.header")
	private QAFWebElement curbLblHeader;

	@FindBy(locator = "curb.btn.changeCurb")
	private QAFWebElement curbBtnChangeCurb;

	@FindBy(locator = "curb.btn.get.mapStoreSel")
	private QAFWebElement curbBtnGetMapStoreSel;

	@FindBy(locator = "curb.hdr.curbOrDelvHdr")
	private QAFWebElement curbHdrCurbOrDelvHdr;

	@FindBy(locator = "curb.btn.selectCurb")
	private QAFWebElement curbBtnSelectCurb;

	@FindBy(locator = "curb.btn.selectDelivery")
	private QAFWebElement curbBtnSelectDelivery;

	@FindBy(locator = "curb.edt.enterZip")
	private QAFWebElement curbEdtEnterZip;

	@FindBy(locator = "curb.get.selectedStoreName")
	private QAFWebElement curbGetSelectedStoreName;

	@FindBy(locator = "curb.txt.delOrCurbHeader")
	private QAFWebElement curbTxtDelOrCurbHeader;

	@FindBy(locator = "curb.btn.chooseStoreMain")
	private QAFWebElement curbBtnChooseStoreMain;

	@FindBy(locator = "curb.box.mapBox")
	private QAFWebElement curbBoxMapBox;

	@FindBy(locator = "curb.hdr.timeSlotHeader")
	private QAFWebElement curbHdrTimeSlotHeader;

	@FindBy(locator = "curb.hdr.reserveTime")
	private QAFWebElement curbHdrReserveTime;

	@FindBy(locator = "curb.txt.currentMonth")
	private QAFWebElement curbTxtCurrentMonth;

	@FindBy(locator = "curb.get.dayOfWeek")
	private QAFWebElement curbGetDayOfWeek;

	@FindBy(locator = "curb.get.dayOfMonth")
	private QAFWebElement curbGetDayOfMonth;

	@FindBy(locator = "curb.btn.weekDecrement")
	private QAFWebElement curbBtnWeekDecrement;

	@FindBy(locator = "curb.btn.weekIncrement")
	private QAFWebElement curbBtnWeekIncrement;

	@FindBy(locator = "curb.lnk.selectLater")
	private QAFWebElement curbLnkSelectLater;

	@FindBy(locator = "curb.lnk.justBrowsing")
	private QAFWebElement curbLnkJustBrowsing;

	@FindBy(locator = "curb.get.txt.startTime")
	private QAFWebElement curbGetTxtStartTime;

	@FindBy(locator = "curb.get.txt.endTime")
	private QAFWebElement curbGetTxtEndTime;

	@FindBy(locator = "curb.get.txt.pickFee")
	private QAFWebElement curbGetTxtPickFee;

	@FindBy(locator = "curb.get.selectTime")
	private QAFWebElement curbGetSelectTime;

	@FindBy(locator = "curb.hdr.mapLoadItem")
	private QAFWebElement curbHdrMapLoadItem;
	
	@FindBy(locator = "curb.edt.enterzipcode")
	private QAFWebElement curbedtenterzipcode;
		
	@FindBy(locator = "curb.btn.submit")
	private QAFWebElement curbbtnsubmit;
	
	@FindBy(locator = "curb.lnk.chagefromwindow")
	private QAFWebElement curblnkchagefromwindow;
	
	@FindBy(locator = "curb.txt.storefromwndow")
	private List<QAFWebElement> curbtxtstorefromwndow;
	
	@FindBy(locator = "curb.lbl.enterdeliveryzip")
	private QAFWebElement curblblEnterDeliveryZip;
	
	/**
	 * List of Stores from Curbside Window
	 */
	public List<QAFWebElement> getCurbTxtStoreFromwndow(){ return curbtxtstorefromwndow; }
	
	/**
	 * Change Link from curpside window
	 */
	public QAFWebElement getCurbLnkChageFromWindow(){ return curblnkchagefromwindow; }
	
	/**
	 * Submit button
	 */
	public QAFWebElement getCurbBtnSubmit(){ return curbbtnsubmit; }

	/**
	 * Edit text for ZIP code
	 */
	public QAFWebElement getCurbEdtEnterZipcode(){ return curbedtenterzipcode; }
	
	/**
	 * Load item for curbside
	 */
	public QAFWebElement getCurbPageLoadItem(){ return curbPageLoadItem; }

	/**
	 * Button to choose curbside or delivery, found in top bar
	 */
	public QAFWebElement getCurbBtnHdrChooseCurb(){ return curbBtnHdrChooseCurb; }

	/**
	 * Selector for cubside or delivery
	 */
	public QAFWebElement getCurbHdrSelectorService(){ return curbHdrSelectorService; }

	/**
	 * Close button for selector service
	 */
	public QAFWebElement getCartBtnCloseBtn(){ return cartBtnCloseBtn; }

	/**
	 * Red bar header for curbside
	 */
	public QAFWebElement getCurbLblHeader(){ return curbLblHeader; }

	/**
	 * Chooses between curbside and delivery
	 */
	public QAFWebElement getCurbBtnChangeCurb(){ return curbBtnChangeCurb; }

	/**
	 * Select button on map page of stores
	 */
	public QAFWebElement getCurbBtnGetMapStoreSel(String item){ 
		String retElm = String.format(pageProps.getString("curb.btn.get.mapStoreSel"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Loading header for choosing between curbside or delivery
	 */
	public QAFWebElement getCurbHdrCurbOrDelvHdr(){ return curbHdrCurbOrDelvHdr; }

	/**
	 * Selects curbside option
	 */
	public QAFWebElement getCurbBtnSelectCurb(){ return curbBtnSelectCurb; }

	/**
	 * Selects delivery option
	 */
	public QAFWebElement getCurbBtnSelectDelivery(){ return curbBtnSelectDelivery; }

	/**
	 * Enter zipcode for store select
	 */
	public QAFWebElement getCurbEdtEnterZip(){ return curbEdtEnterZip; }

	/**
	 * Text containing name of selected store
	 */
	public QAFWebElement getCurbGetSelectedStoreName(String item){ 
		String retElm = String.format(pageProps.getString("curb.get.selectedStoreName"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Display text before store name, showing curbside or delivery
	 */
	public QAFWebElement getCurbTxtDelOrCurbHeader(){ return curbTxtDelOrCurbHeader; }

	/**
	 * Chooses store from main curbside window
	 */
	public QAFWebElement getCurbBtnChooseStoreMain(){ return curbBtnChooseStoreMain; }

	/**
	 * Box containing map and store items
	 */
	public QAFWebElement getCurbBoxMapBox(){ return curbBoxMapBox; }

	/**
	 * Header for curbside when choosing a timeslot for pick up
	 */
	public QAFWebElement getCurbHdrTimeSlotHeader(){ return curbHdrTimeSlotHeader; }

	/**
	 * Button to reserve time
	 */
	public QAFWebElement getCurbHdrReserveTime(){ return curbHdrReserveTime; }

	/**
	 * Month for delivery
	 */
	public QAFWebElement getCurbTxtCurrentMonth(){ return curbTxtCurrentMonth; }

	/**
	 * List containing day of week. First two options are 'today' and 'tomorrow', followed by M-F format
	 */
	public QAFWebElement getCurbGetDayOfWeek(String item){ 
		String retElm = String.format(pageProps.getString("curb.get.dayOfWeek"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * List containing day of month in calendar day fashion
	 */
	public QAFWebElement getCurbGetDayOfMonth(String item){ 
		String retElm = String.format(pageProps.getString("curb.get.dayOfMonth"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Button to navigate to previous week
	 */
	public QAFWebElement getCurbBtnWeekDecrement(){ return curbBtnWeekDecrement; }

	/**
	 * Button to navigate to following week
	 */
	public QAFWebElement getCurbBtnWeekIncrement(){ return curbBtnWeekIncrement; }

	/**
	 * Link to navigate back to curbside window
	 */
	public QAFWebElement getCurbLnkSelectLater(){ return curbLnkSelectLater; }

	/**
	 * Button to navigate back to homepage
	 */
	public QAFWebElement getCurbLnkJustBrowsing(){ return curbLnkJustBrowsing; }

	/**
	 * List of start times
	 */
	public QAFWebElement getCurbGetTxtStartTime(String item){ 
		String retElm = String.format(pageProps.getString("curb.get.txt.startTime"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * List of end times
	 */
	public QAFWebElement getCurbGetTxtEndTime(String item){ 
		String retElm = String.format(pageProps.getString("curb.get.txt.endTime"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Price for picking items
	 */
	public QAFWebElement getCurbGetTxtPickFee(String item){ 
		String retElm = String.format(pageProps.getString("curb.get.txt.pickFee"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Button to pick time slot
	 */
	public QAFWebElement getCurbGetSelectTime(String item){ 
		String retElm = String.format(pageProps.getString("curb.get.selectTime"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Loading item for the store selection screen
	 */
	public QAFWebElement getCurbHdrMapLoadItem(){ return curbHdrMapLoadItem; }
	
	/**
	 * Label Enter your Delivery Zip on Home Delivery
	 */
	public QAFWebElement getCurbLblEnterDeliveryZip(){ return curblblEnterDeliveryZip; }

}