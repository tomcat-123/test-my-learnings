package com.automation.web.pages.unatadashboardsite;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class DashboardTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void loadPage() {
		// dashPageLoadItem.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}

	@FindBy(locator = "dash.pageLoadItem")
	private QAFWebElement dashPageLoadItem;

	@FindBy(locator = "dash.igm.loginLogo")
	private QAFWebElement dashIgmLoginLogo;

	@FindBy(locator = "dash.login.email")
	private QAFWebElement dashLoginEmail;

	@FindBy(locator = "dash.login.password")
	private QAFWebElement dashLoginPassword;

	@FindBy(locator = "dash.btn.login")
	private QAFWebElement dashBtnLogin;

	@FindBy(locator = "dash.img.mainLogo")
	private QAFWebElement dashImgMainLogo;

	@FindBy(locator = "dash.dd.support")
	private QAFWebElement dashDdSupport;

	@FindBy(locator = "dash.hdr.productLookup")
	private QAFWebElement dashHdrProductLookup;

	@FindBy(locator = "dash.edt.searchBar")
	private QAFWebElement dashEdtSearchBar;

	@FindBy(locator = "dash.hdr.mainHdr")
	private QAFWebElement dashHdrMainHdr;

	@FindBy(locator = "dash.tab.pricing")
	private QAFWebElement dashTabPricing;

	@FindBy(locator = "dash.edt.filterBar")
	private QAFWebElement dashEdtFilterBar;

	@FindBy(locator = "dash.lnk.support")
	private QAFWebElement dashLnkSupport;

	@FindBy(locator = "dash.edt.searchtextbox")
	private QAFWebElement dashedtsearchtextbox;

	@FindBy(locator = "dash.lnk.ordermangement")
	private QAFWebElement dashlnkordermangement;

	@FindBy(locator = "dash.btn.search")
	private QAFWebElement dashbtnsearch;

	@FindBy(locator = "dash.txt.ordernumber")
	private QAFWebElement dashtxtordernumber;

	@FindBy(locator = "dash.lnk.store")
	private QAFWebElement dashlnkstore;

	@FindBy(locator = "dash.txt.storename")
	private QAFWebElement dashtxtstorename;

	@FindBy(locator = "dash.dd.supportdd")
	private List<QAFWebElement> dashddsupportdd;

	@FindBy(locator = "dash.txt.producttitle")
	private QAFWebElement dashtxtproducttitle;

	@FindBy(locator = "dash.li.rowpath")
	private List<QAFWebElement> liRowpath;

	/**
	 * Load item for the login page
	 */
	public QAFWebElement getDashPageLoadItem() {
		return dashPageLoadItem;
	}

	/**
	 * Text view of Product title
	 */
	public QAFWebElement getDashTxtProductTitle() {
		return dashtxtproducttitle;
	}

	/**
	 * Unata logo at login
	 */
	public QAFWebElement getDashIgmLoginLogo() {
		return dashIgmLoginLogo;
	}

	/**
	 * Login on homepage for dashboard
	 */
	public QAFWebElement getDashLoginEmail() {
		return dashLoginEmail;
	}

	/**
	 * Password on homepage for dashboard
	 */
	public QAFWebElement getDashLoginPassword() {
		return dashLoginPassword;
	}

	/**
	 * Login button on homepage
	 */
	public QAFWebElement getDashBtnLogin() {
		return dashBtnLogin;
	}

	/**
	 * Main logo for Unata on products page
	 */
	public QAFWebElement getDashImgMainLogo() {
		return dashImgMainLogo;
	}

	/**
	 * Drop down for support menu
	 */
	public QAFWebElement getDashDdSupport() {
		return dashDdSupport;
	}

	/**
	 * Header for the product search page
	 */
	public QAFWebElement getDashHdrProductLookup() {
		return dashHdrProductLookup;
	}

	/**
	 * Search bar for product search
	 */
	public QAFWebElement getDashEdtSearchBar() {
		return dashEdtSearchBar;
	}

	/**
	 * Product title header
	 */
	public QAFWebElement getDashHdrMainHdr() {
		return dashHdrMainHdr;
	}

	/**
	 * Pricing tab
	 */
	public QAFWebElement getDashTabPricing() {
		return dashTabPricing;
	}

	/**
	 * Input for filtering items
	 */
	public QAFWebElement getDashEdtFilterBar() {
		return dashEdtFilterBar;
	}

	/**
	 * Link View of support
	 */
	public QAFWebElement getLnkSupport() {
		return dashLnkSupport;
	}

	/**
	 * Edit View of search Text Box
	 */
	public QAFWebElement getEdtSearchBox() {
		return dashedtsearchtextbox;
	}

	/**
	 * Link View of Order Managemant
	 */
	public QAFWebElement getLnkOrderMangement() {
		return dashlnkordermangement;
	}

	/**
	 * Button view for search
	 */
	public QAFWebElement getBtnSearch() {
		return dashbtnsearch;
	}

	/**
	 * Text View of Order Number
	 */
	public QAFWebElement getTxtOrderNumber() {
		return dashtxtordernumber;
	}

	/**
	 * Link view of store Number from order details
	 */
	public QAFWebElement getLnkStore() {
		return dashlnkstore;
	}

	/**
	 * Text view of store Name
	 */
	public QAFWebElement getTxtStoreName() {
		return dashtxtstorename;
	}

	/**
	 * Text view of support drop down
	 */
	public List<QAFWebElement> getDashDdSupportDd() {
		return dashddsupportdd;
	}

	/**
	 * dynamic value of SKU ID
	 */
	public QAFWebElement getDashLnkSkuSearchResult(String item) {
		String retElm = String.format(pageProps.getString("dash.lnk.skusearchresult"), item);
		return new QAFExtendedWebElement(retElm);
	}

	public List<QAFWebElement> getLiRowpath() {
		return liRowpath;
	}
}