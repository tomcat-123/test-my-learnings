package com.automation.web.databean;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.useraccountactions.AccountTestPages;
import com.qmetry.qaf.automation.data.BaseFormDataBean;
import com.qmetry.qaf.automation.ui.annotations.UiElement;

public class EditBillingInfoBean extends BaseFormDataBean{
	
	@UiElement(fieldLoc = "acct.txt.addr1", order = 1)
	private String address;

	@UiElement(fieldLoc = "acct.txt.city", order = 2)
	private String city;
	
	@UiElement(fieldLoc = "acct.txt.zipcode", order = 3)
	private String zipcode;
	
	
	
	@Override
	public void fillRandomData() { 
		PerfectoUtils select = new PerfectoUtils();
		AccountTestPages account = new AccountTestPages();
		this.city = getBundle().getString("hotuser1.user.city");
		this.zipcode = getBundle().getString("hotuser1.user.zipcode");
		this.address = getBundle().getString("hotuser1.user.address1");
		select.selectBoxSelection(account.getAcctSelState(), getBundle().getString("hotuser1.user.state"));
		super.fillRandomData();
	}
}
