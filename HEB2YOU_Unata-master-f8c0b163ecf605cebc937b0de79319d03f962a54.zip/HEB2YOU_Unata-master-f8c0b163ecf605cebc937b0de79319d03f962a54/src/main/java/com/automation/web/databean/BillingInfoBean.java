package com.automation.web.databean;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.pages.cartandcheckout.PayTestPage;
import com.qmetry.qaf.automation.data.BaseFormDataBean;
import com.qmetry.qaf.automation.ui.annotations.UiElement;

/**
 * Data bean to fill credit card information. Will be populated through the test case
 * providing the data file
 *
 */
public class BillingInfoBean extends BaseFormDataBean {
	@UiElement(fieldLoc = "pay.edt.billingAddress", order = 6)
	String street;
	@UiElement(fieldLoc = "pay.edt.billingCity", order = 7)
	String city;
	@UiElement(fieldLoc = "pay.dd.stateSel")
	String state;
	@UiElement(fieldLoc = "pay.edt.billingZip", order = 8)
	String billZip;
	
	public BillingInfoBean(){
		this.street = getBundle().getString("creditCards.BI.street");
		this.city = getBundle().getString("creditCards.BI.city");
		this.billZip = getBundle().getString("creditCards.BI.billZip");
	}
	
	@Override
	public void fillRandomData() { 
		PerfectoUtils util = new PerfectoUtils();
		PayTestPage checkout = new PayTestPage();
		util.selectBoxSelection(checkout.getCardSelDdStateSel(), getBundle().getString("creditCards.BI.state"));
		super.fillRandomData(); 
	}
	
	public void fillIncorrectData(){
		super.fillRandomData();
	}

	public String getStreet() {
		return street;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getBillZip() {
		return billZip;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setBillZip(String billZip) {
		this.billZip = billZip;
	}
}
