package com.automation.web.pages.orderhistory;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class OrderDetailsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	@FindBy(locator = "orderdetails.lbl.headerordernumber")
	private QAFWebElement lblHeaderordernumber;
	
	@FindBy(locator = "orderdetails.btn.reorderselecteditems")
	private QAFWebElement btnReorderselecteditems;
	
	@FindBy(locator = "orderdetails.li.savedLists")
	private List<QAFWebElement> liSavedLists;
	
	@FindBy(locator = "orderdetails.lbl.cancelled")
	private QAFWebElement lblCancelled;
	
	@FindBy(locator = "orderdetails.li.itemname")
	private List<QAFWebElement> liItemName;
	
	public List<QAFWebElement> getLiItemName() {
		return liItemName;
	}

	public QAFWebElement getLblCancelled() {
		return lblCancelled;
	}


	public List<QAFWebElement> getLiSavedLists() {
		return liSavedLists;
	}


	public QAFWebElement getBtnReorderselecteditems() {
		return btnReorderselecteditems;
	}


	public QAFWebElement getLblHeaderordernumber() {
		return lblHeaderordernumber;
	}
	
	public QAFWebElement getSavedListscheckmark(String savedListName){ 
		String retElm = String.format(pageProps.getString("orderdetails.lbl.savedListscheckmark"), savedListName);
	    return new QAFExtendedWebElement(retElm);
	}

}