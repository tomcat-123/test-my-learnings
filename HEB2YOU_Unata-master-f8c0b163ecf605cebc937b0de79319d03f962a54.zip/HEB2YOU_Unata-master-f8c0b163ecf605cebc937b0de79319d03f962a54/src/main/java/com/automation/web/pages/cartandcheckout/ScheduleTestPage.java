package com.automation.web.pages.cartandcheckout;

import java.util.List;
//import static common.CommonUtils.MAX_WAIT_TIME;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ScheduleTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}

	@FindBy(locator = "schedule.btn.timeslot")
	private QAFWebElement chkOutBtnTimeslot;
	
	@FindBy(locator = "schedule.img.map")
	private QAFWebElement chkOutImgMap;
	
	
	@FindBy(locator = "schedule.get.dateRange")
	private QAFWebElement chkOutGetDateRange;

	@FindBy(locator = "schedule.txt.pickupDate")
	private QAFWebElement chkOutTxtPickupDate;

	@FindBy(locator = "schedule.txt.pickupTime")
	private QAFWebElement chkOutTxtPickupTime;
	
	@FindBy(locator = "schedule.txt.currentmonth")
	private QAFWebElement chkOuttxtcurrentmonth;
	
	@FindBy(locator = "schedule.txt.currentdate")
	private QAFWebElement chkOuttxtcurrentdate;
	
	@FindBy(locator = "schedule.lbl.pickfeeintotalsec")
	private QAFWebElement chkOutLblPickfeeintotalsec ;
	
	@FindBy(locator = "schedule.edt.firstName")
	private QAFWebElement ckconEdtFirstName;

	@FindBy(locator = "schedule.edt.lastName")
	private QAFWebElement ckconEdtLastName;

	@FindBy(locator = "schedule.edt.mobileNum")
	private QAFWebElement ckconEdtMobileNum;

	@FindBy(locator = "schedule.edt.homeNum")
	private QAFWebElement ckconEdtHomeNum;

	@FindBy(locator = "schedule.edt.workNum")
	private QAFWebElement ckconEdtWorkNum;

	@FindBy(locator = "schedule.edt.otherNum")
	private QAFWebElement ckconEdtOtherNum; 
	
	@FindBy(locator = "schedule.btn.saveAddress")
	private QAFWebElement ckconBtnSaveAddress;
	
	@FindBy(locator = "schedule.txt.popuptxtselectTimeSlot")
	private QAFWebElement chkOuttxtpopuptxtselectTimeSlot;
	

	@FindBy(locator = "schedule.txt.selectfromtime")
	private List<QAFWebElement> chkOutTxtSelectFromTime;
	
	@FindBy(locator = "schedule.txt.selecttotime")
	private List<QAFWebElement> chkOutTxtSelectToTime;
	
	@FindBy(locator = "schedule.btn.nextweek")
	private QAFWebElement chkOutBtnNextweek;
	
	@FindBy(locator = "schedule.txt.days")
	private List<QAFWebElement> chkOutTxtDays;
	
	@FindBy(locator = "schedule.lbl.monthintimeslot")
	private QAFWebElement lblMonthintimeslot;
	 
	@FindBy(locator = "schedule.table.totals")
	private QAFWebElement ckconTableTotals;

	@FindBy(locator = "schedule.btn.navigateToPymnt")
	private QAFWebElement ckconBtnNavigateToPymnt;
	
	@FindBy(locator = "schedule.btn.continue")
	private QAFWebElement continueBtn;
	
	@FindBy(locator = "schedule.lis.tablelement")
	private List<QAFWebElement> scheduleListTablelement;
	
	@FindBy(locator = "schedule.lis.selectButtons")
	private List<QAFWebElement> scheduleListSelectButtons ;
	
	@FindBy(locator = "schedule.lis.pickFees")
	private List<QAFWebElement> scheduleListPickFees; 
	 
	@FindBy(locator = "schedule.lis.pricedetails")
	private List<QAFWebElement> scheduleListPriceDetails; 
	
	/**
	 * Table containing all totals
	 */
	public QAFWebElement getCkconTableTotals(){ return ckconTableTotals; }

	/**
	 * Navigates from reservation page to payment page
	 */
	public QAFWebElement getCkconBtnNavigateToPymnt(){ return ckconBtnNavigateToPymnt; }
	
	public QAFWebElement getLblMonthintimeslot() {
		return lblMonthintimeslot;
	}

	public List<QAFWebElement> getChkOutTxtSelectFromTime() {
		return chkOutTxtSelectFromTime;
	}

	public List<QAFWebElement> getChkOutTxtSelectToTime() {
		return chkOutTxtSelectToTime;
	}

	public QAFWebElement getChkOutBtnNextweek() {
		return chkOutBtnNextweek;
	}

	public List<QAFWebElement> getChkOutTxtDays() {
		return chkOutTxtDays;
	}
	/**
	 * Select a Time pop up txt 
	 */
	
	public QAFWebElement getChkOuttxtpopuptxtselectTimeSlot() {
		return chkOuttxtpopuptxtselectTimeSlot;
	}
	
	/**
	 * Button to save changes and reserve timeslot before proceeding
	 */
	public QAFWebElement getCkconBtnSaveAddress(){ return ckconBtnSaveAddress; }

	
	public QAFWebElement getChkOutLblPickfeeintotalsec() {
		return chkOutLblPickfeeintotalsec;
	}
	/**
	 * Reserve a timeslot button
	 */
	public QAFWebElement getChkOutBtnTimeslot(){ return chkOutBtnTimeslot; }

	/**
	 * Map box
	 */
	public QAFWebElement getChkOutImgMap(){ return chkOutImgMap; }
	/**
	 * Day of month for pickup
	 */
	public QAFWebElement getChkOutTxtPickupDate(){ return chkOutTxtPickupDate; }

	/**
	 * Time range for pickup
	 */
	public QAFWebElement getChkOutTxtPickupTime(){ return chkOutTxtPickupTime; }
	
	public QAFWebElement getChkOutTxtCurrentMonth(){ return chkOuttxtcurrentmonth; }
	
	public QAFWebElement getChkOutTxtCurrentDate(){ return chkOuttxtcurrentdate; }
	/**
	 * Date range for timeslot selection
	 */
	public QAFWebElement getChkOutGetDateRange(String item){ 
		String retElm = String.format(pageProps.getString("schedule.get.dateRange"), item);
	    return new QAFExtendedWebElement(retElm);
	}
	
	/**
	 * First Name edit box
	 */
	public QAFWebElement getCkconEdtFirstName(){ return ckconEdtFirstName; }

	/**
	 * Last Name edit box
	 */
	public QAFWebElement getCkconEdtLastName(){ return ckconEdtLastName; }

	/**
	 * Mobile number edit box
	 */
	public QAFWebElement getCkconEdtMobileNum(){ return ckconEdtMobileNum; }

	/**
	 * Home number edit box
	 */
	public QAFWebElement getCkconEdtHomeNum(){ return ckconEdtHomeNum; }
	  
	/**
	 * Work number edit box
	 */
	public QAFWebElement getCkconEdtWorkNum(){ return ckconEdtWorkNum; }

	
	public QAFWebElement getChkOutGetDateRange() {
		return chkOutGetDateRange;
	}

	public QAFWebElement getChkOuttxtcurrentmonth() {
		return chkOuttxtcurrentmonth;
	}

	public QAFWebElement getChkOuttxtcurrentdate() {
		return chkOuttxtcurrentdate;
	}

	public QAFWebElement getContinueBtn() {
		return continueBtn;
	}

	/**
	 * Other number edit box
	 */
	public QAFWebElement getCkconEdtOtherNum(){ return ckconEdtOtherNum; }
	
	public List<QAFWebElement> getScheduleListTablelement(){ return scheduleListTablelement; }
	
	public List<QAFWebElement> getScheduleListSelectButtons(){ return scheduleListSelectButtons; }
	
	public List<QAFWebElement> getScheduleListPickFees(){ return scheduleListPickFees; }
	
	public List<QAFWebElement> getScheduleListPriceDetails(){ return scheduleListPriceDetails; }
}