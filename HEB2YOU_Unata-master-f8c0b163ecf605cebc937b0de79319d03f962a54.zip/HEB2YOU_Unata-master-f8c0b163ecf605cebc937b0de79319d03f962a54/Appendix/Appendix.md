# Appendix


# Scroll to element Methods
	
   // Suggested Method 1

			try { JavascriptExecutor js = (JavascriptExecutor)
			PerfectoUtils.getDriver();
			js.executeScript("arguments[0].scrollIntoView(true);", qafelement);
			} catch (Exception e) { Reporter.log(
			"Error occured while scrolling to the elemenet.", MessageTypes.Info);
			e.printStackTrace(); }
			switchToContext(getDriver(), "VISUAL");
			getDriver().findElement(By.linkText("Ship to Home"));
			 

  // Suggested Method 2
			
			Actions clicker = new Actions(getDriver());
			clicker.sendKeys(Keys.PAGE_DOWN); try { Thread.sleep(1000); } catch
			(InterruptedException e) { // TODO Auto-generated catch block
			e.printStackTrace(); }
			 

  // Suggested method 3

			
			Locatable element = (Locatable) QAFelement; Point p =
			element.getCoordinates().getLocationOnScreen(); JavascriptExecutor js
			= (JavascriptExecutor) getDriver();
			js.executeScript("window.scrollTo(" + p.getX() + "," + (p.getY() +
			150) + ");");
			 

			WebElement element1 = (WebElement)element; Coordinates coordinate =
			((Locatable)element1).getCoordinates(); coordinate.onPage();
			coordinate.inViewPort(); }
			 
			 
# Switch to context

			private static void switchToContext(QAFExtendedWebDriver driver, String context) {
			RemoteExecuteMethod executeMethod = new RemoteExecuteMethod(driver);
			Map<String, String> params = new HashMap<String, String>();
			params.put("name", context);
			executeMethod.execute(DriverCommand.SWITCH_TO_CONTEXT, params);
			}
		
# Clicking an element

			register.getRegisterBtnCreateNewAcc().click();
			register.getRegisterBtnCreateNewAcc().click();
			CommonUtils.getDriver().getKeyboard().sendKeys(Keys.ENTER);
			CommonUtils.clickUsingJavaScript(register.getRegisterBtnCreateNewAcc());
			Actions act = new Actions(PerfectoUtils.getDriver());
			act.clickAndHold(register.getRegisterBtnCreateNewAcc()).perform(;
			act.release(register.getRegisterBtnCreateNewAcc()).perform();
			new Actions(PerfectoUtils.getDriver()).moveToElement(register.getRegisterBtnCreateNewAcc())
			.doubleClick().build().perform();
			
 // Using Java Script
	
			String mouseOverScript = "if(document.createEvent){var evObj = 			document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); 				arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { 				arguments[0].fireEvent('onmouseover');}";
			String onClickScript = "if(document.createEvent){var evObj = 			document.createEvent('MouseEvents');evObj.initEvent('click', true, false); 				arguments[0].dispatchEvent(evObj);} else if(document.createEventObject)	{ 				arguments[0].fireEvent('onclick');}";
			qafelement.waitForPresent(MAX_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor) PerfectoUtils.getDriver();
			js.executeScript(mouseOverScript, qafelement);
			js.executeScript(onClickScript, qafelement);

# Verify Child window

			public static void verifyChildWindow() {
			String parentWindow = PerfectoUtils.getDriver().getWindowHandle();
			Set<String> allWindowHandles = PerfectoUtils.getDriver().getWindowHandles();
			int numberoftabs = allWindowHandles.size();
			System.out.println(numberoftabs);
				if (numberoftabs == 1) {
					Reporter.log("Child window is not present:", MessageTypes.Info);
				} else {
					for (String winHandle : allWindowHandles) {
						System.out.println(winHandle);
						PerfectoUtils.getDriver().switchTo().window(winHandle);
						Reporter.logWithScreenShot("Child window is opened:", MessageTypes.Info);
						// PerfectoUtils.getDriver().close();
						PerfectoUtils.getDriver().switchTo().window(parentWindow);
						// PerfectoUtils.getDriver().close();
						Reporter.logWithScreenShot("Parent window is opened:", MessageTypes.Info);
					}
				}
			}
		
# Mouse hover methods

			Actions class
			Actions act = new Actions(PerfectoUtils.getDriver());
			WebElement element1 = (WebElement) moveToElement;
			act.moveToElement(element1).build().perform();

			Robot Class
			Point point = moveToElement.getLocation();
			int xAxis = point.getX();
			int yAxis = point.getY();
			Robot robot = new Robot();
			robot.mouseMove(xAxis, yAxis);

			Qmetry Approach
			Locatable locatable = (Locatable) moveToElement;
			Coordinates arg0 = locatable.getCoordinates();
			System.out.println(arg0);
			getDriver().getMouse().mouseMove(arg0);
			
# Mouse hover and click methods

			Actions class
			Actions act = new Actions(PerfectoUtils.getDriver());
			
			WebElement element1 = (WebElement) 
				moveAndClickElement;
			act.moveToElement(element1).click().perform();
			act.click().perform();

			Robot Class
			Point point = moveAndClickElement.getLocation();
			int xAxis = point.getX();
			int yAxis = point.getY();
			
			Robot robot = new Robot();
			robot.mouseMove(xAxis, yAxis);

  //Qmetry Approach
			 
			Locatable locatable = (Locatable) 
			moveAndClickElement;
			Coordinates arg0 = locatable.getCoordinates();
			System.out.println(arg0);
			getDriver().getMouse().mouseMove(arg0);
			getDriver().getMouse().click(arg0);
			
// Robot Class

			Point point = moveElement.getLocation();
			int xAxis = point.getX();
			int yAxis = point.getY();
			
			robot.mouseMove(xAxis, yAxis);
			robot.mousePress(InputEvent.getMaskForButton(2));
			robot.mouseRelease(InputEvent.getMaskForButton(2));

			
			try { // Java Script String mouseOverScript =
			"if(document.createEvent){var evObj = 			document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); 
			arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { 			arguments[0].fireEvent('onmouseover');}"
			;JavascriptExecutor js = (JavascriptExecutor) getDriver();
			WebElement element = (WebElement) moveElement;
			js.executeScript(mouseOverScript, element); clickElement.click(); }
			catch (Exception e) { // Qmetry Steps Locatable locatable =
			(Locatable) (WebElement) moveElement; Coordinates arg0 =
			locatable.getCoordinates(); getDriver().getMouse().mouseMove(arg0);
			Locatable locatable1 = (Locatable) (WebElement) clickElement;
			Coordinates arg1 = locatable1.getCoordinates();
			getDriver().getMouse().click(arg1); }
			 
# Dropdown select Methods

			public static void dropdownSelectByValue(WebElement element, String text) {
			Select dropdown = new Select(element);
			dropdown.selectByValue(text);
			}

			public static void dropdownSelectByIndex(WebElement element, int index) {
			Select dropdown = new Select(element);
			dropdown.selectByIndex(index);
			}
			
# PMRListener Class

		public static final String PERFECTO_REPORT_CLIENT = "perfecto.report.client";
	
		@Override
		public void onTestStart(ITestResult testResult) {
			QAFExtendedWebDriver driver = new WebDriverTestBase().getDriver();
			String prjName = testResult.getTestContext().getName();
			String contextName = testResult.getTestContext().getSuite().getName();
			PerfectoExecutionContext perfectoExecutionContext = new 			PerfectoExecutionContext.PerfectoExecutionContextBuilder()
					.withProject(new Project(prjName, 			"1.0")).withContextTags(contextName).withWebDriver(driver).build();
			ReportiumClient reportClient = new ReportiumClientFactory()
					.createPerfectoReportiumClient(perfectoExecutionContext);
			TestContext context = new TestContext(testResult.getMethod().getGroups());
			reportClient.testStart(testResult.getMethod().getMethodName(), context);
			((TestNGScenario) testResult.getMethod()).getMetaData().put("Perfecto-report",
					"<a href=\"" + reportClient.getReportUrl() + "\" target=\"_blank\">view</a>");
			getBundle().setProperty(PERFECTO_REPORT_CLIENT, reportClient);
	
		}
	
		public void beforExecute(StepExecutionTracker stepExecutionTracker) {
			try {
				ReportiumClient reportClient = (ReportiumClient) 				getBundle().getObject(PERFECTO_REPORT_CLIENT);
				reportClient.testStep(stepExecutionTracker.getStep().getDescription());
			} catch (Exception e) {
				/**
				 * ignore
				 */
			}
		}
	
		@Override
		public void onTestSuccess(ITestResult testResult) {
			ReportiumClient reportClient = (ReportiumClient) 			getBundle().getObject(PERFECTO_REPORT_CLIENT);
			reportClient.testStop(TestResultFactory.createSuccess());
		}
	
		@Override
		public void onTestFailure(ITestResult testResult) {
			ReportiumClient reportClient = (ReportiumClient) 			getBundle().getObject(PERFECTO_REPORT_CLIENT);
			reportClient.testStop(TestResultFactory.createFailure("An error occurred", 			testResult.getThrowable()));
		}
	
		@Override
		public void onTestSkipped(ITestResult result) {
			// TODO Auto-generated method stub
	
		}
	
		@Override
		public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
			// TODO Auto-generated method stub
	
		}
	
		@Override
		public void onStart(ITestContext context) {
			// TODO Auto-generated method stub
	
		}
	
		@Override
		public void onFinish(ITestContext context) {
			// TODO Auto-generated method stub
	
		}

}

#	Adds the item and its current count to the hash map
	 * If it exists, it will only add to its current amount and not to the unique item count
	 * @param itemToAdd
	 *            What item to add to the hash map
	 * @param itemAmnt
	 *            Amount to add
	 * @param uniqueItemCnt
	 *            Current unique item count
	 */
	private void addCntToMap(String itemToAdd, int itemAmnt, int uniqueItemCnt) {
		// Check to see if property exists. If it doesn't, add it to the hash
		// map
		if (!getBundle().containsKey(ITEM_ID_KEY + itemToAdd)) {
			getBundle().setProperty(ITEM_ID_KEY + itemToAdd, itemAmnt);
			getBundle().setProperty(CART_UNIQUE_ITEM_CNT_KEY, uniqueItemCnt);
		} else {
			// Item exists. Add it onto current amount in the hash, but don't
			// increment
			// unique item count
			int curCount = (int) getBundle().getProperty(ITEM_ID_KEY + itemToAdd);
			getBundle().setProperty(ITEM_ID_KEY + itemToAdd, (itemAmnt + curCount));
		}
	}

# Listener to handle cases of a populated text field. If the field is populated, the element will be cleared
# Browser selenium webdriver Listner

	public class SendKeysListener extends QAFWebElementCommandAdapter {

	@Override
	public void beforeCommand(QAFExtendedWebElement element, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.SEND_KEYS_TO_ELEMENT)) {
			element.clear();
			String value = String.valueOf(commandTracker.getParameters().get("value"));
			if (StringUtil.isBlank(value)) {
				// No need to send key
				// ignore actual command
				commandTracker.setResponce(new Response());
			}
		}
	}

	@Override
	public void onFailure(QAFExtendedWebElement element, CommandTracker commandTracker) {
		// System.out.println(commandTracker.getException().getMessage());
		if (commandTracker.getException().getMessage().contains("class=\"load-app 		view-loading-indicator\"")) {
			// if(commandTracker.getCommand().equals("clickElement")){
			element.click();
			commandTracker.setException(null);

			return;
		} else {
			PerfectoUtils u = new PerfectoUtils();
			ReportMessage(commandTracker.getException() + "",MessageTypes.Fail);
		}
		super.onFailure(element, commandTracker);
	}

}

}

# Listener to handle cases of a populated text field. If the field is populated, the element will be cleared
		// desiredCapabilities = (Capabilities) DesiredCapabilities.firefox();
		// ((DesiredCapabilities)desiredCapabilities).setCapability("raisesAccessibilityExceptions",
		// true);
		// desiredCapabilities.getCapability("acceptInsecureCerts");
		// desiredCapabilities.getCapability("profile");
		//
		/*
		 * ProfilesIni prof = new ProfilesIni(); FirefoxProfile ffProfile=
		 * prof.getProfile(getBundle().getString("webdriver.firefox.profile"));
		 * ffProfile.setAcceptUntrustedCertificates(true);
		 * ffProfile.setAssumeUntrustedCertificateIssuer(false);
		 */

		// ((DesiredCapabilities)desiredCapabilities).setCapability(CapabilityType.ACCEPT_SSL_CERTS,
		// true);

		/*
		 * DesiredCapabilities capabilities = new DesiredCapabilities();
		 * capabilities.setBrowserName("safari"); CommandExecutor executor = new
		 * SeleneseCommandExecutor(new URL("http://localhost:4444/"), new
		 * URL("http://www.google.com/"), capabilities); WebDriver driver = new
		 * RemoteWebDriver(executor, capabilities);
		 */
		// }

		// if
		// (getBundle().getString("driver.name").equalsIgnoreCase("iExplorerDriver"))
		// {
		// System.setProperty("webdriver.ie.driver", "lib\\IEDriverServer.exe");
		// }
		
			// @Override
		// public void onFailure(QAFExtendedWebDriver driver, CommandTracker
		// commandTracker) {
		//// System.out.println(commandTracker.getCommand());
		//// PerfectoUtils.scrolltoelement(commandTracker.getCommand().);
		// }
