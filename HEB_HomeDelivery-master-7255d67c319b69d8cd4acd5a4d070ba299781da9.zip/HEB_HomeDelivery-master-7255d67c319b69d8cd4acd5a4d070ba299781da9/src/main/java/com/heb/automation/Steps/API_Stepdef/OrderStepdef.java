package com.heb.automation.Steps.API_Stepdef;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.heb.automation.ErrorMessages.ErrorMessage;
import com.heb.automation.Services.BodyParameter.Geocode.Geocode_Body;
import com.heb.automation.Services.BodyParameter.Order.Customer;
import com.heb.automation.Services.BodyParameter.Order.Delivery_from;
import com.heb.automation.Services.BodyParameter.Order.Delivery_schedule;
import com.heb.automation.Services.BodyParameter.Order.Delivery_to;
import com.heb.automation.Services.BodyParameter.Order.Notes;
import com.heb.automation.Services.BodyParameter.Order.Notes_Root;
import com.heb.automation.Services.BodyParameter.Order.Order;
import com.heb.automation.Services.BodyParameter.Order.Order_PostRoot;
import com.heb.automation.Services.BodyParameter.Order.Recipient;
import com.heb.automation.Services.BodyParameter.Order.Status;
import com.heb.automation.Services.BodyParameter.Order.Store;
import com.heb.automation.Services.BodyParameter.Teams.Teams_Body;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.ServiceUtils;
import com.heb.automation.Services.HomeDelivery.GeoCode.Geocode_RootObject;
import com.heb.automation.Services.HomeDelivery.Order.HomeDelivery_Data;
import com.heb.automation.Services.HomeDelivery.Order.HomeDelivery_RootObject;
import com.heb.automation.Services.HomeDelivery.Order.HomeDelivery_Tasks;
import com.heb.automation.Services.HomeDelivery.Order.Orders_Post;
import com.heb.automation.Services.HomeDelivery.Teams.Teams_Post;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class OrderStepdef {

	@QAFTestStep(description = "Build URL for read HomeDelivery orders")
	public void buildURLForReadHomeDeliverOrders() {
		String baseurl = getBundle().getString("HomeDelivery.adminPortal");
		String resource = getBundle().getString("HomeDelivery.endpoint.getOrders");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for read HomeDelivery Single Collection orders")
	public void buildURLForReadHomeDeliverSingleCollectionOrders() {
		String baseurl = getBundle().getString("HomeDelivery.adminPortal");
		String resource = getBundle().getString("HomeDelivery.endpoint.getOrders")+"/1/1";
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for read HomeDelivery geocode")
	public void buildURLForReadHomeDeliverGeoCode() {
		String baseurl = getBundle().getString("HomeDelivery.adminPortal");
		String resource = getBundle().getString("HomeDelivery.endpoint.getGeoCode");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		ord.setGross_bill("41.65");
		ord.setTip("3.0");
		ord.setInvoice(null);
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey("instructions");
		note.setValue("Doorbell.  No gate code");
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id("108");
		str.setEmail("");
		str.setPhone(generateRandom());
		str.setName("SA45 HWY281/EVANS RD");
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id("1875560");
		ctr.setFirst_name("XXXX");
		ctr.setLast_name("XXXXX");
		ctr.setPhone(generateRandom());
		ctr.setEmail("cccccc@gmail.com");
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1("20935 US HIGHWAY 281");
		del.setAddress_2("REPLACING 00569");
		del.setCity("SAN ANTONIO");
		del.setState("TX");
		del.setZip("78258");
		del.setNote("");

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1("615 S Flores St");
		delTo.setAddress_2("");
		delTo.setCity("San Antonio");
		delTo.setState("TX");
		delTo.setZip("78204");
		delTo.setNote("");

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id("1875560");
		rcp.setFirst_name("XXXX");
		rcp.setLast_name("XXXX");
		rcp.setPhone(generateRandom());
		rcp.setEmail("ccccc@gmail.com");

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey("signature_required");
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey("has_alcohol");
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey("item_count");
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter with duplicate COMS id for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterWithDuplicateCOMSIdForCreatingHomeDeliveryOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getBundle().getString("comsID"));
		ord.setGross_bill("41.65");
		ord.setTip("3.0");
		ord.setInvoice(null);
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey("instructions");
		note.setValue("Doorbell.  No gate code");
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id("108");
		str.setEmail("");
		str.setPhone(generateRandom());
		str.setName("SA45 HWY281/EVANS RD");
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id("1875560");
		ctr.setFirst_name("XXXX");
		ctr.setLast_name("XXXXX");
		ctr.setPhone(generateRandom());
		ctr.setEmail("cccccc@gmail.com");
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1("20935 US HIGHWAY 281");
		del.setAddress_2("REPLACING 00569");
		del.setCity("SAN ANTONIO");
		del.setState("TX");
		del.setZip("78258");
		del.setNote("");

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1("615 S Flores St");
		delTo.setAddress_2("");
		delTo.setCity("San Antonio");
		delTo.setState("TX");
		delTo.setZip("78204");
		delTo.setNote("");

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id("1875560");
		rcp.setFirst_name("XXXX");
		rcp.setLast_name("XXXX");
		rcp.setPhone(generateRandom());
		rcp.setEmail("ccccc@gmail.com");

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey("signature_required");
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey("has_alcohol");
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey("item_count");
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Missing Mandatory Body Parameter for creating HomeDelivery Order")
	public void userUsesAnArrayOfMissingMandatoryBodyParameterForCreatingHomeDeliveryOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		ord.setGross_bill("41.65");
		ord.setTip("3.0");
		ord.setInvoice(null);
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey("instructions");
		note.setValue("Doorbell.  No gate code");
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id("108");
		str.setEmail("");
		str.setPhone(null);
		str.setName("SA45 HWY281/EVANS RD");
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id("1875560");
		ctr.setFirst_name("XXXX");
		ctr.setLast_name("XXXXX");
		ctr.setPhone(generateRandom());
		ctr.setEmail("cccccc@gmail.com");
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1("20935 US HIGHWAY 281");
		del.setAddress_2("REPLACING 00569");
		del.setCity("SAN ANTONIO");
		del.setState("TX");
		del.setZip("78258");
		del.setNote("");

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1("615 S Flores St");
		delTo.setAddress_2("");
		delTo.setCity("San Antonio");
		delTo.setState("TX");
		delTo.setZip("78204");
		delTo.setNote("");

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(null);

		Recipient rcp = new Recipient();
		rcp.setExternal_id("1875560");
		rcp.setFirst_name("XXXX");
		rcp.setLast_name("XXXX");
		rcp.setPhone(generateRandom());
		rcp.setEmail("ccccc@gmail.com");

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey("signature_required");
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey("has_alcohol");
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey("item_count");
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Missing All Mandatory Body Parameter for creating HomeDelivery Order")
	public void userUsesAnArrayOfMissingAllMandatoryBodyParameterForCreatingHomeDeliveryOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(null);
		ord.setGross_bill("41.65");
		ord.setTip("3.0");
		ord.setInvoice(null);
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey("instructions");
		note.setValue("Doorbell.  No gate code");
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id("108");
		str.setEmail("");
		str.setPhone(null);
		str.setName("SA45 HWY281/EVANS RD");
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id("1875560");
		ctr.setFirst_name("XXXX");
		ctr.setLast_name("XXXXX");
		ctr.setPhone(null);
		ctr.setEmail("cccccc@gmail.com");
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1("20935 US HIGHWAY 281");
		del.setAddress_2("REPLACING 00569");
		del.setCity("SAN ANTONIO");
		del.setState("TX");
		del.setZip("78258");
		del.setNote("");

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1("615 S Flores St");
		delTo.setAddress_2("");
		delTo.setCity("San Antonio");
		delTo.setState("TX");
		delTo.setZip("78204");
		delTo.setNote("");

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(null);
		delShe.setEnd_time(null);

		Recipient rcp = new Recipient();
		rcp.setExternal_id("1875560");
		rcp.setFirst_name("XXXX");
		rcp.setLast_name("XXXX");
		rcp.setPhone(null);
		rcp.setEmail("ccccc@gmail.com");

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey("signature_required");
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey("has_alcohol");
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey("item_count");
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter With Blank comsID for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterWithBlankcomsIDForCreatingHomeDeliveryOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id("");
		ord.setGross_bill("41.65");
		ord.setTip("3.0");
		ord.setInvoice(null);
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey("instructions");
		note.setValue("Doorbell.  No gate code");
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id("108");
		str.setEmail("");
		str.setPhone(generateRandom());
		str.setName("SA45 HWY281/EVANS RD");
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id("1875560");
		ctr.setFirst_name("XXXX");
		ctr.setLast_name("XXXXX");
		ctr.setPhone(generateRandom());
		ctr.setEmail("cccccc@gmail.com");
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1("20935 US HIGHWAY 281");
		del.setAddress_2("REPLACING 00569");
		del.setCity("SAN ANTONIO");
		del.setState("TX");
		del.setZip("78258");
		del.setNote("");

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1("615 S Flores St");
		delTo.setAddress_2("");
		delTo.setCity("San Antonio");
		delTo.setState("TX");
		delTo.setZip("78204");
		delTo.setNote("");

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id("1875560");
		rcp.setFirst_name("XXXX");
		rcp.setLast_name("XXXX");
		rcp.setPhone(generateRandom());
		rcp.setEmail("ccccc@gmail.com");

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey("signature_required");
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey("has_alcohol");
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey("item_count");
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter With Invalid Store for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterWithInvalidStoreForCreatingHomeDeliveryOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		ord.setGross_bill("41.65");
		ord.setTip("3.0");
		ord.setInvoice(null);
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey("instructions");
		note.setValue("Doorbell.  No gate code");
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id("18");
		str.setEmail("");
		str.setPhone(generateRandom());
		str.setName("SA45 HWY281/EVANS RD");
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id("1875560");
		ctr.setFirst_name("XXXX");
		ctr.setLast_name("XXXXX");
		ctr.setPhone(generateRandom());
		ctr.setEmail("cccccc@gmail.com");
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1("20935 US HIGHWAY 281");
		del.setAddress_2("REPLACING 00569");
		del.setCity("SAN ANTONIO");
		del.setState("TX");
		del.setZip("78258");
		del.setNote("");

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1("615 S Flores St");
		delTo.setAddress_2("");
		delTo.setCity("San Antonio");
		delTo.setState("TX");
		delTo.setZip("78204");
		delTo.setNote("");

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id("1875560");
		rcp.setFirst_name("XXXX");
		rcp.setLast_name("XXXX");
		rcp.setPhone(generateRandom());
		rcp.setEmail("ccccc@gmail.com");

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey("signature_required");
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey("has_alcohol");
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey("item_count");
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter With InActive Store for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterWithInActiveStoreForCreatingHomeDeliveryOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		ord.setGross_bill("41.65");
		ord.setTip("3.0");
		ord.setInvoice(null);
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey("instructions");
		note.setValue("Doorbell.  No gate code");
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id("13");
		str.setEmail("");
		str.setPhone(generateRandom());
		str.setName("SA45 HWY281/EVANS RD");
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id("1875560");
		ctr.setFirst_name("XXXX");
		ctr.setLast_name("XXXXX");
		ctr.setPhone(generateRandom());
		ctr.setEmail("cccccc@gmail.com");
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1("20935 US HIGHWAY 281");
		del.setAddress_2("REPLACING 00569");
		del.setCity("SAN ANTONIO");
		del.setState("TX");
		del.setZip("78258");
		del.setNote("");

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1("615 S Flores St");
		delTo.setAddress_2("");
		delTo.setCity("San Antonio");
		delTo.setState("TX");
		delTo.setZip("78204");
		delTo.setNote("");

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id("1875560");
		rcp.setFirst_name("XXXX");
		rcp.setLast_name("XXXX");
		rcp.setPhone(generateRandom());
		rcp.setEmail("ccccc@gmail.com");

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey("signature_required");
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey("has_alcohol");
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey("item_count");
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter With Invalid DeliveryTo for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterWithInvalidDeliveryToForCreatingHomeDeliveryOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		ord.setGross_bill("41.65");
		ord.setTip("3.0");
		ord.setInvoice(null);
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey("instructions");
		note.setValue("Doorbell.  No gate code");
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id("108");
		str.setEmail("");
		str.setPhone(generateRandom());
		str.setName("SA45 HWY281/EVANS RD");
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id("1875560");
		ctr.setFirst_name("XXXX");
		ctr.setLast_name("XXXXX");
		ctr.setPhone(generateRandom());
		ctr.setEmail("cccccc@gmail.com");
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1("20935 US HIGHWAY 281");
		del.setAddress_2("REPLACING 00569");
		del.setCity("SAN ANTONIO");
		del.setState("TX");
		del.setZip("78258");
		del.setNote("");

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1("");
		delTo.setAddress_2("");
		delTo.setCity("");
		delTo.setState("");
		delTo.setZip("");
		delTo.setNote("");

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id("1875560");
		rcp.setFirst_name("XXXX");
		rcp.setLast_name("XXXX");
		rcp.setPhone(generateRandom());
		rcp.setEmail("ccccc@gmail.com");

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey("signature_required");
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey("has_alcohol");
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey("item_count");
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter Invalid DeliverySchedule for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterInvalidDeliverySchedulForCreatingHomeDeliveryOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		ord.setGross_bill("41.65");
		ord.setTip("3.0");
		ord.setInvoice(null);
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey("instructions");
		note.setValue("Doorbell.  No gate code");
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id("108");
		str.setEmail("");
		str.setPhone(generateRandom());
		str.setName("SA45 HWY281/EVANS RD");
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id("1875560");
		ctr.setFirst_name("XXXX");
		ctr.setLast_name("XXXXX");
		ctr.setPhone(generateRandom());
		ctr.setEmail("cccccc@gmail.com");
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1("20935 US HIGHWAY 281");
		del.setAddress_2("REPLACING 00569");
		del.setCity("SAN ANTONIO");
		del.setState("TX");
		del.setZip("78258");
		del.setNote("");

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1("615 S Flores St");
		delTo.setAddress_2("");
		delTo.setCity("San Antonio");
		delTo.setState("TX");
		delTo.setZip("78204");
		delTo.setNote("");

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time("");
		delShe.setEnd_time("");

		Recipient rcp = new Recipient();
		rcp.setExternal_id("1875560");
		rcp.setFirst_name("XXXX");
		rcp.setLast_name("XXXX");
		rcp.setPhone(generateRandom());
		rcp.setEmail("ccccc@gmail.com");

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey("signature_required");
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey("has_alcohol");
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey("item_count");
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter With Invalid TipAmount for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterWithInvalidTipAmountForCreatingHomeDeliveryOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		ord.setGross_bill("41.65");
		ord.setTip("1000");
		ord.setInvoice(null);
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey("instructions");
		note.setValue("Doorbell.  No gate code");
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id("108");
		str.setEmail("");
		str.setPhone(generateRandom());
		str.setName("SA45 HWY281/EVANS RD");
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id("1875560");
		ctr.setFirst_name("XXXX");
		ctr.setLast_name("XXXXX");
		ctr.setPhone(generateRandom());
		ctr.setEmail("cccccc@gmail.com");
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1("20935 US HIGHWAY 281");
		del.setAddress_2("REPLACING 00569");
		del.setCity("SAN ANTONIO");
		del.setState("TX");
		del.setZip("78258");
		del.setNote("");

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1("615 S Flores St");
		delTo.setAddress_2("");
		delTo.setCity("San Antonio");
		delTo.setState("TX");
		delTo.setZip("78204");
		delTo.setNote("");

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id("1875560");
		rcp.setFirst_name("XXXX");
		rcp.setLast_name("XXXX");
		rcp.setPhone(generateRandom());
		rcp.setEmail("ccccc@gmail.com");

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey("signature_required");
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey("has_alcohol");
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey("item_count");
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter for creating HomeDelivery Alcohol Order")
	public void userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryAlcoholOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		ord.setGross_bill("41.65");
		ord.setTip("3.0");
		ord.setInvoice(null);
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey("instructions");
		note.setValue("Doorbell.  No gate code");
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id("108");
		str.setEmail("");
		str.setPhone(generateRandom());
		str.setName("SA45 HWY281/EVANS RD");
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id("1875560");
		ctr.setFirst_name("XXXX");
		ctr.setLast_name("XXXXX");
		ctr.setPhone(generateRandom());
		ctr.setEmail("cccccc@gmail.com");
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1("20935 US HIGHWAY 281");
		del.setAddress_2("REPLACING 00569");
		del.setCity("SAN ANTONIO");
		del.setState("TX");
		del.setZip("78258");
		del.setNote("");

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1("615 S Flores St");
		delTo.setAddress_2("");
		delTo.setCity("San Antonio");
		delTo.setState("TX");
		delTo.setZip("78204");
		delTo.setNote("");

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id("1875560");
		rcp.setFirst_name("XXXX");
		rcp.setLast_name("XXXX");
		rcp.setPhone(generateRandom());
		rcp.setEmail("ccccc@gmail.com");

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey("signature_required");
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey("has_alcohol");
		notesRoot2.setValue("yes");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey("item_count");
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter for creating HomeDelivery NonAlcohol Order")
	public void userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryNonAlcoholOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		ord.setGross_bill("41.65");
		ord.setTip("3.0");
		ord.setInvoice(null);
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey("instructions");
		note.setValue("Doorbell.  No gate code");
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id("108");
		str.setEmail("");
		str.setPhone(generateRandom());
		str.setName("SA45 HWY281/EVANS RD");
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id("1875560");
		ctr.setFirst_name("XXXX");
		ctr.setLast_name("XXXXX");
		ctr.setPhone(generateRandom());
		ctr.setEmail("cccccc@gmail.com");
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1("20935 US HIGHWAY 281");
		del.setAddress_2("REPLACING 00569");
		del.setCity("SAN ANTONIO");
		del.setState("TX");
		del.setZip("78258");
		del.setNote("");

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1("615 S Flores St");
		delTo.setAddress_2("");
		delTo.setCity("San Antonio");
		delTo.setState("TX");
		delTo.setZip("78204");
		delTo.setNote("");

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id("1875560");
		rcp.setFirst_name("XXXX");
		rcp.setLast_name("XXXX");
		rcp.setPhone(generateRandom());
		rcp.setEmail("ccccc@gmail.com");

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey("signature_required");
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey("has_alcohol");
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey("item_count");
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter with all mandatory and optional fields for creating HomeDelivery Order")
	public void userUsesAnArrayOfBodyParameterWithAllMandatoryAndOptionalFieldsForCreatingHomeDeliveryOrder() throws JsonProcessingException {

		Order_PostRoot pr = new Order_PostRoot();
		ObjectMapper objm = new ObjectMapper();

		Order ord = new Order();
		ord.setExternal_id(getexternalID());
		ord.setGross_bill("41.65");
		ord.setTip("3.0");
		ord.setInvoice(null);
		ArrayList<Notes> nt = new ArrayList<Notes>();
		Notes note = new Notes();
		note.setKey("instructions");
		note.setValue("Doorbell.  No gate code");
		nt.add(note);
		ord.setNotes(nt);

		Store str = new Store();
		str.setExternal_id("108");
		str.setEmail("cccccc@gmail.com");
		str.setPhone(generateRandom());
		str.setName("SA45 HWY281/EVANS RD");
		ord.setStore(str);

		Customer ctr = new Customer();
		ctr.setExternal_id("1875560");
		ctr.setFirst_name("automation");
		ctr.setLast_name("testing");
		ctr.setPhone(generateRandom());
		ctr.setEmail("cccccc@gmail.com");
		ord.setCustomer(ctr);

		Delivery_from del = new Delivery_from();
		del.setAddress_1("20935 US HIGHWAY 281");
		del.setAddress_2("REPLACING 00569");
		del.setCity("SAN ANTONIO");
		del.setState("TX");
		del.setZip("78258");
		del.setNote("note1");

		Delivery_to delTo = new Delivery_to();
		delTo.setAddress_1("615 S Flores St");
		delTo.setAddress_2("NK : testing HD-524 50 char limit validation check");
		delTo.setCity("San Antonio");
		delTo.setState("TX");
		delTo.setZip("78204");
		delTo.setNote("note2");

		Delivery_schedule delShe = new Delivery_schedule();
		delShe.setStart_time(startDate());
		delShe.setEnd_time(endDate());

		Recipient rcp = new Recipient();
		rcp.setExternal_id("1875560");
		rcp.setFirst_name("automation1");
		rcp.setLast_name("testing1");
		rcp.setPhone(generateRandom());
		rcp.setEmail("ccccc@gmail.com");

		ArrayList<Notes_Root> nte = new ArrayList<Notes_Root>();

		Notes_Root notesRoot1 = new Notes_Root();
		notesRoot1.setKey("signature_required");
		notesRoot1.setValue("no");

		Notes_Root notesRoot2 = new Notes_Root();
		notesRoot2.setKey("has_alcohol");
		notesRoot2.setValue("no");

		Notes_Root notesRoot3 = new Notes_Root();
		notesRoot3.setKey("item_count");
		notesRoot3.setValue("3");

		nte.add(notesRoot1);
		nte.add(notesRoot2);
		nte.add(notesRoot3);

		Status sts = new Status();
		sts.setName("new");

		pr.setOrder(ord);
		pr.setDelivery_from(del);
		pr.setDelivery_to(delTo);
		pr.setDelivery_schedule(delShe);
		pr.setNotes(nte);
		pr.setRecipient(rcp);
		pr.setStatus(sts);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User UPDATE HomeDelivery Geocode body parameter contains all valid editable fields")
	public void userUPDATEHomeDeliveryGeocodeBodyParameterContainsAllValidEditableFields() throws JsonProcessingException {

		Geocode_Body pr = new Geocode_Body();
		ObjectMapper objm = new ObjectMapper();
		
		pr.setStreet("3711 Medical Dr");
		pr.setCity("San Antonio");
		pr.setState("TX");
		pr.setZip("78229");
						
		String jsonInString = objm.writeValueAsString(pr);
		jsonInString=jsonInString.replace("\"street\"", "\"street-address\"");
		
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User UPDATE HomeDelivery Geocode body parameter contains invalid valid editable fields")
	public void userUPDATEHomeDeliveryGeocodeBodyParameterContainsInvalidEditableFields() throws JsonProcessingException {

		Geocode_Body pr = new Geocode_Body();
		ObjectMapper objm = new ObjectMapper();
		
		pr.setStreet("0 S Flores St");
		pr.setCity("San Antonio");
		pr.setState("TX");
						
		String jsonInString = objm.writeValueAsString(pr);
		jsonInString=jsonInString.replace("\"street\"", "\"street-address\"");
		
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User GET response call for HomeDelivery orders")
	public static void userGETResponseCallForHomeDeliverOrders() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Orders");
				getBundle().setProperty("rClient", rClient);

				HomeDelivery_RootObject gson1 = new Gson().fromJson(rClient.getEntity(String.class),
						HomeDelivery_RootObject.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				int ID = gson1.getdata().get(0).getId();
				String comsID = gson1.getdata().get(0).getComsId();
				getBundle().setProperty("OrderID", ID);
				getBundle().setProperty("comsID", comsID);
				Reporter.log("Read Success-HomeDelivery Order ID: " + ID);
				Reporter.log("Read Success-HomeDelivery Order ComsID: " + comsID);
				System.out.println("Read Success-HomeDelivery Order ID: " + ID);
				System.out.println("Read Success-HomeDelivery Order ComsID: " + comsID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			getBundle().setProperty("errorStatusCode", errorStatusCode);

		}
	}
	
	@QAFTestStep(description = "User POST the Create HomeDelivery Order call")
	public void userPOSTTheCreateHomeDeliveryOrderCall() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		try {
			RESPONSE = ServiceUtils.POST(headers, bodyParam);
			if (RESPONSE.getStatus() == 200) {

				Reporter.log("Teams is created ");
				getBundle().setProperty("rClient", RESPONSE);

				Orders_Post gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class),
						Orders_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				int OrderID = gson1.getData().getId();
				String comsID = gson1.getData().getComsId();			
				getBundle().setProperty("OrderID", OrderID);
				getBundle().setProperty("comsID", comsID);
				Reporter.log("Created Success-HomeDelivery Order ID: " + OrderID);
				Reporter.log("Created Success-HomeDelivery Order ComsID: " + comsID);
				System.out.println("Created Success-HomeDelivery Order ID: " + OrderID);
				System.out.println("Created Success-HomeDelivery Order ComsID: " + comsID);
			}
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("Order created with failed  " + 400);
				Reporter.log(RESPONSE.toString());
				getBundle().setProperty("rClient", RESPONSE);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	@QAFTestStep(description = "User POST the Create HomeDelivery Order call for Alcohol")
	public void userPOSTTheCreateHomeDeliveryOrderCallForAlcohol() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		try {
			RESPONSE = ServiceUtils.POST(headers, bodyParam);
			if (RESPONSE.getStatus() == 200) {

				Reporter.log("Teams is created ");
				getBundle().setProperty("rClient", RESPONSE);

				Orders_Post gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class),
						Orders_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				List<HomeDelivery_Tasks> task = gson1.getData().gettasks();
				
				if (task.size()==3)
					Reporter.log("Order associated wiht 3onFleet tasks", MessageTypes.Pass);
				 else
					Reporter.log("Order not associated wiht 3onFleet tasks", MessageTypes.Fail);
			}
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("Order created with failed  " + 400);
				Reporter.log(RESPONSE.toString());
				getBundle().setProperty("rClient", RESPONSE);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	@QAFTestStep(description = "User POST the Create HomeDelivery Order call for NonAlcohol")
	public void userPOSTTheCreateHomeDeliveryOrderCallForNonAlcohol() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		try {
			RESPONSE = ServiceUtils.POST(headers, bodyParam);
			if (RESPONSE.getStatus() == 200) {

				Reporter.log("Teams is created ");
				getBundle().setProperty("rClient", RESPONSE);

				Orders_Post gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class),
						Orders_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				List<HomeDelivery_Tasks> task = gson1.getData().gettasks();
				
				if (task.size()==2)
					Reporter.log("Order associated wiht 2onFleet tasks", MessageTypes.Pass);
				 else
					Reporter.log("Order not associated wiht 2onFleet tasks", MessageTypes.Fail);
			}
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("Order created with failed  " + 400);
				Reporter.log(RESPONSE.toString());
				getBundle().setProperty("rClient", RESPONSE);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	public static String getexternalID() {
		Random random = new Random();
		char[] digits = new char[6];
		digits[0] = (char) (random.nextInt(4) + '1');
		for (int i = 1; i < 6; i++) {
			digits[i] = (char) (random.nextInt(5) + '0');
		}
		return (new String(digits));
	}

	public static String startDate() {
		String strdate = null;
		LocalDateTime time = LocalDateTime.now();
		LocalDateTime day = time.plusDays(1);
		String s1 = day.toString();
		String b[] = s1.split("\\.");

		for (String temp : b) {
			strdate = temp + "Z";
			break;
		}
		return strdate;
	}

	public static String endDate() {
		String strdate = null;
		LocalDateTime time = LocalDateTime.now();
		LocalDateTime day = time.plusDays(1).plusHours(1);
		String s1 = day.toString();
		String b[] = s1.split("\\.");

		for (String temp : b) {
			strdate = temp + "Z";
			break;
		}
		return strdate;
	}
	
	public static String generateRandom() {
		Random random = new Random();
		char[] digits = new char[5];
		digits[0] = (char) (random.nextInt(4) + '1');
		for (int i = 1; i < 5; i++) {
			digits[i] = (char) (random.nextInt(5) + '0');
		}
		return "83075"+(new String(digits));
	}
	
	@QAFTestStep(description = "validate the response schema with GET Orders")
	public static void validateTheResponseSchemaWithGETOrders() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Orders");
				getBundle().setProperty("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				getBundle().setProperty(RESPONSE, "RESPONSE");				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "GET_ORDERS");
				HomeDelivery_ReusableUtils.validateJSONschema("Orders_GET", "GET_ORDERS");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			getBundle().setProperty("errorStatusCode", errorStatusCode);

		}
	}
	
	@QAFTestStep(description = "validate the response schema with POST Orders")
	public void validateTheResponseSchemaWithPOSTOrders() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			if (rClient.getStatus() == 200) {

				Reporter.log("Teams is created ");
				getBundle().setProperty("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				getBundle().setProperty(RESPONSE, "RESPONSE");

				Orders_Post gson1 = new Gson().fromJson(RESPONSE,
						Orders_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				int OrderID = gson1.getData().getId();
				getBundle().setProperty("OrderID", OrderID);
				Reporter.log("Created Success-HomeDelivery Order ID: " + OrderID);
				System.out.println("Created Success-HomeDelivery Order ID: " + OrderID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "POST_ORDER");
				HomeDelivery_ReusableUtils.validateJSONschema("Order_POST", "POST_ORDER");
				
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Order created with failed  " + 400);
				Reporter.log(rClient.toString());
				getBundle().setProperty("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			System.out.println(e);
			Reporter.log("Order created with failed  ", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "User PUT the Update HomeDelivery Geocode call")
	public void userPUTTheUpdateHomeDeliveryGeocodeCall() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			RESPONSE = ServiceUtils.PUT(headers, bodyParam);
			if (RESPONSE.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Team is updated ");
				getBundle().setProperty("rClient", RESPONSE);

				Geocode_RootObject gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class), Geocode_RootObject.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				int ID = gson1.getData().getId();
				getBundle().setProperty("GeoID", ID);
				Reporter.log("Update Success-HomeDelivery GeoCode ID: " + ID);
				System.out.println("Update Success-HomeDelivery GeoCode ID: " + ID);
			}
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("HomeDelivery Geocode creation failed  ");
				getBundle().setProperty("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 404) {
				Reporter.log("HomeDelivery GeoCode creation failed  ");
				getBundle().setProperty("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 401) {
				Reporter.log("HomeDelivery GeoCode creation failed  ");
				getBundle().setProperty("rClient", RESPONSE);

			}
			
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
}
