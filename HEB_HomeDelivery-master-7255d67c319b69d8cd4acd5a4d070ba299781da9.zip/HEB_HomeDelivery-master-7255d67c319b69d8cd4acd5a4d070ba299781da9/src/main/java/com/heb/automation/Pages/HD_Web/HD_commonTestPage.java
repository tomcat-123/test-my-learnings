package com.heb.automation.Pages.HD_Web;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public  class HD_commonTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "HD_web.btn.3bar")
	private QAFWebElement HD_3BarBtn;

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}

	public QAFWebElement getHD_3BarBtn() {
		return HD_3BarBtn;
	}

	
	
}
