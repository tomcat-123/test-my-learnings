package com.heb.automation.Services.HomeDelivery;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import org.testng.Assert;

import com.google.gson.Gson;
import com.heb.automation.ErrorMessages.ErrorMessage;
import com.heb.automation.ErrorMessages.Errors;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class CommonUtils {

	public static void buildURL(String resource, String baseurl) {

		getBundle().setProperty("resource", resource);
		getBundle().setProperty("env.baseurl", baseurl);
		System.out.println("URL is "+ getBundle().getProperty("env.baseurl")+getBundle().getProperty("resource"));
		

	}
	
	public static void emptyArrayBodyParameter() {
		
		String BodyParameter = "[]";
		getBundle().setProperty("BodyParameter", BodyParameter);
		
	}
	
public static void emptyJsonBodyParameter() {
		
		String BodyParameter = "{}";
		getBundle().setProperty("BodyParameter", BodyParameter);
		
	}
	
	public static void invalidArrayBodyParameter() {
		String BodyParameterValue = "[\"ares63\", \"ares64\", \"ares65\",]";
		Reporter.log(BodyParameterValue);
		getBundle().setProperty("BodyParameter", BodyParameterValue);
	}
	
	public static void invalidJsonBodyParameter() {
		String BodyParameterValue = "{ \"serviceDescriptionId\": 656	,}";
		getBundle().setProperty("BodyParameter", BodyParameterValue);
	}
	
	public static void getAllStatusupdates(ClientResponse rCLient) {

		Reporter.log("Get Status is : " + rCLient.getStatus());
		Reporter.log("Get StatusInfo is : " + rCLient.getStatusInfo());
		Reporter.log("Get Type is : " + rCLient.getType());
		
		System.out.println("Get Status is : " + rCLient.getStatus());
		System.out.println("Get StatusInfo is : " + rCLient.getStatusInfo());
		System.out.println("Get Type is : " + rCLient.getType());

	}
	
	@QAFTestStep(description="validate the response")
	public void validateTheResponse(){
		ClientResponse rClient = (ClientResponse) getBundle().getProperty("rClient");
		CommonUtils.getAllStatusupdates(rClient);
	}
	
	@QAFTestStep(description="Validate the Error Response{0}")
	public void validateTheErrorResponse(String errorCode){
		
		try {
		ClientResponse rClient = (ClientResponse) getBundle().getProperty("rClient");
		CommonUtils.getAllStatusupdates(rClient);
		Assert.assertEquals(rClient.getStatus(),errorCode);
		
		} catch (Exception e) {
			Reporter.log("Exceptions :"+e);
		}
	
	}
}
