package com.heb.automation.Services.HomeDelivery.Drivers;

import java.util.ArrayList;

public class Drivers_Data {
	
	private String delayTime;

    private String phone;

    private Drivers_Vehicle vehicle = new Drivers_Vehicle();

    private String onDuty;

    private String timeCreated;

    private String[] tasks;

    private String timeLastSeen;

    private String timeLastModified;

    private String id;

    private String[] teams;

    private String organization;

    private String name;

    private String activeTask;

    private String[] metadata;

    public String getDelayTime ()
    {
        return delayTime;
    }

    public void setDelayTime (String delayTime)
    {
        this.delayTime = delayTime;
    }

    public String getPhone ()
    {
        return phone;
    }

    public void setPhone (String phone)
    {
        this.phone = phone;
    }

    public Drivers_Vehicle getVehicle ()
    {
        return vehicle;
    }

    public void setVehicle (Drivers_Vehicle vehicle)
    {
        this.vehicle = vehicle;
    }

    public String getOnDuty ()
    {
        return onDuty;
    }

    public void setOnDuty (String onDuty)
    {
        this.onDuty = onDuty;
    }

    public String getTimeCreated ()
    {
        return timeCreated;
    }

    public void setTimeCreated (String timeCreated)
    {
        this.timeCreated = timeCreated;
    }

    public String[] getTasks ()
    {
        return tasks;
    }

    public void setTasks (String[] tasks)
    {
        this.tasks = tasks;
    }

    public String getTimeLastSeen ()
    {
        return timeLastSeen;
    }

    public void setTimeLastSeen (String timeLastSeen)
    {
        this.timeLastSeen = timeLastSeen;
    }

    public String getTimeLastModified ()
    {
        return timeLastModified;
    }

    public void setTimeLastModified (String timeLastModified)
    {
        this.timeLastModified = timeLastModified;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String[] getTeams ()
    {
        return teams;
    }

    public void setTeams (String[] teams)
    {
        this.teams = teams;
    }

    public String getOrganization ()
    {
        return organization;
    }

    public void setOrganization (String organization)
    {
        this.organization = organization;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getActiveTask ()
    {
        return activeTask;
    }

    public void setActiveTask (String activeTask)
    {
        this.activeTask = activeTask;
    }

    public String[] getMetadata ()
    {
        return metadata;
    }

    public void setMetadata (String[] metadata)
    {
        this.metadata = metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [delayTime = "+delayTime+", phone = "+phone+", vehicle = "+vehicle+", onDuty = "+onDuty+", timeCreated = "+timeCreated+", tasks = "+tasks+", timeLastSeen = "+timeLastSeen+", timeLastModified = "+timeLastModified+", id = "+id+", teams = "+teams+", organization = "+organization+", name = "+name+", activeTask = "+activeTask+", metadata = "+metadata+"]";
    }

}
