package com.heb.automation.common;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.TestListenerAdapter;

public class WindTunnelUtils extends TestListenerAdapter {

	// Gets the requested timer

	public static long timerGet(RemoteWebDriver driver, String timerType) {

		String command = "mobile:timer:info";

		Map<String, String> params = new HashMap<String, String>();

		params.put("type", timerType);

		long result = (long) driver.executeScript(command, params);

		return result;

	}

	// returns ux timer

	public static long getUXTimer(RemoteWebDriver driver) {

		return timerGet(driver, "ux");

	}

	public static String reportTimer(RemoteWebDriver driver, long result, long threshold,

			String description, String name) {

		Map<String, Object> params = new HashMap<String, Object>(7);

		params.put("REPORT_TIMER_RESULT", result);

		params.put("REPORT_TIMER_THRESHOLD", threshold);

		params.put("REPORT_TIMER_DESCRIPTION", description);

		params.put("REPORT_TIMER_NAME", name);

		String status = (String) driver.executeScript("MOBILE_STATUS_TIMER_COMMAND", params);

		return status;

	}

}
