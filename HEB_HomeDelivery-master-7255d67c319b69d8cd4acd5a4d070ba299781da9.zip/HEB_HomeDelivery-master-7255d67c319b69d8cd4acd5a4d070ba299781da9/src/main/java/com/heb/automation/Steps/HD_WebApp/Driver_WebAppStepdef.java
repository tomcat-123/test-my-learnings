package com.heb.automation.Steps.HD_WebApp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.heb.automation.Pages.HD_WebApp.DriverTestPage;
import com.heb.automation.Pages.HD_WebApp.ZoneTestPage;
import com.heb.automation.common.components.PerfectoUtils;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.thoughtworks.selenium.webdriven.commands.GetAllButtons;

public class Driver_WebAppStepdef {

	@QAFTestStep(description = "User is in HomeDelivery driver page")
	public void UserIsInHomeDeliveryDriverPage() {
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getLblFirstName().waitForPresent(50000);
		driverTP.getLblFirstName().verifyPresent();
	}

	@QAFTestStep(description = "I enter valid firstName")
	public void iEnterValidFirstName() {
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getLblFirstName().sendKeys("Shiv");
	}

	@QAFTestStep(description = "I enter valid lastName")
	public void iEnterValidLastName() {
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getLblLastname().sendKeys("Krishnan");
	}

	@QAFTestStep(description = "I click serach button")
	public void iClickSerachButton() {
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getBtnSearch().click();
	}

	@QAFTestStep(description = "I see the search result for FirstName")
	public void iSeeTheSearchResultForFirstName() {
		String data = null;
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getLblTableBody().waitForPresent(1000);
		QAFWebElement tobody = driverTP.getLblTableBody();
		List<WebElement> rows = tobody.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("td"));
			for (int cnum = 0; cnum < columns.size(); cnum++) {
				data = columns.get(cnum).getText();
				break;
			}
		}
		if (data.contains("Shiv"))
			Reporter.log("Driver details are getting displayed as per the search criteria", MessageTypes.Pass);
		else
			Reporter.log("Driver details are not getting displayed as per the search criteria", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I see the search result for LastName")
	public void iSeeTheSearchResultForLastName() {
		String data = null;
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getLblTableBody().waitForPresent(1000);
		QAFWebElement tobody = driverTP.getLblTableBody();
		List<WebElement> rows = tobody.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("td"));
			for (int cnum = 1; cnum < columns.size(); cnum++) {
				data = columns.get(cnum).getText();
				break;
			}
		}
		if (data.contains("Krishnan"))
			Reporter.log("Driver details are getting displayed as per the search criteria", MessageTypes.Pass);
		else
			Reporter.log("Driver details are not getting displayed as per the search criteria", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I Press Enter Key")
	public void iPressEnterKey() {

		PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.ENTER);
	}

	@QAFTestStep(description = "I enter valid LastName with 2 Characters")
	public void iEnterValidLastNameWith2Characters() {
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getLblLastname().sendKeys("Kr");
	}

	@QAFTestStep(description = "I see the search result for LastName with 2 Characters")
	public void iSeeTheSearchResultForLastNameWith2Characters() {
		String data = null;
		DriverTestPage driverTP = new DriverTestPage();
		driverTP.getLblTableBody().waitForPresent(1000);
		QAFWebElement tobody = driverTP.getLblTableBody();
		List<WebElement> rows = tobody.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("td"));

			for (int cnum = 1; cnum < columns.size(); cnum++) {
				data = columns.get(cnum).getText();
				break;
			}
		}
		if (data.contains("Kr"))
			Reporter.log("Driver details are getting displayed as per the search criteria", MessageTypes.Pass);
		else
			Reporter.log("Driver details are not getting displayed as per the search criteria", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I Verify date field defaults to current date")
	public void iVerifyDateFieldDefaultsToCurrentDate() {
		String Currentdate = null;
		DriverTestPage driverTP = new DriverTestPage();

		Currentdate = driverTP.getLblCurrentDate().getAttribute("ng-reflect-min");
		Currentdate = Currentdate.substring(0, 15);
		System.out.println(Currentdate);

		SimpleDateFormat formatter = new SimpleDateFormat("E MMM dd yyyy");
		Date date = new Date();
		System.out.println(formatter.format(date));

		if (Currentdate.equals(formatter.format(date)))
			Reporter.log("The date field is default To CurrentDate", MessageTypes.Pass);
		else
			Reporter.log("The date field is not default To CurrentDate", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I verify past date is not allowed")
	public void iVerifyPastDateIsNotAllowed() {
		DriverTestPage driverTP = new DriverTestPage();

		try {
			driverTP.getBtnOpenCalendar().click();
			int size = driverTP.getLblpastdate().size();
			if (driverTP.getLblpastdate().get(0).isPresent()) {
				driverTP.getLblpastdate().get(size - 1).click();
				driverTP.getLblpastdate().get(size - 1).verifyPresent();
			} else {
				int size1 = driverTP.getLblpastdate().size();
				driverTP.getBtnPreviousMonth().click();
				driverTP.getLblpastdate().get(0).waitForPresent(5000);
				driverTP.getLblpastdate().get(size1 - 1).click();
				driverTP.getLblpastdate().get(size1 - 1).verifyPresent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@QAFTestStep(description = "I Verify breadcrumb is available")
	public void iVerifyBreadCrumbIsAvailable() {
		DriverTestPage driverTP = new DriverTestPage();
		driverTP.getLnkDriverCrumb().verifyPresent();
	}

	@QAFTestStep(description = "I clear Date field")
	public void iClearDateField() {
		DriverTestPage driverTP = new DriverTestPage();
		driverTP.getLblCurrentDate().click();
		driverTP.getLblCurrentDate().clear();
		PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.TAB);

	}

	@QAFTestStep(description = "I verify search is disabled")
	public void iVerifySearchIsDisabled() {
		DriverTestPage driverTP = new DriverTestPage();
		boolean serarch = driverTP.getBtnSearch().isEnabled();

		if (serarch == false)
			Reporter.log("Search Button is Disabled", MessageTypes.Pass);
		else
			Reporter.log("Search Button is not Disabled", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I verify the Driver Snapshot Page")
	public void iVerifyTheDriverSnapshotPage() {
		DriverTestPage driverTP = new DriverTestPage();
		ArrayList<String> data = new ArrayList<>();

		driverTP.getLblTitle().verifyPresent();
		driverTP.getLnkDriverCrumb().verifyPresent();
		driverTP.getLnkPaginationNum().verifyPresent();
		QAFWebElement tHead = driverTP.getLblTebleHead();
		List<WebElement> rows = tHead.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("th"));

			for (int cnum = 0; cnum < columns.size(); cnum++) {
				data.add(columns.get(cnum).getText());
			}
		}
		if (data.contains("First Name"))
			Reporter.log("Firsat Name is Avilable in Grid", MessageTypes.Pass);
		else
			Reporter.log("Firsat Name is not Avilable in Grid", MessageTypes.Fail);
		if (data.contains("Last Name"))
			Reporter.log("Last Name is Avilable in Grid", MessageTypes.Pass);
		else
			Reporter.log("Last Name is not Avilable in Grid", MessageTypes.Fail);
		if (data.contains("Phone Number"))
			Reporter.log("Phone Number is Avilable in Grid", MessageTypes.Pass);
		else
			Reporter.log("Phone Number is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("Date"))
			Reporter.log("Date is Avilable in Grid", MessageTypes.Pass);
		else
			Reporter.log("Date is not Avilable in Grid", MessageTypes.Fail);
		if (data.contains("Zone"))
			Reporter.log("Zone is Avilable in Grid", MessageTypes.Pass);
		else
			Reporter.log("Zone is not Avilable in Grid", MessageTypes.Fail);
		if (data.contains("Start Time"))
			Reporter.log("Start Time is Avilable in Grid", MessageTypes.Pass);
		else
			Reporter.log("Start Time is not Avilable in Grid", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I Verify the Left navigation")
	public void iVerifyTheLeftNavigation() {
		DriverTestPage driverTP = new DriverTestPage();
		driverTP.getLnkHamburger().click();
		driverTP.getLnkDriverSnap().waitForPresent(1000);
		driverTP.getLnkDriverSnap().verifyPresent();
		driverTP.getLnkZoneConfig().click();
		driverTP.getLnkzone().waitForPresent(1000);
		driverTP.getLnkzone().verifyPresent();
		driverTP.getLnkCity().verifyPresent();
		driverTP.getLnkDispatcher().verifyPresent();
		driverTP.getLnkMessaging().verifyPresent();
		driverTP.getLnkorder().verifyPresent();
	}

	@QAFTestStep(description = "I navigate to Zone Page")
	public void iNavigateToZonePage() {
		DriverTestPage driverTP = new DriverTestPage();
		driverTP.getLnkHamburger().click();
		driverTP.getLnkDriverSnap().waitForPresent(1000);
		driverTP.getLnkZoneConfig().click();
		driverTP.getLnkzone().waitForPresent(1000);
		driverTP.getLnkzone().click();
	}

	@QAFTestStep(description = "I verify the Zone Page")
	public void iVerifyTheZonePage() {
		DriverTestPage driverTP = new DriverTestPage();
		ZoneTestPage zPage = new ZoneTestPage();
		ArrayList<String> data = new ArrayList<>();

		driverTP.getLblTitle().waitForPresent(5000);
		driverTP.getLblTitle().verifyPresent();
		zPage.getBtnAddNew().verifyPresent();
		zPage.getLnkZoneCrumb().verifyPresent();
		driverTP.getLnkPaginationNum().verifyPresent();

		QAFWebElement tHead = driverTP.getLblTebleHead();
		List<WebElement> rows = tHead.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("th"));

			for (int cnum = 0; cnum < columns.size(); cnum++) {
				data.add(columns.get(cnum).getText());
			}
		}

		if (data.contains("Zone Name"))
			Reporter.log("Zone Name is Avilable in Grid", MessageTypes.Pass);
		else
			Reporter.log("Zone Name is not Avilable in Grid", MessageTypes.Fail);

		if (data.contains("City"))
			Reporter.log("City is Avilable in Grid", MessageTypes.Pass);
		else
			Reporter.log("City is not Avilable in Grid", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I Click Add new button")
	public void iClickAddNewButton() {
		ZoneTestPage zPage = new ZoneTestPage();
		zPage.getBtnAddNew().click();
	}

	@QAFTestStep(description = "I verify the Create Zone Page")
	public void iVerifyTheCreateZonePage() {
		ZoneTestPage zPage = new ZoneTestPage();
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getLblTitle().waitForPresent(5000);
		zPage.getLnkEditZoneCrumb().verifyPresent();
		zPage.getEdtZoneName().verifyPresent();
		zPage.getEdtZipcode().verifyPresent();
		zPage.getEdtOnFleetTeamId().verifyPresent();
		zPage.getEdtCity().verifyPresent();
		zPage.getBtnSave().verifyPresent();
		zPage.getBtnCancel().verifyPresent();
	}

	@QAFTestStep(description = "I Verify pagination defaults to page 1 and is highlighted")
	public void iVerifyPaginationDefaultsToPage1AndIsHighlighted() {
		DriverTestPage driverTP = new DriverTestPage();

		String pageNum = driverTP.getLnkPaginationNum().getText();
		int pNum = Integer.parseInt(pageNum);
		if (pNum == 1)
			Reporter.log("pagination defaults to page 1", MessageTypes.Pass);
		else
			Reporter.log("pagination not defaults to page 1", MessageTypes.Fail);

		String backColor = driverTP.getLnkPaginationNum().getCssValue("color");
		String buttonColor = driverTP.getLnkPaginationNum().getCssValue("border-color");

		if (backColor.equalsIgnoreCase(buttonColor))
			Reporter.log("Page Num is not highlighted", MessageTypes.Fail);
		else
			Reporter.log("Page Num is highlighted", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I Verify pagination has page forward and backward")
	public void iVerifyPaginationHasPageForwardAndBackward() {
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getLnkForward().verifyPresent();
		driverTP.getLnkForwardNext().verifyPresent();
		driverTP.getLnkBackWard().verifyPresent();
		driverTP.getLnkBackWardNext().verifyPresent();
	}

	@QAFTestStep(description = "I select a zone")
	public void iSelectAZone() {
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getDbpZone().click();
		driverTP.getDpdValue().waitForPresent();
		driverTP.getDpdValue().click();
	}

	@QAFTestStep(description = "I Verify Selected zone returns matching search results")
	public void iVerifyZoneReturnsMatchingSearchResults() {
		String data = null;
		DriverTestPage driverTP = new DriverTestPage();
		driverTP.getLblTableBody().waitForPresent(1000);
		QAFWebElement tobody = driverTP.getLblTableBody();
		List<WebElement> rows = tobody.findElements(By.tagName("tr"));
		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("td"));

			for (int cnum = 4; cnum < columns.size(); cnum++) {
				data = columns.get(cnum).getText();
				break;
			}
		}
		if (data.contains("Boerne/Fair Ranch"))
			Reporter.log("Zone details are getting displayed as per the search criteria", MessageTypes.Pass);
		else
			Reporter.log("Zone details are not getting displayed as per the search criteria", MessageTypes.Fail);

		ConfigurationManager.getBundle().setProperty("Boerne/Fair Ranch", data);
	}

	@QAFTestStep(description = "I Verify changing zone updates search results")
	public void iVerifyChangingZoneUpdatesSearchResults() {
		String data = null;
		DriverTestPage driverTP = new DriverTestPage();
		driverTP.getLblTableBody().waitForPresent(1000);
		QAFWebElement tobody = driverTP.getLblTableBody();
		List<WebElement> rows = tobody.findElements(By.tagName("tr"));
		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("td"));

			for (int cnum = 4; cnum < columns.size(); cnum++) {
				data = columns.get(cnum).getText();
				break;
			}
		}

		iSelectAZone();
		iVerifyZoneReturnsMatchingSearchResults();

		if (!data.equals(ConfigurationManager.getBundle().getString("Boerne/Fair Ranch")))
			Reporter.log("Changing zone updates the search results", MessageTypes.Pass);
		else
			Reporter.log("Changing zone not updates the search results", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I Verify pagination defaults to display the first 50 records per page")
	public void iVerifyPaginationDefaultsToDisplayTheFirst50RecordsPerPage() {
		ZoneTestPage ZoneTP = new ZoneTestPage();

		ZoneTP.getZoneLblTableBody().waitForPresent(1000);
		QAFWebElement tobody = ZoneTP.getZoneLblTableBody();
		List<WebElement> rows = tobody.findElements(By.tagName("tr"));

		int recordSize = rows.size();

		if (recordSize == 50)
			Reporter.log("Pagination Defaults To Display The First 50 Records Per Page", MessageTypes.Pass);
		else
			Reporter.log("Pagination Not Defaults To Display The First 50 Records Per Page", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I Verify Pagination dropdown values")
	public void iVerifyPaginationDropdownValues() {
		ZoneTestPage ZoneTP = new ZoneTestPage();

		ZoneTP.getDpdDropDown().click();
		List<QAFWebElement> lists = ZoneTP.getDpdDropDownValue();

		ArrayList<String> value = new ArrayList<>();

		for (QAFWebElement list : lists)
			value.add(list.getText());

		if (value.contains("50"))
			Reporter.log("The Value of 50 is avilable in Pagination dropdown", MessageTypes.Pass);
		else
			Reporter.log("The Value of 50 is not avilable in Pagination dropdown", MessageTypes.Fail);

		if (value.contains("100"))
			Reporter.log("The Value of 100 is avilable in Pagination dropdown", MessageTypes.Pass);
		else
			Reporter.log("The Value of 100 is not avilable in Pagination dropdown", MessageTypes.Fail);

		if (value.contains("150"))
			Reporter.log("The Value of 150 is avilable in Pagination dropdown", MessageTypes.Pass);
		else
			Reporter.log("The Value of 150 is not avilable in Pagination dropdown", MessageTypes.Fail);

		if (value.contains("200"))
			Reporter.log("The Value of 200 is avilable in Pagination dropdown", MessageTypes.Pass);
		else
			Reporter.log("The Value of 200 is not avilable in Pagination dropdown", MessageTypes.Fail);
	}

	@QAFTestStep(description = "I Click Reset button")
	public void iClickResetButton() {

		DriverTestPage driverTP = new DriverTestPage();

		PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.TAB);
		PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.TAB);
		PerfectoUtils.getDriver().getKeyboard().pressKey(Keys.ENTER);

	}

	@QAFTestStep(description = "I verify click of reset button clears search criteria")
	public void iVerifyClickOfResetButtonClearsSearchCriteria() {

		DriverTestPage driverTP = new DriverTestPage();

		if (driverTP.getLblFirstName().getText().equals(""))
			Reporter.log("First Name is Cleared", MessageTypes.Pass);
		else
			Reporter.log("First Name is not Cleared", MessageTypes.Fail);

		if (driverTP.getLblLastname().getText().equals(""))
			Reporter.log("Last Name is Cleared", MessageTypes.Pass);
		else
			Reporter.log("Last Name is not Cleared", MessageTypes.Fail);

		driverTP.getLblZoneNotSelected().isPresent();

	}

}
