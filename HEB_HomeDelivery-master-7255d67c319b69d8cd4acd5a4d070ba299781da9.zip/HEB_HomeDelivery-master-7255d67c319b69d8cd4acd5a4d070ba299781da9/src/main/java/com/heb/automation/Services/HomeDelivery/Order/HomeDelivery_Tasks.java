package com.heb.automation.Services.HomeDelivery.Order;

public class HomeDelivery_Tasks {
	
	private String lastModifiedTimestamp;

    private String shortId;

    private String externalOnFleetId;

    private String type;

    public String getLastModifiedTimestamp ()
    {
        return lastModifiedTimestamp;
    }

    public void setLastModifiedTimestamp (String lastModifiedTimestamp)
    {
        this.lastModifiedTimestamp = lastModifiedTimestamp;
    }

    public String getShortId ()
    {
        return shortId;
    }

    public void setShortId (String shortId)
    {
        this.shortId = shortId;
    }

    public String getExternalOnFleetId ()
    {
        return externalOnFleetId;
    }

    public void setExternalOnFleetId (String externalOnFleetId)
    {
        this.externalOnFleetId = externalOnFleetId;
    }

    public String getType ()
    {
        return type;
    }

    public void setType (String type)
    {
        this.type = type;
    }

}
