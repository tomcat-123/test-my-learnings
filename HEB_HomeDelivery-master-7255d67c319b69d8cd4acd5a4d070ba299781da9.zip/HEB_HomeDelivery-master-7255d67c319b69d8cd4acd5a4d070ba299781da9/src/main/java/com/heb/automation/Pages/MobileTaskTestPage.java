package com.heb.automation.Pages;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MobileTaskTestPage extends WebDriverBaseTestPage<WebDriverTestPage>{

	@FindBy(locator = "task.txt.tasklist")
	private List<QAFWebElement> tasktxttasklist;
	@FindBy(locator = "task.txt.taskdetails")
	private QAFWebElement tasktxttaskdetails;
	@FindBy(locator = "task.btn.taskcomplete")
	private QAFWebElement taskbtntaskcomplete;
	@FindBy(locator = "task.btn.slide")
	private QAFWebElement taskbtnslide;
	@FindBy(locator = "task.btn.checkboxchecked")
	private QAFWebElement taskbtncheckboxchecked;
	@FindBy(locator = "task.btn.checkboxunchecked")
	private QAFWebElement taskbtncheckboxunchecked;
	@FindBy(locator = "task.txt.failurereason")
	private QAFWebElement tasktxtfailurereason;
	@FindBy(locator = "task.btn.faliurelist")
	private List<QAFWebElement> taskbtnfaliurelist;
	@FindBy(locator = "task.btn.leftnav")
	private QAFWebElement taskbtnleftnav;	
	@FindBy(locator = "task.btn.yes")
	private QAFWebElement taskbtnyes;
	@FindBy(locator = "task.btn.cancel")
	private QAFWebElement taskbtncancel;


	@Override
	protected void openPage(PageLocator locator, Object... args) {
	}
	
	public QAFWebElement getTaskTxtTaskDetails() {
		return tasktxttaskdetails;
	}
	public QAFWebElement getTaskBtnSlide() {
		return taskbtnslide;
	}
	public QAFWebElement getTaskBtnCheckBoxChecked() {
		return taskbtncheckboxchecked;
	}
	public QAFWebElement getTaskBtnCheckBoxUnChecked() {
		return taskbtncheckboxunchecked;
	}	
	public QAFWebElement getTaskTxtFailureReason() {
		return tasktxtfailurereason;
	}
	public List<QAFWebElement> getTaskBtnFaliureList() {
		return taskbtnfaliurelist;
	}	
	public QAFWebElement getTaskBtnTaskComplete() {
		return taskbtntaskcomplete;
	}
	public List<QAFWebElement> getTaskTxtTaskList() {
		return tasktxttasklist;
	}
	public QAFWebElement getTaskBtnLeftNav() {
		return taskbtnleftnav;
	}
	public QAFWebElement getTaskBtnYes() {
		return taskbtnyes;
	}
	public QAFWebElement getTaskBtnCancel() {
		return taskbtncancel;
	}

}
