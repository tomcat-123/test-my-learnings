package com.heb.automation.Pages.HD_WebApp;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ZoneTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}

	@FindBy(locator = "zone.lnk.zoneCrumb")
	private QAFWebElement zonelnkzoneCrumb;
	
	@FindBy(locator = "zone.btn.addnew")
	private QAFWebElement zonebtnaddnew;
	
	@FindBy(locator = "zone.lnk.editZoneCrumb")
	private QAFWebElement zonelnkeditZoneCrumb;
	
	@FindBy(locator = "zone.edt.zonename")
	private QAFWebElement zoneedtzonename;
	
	@FindBy(locator = "zone.edt.onfleetTeamId")
	private QAFWebElement zoneedtonfleetTeamId;
	
	@FindBy(locator = "zone.edt.city")
	private QAFWebElement zoneedtcity;
	
	@FindBy(locator = "zone.edt.zipcode")
	private QAFWebElement zoneedtzipcode;
	
	@FindBy(locator = "zone.btn.save")
	private QAFWebElement zonebtnsave;
	
	@FindBy(locator = "zone.btn.cancel")
	private QAFWebElement zonebtncancel;
	
	@FindBy(locator = "zone.lbl.tablebody")
	private QAFWebElement zonelbltablebody;
	
	@FindBy(locator = "zone.dpd.dropdown")
	private QAFWebElement zonedpddropdown;
	
	@FindBy(locator = "zone.dpd.dropdownvalue")
	private List<QAFWebElement> zonedpddropdownvalue;
		
	public QAFWebElement getLnkEditZoneCrumb() {
		return zonelnkeditZoneCrumb;
	}
	
	public QAFWebElement getEdtZoneName() {
		return zoneedtzonename;
	}
	
	public QAFWebElement getEdtOnFleetTeamId() {
		return zoneedtonfleetTeamId;
	}
	
	public QAFWebElement getEdtCity() {
		return zoneedtcity;
	}
	
	public QAFWebElement getEdtZipcode() {
		return zoneedtzipcode;
	}
	
	public QAFWebElement getBtnSave() {
		return zonebtnsave;
	}
	
	public QAFWebElement getBtnCancel() {
		return zonebtncancel;
	}
	
	public QAFWebElement getLnkZoneCrumb() {
		return zonelnkzoneCrumb;
	}
	
	public QAFWebElement getBtnAddNew() {
		return zonebtnaddnew;
	}
	
	public QAFWebElement getZoneLblTableBody() {
		return zonelbltablebody;
	}	

	public QAFWebElement getDpdDropDown() {
		return zonedpddropdown;
	}
	
	public List<QAFWebElement> getDpdDropDownValue() {
		return zonedpddropdownvalue;
	}
		
}
