package com.heb.automation.Steps.HD_WebApp;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.heb.automation.Pages.HD_WebApp.DriverTestPage;
import com.heb.automation.Pages.HD_WebApp.EditzoneTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class Zone_WebAppStepdef {

	@QAFTestStep(description = "I Verify zone details sorted by Name in ascending alphabetical order")
	public void iVerifyZoneDetailsSortedByNameInAscendingAlphabeticalOrder() {
		String data = null;
		ArrayList<String> assending = new ArrayList<String>();
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getLblTableBody().waitForPresent(1000);
		QAFWebElement thead = driverTP.getLblTebleHead();
		List<WebElement> rows = thead.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("th"));
			for (int cnum = 0; cnum < columns.size(); cnum++) {
				columns.get(cnum).click();
				break;
			}
		}

		QAFWebElement tbody = driverTP.getLblTableBody();
		List<WebElement> rows1 = tbody.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows1.size(); rnum++) {
			List<WebElement> columns1 = rows1.get(rnum).findElements(By.tagName("td"));
			for (int cnum = 0; cnum < columns1.size(); cnum++) {
				data = columns1.get(cnum).getText();
				assending.add(data);
				break;
			}
		}

		for (int i = 0; i < assending.size() - 1; i++) {
			for (int j = i + 1; j < assending.size() - 1; j++) {

				if (assending.get(i).compareToIgnoreCase(assending.get(j)) < 0)
					Reporter.log("Zone details are sorted by Name in ascending alphabetical order ", MessageTypes.Pass);
				else
					Reporter.log("Zone details are not sorted by Name in ascending alphabetical order ",
							MessageTypes.Fail);

			}

		}

	}

	@QAFTestStep(description = "I Verify zone details sorted by Name in descending alphabetical order")
	public void iVerifyZoneDetailsSortedByNameInDescendingAlphabeticalOrder() {
		String data = null;
		ArrayList<String> assending = new ArrayList<String>();
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getLblTableBody().waitForPresent(1000);
		QAFWebElement thead = driverTP.getLblTebleHead();
		List<WebElement> rows = thead.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("th"));
			for (int cnum = 0; cnum < columns.size(); cnum++) {
				columns.get(cnum).click();
				columns.get(cnum).click();
				break;
			}
		}

		QAFWebElement tbody = driverTP.getLblTableBody();
		List<WebElement> rows1 = tbody.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows1.size(); rnum++) {
			List<WebElement> columns1 = rows1.get(rnum).findElements(By.tagName("td"));
			for (int cnum = 0; cnum < columns1.size(); cnum++) {
				data = columns1.get(cnum).getText();
				assending.add(data);
				break;
			}
		}

		for (int i = 0; i < assending.size() - 1; i++) {
			for (int j = i + 1; j < assending.size() - 1; j++) {

				if (assending.get(i).compareToIgnoreCase(assending.get(j)) > 0)
					Reporter.log("Zone details are sorted by Name in descending alphabetical order ",
							MessageTypes.Pass);
				else
					Reporter.log("Zone details are not sorted by Name in descending alphabetical order ",
							MessageTypes.Fail);

			}

		}

	}

	@QAFTestStep(description = "I Verify zone details sorted by City in ascending alphabetical order")
	public void iVerifyZoneDetailsSortedByCityInAscendingAlphabeticalOrder() {
		String data = null;
		ArrayList<String> assending = new ArrayList<String>();
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getLblTableBody().waitForPresent(1000);
		QAFWebElement thead = driverTP.getLblTebleHead();
		List<WebElement> rows = thead.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("th"));
			for (int cnum = 1; cnum < columns.size(); cnum++) {
				columns.get(cnum).click();
				break;
			}
		}

		QAFWebElement tbody = driverTP.getLblTableBody();
		List<WebElement> rows1 = tbody.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows1.size(); rnum++) {
			List<WebElement> columns1 = rows1.get(rnum).findElements(By.tagName("td"));
			for (int cnum = 1; cnum < columns1.size(); cnum++) {
				data = columns1.get(cnum).getText();
				assending.add(data);
				break;
			}
		}

		for (int i = 0; i < assending.size() - 1; i++) {
			for (int j = i + 1; j < assending.size() - 1; j++) {

				if (assending.get(i).compareToIgnoreCase(assending.get(j)) < 0)
					Reporter.log("Zone details are sorted by Name in ascending alphabetical order ", MessageTypes.Pass);
				else
					Reporter.log("Zone details are not sorted by Name in ascending alphabetical order ",
							MessageTypes.Fail);

			}

		}

	}

	@QAFTestStep(description = "I Verify zone details sorted by City in descending alphabetical order")
	public void iVerifyZoneDetailsSortedByCityInDescendingAlphabeticalOrder() {
		String data = null;
		ArrayList<String> assending = new ArrayList<String>();
		DriverTestPage driverTP = new DriverTestPage();

		driverTP.getLblTableBody().waitForPresent(1000);
		QAFWebElement thead = driverTP.getLblTebleHead();
		List<WebElement> rows = thead.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("th"));
			for (int cnum = 1; cnum < columns.size(); cnum++) {
				columns.get(cnum).click();
				columns.get(cnum).click();
				break;
			}
		}

		QAFWebElement tbody = driverTP.getLblTableBody();
		List<WebElement> rows1 = tbody.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows1.size(); rnum++) {
			List<WebElement> columns1 = rows1.get(rnum).findElements(By.tagName("td"));
			for (int cnum = 1; cnum < columns1.size(); cnum++) {
				data = columns1.get(cnum).getText();
				assending.add(data);
				break;
			}
		}

		for (int i = 0; i < assending.size() - 1; i++) {
			for (int j = i + 1; j < assending.size() - 1; j++) {

				if (assending.get(i).compareToIgnoreCase(assending.get(j)) > 0)
					Reporter.log("Zone details are sorted by Name in descending alphabetical order ",
							MessageTypes.Pass);
				else
					Reporter.log("Zone details are not sorted by Name in descending alphabetical order ",
							MessageTypes.Fail);

			}

		}

	}

	@QAFTestStep(description = "I navigate to Edit Zone Page")
	public void iNavigateToEditZonePage() {
		DriverTestPage driverTP = new DriverTestPage();
		EditzoneTestPage editZoneTP = new EditzoneTestPage();

		driverTP.getLblTableBody().waitForPresent(1000);
		QAFWebElement tbody = driverTP.getLblTableBody();
		List<WebElement> rows = tbody.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("td"));
			for (int cnum = 0; cnum < columns.size(); cnum++) {
				String ZoneName = columns.get(cnum).getText();
				ConfigurationManager.getBundle().setProperty("ZoneName", ZoneName);
				columns.get(cnum).click();
				break;
			}
			break;
		}

		editZoneTP.getBtnEdit().click();
	}

	@QAFTestStep(description = "I Verify zone is not deleted")
	public void iVerifyZoneIsNotDeleted() {
		DriverTestPage driverTP = new DriverTestPage();
		EditzoneTestPage editZoneTP = new EditzoneTestPage();

		driverTP.getLblTableBody().waitForPresent(1000);
		QAFWebElement tbody = driverTP.getLblTableBody();
		List<WebElement> rows = tbody.findElements(By.tagName("tr"));

		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("td"));
			for (int cnum = 0; cnum < columns.size(); cnum++) {
				String Zone = columns.get(cnum).getText();

				if (Zone.equals(ConfigurationManager.getBundle().getString("ZoneName"))) {
					Reporter.log("Selected Zone is not Deleted", MessageTypes.Pass);
				} else {
					Reporter.log("Selected Zone is Deleted", MessageTypes.Fail);
				}
				break;
			}
			break;
		}

	}

}
