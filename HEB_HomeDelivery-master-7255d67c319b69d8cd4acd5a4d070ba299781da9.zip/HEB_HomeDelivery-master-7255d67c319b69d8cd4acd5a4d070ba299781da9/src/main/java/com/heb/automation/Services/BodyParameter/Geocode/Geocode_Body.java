package com.heb.automation.Services.BodyParameter.Geocode;

public class Geocode_Body {
	
	 private String zip;

	    private String state;

	    private String street;

	    private String city;

	    public String getZip ()
	    {
	        return zip;
	    }

	    public void setZip (String zip)
	    {
	        this.zip = zip;
	    }

	    public String getState ()
	    {
	        return state;
	    }

	    public void setState (String state)
	    {
	        this.state = state;
	    }

	    public String getStreet ()
	    {
	        return street;
	    }

	    public void setStreet (String street)
	    {
	        this.street = street;
	    }

	    public String getCity ()
	    {
	        return city;
	    }

	    public void setCity (String city)
	    {
	        this.city = city;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [zip = "+zip+", state = "+state+", street-address = "+street+", city = "+city+"]";
	    }

}
