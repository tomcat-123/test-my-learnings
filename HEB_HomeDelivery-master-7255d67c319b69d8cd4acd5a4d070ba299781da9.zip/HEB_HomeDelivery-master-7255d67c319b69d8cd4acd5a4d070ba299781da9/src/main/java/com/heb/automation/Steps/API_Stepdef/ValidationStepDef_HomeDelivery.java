package com.heb.automation.Steps.API_Stepdef;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.ArrayList;

import org.testng.Assert;

import com.google.gson.Gson;
import com.heb.automation.ErrorMessages.ErrorMessage;
import com.heb.automation.ErrorMessages.Error_InvalidStore_Child;
import com.heb.automation.ErrorMessages.Error_InvalidStore_Root;
import com.heb.automation.ErrorMessages.InvalidAPIError;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.Dispatchers.Dispatchers_Data;
import com.heb.automation.Services.HomeDelivery.Dispatchers.Dispatchers_RootObject;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class ValidationStepDef_HomeDelivery {

	@QAFTestStep(description = "validate the HomeDeliver response for full success")
	public void validateTheHomeDeliverResponseForFullSuccess() {
		ClientResponse rClient = (ClientResponse) getBundle().getProperty("rClient");
		CommonUtils.getAllStatusupdates(rClient);
		Assert.assertEquals(rClient.getStatus(), 200);
		
	}
	
	
	
	@QAFTestStep(description = "validate the HomeDeliver response for {0} failure")
	public void validateTheHomeDeliverResponseForFailure(int errorcode) {
		ClientResponse rClient = (ClientResponse) getBundle().getProperty("rClient");
		ErrorMessage gson = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
		CommonUtils.getAllStatusupdates(rClient);
		Assert.assertNull(gson.getSuccess());
		Assert.assertEquals(rClient.getStatus(), errorcode);

	}
	
	@QAFTestStep(description = "validate the HomeDeliver response for {0} failure store")
	public void validateTheHomeDeliverResponseForFailureStore(int errorcode) {
		ClientResponse rClient = (ClientResponse) getBundle().getProperty("rClient");
		CommonUtils.getAllStatusupdates(rClient);
		Assert.assertEquals(rClient.getStatus(), errorcode);

	}
	
	@QAFTestStep(description = "validate the invalid API Error message for HomeDelivery")
	public void validateTheInvalidAPIErrorMessageForHomeDelivery() {

		ClientResponse rClient = (ClientResponse) getBundle().getProperty("rClient");
		InvalidAPIError gson = new Gson().fromJson(rClient.getEntity(String.class), InvalidAPIError.class);
		CommonUtils.getAllStatusupdates(rClient);
		Assert.assertEquals(rClient.getStatus(), 400);
		Assert.assertEquals(gson.getMessage(), "API key not valid. Please pass a valid API key.");
		Reporter.log("API key not valid. Please pass a valid API key.", MessageTypes.Pass);
	}

	@QAFTestStep(description = "validate the blank API Error message for HomeDelivery")
	public void validateTheBlankAPIErrorMessageForHomeDelivery() {

		ClientResponse rClient = (ClientResponse) getBundle().getProperty("rClient");
		InvalidAPIError gson = new Gson().fromJson(rClient.getEntity(String.class), InvalidAPIError.class);
		CommonUtils.getAllStatusupdates(rClient);
		Assert.assertEquals(rClient.getStatus(), 401);
		Assert.assertEquals(gson.getMessage(), "Method doesn't allow unregistered callers (callers without established identity). Please use API Key or other form of API consumer identity to call this API.");
		Reporter.log("Method doesn't allow unregistered callers (callers without established identity). Please use API Key or other form of API consumer identity to call this API.", MessageTypes.Pass);
	}
	
	@QAFTestStep(description = "Validate the response for Full success of HomeDelivery Team update")
	public void validateTheResponseForFullSuccessOfHomeDeliveryTeamUpdate() throws Exception {

		ClientResponse rClient = (ClientResponse) getBundle().getProperty("rClient");
		CommonUtils.getAllStatusupdates(rClient);
		HomeDelivery_ReusableUtils.compareHomeDeliveryTeamActualandExpected();

	}
	
	@QAFTestStep(description = "Validate the response for Full success of HomeDelivery GeoCode update")
	public void validateTheResponseForFullSuccessOfHomeDeliveryGeoCodeUpdate() throws Exception {

		ClientResponse rClient = (ClientResponse) getBundle().getProperty("rClient");
		CommonUtils.getAllStatusupdates(rClient);
		HomeDelivery_ReusableUtils.compareHomeDeliveryGeocodeActualandExpected();

	}
	
	@QAFTestStep(description = "Validate the response for Full success of HomeDelivery Dispatcher update")
	public void validateTheResponseForFullSuccessOfHomeDeliveryDispatcherUpdate() throws Exception {

		ClientResponse rClient = (ClientResponse) getBundle().getProperty("rClient");
		CommonUtils.getAllStatusupdates(rClient);
		HomeDelivery_ReusableUtils.compareHomeDeliveryDispatcherActualandExpected();

	}
	
	@QAFTestStep(description = "Validate the response for Full success of HomeDelivery Driver update")
	public void validateTheResponseForFullSuccessOfHomeDeliveryDriverUpdate() throws Exception {

		ClientResponse rClient = (ClientResponse) getBundle().getProperty("rClient");
		CommonUtils.getAllStatusupdates(rClient);
		HomeDelivery_ReusableUtils.compareHomeDeliveryDriverActualandExpected();

	}

}
