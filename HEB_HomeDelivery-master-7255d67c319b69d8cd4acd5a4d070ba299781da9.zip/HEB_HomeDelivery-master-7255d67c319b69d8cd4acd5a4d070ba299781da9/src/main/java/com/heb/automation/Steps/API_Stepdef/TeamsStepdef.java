package com.heb.automation.Steps.API_Stepdef;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.heb.automation.ErrorMessages.ErrorMessage;
import com.heb.automation.Services.BodyParameter.Teams.Teams_Body;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_Success;
import com.heb.automation.Services.HomeDelivery.ServiceUtils;
import com.heb.automation.Services.HomeDelivery.Teams.Teams_Post;
import com.heb.automation.Services.HomeDelivery.Teams.Teams_RootObject;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class TeamsStepdef {
	
	@QAFTestStep(description = "User with Invalid APIkey for HomeDelivery")
	public void userWithInvalidAPIkeyForAppInfo() {
		HomeDelivery_ReusableUtils.InvalidApi_Common_headers();
	}

	@QAFTestStep(description = "User with Blank APIkey for HomeDelivery")
	public void userWithBlankAPIkeyForAppInfo() {
		HomeDelivery_ReusableUtils.BlankApi_Common_headers();
	}
	
	@QAFTestStep(description = "User with valid APIkey for HomeDelivery")
	public void userWithValidAPIkeyForAppInfo() {
		HomeDelivery_ReusableUtils.Common_headers();
	}
		
	@QAFTestStep(description = "Build URL for read all the HomeDelivery teams")
	public void buildURLForReadAllTheHomeDeliverTeams() {
		String baseurl = getBundle().getString("HomeDelivery.adminPortal");
		String resource = getBundle().getString("HomeDelivery.endpoint.getTeams");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for read HomeDelivery team using teamId")
	public void buildURLForReadHomeDeliverTeamUsingTeamId() {
		String baseurl = getBundle().getString("HomeDelivery.adminPortal");
		String resource = getBundle().getString("HomeDelivery.endpoint.getTeams")+"/"+getBundle().getString("TeamID");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for Creating HomeDelivery team")
	public void buildURLForCreatingHomeDeliveryTeam() {
		String baseurl = getBundle().getString("HomeDelivery.adminPortal");
		String resource = getBundle().getString("HomeDelivery.endpoint.getTeams");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for Delete HomeDelivery team")
	public void buildURLForDeleteHomeDeliveryTeam() {
		String baseurl = getBundle().getString("HomeDelivery.adminPortal");
		String resource = getBundle().getString("HomeDelivery.endpoint.getTeams")+"/"+getBundle().getString("TeamID");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for Delete HomeDelivery team with invalid Id")
	public void buildURLForDeleteHomeDeliveryTeamWithInvalidId() {
		String baseurl = getBundle().getString("HomeDelivery.adminPortal");
		String resource = getBundle().getString("HomeDelivery.endpoint.getTeams")+"/Llh61RFjeqVXnnRFJRW6Nk";
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter for creating HomeDelivery team")
	public void userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryTeam() throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm =new ObjectMapper();
		pr.setName(getName());
		pr.setHub(null);
		pr.setId(null);
		pr.setManagers(null);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :"+jsonInString);
		System.out.println("Full body paramter is : "+ jsonInString);
		
		getBundle().setProperty("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter with all values for creating HomeDelivery team")
	public void userUsesAnArrayOfBodyParameterWithAllValuesForCreatingHomeDeliveryTeam() throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm =new ObjectMapper();
		
/*		List<String> workers = new ArrayList<>();
		List<String> managers = new ArrayList<>();		
		List<String> tasks = new ArrayList<>();

		String worker1 = getBundle().getString("DispatcherID");
		String worker2 = getBundle().getString("DispatcherID2");
		String worker3 = getBundle().getString("DispatcherID3");
		
		workers.add(getBundle().getString("DispatcherID"));				
		managers.add(getBundle().getString("DispatcherID"));
		tasks.add("G3fCaTlfCSUVv2sW*3pY9TAE");
		tasks.add("fJPOvPLD85LRHEQyMTbo3oso");
		tasks.add("K3~PYGcXb*amQtjTjX7IZK8I");*/
		
		List<String> batchPostDispatcherID = new ArrayList<>();
		List<String> batchPostDriverID = new ArrayList<>();
		
		batchPostDispatcherID = (List<String>) getBundle().getProperty("DispatcherIDList");
		//batchPostDispatcherID.add(getBundle().getString("DispatcherIDList"));
		//batchPostDispatcherID.add(getBundle().getProperty("DispatcherIDList"));
		batchPostDriverID = (List<String>) getBundle().getProperty("DriverIDList");
		//batchPostDriverID.add(getBundle().getString("DriverIDList"));
		//batchPostDriverID.add(getBundle().getProperty("DriverIDList"));
		
		pr.setName(getName());
		pr.setHub(null);
		pr.setId(null);
		pr.setManagers(batchPostDispatcherID);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(batchPostDriverID);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :"+jsonInString);
		System.out.println("Full body paramter is : "+ jsonInString);
		
		getBundle().setProperty("BodyParameter", jsonInString);
	}
	

	@QAFTestStep(description = "User uses a Body Parameter with team name More than Fiftycharacters for creating HomeDelivery team")
	public void userUsesABodyParameterWithTeamNameMoreThanFiftycharactersForCreatingHomeDeliveryTeam()
			throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getNameMoreThan50Characters());
		pr.setHub(null);
		pr.setId(null);
		pr.setManagers(null);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses a Body Parameter with team ID More than Thirtycharacters for creating HomeDelivery team")
	public void userUsesABodyParameterWithTeamIDMoreThanThirtycharactersForCreatingHomeDeliveryTeam()
			throws JsonProcessingException {

		String thirtyCharTeamId = getBundle().getString("TeamID") + "Invalid";
		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getName());
		pr.setHub(null);
		pr.setId(thirtyCharTeamId);
		pr.setManagers(null);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Missing Body Parameter for creating HomeDelivery team")
	public void userUsesAnArrayOfMissingBodyParameterForCreatingHomeDeliveryTeam() throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(null);
		pr.setHub(null);
		pr.setId(null);
		pr.setManagers(null);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(null);
		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Existing Body Parameter for creating HomeDelivery team")
	public void userUsesAnArrayOfExistingBodyParameterForCreatingHomeDeliveryTeam() throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getBundle().getString("TeamName"));
		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Team body parameter contains all valid editable fields")
	public void userUPDATEHomeDeliveryTeamBodyParameterContainsAllValidEditableFields() throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getName());
		pr.setHub(null);
		pr.setId(getBundle().getString("TeamID"));
		pr.setManagers(null);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Team body parameter contains only optional fields")
	public void userUPDATEHomeDeliveryTeamBodyParameterContainsOnlyOptionalFields() throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(null);
		pr.setHub(null);
		pr.setId(getBundle().getString("TeamID"));
		pr.setManagers(null);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Team body parameter contains duplicate team name")
	public void userUPDATEHomeDeliveryTeamBodyParameterContainsDuplicateTeamName() throws JsonProcessingException {

		Teams_Body pr = new Teams_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getBundle().getString("TeamName"));
		pr.setHub(null);
		pr.setId(getBundle().getString("TeamID"));
		pr.setManagers(null);
		pr.setTasks(null);
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);
		pr.setWorkers(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User GET response call for HomeDelivery teams")
	public static void userGETResponseCallForHomeDeliverTeams() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Teams");
				getBundle().setProperty("rClient", rClient);

				Teams_RootObject gson1 = new Gson().fromJson(rClient.getEntity(String.class), Teams_RootObject.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String TeamID = gson1.getData().get(0).getId();
				String TeamName = gson1.getData().get(0).getName();
				getBundle().setProperty("TeamID", TeamID);
				getBundle().setProperty("TeamName", TeamName);
				Reporter.log("Read Success-HomeDelivery Teams ID: " + TeamID);
				Reporter.log("Read Success-HomeDelivery Teams Name: " + TeamName);
				System.out.println("Read Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Read Success-HomeDelivery Teams Name: " + TeamName);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			getBundle().setProperty("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "User POST the Create HomeDelivery team call")
	public void userPOSTTheCreateHomeDeliveryTeamCall() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		try {
			RESPONSE = ServiceUtils.POST(headers, bodyParam);
			if (RESPONSE.getStatus() == 200) {

				Reporter.log("Teams is created ");
				getBundle().setProperty("rClient", RESPONSE);

				Teams_Post gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class), Teams_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String TeamID = gson1.getData().getId();
				String TeamName = gson1.getData().getName();
				getBundle().setProperty("TeamID", TeamID);
				getBundle().setProperty("TeamName", TeamName);
				Reporter.log("Created Success-HomeDelivery Teams ID: " + TeamID);
				Reporter.log("Created Success-HomeDelivery Teams Name: " + TeamName);
				System.out.println("Created Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Created Success-HomeDelivery Teams Name: " + TeamName);
			}
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("Team created with failed  " + 400);
				Reporter.log(RESPONSE.toString());
				getBundle().setProperty("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 503) {
				Reporter.log("Team created with failed  " + 503);
				Reporter.log(RESPONSE.toString());
				getBundle().setProperty("rClient", RESPONSE);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User GET response call for Specific HomeDelivery teams")
	public static void userGETResponseCallForSpecificHomeDeliverTeams() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Teams");
				getBundle().setProperty("rClient", rClient);

				Teams_Post gson1 = new Gson().fromJson(rClient.getEntity(String.class), Teams_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String TeamID = gson1.getData().getId();
				String TeamName = gson1.getData().getName();
				getBundle().setProperty("TeamID", TeamID);
				getBundle().setProperty("TeamName", TeamName);
				Reporter.log("Read Success-HomeDelivery Teams ID: " + TeamID);
				Reporter.log("Read Success-HomeDelivery Teams Name: " + TeamName);
				System.out.println("Read Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Read Success-HomeDelivery Teams Name: " + TeamName);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			getBundle().setProperty("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "User PUT the Update HomeDelivery Team call")
	public void userPUTTheUpdateHomeDeliveryTeamCall() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			RESPONSE = ServiceUtils.PUT(headers, bodyParam);
			if (RESPONSE.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Team is updated ");
				getBundle().setProperty("rClient", RESPONSE);

				Teams_Post gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class), Teams_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String TeamID = gson1.getData().getId();
				String TeamName = gson1.getData().getName();
				getBundle().setProperty("TeamID", TeamID);
				getBundle().setProperty("Updated_TeamName", TeamName);
				Reporter.log("Update Success-HomeDelivery Teams ID: " + TeamID);
				Reporter.log("Update Success-HomeDelivery Teams Name: " + TeamName);
				System.out.println("Update Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Update Success-HomeDelivery Teams Name: " + TeamName);
			}
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("HomeDelivery Team creation failed  ");
				getBundle().setProperty("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 404) {
				Reporter.log("HomeDelivery Team creation failed  ");
				getBundle().setProperty("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 401) {
				Reporter.log("HomeDelivery Teams creation failed  ");
				getBundle().setProperty("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 503) {
				Reporter.log("HomeDelivery Teams creation failed  ");
				getBundle().setProperty("rClient", RESPONSE);

			}			
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	@QAFTestStep(description = "User DELETE the HomeDelivery Team DELETE call")
	public void userDELETETheHomeDeliveryTeamDELETECall() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		try {
			RESPONSE = ServiceUtils.DELETE(headers, bodyParam);
			if (RESPONSE.getStatus() == 200) {

				Reporter.log("HomeDelivery Team is deleted ");
				getBundle().setProperty("rClient", RESPONSE);

				HomeDelivery_Success gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class),
						HomeDelivery_Success.class);
				getBundle().setProperty("rGSON", gson1);
				System.out.println(" : " + gson1.getApiStatus());
				Reporter.log("Deleted HomeDelivery Team : " + gson1.getApiStatus());
			}
			if (RESPONSE.getStatus() == 207) {
				Reporter.log("HomeDelivery team Deletion with Partial success  ");
				getBundle().setProperty("rClient", RESPONSE);
				ErrorMessage gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class), ErrorMessage.class);
				getBundle().setProperty("rGSON", gson1);
			}

			if (RESPONSE.getStatus() == 400) {
				Reporter.log("HomeDelivery team Deletion failed with 400");
				getBundle().setProperty("rClient", RESPONSE);
			}

			if (RESPONSE.getStatus() == 404) {
				Reporter.log("HomeDelivery team Deletion failed with 404");
				getBundle().setProperty("rClient", RESPONSE);
			}
			if (RESPONSE.getStatus() == 401) {
				Reporter.log("HomeDelivery team Deletion failed with 401");
				getBundle().setProperty("rClient", RESPONSE);
			}
			if (RESPONSE.getStatus() == 503) {
				Reporter.log("HomeDelivery team Deletion failed with 503");
				getBundle().setProperty("rClient", RESPONSE);
			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("HomeDelivery team Deletion failed with 400");
				getBundle().setProperty("rClient", RESPONSE);
			}

		}
	}

	@QAFTestStep(description = "User POST the Create HomeDelivery team calls")
	public void userPOSTTheCreateHomeDeliveryTeamCalls() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		try {
			RESPONSE = ServiceUtils.POST(headers, bodyParam);
			if (RESPONSE.getStatus() == 200) {

				Reporter.log("Teams is created ");
				getBundle().setProperty("rClient", RESPONSE);

				Teams_Post gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class), Teams_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String TeamID = gson1.getData().getId();
				String TeamName = gson1.getData().getName();
				getBundle().setProperty("TeamID", TeamID);
				Reporter.log("Created Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Created Success-HomeDelivery Teams ID: " + TeamID);

			}
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("Team created with failed  " + 400);
				Reporter.log(RESPONSE.toString());
				getBundle().setProperty("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 503) {
				Reporter.log("Team created with failed  " + 503);
				Reporter.log(RESPONSE.toString());
				getBundle().setProperty("rClient", RESPONSE);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}

	public static String getName() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "name_" + name.substring(3, name.length());

	}

	public static String getNameMoreThan50Characters() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "team name more than 50 characters in length should return an exception"
				+ name.substring(3, name.length());

	}

	@QAFTestStep(description = "validate the response schema with GET Teams")
	public static void validateTheResponseSchemaWithGETTeams() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Teams");
				getBundle().setProperty("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				getBundle().setProperty(RESPONSE, "RESPONSE");

				Teams_RootObject gson1 = new Gson().fromJson(RESPONSE, Teams_RootObject.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String TeamID = gson1.getData().get(0).getId();
				getBundle().setProperty("TeamID", TeamID);
				Reporter.log("Read Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Read Success-HomeDelivery Teams ID: " + TeamID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "GET_TEAMS");
				HomeDelivery_ReusableUtils.validateJSONschema("Teams_GET", "GET_TEAMS");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			getBundle().setProperty("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "validate the response schema with GET Team")
	public static void validateTheResponseSchemaWithGETTeam() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Teams");
				getBundle().setProperty("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				getBundle().setProperty(RESPONSE, "RESPONSE");

				Teams_Post gson1 = new Gson().fromJson(RESPONSE, Teams_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String TeamID = gson1.getData().getId();
				String TeamName = gson1.getData().getName();
				getBundle().setProperty("TeamID", TeamID);
				getBundle().setProperty("TeamName", TeamName);
				Reporter.log("Read Success-HomeDelivery Teams ID: " + TeamID);
				Reporter.log("Read Success-HomeDelivery Teams Name: " + TeamName);
				System.out.println("Read Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Read Success-HomeDelivery Teams Name: " + TeamName);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "GET_TEAM");
				HomeDelivery_ReusableUtils.validateJSONschema("Team_GET", "GET_TEAM");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			getBundle().setProperty("errorStatusCode", errorStatusCode);

		}
	}
	
	@QAFTestStep(description = "validate the response schema with POST Team")
	public void validateTheResponseSchemaWithPOSTTeam() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			if (rClient.getStatus() == 200) {

				Reporter.log("Teams is created ");
				getBundle().setProperty("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				getBundle().setProperty(RESPONSE, "RESPONSE");
				
				Teams_Post gson1 = new Gson().fromJson(RESPONSE, Teams_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String TeamID = gson1.getData().getId();
				getBundle().setProperty("TeamID", TeamID);
				Reporter.log("Created Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Created Success-HomeDelivery Teams ID: " + TeamID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "POST_TEAM");
				HomeDelivery_ReusableUtils.validateJSONschema("Team_POST", "POST_TEAM");			
				
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Team created with failed  " + 400);
				Reporter.log(rClient.toString());
				getBundle().setProperty("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	@QAFTestStep(description = "validate the response schema with PUT Team")
	public void validateTheResponseSchemaWithPUTTeam() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			rClient = ServiceUtils.PUT(headers, bodyParam);
			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Team is updated ");
				getBundle().setProperty("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				getBundle().setProperty(RESPONSE, "RESPONSE");

				Teams_Post gson1 = new Gson().fromJson(RESPONSE, Teams_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String TeamID = gson1.getData().getId();
				getBundle().setProperty("TeamID", TeamID);
				Reporter.log("Update Success-HomeDelivery Teams ID: " + TeamID);
				System.out.println("Update Success-HomeDelivery Teams ID: " + TeamID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "PUT_TEAM");
				HomeDelivery_ReusableUtils.validateJSONschema("Team_PUT", "PUT_TEAM");
				
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Teams created with failed  ");
				getBundle().setProperty("rClient", rClient);

			}
			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery Teams created with failed  ");
				getBundle().setProperty("rClient", rClient);

			}

		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}


}
