package com.heb.automation.ErrorMessages;

import java.util.List;

public class ErrorMessage {
    private Message message;

    private String timestamp;

    private Errors[] errors;

    private String error;

    private String status;

    private String exception;

    private String path;
    
    private List<String> success;

    public Message getMessage ()
    {
        return message;
    }

    public void setMessage (Message message)
    {
        this.message = message;
    }

    public String getTimestamp ()
    {
        return timestamp;
    }

    public void setTimestamp (String timestamp)
    {
        this.timestamp = timestamp;
    }

    public Errors[] getErrors ()
    {
        return errors;
    }

    public void setErrors (Errors[] errors)
    {
        this.errors = errors;
    }

    public String getError ()
    {
        return error;
    }

    public void setError (String error)
    {
        this.error = error;
    }

    public String getStatus ()
    {
        return status;
    }

    public void setStatus (String status)
    {
        this.status = status;
    }

    public String getException ()
    {
        return exception;
    }

    public void setException (String exception)
    {
        this.exception = exception;
    }

    public String getPath ()
    {
        return path;
    }

    public void setPath (String path)
    {
        this.path = path;
    }

	public List<String> getSuccess() {
		return success;
	}

	public void setSuccess(List<String> success) {
		this.success = success;
	}


}
