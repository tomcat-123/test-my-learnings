package com.heb.automation.Services.BodyParameter.Order;

import java.util.ArrayList;
import java.util.List;

public class Order {
	
	private String external_id;

    private Store store = new Store();

    private String invoice;

    private Customer customer = new Customer();

    private List<Notes> notes = new ArrayList<Notes>();

    private String gross_bill;

    private String tip;

    public String getExternal_id ()
    {
        return external_id;
    }

    public void setExternal_id (String external_id)
    {
        this.external_id = external_id;
    }

    public Store getStore ()
    {
        return store;
    }

    public void setStore (Store store)
    {
        this.store = store;
    }

    public String getInvoice ()
    {
        return invoice;
    }

    public void setInvoice (String invoice)
    {
        this.invoice = invoice;
    }

    public Customer getCustomer ()
    {
        return customer;
    }

    public void setCustomer (Customer customer)
    {
        this.customer = customer;
    }

    public List<Notes> getNotes ()
    {
        return notes;
    }

    public void setNotes (List<Notes> notes)
    {
        this.notes = notes;
    }

    public String getGross_bill ()
    {
        return gross_bill;
    }

    public void setGross_bill (String gross_bill)
    {
        this.gross_bill = gross_bill;
    }

    public String getTip ()
    {
        return tip;
    }

    public void setTip (String tip)
    {
        this.tip = tip;
    }

}
