package com.heb.automation.Services.HomeDelivery.Dispatchers;

import java.util.ArrayList;



public class Dispatchers_RootObject {
	
	private String apiStatus;

	private ArrayList<Dispatchers_Data> data = new ArrayList<Dispatchers_Data>();

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

    public ArrayList<Dispatchers_Data> getData ()
    {
        return data;
    }

    public void setData (ArrayList<Dispatchers_Data> data)
    {
        this.data = data;
    }

}
