package com.heb.automation.Services.BodyParameter.Order;

public class Delivery_to {
	
	private String zip;

    private String state;

    private String address_1;

    private String address_2;

    private String note;

    private String city;

    public String getZip ()
    {
        return zip;
    }

    public void setZip (String zip)
    {
        this.zip = zip;
    }

    public String getState ()
    {
        return state;
    }

    public void setState (String state)
    {
        this.state = state;
    }

    public String getAddress_1 ()
    {
        return address_1;
    }

    public void setAddress_1 (String address_1)
    {
        this.address_1 = address_1;
    }

    public String getAddress_2 ()
    {
        return address_2;
    }

    public void setAddress_2 (String address_2)
    {
        this.address_2 = address_2;
    }

    public String getNote ()
    {
        return note;
    }

    public void setNote (String note)
    {
        this.note = note;
    }

    public String getCity ()
    {
        return city;
    }

    public void setCity (String city)
    {
        this.city = city;
    }

}
