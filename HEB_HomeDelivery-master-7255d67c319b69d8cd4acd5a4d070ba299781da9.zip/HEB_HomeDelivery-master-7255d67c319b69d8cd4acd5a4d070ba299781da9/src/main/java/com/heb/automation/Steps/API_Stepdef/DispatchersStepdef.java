package com.heb.automation.Steps.API_Stepdef;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.heb.automation.ErrorMessages.ErrorMessage;
import com.heb.automation.Services.BodyParameter.Dispatcher.Dispatcher_Body;
import com.heb.automation.Services.BodyParameter.Teams.Teams_Body;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_Success;
import com.heb.automation.Services.HomeDelivery.ServiceUtils;
import com.heb.automation.Services.HomeDelivery.Dispatchers.Dispatchers_Post;
import com.heb.automation.Services.HomeDelivery.Dispatchers.Dispatchers_RootObject;
import com.heb.automation.Services.HomeDelivery.Teams.Teams_Post;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientResponse;

public class DispatchersStepdef {

	@QAFTestStep(description = "Build URL for read all the HomeDelivery dispatchers")
	public void buildURLForReadAllTheHomeDeliverDispatchers() {
		String baseurl = getBundle().getString("HomeDelivery.adminPortal");
		String resource = getBundle().getString("HomeDelivery.endpoint.getDispatchers");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for Delete the HomeDelivery dispatchers")
	public void buildURLForDeleteHomeDeliverDispatchers() {
		String baseurl = getBundle().getString("HomeDelivery.adminPortal");
		String resource = getBundle().getString("HomeDelivery.endpoint.getDispatchers")+"/"+getBundle().getString("DispatcherID");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for Delete the HomeDelivery dispatchers with invaldID")
	public void buildURLForDeleteHomeDeliverDispatchersWithInvaldID() {
		String baseurl = getBundle().getString("HomeDelivery.adminPortal");
		String resource = getBundle().getString("HomeDelivery.endpoint.getDispatchers")+"/15465";
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "User uses an array of Body Parameter for creating HomeDelivery Dispatcher")
	public void userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryDispatcher() throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getDispaterName());
		pr.setEmail(geteMail());
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User uses an array of Body Parameter with all mandatory and optional fields for creating HomeDelivery Dispatcher")
	public void userUsesAnArrayOfBodyParameterWithAllMandatoryAndOptionalFieldsForCreatingHomeDeliveryDispatcher() throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getDispaterName());
		pr.setEmail(geteMail());
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Missing eMail Body Parameter for creating HomeDelivery Dispatcher")
	public void userUsesAnArrayOfMissingeMailBodyParameterForCreatingHomeDeliveryDispatcher()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getName());
		pr.setEmail(null);
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of Missing Body Parameter for creating HomeDelivery Dispatcher")
	public void userUsesAnArrayOfMissingBodyParameterForCreatingHomeDeliveryDispatcher()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(null);
		pr.setEmail(null);
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User uses an array of existing eMail Body Parameter for creating HomeDelivery Dispatcher")
	public void userUsesAnArrayOfExistingeMailBodyParameterForCreatingHomeDeliveryDispatcher()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getDispaterName());
		pr.setEmail(getBundle().getString("DispatchereMail"));
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User UPDATE HomeDelivery Dispatcher body parameter contains all valid editable fields")
	public void userUPDATEHomeDeliveryDispatcherBodyParameterContainsAllValidEditableFields()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getDispaterName());
		pr.setEmail(getBundle().getString("DispatchereMail"));
		pr.setId(getBundle().getString("DispatcherID"));
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User UPDATE HomeDelivery Dispatcher body parameter contains only optional fields")
	public void userUPDATEHomeDeliveryDispatcherBodyParameterContainsOnlyOptionalFields()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getDispaterName());
		pr.setEmail("");
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User UPDATE HomeDelivery Dispatcher Missing Name body parameter")
	public void userUPDATEHomeDeliveryDispatcherMissingNameBodyParameter()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName("");
		pr.setEmail(getBundle().getString("DispatchereMail"));
		pr.setId(getBundle().getString("DispatcherID"));
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}
	
	@QAFTestStep(description = "User UPDATE HomeDelivery Dispatcher body parameter contains duplicate email id")
	public void userUPDATEHomeDeliveryDispatcherBodyParameterDuplicateEmailId()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getBundle().getString("DispatchereName"));
		pr.setEmail(getBundle().getString("DispatchereMail"));
		pr.setId(getBundle().getString("DispatcherID"));
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("CHoosen Name is  :" + jsonInString);
		System.out.println("Full body paramter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);
	}

	@QAFTestStep(description = "User GET response call for HomeDelivery dispatchers")
	public static void userGETResponseCallForHomeDeliverDispatchers() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Dispatchers");
				getBundle().setProperty("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				getBundle().setProperty(RESPONSE, "RESPONSE");
				
				Dispatchers_RootObject gson1 = new Gson().fromJson(RESPONSE,
						Dispatchers_RootObject.class);
				System.out.println("RESPONSE is "+ RESPONSE);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String DispatcherID = gson1.getData().get(0).getId();
				getBundle().setProperty("DispatcherID", DispatcherID);
				Reporter.log("Read Success-HomeDelivery Dispatchers ID: " + DispatcherID);
				System.out.println("Read Success-HomeDelivery Dispatchers ID: " + DispatcherID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			getBundle().setProperty("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "User POST the Create HomeDelivery Dispatcher call")
	public void userPOSTTheCreateHomeDeliveryDispatcherCall() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			if (rClient.getStatus() == 200) {

				Reporter.log("Dispatcher is created ");
				getBundle().setProperty("rClient", rClient);

				Dispatchers_Post gson1 = new Gson().fromJson(rClient.getEntity(String.class), Dispatchers_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String DispatcherID = gson1.getData().getId();
				String DispatchereMail = gson1.getData().getEmail();
				getBundle().setProperty("DispatcherID", DispatcherID);
				getBundle().setProperty("DispatchereMail", DispatchereMail);				
				Reporter.log("Created Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				Reporter.log("Created Success-HomeDelivery Dispatcher eMail: " + DispatchereMail);
				System.out.println("Created Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				System.out.println("Created Success-HomeDelivery Dispatcher eMail: " + DispatchereMail);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Dispatcher creation failed  " + 400);
				Reporter.log(rClient.toString());
				getBundle().setProperty("rClient", rClient);

			}
			if (rClient.getStatus() == 503) {
				Reporter.log("Dispatcher creation failed  " + 503);
				Reporter.log(rClient.toString());
				getBundle().setProperty("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			System.out.println(e);
		}
	}
	
	@QAFTestStep(description = "User POST the Create HomeDelivery Dispatcher calls")
	public void userPOSTTheCreateHomeDeliveryDispatcherCalls() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			if (rClient.getStatus() == 200) {

				Reporter.log("Dispatcher is created ");
				getBundle().setProperty("rClient", rClient);

				Dispatchers_Post gson1 = new Gson().fromJson(rClient.getEntity(String.class), Dispatchers_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String DispatcherID = gson1.getData().getId();
				String DispatchereName = gson1.getData().getName();
				getBundle().setProperty("DispatcherID", DispatcherID);
				getBundle().setProperty("DispatchereName", DispatchereName);
				Reporter.log("Created Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				Reporter.log("Created Success-HomeDelivery Dispatcher Name: " + DispatchereName);
				System.out.println("Created Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				System.out.println("Created Success-HomeDelivery Dispatcher Name: " + DispatchereName);
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Team created with failed  " + 400);
				Reporter.log(rClient.toString());
				getBundle().setProperty("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			System.out.println(e);
		}
	}
	
	@QAFTestStep(description="User uses batch POST to Create Multiple HomeDelivery Dispatcher calls {0}")
	public void userUsesBatchPOSTToCreateMultipleHomeDeliveryDispatcherCalls(int batchCount){
		int batchPostCount = batchCount;
		//String[] dispatcherID = new String[batchPostCount];
		List<String> dispatcherID = new ArrayList<>();
		
		for (int i=1; i<=batchPostCount; i++) {
			
			try {
				
				userUsesAnArrayOfBodyParameterForCreatingHomeDeliveryDispatcher();
				userPOSTTheCreateHomeDeliveryDispatcherCall();
				
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			
			//dispatcherID[i] = getBundle().getString("DispatcherID");
			dispatcherID.add(getBundle().getString("DispatcherID"));
			System.out.println("Dispatcher is :" + dispatcherID);
			
		}
		
		getBundle().setProperty("DispatcherIDList", dispatcherID);
		System.out.println("Final Dispatcher is :" + getBundle().getProperty("DispatcherIDList"));
	}
	
	@QAFTestStep(description="Get the List of Dispatchers")
	public void getTheListOfDispatchers(){
	
	HomeDelivery_ReusableUtils.GetAllDispatcherID();
	
	}

	public static String getName() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "Automation_" + name.substring(3, name.length());
	}

	public static String getNameMoreThan101Characters() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "Automation dispatcher name more than 101 characters in length should return an exception " + name.substring(3, name.length());
	}
	
	public static String geteMail() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "automation_" + name.substring(3, name.length()) + "@heb.com";
	}

	public static String geteMailInvalidFormatMoreThan50Characters() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String name = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "automation_morethan50_characters_" + name.substring(3, name.length()) + "@heb.com";
	}	
	
	public static String getDispaterName() {

		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 10;
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();

		return "automation" + generatedString;

	}

	@QAFTestStep(description = "User PUT the Update HomeDelivery Dispatcher call")
	public void userPUTTheUpdateHomeDeliveryDispatcherCall() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			RESPONSE = ServiceUtils.PUT(headers, bodyParam);
			if (RESPONSE.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Dispatcher is updated ");
				getBundle().setProperty("rClient", RESPONSE);

				Dispatchers_Post gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class), Dispatchers_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String DispatcherID = gson1.getData().getId();
				String DispatchereMail = gson1.getData().getEmail();
				String DispatchereName = gson1.getData().getName();
				getBundle().setProperty("DispatcherID", DispatcherID);
				getBundle().setProperty("DispatchereMail", DispatchereMail);
				getBundle().setProperty("Updated_DispatchereName", DispatchereName);
				Reporter.log("Update Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				Reporter.log("Update Success-HomeDelivery Dispatcher Name: " + DispatchereName);
				Reporter.log("Update Success-HomeDelivery Dispatcher eMail: " + DispatchereMail);
				System.out.println("Update Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				System.out.println("Update Success-HomeDelivery Dispatcher Name: " + DispatchereName);
				System.out.println("Update Success-HomeDelivery Dispatcher eMail: " + DispatchereMail);
			}
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("HomeDelivery dispatcher update failed  ");
				getBundle().setProperty("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 404) {
				Reporter.log("HomeDelivery dispatcher update failed  ");
				getBundle().setProperty("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 401) {
				Reporter.log("HomeDelivery dispatcher update failed  ");
				getBundle().setProperty("rClient", RESPONSE);

			}
			if (RESPONSE.getStatus() == 503) {
				Reporter.log("HomeDelivery dispatcher update failed  ");
				getBundle().setProperty("rClient", RESPONSE);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
		}
	}
	
	@QAFTestStep(description = "User DELETE the HomeDelivery Dispatcher DELETE call")
	public void userDELETETheHomeDeliveryDispatcherDELETECall() {
		ClientResponse RESPONSE = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		try {
			RESPONSE = ServiceUtils.DELETE(headers, bodyParam);
			if (RESPONSE.getStatus() == 200) {

				Reporter.log("HomeDelivery Dispatcher is deleted ");
				getBundle().setProperty("rClient", RESPONSE);

				HomeDelivery_Success gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class),
						HomeDelivery_Success.class);
				getBundle().setProperty("rGSON", gson1);
				System.out.println(" : " + gson1.getApiStatus());
				Reporter.log("Deleted HomeDelivery Dispatcher : " + gson1.getApiStatus());
			}
			if (RESPONSE.getStatus() == 207) {
				Reporter.log("HomeDelivery Dispatcher Deleted with Partial success  ");
				getBundle().setProperty("rClient", RESPONSE);
				ErrorMessage gson1 = new Gson().fromJson(RESPONSE.getEntity(String.class), ErrorMessage.class);
				getBundle().setProperty("rGSON", gson1);
			}

			if (RESPONSE.getStatus() == 400) {
				Reporter.log("HomeDelivery Dispatcher Delete failed with 400");
				getBundle().setProperty("rClient", RESPONSE);
			}

			if (RESPONSE.getStatus() == 404) {
				Reporter.log("HomeDelivery Dispatcher Delete failed with 404");
				getBundle().setProperty("rClient", RESPONSE);
			}
			
			if (RESPONSE.getStatus() == 401) {
				Reporter.log("HomeDelivery Dispatcher Delete failed with 401");
				getBundle().setProperty("rClient", RESPONSE);
			}

			if (RESPONSE.getStatus() == 503) {
				Reporter.log("HomeDelivery Dispatcher Delete failed with 503");
				getBundle().setProperty("rClient", RESPONSE);
			}
			
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e);
			if (RESPONSE.getStatus() == 400) {
				Reporter.log("HomeDelivery Dispatcher Deleted failed with 400");
				getBundle().setProperty("rClient", RESPONSE);
			}

		}
	}

	@QAFTestStep(description = "User uses an array of More than 50character invalid format eMail Body Parameter for creating HomeDelivery Dispatcher")
	public void userUsesAnArrayOfMoreThan50CharacterInvalidFormateMailBodyParameterForCreatingHomeDeliveryDispatcher()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getName());
		pr.setEmail(geteMailInvalidFormatMoreThan50Characters());
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("Full body parameter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);	
	}

	@QAFTestStep(description = "User uses Body Parameter with More than 101character name for creating HomeDelivery Dispatcher")
	public void userUsesBodyParameterWithMoreThan101CharacterNameForCreatingHomeDeliveryDispatcher()
			throws JsonProcessingException {

		Dispatcher_Body pr = new Dispatcher_Body();
		ObjectMapper objm = new ObjectMapper();
		pr.setName(getNameMoreThan101Characters());
		pr.setEmail(geteMail());
		pr.setId(null);
		pr.setIsActive(false);
		pr.setOrganization("cmwYeCU*LSXUJ8AjpuYCT5gY");
		pr.setTimeCreated(null);
		pr.setTimeLastModified(null);

		String jsonInString = objm.writeValueAsString(pr);
		System.out.println("Full body parameter is : " + jsonInString);

		getBundle().setProperty("BodyParameter", jsonInString);	
	}
	
	/*@QAFTestStep(description="validate the response schema with GET Dispatcher")
	public void validateTheResponseSchemaWithGETDispatcher() throws IOException{
	
		Dispatchers_RootObject gson1 = (Dispatchers_RootObject) getBundle().getProperty("rGSON");
		System.out.println(gson1);
		System.out.println(gson1.getApiStatus());
		
		String RESPONSE = getBundle().getString("RESPONSE");
		System.out.println("Response :"+ RESPONSE);
		HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "GET_DISPATCHER");	
	
	}*/
	
	@QAFTestStep(description = "validate the response schema with GET Dispatcher")
	public static void validateTheResponseSchemaWithGETDispatcher() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Dispatchers");
				getBundle().setProperty("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				getBundle().setProperty(RESPONSE, "RESPONSE");
				
				Dispatchers_RootObject gson1 = new Gson().fromJson(RESPONSE,
						Dispatchers_RootObject.class);
				System.out.println("RESPONSE is "+ RESPONSE);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String DispatcherID = gson1.getData().get(0).getId();
				getBundle().setProperty("DispatcherID", DispatcherID);
				Reporter.log("Read Success-HomeDelivery Dispatchers ID: " + DispatcherID);
				System.out.println("Read Success-HomeDelivery Dispatchers ID: " + DispatcherID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "GET_DISPATCHER");
				HomeDelivery_ReusableUtils.validateJSONschema("Dispatcher_GET", "GET_DISPATCHER");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			getBundle().setProperty("errorStatusCode", errorStatusCode);

		}
	}
	
	@QAFTestStep(description = "validate the response schema with POST Dispatcher")
	public void validateTheResponseSchemaWithPOSTDispatcher() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		try {
			rClient = ServiceUtils.POST(headers, bodyParam);
			if (rClient.getStatus() == 200) {

				Reporter.log("Dispatcher is created ");
				getBundle().setProperty("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				getBundle().setProperty(RESPONSE, "RESPONSE");

				Dispatchers_Post gson1 = new Gson().fromJson(RESPONSE, Dispatchers_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String DispatcherID = gson1.getData().getId();		
				Reporter.log("Created Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				System.out.println("Created Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "POST_DISPATCHER");
				HomeDelivery_ReusableUtils.validateJSONschema("Dispatcher_POST", "POST_DISPATCHER");
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("Team created with failed  " + 400);
				Reporter.log(rClient.toString());
				getBundle().setProperty("rClient", rClient);

			}
		} catch (Exception e) {

			Reporter.log("Exceptions :" + e,MessageTypes.Fail);
			System.out.println(e);
		}
	}
	
	@QAFTestStep(description = "validate the response schema with PUT Dispatche")
	public void validateTheResponseSchemaWithPUTDispatche() {
		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		String bodyParam = (String) getBundle().getProperty("BodyParameter");
		System.out.println("BodyParamter is : " + bodyParam);
		try {
			rClient = ServiceUtils.PUT(headers, bodyParam);
			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("HomeDelivery Dispatcher is updated ");
				getBundle().setProperty("rClient", rClient);
				
				String RESPONSE = rClient.getEntity(String.class);
				getBundle().setProperty(RESPONSE, "RESPONSE");

				Dispatchers_Post gson1 = new Gson().fromJson(RESPONSE, Dispatchers_Post.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				String DispatcherID = gson1.getData().getId();
				getBundle().setProperty("DispatcherID", DispatcherID);
				Reporter.log("Update Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				System.out.println("Update Success-HomeDelivery Dispatcher ID: " + DispatcherID);
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "PUT_DISPATCHER");
				HomeDelivery_ReusableUtils.validateJSONschema("Dispatcher_PUT", "PUT_DISPATCHER");
				
			}
			if (rClient.getStatus() == 400) {
				Reporter.log("HomeDelivery Teams created with failed  ");
				getBundle().setProperty("rClient", rClient);

			}
			if (rClient.getStatus() == 404) {
				Reporter.log("HomeDelivery Teams created with failed  ");
				getBundle().setProperty("rClient", rClient);

			}

		} catch (Exception e) {

			Reporter.log("Exceptions :" + e, MessageTypes.Fail);
			System.out.println(e);
		}
	}
		
}
