/*List of Steps in Common_APIStepDef Step definition

		User uses invalid JSON Array Body Parameter
		User uses invalid JSON Object Body Parameter
		User uses empty Array Body Parameter
		User uses empty Json Body Parameter*/

package com.heb.automation.Steps.API_Stepdef;

import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class Common_APIStepDef {

	@QAFTestStep(description="User uses invalid JSON Array Body Parameter")
	public void userUsesInvalidJSONArrayBodyParameter(){
	
	CommonUtils.invalidArrayBodyParameter();
	}
	
	@QAFTestStep(description="User uses invalid JSON Object Body Parameter")
	public void userUsesInvalidJSONObjectBodyParameter(){
	
	CommonUtils.invalidJsonBodyParameter();
	}
	
	@QAFTestStep(description="User uses empty Array Body Parameter")
	public void userUsesEmptyArrayBodyParameter(){
	
	CommonUtils.emptyArrayBodyParameter();
	}
	
	@QAFTestStep(description="User uses empty Json Body Parameter")
	public void userUsesEmptyJsonBodyParameter(){
	
	CommonUtils.emptyJsonBodyParameter();
	}
	
	
	
}
