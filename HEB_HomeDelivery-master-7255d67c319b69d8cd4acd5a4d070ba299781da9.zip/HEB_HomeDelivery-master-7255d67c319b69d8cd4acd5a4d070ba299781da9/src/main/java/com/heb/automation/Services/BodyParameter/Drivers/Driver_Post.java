package com.heb.automation.Services.BodyParameter.Drivers;

import com.heb.automation.Services.HomeDelivery.Drivers.Drivers_Data;

public class Driver_Post {
	
	private String apiStatus;

    private Drivers_Data data = new Drivers_Data();

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

    public Drivers_Data getData ()
    {
        return data;
    }

    public void setData (Drivers_Data data)
    {
        this.data = data;
    }

}
