package com.heb.automation.Services.HomeDelivery.Order;

import java.util.ArrayList;
import java.util.List;


public class HomeDelivery_RootObject {
	
	private String apiStatus;

    private List<HomeDelivery_Data> data = new ArrayList<HomeDelivery_Data>();
    

    public List<HomeDelivery_Data> getdata() {
		return this.data;
	}

	public void setdata(List<HomeDelivery_Data> data) {
		this.data = data;
	}

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

}
