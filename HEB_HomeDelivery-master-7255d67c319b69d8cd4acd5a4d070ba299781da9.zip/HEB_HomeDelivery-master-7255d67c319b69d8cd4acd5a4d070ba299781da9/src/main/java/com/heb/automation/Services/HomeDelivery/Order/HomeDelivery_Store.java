package com.heb.automation.Services.HomeDelivery.Order;

public class HomeDelivery_Store {
	
	 private String id;

	    private String lastModifiedTimestamp;

	    private String phone;

	    private HomeDelivery_Address address = new HomeDelivery_Address();

	    private String name;

	    private String active;

	    private String ecomCloseDate;

	    private String ecomOpenDate;

	    private String apiHubId;
	    
	    
	    public HomeDelivery_Address getaddress() {
			return this.address;
		}

		public void setaddress(HomeDelivery_Address address) {
			this.address = address;
		}
	    
	    public String getId ()
	    {
	        return id;
	    }

	    public void setId (String id)
	    {
	        this.id = id;
	    }

	    public String getLastModifiedTimestamp ()
	    {
	        return lastModifiedTimestamp;
	    }

	    public void setLastModifiedTimestamp (String lastModifiedTimestamp)
	    {
	        this.lastModifiedTimestamp = lastModifiedTimestamp;
	    }

	    public String getPhone ()
	    {
	        return phone;
	    }

	    public void setPhone (String phone)
	    {
	        this.phone = phone;
	    }

	    public String getName ()
	    {
	        return name;
	    }

	    public void setName (String name)
	    {
	        this.name = name;
	    }

	    public String getActive ()
	    {
	        return active;
	    }

	    public void setActive (String active)
	    {
	        this.active = active;
	    }

	    public String getEcomCloseDate ()
	    {
	        return ecomCloseDate;
	    }

	    public void setEcomCloseDate (String ecomCloseDate)
	    {
	        this.ecomCloseDate = ecomCloseDate;
	    }

	    public String getEcomOpenDate ()
	    {
	        return ecomOpenDate;
	    }

	    public void setEcomOpenDate (String ecomOpenDate)
	    {
	        this.ecomOpenDate = ecomOpenDate;
	    }

	    public String getApiHubId ()
	    {
	        return apiHubId;
	    }

	    public void setApiHubId (String apiHubId)
	    {
	        this.apiHubId = apiHubId;
	    }
	
}
