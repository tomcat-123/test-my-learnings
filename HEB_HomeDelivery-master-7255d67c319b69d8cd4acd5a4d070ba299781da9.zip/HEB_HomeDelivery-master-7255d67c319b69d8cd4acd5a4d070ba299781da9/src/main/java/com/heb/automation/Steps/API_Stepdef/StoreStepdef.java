package com.heb.automation.Steps.API_Stepdef;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;
import com.google.gson.Gson;
import com.heb.automation.ErrorMessages.ErrorMessage;
import com.heb.automation.Services.HomeDelivery.CommonUtils;
import com.heb.automation.Services.HomeDelivery.HomeDelivery_ReusableUtils;
import com.heb.automation.Services.HomeDelivery.ServiceUtils;
import com.heb.automation.Services.HomeDelivery.Store.Store_RootObject;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;

public class StoreStepdef {

	@QAFTestStep(description = "Build URL for read HomeDelivery stores")
	public void buildURLForReadHomeDeliverStores() {
		String baseurl = getBundle().getString("HomeDelivery.adminPortal");
		String resource = getBundle().getString("HomeDelivery.endpoint.getStores");
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for read HomeDelivery CRON stores")
	public void buildURLForReadHomeDeliverCRONStores() {
		String baseurl = getBundle().getString("HomeDelivery.adminPortal");
		String resource = getBundle().getString("HomeDelivery.endpoint.getCRONStores");
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "Build URL for read Specific HomeDelivery stores")
	public void buildURLForReadSpecificHomeDeliverstores() {
		String baseurl = getBundle().getString("HomeDelivery.adminPortal");
		String resource = getBundle().getString("HomeDelivery.endpoint.getStore") + "/108";
		CommonUtils.buildURL(resource, baseurl);
	}
	
	@QAFTestStep(description = "Build URL for read Specific HomeDelivery CRON stores")
	public void buildURLForReadSpecificHomeDeliverCRONStores() {
		String baseurl = getBundle().getString("HomeDelivery.adminPortal");
		String resource = getBundle().getString("HomeDelivery.endpoint.getCRONStores") + "/108";
		CommonUtils.buildURL(resource, baseurl);
	}

	@QAFTestStep(description = "User GET response call for HomeDelivery stores")
	public static void userGETResponseCallForHomeDeliverStores1() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Stores");
				getBundle().setProperty("rClient", rClient);

				Store_RootObject gson1 = new Gson().fromJson(rClient.getEntity(String.class), Store_RootObject.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);
				int storeID = gson1.getData().get(0).getId();
				int hubID = gson1.getData().get(0).getApiHubId();
				getBundle().setProperty("StoreID", storeID);
				getBundle().setProperty("HubID", hubID);
				Reporter.log("Read Success-HomeDelivery Store ID: " + storeID);
				Reporter.log("Read Success-HomeDelivery Store HubID: " + hubID);
				System.out.println("Read Success-HomeDelivery Store ID: " + storeID);
				System.out.println("Read Success-HomeDelivery Store HubID: " + hubID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			getBundle().setProperty("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "User GET response call for Specific HomeDelivery stores")
	public static void userGETResponseCallForSpecificHomeDeliverStores1() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Stores");
				getBundle().setProperty("rClient", rClient);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			getBundle().setProperty("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "Verify stores response does not have any stores with Mexico state")
	public static void verifyStoresResponseDoesNotHaveAnyStoresWithMexicoState() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Stores");
				getBundle().setProperty("rClient", rClient);

				Store_RootObject gson1 = new Gson().fromJson(rClient.getEntity(String.class), Store_RootObject.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);

				int storeList = gson1.getData().size();

				for (int i = 0; i < storeList; i++) {

					String state = gson1.getData().get(i).getAddress().getState();

					if (state.equals("MX"))
						Reporter.log("Stores have Mexico State" + MessageTypes.Fail);
					int storeID = gson1.getData().get(i).getId();
					int hubID = gson1.getData().get(i).getApiHubId();
					Reporter.log("Read Success-HomeDelivery Store ID: " + storeID);
					Reporter.log("Read Success-HomeDelivery Store HubID: " + hubID);
					Reporter.log("Read Success-HomeDelivery Store State: " + state);
					System.out.println("Read Success-HomeDelivery Store ID: " + storeID);
					System.out.println("Read Success-HomeDelivery Store HubID: " + hubID);
					System.out.println("Read Success-HomeDelivery Store State: " + state);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			getBundle().setProperty("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "Verify stores response does not have ecomOpenDate with older date")
	public static void verifyStoresResponseDoesNotHaveEcomOpenDateWithOlderDate() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Stores");
				getBundle().setProperty("rClient", rClient);

				Store_RootObject gson1 = new Gson().fromJson(rClient.getEntity(String.class), Store_RootObject.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);

				int storeList = gson1.getData().size();

				SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
				Date date2 = new Date();
				formater.format(date2);
				System.out.println("The Current Date is" + date2);
				for (int i = 0; i < storeList; i++) {

					String eDate = gson1.getData().get(i).getEcomOpenDate();
					if (eDate != null) {

						Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse(eDate);

						if (date1.compareTo(date2) == 0 && date1 != null)
							Reporter.log("ecomOpenDate is Curreent date" + MessageTypes.Fail);
						else if (date1.compareTo(date2) > 0 && date1 != null)
							Reporter.log("ecomOpenDate is Future date" + MessageTypes.Fail);
						else if (date1.compareTo(date2) < 0 && date1 != null)
							Reporter.log("ecomOpenDate is Past date" + MessageTypes.Pass);
						System.out.println("ecomOpenDate is..." + date1);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			getBundle().setProperty("errorStatusCode", errorStatusCode);

		}
	}

	@QAFTestStep(description = "Verify stores response to flag stores with ecomCloseDate not equal to null")
	public static void parseStoresResponseToFlagStoresWithEcomCloseDateNotEqualToNull() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Stores");
				getBundle().setProperty("rClient", rClient);

				Store_RootObject gson1 = new Gson().fromJson(rClient.getEntity(String.class), Store_RootObject.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);

				int storeList = gson1.getData().size();

				for (int i = 0; i < storeList; i++) {

					String eDate = gson1.getData().get(i).getEcomCloseDate();

					if (eDate == null) {
						Reporter.log("getEcomCloseDate is null for the below stores" + MessageTypes.Info);
						int storeID = gson1.getData().get(i).getId();
						int hubID = gson1.getData().get(i).getApiHubId();
						String storeName = gson1.getData().get(i).getName();
						Reporter.log("Read Success-HomeDelivery Store ID: " + storeID);
						Reporter.log("Read Success-HomeDelivery Store HubID: " + hubID);
						Reporter.log("Read Success-HomeDelivery Store Name: " + storeName);
						System.out.println("getEcomCloseDate is null for the below stores");
						System.out.println("Read Success-HomeDelivery Store ID: " + storeID);
						System.out.println("Read Success-HomeDelivery Store HubID: " + hubID);
						System.out.println("Read Success-HomeDelivery Store Name: " + storeName);

					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			getBundle().setProperty("errorStatusCode", errorStatusCode);

		}

	}

	@QAFTestStep(description = "Verify stores response to flag stores that have Active equal to false")
	public static void verifyStoresResponseToFlagStoresThatHaveActiveEqualToFalse() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Stores");
				getBundle().setProperty("rClient", rClient);

				Store_RootObject gson1 = new Gson().fromJson(rClient.getEntity(String.class), Store_RootObject.class);
				Arrays.asList(gson1);
				getBundle().setProperty("rGSON", gson1);

				int storeList = gson1.getData().size();

				for (int i = 0; i < storeList; i++) {

					String active = gson1.getData().get(i).getActive();

					if (active == "false") {
						Reporter.log("Active Flag is false for the below stores" + MessageTypes.Info);
						int storeID = gson1.getData().get(i).getId();
						int hubID = gson1.getData().get(i).getApiHubId();
						String storeName = gson1.getData().get(i).getName();
						Reporter.log("Read Success-HomeDelivery Store ID: " + storeID);
						Reporter.log("Read Success-HomeDelivery Store HubID: " + hubID);
						Reporter.log("Read Success-HomeDelivery Store Name: " + storeName);
						System.out.println("Active Flag is false for the below stores");
						System.out.println("Read Success-HomeDelivery Store ID: " + storeID);
						System.out.println("Read Success-HomeDelivery Store HubID: " + hubID);
						System.out.println("Read Success-HomeDelivery Store Name: " + storeName);

					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			getBundle().setProperty("errorStatusCode", errorStatusCode);

		}

	}
	
	@QAFTestStep(description = "User GET response call for HomeDelivery stores schema {0}")
	public static void userGETResponseCallForHomeDeliverStoresSchema (String filename) throws UniformInterfaceException, ClientHandlerException, Exception {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
	
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);
			
			HomeDelivery_ReusableUtils.writeJSONreponse(getBundle().getString("rClient"), filename);
			HomeDelivery_ReusableUtils.validateJSONschema("Store_Schema", filename);
	}
	
	@QAFTestStep(description = "validate the response schema with GET stores")
	public static void validateTheResponseSchemaWithGETStores() {

		ClientResponse rClient = null;
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");
		if (headers == null) {
			headers = HomeDelivery_ReusableUtils.Common_headers();
		}
		try {
			rClient = ServiceUtils.GET(headers);
			Reporter.log("rClient list is : " + rClient.getStatusInfo());
			getBundle().setProperty("rClient", rClient);

			if (rClient.getStatus() == 200) {
				System.out.println("inside..");
				Reporter.log("Read the HomeDelivery Stores");
				getBundle().setProperty("rClient", rClient);
				String RESPONSE = rClient.getEntity(String.class);
				getBundle().setProperty(RESPONSE, "RESPONSE");
				
				HomeDelivery_ReusableUtils.writeJSONreponse(RESPONSE, "GET_STORES");
				HomeDelivery_ReusableUtils.validateJSONschema("Stores_GET", "GET_STORES");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error in API call.....");
			String errorMsg = rClient.getEntity(String.class);
			Reporter.log("Error message : " + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);

			ErrorMessage json = new Gson().fromJson(rClient.getEntity(String.class), ErrorMessage.class);
			String errorStatusCode = json.getStatus();
			Reporter.log("Error Status Code : " + errorStatusCode);
			getBundle().setProperty("errorStatusCode", errorStatusCode);

		}
	}
}
