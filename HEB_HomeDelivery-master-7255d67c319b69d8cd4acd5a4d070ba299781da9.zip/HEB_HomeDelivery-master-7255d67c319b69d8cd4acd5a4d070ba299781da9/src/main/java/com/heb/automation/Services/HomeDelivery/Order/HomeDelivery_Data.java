package com.heb.automation.Services.HomeDelivery.Order;

import java.util.ArrayList;
import java.util.List;

public class HomeDelivery_Data {

	private String lastModifiedTimestamp;

	private String alcoholOrder;

	private String deliveryNotes;

	private HomeDelivery_Store store = new HomeDelivery_Store();

	private String comsId;

	private String deliveryEndDateTime;

	private String status;

	private String deliveryWindowStartDateTime;

	private List<HomeDelivery_Tasks> tasks = new ArrayList<HomeDelivery_Tasks>();

	private HomeDelivery_Customer customer = new HomeDelivery_Customer();

	private String addressLine2;

	private int id;

	private String tipAmount;

	private String signatureRequired;

	private String createdDateTime;

	private String deliveryStartDateTime;

	private String deliveryWindowEndDateTime;

	private String itemCount;

	private HomeDelivery_DeliveryAddress deliveryAddress = new HomeDelivery_DeliveryAddress();
	
	

	public HomeDelivery_DeliveryAddress getdeliveryAddress() {
		return this.deliveryAddress;
	}

	public void setdeliveryAddress(HomeDelivery_DeliveryAddress deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}

	public HomeDelivery_Store getstore() {
		return this.store;
	}

	public void setstore(HomeDelivery_Store store) {
		this.store = store;
	}

	public HomeDelivery_Customer getcustomer() {
		return this.customer;
	}

	public void setcustomer(HomeDelivery_Customer customer) {
		this.customer = customer;
	}
	
	public List<HomeDelivery_Tasks> gettasks() {
		return this.tasks;
	}

	public void settasks(ArrayList<HomeDelivery_Tasks> tasks) {
		this.tasks = tasks;
	}
	
	
	
	public String getLastModifiedTimestamp() {
		return lastModifiedTimestamp;
	}

	public void setLastModifiedTimestamp(String lastModifiedTimestamp) {
		this.lastModifiedTimestamp = lastModifiedTimestamp;
	}

	public String getAlcoholOrder() {
		return alcoholOrder;
	}

	public void setAlcoholOrder(String alcoholOrder) {
		this.alcoholOrder = alcoholOrder;
	}

	public String getDeliveryNotes() {
		return deliveryNotes;
	}

	public void setDeliveryNotes(String deliveryNotes) {
		this.deliveryNotes = deliveryNotes;
	}

	public String getComsId() {
		return comsId;
	}

	public void setComsId(String comsId) {
		this.comsId = comsId;
	}

	public String getDeliveryEndDateTime ()
    {
        return deliveryEndDateTime;
    }

	public void setDeliveryEndDateTime (String deliveryEndDateTime)
    {
        this.deliveryEndDateTime = deliveryEndDateTime;
    }

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDeliveryWindowStartDateTime() {
		return deliveryWindowStartDateTime;
	}

	public void setDeliveryWindowStartDateTime(String deliveryWindowStartDateTime) {
		this.deliveryWindowStartDateTime = deliveryWindowStartDateTime;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTipAmount() {
		return tipAmount;
	}

	public void setTipAmount(String tipAmount) {
		this.tipAmount = tipAmount;
	}

	public String getSignatureRequired() {
		return signatureRequired;
	}

	public void setSignatureRequired(String signatureRequired) {
		this.signatureRequired = signatureRequired;
	}

	public String getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(String createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public String getDeliveryStartDateTime ()
    {
        return deliveryStartDateTime;
    }

	public void setDeliveryStartDateTime (String deliveryStartDateTime)
    {
        this.deliveryStartDateTime = deliveryStartDateTime;
    }

	public String getDeliveryWindowEndDateTime() {
		return deliveryWindowEndDateTime;
	}

	public void setDeliveryWindowEndDateTime(String deliveryWindowEndDateTime) {
		this.deliveryWindowEndDateTime = deliveryWindowEndDateTime;
	}

	public String getItemCount() {
		return itemCount;
	}

	public void setItemCount(String itemCount) {
		this.itemCount = itemCount;
	}

}
