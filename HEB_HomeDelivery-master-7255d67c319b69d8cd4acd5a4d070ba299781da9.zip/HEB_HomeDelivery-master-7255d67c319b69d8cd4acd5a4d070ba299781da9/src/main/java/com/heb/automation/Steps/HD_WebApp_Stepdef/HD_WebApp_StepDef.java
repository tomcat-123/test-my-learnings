package com.heb.automation.Steps.HD_WebApp_Stepdef;

import com.heb.automation.Pages.HD_Web.HD_commonTestPage;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class HD_WebApp_StepDef {
	@QAFTestStep(description="user is on order page")
	public void userIsOnOrderPage(){
	
	System.out.println("started");
	// HD_commonTestPage HDcommon = new HD_commonTestPage();
	
	
	}
}
