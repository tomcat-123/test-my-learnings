package com.heb.automation.common.components;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.HashMap;
import java.util.Map;

public class CommonParameters {
	public static Map<String, String> Common_headers() {
		
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("x-api-key",getBundle().getString("Discovery.APIkey"));
		headers.put("Referer",getBundle().getString("Discovery.Referer"));
		/*
		headers.put("x-api-key", "AIzaSyBT57p0vCDDOuTA_MsiiPbJzPDLLBtsOFc");
		headers.put("Referer", "qa-regression-heb-mls-qa1");
		*/
		getBundle().setProperty("headers", headers);
		
		
		return headers;
	}
	
public static Map<String, String> DiscoveryService_Common_headers() {
		
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("x-api-key",getBundle().getString("Discovery.APIkey"));
		headers.put("Referer",getBundle().getString("Discovery.Referer"));
		
		getBundle().setProperty("headers", headers);
		
		
		return headers;
	}


	
public static Map<String, String> Darkstore_Common_headers() {
	
	Map<String, String> headers = new HashMap<String, String>();
	headers.put("x-api-key",getBundle().getString("Discovery.APIkey"));
	headers.put("Referer",getBundle().getString("Discovery.Referer"));
	
	getBundle().setProperty("headers", headers);
	
	
	return headers;
}
}
