package com.heb.automation.Pages;





import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class OnFleetTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "onfleet.txt.email")
	private QAFWebElement tXtOnfleetEmail ;

	@FindBy(locator = "onfleet.txt.password")
	private QAFWebElement tXtOnfleetPassword;

	public QAFWebElement gettXtOnfleetEmail() {
		return tXtOnfleetEmail;
	}

	public void settXtOnfleetEmail(QAFWebElement tXtOnfleetEmail) {
		this.tXtOnfleetEmail = tXtOnfleetEmail;
	}

	public QAFWebElement gettXtOnfleetPassword() {
		return tXtOnfleetPassword;
	}

	public void settXtOnfleetPassword(QAFWebElement tXtOnfleetPassword) {
		this.tXtOnfleetPassword = tXtOnfleetPassword;
	}

	/* onfleet test page2 */	
	
}