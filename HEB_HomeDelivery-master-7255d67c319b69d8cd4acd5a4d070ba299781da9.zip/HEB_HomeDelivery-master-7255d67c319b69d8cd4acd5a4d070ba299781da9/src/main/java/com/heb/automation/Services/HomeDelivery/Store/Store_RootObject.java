package com.heb.automation.Services.HomeDelivery.Store;

import java.util.ArrayList;
import java.util.List;

public class Store_RootObject {
	
	 private String apiStatus;

	    private List<Store_Data> data = new ArrayList<Store_Data>();

	    public String getApiStatus ()
	    {
	        return apiStatus;
	    }

	    public void setApiStatus (String apiStatus)
	    {
	        this.apiStatus = apiStatus;
	    }

	    public  List<Store_Data> getData ()
	    {
	        return data;
	    }

	    public void setData (List<Store_Data> data)
	    {
	        this.data = data;
	    }

}
