package com.heb.automation.Steps.Onfleet_Stepdef;

import com.heb.automation.Pages.OnFleetTestPage;
import com.qmetry.qaf.automation.step.NotYetImplementedException;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class Onfleet_stepdef {

	
	
	@QAFTestStep(description="Login onfleet web Application")
	public void loginOnfleetWebApplication(){
		System.out.println("inside");
		OnFleetTestPage landing = new OnFleetTestPage();
		landing.gettXtOnfleetEmail().sendKeys("vijayakarthikeyan.arul@heb.com");
	}
}
