package com.heb.automation.Services.HomeDelivery.GeoCode;

public class Geocode_RootObject {

	private String apiStatus;

	private Geocode_data data = new Geocode_data();

	public String getApiStatus() {
		return apiStatus;
	}

	public void setApiStatus(String apiStatus) {
		this.apiStatus = apiStatus;
	}

	public Geocode_data getData() {
		return data;
	}

	public void setData(Geocode_data data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "ClassPojo [apiStatus = " + apiStatus + ", data = " + data + "]";
	}
}
