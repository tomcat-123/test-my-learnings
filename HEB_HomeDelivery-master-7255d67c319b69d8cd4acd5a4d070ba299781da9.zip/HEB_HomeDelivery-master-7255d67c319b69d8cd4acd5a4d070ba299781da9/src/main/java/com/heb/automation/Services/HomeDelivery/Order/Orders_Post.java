package com.heb.automation.Services.HomeDelivery.Order;

public class Orders_Post {
	
	private String apiStatus;

    private HomeDelivery_Data data = new HomeDelivery_Data();

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

    public HomeDelivery_Data getData ()
    {
        return data;
    }

    public void setData (HomeDelivery_Data data)
    {
        this.data = data;
    }

}
