package com.heb.automation.Services.HomeDelivery;

public class HomeDelivery_Success {
	
	private String apiStatus;

    private String data;

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

    public String getData ()
    {
        return data;
    }

    public void setData (String data)
    {
        this.data = data;
    }

}
