package com.heb.automation.Services.HomeDelivery.Dispatchers;

public class Dispatchers_Post {
	
	private String apiStatus;

    private Dispatchers_Data data = new Dispatchers_Data();

    public String getApiStatus ()
    {
        return apiStatus;
    }

    public void setApiStatus (String apiStatus)
    {
        this.apiStatus = apiStatus;
    }

    public Dispatchers_Data getData ()
    {
        return data;
    }

    public void setData (Dispatchers_Data data)
    {
        this.data = data;
    }

}
