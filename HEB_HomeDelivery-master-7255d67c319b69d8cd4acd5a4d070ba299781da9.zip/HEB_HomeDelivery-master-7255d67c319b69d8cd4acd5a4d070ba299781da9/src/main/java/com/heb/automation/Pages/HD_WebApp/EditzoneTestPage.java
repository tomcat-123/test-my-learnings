package com.heb.automation.Pages.HD_WebApp;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class EditzoneTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}

	@FindBy(locator = "editzone.txt.zonename")
	private QAFWebElement editzonetxtzonename;
	
	@FindBy(locator = "editzone.txt.onfleetteamid")
	private QAFWebElement editzonetxtonfleetteamid;
	
	@FindBy(locator = "editzone.txt.city")
	private QAFWebElement editzonetxtcity;
	
	@FindBy(locator = "editzone.txt.zipcode")
	private QAFWebElement editzonetxtzipcode;
	
	@FindBy(locator = "editzone.btn.cancel")
	private QAFWebElement editzonebtncancel;
	
	@FindBy(locator = "editzone.btn.save")
	private QAFWebElement editzonebtnsave;
	
	@FindBy(locator = "editzone.btn.edit")
	private QAFWebElement editzonebtnedit;
	
	@FindBy(locator = "editzone.btn.delete")
	private QAFWebElement editzonebtndelete;
	
	@FindBy(locator = "editzone.lnk.editzonecrumb")
	private QAFWebElement editzonelnkeditzonecrumb;
	
	@FindBy(locator = "editzone.lbl.title")
	private QAFWebElement editzonelbltitle;
	
	@FindBy(locator = "editzone.btn.deleteno")
	private QAFWebElement editzonebtndeleteno;
	
	
	public QAFWebElement getBtnDeleteNo() {
		return editzonebtndeleteno;
	}
	
	public QAFWebElement getTxtZoneName() {
		return editzonetxtzonename;
	}
	
	public QAFWebElement getLblTitle() {
		return editzonelbltitle;
	}
	
	public QAFWebElement getLnkEditZoneCrumb() {
		return editzonelnkeditzonecrumb;
	}
	
	public QAFWebElement getBtnDelete() {
		return editzonebtndelete;
	}
	
	public QAFWebElement getBtnEdit() {
		return editzonebtnedit;
	}
	
	public QAFWebElement getBtnSave() {
		return editzonebtnsave;
	}
	
	public QAFWebElement getBtnCancel() {
		return editzonebtncancel;
	}
	
	public QAFWebElement getTxtZipcode() {
		return editzonetxtzipcode;
	}
	
	public QAFWebElement getTxtCity() {
		return editzonetxtcity;
	}
	
	public QAFWebElement getTxtOnFleetTeamId() {
		return editzonetxtonfleetteamid;
	}
	
}
