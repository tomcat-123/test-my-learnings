package com.heb.automation.Services.HomeDelivery.Drivers;

public class Drivers_Vehicle {
	
	private String id;

    private String color;

    private String description;

    private String type;

    private String licensePlate;

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getColor ()
    {
        return color;
    }

    public void setColor (String color)
    {
        this.color = color;
    }

    public String getDescription ()
    {
        return description;
    }

    public void setDescription (String description)
    {
        this.description = description;
    }

    public String getType ()
    {
        return type;
    }

    public void setType (String type)
    {
        this.type = type;
    }

    public String getLicensePlate ()
    {
        return licensePlate;
    }

    public void setLicensePlate (String licensePlate)
    {
        this.licensePlate = licensePlate;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [id = "+id+", color = "+color+", description = "+description+", type = "+type+", licensePlate = "+licensePlate+"]";
    }

}
