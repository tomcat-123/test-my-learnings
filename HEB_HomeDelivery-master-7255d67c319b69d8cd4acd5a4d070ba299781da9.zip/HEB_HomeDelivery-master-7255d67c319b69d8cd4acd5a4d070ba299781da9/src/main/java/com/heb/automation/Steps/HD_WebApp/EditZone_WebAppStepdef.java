package com.heb.automation.Steps.HD_WebApp;

import com.heb.automation.Pages.HD_WebApp.EditzoneTestPage;
import com.heb.automation.Pages.HD_WebApp.ZoneTestPage;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class EditZone_WebAppStepdef {
	
	@QAFTestStep(description = "I Verify the Edit Zone Page")
	public void iVerifyTheEditZonePage() {
		EditzoneTestPage editZoneTP = new EditzoneTestPage();
		
		editZoneTP.getLblTitle().waitForPresent(5000);
		editZoneTP.getLblTitle().verifyPresent();
		editZoneTP.getLnkEditZoneCrumb().verifyPresent();
		editZoneTP.getTxtZoneName().verifyPresent();
		editZoneTP.getTxtOnFleetTeamId().verifyPresent();
		editZoneTP.getTxtCity().verifyPresent();
		editZoneTP.getTxtZipcode().verifyPresent();
		editZoneTP.getBtnCancel().verifyPresent();
		editZoneTP.getBtnSave().verifyPresent();		
	}
	
	@QAFTestStep(description = "I Click on Cancel button in EditZone Page")
	public void iClickOnCancelButtonInEditZonePage() {
		EditzoneTestPage editZoneTP = new EditzoneTestPage();
		
		editZoneTP.getBtnCancel().waitForPresent();
		editZoneTP.getBtnCancel().click();	
	}
	
	@QAFTestStep(description = "I Verify user is navigated back to the Zone List Page")
	public void iVerifyUserIsNavigatedBackToTheZoneListPage() {
		ZoneTestPage zPage = new ZoneTestPage();
		zPage.getBtnAddNew().waitForPresent(5000);;
		zPage.getBtnAddNew().verifyPresent();	
	}
	
	@QAFTestStep(description = "I Click on Delete button in EditZone Page")
	public void iClickOnDeleteButtonInEditZonePage() {
		EditzoneTestPage editZoneTP = new EditzoneTestPage();
		
		editZoneTP.getBtnCancel().waitForPresent(5000);
		editZoneTP.getBtnDelete().click();
	}
	
	@QAFTestStep(description = "I Click No on the Delete Confirmation pop-up modal")
	public void iClickNoOnTheDeleteConfirmationPopupModal() {
		EditzoneTestPage editZoneTP = new EditzoneTestPage();
		
		editZoneTP.getBtnDeleteNo().waitForPresent(5000);
		editZoneTP.getBtnDeleteNo().click();
	}
}
