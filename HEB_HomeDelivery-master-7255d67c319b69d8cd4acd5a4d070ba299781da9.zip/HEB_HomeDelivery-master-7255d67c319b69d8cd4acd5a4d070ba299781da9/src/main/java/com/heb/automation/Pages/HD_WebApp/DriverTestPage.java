package com.heb.automation.Pages.HD_WebApp;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class DriverTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}

	@FindBy(locator = "driver.lbl.firstname")
	private QAFWebElement driverlblfirstname;

	@FindBy(locator = "driver.btn.search")
	private QAFWebElement driverbtnsearch;

	@FindBy(locator = "driver.lbl.fnameserachrslt")
	private QAFWebElement driverlblfnameserachrslt;
	
	@FindBy(locator = "driver.lbl.tablebody")
	private QAFWebElement driverlbltablebody;
	
	@FindBy(locator = "driver.lbl.lastname")
	private QAFWebElement driverlbllastname;
	
    @FindBy(locator = "driver.lbl.currentdate")
    private QAFWebElement driverlblcurrentdate;
    
    @FindBy(locator = "driver.lbl.pastdate")
    private List<QAFWebElement> driverlblpastdate;
    
    @FindBy(locator = "driver.btn.previousmonth")
    private QAFWebElement driverbtnpreviousmonth;

    @FindBy(locator = "driver.btn.opencalendar")
    private QAFWebElement driverbtnopencalendar;

    @FindBy(locator = "driver.lnk.driverCrumb")
    private QAFWebElement driverlnkdriverCrumb;
     
    @FindBy(locator ="driver.lbl.title")
    private QAFWebElement driverlbltitle;
    
    @FindBy(locator ="driver.lnk.paginationnum")
    private QAFWebElement driverlnkpaginationnum;
    
    @FindBy(locator ="driver.lbl.teblehead")
    private QAFWebElement driverlblteblehead;
    
    @FindBy(locator ="driver.lnk.hamburger")
    private QAFWebElement driverlnkhamburger;
    
    @FindBy(locator ="driver.lnk.driversnap")
    private QAFWebElement driverlnkdriversnap;
    
    @FindBy(locator ="driver.lnk.zoneconfig")
    private QAFWebElement driverlnkzoneconfig;
    
    @FindBy(locator ="driver.lnk.zone")
    private QAFWebElement driverlnkzone;
    
    @FindBy(locator ="driver.lnk.city")
    private QAFWebElement driverlnkcity;
    
    @FindBy(locator ="driver.lnk.dispatcher")
    private QAFWebElement driverlnkdispatcher;
    
    @FindBy(locator ="driver.lnk.messaging")
    private QAFWebElement driverlnkmessaging;
    
    @FindBy(locator ="driver.lnk.order")
    private QAFWebElement driverlnkorder;
    
    @FindBy(locator ="driver.lnk.backwardlastpage")
    private QAFWebElement driverlnkbackward;
    
    @FindBy(locator ="driver.lnk.forwardlast")
    private QAFWebElement driverlnkforward;
    
    @FindBy(locator ="driver.lnk.backwardnext")
    private QAFWebElement driverlnkbackwardnext;
    
    @FindBy(locator ="driver.lnk.forwardnext")
    private QAFWebElement driverlnkforwardnext;
    
    @FindBy(locator ="driver.dbp.zone")
    private QAFWebElement driverdbpzone;
    
    @FindBy(locator ="driver.dpd.value")
    private QAFWebElement driverdpdvalue;
    
    @FindBy(locator ="driver.lbl.zone")
    private QAFWebElement driverlblzone;
    
    @FindBy(locator ="driver.btn.reset")
    private QAFWebElement driverbtnreset;
    
    @FindBy(locator ="driver.lbl.zonenotselected")
    private QAFWebElement driverlblzonenotselected;
    
    
    @FindBy(locator ="driver.lbl.futuredate")
    private List<QAFWebElement> driverlblfuturedate;
    
    public List<QAFWebElement> getLblFutureDate() {
		return driverlblfuturedate;
	}
    
    public QAFWebElement getLblZoneNotSelected() {
		return driverlblzonenotselected;
	}
    
    public QAFWebElement getBtnReset() {
		return driverlblzone;
	}
     
    public QAFWebElement getLblZone() {
		return driverlblzone;
	}
   
    public QAFWebElement getDpdValue() {
		return driverdpdvalue;
	}
    
    public QAFWebElement getDbpZone() {
		return driverdbpzone;
	}
    
    public QAFWebElement getLblFirstName() {
		return driverlblfirstname;
	}

	public QAFWebElement getBtnSearch() {
		return driverbtnsearch;
	}

	public QAFWebElement getLblFNameSerachRslt() {
		return driverlblfnameserachrslt;
	}
	
	public QAFWebElement getLblTableBody() {
		return driverlbltablebody;
	}
	
	public QAFWebElement getLblLastname() {
		return driverlbllastname;
	}
	
    public QAFWebElement getLblCurrentDate() {
        return driverlblcurrentdate;
    }
    
    public List<QAFWebElement> getLblpastdate() {
        return driverlblpastdate;
    }
    
    public QAFWebElement getBtnPreviousMonth() {
        return driverbtnpreviousmonth;
    }
    
    public QAFWebElement getBtnOpenCalendar() {
        return driverbtnopencalendar;
    }

    public QAFWebElement getLnkDriverCrumb() {
        return driverlnkdriverCrumb;
    }
    
    public QAFWebElement getLblTitle() {
		return driverlbltitle;
	}
    
    public QAFWebElement getLnkPaginationNum() {
		return driverlnkpaginationnum;
	}
    
    public QAFWebElement getLblTebleHead() {
		return driverlblteblehead;
	}
    
    public QAFWebElement getLnkHamburger() {
		return driverlnkhamburger;
	}
    
    public QAFWebElement getLnkDriverSnap() {
		return driverlnkdriversnap;
	}
    
    public QAFWebElement getLnkZoneConfig() {
		return driverlnkzoneconfig;
	}
    
    public QAFWebElement getLnkzone() {
		return driverlnkzone;
	}
    
    public QAFWebElement getLnkCity() {
		return driverlnkcity;
	}
    
    public QAFWebElement getLnkDispatcher() {
		return driverlnkdispatcher;
	}
    
    public QAFWebElement getLnkMessaging() {
		return driverlnkmessaging;
	}
    
    public QAFWebElement getLnkorder() {
		return driverlnkorder;
	}
    
    public QAFWebElement getLnkBackWard() {
		return driverlnkbackward;
	}
    
    public QAFWebElement getLnkForward() {
		return driverlnkforward;
	}
    
    public QAFWebElement getLnkBackWardNext() {
		return driverlnkbackwardnext;
	}
    
    public QAFWebElement getLnkForwardNext() {
		return driverlnkforwardnext;
	}
}
