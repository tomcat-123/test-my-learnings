package com.heb.automation.Services.HomeDelivery.Drivers;

import java.util.ArrayList;

public class Drivers_RootObject {
	
	 private String apiStatus;

	    private ArrayList<Drivers_Data> data = new ArrayList<Drivers_Data>();

	    public String getApiStatus ()
	    {
	        return apiStatus;
	    }

	    public void setApiStatus (String apiStatus)
	    {
	        this.apiStatus = apiStatus;
	    }

	    public ArrayList<Drivers_Data> getData ()
	    {
	        return data;
	    }

	    public void setData (ArrayList<Drivers_Data> data)
	    {
	        this.data = data;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [apiStatus = "+apiStatus+", data = "+data+"]";
	    }
}
