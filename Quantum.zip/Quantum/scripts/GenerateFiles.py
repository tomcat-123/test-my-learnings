################################################################################
#GenerateFiles.py written by Garrett Griffin
#
#Usage:
#    > python GenerateFiles.py [-g] <textInput.txt>
#
#Purpose:
#    Will generate both the Javafile and the .loc file using the files ConvertToLoc.py and
#    GenerateJavaFile.py. The two files are still stand alone programs if you need to only run one
#    or the other. This one just cuts out the middle man.
#
#Input:
#    No GUI: > python GenerateFiles.py textInput.txt
#       The only difference in input is the first line of the file needs to be the path for the location file,
#       and the second line needs to be the path for the Java file. The third line
#       needs to be the name of the package that the Java file will be going to. Sample input:
#           C:\Users\g767426\workspace\HEBToYouWebAutomation\resources\testLoc\test.loc
#           C:\Users\g767426\workspace\HEBToYouWebAutomation\src\pages\testPages\test.java
#           pages.test
#           search.box.navTab;xpath=html/body/div[3]/div/div/div[1]/ul/li[1]/a;Navigation tab on sidebar on search page
#
#    GUI Instructions: > python GenerateFiles -g textInput.txt
#       Invoke the program with the optional '-g' flag. You will be prompted for the input file, location file, and java file.
#       You will also need to type in the package name for the java file. Do not include the word package. That will be added.
#
#Notes:
#    For more in depth explainations, you can view the stand alone files in the same directory.
#    An optional '-g' flag can be used on the commandline to access a GUI to dictate input and output of the files.
################################################################################

import re
import sys
import os
from tkinter import filedialog
from tkinter import *

INIT_LOC_DIR = "~\HEBToYouWebAutomation\\resources\qa"
INIT_JAVA_DIR = "~\HEBToYouWebAutomation\src\pages"

javaGetters = []
javaFindBy = []

# Opens the input file based on command line switch
def genInputFile():
    if(len(sys.argv) > 3):
        print("Incorrect program call. Usage: ")
        print(">python GenerateFiles.py [-g] <textInput.txt>")
        sys.exit(1)

    # Determine whether or not GUI flag is activated
    if(len(sys.argv) == 3):
        flagActivated = True
        root = Tk()
        root.filename =  filedialog.askopenfilename(initialdir = "~\HEBWeb_Quantum\script_input_files",title = "Select Input file",filetypes = (("text files","*.txt"),("all files","*.*")))
        inputFileName = root.filename
        root.filename = ""
    else:
        flagActivated = False
        inputFileName = sys.argv[1]
    return inputFileName, flagActivated

# Opens up outfiles based on command line flag
def processCommandSwitches(inputF, flagActivated):
    if(not flagActivated):
        # Grab and fix file paths
        locationFP = inputF.readline()
        javaFP = inputF.readline()
        javaPkg = 'package '
        packageNm = inputF.readline()
        javaPkg += packageNm.rstrip() + ';\n\n'

        filePathGrab = re.search(r'^(.*)\n$', locationFP)
        locationOutF = open(filePathGrab.group(1), 'w')
        filePathGrab = re.search(r'^(.*)\n$', javaFP)
        javaOutF = open(filePathGrab.group(1), 'w')

        # Grab java class name
        # Sample match: 'C:\Users\...\src\pages\homepage\HomeTestPage.java'
        javaMatch = re.search(r'^.*\\(.*)\.java$', javaFP)
        firstLine = True    # Bool to check for first line in file to grab loc tag starter
    else:
        root = Tk()
        root.filename =  filedialog.askopenfilename(initialdir = INIT_LOC_DIR,title = "Select Location file",filetypes = (("Location Files","*.loc"),("all files","*.*")))
        locationOutF = open(root.filename, 'w')
        root.filename = ""
        root.filename = filedialog.askopenfilename(initialdir = INIT_JAVA_DIR,title = "Select Java file",filetypes = (("Java Files","*.java"),("all files","*.*")))
        javaOutF = open(root.filename, 'w')
        javaPkg = 'package '
        packageName = input('Please enter Java Package name: ')
        javaPkg += packageName.rstrip() + ';\n\n'
        matchLine = str(root.filename).replace('/', '\\')
        javaMatch = re.search(r'^.*\\(.*)\.java$', matchLine)
        print(matchLine)
        root.filename = ""
    return locationOutF, javaOutF, javaPkg, javaMatch


# Generates the location file. Everything will be semi-colon delimitted for ease of parsing
def generateLoc(outline):
    valueName = outline.group(1)
    locationName = outline.group(2)
    desName = outline.group(3)
    var = ("%s = {\"locator\":\"%s\",\"desc\":\"%s\"}\n" % (valueName, locationName, desName))
    #print(var)
    locationOutF.write(var)

# Wait method for the main automation program
def createWaitMethod(locTag):
    methodMatch = javaMatch.group(1)
    createTag = locTag.split(".")

    commentLine = '\t/**\n\t* Whatever item takes longest to load needs to be set with the "waitForPresent()" call\n\t**/\n'
    methodDec = '\n\tpublic synchronized void waitForPageToLoad(){\n'
    waitLine = '\t\t'+ createTag[0] + 'PageLoadItem.waitForPresent(5000);\n'
    superLine = '\t\tsuper.waitForPageToLoad();\n\t}\n\n'

    javaOutF.writelines([methodDec, superLine])

# Creates the package and import headings for the java file
def createHeading(locTag):
    javaOutF.writelines([javaPkg
                         , 'import java.util.List;\n\n'
                         , 'import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;\n'
                         , 'import com.qmetry.qaf.automation.ui.annotations.FindBy;\n'
                         , 'import com.qmetry.qaf.automation.ui.api.PageLocator;\n'
                         , 'import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;\n'
                         , 'import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;\n'
                         , 'import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;\n\n'])

    classDefStr = 'public class ' + javaMatch.group(1) + ' extends WebDriverBaseTestPage<WebDriverTestPage>  {\n'

    javaOutF.writelines([classDefStr
                         ,'\n\t@Override\n'
                         ,'\tprotected void openPage(PageLocator arg0, Object... arg1){}\n\n'])

    createWaitMethod(locTag)

# If the getter can accept extra input, will invoke this method
def createDynamicGetter(variableName, locationName):
    returnString = '\n\t\tString retElm = String.format(pageProps.getString("' +locationName+'"), item);\n\t\
    return new QAFExtendedWebElement(retElm);\n\t}\n\n'
    return returnString

# Generates the java file
def generateJava(outline):
    valueName = outline.group(1)
    # Sample match: 'home.box.get.CategoryList;...;...'
    isList = re.search(r'^.*(\.li\.).*$', valueName)
    isDynamic = re.search(r'^.*(\.get\.).*$', valueName)

    # Locator for QAF
    firstLine = '\t@FindBy(locator = "' + valueName + '")\n'
    name = valueName.split('.')
    result = ''
    # Upper case each letter
    for item in name:
        result += item[0].upper() + item[1:]
    # Convert to a camelcase
    jName = result[:1].lower() + result[1:]
    # Add JavaDoc
    commentLine = '\t/**\n\t * ' + outline.group(3) + '\n\t */\n'
    # Check for lists
    if isList is None:
        secondLine = '\tprivate QAFWebElement ' + jName + ';\n\n'
        if isDynamic is None:
            getterLine = '\tpublic QAFWebElement get' + result + '(){ '
        else:
            getterLine = '\tpublic QAFWebElement get' + result + '(String item){ '
    else:
        secondLine = '\tprivate List<QAFWebElement> ' + jName + ';\n\n'
        getterLine = '\tpublic List<QAFWebElement> get' + result + '(){ '
    if isDynamic is None:
        returnLine = 'return ' + jName + '; }\n\n'
    else:
        returnLine = createDynamicGetter(jName, valueName)

    javaOutF.writelines([firstLine, secondLine])
    javaGetters.append([commentLine, getterLine, returnLine])
    #javaOutF.writelines([firstLine, secondLine, commentLine, getterLine, returnLine])

##### Main Starts Here ######
inputFileName, flagActivated = genInputFile()

# Create and open new files
inputF = open(inputFileName, 'r')
locationOutF, javaOutF, javaPkg, javaMatch = processCommandSwitches(inputF, flagActivated)

firstLine = True

for line in inputF:
    # Sample regex invocation: 'home.logo;xpath=//div[...];HEB Logo'
    outline = re.search(r'^(.*);(.*);(.*)$', line)

    if firstLine is True and outline is not None:
        createHeading(outline.group(1))
        firstLine = False

    # If it's not a match, line is printed to the console and skipped.
    if outline is None:
        print(line.rstrip() + ' is not formatted correctly.')
        continue

    # Create the location file
    generateLoc(outline)
    # Create the java file
    generateJava(outline)

for getLine in javaGetters:
    javaOutF.writelines(getLine)

# Fencepost bracket for the java file
javaOutF.write('}')

# Close the files
inputF.close()
locationOutF.close()
javaOutF.close()
