package com.heb.automation.common.pages.shoppinglist;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ForgotpasswordTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "forgotpass.lbl.title")
	private QAFWebElement LblTitle;
	@FindBy(locator = "forgotpass.txt.email")
	private QAFWebElement TxtEmail;
	@FindBy(locator = "forgotpass.btn.submit")
	private QAFWebElement BtnSubmit;
	@FindBy(locator = "forgotpass.btn.resetpassword")
	private QAFWebElement BtnResetpassword;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblTitle() {
		return LblTitle;
	}

	public QAFWebElement getTxtEmail() {
		return TxtEmail;
	}

	public QAFWebElement getBtnSubmit() {
		return BtnSubmit;
	}
	
	public QAFWebElement getBtnResetpassword() {
		return BtnResetpassword;
	}
}
