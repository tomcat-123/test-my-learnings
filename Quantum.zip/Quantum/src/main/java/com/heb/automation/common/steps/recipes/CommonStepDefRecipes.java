/**
 * 
 */
package com.heb.automation.common.steps.recipes;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.recipes.QuickrecipefinderTestPage;
import com.heb.automation.common.pages.recipes.RecipeboxTestPage;
import com.heb.automation.common.pages.recipes.RecipeboxresultTestPage;
import com.heb.automation.common.pages.recipes.RecipedetailTestPage;
import com.heb.automation.common.pages.recipes.RecipeinstructionsTestPage;
import com.heb.automation.common.pages.recipes.RecipenutritioninfoTestPage;
import com.heb.automation.common.pages.recipes.ReciperesultTestPage;
import com.heb.automation.common.pages.recipes.RecipeslandingTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.ios.steps.IOSStepdef;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in Common Recipes

	I select Quick Recipe Finder
	I should see Quick recipe finder options
	I choose the recipe options and click find
	I should see the recipe search result
	I select an recipe row in the search result
	I should see the recipe detail screen
	user selects the All on the Grill display recipe
	I click Add button on select shopping list from scrolling selector
	I see login splash page by clicking on Log in button
	I select Advanced option and choose the recipe options and click find
	I see Search Field is displayed by clicking on Search Icon in Recipe screen
	I navigate to My Recipe Box page
	I should able to see new folder
	I validate the elements in the recipe landing page
	I validate the elements in the recipe box landing page
	I validate elements in Recipes Detail page
	I navigate to instructions tab in Recipe Detail page
	I validate elements in instructions tab
	I navigate to nutritions info tab in Recipe Detail page
	I validate elements in nutritions info tab
	I navigate to my recipe Box page from recipe detail screen
	I validate quick finder landing page
	I validate recipe result list page
	I validate search results of recipes
	I click on Add to recipe box button
	I verify the no recipe boxes avialable popup
	I click on move recipe button
	I validate the elements in the recipe box landing page as an cold user
	I validate the elements in the recipe box landing page as an hot user
	I navigate to Refine page on clicking refine button
	I navigate to My Recipe Box page from search result page
	I navigate to registration page after clicking Create an account link
	I validate nutrition info tab for recipes
	I validate instruction tab for recipes
	I choose the invalid recipe options and click find
	I select uncheck all items from recipedetails page
	I should see the recipe items unchecked
	I should see the recipe result page
	I verify My Recipe Box page is displayed
	I select Refine button in recipe result page
	I verify that recipe is added to All recipe box*/

public class CommonStepDefRecipes {

	/**
	 * Verifying and Clicking on Quick recipe finder button
	 */

	@QAFTestStep(description = "I select Quick Recipe Finder")
	public void iSelectQuickRecipeFinder() {
		RecipeslandingTestPage recipelanding = new RecipeslandingTestPage();

		// Verify QuickFinder button and click
		recipelanding.getRecipesQuickfinderBtn().waitForPresent(70000);
		recipelanding.getRecipesQuickfinderBtn().verifyPresent();
		recipelanding.getRecipesQuickfinderBtn().click();
	}

	/**
	 * Verifying Quick Recipe Finder options
	 */

	@QAFTestStep(description = "I should see Quick recipe finder options")
	public void iShouldSeeQuickRecipeFinderOptions() {
		QuickrecipefinderTestPage quickfinder = new QuickrecipefinderTestPage();

		// Verifying Quick recipe finder options
		quickfinder.getQuickfinderLblIwanttomake().verifyPresent();
	}

	/**
	 * Selecting the recipe options. Clicking on FInd button.
	 */
	@QAFTestStep(description = "I choose the recipe options and click find")
	public void iChooseTheRecipeOptionsAndClickFind() {
		QuickrecipefinderTestPage quickfinder = new QuickrecipefinderTestPage();

		// Select Make Item1 option and With Item 1 option
		quickfinder.getQuickfinderBtnMakeItem1().click();
		quickfinder.getQuickfinderBtnWithItem1().click();

		// Verifying Find button and click
		quickfinder.getQuickfinderFind().verifyPresent();
		quickfinder.getQuickfinderFind().click();
	}

	/**
	 * Verifying the search result after selecting recipe options.
	 */

	@QAFTestStep(description = "I should see the recipe search result")
	public void iShouldSeeTheSearchResult() {
		ReciperesultTestPage reciperesult = new ReciperesultTestPage();

		// Verify if search results are displayed
		reciperesult.getReciperesultItem1().waitForPresent(5000);
		if (reciperesult.getReciperesultPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Page navigate to the recipe search result as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to navigate recipe search result", MessageTypes.Fail);
		}
	}

	/**
	 * CLicking on the first recipe row from the result list.
	 */
	@QAFTestStep(description = "I select an recipe row in the search result")
	public void iSelectAnRecipeRowInTheSearchResult() {
		ReciperesultTestPage reciperesult = new ReciperesultTestPage();

		// Getting recipe name
		reciperesult.getReciperesultRecipename().waitForPresent(5000);
		String recipeName = reciperesult.getReciperesultRecipename().getText();
		getBundle().setProperty("recipeName", recipeName);

		System.out.println(recipeName);
		// Click on first recipe
		reciperesult.getReciperesultItem1().waitForPresent(1500);
		reciperesult.getReciperesultItem1().click();
		PerfectoUtils.reportMessage("Selected item: " + recipeName, MessageTypes.Pass);
	}

	/**
	 * Verifying the recipe detail page. Handling the re login pop up.
	 */
	@QAFTestStep(description = "I should see the recipe detail screen")
	public static void iShouldSeeTheRecipeDetailScreen() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		recipedetail.waitForPageToLoad();
		// Validating recipe name
		try {
			recipedetail.getRecipedetailpageRecipename().waitForPresent(15000);
		} catch (Exception e) {
			if (appCrash.getReloginTitle().isPresent()) {
				PerfectoUtils.reportMessage("Handling re-Login popup", MessageTypes.Pass);
				appCrash.getReloginPassword().sendKeys(getBundle().getString("currentPassword"));
				appCrash.getReloginLoginBtn().waitForPresent(10000);
				appCrash.getReloginLoginBtn().click();
			}
		}
		recipedetail.getRecipedetailpageRecipename().verifyPresent();
		String dtlPageRecipeName = recipedetail.getRecipedetailpageRecipename().getText();
		System.out.println(dtlPageRecipeName);
		String strRecipenamefromCDP = getBundle().getString("recipeName");
		System.out.println(strRecipenamefromCDP);

		if (dtlPageRecipeName.equalsIgnoreCase(strRecipenamefromCDP)) {
			PerfectoUtils.reportMessage("Selected Recipe is viewed in Recipe detail page: " + dtlPageRecipeName,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected Recipe is not viewed in Recipe detail page", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking on Recipe Featured content image.
	 */
	@QAFTestStep(description = "user selects the All on the Grill display recipe")
	public void userSelectsTheAllOnTheGrillDisplayRecipe() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		RecipeslandingTestPage recipelandingpage = new RecipeslandingTestPage();

		// Click on Recipe featured content image
		recipelandingpage.getRecipesFeatured().waitForPresent(10000);
		recipelandingpage.getRecipesFeatured().click();

		if (weeklygrocery.getShopingListEntryByLable("Search Error").isPresent()) {
			PerfectoUtils.reportMessage("Search error: Unable to load search results!!", MessageTypes.Fail);
			appcrash.getExceptionBtnOk().waitForPresent(5000);
			appcrash.getExceptionBtnOk().click();
		}
	}

	/**
	 * Clicking on Add button from scrolling selector pop up.
	 */
	@QAFTestStep(description = "I click Add button on select shopping list from scrolling selector")
	public void iClickAddButtonOnSelectShoppingListFromScrollingSelector() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		// Clicking on add button
		recipedetail.getRecipedetailpageLstpopupBtnAdd().verifyPresent();
		recipedetail.getRecipedetailpageLstpopupBtnAdd().click();
		PerfectoUtils.reportMessage("Clicked on Add button from the popup.", MessageTypes.Pass);
	}

	/**
	 * Clicking on Login button.
	 */
	@QAFTestStep(description = "I see login splash page by clicking on Log in button")
	public void iSeeLoginSplashPageByClickingOnLogInButton() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		// Verify the log in button and click
		if (recipedetail.getBtnLogin().isPresent()) {
			recipedetail.getBtnLogin().click();
			PerfectoUtils.reportMessage("Clicked: on login button", MessageTypes.Pass);
		} else {
			recipedetail.getRecipedetailBtnLoginrecipebox().verifyPresent();
			recipedetail.getRecipedetailBtnLoginrecipebox().click();
			PerfectoUtils.reportMessage("Clicked: on login button", MessageTypes.Pass);
		}

		// Click Login from Recipe Box page
		/*
		 * if (recipebox.getMyrecipeboxBtnLogin().isPresent()) {
		 * recipebox.getMyrecipeboxBtnLogin().click(); }
		 */
	}

	/**
	 * Selecting the Advance tab for recipes. Select recipes options. CLicking
	 * on Find button.
	 */
	@QAFTestStep(description = "I select Advanced option and choose the recipe options and click find")
	public void iSelectAdvancedOptionAndChooseTheRecipeOptionsAndClickFind() {
		QuickrecipefinderTestPage recipefinder = new QuickrecipefinderTestPage();

		recipefinder.getQuickfinderBtnAdvancedtab().waitForPresent(3000);
		recipefinder.getQuickfinderBtnAdvancedtab().click();
		recipefinder.waitForPageToLoad();
		recipefinder.getquickfinderchkrecipe().click();
		recipefinder.getQuickfinderFind().click();
	}

	/**
	 * Verifying and clicking on Search icon.
	 */
	@QAFTestStep(description = "I see Search Field is displayed by clicking on Search Icon in Recipe screen")
	public void iSeeSearchFieldIsDisplayedByClickingOnSearchIconInRecipeScreen() {
		RecipeslandingTestPage recipelanding = new RecipeslandingTestPage();

		// Click on search icon
		recipelanding.getRecipesIconSearchProducts().waitForPresent(3000);
		recipelanding.getRecipesIconSearchProducts().verifyPresent();
		recipelanding.getRecipesIconSearchProducts().click();
		PerfectoUtils.reportMessage("Clicked on Search Icon from Recipe landing page.", MessageTypes.Pass);

		// Verifying Search icon text
		recipelanding.getRecipesTxtSearchProducts().verifyPresent();
	}

	/**
	 * Navigating to recipe box page.Verifying the recipe box page.Handling the
	 * re login pop up.
	 */
	@QAFTestStep(description = "I navigate to My Recipe Box page")
	public void iNavigateToMyRecipeBoxPage() {
		RecipeslandingTestPage recipelandingpage = new RecipeslandingTestPage();
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		// Click on My Recipe Box
		recipelandingpage.getRecipesRecipeboxname().verifyPresent();
		recipelandingpage.getRecipesRecipeboxname().click();

		// Validate My Recipe Box page
		try {
			recipebox.getRecipeboxLblPagetitle().waitForPresent(1000);
		} catch (Exception e) {
			if (appCrash.getReloginTitle().isPresent()) {
				PerfectoUtils.reportMessage("Handling re-Login popup", MessageTypes.Pass);
				appCrash.getReloginPassword()
						.sendKeys(ConfigurationManager.getBundle().getString("default.user.password"));
				appCrash.getReloginLoginBtn().waitForPresent(5000);
				appCrash.getReloginLoginBtn().click();
			}
		}
		recipebox.getRecipeboxLblPagetitle().waitForPresent(5000);
		recipebox.getRecipeboxLblPagetitle().verifyPresent();
		PerfectoUtils.reportMessage("Navigated to My recipe box page", MessageTypes.Info);
	}

	/**
	 * Verifying the new folder in My Recipe Box page.
	 */
	@QAFTestStep(description = "I should able to see new folder")
	public void iShouldAbleToSeeNewFolder() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		// Verify new folder in My Recipe Box page
		String newFolder = getBundle().getString("NewRecipeboxname");
		weeklygrocery.getShopingListEntryByLable(newFolder).waitForPresent(1000);
		weeklygrocery.getShopingListEntryByLable(newFolder).verifyPresent();
	}

	/**
	 * Validating the elements in recipe landing page
	 */
	@QAFTestStep(description = "I validate the elements in the recipe landing page")
	public void iValidateTheElementsInTheRecipeLandingPage() {
		RecipeslandingTestPage recipelanding = new RecipeslandingTestPage();

		recipelanding.getRecipesQuickfinderBtn().verifyPresent();
		recipelanding.getRecipesPagename().verifyPresent();
		recipelanding.getRecipesRecipeboxname().verifyPresent();
		recipelanding.getRecipesFeatured().verifyPresent();
		recipelanding.getRecipesIconSearchProducts().verifyPresent();
	}

	/**
	 * Validating the elements in Recipe Box landing page.
	 */
	@QAFTestStep(description = "I validate the elements in the recipe box landing page")
	public void iValidateTheElementsInTheRecipeBoxLandingPage() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		recipebox.getRecipeboxLblPagetitle().verifyPresent();
		recipebox.getMyrecipeboxBtnCreateanaccount().verifyPresent();
		recipebox.getMyrecipeboxBtnLogin().verifyPresent();
	}

	/**
	 * Validating the elements in Recipe Detail page.
	 */
	@QAFTestStep(description = "I validate elements in Recipes Detail page")
	public void iValidateElementsInRecipesDetailPage() {
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();
		RecipedetailTestPage recipedetailpage = new RecipedetailTestPage();

		int i = 0;

		if (androidcommonpage.getAppHamburger().isPresent()) {
			androidcommonpage.getAppHamburger().verifyPresent();
		}
		recipedetailpage.getRecipedetailpageHeaderRecipeboxbutton().verifyPresent();
		recipedetailpage.getRecipedetailpageHeaderSharebutton().verifyPresent();
		recipedetailpage.getRecipedetailpageRecipename().verifyPresent();
		recipedetailpage.getRecipedetailImgRecipeimage().verifyPresent();
		if (recipedetailpage.getRecipedetailLblSaverecipe().isPresent()) {
			recipedetailpage.getRecipedetailLblSaverecipe().verifyPresent();
			recipedetailpage.getBtnLogin().verifyPresent();
		} else if (recipedetailpage.getRecipedetailpageAddtoBox().isPresent()) {
			recipedetailpage.getRecipedetailpageAddtoBox().verifyPresent();
		}
		recipedetailpage.getRecipedetailLblPreptime().verifyPresent();
		recipedetailpage.getRecipedetailLblPreptimevalue().verifyPresent();
		recipedetailpage.getRecipedetailLblTotaltime().verifyPresent();
		recipedetailpage.getRecipedetailLblTotaltimevalue().verifyPresent();
		recipedetailpage.getRecipedetailLblServes().verifyPresent();
		recipedetailpage.getRecipedetailLblServesvalue().verifyPresent();
		// recipedetailpage.getRecipedetailLblIngredientsheading().verifyPresent();
		// --Duplicate
		recipedetailpage.getRecipedetailLblIngredientsheading().verifyPresent();
		if (recipedetailpage.getRecipedetailLblNutritioninfo().isPresent()) {
			PerfectoUtils.reportMessage("Nutrition Info is present for selected recipe", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Nutrition Info is not present for selected recipe", MessageTypes.Pass);
		}
		recipedetailpage.getRecipedetailLblIngredientsheading().verifyPresent();

		// Scrolling till the Add to List button is visible
		if (!recipedetailpage.getRecipedetailpageAddtolist().isPresent()) {
			while (!recipedetailpage.getRecipedetailpageAddtolist().isPresent() && i < 2) {
				PerfectoUtils.verticalswipe(80, 50, 2);
				i++;
			}
		}
		recipedetailpage.getRecipedetailpageIngChkbox1().verifyPresent();
		recipedetailpage.getRecipedetailpagelblselectall().verifyPresent();
		recipedetailpage.getRecipedetailpageAddtolist().verifyPresent();

		i = 0;
		// Scrolling till the Review option is visible
		if (!recipedetailpage.getRecipedetailLblReview().isPresent()) {
			while (!recipedetailpage.getRecipedetailLblReview().isPresent() && i < 2) {
				PerfectoUtils.verticalswipe(80, 50, 2);
				i++;
			}
		}
		recipedetailpage.getRecipedetailLblReview().verifyPresent();
	}

	/**
	 * Navigating to instructions tab in Recipe Detail page.
	 */
	@QAFTestStep(description = "I navigate to instructions tab in Recipe Detail page")
	public void iNavigateToInstructionsTabInRecipeDetailPage() {
		RecipedetailTestPage recipedetailpage = new RecipedetailTestPage();

		recipedetailpage.getRecipedetaillblinstructions().waitForPresent(5000);
		recipedetailpage.getRecipedetaillblinstructions().click();

	}

	/**
	 * Validating elements in instructions tab.
	 */
	@QAFTestStep(description = "I validate elements in instructions tab")
	public void iValidateElementsInInstructionsTab() {
		RecipeinstructionsTestPage recipeinstructionsPage = new RecipeinstructionsTestPage();

		int i = 0;
		recipeinstructionsPage.getRecipeinstructionsBtnInstructions().waitForPresent(5000);
		if (recipeinstructionsPage.getRecipeinstructionsLblInstructions().isPresent()) {
			PerfectoUtils.reportMessage("Page is navigated to the instructions tab as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Page is not navigated to the instructions tab", MessageTypes.Fail);
		}

		// Scrolling down if the "Review" label is not visible
		if (!recipeinstructionsPage.getRecipeingredientsLblReview().isPresent()) {
			while (!recipeinstructionsPage.getRecipeingredientsLblReview().isPresent() && i < 3) {
				PerfectoUtils.verticalswipe(80, 50, 2);
				i++;
			}
		}
		recipeinstructionsPage.getRecipeingredientsLblReview().verifyPresent();

	}

	/**
	 * Navigation to Nutrition Info tab in recipe detail page.
	 */
	@QAFTestStep(description = "I navigate to nutritions info tab in Recipe Detail page")
	public void iNavigateToNutritionsInfoTabInRecipeDetailPage() {
		RecipedetailTestPage recipedetailpage = new RecipedetailTestPage();

		IOSStepdef.scrollToElement("Nutrition Info");
		recipedetailpage.getRecipedetailLblNutritioninfo().waitForPresent(5000);
		recipedetailpage.getRecipedetailLblNutritioninfo().click();
	}

	/**
	 * Validating elements in nutrition info tab.
	 */
	@QAFTestStep(description = "I validate elements in nutritions info tab")
	public void iValidateElementsInNutritionsInfoTab() {
		RecipenutritioninfoTestPage recipenutritioninfoPage = new RecipenutritioninfoTestPage();

		int i = 0;
		if (recipenutritioninfoPage.getRecipenutritioninfoBtnNutritioninfo().isPresent()) {
			PerfectoUtils.reportMessage("Page is navigated to the Nutrition Info tab as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Page is not navigated to the Nutrition Info tab", MessageTypes.Fail);
		}
		if (!recipenutritioninfoPage.getRecipenutritioninfoLblServingsize().isPresent()) {
			while (!recipenutritioninfoPage.getRecipenutritioninfoLblServingsize().isPresent() && i < 5) {
				PerfectoUtils.verticalswipe(80, 60, 2);
				i++;
			}
		}
		recipenutritioninfoPage.getRecipenutritioninfoLblServingsize().verifyPresent();
		recipenutritioninfoPage.getRecipenutritioninfoLblServingspercontainer().verifyPresent();
	}

	/*	*//**
			 * Clicking and Validating My Recipe box page.
			 *//*
			 * @QAFTestStep(description =
			 * "I navigate to my recipe Box page from recipe detail screen")
			 * public void iNavigateToMyRecipeBoxPageFromRecipeDetailScreen() {
			 * RecipedetailTestPage recipedetailspage = new
			 * RecipedetailTestPage(); RecipeboxTestPage recipebox = new
			 * RecipeboxTestPage();
			 * 
			 * // Click on My Recipe Box
			 * recipedetailspage.getRecipedetailpageHeaderRecipeboxbutton().
			 * verifyPresent();
			 * recipedetailspage.getRecipedetailpageHeaderRecipeboxbutton().
			 * click(); // Validate My Recipe Box page
			 * recipebox.getRecipeboxLblPagetitle().waitForPresent(3000);
			 * recipebox.getRecipeboxLblPagetitle().verifyPresent(); }
			 */

	/**
	 * Validating Quick Finder landing page.
	 */
	@QAFTestStep(description = "I validate quick finder landing page")
	public void iValidateQuickFinderLandingPage() {
		QuickrecipefinderTestPage quickrecipefinder = new QuickrecipefinderTestPage();

		quickrecipefinder.getQuickfinderLblIwanttomake().verifyPresent();
		quickrecipefinder.getQuickfinderLblWith().verifyPresent();
		quickrecipefinder.getQuickfinderLblIn().verifyPresent();
		quickrecipefinder.getQuickfinderBtnQuickfindertab().verifyPresent();
		quickrecipefinder.getQuickfinderBtnAdvancedtab().verifyPresent();
		quickrecipefinder.getQuickfinderFind().verifyPresent();
	}

	/**
	 * Validating elements in Recipe result list page.
	 */
	@QAFTestStep(description = "I validate recipe result list page")
	public void iValidateRecipeResultListPage() {
		ReciperesultTestPage reciperesult = new ReciperesultTestPage();

		reciperesult.waitForPageToLoad();
		if (reciperesult.getReciperesultCount().isPresent()) {
			reciperesult.getReciperesultCount().verifyPresent();
			reciperesult.getReciperesultRefine().verifyPresent();
			reciperesult.getReciperesultHeaderRecipebox().verifyPresent();
			reciperesult.getReciperesultItem1().verifyPresent();
		} else {
			PerfectoUtils.reportMessage("Unable to see the recipe search result page", MessageTypes.Fail);
		}
	}

	/**
	 * Verifying the Recipe page title. Getting recipe name.
	 */
	@QAFTestStep(description = "I validate search results of recipes")
	public void iValidateSearchResultsOfRecipes() {
		ReciperesultTestPage reciperesult = new ReciperesultTestPage();
		String strResultrecipeName, strSearchRecipe;

		// Verify page title
		reciperesult.getReciperesultPagetitle().waitForPresent(15000);
		reciperesult.getReciperesultPagetitle().verifyPresent();
		// Getting recipe name
		strResultrecipeName = reciperesult.getReciperesultRecipename().getText();
		strSearchRecipe = getBundle().getString("Recipes.RecipesName");

		if (strResultrecipeName.toLowerCase().contains(strSearchRecipe.toLowerCase())) {
			PerfectoUtils.reportMessage(
					"Result Recipe Name: " + strResultrecipeName + " contains search text: " + strSearchRecipe,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Result Recipe Name: " + strResultrecipeName + " does not contain search text: " + strSearchRecipe,
					MessageTypes.Fail);
		}

	}

	/**
	 * Clicking on Add to recipe box button.
	 */
	@QAFTestStep(description = "I click on Add to recipe box button")
	public void iClickOnAddToRecipeBoxButton() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		// Click on Add to Box button
		recipedetail.getRecipedetailpageAddtoBox().waitForPresent(1000);
		recipedetail.getRecipedetailpageAddtoBox().click();
	}

	/**
	 * Verifying the no recipe box found pop up.
	 */
	@QAFTestStep(description = "I verify the no recipe boxes avialable popup")
	public void iVerifyTheNoRecipeBoxesAvialablePopup() {
		RecipedetailTestPage recipedetails = new RecipedetailTestPage();

		try {
			// Checking for the no recipe box found pop-up
			if (recipedetails.getLblErrorpopuptitle().isPresent()) {
				PerfectoUtils.reportMessage("Popup displayed as expected.", MessageTypes.Pass);
				PerfectoUtils.reportMessage("Message: " + recipedetails.getLblErrorpopuptitle().getText(),
						MessageTypes.Pass);
				recipedetails.getBtnErrorpopupno().click();
			} else {
				PerfectoUtils.reportMessage("Popup not displayed.", MessageTypes.Info);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Clicking on Move Recipe button.
	 */
	@QAFTestStep(description = "I click on move recipe button")
	public void iClickOnMoveRecipeButton() {
		RecipeboxresultTestPage recipeboxresult = new RecipeboxresultTestPage();

		try {
			recipeboxresult.getBtnMovetoListByLable(2).waitForPresent(7000);
			recipeboxresult.getBtnMovetoListByLable(2).click();
		} catch (Exception e) {
			recipeboxresult.getBtnMoverecipe().waitForPresent(5000);
			recipeboxresult.getBtnMoverecipe().click();
		}
	}

	/**
	 * Validation of elements in Recipe box as a cold user.
	 */
	@QAFTestStep(description = "I validate the elements in the recipe box landing page as an cold user")
	public void iValidateTheElementsInTheRecipeBoxLandingPageAsAnColdUser() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		// Validate My Recipe Box page
		recipebox.getRecipeboxLblPagetitle().waitForPresent(3000);
		if (recipebox.getRecipeboxLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Page is navigated to My recipe box page as expected", MessageTypes.Pass);
			recipebox.getRecipeboxLblPagetitle().verifyPresent();
			recipebox.getMyrecipeboxBtnCreateanaccount().verifyPresent();
			recipebox.getMyrecipeboxBtnLogin().verifyPresent();
		} else {
			PerfectoUtils.reportMessage("Uanbel to navigat My recipe box page", MessageTypes.Fail);
		}
	}

	/**
	 * Validation of elements in Recipe box as a hot user.
	 */
	@QAFTestStep(description = "I validate the elements in the recipe box landing page as an hot user")
	public void iValidateTheElementsInTheRecipeBoxLandingPageAsAnHotUser() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		recipebox.getRecipeboxLblPagetitle().verifyPresent();
		if (recipebox.getBtnEditfolder().isPresent()) {
			recipebox.getBtnEditfolder().verifyPresent();
		}
		recipebox.getLblAll().verifyPresent();
		recipebox.getRecipeboxBtnPlusicon().verifyPresent();
	}

	/**
	 * Navigation to refine page after clicking Refine button.
	 */
	@QAFTestStep(description = "I navigate to Refine page on clicking refine button")
	public void iNavigateToRefinePageOnClickingRefineButton() {
		ReciperesultTestPage reciperesult = new ReciperesultTestPage();

		reciperesult.waitForPageToLoad();
		if (reciperesult.getReciperesultCount().isPresent()) {
			reciperesult.getReciperesultRefine().waitForPresent(10000);
			reciperesult.getReciperesultRefine().verifyPresent();
			PerfectoUtils.reportMessage("Able to see refine button", MessageTypes.Info);
			reciperesult.getReciperesultRefine().click();
		} else {
			PerfectoUtils.reportMessage("Unable to see recipe list page", MessageTypes.Fail);
		}
	}

	/**
	 * Navigation to Recipe box page from Search result page.
	 */
	@QAFTestStep(description = "I navigate to My Recipe Box page from search result page")
	public void iNavigateToMyRecipeBoxPageFromSearchResultPage() {
		ReciperesultTestPage reciperesultpage = new ReciperesultTestPage();

		reciperesultpage.getReciperesultHeaderRecipebox().waitForPresent(3000);
		reciperesultpage.getReciperesultHeaderRecipebox().click();
	}

	/**
	 * Clicking on create an account link.
	 */
	@QAFTestStep(description = "I navigate to registration page after clicking Create an account link")
	public void iNavigateToRegistrationPageAfterClickingCreateAnAccountLink() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		RegistrastionTestPage registration = new RegistrastionTestPage();
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		recipebox.getMyrecipeboxBtnCreateanaccount().waitForPresent(3000);
		recipebox.getMyrecipeboxBtnCreateanaccount().click();

	}

	/**
	 * Validation of nutrition tab for recipes.
	 */
	@QAFTestStep(description = "I validate nutrition info tab for recipes")
	public void iValidateNutritionInfoTabForRecipes() {
		RecipedetailTestPage recipedetailpage = new RecipedetailTestPage();

		if (recipedetailpage.getRecipedetailLblNutritioninfo().isPresent()) {
			recipedetailpage.getRecipedetailLblNutritioninfo().click();
			PerfectoUtils.verticalswipe();
			PerfectoUtils.reportMessage("Nutrition info tab is present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Nutrition info tab is not present", MessageTypes.Fail);
		}
	}

	/**
	 * Validation of instruction tab for recipes.
	 */
	@QAFTestStep(description = "I validate instruction tab for recipes")
	public void iValidateInstructionTabForRecipes() {
		RecipedetailTestPage recipedetailpage = new RecipedetailTestPage();

		if (recipedetailpage.getRecipedetailLblIngredientsheading().isPresent()) {
			recipedetailpage.getRecipedetailLblIngredientsheading().click();
			recipedetailpage.getRecipedetailLblIngredientsheading().waitForPresent(3000);
			PerfectoUtils.verticalswipe();
			PerfectoUtils.reportMessage("Instruction tab is present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Instruction tab is not present", MessageTypes.Fail);
		}
	}

	// Not avaiable in bdd
	/*
	 * @QAFTestStep(description =
	 * "I select the share icon from recipe details page") public void
	 * iSelectTheShareIconFromRecipeDetailsPage() { RecipedetailTestPage
	 * recipedetails = new RecipedetailTestPage();
	 * 
	 * recipedetails.getRecipedetailpageHeaderSharebutton().waitForPresent(5000)
	 * ; recipedetails.getRecipedetailpageHeaderSharebutton().click(); }
	 */
	/**
	 * Choosing invalid recipe and Clicking on Find button.
	 */
	@QAFTestStep(description = "I choose the invalid recipe options and click find")
	public void iChooseTheInvalidRecipeOptionsAndClickFind() {
		QuickrecipefinderTestPage quickfinder = new QuickrecipefinderTestPage();

		// do{
		// PerfectoUtils.rightSwipeforrecipe();
		// }while (!quickfinder.getQuickfinderBtnMakeItem2().isPresent());
		//
		// do{
		// PerfectoUtils.rightSwipeforrecipes();
		// }while (!quickfinder.getQuickfinderBtnWithItem2().isPresent());

		// Select Make Item2 option and With Item2 option
		quickfinder.getQuickfinderBtnMakeItem2().waitForPresent(5000);
		quickfinder.getQuickfinderBtnMakeItem2().click();
		quickfinder.getQuickfinderBtnMakeItem2().waitForPresent(5000);
		quickfinder.getQuickfinderBtnWithItem2().click();

		// Verifying Find button and click
		quickfinder.getQuickfinderFind().verifyPresent();
		quickfinder.getQuickfinderFind().click();
	}

	/**
	 * Selecting uncheck All Items from Recipe Detail page.
	 */
	@QAFTestStep(description = "I select uncheck all items from recipedetails page")
	public void iSelectUncheckAllItemsFromRecipedetailsPage() {
		RecipedetailTestPage recipedetails = new RecipedetailTestPage();

		recipedetails.getLblUnselectall().waitForPresent(5000);
		recipedetails.getLblUnselectall().click();
		PerfectoUtils.reportMessage("Clicked unselectall.", MessageTypes.Pass);
	}

	/**
	 * Verification of Recipes Items is unchecked.
	 */
	@QAFTestStep(description = "I should see the recipe items unchecked")
	public void iShouldSeeTheRecipeItemsUnchecked() {
		RecipedetailTestPage recipedetails = new RecipedetailTestPage();

		if (recipedetails.getRecipedetailpagelblselectall().isPresent()) {
			PerfectoUtils.reportMessage("Recipe items have been unchecked.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Recipe items have not been unchecked.", MessageTypes.Fail);
		}
	}

	/**
	 * Verification of Recipe result page.
	 */
	@QAFTestStep(description = "I should see the recipe result page")
	public void iShouldSeeTheRecipeResultPage() {
		ReciperesultTestPage reciperesult = new ReciperesultTestPage();

		if (reciperesult.getReciperesultPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to recipe result page.", MessageTypes.Pass);
			PerfectoUtils.reportMessage("Page title: " + reciperesult.getReciperesultPagetitle().getText(),
					MessageTypes.Pass);
			reciperesult.getReciperesultRefine().verifyPresent();
			reciperesult.getReciperesultHeaderRecipebox().verifyPresent();
		} else {
			PerfectoUtils.reportMessage("Not navigated to recipe result page.", MessageTypes.Fail);
		}

	}

	/**
	 * Verification of My Recipe Box page.
	 */
	@QAFTestStep(description = "I verify My Recipe Box page is displayed")
	public void iVerifyMyRecipeBoxPageIsDisplayed() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		recipebox.getRecipeboxLblPagetitle().waitForPresent(5000);
		if (recipebox.getRecipeboxLblPagetitle().isPresent())
			PerfectoUtils.reportMessage("Navigated to My recipe box page", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not Navigated to My recipe box page", MessageTypes.Fail);

	}

	/**
	 * Selecting Refine button in Recipe Result page.
	 */
	@QAFTestStep(description = "I select Refine button in recipe result page")
	public void iSelectRefineButtonInRecipeResult() {
		ReciperesultTestPage reciperesult = new ReciperesultTestPage();

		reciperesult.getReciperesultRefine().waitForPresent(3000);
		reciperesult.getReciperesultRefine().click();
		PerfectoUtils.reportMessage("Clicked on Refine.", MessageTypes.Pass);
	}

	/**
	 * Verifying Added recipe in All recipe box.
	 */

	@QAFTestStep(description = "I verify that recipe is added to All recipe box")
	public void iVerifyThatRecipeIsAddedToAllRecipeBox() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		RecipeboxresultTestPage recipeboxresult = new RecipeboxresultTestPage();
		RecipedetailTestPage recipedetails = new RecipedetailTestPage();

		// Click on My Recipe Box
		recipedetails.getRecipedetailpageHeaderRecipeboxbutton().verifyPresent();
		recipedetails.getRecipedetailpageHeaderRecipeboxbutton().click();
		recipebox.getRecipeboxLblPagetitle().waitForPresent(5000);

		String selectedrecipe = getBundle().getString("recipeName");
		System.out.println(selectedrecipe);
		int count = Integer.parseInt(recipebox.getLblAllCount().getText());

		// Click on All recipe box and verify the added recipe
		if (recipebox.getLblAll().isPresent()) {
			recipebox.getLblAll().click();

			int i = 0;
			while (i < count) {
				String addedrecipe = recipeboxresult.getRecipeboxresultLblRecipename().get(i).getText();
				System.out.println(addedrecipe);

				if (addedrecipe.equalsIgnoreCase(selectedrecipe)) {
					PerfectoUtils.reportMessage("Selected Recipe is present in All recipe box", MessageTypes.Pass);
				} else {
					PerfectoUtils.verticalswipe();
				}
				i++;
			}

		} else {
			PerfectoUtils.reportMessage("Selected Recipe is not present in All recipe box", MessageTypes.Fail);
		}
	}
}
