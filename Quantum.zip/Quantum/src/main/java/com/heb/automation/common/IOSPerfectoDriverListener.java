/**
 * 
 */
package com.heb.automation.common;

import static com.heb.automation.common.PerfectoUtils.closeApplication;
import static com.heb.automation.common.PerfectoUtils.openApplication;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.html5.Location;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.DriverCommand;

import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.ios.steps.IOSStepdef;
import com.perfectomobile.selenium.util.EclipseConnector;
import com.qmetry.qaf.automation.ui.webdriver.CommandTracker;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriverCommandAdapter;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.StringUtil;

public class IOSPerfectoDriverListener extends QAFWebDriverCommandAdapter {
	@Override
	public void beforeCommand(QAFExtendedWebDriver driver, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.QUIT)) {
			try {
				closeApp();
				driver.executeScript("mobile:logs:stop", getBundle().getProperty("deviceLogMapObject"));
				stopVitals(driver);
				driver.close();
				 } catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void afterCommand(QAFExtendedWebDriver driver, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.CLOSE)) {
			try {
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void beforeInitialize(Capabilities desiredCapabilities) {
		try {
			EclipseConnector connector = new EclipseConnector();
			String executionId = connector.getExecutionId();
			System.out.println(executionId);
			if (getBundle().getString("remote.server", "").contains("perfecto")) {
				if (StringUtil.isNotBlank(executionId)) {
					((DesiredCapabilities) desiredCapabilities).setCapability(EclipseConnector.ECLIPSE_EXECUTION_ID,
							executionId);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void onInitialize(QAFExtendedWebDriver driver) {
		System.out.println("------------Opening application -----------");

		startAppVitals(driver, getBundle().getString("app.name"), true);

		/* Starting the device log */
		java.util.Map<String, Object> deviceLog = new HashMap<String, Object>();
		driver.executeScript("mobile:logs:start", deviceLog);
		getBundle().setProperty("deviceLogMapObject", deviceLog);


		/* OpenApplication */
		openApplication(driver, getBundle().getString("app.name"));
		closeApplication(driver, getBundle().getString("app.name"));
		openApplication(driver, getBundle().getString("app.name"));

		
		
		/* Set location */
		java.util.Map<String, Object> params0 = new HashMap<String, Object>();
		driver.executeScript("mobile:location:reset", params0);

		java.util.Map<String, Object> params1 = new HashMap<String, Object>();
		params1.put("address", "San Antonio");
		driver.executeScript("mobile:location:set", params1);
		
		
	}

	@Override
	public void onFailure(QAFExtendedWebDriver driver, CommandTracker commandTracker) {
		/*
		 * super.onFailure(driver, commandTracker); AppcrashhandlerTestPage
		 * appCrash = new AppcrashhandlerTestPage(); IoscommonTestPage iosfun =
		 * new IoscommonTestPage();
		 * 
		 * System.out.println("executing listner"); if
		 * (appCrash.getExceptionBtnOk().isPresent()) {
		 * appCrash.getExceptionBtnOk().click(); PerfectoUtils.reportMessage(
		 * "Unexpected error in Application. Click Ok button"); }
		 */

		/*
		 * if (appCrash.getLoginrequiredPopup().isPresent()) {
		 * appCrash.getEnterPassword().sendKeys("automation1");
		 * appCrash.getSubmitLogincredentials().click(); }
		 */

		/*
		 * if (appCrash.getSoftwareUpdatePopup().isPresent()) {
		 * appCrash.getSoftwareUpdateLater().click(); }
		 */

		/*
		 * if (appCrash.getAllowPopup().isPresent()) {
		 * appCrash.getAllowPopup().click(); PerfectoUtils.reportMessage("Allow is enabled"); }
		 */

		/*
		 * if (iosfun.getAppBtnSkip().isPresent()) {
		 * iosfun.getAppBtnSkip().click(); PerfectoUtils.reportMessage("Clicked Skip button.");
		 * }
		 */
	}

	public static String startAppVitals(QAFExtendedWebDriver driver, String app, boolean startDeviceVitals) {
		Map<String, Object> params = new HashMap<>();
		List<String> vitals = new ArrayList<>();
		vitals.add("all");
		params.put("vitals", vitals);
		params.put("interval", Long.toString(1));
		List<String> sources = new ArrayList<>();
		sources.add(getBundle().getString("app.name"));
		if (startDeviceVitals)
			sources.add("device");
		params.put("sources", sources);
		return (String) driver.executeScript("mobile:monitor:start", params);
	}

	/* Stop vitals */
	public static String stopVitals(QAFExtendedWebDriver driver) {
		Map<String, Object> params = new HashMap<>();
		List<String> vitals = new ArrayList<>();
		vitals.add("all");
		params.put("vitals", vitals);
		return (String) driver.executeScript("mobile:monitor:stop", params);
	}

	private void closeApp() {
		String checklogin;
		try {
			try {
				HomeTestPage homepage = new HomeTestPage();
				if (homepage.getAppFooterHomeicon().isPresent()) {
					homepage.getAppFooterHomeicon().click();
				}
				/*
				 * Adding condition again to click home icon button if home page
				 * not loaded
				 */
				if (!homepage.getHomeLblWelcomeUser().isPresent()) {
					homepage.getAppFooterHomeicon().click();
					homepage.waitForPageToLoad();
				}
				checklogin = homepage.getHomeLblWelcomeUser().getText();

				if (checklogin.contains("Hi,")) {
					IOSStepdef ioscommon = new IOSStepdef();
					ioscommon.iOSLogout();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			closeApplication(getBundle().getString("app.name"));
		} catch (Exception e) {

		}

	}

}
