package com.heb.automation.common.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class StoreResult extends QAFWebComponent {

	@FindBy(locator = "storeloclistview.lbl.storename")
	private QAFWebElement storelocatorLblStorename;
	@FindBy(locator = "storeloclistview.lbl.storeaddress")
	private QAFWebElement storelocatorLblStoreaddress;
	@FindBy(locator = "storeloclistview.lbl.cityname")
	private QAFWebElement storelocatorLblCityname;
	@FindBy(locator = "storeloclistview.lbl.milesaway")
	private QAFWebElement storelocatorLblMilesaway;
	@FindBy(locator = "storeloclistview.img.imageview")
	private QAFWebElement storelocatorimgimageview;

	public StoreResult(String locator) {
		super(locator);
	}

	public QAFWebElement getStorelocatorLblStorename() {
		return storelocatorLblStorename;
	}

	public QAFWebElement getStorelocatorLblStoreaddress() {
		return storelocatorLblStoreaddress;
	}

	public QAFWebElement getStorelocatorLblCityname() {
		return storelocatorLblCityname;
	}

	public QAFWebElement getStorelocatorLblMilesaway() {
		return storelocatorLblMilesaway;
	}
	
	public QAFWebElement getStorelocatorimgimageview() {
		return storelocatorimgimageview;
	}
	

}
