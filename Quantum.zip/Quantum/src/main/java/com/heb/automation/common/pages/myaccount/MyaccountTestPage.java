package com.heb.automation.common.pages.myaccount;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MyaccountTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "myaccount.lbl.pagetitle")
	private QAFWebElement LblPagetitle;
	@FindBy(locator = "myaccount.btn.myprofile")
	private QAFWebElement BtnMyprofile;
	@FindBy(locator = "myaccount.lbl.myhebbarcode")
	private QAFWebElement LblMyhebbarcode;
	@FindBy(locator = "myaccount.lbl.mynotifications")
	private QAFWebElement LblMynotifications;
	@FindBy(locator = "myaccount.lbl.mystore")
	private QAFWebElement BtnMystore;
	@FindBy(locator = "myaccount.lbl.selectstore")
	private QAFWebElement LblSelectstore;
	@FindBy(locator = "myaccount.btn.logout")
	private QAFWebElement BtnLogout;

	@FindBy(locator = "myaccount.myprofile.lbl.pagetitle")
	private QAFWebElement myprofileLblPagetitle;
	@FindBy(locator = "myaccount.myhebbarcode.img.title")
	private QAFWebElement myhebbarcodeImgTitle;
	@FindBy(locator = "myaccount.mynotification.lbl.pagetitle")
	private QAFWebElement mynotificationLblPagetitle;
	@FindBy(locator = "myaccount.mystore.lbl.pagetitle")
	private QAFWebElement mystoreLblPagetitle;

	@FindBy(locator = "myaccount.btn.signin")
	private QAFWebElement BtnSignin;
	@FindBy(locator = "myaccount.lbl.contactus")
	private QAFWebElement LblContactus;
	@FindBy(locator = "myaccount.lbl.ratethisapp")
	private QAFWebElement LblRatethisapp;

	@FindBy(locator = "myaccount.btn.faqs")
	private QAFWebElement BtnFaqs;
	@FindBy(locator = "myaccount.faqs.lbl.pagetitle")
	private QAFWebElement faqsLblPagetitle;

	@FindBy(locator = "myaccount.btn.privacypolicy")
	private QAFWebElement BtnPrivacypolicy;
	@FindBy(locator = "myaccount.privacypolicy.lbl.pagetitle")
	private QAFWebElement PrivacypolicyLblPagetitle;

	@FindBy(locator = "myaccount.btn.termsncondtn")
	private QAFWebElement BtnTermsncondtn;
	@FindBy(locator = "myaccount.termsncondtsn.lbl.pgtitle")
	private QAFWebElement TermsncondtsnLblPagetitle;

	@FindBy(locator = "myaccount.btn.addressbook")
	private QAFWebElement BtnAddressbook;
	@FindBy(locator = "myaccount.addressbook.lbl.pgtitle")
	private QAFWebElement AddressbookLblPagetitle;

	@FindBy(locator = "myaccount.lbl.ratethisapp")
	private QAFWebElement lblRatethisapp;
	@FindBy(locator = "myaccount.lbl.contactus")
	private QAFWebElement lblContactus;

	@FindBy(locator = "myaccount.lbl.couponsandpromotions")
	private QAFWebElement lblCouponsandpromotions;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblPagetitle() {
		return LblPagetitle;
	}

	public QAFWebElement getBtnMyprofile() {
		return BtnMyprofile;
	}

	public QAFWebElement getLblMyhebbarcode() {
		return LblMyhebbarcode;
	}

	public QAFWebElement getLblMynotifications() {
		return LblMynotifications;
	}

	public QAFWebElement getBtnMystore() {
		return BtnMystore;
	}

	public QAFWebElement getLblSelectstore() {
		return LblSelectstore;
	}

	public QAFWebElement getBtnLogout() {
		return BtnLogout;
	}

	public QAFWebElement getMyprofileLblPagetitle() {
		return myprofileLblPagetitle;
	}

	public QAFWebElement getMyhebbarcodeImgTitle() {
		return myhebbarcodeImgTitle;
	}

	public QAFWebElement getMynotificationLblPagetitle() {
		return mynotificationLblPagetitle;
	}

	public QAFWebElement getBtnSignin() {
		return BtnSignin;
	}

	public QAFWebElement getLblContactus() {
		return LblContactus;
	}

	public QAFWebElement getLblRatethisapp() {
		return LblRatethisapp;
	}

	public QAFWebElement getBtnFaqs() {
		return BtnFaqs;
	}

	public QAFWebElement getBtnPrivacypolicy() {
		return BtnPrivacypolicy;
	}

	public QAFWebElement getBtnTermsncondtn() {
		return BtnTermsncondtn;
	}

	public QAFWebElement getBtnAddressbookIOS() {
		return BtnAddressbook;
	}

	public QAFWebElement getMystoreLblPagetitle() {
		return mystoreLblPagetitle;
	}

	public QAFWebElement getFaqsLblPagetitle() {
		return faqsLblPagetitle;
	}

	public QAFWebElement getTermsncondtnLblPagetitle() {
		return TermsncondtsnLblPagetitle;
	}

	public QAFWebElement getPrivacypolicyLblPagetitle() {
		return PrivacypolicyLblPagetitle;
	}

	public QAFWebElement getAddressbookLblPagetitle() {
		return AddressbookLblPagetitle;
	}

	public QAFWebElement getLblCouponsandpromotions() {
		return lblCouponsandpromotions;
	}
}
