/**
 * 
 */
package com.heb.automation.common.steps.myaccount;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.android.steps.AndroidStepDef;
import com.heb.automation.android.steps.coupons.AndroidStepdefCoupons;
import com.heb.automation.android.steps.myaccount.AndroidStepDefMyaccount;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.coupons.CouponsselectionTestPage;
import com.heb.automation.common.pages.myaccount.MyaccountTestPage;
import com.heb.automation.common.pages.myaccount.MyaccountstoredetailsTestPage;
import com.heb.automation.common.pages.myaccount.MyhebbarcodeTestPage;
import com.heb.automation.common.pages.myaccount.MynotificationsTestPage;
import com.heb.automation.common.pages.myaccount.MyprofileTestPage;
import com.heb.automation.common.pages.registeration.ExtraOffersTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.pages.registeration.WantmoreTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.storelocator.StorelocatorTestPage;
import com.heb.automation.common.steps.CommonSteps;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.heb.automation.ios.steps.myaccount.IOSStepDefMyAccounts;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in Common MyAccount

	I navigate to My profile page
	I navigate to the Change my H-E-B store
	I validate the newly selected store details
	I see My Account/More page
	I validate the user registered for offers in wantmore page
	I click on my notifications
	I navigate to want more page on clicking Skip for Now
	I navigate to change password page
	I see want more screen on selecting stores
	I Verify the Keyboard is getting appeared only when the user taps on a field
	I click on first name field
	I verify the Keyboard is getting closed on clicking the Done button
	I navigate to My Notifications page
	I verify Signup message is availble in Get Extra Offers tab
	I click on Weekly ad subscriptions toggle switch
	I verify the Select a store popup is getting populated
	I should see the My Account/ More screen
	I verify the Save button is disabled by default
	I verify the Save button is getting enabled
	I validate title of MyAccount/More page
	I see Want more screen with the selected store
	I navigate to Redeem Coupon page
	I click on password field in Registration page
	I click done from want more page
	I see the selected store in My Store
	I see select a store under My Store
	I see password is not valid text
	I validate emailid&pwd by entering input with beyond limit in registeration page
	I click on last name field in registration page
	I click on email field in registration page
	I see Registration page
	I navigate to Get Extra Offers page
	I validate Signup message in Get Extra Offers tab
	I verify the Redeem Coupon cell is displayed
	I validate the My Profile page elements
	I login with empty email id and valid password
	I login with empty password and valid email id
	I validate the login button is disabled
	I enter valid credentials {0}{1} in login splash page
	I navigate to Redeem Coupon page from Homepage
	I verify Done button is enabled by default
	I keep the mobile idle for 10 minutes
	I verify by default Login button is disabled on the Log In page
	I verify Forgot Password link is displayed on the Log In page
	I click on forgot password link
	I verify user navigates to Forgot Password page
	I verify instructions are displayed on the Forgot Password page
	I verify submit button is disabled by default
	Navigate to extra offers page from Want more page
	I verify My HEB Barcode appears instead of Redeem Coupons
	Verify the Save button is disabled by default in Extra offers page
	Clear the phone number field in offers page
	Verify the Save button is enabled in offers page
	Select Save button from Extra offers page
	I verify Redeem Coupons does not appear on the Homescreen
	I verify Redeem Coupons is not present on the Homescreen
	I verify Valued Partner text appears in red
	I verify regular HEB Barcode screen is displayed
	I validate error message for already enrolled Phone number
	I enter all required fields in offers page with alredy registered phone number
*/

public class CommonStepDefMyAccounts {

	/**
	 * Clicking on My Profile option and verifying whether navigated to the page
	 * successfully 1. Checkpoint--> First name text field
	 * 
	 */
	@QAFTestStep(description = "I navigate to My profile page")
	public void iNavigateToMyProfilePage() {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		MyprofileTestPage myprofile = new MyprofileTestPage();

		myaccount.getBtnMyprofile().waitForPresent(5000);
		myaccount.getBtnMyprofile().click();
		PerfectoUtils.reportMessage("Selected My Profile option.", MessageTypes.Pass);

		try {
			myprofile.getMyprofileTxtFirstname().waitForPresent(5000);
		} catch (Exception e) {
			myaccount.getBtnMyprofile().click();
			myprofile.getMyprofileTxtFirstname().verifyPresent();
		}
	}

	/**
	 * Clicking on Change My HEB Store option
	 * 
	 */
	@QAFTestStep(description = "I navigate to the Change my H-E-B store")
	public void iNavigateToTheChangeMyHEBStore() {
		MyaccountstoredetailsTestPage storedetails = new MyaccountstoredetailsTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		String strOldStoreName = null;

		// Set location
		/*
		 * java.util.Map<String, Object> params1 = new HashMap<String,
		 * Object>(); params1.put("address", "San Antonio, TX");
		 * PerfectoUtils.getAppiumDriver().executeScript("mobile:location:set",
		 * params1);
		 */

		if (storelocator.getStorelocatorBtnAllow().isPresent()) {
			storelocator.getStorelocatorBtnAllow().click();
		}
		PerfectoUtils.verticalswipe();
		storedetails.getLblChangemyhebstore().waitForPresent(5000);

		if (storedetails.getLblStorename().isPresent()) {
			strOldStoreName = storedetails.getLblStorename().getText();
		} else {
			strOldStoreName = storedetails.getLblStorename1().getText();
		}

		getBundle().setProperty("oldStoreName", strOldStoreName);
		storedetails.getLblChangemyhebstore().verifyPresent();
		String changeStrTXt = storedetails.getLblChangemyhebstore().getText();

		// if(changeStrTXt.contains("Change"))
		if (changeStrTXt.contains("Set") || changeStrTXt.contains("Change")) {
			PerfectoUtils.reportMessage("Change store option text matches", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Change store option text not matches", MessageTypes.Fail);
		}
		storedetails.getLblChangemyhebstore().click();
		PerfectoUtils.reportMessage("Clicked on Change My H-E-B Store.", MessageTypes.Pass);

		if (storedetails.getLblChangemyhebstore().isPresent()) {
			storedetails.getLblChangemyhebstore().click();
		}
	}

	/**
	 * Comparing the Store details in My Profile page with the Selected Store
	 * details
	 * 
	 */
	@QAFTestStep(description = "I validate the newly selected store details")
	public void iValidateTheNewlySelectedStoreDetails() {
		MyaccountstoredetailsTestPage storedetails = new MyaccountstoredetailsTestPage();

		String storenamefromstoredetail = null;
		String selectedStoreName = getBundle().getString("StoreName");
		storedetails.waitForPageToLoad();

		if (storedetails.getLblStorename().isPresent()) {
			storenamefromstoredetail = storedetails.getLblStorename().getText();
		} else {
			storenamefromstoredetail = storedetails.getLblStorename1().getText();
		}

		if (selectedStoreName.equals(storenamefromstoredetail)) {
			PerfectoUtils.reportMessage("The Selected StoreName " + selectedStoreName + " is displayed as expected",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("The Selected Storename " + selectedStoreName + " is not displayed",
					MessageTypes.Fail);
		}

	}

	/**
	 * Clicking on hamburger button and verifying whether the pagetitle is
	 * visible
	 * 
	 */
	@QAFTestStep(description = "I see My Account/More page")
	public void iSeeMyAccountPage() {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		androidcommon.getAppHamburger().click();
		PerfectoUtils.reportMessage("Hamburger icon..", MessageTypes.Pass);
		myaccount.getLblPagetitle().verifyPresent();
	}

	/**
	 * Verifying whether the user registered for Offers 1. Check point --> The
	 * below text should be present "Reply with a ‘Y’ or ‘Yes’ to the message
	 * sent to your phone to complete your registration."
	 * 
	 */
	@QAFTestStep(description = "I validate the user registered for offers in wantmore page")
	public static void iValidateTheUserRegisteredForOffersInWantmorePage() {
		WantmoreTestPage wantmore = new WantmoreTestPage();
		String msg = null;

		String isAutoEnrollEnabled = getBundle().getString("isAutoEnrollEnabled");

		if (isAutoEnrollEnabled.equalsIgnoreCase("true")) {

			wantmore.getLblExtraOffersDescription().waitForPresent(50000);
			msg = wantmore.getLblExtraOffersDescription().getText();

			if (msg.equals(
					"Reply with a ‘Y’ or ‘Yes’ to the message sent to your phone to complete your registration.")) {
				PerfectoUtils.reportMessage("User successfully registered for offers", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("User not registered for offers", MessageTypes.Fail);
			}

		} else {

			wantmore.getLblDigitalcouponsstatus().waitForPresent(50000);
			try {
				msg = wantmore.getLblDigitalcouponsstatus().getText();
			} catch (Exception e) {
				PerfectoUtils.reportMessage("Error occured while Getting the Digital Coupons Status.",
						MessageTypes.Fail);
			}

			if (msg.equals("On")) {
				PerfectoUtils.reportMessage("User successfully registered for offers", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("User not registered for offers", MessageTypes.Fail);
			}
		}

	}

	/**
	 * Clicking on My Notification
	 * 
	 */
	@QAFTestStep(description = "I click on my notifications")
	public void iClickOnMyNotifications() {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		MyaccountTestPage accounttestpage = new MyaccountTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			myaccount.getLblMynotifications().waitForPresent(3000);
			myaccount.getLblMynotifications().click();
			PerfectoUtils.reportMessage("Clicked on My Notifications.", MessageTypes.Pass);
			ioscommon.getAppLblLoading().waitForNotPresent(60000);
		} else {

			accounttestpage.getLblCouponsandpromotions().waitForPresent(2000);
			accounttestpage.getLblCouponsandpromotions().click();
			accounttestpage.waitForPageToLoad();
			accounttestpage.getLblCouponsandpromotions().verifyPresent();
			PerfectoUtils.reportMessage("Coupons&Promotion is displayed ", MessageTypes.Pass);

		}
	}

	/**
	 * Clicking on "Skip for now" option
	 * 
	 */
	@QAFTestStep(description = "I navigate to want more page on clicking Skip for Now")
	public static void iNavigateToWantMorePageOnClickingSkipForNow() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		WeeklygroceriesTestPage randomdata = new WeeklygroceriesTestPage();

		randomdata.getShopingListEntryByLable("Welcome").waitForNotPresent(50000);
		register.getLblPickstore().waitForPresent(15000);
		register.getLblPickstore().verifyPresent();
		register.getBtnSkipfornow().click();
		PerfectoUtils.reportMessage("Clicked on Skip for Now..", MessageTypes.Pass);
	}

	/**
	 * Clicking on Change Password option from My Profile page
	 * 
	 */
	@QAFTestStep(description = "I navigate to change password page")
	public void iNavigateToChangePasswordPage() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		myprofile.getLnkChgpwd().waitForPresent(5000);
		myprofile.getLnkChgpwd().click();
		PerfectoUtils.reportMessage("Clicked on Change Password..", MessageTypes.Pass);
	}

	/**
	 * Verifying the properties on Want More screen 1. Checkpoint --> page
	 * header
	 * 
	 */
	@QAFTestStep(description = "I see want more screen on selecting stores")
	public void iSeeWantMoreScreenOnSelectingStores() {
		WantmoreTestPage wantmore = new WantmoreTestPage();

		wantmore.getLblPageHeader().waitForPresent(50000);
		wantmore.getLblPageDescription().verifyPresent();
	}

	/**
	 * Verify the keyboard is not visible initially on navigating to
	 * "My Profile" page 1. Checkpoint --> next button from keyboard
	 * 
	 */
	@QAFTestStep(description = "I Verify the Keyboard is getting appeared only when the user taps on a field")
	public void iVerifyTheKeyboardIsGettingAppearedOnlyWhenTheUserTapsOnAField() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Next");
		String isBtnNextVisible = (String) myprofile.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
				params1);

		if (isBtnNextVisible.equalsIgnoreCase("false")) {
			PerfectoUtils.reportMessage("Keyboard is not visible by default, before tapping on any field.",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Keyboard is Visible by default, before tapping on any field",
					MessageTypes.Fail);
		}
	}

	/**
	 * Clicking on "First Name" field on My profile page
	 * 
	 */
	@QAFTestStep(description = "I click on first name field")
	public void iClickOnFirstNameField() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		myprofile.getMyprofileTxtFirstname().waitForPresent(3000);
		myprofile.getMyprofileTxtFirstname().click();
		PerfectoUtils.reportMessage("CLicked on First name field.");

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Delete");
		String isBtnDeleteVisible = (String) myprofile.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
				params1);

		if (isBtnDeleteVisible.equalsIgnoreCase("true")) {
			myprofile.getTestBase().getDriver().executeScript("mobile:text:select", params1);
		}
	}

	/**
	 * Clicking "Done" button from the keyboard and verifying the Keyboard is
	 * getting closed
	 * 
	 */
	@QAFTestStep(description = "I verify the Keyboard is getting closed on clicking the Done button")
	public void iVerifyTheKeyboardIsGettingClosedOnClickingTheDoneButton() {
		MyprofileTestPage myprofile = new MyprofileTestPage();
		String isBtnDoneVisible = null;

		// Clicking on Done button from Keyboard
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");
		String isBtnDoneVisible1 = (String) myprofile.getTestBase().getDriver().executeScript("mobile:text:find",
				params1);

		if (isBtnDoneVisible1.equalsIgnoreCase("true")) {
			myprofile.getTestBase().getDriver().executeScript("mobile:text:select", params1);
			PerfectoUtils.reportMessage("Clicked Done button");
		} else {
			Map<String, Object> params2 = new HashMap<>();
			params2.put("content", "Done");
			params2.put("profile", "DocumentConversion_Speed");
			params2.put("analysis", "manual");
			params2.put("inverse", "yes");
			params2.put("screen.top", "69%");
			params2.put("screen.height", "31%");
			params2.put("screen.left", "51%");
			params2.put("screen.width", "49%");
			isBtnDoneVisible1 = (String) myprofile.getTestBase().getDriver().executeScript("mobile:text:find", params2);

			myprofile.getTestBase().getDriver().executeScript("mobile:text:select", params2);
			PerfectoUtils.reportMessage("Clicked Done button");

			isBtnDoneVisible = (String) myprofile.getTestBase().getDriver().executeScript("mobile:text:find", params2);

			if (isBtnDoneVisible.equalsIgnoreCase("false")) {
				PerfectoUtils.reportMessage("Keyboard is getting closed on clicking Done button as expected.",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Keyboard is not getting closed on clicking Done button",
						MessageTypes.Fail);
			}
		}
	}

	/**
	 * Clicking on My Notifications option from My Account page
	 * 
	 */
	@QAFTestStep(description = "I navigate to My Notifications page")
	public void iNavigateToMyNotificationsPage() {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		String isAutoEnrollEnabled = getBundle().getString("isAutoEnrollEnabled");

		if (isAutoEnrollEnabled.equalsIgnoreCase("true")) {
			myaccount.getLblMynotifications().waitForPresent(3000);
			myaccount.getLblMynotifications().click();
			PerfectoUtils.reportMessage("Clicked on My Notifications.", MessageTypes.Pass);

		} else {
			myaccount.getLblCouponsandpromotions().waitForPresent(1000);
			myaccount.getLblCouponsandpromotions().click();
			PerfectoUtils.reportMessage("Clicked on Coupons and Promotions.", MessageTypes.Pass);
		}

		ioscommon.getAppLblLoading().waitForNotPresent(60000);
	}

	/**
	 * Verify the SignUp message is visible in Extra Offers tab
	 * 
	 */
	@QAFTestStep(description = "I verify Signup message is availble in Get Extra Offers tab")
	public void iVerifySignupMessageIsAvailbleInGetExtraOffersTab() {
		MynotificationsTestPage mynotifications = new MynotificationsTestPage();
		WantmoreTestPage wantmore = new WantmoreTestPage();

		String isAutoEnrollEnabled = getBundle().getString("isAutoEnrollEnabled");

		if (isAutoEnrollEnabled.equalsIgnoreCase("true")) {

			if (mynotifications.getlblTextmsgsforsignup().isPresent()) {
				PerfectoUtils.reportMessage("Signup message is available in the Get Extra Offers section",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Signup message is not available in the Get Extra Offers section",
						MessageTypes.Fail);
			}
		} else {
			if (wantmore.getLblDigitalcouponsstatus().isPresent()) {
				PerfectoUtils.reportMessage("Signup message is available in Coupons and Promotions section",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Signup message is not available in Coupons and Promotions section",
						MessageTypes.Fail);
			}
		}
	}

	/**
	 * Clicking on Weekly Ads subscription toggle switch
	 * 
	 */
	@QAFTestStep(description = "I click on Weekly ad subscriptions toggle switch")
	public void iClickOnWeeklyAdSubscriptionsToggleSwitch() {
		MynotificationsTestPage mynotifications = new MynotificationsTestPage();

		mynotifications.getRbtWeeklyad().waitForPresent(3000);
		mynotifications.getRbtWeeklyad().click();
		PerfectoUtils.reportMessage("Clicked on Weekly ad toggle switch.", MessageTypes.Pass);
	}

	/**
	 * Verify the Select a Store pop-up is getting populated. Checkpoint -->
	 * Select a Store popup title
	 * 
	 * 
	 */
	@QAFTestStep(description = "I verify the Select a store popup is getting populated")
	public void iVerifyTheSelectAStorePopupIsGettingPopulated() {
		MynotificationsTestPage mynotifications = new MynotificationsTestPage();

		mynotifications.getLblSelectastore().waitForPresent(10000);

		if (mynotifications.getLblSelectastore().isPresent()) {
			PerfectoUtils.reportMessage("Select a Store Popup found.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Select a Store Popup not found.", MessageTypes.Fail);
		}
	}

	/**
	 * Verify whether navigated to My Profile page
	 *
	 */
	@QAFTestStep(description = "I should see the My Account/ More screen")
	public void iShouldSeeTheMyAccountMoreScreen() {
		MyaccountTestPage myaccounts = new MyaccountTestPage();

		myaccounts.getBtnMyprofile().waitForPresent(5000);

		if (myaccounts.getBtnMyprofile().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to My Accounts page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not Navigated to My Accounts page.", MessageTypes.Fail);
		}
	}

	/**
	 * Verify the Save button from My Profile page is Disabled by default.
	 * Checkpoint --> enabled attribute should be false
	 * 
	 */
	@QAFTestStep(description = "I verify the Save button is disabled by default")
	public void iVerifyTheSaveButtonIsDisabledByDefault() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		myprofile.getBtnSaveprofile().verifyPresent();

		if (myprofile.getBtnSaveprofile().getAttribute("enabled").equalsIgnoreCase("false")) {
			PerfectoUtils.reportMessage("Save button is disabled by default", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Save button is not disabled by default", MessageTypes.Fail);
		}
	}

	/**
	 * Verify the Save button from My Profile page get enabled Checkpoint -->
	 * enabled attribute should be true
	 * 
	 */
	@QAFTestStep(description = "I verify the Save button is getting enabled")
	public void iVerifyTheSaveButtonIsGettingEnabled() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		PerfectoUtils.verticalswipe();
		myprofile.getBtnSaveprofile().verifyPresent();

		if (myprofile.getBtnSaveprofile().getAttribute("Enabled").equalsIgnoreCase("false")) {
			PerfectoUtils.reportMessage("Save button is not enabled", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("Save button is Enabled", MessageTypes.Pass);
		}
	}

	/**
	 * Validating the title of My Account page
	 * 
	 */
	@QAFTestStep(description = "I validate title of MyAccount/More page")
	public void iValidateTitleOfMyAccountMorePage() {
		MyaccountTestPage myaccount = new MyaccountTestPage();

		myaccount.getLblPagetitle().waitForPresent(3000);
		myaccount.getLblPagetitle().verifyPresent();
	}

	/**
	 * Verifying whether the selected Store is getting displayed on Want More
	 * screen
	 * 
	 */
	@QAFTestStep(description = "I see Want more screen with the selected store")
	public void iSeeWantMoreScreenWithTheSelectedStore() {
		WantmoreTestPage wantmorepage = new WantmoreTestPage();

		wantmorepage.getLblMystoreaddress().waitForPresent(5000);
		String strSelectedStore = getBundle().getString("StoreAddress");
		String strStoreFromWantMoreScreen = wantmorepage.getLblMystoreaddress().getText();

		if (strStoreFromWantMoreScreen.contains(strSelectedStore)) {
			PerfectoUtils.reportMessage("Store has been changed Successfully.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Store update failed.", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking on My HEB barcode option from My Account page
	 * 
	 */
	@QAFTestStep(description = "I navigate to Redeem Coupon page")
	public void iNavigateToMyHEBBarcodePage() {
		MyaccountTestPage myaccount = new MyaccountTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			myaccount.getLblMyhebbarcode().waitForPresent(3000);
			myaccount.getLblMyhebbarcode().click();
			PerfectoUtils.reportMessage("Clicked on My HEB barcode option.", MessageTypes.Pass);
		} else {
			if (!myaccount.getLblMyhebbarcode().isPresent()) {
				PerfectoUtils.reportMessage("Redeem Coupon section is not present", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Redeem Coupon section is present while flagstatus is false",
						MessageTypes.Fail);
			}
		}

	}

	/**
	 * Clicking on Password text field from Registration page
	 * 
	 */
	@QAFTestStep(description = "I click on password field in Registration page")
	public void iClickOnPasswordField() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getRegistrationTxtPassword().waitForPresent(3000);
		register.getRegistrationTxtPassword().click();
		PerfectoUtils.reportMessage("CLicked on Password field.", MessageTypes.Pass);
	}

	/**
	 * Clicking on Done button from Want More page
	 * 
	 */
	@QAFTestStep(description = "I click done from want more page")
	public static void iClickDoneFromWantMorePage() {
		WantmoreTestPage wantmore = new WantmoreTestPage();

		wantmore.waitForPageToLoad();
		PerfectoUtils.verticalswipe();

		try {
			PerfectoUtils.verticalswipe();
			wantmore.getBtnDone().waitForPresent(3000);
			wantmore.getBtnDone().click();
			PerfectoUtils.reportMessage("Clicked Done button..", MessageTypes.Pass);
			wantmore.getBtnDone().waitForNotPresent(20000);
		} catch (Exception e) {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "DONE");
			String isBtnDoneVisible = (String) wantmore.getTestBase().getDriver()
					.executeScript("mobile:checkpoint:text", params1);

			if (isBtnDoneVisible.equalsIgnoreCase("true")) {
				wantmore.getTestBase().getDriver().executeScript("mobile:text:select", params1);
			} else {
				PerfectoUtils.reportMessage("Error occured while clicking on Done button.", MessageTypes.Fail);
			}
		}
	}

	/**
	 * Verifying whether the Selected Store is getting displayed in My HEB Page
	 * 
	 */
	@QAFTestStep(description = "I see the selected store in My Store")
	public void iSeeTheSelectedStoreInMyStore() {
		MyaccountTestPage myaccount = new MyaccountTestPage();

		String storeName = getBundle().getString("StoreAddress");
		myaccount.getLblSelectstore().verifyPresent();

		if ((myaccount.getLblSelectstore().getText()).contains(storeName)) {
			PerfectoUtils.reportMessage("Selected Store is updated as My Store", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected Store is not updated as My Store", MessageTypes.Fail);
		}
	}

	/**
	 * Verifying whether the "Select a Store" option is getting displayed under
	 * My HEB option
	 * 
	 */
	@QAFTestStep(description = "I see select a store under My Store")
	public void iSeeSelectAStoreUnderMyStore() {
		MyaccountTestPage myaccount = new MyaccountTestPage();

		myaccount.getLblSelectstore().waitForPresent(3000);

		if ((myaccount.getLblSelectstore().getText()).equals("Select a Store")) {
			PerfectoUtils.reportMessage("Select a Store is displayed as expected!!", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User selected store while registeration", MessageTypes.Fail);
		}
	}

	/**
	 * Verifying the error message for incorrect password entry
	 * 
	 */
	@QAFTestStep(description = "I see password is not valid text")
	public void iSeePasswordIsNotValidText() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		String errmsg = "Password must be at least eight characters and contains at least one number and one letter.Please enter a valid password.";

		CommonSteps.validaterrormessages(errmsg, register.getRegistrationTxtEmail());
	}

	/**
	 * Validating the user not able to enter emailID and password beyond the
	 * limit. Password --> 25 chars , Email --> 40 chars
	 * 
	 */
	@QAFTestStep(description = "I validate emailid&pwd by entering input with beyond limit in registeration page")
	public void iValidateEmailidPwdByEnteringInputWithBeyondLimitInRegisterationPage() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		String strEmailId = getBundle().getString("registration.Emailaddress1_Limit");
		String strpassword = getBundle().getString("registration.Password_Limit");

		register.getRegistrationTxtEmail().waitForPresent(3000);
		register.getRegistrationTxtEmail().click();
		register.getRegistrationTxtEmail().sendKeys(strEmailId);

		if ((register.getRegistrationTxtEmail().getText().length()) == 40) {
			PerfectoUtils.reportMessage(
					"App not allowed user to enter emailid when the limit is reached(40 characters) as expected",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("App allowed user to enter emailid when the limit is reached(40 characters)",
					MessageTypes.Fail);
		}

		register.getRegistrationTxtPassword().click();
		register.getRegistrationTxtPassword().sendKeys(strpassword);

		register.getImgShowPwd().click();
		if ((register.getRegistrationTxtPassword().getText().length()) == 25) {
			PerfectoUtils.reportMessage(
					"App not allowed user to enter password when the limit is reached(25 characters) as expected",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"App not allowed user to enter password when the limit is reached(25 characters)",
					MessageTypes.Fail);
		}

		register.getRegistrationTxtFirstname().click();
		register.getRegistrationTxtFirstname().sendKeys("fname");
		PerfectoUtils.getAppiumDriver().hideKeyboard();
		PerfectoUtils.verticalswipe();
		register.getRegistrationChkIagree().click();
		PerfectoUtils.reportMessage("Clicked on I Agree Checkbox..", MessageTypes.Pass);
		register.getRegistrationBtnSubmit().click();
		PerfectoUtils.reportMessage("Created Account!!", MessageTypes.Pass);
		PerfectoUtils.getAppiumDriver().hideKeyboard();

	}

	/**
	 * Clicking on last name text field in registration page
	 * 
	 */
	@QAFTestStep(description = "I click on last name field in registration page")
	public void iClickOnLastNameFieldInRegistrationPage() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getRegistrationTxtLastname().waitForPresent(3000);
		register.getRegistrationTxtLastname().click();
		PerfectoUtils.reportMessage("CLicked on Last name field.", MessageTypes.Pass);

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Delete");
		String isBtnDeleteVisible = (String) register.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
				params1);

		if (isBtnDeleteVisible.equalsIgnoreCase("true")) {
			register.getTestBase().getDriver().executeScript("mobile:text:select");
		}
	}

	/**
	 * Clicking on Email text field in registration page
	 * 
	 */
	@QAFTestStep(description = "I click on email field in registration page")
	public void iClickOnEmailFieldInRegistrationPage() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getRegistrationTxtEmail().waitForPresent(3000);
		register.getRegistrationTxtEmail().click();
		PerfectoUtils.reportMessage("CLicked on Email field.", MessageTypes.Pass);
	}

	/**
	 * Verifying the properties from registration page. 1. First name 2. last
	 * name 3. Email 4. Password 5. Submit button
	 * 
	 */
	@QAFTestStep(description = "I see Registration page")
	public void iSeeRegistrationPage() {
		RegistrastionTestPage registerpage = new RegistrastionTestPage();
		IOSStepDefMyAccounts iosmyaccount = new IOSStepDefMyAccounts();
		AndroidStepDefMyaccount androidmyacc = new AndroidStepDefMyaccount();

		try {
			androidmyacc.byTappingAnywhereClickingDeviceBackButtonShouldDismissTheKeyboard();
		} catch (Exception e) {
			iosmyaccount.byTappingAnywhereClickingDeviceBackButtonShouldDismissTheKeyboard();
		}

		registerpage.getRegistrationTxtFirstname().verifyPresent();
		registerpage.getRegistrationTxtLastname().verifyPresent();
		registerpage.getRegistrationTxtEmail().verifyPresent();
		registerpage.getRegistrationTxtPassword().verifyPresent();
		PerfectoUtils.verticalswipe();
		registerpage.getRegistrationBtnSubmit().verifyPresent();
	}

	/**
	 * Clicking on Extra Offers page
	 * 
	 */
	@QAFTestStep(description = "I navigate to Get Extra Offers page")
	public void iNavigateToGetExtraOffersPage() {
		MynotificationsTestPage mynotify = new MynotificationsTestPage();
		ExtraOffersTestPage offerspage = new ExtraOffersTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			mynotify.getLblGetextraoffers().waitForPresent(5000);
			mynotify.getLblGetextraoffers().click();
			PerfectoUtils.reportMessage("Clicked on Get Extra Offers..", MessageTypes.Pass);
		} else {
			offerspage.getLbldigitalcoupons().click();
			PerfectoUtils.reportMessage("Clicked on Digital Coupon ..");
			offerspage.gettxtdigitalcoupons().waitForPresent(20000);
			offerspage.gettxtdigitalcoupons().verifyPresent();
		}
	}

	/**
	 * validating the Sign up test in Extra Offers page. Text --> Reply with a
	 * ‘Y’ or ‘Yes’ to the message sent to your phone to complete your
	 * registration.
	 * 
	 */
	@QAFTestStep(description = "I validate Signup message in Get Extra Offers tab")
	public void iValidateSignupMessageInGetExtraOffersTab() {
		MynotificationsTestPage mynotify = new MynotificationsTestPage();
		WantmoreTestPage wantmore = new WantmoreTestPage();

		String msg;

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			mynotify.getlblTextmsgsforsignup().waitForPresent(5000);
			msg = mynotify.getlblTextmsgsforsignup().getText();

			if (msg.equals(
					"Reply with a ‘Y’ or ‘Yes’ to the message sent to your phone to complete your registration.")) {
				PerfectoUtils.reportMessage("User successfully registered for offers", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("User not registered for offers", MessageTypes.Fail);
			}

		} else {
			wantmore.getLblDigitalcouponsstatus().waitForPresent(1000);
			msg = wantmore.getLblDigitalcouponsstatus().getText();

			if (msg.equals("On")) {
				PerfectoUtils.reportMessage("User successfully registered for offers", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("User not registered for offers", MessageTypes.Fail);
			}
		}

	}

	/**
	 * Verify MY heb barcode is present in My Account page
	 * 
	 */
	@QAFTestStep(description = "I verify the Redeem Coupon cell is displayed")
	public void iVerifyMyHEBBarcodePagePresent() {
		MyaccountTestPage myaccount = new MyaccountTestPage();

		// Verify MY heb barcode is present
		if (myaccount.getLblMyhebbarcode().isPresent())
			PerfectoUtils.reportMessage("My HEB barcode cell is present..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("My HEB barcode cell is not present..", MessageTypes.Fail);
	}

	/**
	 * Verify the Save button from My Profile page is Disabled by default.
	 * Checkpoint --> enabled attribute should be false
	 * 
	 */
	@QAFTestStep(description = "I validate the My Profile page elements")
	public void iValidateTheMyProfilePageElements() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		myprofile.getMyprofileTxtPagetitle().verifyPresent();
		myprofile.getMyprofileTxtFirstname().verifyPresent();
		myprofile.getMyprofileTxtLastname().verifyPresent();
		myprofile.getMyprofileTxtEmail().verifyPresent();
		myprofile.getLnkChgpwd().verifyPresent();
		myprofile.getBtnSaveprofile().verifyPresent();

		String firstName = myprofile.getMyprofileTxtFirstname().getText();
		String lastName = myprofile.getMyprofileTxtLastname().getText();
		String emailId = myprofile.getMyprofileTxtEmail().getText();

		PerfectoUtils.reportMessage("Validated My Profile page", MessageTypes.Pass);
		PerfectoUtils.reportMessage("Email Id: " + emailId);
		PerfectoUtils.reportMessage("First Name: " + firstName);
		PerfectoUtils.reportMessage("Last Name: " + lastName);
	}

	/**
	 * login with empty email and valid password
	 */
	@QAFTestStep(description = "I login with empty email id and valid password")
	public static void iLoginWithEmptyEmailIdAndValidPassword() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		loginsplash.getLoginTxtEmail().waitForPresent(3000);
		String pswd = getBundle().getString("myaccount.hotuser1.user.password");
		loginsplash.getLoginTxtPassword().click();
		loginsplash.getLoginTxtPassword().sendKeys(pswd);
	}

	/**
	 * login with empty password and valid email
	 */
	@QAFTestStep(description = "I login with empty password and valid email id")
	public static void iLoginWithEmptyPasswordAndValidEmailId() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		loginsplash.getLoginTxtEmail().waitForPresent(3000);
		String email = getBundle().getString("myaccount.hotuser1.user.email");
		loginsplash.getLoginTxtEmail().click();
		loginsplash.getLoginTxtEmail().sendKeys(email);
	}

	/**
	 * validate the login button is disabled
	 */
	@QAFTestStep(description = "I validate the login button is disabled")
	public static void iValidateTheLoginButtonIsDisabled() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		loginsplash.getLoginBtnLogin().verifyPresent();
		String isEnabled = loginsplash.getLoginBtnLogin().getAttribute("enabled");

		if (isEnabled.equals("false")) {
			PerfectoUtils.reportMessage("Login button is disabled", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Login button is enabled", MessageTypes.Fail);
		}
	}

	/**
	 * Enter valid email id and password in login splash page
	 */
	@QAFTestStep(description = "I enter valid credentials {0}{1} in login splash page")
	public static void iEnterValidCredentialsInLoginSplashPage(String username, String pswd) {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		loginsplash.getLoginTxtEmail().waitForPresent(3000);
		loginsplash.getLoginTxtEmail().click();
		loginsplash.getLoginTxtEmail().sendKeys(username);
		loginsplash.getLoginTxtPassword().click();
		getBundle().setProperty("currentPassword", pswd);
		loginsplash.getLoginTxtPassword().sendKeys(pswd);

		PerfectoUtils.reportMessage("Entered valid credentials", MessageTypes.Pass);

	}

	/**
	 * Clicking on My HEB barcode option from My Account page
	 * 
	 */
	@QAFTestStep(description = "I navigate to Redeem Coupon page from Homepage")
	public void iNavigateToMyHEBBarcodePageFromHomepage() {
		HomeTestPage homepage = new HomeTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			homepage.getLblRedeemCoupon().waitForPresent(3000);
			homepage.getLblRedeemCoupon().click();
			PerfectoUtils.reportMessage("Clicked on Redeem Coupons.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Redeem Coupons not available as the AutoEnroll flag is false.");
		}

	}

	/**
	 * verify Done button is enabled by default
	 * 
	 */
	@QAFTestStep(description = "I verify Done button is enabled by default")
	public void iVerifyDoneButtonIsEnabledByDefault() {
		WantmoreTestPage wantmore = new WantmoreTestPage();

		PerfectoUtils.verticalswipe();
		wantmore.getBtnDone().verifyPresent();
		String enabled = wantmore.getBtnDone().getAttribute("enabled");
		if (enabled.equals("true"))
			PerfectoUtils.reportMessage("Done button is enabled by default..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Done button is not enabled by default..", MessageTypes.Fail);

	}

	/**
	 * I keep the mobile idle for 10 minutes
	 * 
	 */
	@QAFTestStep(description = "I keep the mobile idle for 10 minutes")
	public void iKeepTheMobileIdleFor10Minutes() {
		WantmoreTestPage wantmore = new WantmoreTestPage();

		try {
			wantmore.getLblExtraOffers().waitForNotPresent(600000);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Waited for 10 minutes...");
		}

	}

	/**
	 * Verifying Log In button is disabled by default
	 * 
	 */
	@QAFTestStep(description = "I verify by default Login button is disabled on the Log In page")
	public void iVerifyByDefaultLoginButtonIsDisabledOnTheLogInPage() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		loginsplash.getLoginBtnLogin().verifyPresent();
		String isEnabled = loginsplash.getLoginBtnLogin().getAttribute("enabled");

		if (isEnabled.equals("false")) {
			PerfectoUtils.reportMessage("Login button is disabled", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Login button is enabled", MessageTypes.Fail);
		}

	}

	/**
	 * verifying Forgot Password link
	 * 
	 */
	@QAFTestStep(description = "I verify Forgot Password link is displayed on the Log In page")
	public void iVerifyForgotPasswordLinkIsDisplayedOnTheLogInPage() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		if (loginsplash.getLoginLblForgotPassword().isPresent()) {
			loginsplash.getLoginLblForgotPassword().verifyPresent();
			PerfectoUtils.reportMessage("Forgot Password link is present in Log In page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Forgot Password link is not present in Log In page", MessageTypes.Fail);
		}

	}

	/**
	 * click on Forgot password link
	 * 
	 */
	@QAFTestStep(description = "I click on forgot password link")
	public void iClickOnForgotPasswordLink() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		if (loginsplash.getLoginLblForgotPassword().isPresent()) {
			loginsplash.getLoginLblForgotPassword().verifyPresent();
			loginsplash.getLoginLblForgotPassword().click();
			PerfectoUtils.reportMessage("Forgot Password clicked", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Forgot Password link is not present in Log In page", MessageTypes.Fail);
		}

	}

	/**
	 * verifying Forgot Password Page
	 * 
	 */
	@QAFTestStep(description = "I verify user navigates to Forgot Password page")
	public void iVerifyUserNavigatesToForgotPasswordPage() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		if (loginsplash.getTxtForgotPassword().isPresent()) {
			loginsplash.getTxtForgotPassword().verifyPresent();
			PerfectoUtils.reportMessage("User navigates to Forgot password page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User still is in log in page", MessageTypes.Fail);
		}

	}

	/**
	 * verifying instructions on the Forgot Password page
	 * 
	 */
	@QAFTestStep(description = "I verify instructions are displayed on the Forgot Password page")
	public void iVerifyInstructionsAreDisplayedOnTheForgotPasswordPage() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		if (loginsplash.getTxtResetInstructions().isPresent()) {
			loginsplash.getTxtResetInstructions().verifyPresent();
			PerfectoUtils.reportMessage("Reset Instructions is present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Reset Instructions is not present", MessageTypes.Fail);
		}

	}

	/**
	 * verifying submit button is disabled by default
	 * 
	 */
	@QAFTestStep(description = "I verify submit button is disabled by default")
	public void iVerifySubmitButtonIsDisabledByDefault() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		if (loginsplash.getBtnResetPassword().getAttribute("enabled").equalsIgnoreCase("false")) {
			PerfectoUtils.reportMessage("Submit button is disabled by default", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Submit button is not disabled by default", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Navigate to extra offers page from Want more page")
	public static void navigateToExtraOffersPageFromWantMorePage() {
		WantmoreTestPage wantmore = new WantmoreTestPage();
		ExtraOffersTestPage offerspage = new ExtraOffersTestPage();
		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			wantmore.getLblExtraOffers().click();
			PerfectoUtils.reportMessage("Clicked on Extra Offers label..", MessageTypes.Pass);
		} else {
			offerspage.getLbldigitalcoupons().click();
			PerfectoUtils.reportMessage("Clicked on Digital Coupon ..");
		}
	}

	@QAFTestStep(description = "I verify My HEB Barcode appears instead of Redeem Coupons")
	public void iVerifyMyHEBBarcodeAppearsInsteadOfRedeemCoupons() {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		MyhebbarcodeTestPage myhebbarcode = new MyhebbarcodeTestPage();

		myaccount.getLblMyhebbarcode().waitForPresent(3000);
		myaccount.getLblMyhebbarcode().click();

		if (myhebbarcode.getvppMyhebBcLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("My HEB Barcode appears instead of Redeem Coupons", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("My HEB Barcode is not present", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Save button is disabled by default in Extra offers page")
	public void verifyTheSaveButtonIsDisabledByDefaultInExtraOffersPage() {
		ExtraOffersTestPage offerspage = new ExtraOffersTestPage();

		offerspage.getLblPageHeader().waitForPresent(5000);
		PerfectoUtils.verticalswipe();
		if (offerspage.getBtnSave().getAttribute("enabled").equalsIgnoreCase("false")) {
			PerfectoUtils.reportMessage("Save button is disabled by default..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Save button is not disabled by default..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Save button is enabled in offers page")
	public void verifyTheSaveButtonIsEnabledInOffersPage() {
		ExtraOffersTestPage offerspage = new ExtraOffersTestPage();

		PerfectoUtils.scrollToElement(offerspage.getBtnSave());

		if (offerspage.getBtnSave().getAttribute("enabled").equalsIgnoreCase("true")) {
			PerfectoUtils.reportMessage("Save button is enabled..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Save button is not enabled..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Select Save button from Extra offers page")
	public void selectSaveButtonFromExtraOffersPage() {
		ExtraOffersTestPage extraoffers = new ExtraOffersTestPage();

		extraoffers.getBtnSave().waitForPresent(10000);
		extraoffers.getBtnSave().click();
		PerfectoUtils.reportMessage("Clicked on Save button..");
	}

	@QAFTestStep(description = "I verify Redeem Coupons does not appear on the Homescreen")
	public void iVerifyRedeemCouponsDoesNotAppearOnTheHomescreen() {
		HomeTestPage homepage = new HomeTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			if (homepage.getLblRedeemCoupon().isPresent())
				PerfectoUtils.reportMessage("Redeem Coupons is present.", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Redeem button is not present.", MessageTypes.Fail);
		} else {
			if (homepage.getLblRedeemCoupon().isPresent()) {
				PerfectoUtils.reportMessage("Redeem Coupons is present.", MessageTypes.Fail);
			} else {
				PerfectoUtils.reportMessage("Redeem Coupons is not present.", MessageTypes.Pass);
			}
		}
	}

	@QAFTestStep(description = "I verify Redeem Coupons is not present on the Homescreen")
	public void iVerifyRedeemCouponsIsNotPresentOnTheHomescreen() {
		HomeTestPage homepage = new HomeTestPage();

		if (homepage.getLblRedeemCoupon().isPresent()) {
			PerfectoUtils.reportMessage("Redeem Coupon section is present", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("Redeem Coupon section is not present", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I verify Valued Partner text appears in red")
	public void iVerifyValuedPartnerTextAppearsInRed() {
		MyhebbarcodeTestPage myhebbarcode = new MyhebbarcodeTestPage();

		myhebbarcode.getLblNamelabel().waitForPresent(2000);
		if (myhebbarcode.getvppMyhebBcLblValuedPartner().isPresent()) {
			PerfectoUtils.reportMessage("valued Partner text is present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("valued Partner text is not present", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify regular HEB Barcode screen is displayed")
	public void iVerifyRegularHEBBarcodeScreenIsDisplayed() {
		MyhebbarcodeTestPage myhebbarcode = new MyhebbarcodeTestPage();

		myhebbarcode.getLblNamelabel().waitForPresent(2000);
		if (!myhebbarcode.getvppMyhebBcLblValuedPartner().isPresent()) {
			PerfectoUtils.reportMessage("regular HEB Barcode screen is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("valued Partner text is present", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I validate error message for already enrolled Phone number")
	public void iValidateErrorMessageForAlreadyEnrolledPhoneNumber() {
		ExtraOffersTestPage Extraoffers = new ExtraOffersTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();

		PerfectoUtils.verticalswipe();
		Extraoffers.getBtnSave().verifyPresent();
		Extraoffers.getBtnSave().click();
		PerfectoUtils.reportMessage("Clicked Save button..");

		if (appcrash.getExceptionBtnOk().isPresent()) {
			appcrash.getExceptionBtnOk().click();
			PerfectoUtils.reportMessage("Clicked on Ok button from the pop up..");
		} else {
			PerfectoUtils.reportMessage("OK button is not present");
		}

		if (Extraoffers.getBtnSave().isPresent()) {
			PerfectoUtils.reportMessage("Getting toast message.Number is already enrolled.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User is able to register with already enroll number", MessageTypes.Fail);
		}
	}

	/**
	 * Entering All the required fields in Offers page and clicking save button
	 * 
	 */
	@QAFTestStep(description = "I enter all required fields in offers page with alredy registered phone number")
	public void iEnterAllRequiredFieldsInOffersPageWithRegisteredPhoneNumber() {
		ExtraOffersTestPage extraoffers = new ExtraOffersTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		PerfectoUtils.reportMessage("Registering for Extra Offers", MessageTypes.Pass);

		// Getting the current time to form the unique Mobile number
		// Getting the current time to form the unique Mobile number
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();

		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		String strpin = strTimeStmp.substring(8, 12);

		String strPhonenum = ConfigurationManager.getBundle().getString("enrolledPhoneNumber");

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(strPhonenum);
			// extraoffers.getEdtMobilenum().sendKeys(strPhonenum);
			PerfectoUtils.hidekeyboard();

			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");

			extraoffers.getBtnSave().waitForPresent(10000);
			extraoffers.getBtnSave().click();
			PerfectoUtils.reportMessage("Clicked on Save button..");

			androidcommon.getImgProgress().waitForNotPresent(50000);
		} else {
			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			extraoffers.getEdtMobilenum().sendKeys(strPhonenum);
			PerfectoUtils.hidekeyboard();

			extraoffers.getedt4digitpin().click();
			extraoffers.getedt4digitpin().sendKeys(strpin);
			PerfectoUtils.hidekeyboard();

			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");

			extraoffers.getBtnSave().waitForPresent(10000);
			extraoffers.getBtnSave().click();
			PerfectoUtils.reportMessage("Clicked on Save button..");

			androidcommon.getImgProgress().waitForNotPresent(50000);
		}
	}
}
