package com.heb.automation.ios.pages;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class AddressbookTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "addressbook.btn.add")
	private QAFWebElement BtnAdd;
	@FindBy(locator = "addressbook.lbl.pagetitle")
	private QAFWebElement LblPagetitle;
	@FindBy(locator = "addressbook.cell.scrollview")
	private List<QAFWebElement> CellScrollview;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getBtnAdd() {
		return BtnAdd;
	}

	public QAFWebElement getLblPagetitle() {
		return LblPagetitle;
	}

	public List<QAFWebElement> getCellScrollview() {
		return CellScrollview;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
}
