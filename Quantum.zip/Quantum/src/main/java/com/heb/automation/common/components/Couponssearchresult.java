package com.heb.automation.common.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class Couponssearchresult extends QAFWebComponent {

	@FindBy(locator = "couponsresult.lbl.couponexpire")
	private QAFWebElement couponsresultLblCouponexpire;
	@FindBy(locator = "couponsresult.lbl.couponexpirationValue")
	private QAFWebElement couponsresultLblCouponexpirationvalue;
	@FindBy(locator = "couponsresult.img.couponimage")
	private QAFWebElement couponsresultImgCouponimage;
	@FindBy(locator = "couponsresult.lbl.offerlimit")
	private QAFWebElement couponsresultLblOfferlimit;
	@FindBy(locator = "couponsresult.img.nexticon")
	private QAFWebElement couponsresultImgNexticon;
	@FindBy(locator = "couponsresult.lbl.offercallout")
	private QAFWebElement couponsresultLblOffercallout;
	@FindBy(locator = "couponsresult.lbl.coupondescription")
	private QAFWebElement couponsresultLblCoupondescription;
	@FindBy(locator = "couponsresult.img.selectplus")
	private QAFWebElement couponsresultImgSelectplus;
	@FindBy(locator = "couponsresult.lbl.couponname")
	private QAFWebElement couponsresultLblCouponName;
	@FindBy(locator = "couponselection.chk.couponitems")
	private QAFWebElement couponsChkCouponItems;

	public Couponssearchresult(String loc) {
		super(loc);
	}

	public QAFWebElement getCouponsresultLblCouponexpire() {
		return couponsresultLblCouponexpire;
	}

	public QAFWebElement getCouponsresultLblCouponexpirationvalue() {
		return couponsresultLblCouponexpirationvalue;
	}

	public QAFWebElement getCouponsresultImgCouponimage() {
		return couponsresultImgCouponimage;
	}

	public QAFWebElement getCouponsresultLblOfferlimit() {
		return couponsresultLblOfferlimit;
	}

	public QAFWebElement getCouponsresultImgNexticon() {
		return couponsresultImgNexticon;
	}

	public QAFWebElement getCouponsresultLblOffercallout() {
		return couponsresultLblOffercallout;
	}

	public QAFWebElement getCouponsresultLblCoupondescription() {
		return couponsresultLblCoupondescription;
	}

	public QAFWebElement getCouponsresultImgSelectplus() {
		return couponsresultImgSelectplus;
	}

	public QAFWebElement getCouponsresultLblCouponName() {
		return couponsresultLblCouponName;
	}

	public QAFWebElement getCouponsChkCouponItems() {
		return couponsChkCouponItems;
	}

}
