package com.heb.automation.android.steps.coupons;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.android.steps.AndroidStepDef;
import com.heb.automation.android.steps.products.AndroidStepdefProducts;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.CouponsSelected;
import com.heb.automation.common.components.Couponssearchresult;
import com.heb.automation.common.components.ListDetails;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.ShareTestPage;
import com.heb.automation.common.pages.coupons.CouponsdetailsTestPage;
import com.heb.automation.common.pages.coupons.CouponsemailTestPage;
import com.heb.automation.common.pages.coupons.CouponssearchresultTestPage;
import com.heb.automation.common.pages.coupons.CouponsselectionTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.pages.registeration.WantmoreTestPage;
import com.heb.automation.common.pages.shoppinglist.ListdetailsTestPage;
import com.heb.automation.common.pages.shoppinglist.LoginpopupTestPage;
import com.heb.automation.common.steps.coupons.CommonStepDefCoupons;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in Coupons
	
	I see Coupons page
	I click on Add/Done button from the popup
	I click on Search
	I should see the list of Coupons in the selected list page
	I add all the coupons to the shopping list
	I add the coupon to the shopping list
	I should see the selected Coupon in the selected list page
	I navigate to Selected Savings tab
	I see Search products page
	I see Registration detail page
	I am a hot user for validating coupons
	I click on Login from coupons landing page
	I navigate back to Coupons page from registration page
	I verify Login/Submit message
	I select a coupon
	I should see the coupons selection page
	I select multiple available coupon
	I validate selected coupons available in selected savings
	I select an option from the sort popup
	I verify the sort option is not present
	I should see coupons selection page
	I select an different sort option from the sort popup
	I see No result for invalid coupons
	I send coupon by entering all mandatory field in email page
	I select coupons from Selected Savings tab
	I validate the filtered coupons selection page
	I click signup for digital coupons
	I click on Cancel button
	I click on Login from coupons selection page
	I click on Login/Submit button from the popup
	I select an category from the coupons dropdown
	I validate register and Login button in coupons detail page
	I navigate to Selected Savings tab as a cold user
	I select coupons by clicking SELECT ALL
	I click on Unselecet All option and select single coupon
	I click share button
	I add the selected coupon to list
	I verify add to list options in selected savings tab
	Verify the Read more functionality not present
	I verify the coupons getting displayed
	I verify that coupons are displayed based on the selection
	I validate Coupons selection page as cold user
	I validate Coupons selection page as hot user
	I click clear from search result
	I verify counpon landing page is displayed
	I verify add to list and select button
	I note down the list name
	I enter mandatory field for cold user and click on Send button
	I select Select All button*/


public class AndroidStepdefCoupons {

	/**
	 * Verifies whether the user navigated to the Coupons page
	 * 
	 */
	@QAFTestStep(description = "I see Coupons page")
	public void iSeeCouponsPage() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		CouponssearchresultTestPage Couponsresult = new CouponssearchresultTestPage();

		String pgtitle = null;
		String actualpgtitle = "ALL COUPONS";

		couponsselection.waitForPageToLoad();
		Couponsresult.getCouponsresultLblPgtitleallcoupon().waitForPresent(20000);
		Couponsresult.getCouponsresultLblPgtitleallcoupon().verifyPresent();

		if (couponsselection.getCouponsLblPgtitlecoupons().isPresent()) {
			pgtitle = couponsselection.getCouponsLblPgtitlecoupons().getText().toUpperCase();
			System.out.println(pgtitle);
		} else if (Couponsresult.getCouponsresultLblPgtitleallcoupon().isPresent()) {
			pgtitle = Couponsresult.getCouponsresultLblPgtitleallcoupon().getText().toUpperCase();
			System.out.println(pgtitle);
		}

		if (pgtitle.contains(actualpgtitle)) {
			PerfectoUtils.reportMessage("Title page is displayed as expected:" + actualpgtitle, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Title page is not displayed as expected:" + actualpgtitle, MessageTypes.Pass);
		}
	}

	/**
	 * Clicks on Add button from the Add to list pop-up
	 */
	@QAFTestStep(description = "I click on Add/Done button from the popup")
	public void iClickOnAddDoneButtonFromThePopup() {
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();

		String pickerName = androidcommonpage.getAddtolistTxtNumberpicker().getText();
		ConfigurationManager.getBundle().setProperty("NewListName", pickerName);
		androidcommonpage.getAddtolistBtnAdd().click();
		PerfectoUtils.reportMessage("Selected the List: " + pickerName, MessageTypes.Pass);
	}

	/**
	 * Clicks on Search icon from Coupons page
	 */
	@QAFTestStep(description = "I click on Search")
	public void iClickOnSearch() {
		CouponssearchresultTestPage couponsearch = new CouponssearchresultTestPage();
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponselectionLblAllcoupons().waitForPresent(10000);

		couponsearch.getCouponsresultIconSearch().waitForPresent(5000);
		couponsearch.getCouponsresultIconSearch().click();
		try {
			couponsearch.getCouponsresultLblSearchtext().waitForPresent(5000);
		} catch (Exception e) {
			couponsearch.getCouponsresultIconSearch().click();
			couponsearch.getCouponsresultLblSearchtext().verifyPresent();
		}
	}

	/**
	 * Verifies whether the Added Coupons are available in the Shopping list
	 * 
	 */
	@QAFTestStep(description = "I should see the list of Coupons in the selected list page")
	public void iShouldSeeTheListOfCouponsInTheSelectedListPage() {
		ListdetailsTestPage listdetailspage = new ListdetailsTestPage();
		List<String> listFromListDetailsPage = new ArrayList<String>();

		List<ListDetails> itemList = listdetailspage.getListpageLblItemNameList();
		System.out.println("itemList.size(): " + itemList.size());

		for (ListDetails singleItem : itemList) {
			try {
				String prdname = singleItem.getListpageLblItemname().getText();
				System.out.println("prdname: " + prdname);
				listFromListDetailsPage.add(prdname);
			} catch (Exception e) {
				PerfectoUtils.reportMessage("Item name is not visible. Failed to get Item name!", MessageTypes.Info);
			}
		}
		List<String> listFromCouponspage = getBundle().getList("listFromCouponspage");
		System.out.println("The components of listFromCouponspage:");
		System.out.println(listFromCouponspage.size());

		for (int i = 0; i < listFromCouponspage.size(); i++) {
			System.out.println(listFromCouponspage.get(i));
		}
		System.out.println("The components of listFromListDetailsPage:");

		for (int i = 0; i < listFromListDetailsPage.size(); i++) {
			System.out.println(listFromListDetailsPage.get(i));
		}
		if (listFromListDetailsPage.size() > 0) {
			System.out.println("Success");
			PerfectoUtils.reportMessage("Items are available in shopping list", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Items are not available in shopping list", MessageTypes.Fail);
		}
	}

	/**
	 * Clicks on Select ALL and Plus Icon from SELECTED Section of Coupons page
	 */
	@QAFTestStep(description = "I add all the coupons to the shopping list")
	public void iAddAllTheCouponsToTheShoppingList() {
		CouponsselectionTestPage couponsselectionpage = new CouponsselectionTestPage();
		List<String> listFromCouponspage = new ArrayList<String>();

		List<Couponssearchresult> couponsList = couponsselectionpage.getCouponsLblSearchresult();

		if (couponsselectionpage.getLblToastmsgcross().isPresent()) {
			couponsselectionpage.getLblToastmsgcross().click();
			PerfectoUtils.reportMessage("Digital coupons sign up toast message is present", MessageTypes.Info);
		}
		String prdname = couponsList.get(0).getCouponsresultLblCouponName().getText();
		System.out.println("prdname: " + prdname);
		listFromCouponspage.add(prdname);

		getBundle().setProperty("listFromCouponspage", listFromCouponspage);

		couponsselectionpage.getCouponsBtnSelectall().click();
		couponsselectionpage.getCouponsIconPlus().click();
	}

	/**
	 * Clicks the Check box of a Coupon and Clicks Plus Icon to Add to list from
	 * Coupons page
	 */
	@QAFTestStep(description = "I add the coupon to the shopping list")
	public void iAddTheCouponToTheShoppingList() {
		CouponsselectionTestPage couponsselectionpage = new CouponsselectionTestPage();

		List<Couponssearchresult> couponsList = couponsselectionpage.getCouponsLblSearchresult();

		for (Couponssearchresult singleCoupon : couponsList) {
			String prdname = singleCoupon.getCouponsresultLblCouponName().getText();
			System.out.println("prdname: " + prdname);
			ConfigurationManager.getBundle().setProperty("ChoosenProduct", prdname);
			// couponsselectionpage.getLstSelectcheckbox().get(0).click();
			singleCoupon.getCouponsChkCouponItems().verifyPresent();
			singleCoupon.getCouponsChkCouponItems().click();
			PerfectoUtils.reportMessage("Selected the Checkbox of single coupon.", MessageTypes.Pass);
			break;
		}
		couponsselectionpage.getCouponsIconPlus().click();
		PerfectoUtils.reportMessage("Clicked Add to list/ Plus- button.", MessageTypes.Pass);
	}

	/**
	 * Verifying whether the Added Coupons is Available in the Shopping list
	 */
	@QAFTestStep(description = "I should see the selected Coupon in the selected list page")
	public void iShouldSeeTheSelectedCouponInTheSelectedListPage() {
		ListdetailsTestPage listdetailspage = new ListdetailsTestPage();

		List<ListDetails> itemList = listdetailspage.getListpageLblItemNameList();
		System.out.println("itemList.size(): " + itemList.size());
		String choosenCoupon = ConfigurationManager.getBundle().getString("choosenCoupon");
		int count = 0;

		for (ListDetails singleItem : itemList) {
			String prdname = singleItem.getListpageLblItemname().getText();
			System.out.println("prdname: " + prdname);
			if (choosenCoupon.equalsIgnoreCase(prdname)) {
				count = 1;
				break;
			}
		}
		if (count == 1) {
			System.out.println("Pass.");
		} else {
			System.out.println("Fail.");
		}
	}

	/**
	 * Navigating to SELECTED Section and Verifying whether the coupons are
	 * available in the Section. If Coupons are not available, Add Coupons from
	 * AVAILABLE Section
	 */
	@QAFTestStep(description = "I navigate to Selected Savings tab")
	public void iNavigateToSelectedSavingsTab() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		CouponssearchresultTestPage couponsSearchresultPage = new CouponssearchresultTestPage();
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		int listsize;

		if (dcAutoEnrolFlag.contains("true")) {
			try {
				couponsselection.getCouponsLblSelected().waitForPresent(5000);
				if (!couponsselection.getCouponsLblSelected().isPresent()) {
					PerfectoUtils.androiddeviceback();
				}
				couponsselection.getCouponsLblSelected().verifyPresent();
				couponsselection.getCouponsLblSelected().click();
				PerfectoUtils.reportMessage("Navigated to Selected Section.", MessageTypes.Pass);
			} catch (Exception e) {
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", "SELECTED");
				String isBtnDoneVisible = (String) couponsselection.getTestBase().getDriver()
						.executeScript("mobile:checkpoint:text", params1);
				if (isBtnDoneVisible.equalsIgnoreCase("true")) {
					couponsselection.getTestBase().getDriver().executeScript("mobile:text:select", params1);
					PerfectoUtils.reportMessage("Navigated to Selected Section.", MessageTypes.Pass);
				}
			}

			// Validating whether the SELECTED Section is not empty
			List<QAFWebElement> couponsNamesList = couponsSearchresultPage.getLblCoupondescription();
			listsize = couponsNamesList.size();

			if (listsize != 0) {
				PerfectoUtils.reportMessage(listsize + " Coupons found.", MessageTypes.Info);

			} else {
				PerfectoUtils.reportMessage("Coupons not found!! Adding the coupons from Available Section..", MessageTypes.Info);

				couponsselection.getCouponsLblAvailable().waitForPresent(1000);
				couponsselection.getCouponsLblAvailable().click();

				// Selecting and adding the coupons to SELECTED Section
				List<String> prdname = new ArrayList<String>();

				List<Couponssearchresult> couponsList = couponsselection.getCouponsLblSearchresult();
				listsize = couponsList.size();

				if (listsize != 0) {
					// Select First Item
					prdname.add(couponsList.get(0).getCouponsresultLblCouponName().getText());
					couponsselection.getLstSelectcheckbox().get(0).click();
					PerfectoUtils.reportMessage("Selected coupon name1: " + prdname.get(0), MessageTypes.Pass);

					// Navigating back to SELECTED Section
					try {
						couponsselection.getCouponsLblSelected().waitForPresent(5000);
						if (!couponsselection.getCouponsLblSelected().isPresent()) {
							PerfectoUtils.androiddeviceback();
						}
						couponsselection.getCouponsLblSelected().verifyPresent();
						couponsselection.getCouponsLblSelected().click();
						PerfectoUtils.reportMessage("Navigated to Selected Section.", MessageTypes.Pass);
					} catch (Exception e) {
						Map<String, Object> params1 = new HashMap<>();
						params1.put("content", "SELECTED");
						String isBtnDoneVisible = (String) couponsselection.getTestBase().getDriver()
								.executeScript("mobile:checkpoint:text", params1);
						if (isBtnDoneVisible.equalsIgnoreCase("true")) {
							couponsselection.getTestBase().getDriver().executeScript("mobile:text:select", params1);
							PerfectoUtils.reportMessage("Navigated to Selected Section.", MessageTypes.Pass);
						}
					}

				} else {
					PerfectoUtils.reportMessage("Coupons not found!!", MessageTypes.Fail);
				}

			}
		} else {
			if (couponsSearchresultPage.getBtnsignupnow().isPresent()) {
				PerfectoUtils.reportMessage("Signup Now button is displayed. Cannot navigate to selected coupon", MessageTypes.Info);
				try {
					couponsselection.getCouponsLblSelected().waitForPresent(5000);
					if (!couponsselection.getCouponsLblSelected().isPresent()) {
						PerfectoUtils.androiddeviceback();
					}
					couponsselection.getCouponsLblSelected().verifyPresent();
					couponsselection.getCouponsLblSelected().click();
					PerfectoUtils.reportMessage("Navigated to Selected Section.", MessageTypes.Pass);
				} catch (Exception e) {
					Map<String, Object> params1 = new HashMap<>();
					params1.put("content", "SELECTED");
					String isBtnDoneVisible = (String) couponsselection.getTestBase().getDriver()
							.executeScript("mobile:checkpoint:text", params1);
					if (isBtnDoneVisible.equalsIgnoreCase("true")) {
						couponsselection.getTestBase().getDriver().executeScript("mobile:text:select", params1);
					}
				}

			} else {
				PerfectoUtils.reportMessage("Signup Now button is not displayed. Can navigate to selected coupon", MessageTypes.Pass);

				try {
					couponsselection.getCouponsLblSelected().waitForPresent(5000);
					if (!couponsselection.getCouponsLblSelected().isPresent()) {
						PerfectoUtils.androiddeviceback();
					}
					couponsselection.getCouponsLblSelected().verifyPresent();
					couponsselection.getCouponsLblSelected().click();
					PerfectoUtils.reportMessage("Navigated to Selected Section.", MessageTypes.Pass);
				} catch (Exception e) {
					Map<String, Object> params1 = new HashMap<>();
					params1.put("content", "SELECTED");
					String isBtnDoneVisible = (String) couponsselection.getTestBase().getDriver()
							.executeScript("mobile:checkpoint:text", params1);
					if (isBtnDoneVisible.equalsIgnoreCase("true")) {
						couponsselection.getTestBase().getDriver().executeScript("mobile:text:select", params1);
					}
				}

				// Validating whether the SELECTED Section is not empty
				List<QAFWebElement> couponsNamesList = couponsSearchresultPage.getLblCoupondescription();
				listsize = couponsNamesList.size();

				if (listsize != 0) {
					PerfectoUtils.reportMessage(listsize + " Coupons found.", MessageTypes.Info);

				} else {
					PerfectoUtils.reportMessage("Coupons not found!! Adding the coupons from Available Section..", MessageTypes.Info);

					couponsselection.getCouponsLblAvailable().waitForPresent(1000);
					couponsselection.getCouponsLblAvailable().click();

					// Selecting and adding the coupons to SELECTED Section
					List<String> prdname = new ArrayList<String>();
					List<String> expirevalue = new ArrayList<String>();

					List<Couponssearchresult> couponsList = couponsselection.getCouponsLblSearchresult();
					listsize = couponsList.size();

					if (listsize != 0) {
						// Select First Item
						prdname.add(couponsList.get(0).getCouponsresultLblCouponName().getText());
						expirevalue.add(couponsList.get(0).getCouponsresultLblCouponexpire().getText());
						couponsselection.getLstSelectcheckbox().get(0).click();
						PerfectoUtils.reportMessage("Selected coupon name1: " + prdname.get(0), MessageTypes.Pass);

						// Navigating back to SELECTED Section
						try {
							couponsselection.getCouponsLblSelected().waitForPresent(5000);
							if (!couponsselection.getCouponsLblSelected().isPresent()) {
								PerfectoUtils.androiddeviceback();
							}
							couponsselection.getCouponsLblSelected().verifyPresent();
							couponsselection.getCouponsLblSelected().click();
							PerfectoUtils.reportMessage("Navigated to Selected Section.", MessageTypes.Pass);
						} catch (Exception e) {
							Map<String, Object> params1 = new HashMap<>();
							params1.put("content", "SELECTED");
							String isBtnDoneVisible = (String) couponsselection.getTestBase().getDriver()
									.executeScript("mobile:checkpoint:text", params1);
							if (isBtnDoneVisible.equalsIgnoreCase("true")) {
								couponsselection.getTestBase().getDriver().executeScript("mobile:text:select", params1);
							}
						}

					} else {
						PerfectoUtils.reportMessage("Coupons not found!!", MessageTypes.Fail);
					}

				}

			}

		}

	}

	/**
	 * Verifying the Search Product Screen is Displayed. i.e. Checking if the
	 * SEARCH Term is available in the Search results.
	 */
	@QAFTestStep(description = "I see Search products page")
	public void iSeeSearchProductPage() {
		CouponssearchresultTestPage couponsearch = new CouponssearchresultTestPage();
		couponsearch.getCouponsresultIconSearch().waitForPresent(10000);
		String strValidCouponname = getBundle().getString("coupons.couponname");

		couponsearch.getCouponsresultIconSearch().click();
		AndroidStepDef.enterValueIntoTheTextboxandClick(couponsearch, strValidCouponname);
		couponsearch.waitForPageToLoad();

		PerfectoUtils.hidekeyboard();
		try {
			couponsearch.getIconProgressBar().waitForNotVisible(10000);
		} catch (Exception e) {
		}
		int couponslistsize = couponsearch.getLblCoupondescription().size();
		couponsearch.getLblCoupondescription().get(0).waitForPresent(10000);
		Boolean result = (couponsearch.getLblCoupondescription().get(0).getText().toLowerCase())
				.contains(strValidCouponname.toLowerCase());

		if (result) {
			PerfectoUtils.reportMessage("Searched Coupon is displayed in Result: " + strValidCouponname, MessageTypes.Pass);
			System.out.println("Searched Coupon is displayed in Result: " + strValidCouponname);
		} else {
			PerfectoUtils.reportMessage("Searched Coupon is not displayed in Result: " + strValidCouponname, MessageTypes.Fail);
		}
	}

	/**
	 * Validating the Components from Registration page
	 */
	@QAFTestStep(description = "I see Registration detail page")
	public void iRegistrationDetailPage() {
		RegistrastionTestPage registrationpage = new RegistrastionTestPage();

		registrationpage.getRegistrationTxtEmail().waitForPresent(5000);
		PerfectoUtils.hidekeyboard();
		registrationpage.getRegistrationTxtEmail().verifyPresent();
		registrationpage.getRegistrationTxtPassword().verifyPresent();
		registrationpage.getRegistrationTxtFirstname().verifyPresent();
		registrationpage.getRegistrationChkIagree().verifyPresent();
	}

	/**
	 * Logging in to the Application as a hot user.
	 */
	@QAFTestStep(description = "I am a hot user for validating coupons")
	public void iAmAHotUserForValidatingCoupons() {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		AndroidStepDef.handleSkip();
		/* Setting Environment before execution */
		// AndroidStepDef.settingEnvironmentinApp();

		PerfectoUtils.getAppiumDriver().context("NATIVE_APP");

		try {
			loginsplash.getLoginBtnLogin().waitForPresent(15000);
		} catch (Exception e) {
			if (!loginsplash.getLoginBtnLogin().isPresent()) {
				PerfectoUtils.reportMessage("User has an Pre-existing session.",MessageTypes.Info);
				androidfun.getAppHamburger().click();
				PerfectoUtils.verticalswipe();
				if (!androidfun.getAppSliderLogout().isPresent()) {
					PerfectoUtils.verticalswipe();
				}
				androidfun.getAppSliderLogout().waitForPresent(5000);
				androidfun.getAppSliderLogout().click();

				// handle re-login pop up
				if (appCrash.getReloginTitle().isPresent()) {
					PerfectoUtils.handleReloginPopup();
				}
			}
		}

		if (loginsplash.getLoginBtnLogin().isPresent()) {
			String username = ConfigurationManager.getBundle().getString("coupons.user.email");
			String pswd = ConfigurationManager.getBundle().getString("coupons.user.password");
			AndroidStepDef.EnterCredentialsAndLogin(username, pswd);
		}
	}

	/**
	 * Clicks on Login button from Coupons Landing page
	 */
	@QAFTestStep(description = "I click on Login from coupons landing page")
	public void iClickOnLoginFromCouponsLandingPage() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponsBtnLogin().waitForPresent(50000);
		couponsselection.getCouponsBtnLogin().click();
	}

	/**
	 * Clicks on Android Device back button to navigate back
	 */
	@QAFTestStep(description = "I navigate back to Coupons page from registration page")
	public void iNavigateBackToCouponsPageFromRegistrationPage() {

		// Click on device back button
		PerfectoUtils.hidekeyboard();
		PerfectoUtils.androiddeviceback();
	}

	/**
	 * Validating the elements in the Login Page
	 */

	@QAFTestStep(description = "I verify Login/Submit message")
	public void iVerifyLoginMessage() {
		LoginpopupTestPage loginpopup = new LoginpopupTestPage();

		loginpopup.getLoginpopupTxtAlerttitle().waitForPresent(5000);
		PerfectoUtils.hidekeyboard();
		loginpopup.getLoginpopupBtnOverlaylogin().verifyPresent();
		loginpopup.getLoginpopupLblLoginmsg().verifyPresent();
		loginpopup.getLoginpopupBtnCancel().verifyPresent();
		loginpopup.getLoginpopupTxtfldEmail().verifyPresent();
		loginpopup.getLoginpopupTxtfldPassword().verifyPresent();
		loginpopup.getLoginpopupLblForgetpwd().verifyPresent();
	}

	/**
	 * Selecting the first Coupon
	 */
	@QAFTestStep(description = "I select a coupon")
	public void iSelectACoupon() {
		CouponsselectionTestPage couponsselectionpage = new CouponsselectionTestPage();

		String prdname = "";
		int listsize;
		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		List<Couponssearchresult> couponsList = couponsselectionpage.getCouponsLblSearchresult();
		listsize = couponsList.size();

		if (listsize != 0) {
			couponsselectionpage.getCouponsListCoupondesc().get(0).waitForPresent(10000);
			prdname = couponsselectionpage.getCouponsListCoupondesc().get(0).getText();
			ConfigurationManager.getBundle().setProperty("ChoosenProduct", prdname);
			couponsselectionpage.getCouponsListCoupondesc().get(0).click();
			PerfectoUtils.reportMessage("Selected coupon name: " + prdname, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons not found!!", MessageTypes.Fail);
		}
	}

	/**
	 * Verifying the user navigated to Coupons Selection Page i.e. the ALL
	 * COUPONS label is present
	 */
	@QAFTestStep(description = "I should see the coupons selection page")
	public void iShouldSeeTheCouponsSelectionPage() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponselectionLblAllcoupons().waitForPresent(10000);
		if (couponsselection.getCouponselectionLblAllcoupons().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Coupons selection page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Coupons selection page.", MessageTypes.Fail);
		}
	}

	/**
	 * Selecting the Check box of 2 Coupons from SELECTED Section
	 */
	@QAFTestStep(description = "I select multiple available coupon")
	public void iSelectMultipleAvailableCoupon() {
		CouponsselectionTestPage couponsselectionpage = new CouponsselectionTestPage();
		CouponssearchresultTestPage couponsSearchresultPage = new CouponssearchresultTestPage();
		List<String> prdname = new ArrayList<String>();
		List<String> expirevalue = new ArrayList<String>();
		int listsize;
		int clipIcon = 0;

		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		if (dcAutoEnrolFlag.contains("true")) {
			try {
				if (couponsselectionpage.getLblToastmsgcross().isPresent())
					couponsselectionpage.getLblToastmsgcross().click();
			} catch (Exception e) {
			}

			try {
				couponsselectionpage.getLstSelectcheckbox().get(0).waitForPresent(3000);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			int couponClip = couponsselectionpage.getLstSelectcheckbox().size();

			if (couponClip != 0) {
				// Select First Item
				System.out.println(couponsselectionpage.getCouponsListCoupondesc().get(0).getText());
				prdname.add(couponsselectionpage.getCouponsListCoupondesc().get(0).getText());
				// expirevalue.add(couponsList.get(0).getText());
				couponsselectionpage.getLstSelectcheckbox().get(0).click();
				PerfectoUtils.reportMessage("Selected coupon name1: " + prdname.get(0), MessageTypes.Pass);
				ConfigurationManager.getBundle().setProperty("ChoosenCouponName1", prdname.get(0));

				// Select Second Item
				try {
					couponsselectionpage.getLstSelectcheckbox().get(0).waitForPresent(3000);
				} catch (Exception e) {

				}
				System.out.println(couponsselectionpage.getCouponsListCoupondesc().get(1).getText());
				prdname.add(couponsselectionpage.getCouponsListCoupondesc().get(1).getText());
				couponsselectionpage.getLstSelectcheckbox().get(0).click();

				PerfectoUtils.reportMessage("Selected coupon name: " + prdname.get(1), MessageTypes.Pass);
				ConfigurationManager.getBundle().setProperty("ChoosenCouponName2", prdname.get(1));
				// ConfigurationManager.getBundle().setProperty("ChoosenCouponExpireDate2",
				// expirevalue.get(1));
			} else {
				PerfectoUtils.reportMessage("Coupons not found!!", MessageTypes.Fail);
			}
		} else {
			if (couponsSearchresultPage.getBtnsignupnow().isPresent()) {
				PerfectoUtils.reportMessage("Signup Now button is displayed. Cannot navigate to selected coupon", MessageTypes.Info);
				clipIcon = couponsselectionpage.getLstSelectcheckbox().size();
				if (clipIcon == 0)
					PerfectoUtils.reportMessage("No clip icons present as exected", MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("Clip icons are present..", MessageTypes.Fail);

			} else {
				PerfectoUtils.reportMessage("DCAutoEnrol flag is false",MessageTypes.Info);
				PerfectoUtils.reportMessage("Signup Now button is not displayed. Can navigate to selected coupon", MessageTypes.Pass);

				try {
					if (couponsselectionpage.getLblToastmsgcross().isPresent())
						couponsselectionpage.getLblToastmsgcross().click();
				} catch (Exception e) {
				}

				try {
					couponsselectionpage.getLstSelectcheckbox().get(0).waitForPresent(3000);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				int couponClip = couponsselectionpage.getLstSelectcheckbox().size();

				if (couponClip != 0) {
					// Select First Item
					System.out.println(couponsselectionpage.getCouponsListCoupondesc().get(0).getText());
					prdname.add(couponsselectionpage.getCouponsListCoupondesc().get(0).getText());
					// expirevalue.add(couponsList.get(0).getText());
					couponsselectionpage.getLstSelectcheckbox().get(0).click();
					PerfectoUtils.reportMessage("Selected coupon name1: " + prdname.get(0), MessageTypes.Pass);
					ConfigurationManager.getBundle().setProperty("ChoosenCouponName1", prdname.get(0));

					// Select Second Item
					try {
						couponsselectionpage.getLstSelectcheckbox().get(0).waitForPresent(3000);
					} catch (Exception e) {

					}
					System.out.println(couponsselectionpage.getCouponsListCoupondesc().get(1).getText());
					prdname.add(couponsselectionpage.getCouponsListCoupondesc().get(1).getText());
					couponsselectionpage.getLstSelectcheckbox().get(0).click();

					PerfectoUtils.reportMessage("Selected coupon name: " + prdname.get(1), MessageTypes.Pass);
					ConfigurationManager.getBundle().setProperty("ChoosenCouponName2", prdname.get(1));
					// ConfigurationManager.getBundle().setProperty("ChoosenCouponExpireDate2",
					// expirevalue.get(1));
				} else {
					PerfectoUtils.reportMessage("Coupons not found!!", MessageTypes.Fail);
				}

			}
		}
	}

	/**
	 * Validating the Clipped Coupons are available in SELECTED Section
	 */
	@QAFTestStep(description = "I validate selected coupons available in selected savings")
	public void iValidateSelectedCouponsAvailableInSelectedSavings() {
		CouponsselectionTestPage couponsselectionpage = new CouponsselectionTestPage();
		ArrayList<String> couponsDesclist = new ArrayList<String>();
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		boolean found1 = false, found2 = false;

		try {
			couponsselectionpage.getCouponsLblSelected().waitForPresent(10000);
			if (!couponsselectionpage.getCouponsLblSelected().isPresent()) {
				PerfectoUtils.androiddeviceback();
			}
			couponsselectionpage.getCouponsLblSelected().verifyPresent();
			couponsselectionpage.getCouponsLblSelected().click();
			PerfectoUtils.reportMessage("Clicked to Selected Section.", MessageTypes.Pass);
		} catch (Exception e) {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "SELECTED");
			String isBtnDoneVisible = (String) couponsselectionpage.getTestBase().getDriver()
					.executeScript("mobile:checkpoint:text", params1);
			if (isBtnDoneVisible.equalsIgnoreCase("true")) {
				couponsselectionpage.getTestBase().getDriver().executeScript("mobile:text:select", params1);
				PerfectoUtils.reportMessage("Clicked to Selected Section.", MessageTypes.Pass);
			}
		}

		try {
			couponsselectionpage.getCouponsPopupSignupOrSignin().waitForPresent(4000);
		} catch (Exception e) {
		}

		if (!couponsselectionpage.getCouponsPopupSignupOrSignin().isPresent()) {

			String selectedcoupon1 = ConfigurationManager.getBundle().getString("ChoosenCouponName1");
			String selectedcoupon2 = ConfigurationManager.getBundle().getString("ChoosenCouponName2");

			int size = couponsselectionpage.getLstSelectedcoupons().size();

			if (size > 0) {
				for (CouponsSelected singlecell : couponsselectionpage.getLstSelectedcoupons()) {
					String couponsDesc = singlecell.getCouponsLblCoupondesc().getText();
					couponsDesclist.add(couponsDesc);
				}

				// Checking for Selected Coupons1
				if (couponsDesclist.contains(selectedcoupon1)) {
					PerfectoUtils.reportMessage("Clipped Coupon: " + selectedcoupon1 + " is present in Selected Coupons Page",MessageTypes.Info);
					found1 = true;
				} else
					PerfectoUtils.reportMessage("Clipped Coupon: " + selectedcoupon1 + " is not found in Selected Coupons Page",MessageTypes.Info);
				// Checking for Selected Coupons2
				if (couponsDesclist.contains(selectedcoupon2)) {
					PerfectoUtils.reportMessage("Clipped Coupon: " + selectedcoupon2 + " is present in Selected Coupons Page",MessageTypes.Info);
					found2 = true;
				} else
					PerfectoUtils.reportMessage("Clipped Coupon: " + selectedcoupon2 + " is not found in Selected Coupons Page",MessageTypes.Info);

				if (found1 && found2)
					PerfectoUtils.reportMessage("Clipped coupons found in Selected Tab", MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("Clipped coupons not found in Selected Tab", MessageTypes.Fail);

			} else {
				PerfectoUtils.reportMessage("No items Found", MessageTypes.Fail);
			}

		} else if (dcAutoEnrolFlag.equals("false")) {

			PerfectoUtils.reportMessage("DCC auto enroll flag is off, cannot select coupons",MessageTypes.Info);
			PerfectoUtils.reportMessage("User need to sign up for digital coupons..", MessageTypes.Pass);
		} else
			PerfectoUtils.reportMessage("DCC auto enroll flag is not false, Still user not able to navigate to selected tab",
					MessageTypes.Fail);
	}

	/**
	 * Selecting an Option from the Sort pop up
	 */
	@QAFTestStep(description = "I select an option from the sort popup")
	public void iSelectAnOptionFromTheSortPopup() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getLblSortpopupSecondoption().waitForPresent(5000);
		String strSelectedOption = couponsselection.getLblSortpopupoption().get(1).getText();
		System.out.println(strSelectedOption);
		couponsselection.getLblSortpopupoption().get(1).click();
		PerfectoUtils.reportMessage("Selected option: " + strSelectedOption, MessageTypes.Pass);
	}

	/**
	 * Verifying the Sort option is not present
	 */
	@QAFTestStep(description = "I verify the sort option is not present")
	public void iVerifyTheSortOptionIsNotPresent() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponsLblAvailable().waitForPresent(5000);
		if (!couponsselection.getCouponsBtnSort().isPresent()) {
			PerfectoUtils.reportMessage("Sort option is visible in the Search result page as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Sort option is visible in the Search result page", MessageTypes.Fail);
		}
	}

	/**
	 * Verifying the user has navigated to Coupons Selection Page i.e. verifying
	 * the ALL COUPONS label is visible
	 */
	@QAFTestStep(description = "I should see coupons selection page")
	public void iShouldSeeCouponsSelectionPage() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponselectionLblAllcoupons().waitForPresent(5000);
		if (couponsselection.getCouponselectionLblAllcoupons().isPresent()) {
			PerfectoUtils.reportMessage("Coupons selection page displayed successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons selection page is not displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Selecting a different Sort option from the pop up
	 */
	@QAFTestStep(description = "I select an different sort option from the sort popup")
	public void iSelectAnDifferentSortOptionFromTheSortPopup() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		String sortby = getBundle().getString("coupons.sortby");
		String strSelectedOption = null;

		int getcell = couponsselection.getLblSortpopupoption().size();
		System.out.println(getcell);

		for (int i = 0; i < getcell; i++) {
			strSelectedOption = couponsselection.getLblSortpopupoption().get(i).getText();
			System.out.println(strSelectedOption + " " + sortby);
			if (!sortby.equals(strSelectedOption)) {
				PerfectoUtils.reportMessage("Selected option: " + strSelectedOption, MessageTypes.Pass);
				couponsselection.getLblSortpopupoption().get(i).click();
				couponsselection.waitForPageToLoad();
				CommonStepDefCoupons.iSelectTheSortButton();
				strSelectedOption = couponsselection.getLblSortpopupoption().get(i).getText();
			} else if (sortby.equals(strSelectedOption)) {
				PerfectoUtils.reportMessage("Selected option: " + strSelectedOption, MessageTypes.Pass);
				couponsselection.getLblSortpopupSecondoption().click();
				break;
			}
		}
	}

	/**
	 * Enter Invalid Coupons name and Verifying No Results Found.
	 */
	@QAFTestStep(description = "I see No result for invalid coupons")
	public void iSeeNoResultForInvalidCoupons() {
		CouponssearchresultTestPage couponsearch = new CouponssearchresultTestPage();
		String strInvalidCouponname = ConfigurationManager.getBundle().getString("coupons.invalidcouponname");
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		// Entering invalid coupons name
		couponsearch.getCouponsresultIconSearch().click();
		PerfectoUtils.reportMessage("Search Coupon for: " + strInvalidCouponname + " product", MessageTypes.Pass);
		AndroidStepDef.enterValueIntoTheTextboxandClick(couponsearch, strInvalidCouponname);

		PerfectoUtils.hidekeyboard();

		couponsselection.getLblSearchresult().waitForPresent(8000);

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "No Items Found");
		String isBtnDoneVisible = (String) couponsselection.getTestBase().getDriver()
				.executeScript("mobile:checkpoint:text", params1);

		if (isBtnDoneVisible.equalsIgnoreCase("true")) {
			PerfectoUtils.reportMessage("No Result is found for " + strInvalidCouponname + " is displayed as expected",
					MessageTypes.Pass);
		} else {
			isBtnDoneVisible = (String) couponsselection.getTestBase().getDriver()
					.executeScript("mobile:checkpoint:text", params1);

			if (isBtnDoneVisible.equalsIgnoreCase("true"))
				PerfectoUtils.reportMessage("No Result is found for " + strInvalidCouponname + " is displayed as expected",
						MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Provide invalid coupons name", MessageTypes.Fail);
		}
	}

	/**
	 * Enter the Mandatory fields in the Email page and Click on Send button
	 */
	@QAFTestStep(description = "I send coupon by entering all mandatory field in email page")
	public void iSendCouponByEnteringAllMandatoryFieldInEmailPage() {
		CouponsemailTestPage couponsemail = new CouponsemailTestPage();
		String youremail = ConfigurationManager.getBundle().getString("coupons.user.email");
		String recipientemail = ConfigurationManager.getBundle().getString("hotuser1.user.email");
		CouponsdetailsTestPage couponsdetailspage = new CouponsdetailsTestPage();

		couponsemail.waitForPageToLoad();
		couponsemail.getLblPagetitle().verifyPresent();
		couponsemail.getEdtName().waitForPresent(3000);
		couponsemail.getEdtName().sendKeys("Test");
		couponsemail.getEdtSenderemail().sendKeys(youremail);
		couponsemail.getEdtRecipientemail().sendKeys(recipientemail);
		couponsemail.getChkSendcopy().click();
		couponsemail.getBtnSend().click();

		couponsdetailspage.waitForPageToLoad();
		couponsdetailspage.getCouponsdetailLblPagetitle().waitForPresent(12000);

		if (couponsdetailspage.getCouponsdetailLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Email sent successfully to:" + recipientemail, MessageTypes.Pass);
		} else if (couponsemail.getBtnSubmit().isDisplayed()) {
			PerfectoUtils.reportMessage("Email not sent to:" + recipientemail, MessageTypes.Fail);
		}
	}

	/**
	 * Select a Coupon from SELECTED Section
	 */
	@QAFTestStep(description = "I select coupons from Selected Savings tab")
	public void iSelectCouponsFromSelectedSavingsTab() {
		CouponsselectionTestPage couponsselectionpage = new CouponsselectionTestPage();

		List<Couponssearchresult> couponsList = couponsselectionpage.getCouponsLblSearchresult();

		for (Couponssearchresult singleCoupon : couponsList) {
			String prdname = singleCoupon.getCouponsresultLblCouponName().getText();
			ConfigurationManager.getBundle().setProperty("ChoosenProduct", prdname);
			singleCoupon.getCouponsresultLblCouponName().click();
			break;
		}
	}

	/**
	 * Verifying the Title has been changes as per the Selected category
	 */
	@QAFTestStep(description = "I validate the filtered coupons selection page")
	public void iValidateTheFilteredCouponsSelectionPage() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		String strSelectedcategory = ConfigurationManager.getBundle().getString("selectedcategory");
		System.out.println(strSelectedcategory);

		couponsselection.waitForPageToLoad();
		couponsselection.getCouponselectionLblAllcoupons().waitForPresent(5000);

		// Checking, if the title is Selected category
		if (couponsselection.getCouponselectionLblAllcoupons().getText().contains(strSelectedcategory)) {
			PerfectoUtils.reportMessage("The category has been changed successfully.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("The category has been changed.", MessageTypes.Fail);
		}
	}

	/**
	 * Clicks on Extra Offers and navigates to Digital Coupons page
	 */
	@QAFTestStep(description = "I click signup for digital coupons")
	public void iClickSignupForDigitalCoupons() {
		WantmoreTestPage wantmorepage = new WantmoreTestPage();

		wantmorepage.getLblPageHeader().verifyPresent();
		if (wantmorepage.getLblExtraOffers().isPresent()) {
			wantmorepage.getLblExtraOffers().click();
			PerfectoUtils.reportMessage("Navigate to Digital Coupons page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Navigate to Digital Coupons page", MessageTypes.Fail);
		}
	}

	/**
	 * Clicks on Cancel button from the Login pop up
	 */
	@QAFTestStep(description = "I click on Cancel button")
	public void iClickOnCancelButton() {
		LoginpopupTestPage loginpopup = new LoginpopupTestPage();

		loginpopup.getLoginpopupBtnCancel().waitForPresent(3000);
		loginpopup.getLoginpopupBtnCancel().click();
	}

	/**
	 * Clicks on Login button from Coupons Selection page
	 */
	@QAFTestStep(description = "I click on Login from coupons selection page")
	public void iClickOnLoginFromCouponsSelectionPage() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.waitForPageToLoad();
		couponsselection.getCouponsBtnLogin().waitForPresent(50000);
		couponsselection.getCouponsBtnLogin().click();
	}

	/**
	 * Clicks on Login button from the Login Pop up
	 */
	@QAFTestStep(description = "I click on Login/Submit button from the popup")
	public void iClickOnLoginSubmitButtonFromThePopup() {
		LoginpopupTestPage loginpopup = new LoginpopupTestPage();

		// Clicking on Login button
		loginpopup.getLoginpopupBtnOverlaylogin().waitForPresent(3000);
		loginpopup.getLoginpopupBtnOverlaylogin().click();
	}

	/**
	 * Selecting a category from the Coupons drop down options
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I select an category from the coupons dropdown")
	public void iSelectAnCategoryFromTheCouponsDorpdown() throws InterruptedException {
		CouponsselectionTestPage selectcoupons = new CouponsselectionTestPage();

		// Condition verify the coupons list page
		selectcoupons.getCouponselectionLblAllcoupons().waitForPresent(6000);
		if (selectcoupons.getCouponselectionLblAllcoupons().isPresent()) {
			PerfectoUtils.reportMessage("Coupons List page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons List page is not displayed", MessageTypes.Fail);
		}

		selectcoupons.getCouponsLblDropDown().click();
		try {
			selectcoupons.getCouponSelectCategory().waitForPresent(10000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
			selectcoupons.getCouponSelectCategory().waitForPresent(10000);
		}
		ConfigurationManager.getBundle().setProperty("selectedcategory",
				selectcoupons.getCouponSelectCategory().getText());
		selectcoupons.getCouponSelectCategory().click();

		PerfectoUtils.reportMessage("Clicked Apply button from Category filter page", MessageTypes.Pass);
	}

	/**
	 * Verifying the Login and Register buttons are available in the Coupons
	 * Details page
	 */
	@QAFTestStep(description = "I validate register and Login button in coupons detail page")
	public void iValidateRegisterAndLoginButtonInCouponsDetailPage() {
		CouponsdetailsTestPage couponsdetailspage = new CouponsdetailsTestPage();

		PerfectoUtils.verticalswipe();
		couponsdetailspage.getCouponsdetailBtnLogin().verifyPresent();
		couponsdetailspage.getCouponsdetailBtnRegister().verifyPresent();
	}

	/**
	 * Clicking on SELECTED tab as a Cold user from Coupons Selection page
	 */
	@QAFTestStep(description = "I navigate to Selected Savings tab as a cold user")
	public void iNavigateToSelectedSavingsTabAsAColdUser() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		try {
			couponsselection.getCouponsLblSelected().waitForPresent(5000);
			if (!couponsselection.getCouponsLblSelected().isPresent()) {
				PerfectoUtils.androiddeviceback();
			}
			couponsselection.getCouponsLblSelected().verifyPresent();
			couponsselection.getCouponsLblSelected().click();
			PerfectoUtils.reportMessage("Clicked Selected Section.", MessageTypes.Pass);
		} catch (Exception e) {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "SELECTED");
			String isBtnDoneVisible = (String) couponsselection.getTestBase().getDriver()
					.executeScript("mobile:checkpoint:text", params1);
			if (isBtnDoneVisible.equalsIgnoreCase("true")) {
				couponsselection.getTestBase().getDriver().executeScript("mobile:text:select", params1);
			}
		}
	}

	/**
	 * Select all coupons in Selected Savings page by clicking SELECT ALL option
	 */
	@QAFTestStep(description = "I select coupons by clicking SELECT ALL")
	public void iSelectCouponsByClickingSELECTALL() {
		CouponsselectionTestPage couponsselectionpage = new CouponsselectionTestPage();

		if (couponsselectionpage.getLblToastmsgcross().isPresent()) {
			couponsselectionpage.getLblToastmsgcross().click();
			PerfectoUtils.reportMessage("Digital coupons sign up toast message is present", MessageTypes.Info);
		}

		// Click Select ALL option
		couponsselectionpage.getCouponsBtnSelectall().click();

		// Verify Add to List is not available
		couponsselectionpage.getCouponsIconPlus().waitForNotPresent(5000);
		couponsselectionpage.getCouponsIconPlus().verifyNotPresent();
	}

	/**
	 * Click on UN SELECT ALL option. Click on single coupon.
	 */
	@QAFTestStep(description = "I click on Unselecet All option and select single coupon")
	public void iClickOnUnselecetAllOptionAndSelectSingleCoupon() {
		CouponsselectionTestPage couponsselectionpage = new CouponsselectionTestPage();

		// Click UN Select All button
		couponsselectionpage.getCouponsBtnUnSelectall().click();

		// Select single coupon
		List<Couponssearchresult> couponsList = couponsselectionpage.getCouponsLblSearchresult();

		for (Couponssearchresult singleCoupon : couponsList) {
			String prdname = singleCoupon.getCouponsresultLblCouponName().getText();
			System.out.println("prdname: " + prdname);
			ConfigurationManager.getBundle().setProperty("ChoosenProduct", prdname);
			// couponsselectionpage.getLstSelectcheckbox().get(0).click();
			singleCoupon.getCouponsChkCouponItems().verifyPresent();
			singleCoupon.getCouponsChkCouponItems().click();
			PerfectoUtils.reportMessage("Selected the Checkbox of single coupon.", MessageTypes.Pass);
			break;
		}
	}

	/**
	 * Clicking on Share button from Recipe/Coupons/Product details page
	 */
	@QAFTestStep(description = "I click share button")
	public void iClickShareButton() {
		CouponsdetailsTestPage couponsdetailspage = new CouponsdetailsTestPage();
		ShareTestPage sharepage = new ShareTestPage();

		couponsdetailspage.getCouponsdetailBtnShare().verifyPresent();
		couponsdetailspage.getCouponsdetailBtnShare().click();

		try {
			sharepage.getSharelblTitle().waitForPresent(5000);
			sharepage.getSharelblTitle().verifyPresent();
		} catch (Exception e) {
			couponsdetailspage.getCouponsdetailBtnShare().waitForPresent(2000);
			couponsdetailspage.getCouponsdetailBtnShare().click();
		}
	}

	/**
	 * Verify user able to add the selected coupon to list
	 */
	@QAFTestStep(description = "I add the selected coupon to list")
	public void iAddTheSelectedCouponTolist() {
		CouponsselectionTestPage couponSelection = new CouponsselectionTestPage();
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();

		String couponsname = couponSelection.getCouponsListCoupondesc().get(0).getText();
		getBundle().setProperty("ChoosenProduct", couponsname);

		couponSelection.getLstSelectedTabcheckbox().get(0).click();
		PerfectoUtils.reportMessage("Selected first item checkbox",MessageTypes.Info);
		couponSelection.getCouponsLblAddtolist().click();
		PerfectoUtils.reportMessage("Clicked on the add to list option", MessageTypes.Info);

		String pickerName = androidcommonpage.getAddtolistTxtNumberpicker().getText().replace(". Double tap to edit.",
				"");
		String newListNameValue = getBundle().getString("NewListName");
		int getSize = 0, actualSize = 0, i = 0;

		getSize = androidcommonpage.getAddtolistTxtNextpicker().size();

		while ((!pickerName.equals(newListNameValue) && i < 10)) {
			actualSize = getSize - 1;
			String nextPicker = androidcommonpage.getAddtolistTxtNextpicker().get(actualSize).getText();
			try {
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", nextPicker);
				Object result1 = androidcommonpage.getTestBase().getDriver().executeScript("mobile:text:select",
						params1);
			} catch (Exception e) {
				androidcommonpage.getAddtolistTxtNextpicker().get(actualSize).click();
			}
			pickerName = androidcommonpage.getAddtolistTxtNumberpicker().getText().replace(". Double tap to edit.", "");
			getSize = androidcommonpage.getAddtolistTxtNextpicker().size();
			i++;
		}
		PerfectoUtils.reportMessage("Selected List Name: " + pickerName + " from picker",MessageTypes.Info);

	}

	/**
	 * Verify add to list options in selected savings tab
	 */
	@QAFTestStep(description = "I verify add to list options in selected savings tab")
	public void iVerifyAddToListOptionsinSelectedSavings() {
		CouponsselectionTestPage couponSelection = new CouponsselectionTestPage();

		try {
			if (couponSelection.getLblToastmsgcross().isPresent())
				couponSelection.getLblToastmsgcross().click();
		} catch (Exception e) {
		}
		couponSelection.getCouponsBtnSelectall().verifyPresent();
		couponSelection.getCouponsLblAddtolist().verifyPresent();
		int checkBox = couponSelection.getLstSelectedTabcheckbox().size();
		if (checkBox != 0)
			PerfectoUtils.reportMessage("Check box for select coupon is displayed..",MessageTypes.Info);
		else
			PerfectoUtils.reportMessage("Check box for select coupon is not displayed..", MessageTypes.Fail);

		couponSelection.getCouponsBtnSelectall().click();
		couponSelection.getCouponsBtnUnSelectall().verifyPresent();

		couponSelection.getCouponsBtnUnSelectall().click();
		couponSelection.getCouponsBtnSelectall().verifyPresent();

	}

	@QAFTestStep(description = "Verify the Read more functionality not present")
	public void verifyTheReadMoreFunctionality() {

		PerfectoUtils.reportMessage("NA for android.",MessageTypes.Info);
	}

	@QAFTestStep(description = "I verify the coupons getting displayed")
	public void iverifythecouponsgettingdisplayed() {
		CouponsselectionTestPage couponSelection = new CouponsselectionTestPage();
		CouponssearchresultTestPage couponsearch = new CouponssearchresultTestPage();
		String selectedcategory = ConfigurationManager.getBundle().getPropertyValue("selectedcategory");
		String coupontitle = couponsearch.getCouponsresultLblPgtitleallcoupon().getText();
		if (coupontitle.contains(selectedcategory)) {
			PerfectoUtils.reportMessage("Selected category coupon is getting displayed", MessageTypes.Pass);
		}

		else {
			PerfectoUtils.reportMessage("Selected category coupon is not getting displayed", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I verify that coupons are displayed based on the selection")
	public void iverifythatcouponsaredisplayedbasedontheselection() {

		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		couponsselection.getLblSortpopupSecondoption().waitForPresent(5000);
		String color = couponsselection.getLblSortpopupoption().get(1).getAttribute("fgColor");
		System.out.println(color);

	}

	/**
	 * user validated the coupon selection page as cold user
	 */
	@QAFTestStep(description = "I validate Coupons selection page as cold user")
	public void iValidateCouponsSelectionPageAsColdUser() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		CouponssearchresultTestPage couponsearch = new CouponssearchresultTestPage();
		AndroidcommonTestPage androidCommon = new AndroidcommonTestPage();

		couponsselection.getCouponselectionLblAllcoupons().verifyPresent();
		couponsselection.getCouponsLblCoupondesc().verifyPresent();
		couponsselection.getLblYouMustLoginText().verifyPresent();
		couponsselection.getCouponsBtnLogin().verifyPresent();
		couponsselection.getCouponsBtnRegister().verifyPresent();
		couponsearch.getCouponsresultLblCouponexpire().verifyPresent();
		couponsearch.getCouponsresultLblOfferlimit().verifyPresent();
		androidCommon.getAppHamburger().verifyPresent();

		couponsearch.getCouponsresultLblOffercallout().get(0).verifyPresent();

		String strTtlavailCount = couponsselection.getCouponselectionLblAllcoupons().getText();
		strTtlavailCount = strTtlavailCount.replaceAll("All Coupons", "");
		strTtlavailCount = strTtlavailCount.replaceAll("\\(", "").replaceAll("\\)", "");

		if (couponsselection.getCouponsLblAvailable().isPresent()) {
			PerfectoUtils.reportMessage("Coupons Selection Page is validated and total available coupons are: " + strTtlavailCount,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons Selection Page is not applicable with the latest build", MessageTypes.Fail);
		}
	}

	/**
	 * user validated the coupon selection page as cold user
	 */
	@QAFTestStep(description = "I validate Coupons selection page as hot user")
	public void iValidateCouponsSelectionPageAsHotUser() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		CouponssearchresultTestPage couponsearch = new CouponssearchresultTestPage();
		AndroidcommonTestPage androidCommon = new AndroidcommonTestPage();
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		couponsselection.getCouponselectionLblAllcoupons().verifyPresent();
		couponsselection.getCouponsLblCoupondesc().verifyPresent();
		if (dcAutoEnrolFlag.contains("true")) {
			couponsselection.getLblYouMustLoginText().verifyNotPresent();
		} else {
			if (couponsearch.getBtnsignupnow().isPresent())
				couponsselection.getLblYouMustLoginText().verifyPresent();
			else
				couponsselection.getLblYouMustLoginText().verifyNotPresent();
		}
		couponsselection.getCouponsBtnLogin().verifyNotPresent();
		couponsselection.getCouponsBtnRegister().verifyNotPresent();
		couponsearch.getCouponsresultLblCouponexpire().verifyPresent();
		couponsearch.getCouponsresultLblOfferlimit().verifyPresent();
		androidCommon.getAppHamburger().verifyPresent();

		couponsearch.getCouponsresultLblOffercallout().get(0).verifyPresent();

		String strTtlavailCount = couponsselection.getCouponselectionLblAllcoupons().getText();
		strTtlavailCount = strTtlavailCount.replaceAll("All Coupons", "");
		strTtlavailCount = strTtlavailCount.replaceAll("\\(", "").replaceAll("\\)", "");

		if (couponsselection.getCouponsLblAvailable().isPresent()) {
			PerfectoUtils.reportMessage("Coupons Selection Page is validated and total available coupons are: " + strTtlavailCount,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons Selection Page is not applicable with the latest build", MessageTypes.Fail);
		}
	}

	/**
	 * CLick on Clear from search result
	 */
	@QAFTestStep(description = "I click clear from search result")
	public void iClickClearFromSearchResult() {
		PerfectoUtils.reportMessage("NA for Android..",MessageTypes.Info);

	}

	/**
	 * Verify counpons landing page is displayed
	 */
	@QAFTestStep(description = "I verify counpon landing page is displayed")
	public void iVerifyCouponLandingPageIsDisplayed() {
		PerfectoUtils.reportMessage("NA for Android..",MessageTypes.Info);

	}

	/**
	 * Verify add to list and select button
	 */
	@QAFTestStep(description = "I verify add to list and select button")
	public void iVerifyAddToListAndSelectButton() {
		CouponsdetailsTestPage couponDetails = new CouponsdetailsTestPage();

		couponDetails.getBtnAddToList().verifyPresent();
		System.out.println(couponDetails.getCoupondetailsBtnSelect().getText());
		if (couponDetails.getCoupondetailsBtnSelect().getText().equals("SELECTED")) {
			PerfectoUtils.reportMessage("Selected button is displayed..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected button is not displayed..", MessageTypes.Fail);

		}
	}

	/**
	 * Note down the selected list name
	 */
	@QAFTestStep(description = "I note down the list name")
	public void iNoteDownTheListName() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		String ChoosenList = androidcommon.getAddtolistTxtNumberpicker().getText();
		getBundle().setProperty("ChoosenList", ChoosenList);
		getBundle().setProperty("NewListName", ChoosenList);
		PerfectoUtils.reportMessage("Selected list: " + ChoosenList, MessageTypes.Pass);
	}

	@QAFTestStep(description = "I enter mandatory field for cold user and click on Send button")
	public void iEnterMandatoryFieldForColdUserAndClickOnSendButton() {
		AndroidStepdefProducts andProd = new AndroidStepdefProducts();

		andProd.iEnterValidEmailAddressAndClickOnSendButton();
	}

	@QAFTestStep(description = "I select Select All button")
	public void iSelectSelectAllButton() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponsBtnSelectall().verifyPresent();
		couponsselection.getCouponsBtnSelectall().click();

	}
}
