package com.heb.automation.android.pages;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class EmailcontentTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "emailpage.btn.attach")
	private QAFWebElement BtnAttach;
	@FindBy(locator = "emailpage.btn.send")
	private QAFWebElement BtnSend;
	@FindBy(locator = "emailpage.btn.more")
	private QAFWebElement BtnMore;
	@FindBy(locator = "emailpage.lbl.to")
	private QAFWebElement LblTo;
	@FindBy(locator = "emailpage.edt.recipientto")
	private QAFWebElement EdtRecipientto;
	@FindBy(locator = "emailpage.lbl.subject")
	private QAFWebElement LblSubject;
	@FindBy(locator = "emailpage.lbl.emailbody")
	private QAFWebElement LblEmailbody;
	@FindBy(locator = "emailpage.lbl.manualsetup")
	private QAFWebElement LblManualsetup;
	@FindBy(locator = "manualsetup.btn.pop3account")
	private QAFWebElement BtnPop3account;
	@FindBy(locator = "manualsetup.btn.imapaccount")
	private QAFWebElement BtnImapaccount;
	@FindBy(locator = "manualsetup.btn.microsoft")
	private QAFWebElement BtnMicrosoft;
	@FindBy(locator = "manualsetup.btn.signin")
	private QAFWebElement BtnSignin;
	@FindBy(locator = "manualsetup.lbl.alertpopup")
	private QAFWebElement LblAlertpopup;
	@FindBy(locator = "manualsetup.btn.continue")
	private QAFWebElement BtnContinue;
	@FindBy(locator = "manualsetup.btn.cancel")
	private QAFWebElement BtnCancel;
	@FindBy(locator = "manualsetup.chk.notification")
	private QAFWebElement ChkNotification;
	@FindBy(locator = "manualsetup.lbl.editnames")
	private QAFWebElement LblEditnames;
	@FindBy(locator = "manualsetup.btn.done")
	private QAFWebElement BtnDone;
	@FindBy(locator = "manualsetup.btn.newmail")
	private QAFWebElement BtnNewmail;
	@FindBy(locator = "manualsetup.chk.pop3")
	private QAFWebElement chkPop3;
	@FindBy(locator = "manualsetup.chk.imap4")
	private QAFWebElement chkImap4;
	@FindBy(locator = "manualsetup.edt.server")
	private QAFWebElement edtServer;
	@FindBy(locator = "manualsetup.edt.smtp")
	private QAFWebElement edtSmtp;		
	@FindBy(locator = "manualsetup.lbl.message")
	private QAFWebElement lblMessage;
	@FindBy(locator = "manualsetup.btn.ok")
	private QAFWebElement btnOk;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getBtnAttach() {
		return BtnAttach;
	}

	public QAFWebElement getBtnSend() {
		return BtnSend;
	}

	public QAFWebElement getBtnMore() {
		return BtnMore;
	}

	public QAFWebElement getLblTo() {
		return LblTo;
	}

	public QAFWebElement getEdtRecipientto() {
		return EdtRecipientto;
	}

	public QAFWebElement getLblSubject() {
		return LblSubject;
	}

	public QAFWebElement getLblEmailbody() {
		return LblEmailbody;
	}

	public QAFWebElement getLblManualsetup() {
		return LblManualsetup;
	}

	public QAFWebElement getBtnPop3account() {
		return BtnPop3account;
	}

	public QAFWebElement getBtnImapaccount() {
		return BtnImapaccount;
	}

	public QAFWebElement getBtnMicrosoft() {
		return BtnMicrosoft;
	}

	public QAFWebElement getBtnSignin() {
		return BtnSignin;
	}

	public QAFWebElement getLblAlertpopup() {
		return LblAlertpopup;
	}

	public QAFWebElement getBtnContinue() {
		return BtnContinue;
	}

	public QAFWebElement getBtnCancel() {
		return BtnCancel;
	}

	public QAFWebElement getChkNotification() {
		return ChkNotification;
	}

	public QAFWebElement getLblEditnames() {
		return LblEditnames;
	}

	public QAFWebElement getBtnDone() {
		return BtnDone;
	}

	public QAFWebElement getBtnNewmail() {
		return BtnNewmail;
	}
	
	public QAFWebElement getChkPop3() {
		return chkPop3;
	}

	public QAFWebElement getChkImap4() {
		return chkImap4;
	}
	
	public QAFWebElement getEdtServer() {
		return edtServer;
	}
	
	public QAFWebElement getEdtSmtp() {
		return edtSmtp;
	}
	
	public QAFWebElement getLblMessage() {
		return lblMessage;
	}
	
	public QAFWebElement getBtnOk() {
		return btnOk;
	}
}
