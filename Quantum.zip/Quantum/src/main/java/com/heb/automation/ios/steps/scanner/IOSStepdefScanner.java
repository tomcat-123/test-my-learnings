package com.heb.automation.ios.steps.scanner;

import java.util.HashMap;
import java.util.Map;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.products.ProductdetailTestPage;
import com.heb.automation.common.pages.scanner.ScanProductsTestPage;
import com.heb.automation.common.pages.scanner.ScannerTestPage;
import com.heb.automation.common.pages.shoppinglist.ListdetailsTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of steps in Scanner

	I navigate to Scan Products screen
	Verify the elements in Scan products screen
	I should see the scanned product in the selected list
	I click on Cancel button from the add to list popup
	I click on add to list buttom from the popup
	Verify the Scan receipt option is not present for cold user
	I click on add to list buttom from the popup for receipt*/


public class IOSStepdefScanner {

	/**
	 * Navigating to Scan product screen
	 */
	@QAFTestStep(description = "I navigate to Scan Products screen")
	public void iNavigateToScanProductsScreen() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		ioscommon.getHeaderBtnScanProducts().waitForPresent(3000);
		ioscommon.getHeaderBtnScanProducts().click();

		try {
			if (ioscommon.getScanPopupEnablecamera().isPresent()) {
				ioscommon.getScanBtnOkEnablecamera().click();
				ioscommon.waitForPageToLoad();
			} if (ioscommon.getScanLblPagetitle().isPresent()) {
				PerfectoUtils.reportMessage("Navigated to Scan Products page", MessageTypes.Pass);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Validating the elements in Scan products page
	 */
	@QAFTestStep(description = "Verify the elements in Scan products screen")
	public void verifyTheElementsInScanProductsScreen() {
		ScanProductsTestPage scanprdts = new ScanProductsTestPage();
		
		scanprdts.getLblPagetitle().verifyPresent();
		scanprdts.getLblScandescription().verifyPresent();
		scanprdts.getLblMultiscanswitch().verifyPresent();
		
	}
	
	/**
	 * Verification of scanned product in selected list.
	 */
	@QAFTestStep(description = "I should see the scanned product in the selected list")
	public void iShouldSeeTheScannedProductInTheSelectedList() {
		WeeklygroceriesTestPage weeklygroceries = new WeeklygroceriesTestPage();
		ListdetailsTestPage listdetails = new ListdetailsTestPage();

		String scannedPdtname = ConfigurationManager.getBundle().getString("scannedItemname");

		// Checking whether the page has been navigated to List Details page
		if (listdetails.getListpageLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to " + listdetails.getListpageLblPagetitle().getText() + " page.",
					MessageTypes.Pass);

			// Checking whether the scanned product is available in the list
			if (weeklygroceries.getShopingListEntryByLable(scannedPdtname).isPresent()) {
				PerfectoUtils.reportMessage("Scanned product: " + scannedPdtname + ", is available in the list", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Scanned product: " + scannedPdtname + ", is not available in the list",
						MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("Not navigated to List details Page.", MessageTypes.Fail);
		}
	}
	
	/**
	 * Clicking on Cancel button. Verification of Add to List pop up.
	 */
	@QAFTestStep(description = "I click on Cancel button from the add to list popup")
	public void iClickOnCancelButtonFromTheAddToListPopup() {
		ScannerTestPage scanner = new ScannerTestPage();

		// Verify whether the "Add to list" pop-up is present
		if (scanner.getAppscanBtnAddtolist().isPresent()) {
			String scannedItemname = scanner.getAppscanLblItemname().getText();
			
			scanner.getAppscanBtnCanceladdtolist().click();
			scanner.waitForPageToLoad();
			
			ConfigurationManager.getBundle().setProperty("scannedItemname", scannedItemname);
			
			PerfectoUtils.reportMessage("Product name: " + scannedItemname, MessageTypes.Pass);
			PerfectoUtils.reportMessage("Clicked Cancel button from the popup.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Add to list popup not present.", MessageTypes.Fail);
		}
	}
	
	/**
	 * Clicking on Add to List from Pop up.Handling the error pop up.
	 */
	@QAFTestStep(description = "I click on add to list buttom from the popup")
	public void iClickOnAddToListButtomFromThePopup() {
		ScannerTestPage scanner = new ScannerTestPage();
		ProductdetailTestPage productdetails = new ProductdetailTestPage();
		
		productdetails.waitForPageToLoad();
		// Verify whether the "Add to list" pop-up is present
		if (scanner.getAppscanBtnAddtolist().isPresent()
				&& ((scanner.getAppscanBtnAddtolist().getAttribute("hidden")).equals("false"))) {
			String scannedItemname = scanner.getAppscanLblItemname().getText();
			ConfigurationManager.getBundle().setProperty("scannedItemname", scannedItemname);
			scanner.getAppscanBtnAddtolist().click();
			//PerfectoUtils.reportMessage("Adding the product " + scannedItemname + " to the list.", MessageTypes.Pass);
			PerfectoUtils.reportMessage("Clicked Add to list button from the popup.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Add to list popup not present.", MessageTypes.Fail);
		}
		
		// handling the error pop-up
		if (scanner.getLblErrorpopuptitle().isPresent()) {
			PerfectoUtils.reportMessage("Error occured!" + scanner.getLblErrorpopupcontent().getText(), MessageTypes.Fail);
			scanner.getBtnOkbtnerrorpopup().click();
		} 
		
	}
	
	/**
	 * Validating the elements in Scan products page
	 */
	@QAFTestStep(description = "Verify the Scan receipt option is not present for cold user")
	public void verifyTheScanReceiptOptionIsNotPresentForColdUser() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		
		if(!listdetails.getListpageLinkScanreciept().isPresent()){
			PerfectoUtils.reportMessage("Scan Receipt option not available for cold user as expected.",MessageTypes.Pass);
		} else{
			PerfectoUtils.reportMessage("Found Scan Receipt option for cold user.",MessageTypes.Fail);
		}
		
		
	}
	
	/**
	 * Clicking on Add to List from Pop up.Handling the error pop up.
	 */
	@QAFTestStep(description = "I click on add to list buttom from the popup for receipt")
	public void iClickOnAddToListButtomFromThePopupForReceipt() {
		ScannerTestPage scanner = new ScannerTestPage();
		ProductdetailTestPage productdetails = new ProductdetailTestPage();
		
		productdetails.waitForPageToLoad();
		// Verify whether the "Add to list" pop-up is present
		if (scanner.getAppscanBtnAddtolist().isPresent()
				&& ((scanner.getAppscanBtnAddtolist().getAttribute("hidden")).equals("false"))) {
			String scannedItemname = scanner.getAppscanLblItemname().getText();
			ConfigurationManager.getBundle().setProperty("scannedItemname", scannedItemname);
			scanner.getAppscanBtnAddtolist().click();
			//PerfectoUtils.reportMessage("Adding the product " + scannedItemname + " to the list.", MessageTypes.Pass);
			PerfectoUtils.reportMessage("Clicked Add to list button from the popup.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Add to list popup not present.", MessageTypes.Fail);
		}
		
		// handling the error pop-up
		if (scanner.getLblErrorpopuptitle().isPresent()) {
			PerfectoUtils.reportMessage("Error occured!" + scanner.getLblErrorpopupcontent().getText(), MessageTypes.Fail);
			scanner.getBtnOkbtnerrorpopup().click();
		} 
		
	}
}
