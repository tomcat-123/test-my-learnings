/**
 * 
 */
package com.heb.automation.common.steps.storelocator;

import java.util.HashMap;
import java.util.Map;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.StoreResult;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.storelocator.StoredetailsTestPage;
import com.heb.automation.common.pages.storelocator.StorelistviewresultTestPage;
import com.heb.automation.common.pages.storelocator.StorelocatorTestPage;
import com.heb.automation.common.pages.storelocator.StoremapviewTestPage;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in StoreLocator

	I choose an store from the store list
	I set the store my Store
	I should see the store name in my Store Locator page as default
	I should see Store Locator screen in map view for the selected City
	I select Refine button
	I verify the store details page
	I naviagte to List view and I verify filter options
	I validate the map view of store locator page
	I select a store from List view
	I verify refine page
	I verify pharmacy info displays for pharmacy store*/

public class CommonStepDefStoreLocator {
	/**
	 * user choose a store of his choice from the listed store
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I choose an store from the store list")
	public void iChooseAnStoreFromTheStoreList() throws InterruptedException {
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		StoredetailsTestPage storedetail = new StoredetailsTestPage();

		storepage.getStorelocatorImgListswitch().waitForPresent(5000);
		storepage.getStorelocatorImgListswitch().click();

		// storepage.getStorelocatorChooseStorename().click();
		storelistresult.launchPage(null);
		StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(1);
		String StoreName = store.getStorelocatorLblStorename().getText();
		PerfectoUtils.reportMessage("Store Name:" + StoreName);
		store.click();
		try {
			storedetail.waitForPageToLoad();
			storedetail.getStoredetailsSetasyourstore().waitForPresent(20000);
			storedetail.getStoredetailsSetasyourstore().verifyPresent();
			getBundle().setProperty("ChoosenStoreNumber", "1");
			System.out.println(getBundle().getProperty("ChoosenStoreNumber"));
		} catch (Exception e) {
			PerfectoUtils.getAppiumDriver().navigate().back();
			storelistresult.waitForPageToLoad();
			StoreResult store1 = storelistresult.getStorelocatorLblStoreresults().get(2);
			StoreName = store1.getStorelocatorLblStorename().getText();
			PerfectoUtils.reportMessage("Store Name:" + StoreName);
			store1.click();
			storedetail.waitForPageToLoad();
			storedetail.getStoredetailsSetasyourstore().waitForPresent(20000);
			storedetail.getStoredetailsSetasyourstore().verifyPresent();
			getBundle().setProperty("ChoosenStoreNumber", "2");
		}
	}

	/**
	 * User set the store my Store
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I set the store my Store")
	public void iSetTheStoreMyStore() throws InterruptedException {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();

		storedetail.waitForPageToLoad();
		PerfectoUtils.verticalswipe(80, 75, 2);
		storedetail.getStoredetailsSetasyourstore().waitForPresent(20000);
		storedetail.getStoredetailsSetasyourstore().click();
		storedetail.waitForPageToLoad();

		// Checking for Store Update Error pop-up
		if (storedetail.getLblPopupstoreupdaterrortitle().isPresent()) {
			PerfectoUtils.reportMessage("Store Update Error popup found.", MessageTypes.Fail);
			PerfectoUtils.reportMessage("Mesage: " + storedetail.getLblPopupstoreupdaterrormsg().getText());
			storedetail.getBtnPopupstoreupdaterrorok().click();
			PerfectoUtils.reportMessage("Clicked Ok button from the popup. Please re-login and try again");
		}

		try {
			storedetail.getStoredetailsHotuseroption().waitForPresent(50000);
			if (storedetail.getStoredetailsHotuseroption().isPresent()) {
				PerfectoUtils.reportMessage("My HEB Store option is visible", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("My HEB Store option is not visible", MessageTypes.Fail);
			}
		} catch (Exception e) {
			// Clicking again "Set as My H-E-B Store", since the clicking is not
			// happening sometimes in the first time.
			storedetail.getStoredetailsSetasyourstore().waitForPresent(20000);
			storedetail.getStoredetailsSetasyourstore().click();

			// Checking for Store Update Error pop-up
			if (storedetail.getLblPopupstoreupdaterrortitle().isPresent()) {
				PerfectoUtils.reportMessage("Store Update Error popup found.", MessageTypes.Fail);
				PerfectoUtils.reportMessage("Mesage: " + storedetail.getLblPopupstoreupdaterrormsg().getText());
				storedetail.getBtnPopupstoreupdaterrorok().click();
				PerfectoUtils.reportMessage("Clicked Ok button from the popup. Please re-login and try again");
			}

			// Checking if My HEB Store option is present
			storedetail.getStoredetailsHotuseroption().waitForPresent(80000);
			if (storedetail.getStoredetailsHotuseroption().isPresent()) {
				PerfectoUtils.reportMessage("My HEB Store option is visible", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("My HEB Store option is not visible", MessageTypes.Fail);
			}
		}
	}

	/**
	 * user should see the store name in my Store Locator page as default
	 */
	@QAFTestStep(description = "I should see the store name in my Store Locator page as default")
	public void iShouldSeeTheStoreNameInMyStoreLocatorPageAsDefault() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		StoredetailsTestPage storedetail = new StoredetailsTestPage();

		androidcommon.getAppHamburger().click();
		storedetail.getStoredetailsViewstoreaddress().verifyPresent();
		androidcommon.getAppSliderStorelocator().click();
	}

	/**
	 * user should see Store Locator screen in map view for the selected City
	 */
	@QAFTestStep(description = "I should see Store Locator screen in map view for the selected City")
	public void iShouldSeeStoreLocatorScreenInMapViewForTheSelectedCity() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		// Check if selected city is present on screen
		weeklygrocery.getShopingListEntryByLable(getBundle().getString("storelocator.city")).verifyPresent();
	}

	/**
	 * user select Refine button
	 */
	@QAFTestStep(description = "I select Refine button")
	public void iSelectRefineButton() {
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		storelocator.getStorelocatorLblRefine().waitForPresent(3000);
		storelocator.getStorelocatorLblRefine().click();
		PerfectoUtils.reportMessage("Clicked on Refine.", MessageTypes.Pass);
	}

	/**
	 * user verify the store detail page
	 */
	@QAFTestStep(description = "I verify the store details page")
	public void iVerifyTheStoreDetailsPage() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();
		boolean storedtl;
		String StoreName;

		if (storedetail.getStoredetailsViewstorename().isPresent()) {
			storedtl = storedetail.getStoredetailsViewstorename().verifyPresent();
			StoreName = storedetail.getStoredetailsViewstorename().getText();
		} else {
			storedtl = storedetail.getlnkViewStoreName1().verifyPresent();
			StoreName = storedetail.getlnkViewStoreName1().getText();
		}
		/*
		 * direction is removed from new app
		 */
		//storedetail.getStoredetailsGetdirections().verifyPresent();
		storedetail.getStoredetailsViewphonenumber().verifyPresent();
		PerfectoUtils.reportMessage("Selected store name: " + StoreName);
		if (storedtl) {
			PerfectoUtils.reportMessage("Store detail page is displayed for the store:" + StoreName, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Store detail page is not displayed", MessageTypes.Fail);
		}
		PerfectoUtils.verticalswipe();
		storedetail.getStoredetailsViewweeklyad().verifyPresent();
	}

	/**
	 * user is naviagted to List view and I verify filter options
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I naviagte to List view and I verify filter options")
	public void iNaviagteToListViewAndIVerifyFilterOptions() throws InterruptedException {
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		storelocator.getStorelocatorImgListswitch().waitForPresent(20000);
		storelocator.getStorelocatorImgListswitch().click();
		try {
			// check the Pharmacy image is available
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "GROUP:Android\\store Locator\\pharmacy_image.png");
			params1.put("screen.top", "0%");
			params1.put("screen.height", "100%");
			params1.put("screen.left", "0%");
			params1.put("screen.width", "100%");
			Object result1 = storelocator.getTestBase().getDriver().executeScript("mobile:image:find", params1);
			PerfectoUtils.reportMessage("Stores are filtered for Pharmacy option", MessageTypes.Pass);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Stores with Pharmacy are not filtered properly", MessageTypes.Fail);
		}
	}

	/**
	 * user validate the map view of store locator page
	 */
	@QAFTestStep(description = "I validate the map view of store locator page")
	public void iValidateTheMapViewOfStoreLocatorPage() {
		StoremapviewTestPage mapview = new StoremapviewTestPage();
		StorelocatorTestPage storepage = new StorelocatorTestPage();

		try {
			// Verify all fields of map view
			storepage.getStorelocatorLblRefine().verifyPresent();
			mapview.getStorelocatorIconSearch().verifyPresent();
			storepage.getStorelocatorImgListswitch().verifyPresent();
			storepage.getStorelocatorImgMapswitch().verifyPresent();
			PerfectoUtils.reportMessage("Store locator map view page is validated", MessageTypes.Pass);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Store locator map view page is validated and found errors", MessageTypes.Fail);
		}
	}

	/**
	 * user select a store from List view
	 */
	@QAFTestStep(description = "I select a store from List view")
	public void iSelectAStoreFromListView() {
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		WeeklygroceriesTestPage wgroceries = new WeeklygroceriesTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();

		if (wgroceries.getShopingListEntryByLable("Store Location Not Found").isPresent()) {
			PerfectoUtils.reportMessage("Store Location Not Found", MessageTypes.Info);
			appcrash.getbtnStoreLocatorOK().verifyPresent();
			appcrash.getbtnStoreLocatorOK().click();
		}

		storelistresult.launchPage(null);
		storelistresult.getStorelocatorLblStoreresults().get(1).waitForPresent(3000);
		StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(1);
		PerfectoUtils.reportMessage("Selecting store from list view page", MessageTypes.Pass);
		store.click();
		PerfectoUtils.reportMessage("Store Selected from Listview.", MessageTypes.Pass);
	}

	/**
	 * user verify refine page
	 */
	@QAFTestStep(description = "I verify refine page")
	public void iVerifyRefinePage() {
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		if (storelocator.getstorelocatorlblrefinestores().isPresent()) {
			storelocator.getstorelocatorchkpharmacy().verifyPresent();
			storelocator.getStorelocatorChkCarwash().verifyPresent();
			storelocator.getStorelocatorChkFuel().verifyPresent();
			storelocator.getStorelocatorChkHebplus().verifyPresent();
			storelocator.getStorelocatorChkHrpharmacy().verifyPresent();
			storelocator.getStorelocatorChkOpenhr().verifyPresent();
			
			storelocator.getstorelocatorbtndone().verifyPresent();
			PerfectoUtils.reportMessage("Verifying refine page", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("Please navigate to refine page", MessageTypes.Fail);
		}
	}

	/**
	 * user verify pharmacy info displays for pharmacy store
	 */
	@QAFTestStep(description = "I verify pharmacy info displays for pharmacy store")
	public void iVerifyPharmacyInfoDisplaysForPharmacyStore() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();

		storedetail.waitForPageToLoad();
		PerfectoUtils.verticalswipe();
		storedetail.getStoreDetailsLblPharmacy().verifyPresent();
		storedetail.getStoredetailsLnkPharmacyphonenumber().verifyPresent();
	}

}
