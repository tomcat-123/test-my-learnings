package com.heb.automation.common.pages.cartncheckout;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CreditcardTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "creditcard.txt.cardholder")
	private QAFWebElement creditcardTxtCardholder;
	@FindBy(locator = "creditcard.txt.cardnumber")
	private QAFWebElement creditcardTxtCardnumber;
	@FindBy(locator = "creditcard.txt.cvc")
	private QAFWebElement creditcardTxtCvc;
	@FindBy(locator = "creditcard.txt.expiration")
	private QAFWebElement creditcardTxtExpiration;
	@FindBy(locator = "creditcard.btn.add")
	private QAFWebElement creditcardBtnAdd;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getCreditcardTxtCardholder() {
		return creditcardTxtCardholder;
	}

	public QAFWebElement getCreditcardTxtCardnumber() {
		return creditcardTxtCardnumber;
	}

	public QAFWebElement getCreditcardTxtCvc() {
		return creditcardTxtCvc;
	}

	public QAFWebElement getCreditcardTxtExpiration() {
		return creditcardTxtExpiration;
	}

	public QAFWebElement getCreditcardBtnAdd() {
		return creditcardBtnAdd;
	}

	@Override
	public void waitForPageToLoad() {
		// TODO Auto-generated method stub
		super.waitForPageToLoad();
		creditcardBtnAdd.waitForPresent(5000);
	}
}
