package com.heb.automation.common;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.appium.java_client.ios.IOSDriver;

public class InstallAppiOS {

	@Parameters({ "deviceName_", "repository_url", "application_name", "user", "password", "app_environment", "app_instrument", "sensor_instrument" })
	@Test
	public void InstallApp_iOS(String deviceName_, String repository_url, String application_name, String user,
			String password, String appEnv, String app_instrument, String sensor_instrument) throws IOException {

		System.out.println("Run started");

		DesiredCapabilities capabilities = new DesiredCapabilities("", "", Platform.ANY);
		String host = "heb.perfectomobile.com";

		capabilities.setCapability("user", user);
		capabilities.setCapability("password", password);
		capabilities.setCapability("deviceName", deviceName_);
		PerfectoUtils.setExecutionIdCapability(capabilities, host);

		IOSDriver<WebElement> driver = new IOSDriver<WebElement>(
				new URL("https://" + host + "/nexperience/perfectomobile/wd/hub"), capabilities);
		
		System.out.println("Device opened using "+ user);
		try {
			uninstallApp(driver, application_name);
		} catch (Exception e) {
			e.printStackTrace();
		}
		installApp(driver, repository_url, app_instrument, sensor_instrument);
		openApp(driver, application_name);

		handleLocationpopup(driver);
		handlepopup(driver);
		if (appEnv.equalsIgnoreCase("production")) {
			openApp(driver, application_name);
			setProdEnv(driver);
		}
		driver.quit();
	}

	private void handlepopup(IOSDriver<WebElement> driver) {

		try {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "Allow");
			Object result1 = driver.executeScript("mobile:text:select", params1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void handleLocationpopup(RemoteWebDriver driver) {

		try {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "Only While Using the App");
			Object result1 = driver.executeScript("mobile:text:select", params1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Parameters({ "application_name" })
	private static void openApp(IOSDriver<WebElement> driver, String application_name) {
		
		Map<String, Object> params1 = new HashMap<>();
		// params1.put("name", application_name);
		params1.put("name", application_name);
		Object result1 = driver.executeScript("mobile:application:open", params1);
		System.out.println("Application Launched");
	}

	@Parameters({ "repository_url", "app_instrument", "sensor_instrument" })
	private static void installApp(IOSDriver<WebElement> driver, String repository_url, String app_instrument, String sensor_instrument) {

		System.out.println("Installing the application");
		
		System.out.println("Application path used for Installing "+ repository_url );
		
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("file", repository_url);
		params.put("instrument", app_instrument);
		params.put("sensorInstrument", sensor_instrument);
		//params.put("cameraInstrument", "camera");

		String resultStr = (String) driver.executeScript("mobile:application:install", params);
		System.out.println("Install completed");
	}

	@Parameters({ "application_name" })
	private static void uninstallApp(IOSDriver<WebElement> driver, String application_name) {

		System.out.println("Un-Installing the application");

		Map<String, Object> params = new HashMap<>();
		params.put("name", application_name);
		Object result1 = driver.executeScript("mobile:application:uninstall", params);

		System.out.println("Un-Install completed");

	}

	private void setProdEnv(IOSDriver<WebElement> driver) {

		System.out.println("Setting the app env to production");

		Map<String, Object> params7 = new HashMap<>();
		params7.put("content", "SKIP");
		Object result7 = driver.executeScript("mobile:text:select", params7);

		/* Click continue without register */
		try {
			Map<String, Object> params8 = new HashMap<>();
			params8.put("content", "continue without registering");
			Object result8 = driver.executeScript("mobile:text:select", params8);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
