package com.heb.automation.common.pages.recipes;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class QuickrecipefinderTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "quickfinder.btn.quickfindertab")
	private QAFWebElement quickfinderBtnQuickfindertab;
	@FindBy(locator = "quickfinder.btn.find")
	private QAFWebElement quickfinderFind;
	@FindBy(locator = "quickfinder.btn.advancedtab")
	private QAFWebElement quickfinderBtnAdvancedtab;
	@FindBy(locator = "quickfinder.chk.recipe")
	private QAFWebElement quickfinderchkrecipe;
	@FindBy(locator = "quickfinder.lbl.iwanttomake")
	private QAFWebElement quickfinderLblIwanttomake;
	@FindBy(locator = "quickfinder.lbl.with")
	private QAFWebElement quickfinderLblWith;
	@FindBy(locator = "quickfinder.lbl.in")
	private QAFWebElement quickfinderLblIn;
	@FindBy(locator = "quickfinder.btn.makefirstitem")
	private QAFWebElement quickfinderBtnMakeItem1;
	@FindBy(locator = "quickfinder.btn.withfirstitem")
	private QAFWebElement quickfinderBtnWithItem1;
	@FindBy(locator = "quickfinder.btn.infirstitem")
	private QAFWebElement quickfinderBtnInItem1;
	@FindBy(locator = "quickfinder.btn.makeseconditem")
	private QAFWebElement quickfinderBtnMakeItem2;
	@FindBy(locator = "quickfinder.btn.withseconditem")
	private QAFWebElement quickfinderBtnWithItem2;
	@FindBy(locator = "quickfinder.lbl.recipenotfound")
	private QAFWebElement quickfinderlblrecipenotfound;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getQuickfinderBtnQuickfindertab() {
		return quickfinderBtnQuickfindertab;
	}

	public QAFWebElement getQuickfinderFind() {
		return quickfinderFind;
	}

	public QAFWebElement getQuickfinderLblIwanttomake() {
		return quickfinderLblIwanttomake;
	}

	public QAFWebElement getQuickfinderLblWith() {
		return quickfinderLblWith;
	}

	public QAFWebElement getQuickfinderLblIn() {
		return quickfinderLblIn;
	}

	public QAFWebElement getQuickfinderBtnMakeItem1() {
		return quickfinderBtnMakeItem1;
	}

	public QAFWebElement getQuickfinderBtnWithItem1() {
		return quickfinderBtnWithItem1;
	}

	public QAFWebElement getQuickfinderBtnInItem1() {
		return quickfinderBtnInItem1;
	}

	public QAFWebElement getQuickfinderBtnAdvancedtab() {
		return quickfinderBtnAdvancedtab;
	}

	public QAFWebElement getquickfinderchkrecipe() {
		return quickfinderchkrecipe;
	}

	public QAFWebElement getQuickfinderBtnMakeItem2() {
		return quickfinderBtnMakeItem2;
	}

	public QAFWebElement getQuickfinderBtnWithItem2() {
		return quickfinderBtnWithItem2;
	}

	public QAFWebElement getQuickfinderLblRecipenotfound() {
		return quickfinderlblrecipenotfound;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
}
