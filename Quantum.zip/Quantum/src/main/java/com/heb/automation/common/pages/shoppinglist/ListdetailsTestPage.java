package com.heb.automation.common.pages.shoppinglist;

import java.util.List;
import com.heb.automation.common.components.ListDetails;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ListdetailsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "listpage.lbl.pagetitle")
	private QAFWebElement listpageLblPagetitle;
	@FindBy(locator = "listpage.btn.email")
	private QAFWebElement listpageBtnEmail;
	@FindBy(locator = "listpage.btn.menuoverflow")
	private QAFWebElement listpageBtnMenuoverflow;
	@FindBy(locator = "listpage.lbl.shoppingitemcount")
	private QAFWebElement listpageLblShoppingitemcount;
	@FindBy(locator = "listpage.lbl.shoppingitemcheckoffcount")
	private QAFWebElement listpageLblShoppingitemcheckoffcount;
	@FindBy(locator = "listpage.cell.shoppingitem")
	private List<ListDetails> listpageCellShoppingitem;
	@FindBy(locator = "listpage.btn.checkbox")
	private QAFWebElement listpageBtnCheckbox;
	@FindBy(locator = "listpage.lbl.itemname")
	private QAFWebElement listpageLblItemname;
	@FindBy(locator = "listpage.img.shoppinglistitemarrow")
	private QAFWebElement listpageImgShoppinglistitemarrow;
	@FindBy(locator = "listpage.link.copytoanotherlist")
	private QAFWebElement listpageLinkCopytoanotherlist;
	@FindBy(locator = "listpage.btn.cancel")
	private QAFWebElement listpageBtnCancel;
	@FindBy(locator = "listpage.txt.shoppinglistquantity")
	private QAFWebElement listpageTxtShoppinglistquantity;
	@FindBy(locator = "listpage.link.deleteitem")
	private QAFWebElement listpageLinkDeleteitem;
	@FindBy(locator = "listpage.link.deleteallitem")
	private QAFWebElement listpageLinkDeleteallitem;
	@FindBy(locator = "listpage.link.uncheckitem")
	private QAFWebElement listpageLinkUncheckitem;
	@FindBy(locator = "listpage.txt.search")
	private QAFWebElement listpageTxtSearch;
	@FindBy(locator = "listpage.btn.collapse")
	private QAFWebElement listpageBtnCollapse;
	@FindBy(locator = "listpage.btn.scanmenu")
	private QAFWebElement listpageBtnScanmenu;
	@FindBy(locator = "listpage.btn.more")
	private QAFWebElement listpageBtnMore;
	@FindBy(locator = "listpage.lbl.checkedOff")
	private QAFWebElement listpageLblCheckedOff;
	@FindBy(locator = "listpage.lbl.deleteallitemoverlay")
	private QAFWebElement listpageLblDeleteallitemoverlay;
	@FindBy(locator = "listpage.deleteallpopup.lbl.title")
	private QAFWebElement listpageLblPopuptitledeleteallitem;
	@FindBy(locator = "listpage.lbl.itemnamelist")
	private List<ListDetails> listpageLblItemNameList;
	@FindBy(locator = "listpage.lbl.wishlisttitle")
	private QAFWebElement listpageTitleWishlistpage;
	@FindBy(locator = "listpage.lbl.itemname")
	private List<ListDetails> listpageLblItemNameListobj;
	@FindBy(locator = "listpage.txt.enterrecieptnumber")
	private QAFWebElement listpageTxtEnterrecieptnumber;
	@FindBy(locator = "listpage.lbl.recieptmessage")
	private QAFWebElement listpageLblRecieptmessage;
	@FindBy(locator = "listpage.lbl.enterreceiptoverlay")
	private QAFWebElement listpageLblEnterreceiptoverlay;
	@FindBy(locator = "listpage.img.enterreciept")
	private QAFWebElement listpageImgEnterreciept;
	@FindBy(locator = "listpage.link.enterreciept")
	private QAFWebElement listpageLinkEnterreciept;
	@FindBy(locator = "listpage.btn.submit")
	private QAFWebElement listpageBtnSubmit;
	@FindBy(locator = "listpage.link.scanproduct")
	private List<ListDetails> listpageLinkScanproduct;
	@FindBy(locator = "listpage.link.scanproduct")
	private QAFWebElement pageLinkScanproduct;
	@FindBy(locator = "listpage.link.scanreciept")
	private QAFWebElement listpageLinkScanreciept;
	@FindBy(locator = "listpage.btn.add")
	private QAFWebElement listpageBtnAdd;
	@FindBy(locator = "listpage.txt.afterenteringreceipt")
	private QAFWebElement listpageTxtAfterenteringreceipt;
	@FindBy(locator = "listpage.btn.addtolist")
	private QAFWebElement listpageBtnAddtolist;
	@FindBy(locator = "listpage.lbl.selectrowstodelete")
	private QAFWebElement listpageLblSelectrowstodelete;
	@FindBy(locator = "listpage.deletepopup.lbl.title")
	private QAFWebElement listpageLblDeleteitemtitlepopup;
	@FindBy(locator = "listpage.deletepopup.btn.ok")
	private QAFWebElement listpageBtnDeleteitempopupok;
	@FindBy(locator = "listpage.img.deleteicon")
	private QAFWebElement listpageImgDeleteicon;	
	@FindBy(locator = "listpage.btn.searchicon")
	private QAFWebElement btnSearchicon;
	@FindBy(locator = "listpage.lbl.hcitemcount")
	private QAFWebElement lblHcitemcount;
	
	@FindBy(locator = "listpage.btn.searchglass")
	private QAFWebElement btnsearchglass;
	
	

	

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public List<ListDetails> getListpageCellShoppingitem() {
		return listpageCellShoppingitem;
	}

	public QAFWebElement getListpageBtnEmail() {
		return listpageBtnEmail;
	}

	public QAFWebElement getListpageBtnMenuoverflow() {
		return listpageBtnMenuoverflow;
	}

	public QAFWebElement getListpageLblShoppingitemcount() {
		return listpageLblShoppingitemcount;
	}

	public QAFWebElement getListpageLblShoppingitemcheckoffcount() {
		return listpageLblShoppingitemcheckoffcount;
	}

	public QAFWebElement getListpageBtnCheckbox() {
		return listpageBtnCheckbox;
	}

	public QAFWebElement getListpageLblItemname() {
		return listpageLblItemname;
	}

	public QAFWebElement getListpageImgShoppinglistitemarrow() {
		return listpageImgShoppinglistitemarrow;
	}

	public QAFWebElement getListpageLinkCopytoanotherlist() {
		return listpageLinkCopytoanotherlist;
	}

	public QAFWebElement getListpageBtnCancel() {
		return listpageBtnCancel;
	}

	public QAFWebElement getListpageTxtShoppinglistquantity() {
		return listpageTxtShoppinglistquantity;
	}

	public QAFWebElement getListpageLinkDeleteitem() {
		return listpageLinkDeleteitem;
	}

	public QAFWebElement getListpageLinkDeleteallitem() {
		return listpageLinkDeleteallitem;
	}

	public QAFWebElement getListpageLinkUncheckitem() {
		return listpageLinkUncheckitem;
	}

	public QAFWebElement getListpageTxtSearch() {
		return listpageTxtSearch;
	}

	public QAFWebElement getListpageBtnCollapse() {
		return listpageBtnCollapse;
	}

	public QAFWebElement getListpageBtnScanmenu() {
		return listpageBtnScanmenu;
	}

	public QAFWebElement getListpageLblPagetitle() {
		return listpageLblPagetitle;
	}

	public QAFWebElement getListpageBtnMore() {
		return listpageBtnMore;
	}

	public QAFWebElement getListpageLblDeleteallitemoverlay() {
		return listpageLblDeleteallitemoverlay;
	}

	public QAFWebElement getListpageLblPopuptitledeleteallitem() {
		return listpageLblPopuptitledeleteallitem;
	}

	public QAFWebElement getListpageLblCheckedOff() {
		return listpageLblCheckedOff;
	}

	public List<ListDetails> getListpageLblItemNameListobj() {
		return listpageLblItemNameListobj;
	}

	public QAFWebElement getListpageTitleWishlistpage() {
		return listpageTitleWishlistpage;
	}

	public QAFWebElement getListpageTxtEnterrecieptnumber() {
		return listpageTxtEnterrecieptnumber;
	}

	public QAFWebElement getListpageLblRecieptmessage() {
		return listpageLblRecieptmessage;
	}

	public QAFWebElement getListpageLblEnterreceiptoverlay() {
		return listpageLblEnterreceiptoverlay;
	}

	public QAFWebElement getListpageImgEnterreciept() {
		return listpageImgEnterreciept;
	}

	public List<ListDetails> getListpageLinkScanproduct() {
		return listpageLinkScanproduct;
	}

	public QAFWebElement getListpageLinkScanreciept() {
		return listpageLinkScanreciept;
	}

	public QAFWebElement getListpageLinkEnterreciept() {
		return listpageLinkEnterreciept;
	}

	public QAFWebElement getListpageBtnAdd() {
		return listpageBtnAdd;
	}

	public QAFWebElement getListpageBtnSubmit() {
		return listpageBtnSubmit;
	}

	public QAFWebElement getListpageTxtAfterenteringreceipt() {
		return listpageTxtAfterenteringreceipt;
	}

	public List<ListDetails> getListpageLblItemNameList() {
		return listpageLblItemNameList;
	}

	public QAFWebElement getListpageBtnAddtolist() {
		return listpageBtnAddtolist;
	}

	public QAFWebElement getListpageLblItemnameByLable(int lable) {
		String loc = String.format(pageProps.getString("listpage.lbl.itemnamelist.dynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
	
	public QAFWebElement getListpageLblSelectrowstodelete() {
		return listpageLblSelectrowstodelete;
	}

	public QAFWebElement getListpageLblDeleteitemtitlepopup() {
		return listpageLblDeleteitemtitlepopup;
	}

	public QAFWebElement getListpageBtnDeleteitempopupok() {
		return listpageBtnDeleteitempopupok;
	}

	public QAFWebElement getListpageImgDeleteicon() {
		return listpageImgDeleteicon;
	}
	
	public QAFWebElement getBtnSearchicon() {
		return btnSearchicon;
	}
	
	public QAFWebElement getPageLinkScanproduct() {
		return pageLinkScanproduct;
	}
	
	public QAFWebElement getLblHcitemcount() {
		return lblHcitemcount;
	}
	public QAFWebElement getBtnsearchglass() {
		return btnsearchglass;
	}
}
