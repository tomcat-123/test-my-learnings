package com.heb.automation.common.components;

import com.heb.automation.common.pages.weeklyad.WeeklyaddealdetailTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class WeeklyadResult extends QAFWebComponent {

	@FindBy(locator = "weeklyadresult.lbl.dealname")
	private QAFWebElement weeklyadLblDealname;
	@FindBy(locator = "weeklyadresult.lbl.dealproductdate")
	private QAFWebElement weeklyadLblDealproductdate;
	@FindBy(locator = "weeklyadresult.img.dealproductimage")
	private QAFWebElement weeklyadImgDealproductimage;
	@FindBy(locator = "weeklyadresult.checkbox.selectdeal")
	private QAFWebElement weeklyadCheckboxSelectdeal;
	

	public WeeklyadResult(String locator) {
		super(locator);
	}

	public QAFWebElement getWeeklyadLblDealname() {
		return weeklyadLblDealname;
	}

	public QAFWebElement getWeeklyadLblDealproductdate() {
		return weeklyadLblDealproductdate;
	}

	public QAFWebElement getWeeklyadImgDealproductimage() {
		return weeklyadImgDealproductimage;
	}

	public QAFWebElement getWeeklyadCheckboxSelectdeal() {
		return weeklyadCheckboxSelectdeal;
	}

	public WeeklyaddealdetailTestPage select() {
		click();
		WeeklyaddealdetailTestPage WeeklyAddetailTestPage = new WeeklyaddealdetailTestPage();
		WeeklyAddetailTestPage.waitForPageToLoad();

		return WeeklyAddetailTestPage;
	}
	
}
