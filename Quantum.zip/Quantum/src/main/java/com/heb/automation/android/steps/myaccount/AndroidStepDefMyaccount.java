package com.heb.automation.android.steps.myaccount;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.android.steps.AndroidStepDef;
import com.heb.automation.android.steps.coupons.AndroidStepdefCoupons;
import com.heb.automation.android.steps.products.AndroidStepdefProducts;
import com.heb.automation.android.steps.storelocator.AndroidStepDefStoreLocator;
import com.heb.automation.common.InstallAppAndroid;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.StoreResult;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.coupons.CouponsselectionTestPage;
import com.heb.automation.common.pages.myaccount.ChangepasswordTestPage;
import com.heb.automation.common.pages.myaccount.MyaccountTestPage;
import com.heb.automation.common.pages.myaccount.MyhebbarcodeTestPage;
import com.heb.automation.common.pages.myaccount.MynotificationsTestPage;
import com.heb.automation.common.pages.myaccount.MyprofileTestPage;
import com.heb.automation.common.pages.registeration.ExtraOffersTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.pages.registeration.WantmoreTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.storelocator.StoredetailsTestPage;
import com.heb.automation.common.pages.storelocator.StorelistviewresultTestPage;
import com.heb.automation.common.pages.storelocator.StorelocatorTestPage;
import com.heb.automation.common.pages.storelocator.StoremapviewTestPage;
import com.heb.automation.common.steps.CommonSteps;
import com.heb.automation.common.steps.myaccount.CommonStepDefMyAccounts;
import com.heb.automation.common.steps.registeration.CommonStepDefRegisteration;
import com.heb.automation.common.steps.storelocator.CommonStepDefStoreLocator;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.heb.automation.ios.steps.IOSStepdef;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

import io.appium.java_client.android.AndroidDriver;

/*List of Steps in MyAccount
	
	I navigate to My Account page
	I update the Email, FirstName and LastName
	I verify the updated Email, FirstName and LastName
	I revert back the changes of Email, FirstName and LastName
	I update the Email Subscriptions
	I verify the updated Subscriptions
	I validate My Profile page by using invalid details
	I am a hot user user with new registration
	I do logout and login again
	I click on save button
	I validate the negative flow for change password
	I enter all required fields in registeration page
	I enter invalid phone number in offers page
	Enter the already enrolled Phone number in exptra offers page
	Enter the Previously un-enrolled Phone number in exptra offers page
	I validate error message for invalid mobile number
	I choose a store from the store locator page for store details
	I login with updated email
	I navigate to extra offers page and validate the fields
	Create another account and navigate to Extra offers page
	Enter all required fields in offers page with already enrolled phone num
	I enter all required fields in offers page
	Enter all required fields in Extra offers page
	I enter invalid password and validate error message
	I clear the mandatory field values and validate the error message
	I enter all required fields in Extra Offers page without Terms and Conditions
	I select a pharmacy store as my H-E-B store
	I select a non pharmacy store as my H-E-B store
	I verify pharmacy info is not displayed for non pharmacy store
	I navigate to app settings page
	I enter all required fields in registeration page with invalid input
	I logout the application from MyAccount page
	I enter all fields in change password page
	I update the first name in My profile page
	I try to update the fields in My Profile page
	I verify the changes have been cancelled in My Profile page
	by tapping anywhere/clicking device back button should dismiss the keyboard
	I navigate to My H-E-B page
	I validate map and List view on denying permission
	I see home screen on clicking device back button from pick a store page
	I validate sections in Myaccount/more page as a hotuser
	I validate options in Email notifications
	I validate all elements in Redeem Coupon page
	I see homepage/loginpage
	I enter invalid email in registeration page
	I validate weekly Ad switch is {0}
	I select store from My Store
	I verify the next button is available in keyboard
	I verify the Done button is available in keyboard
	I click on last name field
	I click on email field
	I enter all fields in change password page and cancel it
	I enter invalid password in registeration page
	I validate the updated options in Email notifications
	I navigate back to previously viewed page
	I validate default Email Preferences options
	I navigate to offers page
	I am a user with new installed app
	I navigate to My Account page by clicking Hi <UserName> in HomePage
	I validate My Notifications page elements
	I click on Rate this App option
	I see H-E-B app page in App Store
	I click on Contact Us option
	I see Contact Us page
	I update the email notification
	I Login with invalid password 5 times
	I verify login screen changed to Forgot Password screen
	I verify save button is disabled by default
	I enter valid phone number in offers page
	I verify save button is enabled after entering all details
	I register a new user enrolled with get extra offers
	I register new user with get extra offers with same phone number
	I enter all required fields in offers page with alredy registered phone number
	Verify the Done button is enabled by default
	I verify Redeem Coupons does not appear in the Left Nav menu
	I verify partner's name appears on the VPP Barcode screen
	I verify barcode appears at the bottom of the VPP Barcode screen
	I verify header image with the text on the VPP Barcode screen
	I verify Redeem Coupons does not appear on My Account page
	I verify Redeem button is not present in Selected Savings tab
	I verify error message on the Log In page
	I verify email field is displayed on the Forgot Password page
	I verify error message for invalid email id
	I verify Reset Password button becomes enabled after entering email
	I verify email has send after clicking Reset Password button
	I enter invalid email id and valid password
	I enter valid email id and invalid password
	I am a hot user user with new registration and enrolled for Coupons*/

public class AndroidStepDefMyaccount {

	/**
	 * Clicking on My Account option from APP-slider options on clicking
	 * hamburger button
	 * 
	 */
	@QAFTestStep(description = "I navigate to My Account page")
	public void iNavigateToMyAccountPage() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		androidcommon.getAppHamburger().waitForPresent(3000);
		androidcommon.getAppHamburger().click();
		boolean existFlag = androidcommon.getAppSliderMyAccount().verifyPresent();
		if (!existFlag) {
			PerfectoUtils.verticalswipe();
		}
		androidcommon.waitForPageToLoad();
		androidcommon.getAppSliderMyAccount().waitForPresent(3000);
		androidcommon.getAppSliderMyAccount().click();
	}

	/**
	 * Updating the Email, First name and Last name and clicking Save button
	 * 
	 */
	@QAFTestStep(description = "I update the Email, FirstName and LastName")
	public void iUpdateTheEmailFirstNameAndLastName() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		MyaccountTestPage myaccount = new MyaccountTestPage();
		RegistrastionTestPage register = new RegistrastionTestPage();
		MyprofileTestPage myprofile = new MyprofileTestPage();

		String strNewEmailId = "";
		String strNewFirstname = "";
		String strNewLastname = "";

		String strRegisterEmailId = register.getRegistrationTxtEmail().getText();
		String strRegisterFirstname = register.getRegistrationTxtFirstname().getText();
		String strregistrationLastname = register.getRegistrationTxtLastname().getText();

		getBundle().setProperty("strRegisterEmailId", strRegisterEmailId);
		getBundle().setProperty("strRegisterFirstname", strRegisterFirstname);
		getBundle().setProperty("strregistrationLastname", strregistrationLastname);

		// Getting the new Email ID to update
		if (strRegisterEmailId.contains("1")) {
			strNewEmailId = strRegisterEmailId.replaceAll("1", "");
		} else {
			strNewEmailId = strRegisterEmailId.replaceAll("@heb.com", "1@heb.com");
		}

		// Creating the new First name to update
		if (strRegisterFirstname.contains("1")) {
			strNewFirstname = strRegisterFirstname.replaceAll("1", "");
		} else {
			strNewFirstname = strRegisterFirstname + "1";
		}

		// Creating the new last name to update
		if (strregistrationLastname.contains("1")) {
			strNewLastname = strregistrationLastname.replaceAll("1", "");
		} else {
			strNewLastname = strregistrationLastname + "1";
		}

		getBundle().setProperty("NewEmailId", strNewEmailId);
		getBundle().setProperty("NewFirstname", strNewFirstname);
		getBundle().setProperty("NewLastname", strNewLastname);

		register.getRegistrationTxtEmail().click();
		register.getRegistrationTxtEmail().clear();
		register.getRegistrationTxtEmail().sendKeys(strNewEmailId);

		register.getRegistrationTxtFirstname().clear();
		register.getRegistrationTxtFirstname().sendKeys(strNewFirstname);

		register.getRegistrationTxtLastname().click();
		register.getRegistrationTxtLastname().clear();
		register.getRegistrationTxtLastname().sendKeys(strNewLastname);

		myprofile.getBtnSaveprofile().waitForPresent(3000);
		myprofile.getBtnSaveprofile().click();
		PerfectoUtils.reportMessage("Clicked on Save Profile button.", MessageTypes.Pass);

		// Click OK from the Warning pop-up
		if (weeklygrocery.getShopingListEntryByLable("Warning").isPresent()) {
			PerfectoUtils.reportMessage("Confirming for Email change", MessageTypes.Pass);

			if (myprofile.getBtnWarningok().isPresent()) {
				myprofile.getBtnWarningok().click();
				PerfectoUtils.reportMessage("Clicked on Ok button.", MessageTypes.Pass);
			}

			// Wait for the page to navigate to My account page
			myaccount.waitForPageToLoad();
			myaccount.getBtnMystore().waitForPresent(80000);
			myaccount.getBtnMystore().verifyPresent();
		}

		// Verifying, navigated back to my account page
		try {
			myaccount.waitForPageToLoad();
			myaccount.getBtnMystore().waitForPresent(5000);
		} catch (Exception e) {
			try {
				if (myprofile.getBtnSaveprofile().isPresent()) {
					myprofile.getBtnSaveprofile().click();
				}
				myaccount.getBtnMystore().waitForPresent(5000);
				myaccount.getBtnMystore().verifyPresent();
				PerfectoUtils.reportMessage("Email, First name and Last name are updated", MessageTypes.Pass);
			} catch (Exception e1) {
				PerfectoUtils.reportMessage("Error occured while updating the Email, First name and Last name.",
						MessageTypes.Fail);
			}
		}
	}

	/**
	 * Verifying the Updated Email, First name and last names are available in
	 * My Profile page
	 * 
	 */
	@QAFTestStep(description = "I verify the updated Email, FirstName and LastName")
	public void iVerifyTheUpdatedEmailFirstNameAndLastName() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		CommonStepDefMyAccounts myaccounts = new CommonStepDefMyAccounts();

		// Navigating back to My profile page
		PerfectoUtils.reportMessage("Navigating back to My Profile page..", MessageTypes.Info);
		myaccounts.iNavigateToMyProfilePage();

		String strNewEmailId = getBundle().getString("NewEmailId");
		String strNewFirstname = getBundle().getString("NewFirstname");
		String strNewLastname = getBundle().getString("NewLastname");

		// Checking whether the new Email ID has been updated
		if (register.getRegistrationTxtEmail().getText().equalsIgnoreCase(strNewEmailId)) {
			PerfectoUtils.reportMessage("Email Id has been changed to " + strNewEmailId, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Email Id has not been changed", MessageTypes.Fail);
		}

		// Checking whether the new First name has been updated
		if (register.getRegistrationTxtFirstname().getText().equalsIgnoreCase(strNewFirstname)) {
			PerfectoUtils.reportMessage("Firstname has been changed to " + strNewFirstname, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Firstname has not been changed", MessageTypes.Fail);
		}

		// Checking whether the new Last name has been updated
		if (register.getRegistrationTxtLastname().getText().equalsIgnoreCase(strNewLastname)) {
			PerfectoUtils.reportMessage("Lastname has been changed to " + strNewLastname, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Lastname has not been changed", MessageTypes.Fail);
		}
	}

	/**
	 * Reverting back the Email, first name and last name fields an clicking on
	 * Save button
	 * 
	 */
	@QAFTestStep(description = "I revert back the changes of Email, FirstName and LastName")
	public void iRevertBackTheChangesOfEmailFirstNameAndLastName() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		RegistrastionTestPage register = new RegistrastionTestPage();
		MyprofileTestPage myprofile = new MyprofileTestPage();
		MyaccountTestPage myaccount = new MyaccountTestPage();

		// Getting the new Unique Email ID, First name & Last name
		String strOldEmailId = getBundle().getString("strRegisterEmailId");
		String strOldFirstname = getBundle().getString("strRegisterFirstname");
		String strOldLastname = getBundle().getString("strregistrationLastname");

		register.getRegistrationTxtEmail().click();
		register.getRegistrationTxtEmail().clear();
		register.getRegistrationTxtEmail().sendKeys(strOldEmailId);

		register.getRegistrationTxtFirstname().clear();
		register.getRegistrationTxtFirstname().sendKeys(strOldFirstname);

		register.getRegistrationTxtLastname().clear();
		register.getRegistrationTxtLastname().sendKeys(strOldLastname);
		PerfectoUtils.reportMessage("Entered Email, FirstName and LastName", MessageTypes.Pass);

		myprofile.getBtnSaveprofile().waitForPresent(5000);
		myprofile.getBtnSaveprofile().verifyPresent();
		myprofile.getBtnSaveprofile().click();
		PerfectoUtils.reportMessage("Clicked Save profile button.", MessageTypes.Pass);

		// Click Ok from the Warning pop-up
		if (weeklygrocery.getShopingListEntryByLable("Warning").isPresent()) {
			PerfectoUtils.reportMessage("Confirming for Email change", MessageTypes.Pass);

			if (myprofile.getBtnWarningok().isPresent()) {
				myprofile.getBtnWarningok().click();
				PerfectoUtils.reportMessage("Clicked on Ok button.", MessageTypes.Pass);
			}
		}

		// Wait for the page to navigate to My account page
		myaccount.waitForPageToLoad();
		myaccount.getBtnMystore().waitForPresent(80000);
		myaccount.getBtnMystore().verifyPresent();
		PerfectoUtils.reportMessage("Email, First name and Last name are reverted", MessageTypes.Pass);
	}

	/**
	 * Updating the Email Subscriptions 1. Weekly Ads 2. Promotional 3. Monthly
	 * newsletter
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I update the Email Subscriptions")
	public void iUpdateTheEmailSubscriptions() throws Exception {
		MynotificationsTestPage mynotifipage = new MynotificationsTestPage();
		MyaccountTestPage myaccount = new MyaccountTestPage();
		AndroidStepDefStoreLocator storelocator = new AndroidStepDefStoreLocator();

		String chkWeeklyAd = null;
		String chkPromotional = null;
		String chkMonthlyNL = null;

		mynotifipage.getRbtWeeklyad().waitForPresent(3000);

		chkWeeklyAd = mynotifipage.getRbtWeeklyad().getAttribute("checked");

		// Checking whether the Weekly ad button is enabled
		if (chkWeeklyAd.equalsIgnoreCase("false")) {
			mynotifipage.getRbtWeeklyad().click();

			/* Select a Store */
			if (mynotifipage.getLblSelectastore().isPresent()) {
				mynotifipage.getBtnSelectastore().click();
				storelocator.iChooseAStoreFromTheStoreLocatorPage();
				PerfectoUtils.reportMessage("Subscription disabled for Weekly Ad", MessageTypes.Pass);
			}
			getBundle().setProperty("WeeklyAd_InitialStatus", "On");

		} else if (chkWeeklyAd.equalsIgnoreCase("true")) {

			mynotifipage.getRbtWeeklyad().click();
			getBundle().setProperty("WeeklyAd_InitialStatus", "Off");
			PerfectoUtils.reportMessage("Subscription enabled for Weekly Ad", MessageTypes.Pass);
		}

		if (!mynotifipage.getRbtPromotional().isPresent()) {
			PerfectoUtils.verticalswipe();
		}

		chkPromotional = mynotifipage.getRbtPromotional().getAttribute("checked");

		// Checking whether the Promotional button is enabled
		if (chkPromotional.endsWith("true")) {
			mynotifipage.getRbtPromotional().click();
			getBundle().setProperty("Promotional_InitialStatus", "Off");
			PerfectoUtils.reportMessage("Subscription disabled for Promotional", MessageTypes.Pass);
		} else if (chkPromotional.endsWith("false")) {
			mynotifipage.getRbtPromotional().click();
			getBundle().setProperty("Promotional_InitialStatus", "On");
			PerfectoUtils.reportMessage("Subscription enabled for Promotional", MessageTypes.Pass);
		}

		if (!mynotifipage.getRbtNewsletter().isPresent()) {
			PerfectoUtils.verticalswipe();
		}

		// Checking whether the Monthly Newsletter button is enabled
		chkMonthlyNL = mynotifipage.getRbtNewsletter().getAttribute("checked");

		if (chkMonthlyNL.equalsIgnoreCase("true")) {
			mynotifipage.getRbtNewsletter().click();
			PerfectoUtils.reportMessage("Subscription disabled for Monthly Newsletter", MessageTypes.Pass);
			getBundle().setProperty("MonthlyNewsletter_InitialStatus", "Off");
		} else if (chkMonthlyNL.equalsIgnoreCase("false")) {
			mynotifipage.getRbtNewsletter().click();
			getBundle().setProperty("MonthlyNewsletter_InitialStatus", "On");
			PerfectoUtils.reportMessage("Subscription enabled for Monthly Newsletter", MessageTypes.Pass);
		}

		// Navigate back to MyAccount Page
		PerfectoUtils.androiddeviceback();

		try {
			myaccount.getBtnMystore().waitForPresent(30000);
		} catch (Exception e) {
			try {
				myaccount.getBtnMystore().waitForPresent(10000);
				PerfectoUtils.reportMessage("Email subscriptions are updated.", MessageTypes.Pass);
			} catch (Exception e1) {
				PerfectoUtils.reportMessage("Error occured while updating the Email subscriptions.", MessageTypes.Fail);
			}
		}
	}

	/**
	 * Verifying the Updated Email Subscriptions are available 1. Weekly Ads 2.
	 * Promotional 3. Monthly newsletter
	 * 
	 */
	@QAFTestStep(description = "I verify the updated Subscriptions")
	public void iVerifyTheUpdatedSubscriptions() {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		MynotificationsTestPage mynotifipage = new MynotificationsTestPage();

		String chkWeeklyAd = null, chkPromotional = null, chkMonthlyNL = null;

		/* Navigating back to My profile page */
		myaccount.getLblMynotifications().waitForPresent(5000);
		myaccount.getLblMynotifications().click();
		PerfectoUtils.reportMessage("Clicked on My Notifications..");

		/* Verifying the status of Weekly Ad subscription */
		String strWeeklyAd_InitialStatus = getBundle().getString("WeeklyAd_InitialStatus");
		chkWeeklyAd = mynotifipage.getRbtWeeklyad().getAttribute("checked");

		if (strWeeklyAd_InitialStatus.equalsIgnoreCase("On")) {
			if (chkWeeklyAd.equalsIgnoreCase("true")) {
				PerfectoUtils.reportMessage("The Subscription has been disabled for Weekly Ad", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("The Subscription has not been disabled for Weekly Ad", MessageTypes.Fail);
			}
		} else if (strWeeklyAd_InitialStatus.equalsIgnoreCase("Off")) {
			if (chkWeeklyAd.equalsIgnoreCase("false")) {
				PerfectoUtils.reportMessage("The Subscription has been enabled for Weekly Ad", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("The Subscription has not been enabled for Weekly Ad", MessageTypes.Fail);
			}
		}

		/* Verifying the status of Promotional subscription */
		String strPromotional_InitialStatus = getBundle().getString("Promotional_InitialStatus");
		chkPromotional = mynotifipage.getRbtPromotional().getAttribute("checked");

		if (strPromotional_InitialStatus.equalsIgnoreCase("On")) {
			if (chkPromotional.equalsIgnoreCase("true")) {
				PerfectoUtils.reportMessage("The Subscription has been disabled for Promotional", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("The Subscription has not been disabled for Promotional",
						MessageTypes.Fail);
			}
		} else if (strPromotional_InitialStatus.equalsIgnoreCase("Off")) {
			if (chkPromotional.equalsIgnoreCase("false")) {
				PerfectoUtils.reportMessage("The Subscription has been enabled for Promotional", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("The Subscription has not been enabled for Promotional", MessageTypes.Fail);
			}
		}

		/* Verifying the status of Monthly Newsletter subscription */
		String strMonthlyNewsletter_InitialStatus = getBundle().getString("MonthlyNewsletter_InitialStatus");
		chkMonthlyNL = mynotifipage.getRbtNewsletter().getAttribute("checked");

		if (strMonthlyNewsletter_InitialStatus.equalsIgnoreCase("On")) {
			if (chkMonthlyNL.equalsIgnoreCase("true")) {
				PerfectoUtils.reportMessage("The Subscription has been disabled for Monthly Newsletter",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("The Subscription has not been disabled for Monthly Newsletter",
						MessageTypes.Fail);
			}
		} else if (strMonthlyNewsletter_InitialStatus.equalsIgnoreCase("Off")) {
			if (chkMonthlyNL.equalsIgnoreCase("false")) {
				PerfectoUtils.reportMessage("The Subscription has been enabled for Monthly Newsletter",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("The Subscription has not been enabled for Monthly Newsletter",
						MessageTypes.Fail);
			}
		}
	}

	/**
	 * Entering the Invalid inputs and Validating the error messages 1. First
	 * name 2. Last name 3. Email
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I validate My Profile page by using invalid details")
	public void iValidateMyProfilePageByUsingInvalidDetails() throws Exception {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		myprofile.getMyprofileTxtFirstname().click();

		checkingFieldsOnInvalidInput(myprofile.getMyprofileTxtFirstname(), myprofile.getBtnSaveprofile(), "56729##",
				"Please enter valid first name. (special character not accepted)");

		checkingFieldsOnInvalidInput(myprofile.getMyprofileTxtLastname(), myprofile.getBtnSaveprofile(), "12345##",
				"Please enter valid last name. (special character not accepted)");

		checkingFieldsOnInvalidInput(myprofile.getMyprofileTxtEmail(), myprofile.getBtnSaveprofile(), "Testing@hebcom",
				"Email is not valid");
	}

	public static void checkingFieldsOnInvalidInput(QAFWebElement ElementPropertyofEdit,
			QAFWebElement ElementPropertyDone, String inputValue, String expectedResult) {
		AndroidcommonTestPage appcommon = new AndroidcommonTestPage();

		clickkeyboardbut(ElementPropertyofEdit, "Delete");
		ElementPropertyofEdit.clear();
		ElementPropertyofEdit.sendKeys(inputValue);
		PerfectoUtils.hidekeyboard();
		ElementPropertyDone.click();
		if (appcommon.getAddtolistLblAlerttitle().isPresent()) {
			if ((appcommon.getAddtolistLblAlerttitle().getText()).equals("Warning")) {
				appcommon.getBtnLogin().click();
			}
		}
		CommonSteps.validaterrormessages(expectedResult, ElementPropertyDone);
		ElementPropertyofEdit.sendKeys("");
		ElementPropertyofEdit.sendKeys("Testing12");
	}

	/**
	 * Doing registration and navigating to the device home screen
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I am a hot user user with new registration")
	public void iAmAHotUserUserWithNewRegistration() throws Exception {
		CommonSteps commonsteps = new CommonSteps();
		AndroidStepDef androidstepdef = new AndroidStepDef();
		HomeTestPage homepage = new HomeTestPage();
		CommonStepDefRegisteration commonregister = new CommonStepDefRegisteration();

		// Prerequisite: verify the user is in login splash page
		androidstepdef.iAmOnLoginSplashPage();

		// Steps to register for a new user
		commonsteps.iClickRegisterButtonFromLoginSplashPage();

		iEnterAllRequiredFieldsInRegisterationPage();
		commonregister.iClickCreateAccount();

		// Skip select store
		CommonStepDefMyAccounts.iNavigateToWantMorePageOnClickingSkipForNow();

		// Click Done from want more page
		CommonStepDefMyAccounts.iClickDoneFromWantMorePage();

		// Verify registration is success and currently in home page
		homepage.getHomeLblWeeklyAd().waitForPresent(50000);
		homepage.getHomeLblWeeklyAd().verifyPresent();
	}

	/**
	 * Logging out and logging in again
	 * 
	 */
	@QAFTestStep(description = "I do logout and login again")
	public void iDoLogoutAndLoginAgain() {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		/* Clicking on logout */
		androidfun.getAppHamburger().waitForPresent(5000);
		androidfun.getAppHamburger().click();
		if (!androidfun.getAppSliderLogout().isPresent())
			PerfectoUtils.verticalswipe();

		androidfun.getAppSliderLogout().waitForPresent(3000);
		androidfun.getAppSliderLogout().click();
		PerfectoUtils.reportMessage("Clicked on Logout button..");
		loginsplash.waitForPageToLoad();

		/* Handle re-login pop up */
		if (appCrash.getReloginTitle().isPresent()) {
			PerfectoUtils.handleReloginPopup();
		}

		/* Logging in Again */
		String username = getBundle().getString("strRegisterEmailId");
		String pswd = getBundle().getString("strpassword1");

		loginsplash.getLoginTxtEmail().waitForPresent(5000);
		loginsplash.getLoginTxtEmail().sendKeys(username);
		loginsplash.getLoginTxtPassword().click();
		loginsplash.getLoginTxtPassword().sendKeys(pswd);
		PerfectoUtils.reportMessage("Entered Username and password.", MessageTypes.Pass);
		loginsplash.getLoginBtnLogin().click();
		PerfectoUtils.reportMessage("Clicked on Login button", MessageTypes.Pass);
	}

	/**
	 * Clicking on Save button from Change password screen
	 * 
	 */
	@QAFTestStep(description = "I click on save button")
	public void iClickOnSaveButton() {
		ChangepasswordTestPage changepswd = new ChangepasswordTestPage();

		changepswd.getChangepswdBtnSave().waitForPresent(3000);
		changepswd.getChangepswdBtnSave().click();
		PerfectoUtils.reportMessage("Clicked on Save button.");
	}

	/**
	 * Entering the invalid password value and validating the error message
	 * 
	 */
	@QAFTestStep(description = "I validate the negative flow for change password")
	public void iValidateTheChangePasswordPage() {
		ChangepasswordTestPage changepswd = new ChangepasswordTestPage();

		/* Validate the field with no inputs */
		changepswd.getChangepswdBtnSave().click();

		/* Validate old password */
		changepswd.getChangepswdTxtEnteroldpass().sendKeys("password10");

		/* Validate New Password */
		changepswd.getChangepswdTxtEnternewpass().sendKeys("password");
		changepswd.getChangepswdBtnSave().click();
		CommonSteps.validaterrormessages("Min 8 characters,1#", changepswd.getChangepswdBtnSave());

		/* Checking old password with wrong input */
		clearandentertext(changepswd.getChangepswdTxtEnteroldpass(), "automation");
		clearandentertext(changepswd.getChangepswdTxtEnternewpass(), "automation8");
		PerfectoUtils.hidekeyboard();
		changepswd.getChangepswdBtnSave().click();

		PerfectoUtils.androiddeviceback();
	}

	/**
	 * Entering all the required fields in registration page, including the
	 * checking of "I agree" option
	 * 
	 */
	@QAFTestStep(description = "I enter all required fields in registeration page")
	public void iEnterAllRequiredFieldsInRegisterationPage() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.launchPage(null);
		register.getRegistrationBean().fillRandomData();
		register.getRegistrationBean().setiAgree(true);
		PerfectoUtils.hidekeyboard();
		register.getRegistrationBean().fillUiElements();

		String strRegisterEmailId = register.getRegistrationTxtEmail().getText();
		String strRegisterFirstname = register.getRegistrationTxtFirstname().getText();
		String strregistrationLastname = register.getRegistrationTxtLastname().getText();

		getBundle().setProperty("strRegisterEmailId", strRegisterEmailId);
		getBundle().setProperty("strRegisterFirstname", strRegisterFirstname);
		getBundle().setProperty("strregistrationLastname", strregistrationLastname);

		PerfectoUtils.reportMessage("Required details are entered in registration page", MessageTypes.Pass);

		try {
			register.getRegistrationChkIagree().waitForPresent(5000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
			register.getRegistrationChkIagree().waitForPresent(5000);
		}

		if (register.getRegistrationChkIagree().getAttribute("checked").equals("false")) {
			register.getRegistrationChkIagree().click();
			PerfectoUtils.reportMessage("Clicked I Agree check box..");
		}
	}

	/**
	 * Enter Invalid mobile number and check "I agree" option
	 * 
	 */
	@QAFTestStep(description = "I enter invalid phone number in offers page")
	public void iEnterInvalidPhoneNumberInOffersPage() {
		ExtraOffersTestPage Extraoffers = new ExtraOffersTestPage();
		String mobileno = getBundle().getString("myaccount.details.invalidmobilenumber");
		String pinno = getBundle().getString("myaccount.details.Invalidpin");

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("false")) {
			Extraoffers.getEdtMobilenum().verifyPresent();
			Extraoffers.getEdtMobilenum().sendKeys(mobileno);
			PerfectoUtils.reportMessage("Entered Invalid phone number: " + mobileno);
			Extraoffers.getedt4digitpin().sendKeys(pinno);
			PerfectoUtils.reportMessage("Entered Invalid phone number: " + pinno);
			Extraoffers.getChkIagree().waitForPresent(3000);
			Extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked I agree checkbox..");
		} else {
			Extraoffers.getEdtMobilenum().verifyPresent();
			Extraoffers.getEdtMobilenum().sendKeys(mobileno);
			PerfectoUtils.reportMessage("Entered Invalid phone number: " + mobileno);
			Extraoffers.getChkIagree().waitForPresent(3000);
			Extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked I agree checkbox..");
		}

	}

	@QAFTestStep(description = "Enter the already enrolled Phone number in exptra offers page")
	public void enterTheAlreadyEnrolledPhoneNumberInExptraOffersPage() {
		ExtraOffersTestPage Extraoffers = new ExtraOffersTestPage();
		String mobileno = getBundle().getString("myaccount.details.coupons_alreadyenrolled");
		String pinno = getBundle().getString("myaccount.details.Invalidpin");

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("false")) {
			Extraoffers.getEdtMobilenum().verifyPresent();
			Extraoffers.getEdtMobilenum().sendKeys(mobileno);
			PerfectoUtils.reportMessage("Entered Invalid phone number: " + mobileno);
			Extraoffers.getedt4digitpin().sendKeys(pinno);
			PerfectoUtils.reportMessage("Entered Invalid phone number: " + pinno);
			Extraoffers.getChkIagree().waitForPresent(3000);
			Extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked I agree checkbox..");
		} else {
			Extraoffers.getEdtMobilenum().verifyPresent();
			Extraoffers.getEdtMobilenum().sendKeys(mobileno);
			PerfectoUtils.reportMessage("Entered Invalid phone number: " + mobileno);
			Extraoffers.getChkIagree().waitForPresent(3000);
			Extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked I agree checkbox..");
		}

	}

	@QAFTestStep(description = "Enter the Previously un-enrolled Phone number in exptra offers page")
	public void enterThePreviouslyUnEnrolledPhoneNumberInExptraOffersPage() {
		ExtraOffersTestPage Extraoffers = new ExtraOffersTestPage();
		String mobileno = getBundle().getString("myaccount.details.coupons_unenrolled");
		String pinno = getBundle().getString("myaccount.details.Invalidpin");

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("false")) {
			Extraoffers.getEdtMobilenum().verifyPresent();
			Extraoffers.getEdtMobilenum().sendKeys(mobileno);
			PerfectoUtils.reportMessage("Entered Invalid phone number: " + mobileno);
			Extraoffers.getedt4digitpin().sendKeys(pinno);
			PerfectoUtils.reportMessage("Entered Invalid phone number: " + pinno);
			Extraoffers.getChkIagree().waitForPresent(3000);
			Extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked I agree checkbox..");
		} else {
			Extraoffers.getEdtMobilenum().verifyPresent();
			Extraoffers.getEdtMobilenum().sendKeys(mobileno);
			PerfectoUtils.reportMessage("Entered Invalid phone number: " + mobileno);
			Extraoffers.getChkIagree().waitForPresent(3000);
			Extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked I agree checkbox..");
		}

	}

	/**
	 * Clicks Save button and Validates the Error message for the Invalid mobile
	 * number
	 * 
	 */
	@QAFTestStep(description = "I validate error message for invalid mobile number")
	public void iValidateErrorMessageForInvalidMobileNumber() {
		ExtraOffersTestPage Extraoffers = new ExtraOffersTestPage();

		PerfectoUtils.verticalswipe();
		Extraoffers.getBtnSave().verifyPresent();
		Extraoffers.getBtnSave().click();
		PerfectoUtils.reportMessage("Clicked Save button..");

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "SAVE");
		String isSavePresent = (String) Extraoffers.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
				params1);

		if (isSavePresent.equalsIgnoreCase("SAVE"))
			Extraoffers.getTestBase().getDriver().executeScript("mobile:text:select", params1);

		// Validate the Mobile Number
		PerfectoUtils.hidekeyboard();
		CommonSteps.validattextinpage("Must be in (XXX) XXX-XXXX form");
		// PerfectoUtils.androiddeviceback();
	}

	/**
	 * Choosing a store from the Store locator list view
	 * 
	 */
	@QAFTestStep(description = "I choose a store from the store locator page for store details")
	public void iChooseAStoreFromTheStoreLocatorPageForStoreDetails() {
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();

		// Handling the Allow pop up
		if (storepage.getStorelocatorTxtPopupmsg().isPresent()) {
			PerfectoUtils.reportMessage("Allow App to Access the device location popup found..", MessageTypes.Pass);
			storepage.getStorelocatorTxtPopupmsg().verifyPresent();
			storepage.getStorelocatorBtnAllow().click();
			PerfectoUtils.reportMessage("Clicked Allow button..");
		}

		AndroidStepDef.storelocatorErrorHandle();
		storepage.getStorelocatorImgListswitch().waitForPresent(5000);
		storepage.getStorelocatorImgListswitch().click();
		PerfectoUtils.reportMessage("Switching to listview..");
		storelistresult.launchPage(null);

		StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(0);
		getBundle().setProperty("StoreName", store.getStorelocatorLblStorename().getText());
		getBundle().setProperty("StoreAddressdetails", store.getStorelocatorLblStoreaddress().getText());
		getBundle().setProperty("StoreCity", store.getStorelocatorLblCityname().getText());
		PerfectoUtils.reportMessage("Store Name:" + store.getStorelocatorLblStorename().getText());
		store.click();
		PerfectoUtils.reportMessage("Selected Store: " + getBundle().getString("StoreName"));
	}

	public static void clickkeyboardbut(QAFWebElement webelement, String contentvalue) {
		RegistrastionTestPage register = new RegistrastionTestPage();

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", contentvalue);
		String isContentvalueVisible = (String) register.getTestBase().getDriver()
				.executeScript("mobile:checkpoint:text", params1);

		if (isContentvalueVisible.equalsIgnoreCase("true")) {
			Object result1 = register.getTestBase().getDriver().executeScript("mobile:text:select", params1);
		} else {
			webelement.clear();
		}
	}

	/**
	 * Clicks hamburger Icon, logging out and logging in again with the updated
	 * Email
	 * 
	 */
	@QAFTestStep(description = "I login with updated email")
	public void iLoginAgain() {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		// Clicking on logout
		androidfun.getAppHamburger().waitForPresent(3000);
		androidfun.getAppHamburger().click();
		PerfectoUtils.reportMessage("Clicked hamburger button..");

		try {
			androidfun.getAppSliderHome().waitForPresent(3000);
		} catch (Exception e) {
			if (!androidfun.getAppSliderHome().isPresent()) {
				androidfun.getAppHamburger().click();
			}
		}

		if (!androidfun.getAppSliderLogout().isPresent()) {
			PerfectoUtils.verticalswipe();
		}
		androidfun.getAppSliderLogout().waitForPresent(5000);
		androidfun.getAppSliderLogout().click();
		PerfectoUtils.reportMessage("Clicked Logout button..");
		loginsplash.waitForPageToLoad();

		// handle re-login pop up
		if (appCrash.getReloginTitle().isPresent()) {
			PerfectoUtils.handleReloginPopup();
		}

		// Login Again
		String username = getBundle().getString("NewEmailId");
		String pswd = getBundle().getString("hebhotuser.emailchangeuser.password");
		loginsplash.getLoginTxtEmail().waitForPresent(3000);
		loginsplash.getLoginTxtEmail().sendKeys(username);
		loginsplash.getLoginTxtPassword().click();
		loginsplash.getLoginTxtPassword().sendKeys(pswd);
		loginsplash.getLoginTxtEmail().waitForPresent(5000);
		loginsplash.getLoginBtnLogin().click();
		PerfectoUtils.reportMessage("Clicked Login button from Login splash page", MessageTypes.Pass);
	}

	/**
	 * Clicks Extra Offers and validating the fields
	 * 
	 */
	@QAFTestStep(description = "I navigate to extra offers page and validate the fields")
	public void iNavigateToExtraOffersPageAndValidateTheFields() {
		WantmoreTestPage wantmore = new WantmoreTestPage();
		ExtraOffersTestPage offerspage = new ExtraOffersTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			wantmore.getLblExtraOffers().click();
			PerfectoUtils.reportMessage("Clicked on Extra Offers label..", MessageTypes.Pass);
			offerspage.getLblPageHeader().waitForPresent(50000);
			offerspage.getEdtMobilenum().verifyPresent();
			offerspage.getChkIagree().verifyPresent();
			offerspage.getLblDigitcoupdesc().verifyPresent();
			offerspage.getBtnSave().verifyPresent();
		} else {
			offerspage.getLbldigitalcoupons().click();
			PerfectoUtils.reportMessage("Clicked on Digital Coupon ..");
		}
	}

	@QAFTestStep(description = "Create another account and navigate to Extra offers page")
	public void createAnotherAccountAndNavigateToExtraOffersPage() {
		CommonSteps commonsteps = new CommonSteps();
		CommonStepDefRegisteration commonregister = new CommonStepDefRegisteration();

		commonsteps.iClickRegisterButtonFromLoginSplashPage();
		iEnterAllRequiredFieldsInRegisterationPage();
		commonregister.iClickCreateAccount();
		CommonStepDefMyAccounts.iNavigateToWantMorePageOnClickingSkipForNow();
		CommonStepDefMyAccounts.navigateToExtraOffersPageFromWantMorePage();
	}

	@QAFTestStep(description = "Enter all required fields in offers page with already enrolled phone num")
	public void enterAllRequiredFieldsInOffersPageWithAlreadyEnrolledPhoneNum() {
		ExtraOffersTestPage extraoffers = new ExtraOffersTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		PerfectoUtils.reportMessage("Registering for Extra Offers", MessageTypes.Pass);

		// Getting the current time to form the unique Mobile number
		String strPhonenum = getBundle().getString("enrolledPhoneNumber");
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();

		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		String strpin = strTimeStmp.substring(8, 12);
		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			extraoffers.getEdtMobilenum().sendKeys(strPhonenum);
			PerfectoUtils.hidekeyboard();

			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");
		} else {
			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			extraoffers.getEdtMobilenum().sendKeys(strPhonenum);
			PerfectoUtils.hidekeyboard();

			extraoffers.getedt4digitpin().click();
			extraoffers.getedt4digitpin().sendKeys(strpin);
			PerfectoUtils.hidekeyboard();

			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");
		}
	}

	/**
	 * Entering All the required fields in Offers page and clicking save button
	 * 
	 */
	@QAFTestStep(description = "I enter all required fields in offers page")
	public void iEnterAllRequiredFieldsInOffersPage() {
		ExtraOffersTestPage extraoffers = new ExtraOffersTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		PerfectoUtils.reportMessage("Registering for Extra Offers", MessageTypes.Pass);

		// Getting the current time to form the unique Mobile number
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();

		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		String strPhonenum = "8" + strTimeStmp.substring(3, 12);
		String strpin = strTimeStmp.substring(8, 12);
		ConfigurationManager.getBundle().setProperty("enrolledPhoneNumber", strPhonenum);
		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			extraoffers.getEdtMobilenum().sendKeys(strPhonenum);
			PerfectoUtils.hidekeyboard();

			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");

			extraoffers.getBtnSave().waitForPresent(10000);
			extraoffers.getBtnSave().click();
			PerfectoUtils.reportMessage("Clicked on Save button..");

			androidcommon.getImgProgress().waitForNotPresent(50000);
		} else {
			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			extraoffers.getEdtMobilenum().sendKeys(strPhonenum);
			PerfectoUtils.hidekeyboard();

			extraoffers.getedt4digitpin().click();
			extraoffers.getedt4digitpin().sendKeys(strpin);
			PerfectoUtils.hidekeyboard();

			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");

			extraoffers.getBtnSave().waitForPresent(10000);
			extraoffers.getBtnSave().click();
			PerfectoUtils.reportMessage("Clicked on Save button..");

			androidcommon.getImgProgress().waitForNotPresent(50000);
		}
	}

	@QAFTestStep(description = "Enter all required fields in Extra offers page")
	public void enterAllRequiredFieldsInExtraOffersPage() {
		ExtraOffersTestPage extraoffers = new ExtraOffersTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		PerfectoUtils.reportMessage("Registering for Extra Offers", MessageTypes.Pass);

		// Getting the current time to form the unique Mobile number
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();

		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		String strPhonenum = "8" + strTimeStmp.substring(3, 12);
		String strpin = strTimeStmp.substring(8, 12);
		ConfigurationManager.getBundle().setProperty("enrolledPhoneNumber", strPhonenum);
		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			extraoffers.getEdtMobilenum().sendKeys(strPhonenum);
			PerfectoUtils.hidekeyboard();

			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");
		} else {
			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			extraoffers.getEdtMobilenum().sendKeys(strPhonenum);
			PerfectoUtils.hidekeyboard();

			extraoffers.getedt4digitpin().click();
			extraoffers.getedt4digitpin().sendKeys(strpin);
			PerfectoUtils.hidekeyboard();

			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");
		}
	}

	/**
	 * Entering Invalid password, clicking on Save button and validating the
	 * error message
	 * 
	 */
	@QAFTestStep(description = "I enter invalid password and validate error message")
	public void iEnterInvalidPasswordAndValidateErrorMessage() {
		ChangepasswordTestPage changepswd = new ChangepasswordTestPage();

		String strPswd = getBundle().getString("CurrentPassword");
		String strInvalidPswd1 = "test";
		String strErrorMsg = "Min 8 characters, 1#";

		changepswd.waitForPageToLoad();
		changepswd.getChangepswdTxtEnteroldpass().sendKeys(strPswd);
		changepswd.getChangepswdTxtEnternewpass().sendKeys(strInvalidPswd1);
		changepswd.getChangepswdBtnSave().click();
		PerfectoUtils.reportMessage("Clicked on Save button");

		// Validating the error message
		try {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", strErrorMsg);
			Object result1 = PerfectoUtils.getAppiumDriver().executeScript("mobile:text:find", params1);

			PerfectoUtils.reportMessage("Error message is populated for entering less than 8 characters as password!",
					MessageTypes.Pass);
		} catch (Exception e) {
			PerfectoUtils.reportMessage(
					"Error message is not populated for entering less than 8 characters as password!",
					MessageTypes.Fail);
		}

		PerfectoUtils.androiddeviceback();
	}

	/**
	 * Clearing the mandatory fields values, click on Save button and validate
	 * the error messages
	 * 
	 */
	@QAFTestStep(description = "I clear the mandatory field values and validate the error message")
	public void iClearTheMandatoryFieldValuesAndValidateTheErrorMessage() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		MyprofileTestPage myprofile = new MyprofileTestPage();

		String strErrorMsg = "Required Field";

		// Clearing mandatory fields
		register.getRegistrationTxtFirstname().click();
		clickkeyboardbut(register.getRegistrationTxtFirstname(), "Delete");
		register.getRegistrationTxtLastname().click();
		clickkeyboardbut(register.getRegistrationTxtLastname(), "Delete");
		register.getRegistrationTxtEmail().click();
		clickkeyboardbut(register.getRegistrationTxtEmail(), "Delete");
		PerfectoUtils.reportMessage("Cleared Mandatory fields");
		myprofile.getBtnSaveprofile().waitForPresent(3000);
		myprofile.getBtnSaveprofile().click();
		PerfectoUtils.reportMessage("Clicked on Save button");

		// Validate error message
		try {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", strErrorMsg);
			String result1 = (String) PerfectoUtils.getAppiumDriver().executeScript("mobile:text:find", params1);

			if (result1.equalsIgnoreCase("true")) {
				PerfectoUtils.reportMessage(
						"Error message " + strErrorMsg + "is displayed for not entering mandatory fields!",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage(
						"Error message " + strErrorMsg + "is not displayed for not entering mandatory fields!",
						MessageTypes.Fail);
			}
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured while validating the error message.", MessageTypes.Fail);
		}

		PerfectoUtils.androiddeviceback();
		PerfectoUtils.androiddeviceback();
	}

	/**
	 * Clicking on Save button without checking the "Terms and conditions" and
	 * validating the error message
	 * 
	 */
	@QAFTestStep(description = "I enter all required fields in Extra Offers page without Terms and Conditions")
	public void iEnterAllRequiredFieldsInExtraOffersPageWithoutTermsAndConditions() {
		ExtraOffersTestPage offers = new ExtraOffersTestPage();
		String mobileno = getBundle().getString("myaccount.details.phonenum");

		// Enter required fields
		offers.getEdtMobilenum().sendKeys(mobileno);
		offers.getBtnSave().click();
		PerfectoUtils.reportMessage("Clicked on Save button");

		if ((offers.getBtnSave().getAttribute("enabled")).equals("false")) {
			PerfectoUtils.reportMessage("Error:Please check Terms and Conditions", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Registered for Digital Coupons without phone number and pin",
					MessageTypes.Fail);
		}
	}

	/**
	 * Navigating to list view page, clicks on Refine option, Checks pharmacy
	 * option and clicking on "Done" button 2. Then selecting any of the store
	 * from the list view
	 * 
	 */
	@QAFTestStep(description = "I select a pharmacy store as my H-E-B store")
	public void iSelectAPharmacyStoreAsMyHEBStore() {
		CommonStepDefStoreLocator commonstepdefstore = new CommonStepDefStoreLocator();
		AndroidStepDefStoreLocator androidstepdefstore = new AndroidStepDefStoreLocator();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();

		AndroidStepDefStoreLocator.iNavigateToListViewPage();
		commonstepdefstore.iSelectRefineButton();
		androidstepdefstore.iClickOnDoneApplyButtonAfterSelectingStores();

		/* Select store from list view */
		StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(0);
		getBundle().setProperty("StoreName", store.getStorelocatorLblStorename().getText());
		PerfectoUtils.reportMessage("Store Name:" + store.getStorelocatorLblStorename().getText());
		store.click();
		PerfectoUtils.reportMessage("Selected Store: " + getBundle().getString("StoreName"));
	}

	/**
	 * Searching with Non-pharmacy zip code and selecting a store from the
	 * result
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I select a non pharmacy store as my H-E-B store")
	public void iSelectANonPharmacyStoreAsMyHEBStore() throws InterruptedException {
		AndroidStepDefStoreLocator androidstepdefstore = new AndroidStepDefStoreLocator();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		AndroidStepdefProducts androidstepdef = new AndroidStepdefProducts();

		String strNonPharmStoreName = getBundle().getString("storelocator.NonPharmacyStore");
		String intZipCode = getBundle().getString("storelocator.NonPharmacyStoreZip");

		AndroidStepDefStoreLocator.iNavigateToListViewPage();
		androidstepdefstore.iSeeSearchFieldIsDisplayedByClickingOnSearchIconInMapViewOfStorelocator();
		androidstepdef.iEnterValidSearchTermAndSelectSearchButton(intZipCode);

		// Select store from list view
		StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(0);
		String strStoreName = store.getStorelocatorLblStorename().getText();
		getBundle().setProperty("StoreName", strStoreName);
		PerfectoUtils.reportMessage("Store Name:" + strStoreName);

		if (strStoreName.equalsIgnoreCase(strNonPharmStoreName)) {
			PerfectoUtils.reportMessage("Non-Pharmacy store selected: " + strStoreName, MessageTypes.Pass);
			store.click();
		} else {
			PerfectoUtils.reportMessage("Store is not a non pharmacy store: " + strStoreName, MessageTypes.Fail);
		}
	}

	/**
	 * Verifying the Pharmacy info is not present for the non-Pharmacy stores 1.
	 * Pharmacy label 2. Pharmacy Phone number
	 * 
	 */
	@QAFTestStep(description = "I verify pharmacy info is not displayed for non pharmacy store")
	public void iVerifyPharmacyInfoIsNotDisplayedForNonPharmacyStore() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();

		storedetail.waitForPageToLoad();
		PerfectoUtils.verticalswipe();
		storedetail.getStoreDetailsLblPharmacy().waitForNotPresent(5000);
		storedetail.getStoreDetailsLblPharmacy().verifyNotPresent();
		storedetail.getStoredetailsLnkPharmacyphonenumber().verifyNotPresent();
	}

	/**
	 * Clicks hamburger button and navigating to App settings page
	 * 
	 */
	@QAFTestStep(description = "I navigate to app settings page")
	public void iNavigateToAppSettingsPage() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		androidcommon.waitForPageToLoad();
		androidcommon.getAppHamburger().click();
		PerfectoUtils.reportMessage("Clicked on Hamburger button");
		PerfectoUtils.verticalswipe();
		androidcommon.getAppSliderAppSettings().click();
		PerfectoUtils.reportMessage("Clicked on App Settings..");
	}

	/**
	 * Entering the mandatory fields in registration page with the invalid
	 * inputs and validate the error messages
	 * 
	 */
	@QAFTestStep(description = "I enter all required fields in registeration page with invalid input")
	public void iEnterAllRequiredFieldsInRegisterationPageWithInvalidInput() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		/* Checking the Error Messages in Registration Page */
		clickSubmit();

		/* Validate FirstName */
		CommonSteps.validaterrormessages("Required Field", register.getRegistrationBtnSubmit());
		register.getRegistrationTxtFirstname().sendKeys("01234");

		/* Validate LastName */
		clickSubmit();
		CommonSteps.validaterrormessages("Required Field", register.getRegistrationBtnSubmit());
		register.getRegistrationTxtLastname().sendKeys("56789");

		/* Validate Email */
		clickSubmit();
		CommonSteps.validaterrormessages("Required Field", register.getRegistrationBtnSubmit());
		register.getRegistrationTxtEmail().sendKeys("Test@heb.com");

		/* Validate Password */
		clickSubmit();
		CommonSteps.validaterrormessages("Required Field", register.getRegistrationBtnSubmit());
		register.getRegistrationTxtPassword().sendKeys("Test@1");

		/* Validate Invalid Error on Invalid password */
		PerfectoUtils.hidekeyboard();
		clickSubmit();
		CommonSteps.validaterrormessages("Min 8 characters,1#", register.getRegistrationBtnSubmit());
		register.getRegistrationTxtPassword().clear();
		register.getRegistrationTxtPassword().sendKeys("Test@123");

	}

	public void clickSubmit() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		PerfectoUtils.hidekeyboard();
		PerfectoUtils.verticalswipe();
		register.getRegistrationBtnSubmit().click();
		PerfectoUtils.reportMessage("Clicked on Submit button..");
		PerfectoUtils.horizontalswipe();
		PerfectoUtils.horizontalswipe();
	}

	public void clearandentertext(QAFWebElement qafWebElement, String input) {

		qafWebElement.clear();
		qafWebElement.sendKeys(input);
	}

	/**
	 * Clicking on Logout option from My Account page
	 * 
	 */
	@QAFTestStep(description = "I logout the application from MyAccount page")
	public void iLogoutTheApplicationFromMyAccountPage() {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		myaccount.getBtnLogout().waitForPresent(5000);
		myaccount.getBtnLogout().click();
		PerfectoUtils.reportMessage("Clicked Log Out button.", MessageTypes.Pass);

		// Handling the Re-login Pop-up, if present
		if (appCrash.getReloginTitle().isPresent()) {
			PerfectoUtils.handleReloginPopup();
		}
	}

	/**
	 * Entering the required fields in Change password page
	 * 
	 */
	@QAFTestStep(description = "I enter all fields in change password page")
	public void iEnterAllFieldsInChangePasswordPage() {
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		ChangepasswordTestPage changepswd = new ChangepasswordTestPage();

		String newpswd = getBundle().getString("myaccount.changepassword.password");
		String oldpswd = getBundle().getString("strpassword1");

		changepswd.waitForPageToLoad();
		changepswd.getChangepswdTxtEnteroldpass().waitForPresent(3000);
		changepswd.getChangepswdTxtEnteroldpass().sendKeys(oldpswd);

		changepswd.getChangepswdTxtEnternewpass().click();
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(newpswd);

		getBundle().setProperty("strpassword1", newpswd);

		/* Clicking on Cancel button in Login required pop-up */
		if (appcrash.getExceptionTxtLoginrequired().isPresent()) {
			appcrash.getExceptionBtnCancel().click();
			PerfectoUtils.reportMessage("Unable to change password Login required popup appeared..");
		}
	}

	/**
	 * Updating the First name fields from My Profile page
	 * 
	 */
	@QAFTestStep(description = "I update the first name in My profile page")
	public void iUpdateTheFirstNameInMyProfilePage() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		myprofile.getMyprofileTxtFirstname().verifyPresent();
		String fname = myprofile.getMyprofileTxtFirstname().getText();

		String randomName = PerfectoUtils.randomName();
		randomName = randomName.substring(0, randomName.indexOf("-"));
		myprofile.getMyprofileTxtFirstname().click();
		myprofile.getMyprofileTxtFirstname().clear();
		myprofile.getMyprofileTxtFirstname().sendKeys(randomName);
		PerfectoUtils.reportMessage("First Name id updated from: " + fname + " to: " + randomName, MessageTypes.Pass);
		PerfectoUtils.hidekeyboard();
	}

	/**
	 * Trying to Update the fields in My profile page 1. Email 2. First name 3.
	 * last name without clicking the save button
	 * 
	 */
	@QAFTestStep(description = "I try to update the fields in My Profile page")
	public void iTryToUpdateTheFieldsInMyProfilePage() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		String strNewEmailId = "";
		String strNewFirstname = "";
		String strNewLastname = "";

		String strRegisterEmailId = register.getRegistrationTxtEmail().getText();
		String strRegisterFirstname = register.getRegistrationTxtFirstname().getText();
		String strregistrationLastname = register.getRegistrationTxtLastname().getText();

		getBundle().setProperty("strRegisterEmailId", strRegisterEmailId);
		getBundle().setProperty("strRegisterFirstname", strRegisterFirstname);
		getBundle().setProperty("strregistrationLastname", strregistrationLastname);

		/* Getting the new Email ID to update */
		if (strRegisterEmailId.contains("1")) {
			strNewEmailId = strRegisterEmailId.replaceAll("1", "");
		} else {
			strNewEmailId = strRegisterEmailId.replaceAll("@heb.com", "1@heb.com");
		}

		/* Creating the new First name to update */
		if (strRegisterFirstname.contains("1")) {
			strNewFirstname = strRegisterFirstname.replaceAll("1", "");
		} else {
			strNewFirstname = strRegisterFirstname + "1";
		}

		/* Creating the new last name to update */
		if (strregistrationLastname.contains("1")) {
			strNewLastname = strregistrationLastname.replaceAll("1", "");
		} else {
			strNewLastname = strregistrationLastname + "1";
		}

		register.getRegistrationTxtEmail().clear();
		register.getRegistrationTxtEmail().sendKeys(strNewEmailId);

		register.getRegistrationTxtFirstname().clear();
		register.getRegistrationTxtFirstname().sendKeys(strNewFirstname);

		register.getRegistrationTxtLastname().clear();
		register.getRegistrationTxtLastname().sendKeys(strNewLastname);

		PerfectoUtils.hidekeyboard();
	}

	/**
	 * Verifying the values remain unchanged in My Profile page
	 * 
	 */
	@QAFTestStep(description = "I verify the changes have been cancelled in My Profile page")
	public void iVerifyTheChangesHaveBeenCancelledInMyProfilePage() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		CommonStepDefMyAccounts commonsteps = new CommonStepDefMyAccounts();

		commonsteps.iNavigateToMyProfilePage();
		String strExpectedEmailId = getBundle().getString("strRegisterEmailId");
		String strExpectedFirstname = getBundle().getString("strRegisterFirstname");
		String strExpectedLastname = getBundle().getString("strregistrationLastname");

		String strActualEmailId = register.getRegistrationTxtEmail().getText();
		String strActualFirstname = register.getRegistrationTxtFirstname().getText();
		String strActualLastname = register.getRegistrationTxtLastname().getText();

		if (strActualEmailId.equals(strExpectedEmailId) && strActualFirstname.equals(strExpectedFirstname)
				&& strActualLastname.equals(strExpectedLastname)) {
			PerfectoUtils.reportMessage("Changes are cancelled and Same values remain in Fields", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Changes are not cancelled and Same values are not remained in Fields",
					MessageTypes.Fail);
		}
	}

	/**
	 * Hiding the keyboard by clicking the device back button
	 * 
	 */
	@QAFTestStep(description = "by tapping anywhere/clicking device back button should dismiss the keyboard")
	public void byTappingAnywhereClickingDeviceBackButtonShouldDismissTheKeyboard() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		PerfectoUtils.androiddeviceback();

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");
		String isBtnDoneVisible = (String) register.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
				params1);
		params1.put("content", "Next");
		String isBtnNextVisible = (String) register.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
				params1);

		if (isBtnDoneVisible.equalsIgnoreCase("false") && isBtnNextVisible.equalsIgnoreCase("false")) {
			PerfectoUtils.reportMessage("Keyboard is getting closed on clicking Done button as expected.",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Keyboard is not getting closed on clicking Done button", MessageTypes.Fail);
		}
	}

	/**
	 * Navigating to My HEB page
	 * 
	 */
	@QAFTestStep(description = "I navigate to My H-E-B page")
	public void iNavigateToMyHEBPage() {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		AndroidStepDefStoreLocator storelocator = new AndroidStepDefStoreLocator();

		myaccount.getLblSelectstore().verifyPresent();
		try {
			if ((myaccount.getLblSelectstore().getText()).equals("Select a Store")) {
				myaccount.getLblSelectstore().click();
				storelocator.iChooseAStoreFromTheStoreLocatorPage();
			}
			PerfectoUtils.reportMessage("Store name is displaying as" + (myaccount.getLblSelectstore().getText()),
					MessageTypes.Pass);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Store name is not displayed", MessageTypes.Fail);
		}
		myaccount.getLblSelectstore().click();
		PerfectoUtils.reportMessage("Clicked on My H-E-B.", MessageTypes.Pass);

	}

	/**
	 * Denying the Allow location access pop up and validating the store details
	 * are not available in Map view and List view in Store locator
	 * 
	 */
	@QAFTestStep(description = "I validate map and List view on denying permission")
	public void iValidateMapAndListViewOnDenyingPermission() {
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		StoremapviewTestPage mapview = new StoremapviewTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();

		/* Click on Deny in location access pop up */
		if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
			PerfectoUtils.reportMessage("H-E-B to access device location Pop up", MessageTypes.Pass);
			storelocator.getStorelocatorBtnDeny().click();
			PerfectoUtils.reportMessage("Clicked Deny button.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("H-E-B to access device location Pop up is not displayed", MessageTypes.Fail);
		}

		/* Validating map view is not loaded with stores */
		storelocator.getStorelocatorLblRefine().verifyPresent();
		mapview.getStorelocatorMapSelectstore().verifyNotPresent();

		/* Navigate to list view and validate stores are not displayed */
		storelocator.getStorelocatorImgListswitch().click();
		int results = storelistresult.getStorelocatorLblStoreresults().size();

		if (results == 0) {
			PerfectoUtils.reportMessage("No Stores are displaying in List View", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Stores are displaying in List View", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking device back button and verify navigated to home screen
	 * 
	 */

	@QAFTestStep(description = "I see home screen on clicking device back button from pick a store page")
	public void iSeeHomeScreenOnClickingDeviceBackButtonFromPickAStorePage() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		HomeTestPage homepage = new HomeTestPage();
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getLblPickstore().waitForPresent();
		register.getLblPickstore().verifyPresent();

		/* Clicking device back button */
		PerfectoUtils.androiddeviceback();
		androidcommon.getAppHamburger().waitForPresent(3000);
		homepage.getHomeLblProduct().verifyPresent();
	}

	/**
	 * Validating the fields in My Account page as a hot user
	 * 
	 */
	@QAFTestStep(description = "I validate sections in Myaccount/more page as a hotuser")
	public void iValidateSectionsInMyaccountMorePageAsAHotuser() {
		MyaccountTestPage myaccount = new MyaccountTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			myaccount.getBtnMyprofile().verifyPresent();
			myaccount.getLblMyhebbarcode().verifyPresent(); // Redeem Coupons
			myaccount.getLblMynotifications().verifyPresent();
			myaccount.getBtnMystore().verifyPresent();
			myaccount.getLblSelectstore().verifyPresent();
			myaccount.getBtnLogout().verifyPresent();
		} else {
			myaccount.getBtnMyprofile().verifyPresent();
			myaccount.getLblMynotifications().verifyPresent();
			myaccount.getBtnMystore().verifyPresent();
			myaccount.getLblSelectstore().verifyPresent();
			myaccount.getBtnLogout().verifyPresent();
		}
	}

	/**
	 * Selecting the toggle switch of all the Email notification options 1.
	 * Weekly ads 2. Promotional 3. Monthly newsletter and click on "Done"
	 * button
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I validate options in Email notifications")
	public void iValidateOptionsInEmailNotifications() throws Exception {
		WantmoreTestPage wantmore = new WantmoreTestPage();
		MynotificationsTestPage mynotification = new MynotificationsTestPage();
		AndroidStepDefStoreLocator storelocator = new AndroidStepDefStoreLocator();

		wantmore.getLblEmainotification().verifyPresent();

		/* Switching Weekly ad button */
		wantmore.getWeeklyadSwitch().click();

		/* Select a Store */
		if (mynotification.getLblSelectastore().isPresent()) {
			PerfectoUtils.reportMessage("Select a store pop up is displayed", MessageTypes.Pass);
			mynotification.getBtnSelectastore().click();
			storelocator.iChooseAStoreFromTheStoreLocatorPage();
		} else {
			PerfectoUtils.reportMessage("Select a store pop up is not displayed", MessageTypes.Fail);
		}

		PerfectoUtils.reportMessage("Modified Subscription for Weekly Ad", MessageTypes.Pass);
		getBundle().setProperty("WeeklyAd", wantmore.getWeeklyadSwitch().getAttribute("checked"));

		/* Switching Promotional button */
		PerfectoUtils.verticalswipe();
		wantmore.getPromotionalSwitch().click();
		getBundle().setProperty("Promotional", wantmore.getPromotionalSwitch().getAttribute("checked"));

		/* Switching Newsletter button */
		wantmore.getNewsletterSwitch().click();
		getBundle().setProperty("Newsletter", wantmore.getNewsletterSwitch().getAttribute("checked"));

		CommonStepDefMyAccounts.iClickDoneFromWantMorePage();
	}

	/**
	 * Validating the fields from My HEB bar code page
	 * 
	 */
	@QAFTestStep(description = "I validate all elements in Redeem Coupon page")
	public void iValidateAllElementsInMyHEBBarcodePage() {
		MyhebbarcodeTestPage myhebbarcode = new MyhebbarcodeTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			// myhebbarcode.getLblPagetitle().verifyPresent(); // HEB Logo
			myhebbarcode.getLblBarcodephototext().verifyPresent(); // Text: Scan
																	// this
																	// barcode
																	// in store
																	// to redeem
																	// your
																	// coupons
			myhebbarcode.getLblNamelabel().verifyPresent();
			myhebbarcode.getLblNamevalue().verifyPresent();
			myhebbarcode.getImgBarcode().verifyPresent();
			myhebbarcode.getLblBarcodenumber().verifyPresent();
			PerfectoUtils.androiddeviceback();
		} else {
			PerfectoUtils.reportMessage("Redeem Coupon section is not present", MessageTypes.Pass);
		}
	}

	/**
	 * Verifying navigated to login page 1. Checks continue without register
	 * option is present
	 * 
	 */
	@QAFTestStep(description = "I see homepage/loginpage")
	public void iSeeHomepageLoginpage() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		loginsplash.getLoginLblContinue().waitForPresent(5000);
		loginsplash.getLoginLblContinue().verifyPresent();
	}

	/**
	 * Entering the Invalid Email in registration fields. and valid details in
	 * other fields
	 * 
	 */
	@QAFTestStep(description = "I enter invalid email in registeration page")
	public void iEnterInvalidEmailInRegisterationPage() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.launchPage(null);

		String strRegisterEmailId = getBundle().getString("registration.invalidemailaddress1");

		register.getRegistrationTxtEmail().click();
		register.getRegistrationTxtEmail().sendKeys(strRegisterEmailId);

		register.getRegistrationTxtFirstname().click();
		register.getRegistrationTxtFirstname().sendKeys(getBundle().getString("registration.FirstName"));

		register.getRegistrationTxtLastname().click();
		register.getRegistrationTxtLastname().sendKeys(getBundle().getString("registration.LastName"));

		register.getRegistrationTxtPassword().click();
		register.getRegistrationTxtPassword().sendKeys(getBundle().getString("registration.Password"));

		PerfectoUtils.reportMessage("Required details are entered in registration page", MessageTypes.Pass);
		try {
			register.getRegistrationChkIagree().waitForPresent(5000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
			register.getRegistrationChkIagree().waitForPresent(5000);
		}

		if (register.getRegistrationChkIagree().getAttribute("checked").equals("false")) {
			register.getRegistrationChkIagree().click();
		}
	}

	/**
	 * Validating the Weekly Ad switch value is set to true after selecting the
	 * store from the pop up
	 * 
	 * @param str1
	 */
	@QAFTestStep(description = "I validate weekly Ad switch is {0}")
	public void iValidateWeeklyAdSwitchIs(String str1) {
		WantmoreTestPage wantmore = new WantmoreTestPage();

		if (str1.equalsIgnoreCase("ON")) {
			str1 = "true";
		} else if (str1.equalsIgnoreCase("OFF")) {
			str1 = "false";
		}

		wantmore.getWeeklyadSwitch().waitForPresent(5000);
		PerfectoUtils.horizontalswipe();
		String statusWeeklyAdToggle = wantmore.getWeeklyadSwitch().getAttribute("checked");

		/* Verify whether the Weekly Ad toggle switch is ON */
		if (statusWeeklyAdToggle.equalsIgnoreCase(str1)) {
			PerfectoUtils.reportMessage("Weekly Ad Email Preference is set to " + str1 + " after selecting store",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Weekly Ad Email Preference is not set to " + str1 + " after selecting store",
					MessageTypes.Fail);
		}
	}

	/**
	 * selecting a store from My HEB Page
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I select store from My Store")
	public void iSelectStoreFromMyStore() throws Exception {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		AndroidStepDefStoreLocator storelocator = new AndroidStepDefStoreLocator();

		myaccount.getLblSelectstore().verifyPresent();
		myaccount.getLblSelectstore().click();
		storelocator.iChooseAStoreFromTheStoreLocatorPage();
		PerfectoUtils.reportMessage("Store name is selected as" + (myaccount.getLblSelectstore().getText()),
				MessageTypes.Pass);
	}

	/**
	 * Verifying the next button is available in the Keyboard
	 * 
	 */
	@QAFTestStep(description = "I verify the next button is available in keyboard")
	public void iVerifyTheNextButtonIsAvailableInKeyboard() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Next");
		params1.put("timeout", "20");
		String isBtnNextVisible1 = (String) myprofile.getTestBase().getDriver().executeScript("mobile:text:find",
				params1);

		if (isBtnNextVisible1.equalsIgnoreCase("false")) {
			Map<String, Object> params2 = new HashMap<>();
			params2.put("content", "Next");
			params2.put("timeout", "20");
			params2.put("profile", "DocumentConversion_Speed");
			params2.put("analysis", "manual");
			params2.put("inverse", "yes");
			params2.put("screen.top", "69%");
			params2.put("screen.height", "31%");
			params2.put("screen.left", "51%");
			params2.put("screen.width", "49%");
			isBtnNextVisible1 = (String) myprofile.getTestBase().getDriver().executeScript("mobile:text:find", params2);

		}

		if (isBtnNextVisible1.equalsIgnoreCase("true")) {
			PerfectoUtils.reportMessage("Next button is available in the Keyboard as expected.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Next button is not available in the Keyboard.", MessageTypes.Fail);
		}
		PerfectoUtils.androiddeviceback();
	}

	/**
	 * Verifying the Done button is available in the Keyboard
	 * 
	 */
	@QAFTestStep(description = "I verify the Done button is available in keyboard")
	public void iVerifyTheDoneButtonIsAvailableInKeyboard() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");
		String isBtnDoneVisible1 = (String) myprofile.getTestBase().getDriver().executeScript("mobile:text:find",
				params1);

		if (isBtnDoneVisible1.equalsIgnoreCase("false")) {
			Map<String, Object> params2 = new HashMap<>();
			params2.put("content", "Done");
			params2.put("profile", "DocumentConversion_Speed");
			params2.put("analysis", "manual");
			params2.put("inverse", "yes");
			params2.put("screen.top", "69%");
			params2.put("screen.height", "31%");
			params2.put("screen.left", "51%");
			params2.put("screen.width", "49%");
			isBtnDoneVisible1 = (String) myprofile.getTestBase().getDriver().executeScript("mobile:text:find", params2);

		}

		if (isBtnDoneVisible1.equalsIgnoreCase("true")) {
			PerfectoUtils.reportMessage("Done button is available in the Keyboard as expected.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Done button is not available in the Keyboard.", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking on last name field
	 * 
	 */
	@QAFTestStep(description = "I click on last name field")
	public void iClickOnLastNameField() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getRegistrationTxtLastname().waitForPresent(3000);
		register.getRegistrationTxtLastname().click();
		PerfectoUtils.reportMessage("CLicked on Last name field");

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Delete");
		String isBtnDoneVisible = (String) register.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
				params1);
		if (isBtnDoneVisible.equalsIgnoreCase("true")) {
			register.getTestBase().getDriver().executeScript("mobile:text:select");
		}
	}

	/**
	 * Clicking on Email field
	 *
	 */
	@QAFTestStep(description = "I click on email field")
	public void iClickOnEmailField() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getRegistrationTxtEmail().waitForPresent(3000);
		register.getRegistrationTxtEmail().click();
		PerfectoUtils.reportMessage("CLicked on Email field.", MessageTypes.Pass);
	}

	/**
	 * Entering the values from Change Password screen and canceling it
	 * 
	 */
	@QAFTestStep(description = "I enter all fields in change password page and cancel it")
	public void iEnterAllFieldsInChangePasswordPageAndCancelIt() {
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		ChangepasswordTestPage changepswd = new ChangepasswordTestPage();
		AndroidStepDef androidstepdef = new AndroidStepDef();

		String newpswd = getBundle().getString("myaccount.changepassword.password");
		String oldpswd = getBundle().getString("strpassword1");

		changepswd.waitForPageToLoad();
		changepswd.getChangepswdTxtEnteroldpass().waitForPresent(3000);
		changepswd.getChangepswdTxtEnteroldpass().sendKeys(oldpswd);

		changepswd.getChangepswdTxtEnternewpass().click();
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(newpswd);

		/* Clicking on Cancel button in Login required pop-up */
		if (appcrash.getExceptionTxtLoginrequired().isPresent()) {
			appcrash.getExceptionBtnCancel().click();
			PerfectoUtils.reportMessage("Unable to change password Login required popup appeared");
		}

		androidstepdef.iClickOnCancelDeviceBackButton();
	}

	/**
	 * Entering the Invalid Password value and valid value for the remaining
	 * fields
	 * 
	 */
	@QAFTestStep(description = "I enter invalid password in registeration page")
	public void iEnterInvalidPasswordInRegisterationPage() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		String strEmailId = getBundle().getString("registration.EmailAddress");
		String strpwd = getBundle().getString("registration.invalidpassword");

		register.getRegistrationTxtEmail().click();
		register.getRegistrationTxtEmail().clear();
		register.getRegistrationTxtEmail().sendKeys(strEmailId);

		register.getRegistrationTxtPassword().click();
		register.getRegistrationTxtPassword().clear();
		register.getRegistrationTxtPassword().sendKeys(strpwd);

		try {
			register.getRegistrationChkIagree().waitForPresent(5000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
			register.getRegistrationChkIagree().waitForPresent(5000);
		}

		if (register.getRegistrationChkIagree().getAttribute("checked").equals("false")) {
			register.getRegistrationChkIagree().click();
		}
	}

	/**
	 * Validating the Updated Email Subscriptions
	 * 
	 */
	@QAFTestStep(description = "I validate the updated options in Email notifications")
	public void iValidateTheUpdatedOptionsInEmailNotifications() {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		MynotificationsTestPage mynotifipage = new MynotificationsTestPage();

		String isAutoEnrollEnabled = getBundle().getString("isAutoEnrollEnabled");

		if (isAutoEnrollEnabled.equalsIgnoreCase("true")) {
			myaccount.getLblMynotifications().waitForPresent(3000);
			myaccount.getLblMynotifications().click();
			PerfectoUtils.reportMessage("Clicked on My Notifications.", MessageTypes.Pass);

		} else {
			myaccount.getLblCouponsandpromotions().waitForPresent(1000);
			myaccount.getLblCouponsandpromotions().click();
			PerfectoUtils.reportMessage("Clicked on Coupons and Promotions.", MessageTypes.Pass);
		}

		String chkweeklyad = getBundle().getString("WeeklyAd");
		String chkpromotio = getBundle().getString("Promotional");
		String chknewlett = getBundle().getString("Newsletter");

		mynotifipage.getRbtWeeklyad().verifyPresent();
		if (chkweeklyad.equals(mynotifipage.getRbtWeeklyad().getAttribute("checked"))) {
			PerfectoUtils.reportMessage("WeeklyAd updated as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("WeeklyAd not updated", MessageTypes.Fail);
		}

		if (chkpromotio.equals(mynotifipage.getRbtPromotional().getAttribute("checked"))) {
			PerfectoUtils.reportMessage("Promotional updated as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Promotional not updated", MessageTypes.Fail);
		}

		if (chknewlett.equals(mynotifipage.getRbtNewsletter().getAttribute("checked"))) {
			PerfectoUtils.reportMessage("Newsletter updated as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Newsletter not updated", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking the device back button
	 * 
	 */
	@QAFTestStep(description = "I navigate back to previously viewed page")
	public void iNavigateBackToPreviouslyViewedPage() {

		PerfectoUtils.androiddeviceback();
		PerfectoUtils.reportMessage("Done.", MessageTypes.Pass);

	}

	/**
	 * Validating the Default Email notification options 1. Weekly Ads 2.
	 * Promotional 3. Monthly newsletter
	 * 
	 */
	@QAFTestStep(description = "I validate default Email Preferences options")
	public void iValidateDefaultEmailPreferencesOptions() {
		WantmoreTestPage wantmore = new WantmoreTestPage();

		wantmore.getLblPageHeader().waitForPresent(5000);
		PerfectoUtils.verticalswipe();

		String statusWeeklyAdToggle = wantmore.getWeeklyadSwitch().getAttribute("checked");
		String statusPromotionalToggle = wantmore.getPromotionalSwitch().getAttribute("checked");
		String statusNewsletterToggle = wantmore.getNewsletterSwitch().getAttribute("checked");

		/*
		 * Verify whether the Weekly Ad toggle switch is set to false by default
		 */
		if (statusWeeklyAdToggle.equalsIgnoreCase("false")) {
			PerfectoUtils.reportMessage("Weekly Ad Email Preference is set OFF by default as expected",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Weekly Ad Email Preference is ON by default", MessageTypes.Fail);
		}

		/*
		 * Verify whether the Promotional toggle switch is set to true by
		 * default
		 */
		if (statusPromotionalToggle.equalsIgnoreCase("true")) {
			PerfectoUtils.reportMessage("Promotional Email Preference is set ON by default as expected",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Promotional Email Preference is set OFF by default.", MessageTypes.Fail);
		}

		/*
		 * Verify whether the Newsletter toggle switch is set to true by default
		 */
		if (statusNewsletterToggle.equalsIgnoreCase("true")) {
			PerfectoUtils.reportMessage("Newsletter Email Preference is set ON by default as expected",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Newsletter Email Preference is set OFF by default", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking on Extra Offers
	 * 
	 */
	@QAFTestStep(description = "I navigate to offers page")
	public void iNavigateToOffersPage() {
		WantmoreTestPage wantmore = new WantmoreTestPage();

		wantmore.getLblExtraOffers().waitForPresent(3000);
		wantmore.getLblExtraOffers().click();

		PerfectoUtils.reportMessage("Clicked on Extra Offers..");
	}

	@QAFTestStep(description = "I am a user with new installed app")
	public void iAmAUserWithNewInstalledApp() throws Exception {

		String user = getBundle().getString("driver.capabilities.user");
		String password = getBundle().getString("driver.capabilities.password");
		String deviceName_ = getBundle().getString("driver.capabilities.deviceName");
		String repository_url = getBundle().getString("repository_url");
		String application_name = getBundle().getString("application_name");
		String app_instrument = getBundle().getString("app_instrument");
		String cam_instrument = getBundle().getString("cam_instrument");

		try {
			InstallApp_Android(deviceName_, repository_url, application_name, user, password, app_instrument,
					cam_instrument);
			PerfectoUtils.reportMessage("App Installation completed successfully.", MessageTypes.Pass);

		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured during App Installation.", MessageTypes.Fail);
		}
	}

	public static void InstallApp_Android(String deviceName_, String repository_url, String application_name,
			String user, String password, String app_instrument, String cam_instrument) throws IOException {
		InstallAppAndroid installApp = new InstallAppAndroid();
		System.out.println("Run started");

		DesiredCapabilities capabilities = new DesiredCapabilities("", "", Platform.ANY);
		String host = "heb.perfectomobile.com";

		capabilities.setCapability("user", user);
		capabilities.setCapability("password", password);
		capabilities.setCapability("deviceName", deviceName_);
		PerfectoUtils.setExecutionIdCapability(capabilities, host);

		AndroidDriver<WebElement> driver = (AndroidDriver<WebElement>) PerfectoUtils.getAppiumDriver();
		try {
			installApp.uninstallApp(driver, application_name);
		} catch (Exception e) {
			e.printStackTrace();

		}
		// Old version
		installApp.installApp(driver, repository_url, app_instrument, cam_instrument);
		installApp.openApp(driver, application_name);

	}

	/**
	 * Clicking Hi <UserName> in HomePage and navigate to My Account
	 * 
	 */
	@QAFTestStep(description = "I navigate to My Account page by clicking Hi <UserName> in HomePage")
	public void iNavigateToMyAccountPageByClickingHiUserNameInHomePage() {

		PerfectoUtils.reportMessage("This is not applicable for Android", MessageTypes.Info);
	}

	/**
	 * Validating the fields from My Notifications page
	 * 
	 */
	@QAFTestStep(description = "I validate My Notifications page elements")
	public void iValidateMyNotificationsPageElements() {
		MynotificationsTestPage mynotifipage = new MynotificationsTestPage();
		MyaccountTestPage myaccount = new MyaccountTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		MyaccountTestPage accounttestpage = new MyaccountTestPage();
		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		if (Flagstatus.equalsIgnoreCase("true")) {
			mynotifipage.getLblPgetitle().verifyPresent();
			mynotifipage.getBtnGetextraoffers().verifyPresent();
			mynotifipage.getLblEmailnotifications().verifyPresent();
			mynotifipage.getRbtWeeklyad().verifyPresent();
			mynotifipage.getRbtNewsletter().verifyPresent();
			mynotifipage.getRbtPromotional().verifyPresent();
		} else {
			accounttestpage.getLblCouponsandpromotions().verifyPresent();
			mynotifipage.getLblEmailnotifications().verifyPresent();
			mynotifipage.getRbtWeeklyad().verifyPresent();
			mynotifipage.getRbtNewsletter().verifyPresent();
			mynotifipage.getRbtPromotional().verifyPresent();
		}

	}

	/**
	 * Report that this scenario is NA for Android
	 * 
	 */
	@QAFTestStep(description = "I click on Rate this App option")
	public void iClickOnRateThisAppOption() {
		PerfectoUtils.reportMessage("This is NA for Android", MessageTypes.Info);
	}

	/**
	 * Report that this scenario is NA for Android
	 * 
	 */
	@QAFTestStep(description = "I see H-E-B app page in App Store")
	public void iSeeHEBAppPageInAppStore() {
		PerfectoUtils.reportMessage("This is NA for Android", MessageTypes.Info);
	}

	/**
	 * Report that this scenario is NA for Android
	 * 
	 */
	@QAFTestStep(description = "I click on Contact Us option")
	public void iClickOnContactUsOption() {
		PerfectoUtils.reportMessage("This is NA for Android", MessageTypes.Info);
	}

	/**
	 * Report that this scenario is NA for Android
	 * 
	 */
	@QAFTestStep(description = "I see Contact Us page")
	public void iSeeContactUsPage() {
		PerfectoUtils.reportMessage("This is NA for Android", MessageTypes.Info);
	}

	/**
	 * I update the email notification
	 * 
	 */
	@QAFTestStep(description = "I update the email notification")
	public void iUpdateTheEmmailNotification() {
		WantmoreTestPage wantmore = new WantmoreTestPage();

		/* Switching Promotional button */
		PerfectoUtils.verticalswipe();
		wantmore.getPromotionalSwitch().click();
		getBundle().setProperty("Promotional", wantmore.getPromotionalSwitch().getAttribute("checked"));

	}

	/**
	 * Login with invalid password 5 times
	 * 
	 */
	@QAFTestStep(description = "I Login with invalid password 5 times")
	public void iLoginWithInvalidPassword5Times() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		String username = ConfigurationManager.getBundle().getString("strRegisterEmailId");
		String pswd = ConfigurationManager.getBundle().getString("myaccount.invalidpassword");

		loginsplash.getLoginTxtEmail().waitForPresent(3000);
		loginsplash.getLoginTxtEmail().click();
		loginsplash.getLoginTxtEmail().sendKeys(username);
		loginsplash.getLoginTxtPassword().click();
		loginsplash.getLoginTxtPassword().sendKeys(pswd);

		for (int i = 0; i < 5; i++) {
			loginsplash.getLoginBtnLogin().verifyPresent();
			loginsplash.getLoginBtnLogin().click();
			PerfectoUtils.reportMessage("Clicked Login button.", MessageTypes.Pass);
			loginsplash.waitForPageToLoad();

			if (loginsplash.getTxtForgotPassword().isPresent()) {
				PerfectoUtils.reportMessage("Navigated to Forgot Password Page", MessageTypes.Pass);
				break;
			}
		}

	}

	/**
	 * Verifying Forgot password page
	 * 
	 */
	@QAFTestStep(description = "I verify login screen changed to Forgot Password screen")
	public void iVerifyLoginScreenChangedToForgotPasswordScreen() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		if (loginsplash.getTxtForgotPassword().isPresent()) {
			loginsplash.getTxtForgotPassword().verifyPresent();
			loginsplash.getLoginTxtEmail().verifyPresent();
			PerfectoUtils.reportMessage("Navigated to Forgot password page", MessageTypes.Info);
		}

	}

	/**
	 * verify save button is disabled by default
	 * 
	 */
	@QAFTestStep(description = "I verify save button is disabled by default")
	public void iVerifySaveButtonIsDisabledByDefault() {
		ExtraOffersTestPage offerspage = new ExtraOffersTestPage();

		String enabled = offerspage.getBtnSave().getAttribute("enabled");

		if (enabled.equals("false"))
			PerfectoUtils.reportMessage("save button is disabled by default", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("save button is not disabled by default", MessageTypes.Fail);

	}

	/**
	 * Enter Invalid mobile number and check "I agree" option
	 * 
	 */
	@QAFTestStep(description = "I enter valid phone number in offers page")
	public void iEnterValidPhoneNumberInOffersPage() {
		ExtraOffersTestPage Extraoffers = new ExtraOffersTestPage();

		// Getting the current time to form the unique Mobile number
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();

		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		String mobileno = "8" + strTimeStmp.substring(3, 12);

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Extraoffers.getEdtMobilenum().isPresent()) {
			Extraoffers.getEdtMobilenum().click();
			Extraoffers.getEdtMobilenum().clear();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(mobileno);
			// Extraoffers.getEdtMobilenum().sendKeys(mobileno);
		} else {
			Extraoffers.getTxtMobileNumEdit().waitForPresent(10000);
			Extraoffers.getTxtMobileNumEdit().click();
			Extraoffers.getTxtMobileNumEdit().clear();
			Extraoffers.getTxtMobileNumEdit().sendKeys(mobileno);
		}

		PerfectoUtils.reportMessage("Entered Valid phone number: " + mobileno);

		Extraoffers.getBtnSave().verifyPresent();
		Extraoffers.getBtnSave().click();
		PerfectoUtils.reportMessage("Clicked Save button..");

	}

	/**
	 * verify save button is enabled after entering all details
	 * 
	 */
	@QAFTestStep(description = "I verify save button is enabled after entering all details")
	public void iVerifySaveButtonIsEnabledAfterEnteringAllDetails() {
		ExtraOffersTestPage extraoffers = new ExtraOffersTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		PerfectoUtils.reportMessage("Registering for Extra Offers", MessageTypes.Pass);

		// Getting the current time to form the unique Mobile number
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();

		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		String strPhonenum = "8" + strTimeStmp.substring(3, 12);
		String strpin = strTimeStmp.substring(8, 12);

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			extraoffers.getEdtMobilenum().sendKeys(strPhonenum);
			PerfectoUtils.hidekeyboard();

			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");

		} else {
			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			extraoffers.getEdtMobilenum().sendKeys(strPhonenum);
			PerfectoUtils.hidekeyboard();

			extraoffers.getedt4digitpin().click();
			extraoffers.getedt4digitpin().sendKeys(strpin);
			PerfectoUtils.hidekeyboard();

			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");

		}
		extraoffers.getBtnSave().waitForPresent(10000);
		String enabled = extraoffers.getBtnSave().getAttribute("enabled");

		if (enabled.equals("true"))
			PerfectoUtils.reportMessage("save button is enabled after all details entered", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("save button is not enabled after all details entered", MessageTypes.Fail);
	}

	/**
	 * Doing registration and navigating to the device home screen
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I register a new user enrolled with get extra offers")
	public void iRegisterANewUserEnrolledWithGetExtraOffers() throws Exception {
		CommonSteps commonsteps = new CommonSteps();
		AndroidStepDef androidstepdef = new AndroidStepDef();
		HomeTestPage homepage = new HomeTestPage();
		CommonStepDefRegisteration commonregister = new CommonStepDefRegisteration();
		CommonStepDefMyAccounts commonstepsMyAccount = new CommonStepDefMyAccounts();
		AndroidStepDefMyaccount andStepDefMyAcc = new AndroidStepDefMyaccount();

		// Prerequisite: verify the user is in login splash page
		androidstepdef.iAmOnLoginSplashPage();

		// Steps to register for a new user
		commonsteps.iClickRegisterButtonFromLoginSplashPage();

		iEnterAllRequiredFieldsInRegisterationPage();
		commonregister.iClickCreateAccount();

		// Skip select store
		commonstepsMyAccount.iNavigateToWantMorePageOnClickingSkipForNow();

		// Register for get extra offers

		andStepDefMyAcc.iNavigateToExtraOffersPageAndValidateTheFields();
		andStepDefMyAcc.iEnterAllRequiredFieldsInOffersPage();
		commonstepsMyAccount.iValidateTheUserRegisteredForOffersInWantmorePage();

		// Click Done from want more page
		CommonStepDefMyAccounts.iClickDoneFromWantMorePage();

		// Verify registration is success and currently in home page
		homepage.getHomeLblWeeklyAd().waitForPresent(50000);
		homepage.getHomeLblWeeklyAd().verifyPresent();
	}

	/**
	 * Doing registration and navigating to the device home screen
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I register new user with get extra offers with same phone number")
	public void iRegisterANewUserWithEnrolledWithGetExtraOffersWithSamePhoneNumber() throws Exception {
		CommonSteps commonsteps = new CommonSteps();
		AndroidStepDef androidstepdef = new AndroidStepDef();
		HomeTestPage homepage = new HomeTestPage();
		CommonStepDefRegisteration commonregister = new CommonStepDefRegisteration();
		CommonStepDefMyAccounts commonstepsMyAccount = new CommonStepDefMyAccounts();
		AndroidStepDefMyaccount andStepDefMyAcc = new AndroidStepDefMyaccount();

		// Prerequisite: verify the user is in login splash page
		androidstepdef.iAmOnLoginSplashPage();

		// Steps to register for a new user
		commonsteps.iClickRegisterButtonFromLoginSplashPage();

		iEnterAllRequiredFieldsInRegisterationPage();
		commonregister.iClickCreateAccount();

		// Skip select store
		commonstepsMyAccount.iNavigateToWantMorePageOnClickingSkipForNow();

		// Register for get extra offers

		andStepDefMyAcc.iNavigateToExtraOffersPageAndValidateTheFields();
		andStepDefMyAcc.iEnterAllRequiredFieldsInOffersPageWithRegisteredPhoneNumber();

	}

	/**
	 * Entering All the required fields in Offers page and clicking save button
	 * 
	 */
	@QAFTestStep(description = "I enter all required fields in offers page with alredy registered phone number")
	public void iEnterAllRequiredFieldsInOffersPageWithRegisteredPhoneNumber() {
		ExtraOffersTestPage extraoffers = new ExtraOffersTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		PerfectoUtils.reportMessage("Registering for Extra Offers", MessageTypes.Pass);

		// Getting the current time to form the unique Mobile number
		// Getting the current time to form the unique Mobile number
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();

		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		String strpin = strTimeStmp.substring(8, 12);

		String strPhonenum = ConfigurationManager.getBundle().getString("enrolledPhoneNumber");

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			extraoffers.getEdtMobilenum().sendKeys(strPhonenum);
			PerfectoUtils.hidekeyboard();

			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");

			extraoffers.getBtnSave().waitForPresent(10000);
			extraoffers.getBtnSave().click();
			PerfectoUtils.reportMessage("Clicked on Save button..");

			androidcommon.getImgProgress().waitForNotPresent(50000);
		} else {
			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			extraoffers.getEdtMobilenum().sendKeys(strPhonenum);
			PerfectoUtils.hidekeyboard();

			extraoffers.getedt4digitpin().click();
			extraoffers.getedt4digitpin().sendKeys(strpin);
			PerfectoUtils.hidekeyboard();

			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");

			extraoffers.getBtnSave().waitForPresent(10000);
			extraoffers.getBtnSave().click();
			PerfectoUtils.reportMessage("Clicked on Save button..");

			androidcommon.getImgProgress().waitForNotPresent(50000);
		}
	}

	@QAFTestStep(description = "Verify the Done button is enabled by default")
	public static void verifyTheDoneButtonIsEnabledByDefault() {
		WantmoreTestPage wantmore = new WantmoreTestPage();

		wantmore.waitForPageToLoad();
		PerfectoUtils.verticalswipe();

		wantmore.getBtnDone().waitForPresent(3000);
		PerfectoUtils.swipeIfInBottom(wantmore.getBtnDone());

		if (wantmore.getBtnDone().getAttribute("enabled").equalsIgnoreCase("true")) {
			PerfectoUtils.reportMessage("Done button enabled by default..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Done button not enabled by default..", MessageTypes.Fail);

		}
	}

	@QAFTestStep(description = "I verify Redeem Coupons does not appear in the Left Nav menu")
	public void iVerifyRedeemCouponsDoesNotAppearInTheLeftNavMenu() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		androidcommon.getAppHamburger().waitForPresent(5000);
		androidcommon.getAppHamburger().click();

		if (androidcommon.getAppSliderRedeemCoupons().isPresent()) {
			PerfectoUtils.reportMessage("Redeem Coupons is present for cold user.", MessageTypes.Fail);
		} else {
			PerfectoUtils.verticalswipe();
			if (androidcommon.getAppSliderRedeemCoupons().isPresent()) {
				PerfectoUtils.reportMessage("Redeem Coupons is present for cold user.", MessageTypes.Fail);
			} else {
				PerfectoUtils.reportMessage("Redeem Coupons is not present for cold user.", MessageTypes.Pass);
			}

		}

	}

	@QAFTestStep(description = "I verify partner's name appears on the VPP Barcode screen")
	public void iVerifyPartnersNameAppearsOnTheVPPBarcodeScreen() {
		MyhebbarcodeTestPage myhebbarcode = new MyhebbarcodeTestPage();

		if (myhebbarcode.getLblNamevalue().isPresent()) {
			myhebbarcode.getLblNamevalue().verifyPresent();
			PerfectoUtils.reportMessage("Partner's name : " + myhebbarcode.getLblNamevalue().getText(),
					MessageTypes.Pass);
			PerfectoUtils.androiddeviceback();
		} else {
			PerfectoUtils.reportMessage("Partner's name is not present", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify barcode appears at the bottom of the VPP Barcode screen")
	public void iVerifyBarcodeAppearsAtTheBottomOfTheVPPBarcodeScreen() {
		MyhebbarcodeTestPage myhebbarcode = new MyhebbarcodeTestPage();

		if (myhebbarcode.getImgBarcode().isPresent()) {
			myhebbarcode.getLblBarcodenumber().verifyPresent();
			PerfectoUtils.androiddeviceback();
		} else {
			PerfectoUtils.reportMessage("barcode is not present", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify header image with the text on the VPP Barcode screen")
	public void iVerifyHeaderImageWithTheTextOnTheVPPBarcodeScreen() {
		MyhebbarcodeTestPage myhebbarcode = new MyhebbarcodeTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			myhebbarcode.getLblBarcodephototext().verifyPresent();
			PerfectoUtils.androiddeviceback();
		} else {
			PerfectoUtils.reportMessage("Redeem Coupon section is not present", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I verify Redeem Coupons does not appear on My Account page")
	public void iVerifyRedeemCouponsDoesNotAppearOnMyAccountPage() {
		AndroidStepDefMyaccount andmyaccount = new AndroidStepDefMyaccount();
		MyaccountTestPage myaccount = new MyaccountTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		andmyaccount.iNavigateToMyAccountPage();

		if (Flagstatus.equalsIgnoreCase("true")) {
			myaccount.getLblMyhebbarcode().waitForPresent(3000);
			myaccount.getLblMyhebbarcode().verifyPresent();
			PerfectoUtils.reportMessage("Redeem Coupons is present.", MessageTypes.Pass);
		} else {
			if (!myaccount.getLblMyhebbarcode().isPresent()) {
				PerfectoUtils.reportMessage("Redeem Coupon section is not present", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Redeem Coupon section is present", MessageTypes.Fail);
			}
		}

	}

	@QAFTestStep(description = "I verify Redeem button is not present in Selected Savings tab")
	public void IVerifyRedeemButtonIsNotPresentInSelectedSavingsTab() {
		AndroidStepDef androidstep = new AndroidStepDef();
		AndroidStepdefCoupons androidstepcoupons = new AndroidStepdefCoupons();
		CouponsselectionTestPage couponSelection = new CouponsselectionTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		androidstep.iNavigateToCouponsPage();
		androidstepcoupons.iNavigateToSelectedSavingsTab();

		if (Flagstatus.contains("true")) {
			// Verify redeem button is displayed
			if (couponSelection.getCouponsBtnRedeem().isPresent())
				PerfectoUtils.reportMessage("Redeem button is displayed in selected tab..", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Redeem button is not displayed in selected tab..", MessageTypes.Fail);
		} else {
			if (!couponSelection.getCouponsBtnRedeem().isPresent())
				PerfectoUtils.reportMessage("Redeem button is not displayed in selected tab..", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Redeem button is displayed in selected tab..", MessageTypes.Fail);
		}
	}

	/**
	 * verifying error message
	 * 
	 */
	@QAFTestStep(description = "I verify error message on the Log In page")
	public void iVerifyErrorMessageOnTheLogInPage() {
		HomeTestPage homepage = new HomeTestPage();

		if (homepage.getImgHomeHero().isPresent()) {
			PerfectoUtils.reportMessage("Successfully logged in", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("User still is in log in page", MessageTypes.Pass);
		}

	}

	/**
	 * verifying email field is displayed on the Forgot Password page
	 * 
	 */
	@QAFTestStep(description = "I verify email field is displayed on the Forgot Password page")
	public void iVerifyEmailFieldIsDisplayedOnTheForgotPasswordPage() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		if (loginsplash.getLoginTxtEmail().isPresent()) {
			loginsplash.getLoginTxtEmail().verifyPresent();
			PerfectoUtils.reportMessage("email field is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("email field is not displayed", MessageTypes.Fail);
		}
	}

	/**
	 * verifying error message for invalid email id in Forgot Password page
	 * 
	 */
	@QAFTestStep(description = "I verify error message for invalid email id")
	public void iVerifyErrorMessageForInvalidEmailId() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		String username = ConfigurationManager.getBundle().getString("myaccount.invalidemail");
		loginsplash.getLoginTxtEmail().click();
		loginsplash.getLoginTxtEmail().sendKeys(username);
		loginsplash.getBtnResetPassword().click();
		loginsplash.getTxtEmailerror().waitForPresent(2000);

		if (loginsplash.getTxtEmailerror().isPresent()) {
			PerfectoUtils.reportMessage("Email is not valid", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("No error mesg", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify Reset Password button becomes enabled after entering email")
	public void iVerifyResetPasswordButtonBecomesEnabledAfterEnteringEmail() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		String username = ConfigurationManager.getBundle().getString("hotuser1.user.email");
		loginsplash.getLoginTxtEmail().click();
		loginsplash.getLoginTxtEmail().sendKeys(username);

		if (loginsplash.getBtnResetPassword().getAttribute("enabled").equalsIgnoreCase("true")) {
			PerfectoUtils.reportMessage("Reset Password button becomes enabled", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Reset Password button is disabled", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify email has send after clicking Reset Password button")
	public void iVerifyEmailHasSendAfterClickingResetPasswordButton() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		String username = ConfigurationManager.getBundle().getString("hotuser1.user.email");
		loginsplash.getLoginTxtEmail().click();
		loginsplash.getLoginTxtEmail().sendKeys(username);
		loginsplash.getBtnResetPassword().click();

		loginsplash.getLoginLblContinue().waitForPresent(5000);
		if (loginsplash.getLoginLblContinue().isPresent()) {
			PerfectoUtils.reportMessage("Email has been sent", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Email has not been sent", MessageTypes.Fail);
		}
	}

	/**
	 * Entering invalid email id
	 * 
	 */
	@QAFTestStep(description = "I enter invalid email id and valid password")
	public void iEnterInvalidEmailIdAndValidPassword() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		String username = ConfigurationManager.getBundle().getString("myaccount.invalidemail");
		String pswd = ConfigurationManager.getBundle().getString("myaccount.hotuser1.user.password");

		loginsplash.getLoginTxtEmail().waitForPresent(3000);
		loginsplash.getLoginTxtEmail().click();
		loginsplash.getLoginTxtEmail().sendKeys(username);
		loginsplash.getLoginTxtPassword().click();
		loginsplash.getLoginTxtPassword().sendKeys(pswd);

		loginsplash.getLoginBtnLogin().verifyPresent();
		loginsplash.getLoginBtnLogin().click();
		PerfectoUtils.reportMessage("Clicked Login button.", MessageTypes.Pass);

	}

	/**
	 * Entering invalid password id
	 * 
	 */
	@QAFTestStep(description = "I enter valid email id and invalid password")
	public void iEnterValidEmailIdAndInvalidPassword() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		String username = ConfigurationManager.getBundle().getString("hotuser2.user.email");
		String pswd = ConfigurationManager.getBundle().getString("myaccount.invalidpassword");

		loginsplash.getLoginTxtEmail().waitForPresent(3000);
		loginsplash.getLoginTxtEmail().click();
		loginsplash.getLoginTxtEmail().sendKeys(username);
		loginsplash.getLoginTxtPassword().click();
		loginsplash.getLoginTxtPassword().sendKeys(pswd);

		loginsplash.getLoginBtnLogin().verifyPresent();
		loginsplash.getLoginBtnLogin().click();
		PerfectoUtils.reportMessage("Clicked Login button.", MessageTypes.Pass);

	}

	@QAFTestStep(description = "I am a hot user user with new registration and enrolled for Coupons")
	public void iAmAHotUserUserWithNewRegistrationAndEnrolledForCoupons() throws Exception {
		CommonSteps commonsteps = new CommonSteps();
		AndroidStepDef androidstepdef = new AndroidStepDef();
		HomeTestPage homepage = new HomeTestPage();
		CommonStepDefRegisteration commonregister = new CommonStepDefRegisteration();

		// Prerequisite: verify the user is in login splash page
		androidstepdef.iAmOnLoginSplashPage();

		// Steps to register for a new user
		commonsteps.iClickRegisterButtonFromLoginSplashPage();

		iEnterAllRequiredFieldsInRegisterationPage();
		commonregister.iClickCreateAccount();

		// Skip select store
		CommonStepDefMyAccounts.iNavigateToWantMorePageOnClickingSkipForNow();

		// Navigate and Enroll the details from 'Extra Offers' page
		iNavigateToExtraOffersPageAndValidateTheFields();
		iEnterAllRequiredFieldsInOffersPage();
		CommonStepDefMyAccounts.iValidateTheUserRegisteredForOffersInWantmorePage();

		// Click Done from want more page
		CommonStepDefMyAccounts.iClickDoneFromWantMorePage();

		// Verify registration is success and currently in home page
		homepage.getHomeLblWeeklyAd().waitForPresent(50000);
		homepage.getHomeLblWeeklyAd().verifyPresent();
	}

	@QAFTestStep(description = "Clear the phone number field in offers page")
	public void clearThePhoneNumberFieldInOffersPage() {
		ExtraOffersTestPage offerspage = new ExtraOffersTestPage();

		PerfectoUtils.scrollToElement(offerspage.getEdtMobilenum());
		offerspage.getEdtMobilenum().clear();
		PerfectoUtils.reportMessage("Entered phone number has been cleared..", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify the Save button got disabled in offers page")
	public void verifyTheSaveButtonGotDisabledInOffersPage() {
		ExtraOffersTestPage offerspage = new ExtraOffersTestPage();

		PerfectoUtils.hidekeyboard();
		PerfectoUtils.scrollToElement(offerspage.getBtnSave());

		if (offerspage.getBtnSave().getAttribute("enabled").equalsIgnoreCase("false")) {
			PerfectoUtils.reportMessage("Save button is disabled..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Save button is not disabled..", MessageTypes.Fail);
		}
	}
}
