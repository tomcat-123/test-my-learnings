/**
 * 
 */
package com.heb.automation.common.steps.registeration;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.HashMap;
import java.util.Map;

import com.heb.automation.android.steps.AndroidStepDef;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.myaccount.MyhebbarcodeTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.pages.registeration.WantmoreTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.storelocator.StorelocatorTestPage;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in Common Registration

	I click create account
	I click select a store from pick your store page
	I validate empty state for My Store is displayed
	I click My Store takes the user to choose store
	I validate the selected store is displayed in My Store
	I click skip and continue as guest
	I verify Create account button is disabled
	I click on My Store from Want more screen
	I see email is not valid text
	I enter password in registration page
	I verify tapping Show Password toggles password masking*/

public class CommonStepDefRegisteration {

	/**
	 * Creating an account.Handling the error pop up.
	 */
	@QAFTestStep(description = "I click create account")
	public void iClickCreateAccount() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		WeeklygroceriesTestPage randomdata = new WeeklygroceriesTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		try {
			PerfectoUtils.verticalswipe();
			register.getRegistrationBtnSubmit().waitForPresent(5000);
		} catch (Exception e1) {
			PerfectoUtils.verticalswipe();
		}

		if (register.getRegistrationBtnSubmit().getAttribute("enabled").equals("true")) {
			register.getRegistrationBtnSubmit().click();
			PerfectoUtils.reportMessage("Clicked Created Account Button!!", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Please valid the all the mandatory fields are entered!!", MessageTypes.Info);
		}

		try {
			ioscommon.getAppLblLoading().waitForNotPresent(70000);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("App is loading for more than 1 minute while creating account",
					MessageTypes.Fail);
		}

		if (appcrash.getLblError().isPresent()) {
			PerfectoUtils.reportMessage("Unable to Register pop up has been populated", MessageTypes.Fail);
			appcrash.getbtnStoreLocatorOK();
			register.getRegistrationBtnSubmit().click();
		}

		if (register.getRegistrationBtnSubmit().isPresent()) {
			register.getRegistrationBtnSubmit().click();
			PerfectoUtils.reportMessage("Clicked Created Account Button again!!", MessageTypes.Pass);
		}
		randomdata.getShopingListEntryByLable("Welcome").waitForNotPresent(50000);
	}

	/**
	 * Selecting a store from store page.
	 */
	@QAFTestStep(description = "I click select a store from pick your store page")
	public void iClickSelectAStoreFromPickYourStorePage() throws Exception {
		RegistrastionTestPage register = new RegistrastionTestPage();
		WeeklygroceriesTestPage randomdata = new WeeklygroceriesTestPage();

		randomdata.getShopingListEntryByLable("Welcome").waitForNotPresent(20000);
		register.getLblPickstore().waitForPresent(10000);
		register.getLblPickstore().verifyPresent();
		register.getRegistrationBtnSelectStore().click();
	}

	/**
	 * Validation of empty state for My store.
	 */
	@QAFTestStep(description = "I validate empty state for My Store is displayed")
	public void iValidateEmptyStateForMyStoreIsDisplayed() {
		WantmoreTestPage wantmore = new WantmoreTestPage();

		wantmore.getLblMystore().waitForPresent(3000);
		wantmore.getLblMystoreaddress().verifyText("Select a Store");
	}

	/**
	 * Clicking on My stores and Selecting the Store.
	 */
	@QAFTestStep(description = "I click My Store takes the user to choose store")
	public void iClickMyStoreTakesTheUserToChooseStore() {
		WantmoreTestPage wantmore = new WantmoreTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();

		// PerfectoUtils.setLocation("san antonio");
		wantmore.getLblMystore().click();

		if (appcrash.getAppExceptionMsgTitle().isPresent()) {
			appcrash.getExceptionBtnOk().click();
			PerfectoUtils.reportMessage("Store Locator Currently Unavailable", MessageTypes.Info);
		}

		if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
			PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Pass);
			storelocator.getStorelocatorBtnAllow().click();
			PerfectoUtils.reportMessage("Clicked Allow button.", MessageTypes.Pass);
		}
		storelocator.getStorelocatorLblRefine().verifyPresent();
	}

	/**
	 * Validating the selected Store in My store page.
	 */
	@QAFTestStep(description = "I validate the selected store is displayed in My Store")
	public void iValidateTheSelectedStoreIsDisplayedInMyStore() {
		WantmoreTestPage wantmore = new WantmoreTestPage();

		String expectedStore = getBundle().getString("StoreAddress");
		wantmore.getLblMystore().waitForPresent(3000);
		String actualStore = wantmore.getLblMystoreaddress().getText();

		if (actualStore.contains(expectedStore)) {
			PerfectoUtils.reportMessage("Selected Store is displayed in My store as " + actualStore, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected Store is not displayed in My store as " + actualStore,
					MessageTypes.Fail);
		}
	}

	/**
	 * Clicking on Skip and Continue as guest.
	 */
	@QAFTestStep(description = "I click skip and continue as guest")
	public void iClickSkipAndContinueAsGuest() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		PerfectoUtils.hidekeyboard();
		if (!register.getLnkSkipandcontinueasguest().isPresent()) {
			Map<String, Object> params = new HashMap<>();
			params.put("mode", "off");
			PerfectoUtils.getAppiumDriver().executeScript("mobile:keyboard:display", params);
			PerfectoUtils.verticalswipe();
		}
		register.getLnkSkipandcontinueasguest().waitForPresent(5000);
		register.getLnkSkipandcontinueasguest().click();
		PerfectoUtils.reportMessage("Clicked skip and continue as guest option..", MessageTypes.Pass);

	}

	/**
	 * Verifying Create account button is disabled or not.
	 */
	@QAFTestStep(description = "I verify Create account button is disabled")
	public void iVerifyCreateAccountButtonIsDisabled() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		if (register.getRegistrationBtnSubmit().getAttribute("enabled").equals("false")) {
			PerfectoUtils.reportMessage("Create account button is disabled as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Create account button is not disabled", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking on My store from Want more page.
	 */
	@QAFTestStep(description = "I click on My Store from Want more screen")
	public void iClickOnMyStoreFromWantMoreScreen() {
		WantmoreTestPage wantmorepage = new WantmoreTestPage();

		wantmorepage.getLblMystore().verifyPresent();
		wantmorepage.getLblMystore().click();
		PerfectoUtils.reportMessage("Clicked on My Store option.", MessageTypes.Pass);
	}

	/**
	 * Verifying the error message for invalid email.
	 */
	@QAFTestStep(description = "I see email is not valid text")
	public static void iSeeEmailIsNotValidText() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		String errmsg1 = "Please enter a valid email address.";
		String errmsg2 = "Email is not valid";

		register.getLblInvalidmailmsg().waitForPresent(3000);
		String displayedtext = register.getLblInvalidmailmsg().getText();

		if ((errmsg1.equalsIgnoreCase(displayedtext)) || (errmsg2.equalsIgnoreCase(displayedtext))) {
			PerfectoUtils.reportMessage("Email is not Valid error message is displayed!", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Email is not Valid error message is not displayed!", MessageTypes.Fail);
		}
	}

	/**
	 * Verifying entering password in registration page
	 */
	@QAFTestStep(description = "I enter password in registration page")
	public void iEnterPasswordInRegistrationPage() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		PerfectoUtils.hidekeyboard();
		PerfectoUtils.verticalswipe();
		register.getRegistrationTxtPassword().verifyPresent();
		register.getRegistrationTxtPassword().sendKeys("testing");
		PerfectoUtils.reportMessage("Entered password..");
		PerfectoUtils.hidekeyboard();

	}

	/**
	 * Verifying entering password in registration page
	 */
	@QAFTestStep(description = "I verify tapping Show Password toggles password masking")
	public void iVerifyTappingShowPasswordTogglesPasswordMasking() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		String masked = "true";

		register.getImgShowPwd().verifyPresent();
		register.getImgShowPwd().click();

		try {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "GROUP:Android/store Locator/testing_passwordunmasked.png");
			Object result1 = register.getTestBase().getDriver().executeScript("mobile:image:find", params1);

			PerfectoUtils.reportMessage("Password is unmasked on clicking show..", MessageTypes.Pass);
			masked = "false";

		} catch (Exception e) {
			PerfectoUtils.reportMessage("Password is not unmasked on clicking show..", MessageTypes.Fail);
		}

		if (masked.equals("false")) {
			register.getImgShowPwd().click();
			try {
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", "GROUP:Android/store Locator/testing_Passwordmasked.png");
				Object result1 = register.getTestBase().getDriver().executeScript("mobile:image:find", params1);

				PerfectoUtils.reportMessage("Password is masked on clicking show_hide..", MessageTypes.Pass);
				masked = "true";

			} catch (Exception e) {
				PerfectoUtils.reportMessage("Password is not masked on clicking show..", MessageTypes.Fail);
			}
		}
	}

	@QAFTestStep(description = "I verify mail in inbox")
	public void iVerifyMailInInbox() {
		LoginsplashTestPage loginpage = new LoginsplashTestPage();

		PerfectoUtils.openApplication("Gmail");

		PerfectoUtils.verticalswipe();
		loginpage.getGmailLblMailSubject().waitForPresent(2000);
		if (loginpage.getGmailLblMailSubject().isPresent()) {
			PerfectoUtils.reportMessage("Able to see sent mail", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Sent mail is not present", MessageTypes.Fail);
		}
		loginpage.getGmailLblMailSubject().click();
		PerfectoUtils.reportMessage("mail clicked..");
	}

	@QAFTestStep(description = "I tap the link in the password reset email")
	public void iTapTheLinkInThePasswordResetEmail() {
		LoginsplashTestPage loginpage = new LoginsplashTestPage();

		try {
			if (loginpage.getGmailLinkResetPassword().isPresent()) {
				loginpage.getGmailLinkResetPassword().click();
				PerfectoUtils.reportMessage("Reset Password Link is present in the sent mail", MessageTypes.Pass);
			} else {
				PerfectoUtils.verticalswipe();
				loginpage.getGmailLinkResetPassword().verifyPresent();
				loginpage.getGmailLinkResetPassword().click();
				PerfectoUtils.reportMessage("Reset Password Link is present in the sent mail", MessageTypes.Pass);
			}
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Reset Password Link is not present", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I verify user navigates to Change Password screen")
	public void iVerifyUserNavigatesToChangePasswordScreen() {
		LoginsplashTestPage loginpage = new LoginsplashTestPage();

		PerfectoUtils.reportMessage("Pass");

	}

}
