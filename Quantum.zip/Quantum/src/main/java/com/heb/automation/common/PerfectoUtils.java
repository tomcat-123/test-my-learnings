package com.heb.automation.common;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.html5.Location;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.DriverCommand;
import org.openqa.selenium.remote.RemoteExecuteMethod;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableMap;
import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.common.components.ScrollableElement;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.myaccount.MyaccountTestPage;
import com.heb.automation.common.pages.products.ProductlandingTestPage;
import com.heb.automation.common.pages.recipes.RecipedetailTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.ios.steps.IOSStepdef;
import com.perfecto.reportium.client.ReportiumClient;
import com.perfecto.reportium.client.ReportiumClientFactory;
import com.perfectomobile.selenium.util.EclipseConnector;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

import io.appium.java_client.AppiumDriver;

public class PerfectoUtils {

	public static final String PERFECTO_REPORT_CLIENT = "perfecto.report.client";
	private static final Logger logger = LoggerFactory.getLogger(PerfectoUtils.class);

	private static final String HTTPS = "https://";
	private static final String MEDIA_REPOSITORY = "/services/repositories/media/";
	private static final String UPLOAD_OPERATION = "operation=upload&overwrite=true";
	private static final String UTF_8 = "UTF-8";

	/**
	 * Download the report. type - pdf, html, csv, xml Example:
	 * downloadReport(driver, "pdf", "C:\\test\\report");
	 * 
	 */
	public static void downloadReport(RemoteWebDriver driver, String type, String fileName) throws IOException {
		try {
			String command = "mobile:report:download";
			Map<String, Object> params = new HashMap<>();
			params.put("type", type);
			String report = (String) driver.executeScript(command, params);
			File reportFile = new File(fileName + "." + type);
			BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(reportFile));
			byte[] reportBytes = OutputType.BYTES.convertFromBase64Png(report);
			output.write(reportBytes);
			output.close();
		} catch (Exception ex) {
			System.out.println("Got exception " + ex);
		}
	}

	/**
	 * Download all the report attachments with a certain type. type - video,
	 * image, vital, network Examples: downloadAttachment(driver, "video",
	 * "C:\\test\\report\\video", "flv"); downloadAttachment(driver, "image",
	 * "C:\\test\\report\\images", "jpg");
	 */
	public static void downloadAttachment(RemoteWebDriver driver, String type, String fileName, String suffix)
			throws IOException {
		try {
			String command = "mobile:report:attachment";
			boolean done = false;
			int index = 0;

			while (!done) {
				Map<String, Object> params = new HashMap<>();
				params.put("type", type);
				params.put("index", Integer.toString(index));

				String attachment = (String) driver.executeScript(command, params);

				if (attachment == null) {
					done = true;
				} else {
					File file = new File(fileName + index + "." + suffix);
					BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(file));
					byte[] bytes = OutputType.BYTES.convertFromBase64Png(attachment);
					output.write(bytes);
					output.close();
					index++;
				}
			}
		} catch (Exception ex) {
			System.out.println("Got exception " + ex);
		}
	}

	/**
	 * Uploads a file to the media repository. Example:
	 * uploadMedia("demo.perfectomobile.com", "john@perfectomobile.com",
	 * "123456", "C:\\test\\ApiDemos.apk", "PRIVATE:apps/ApiDemos.apk");
	 */
	public static void uploadMedia(String host, String user, String password, String path, String repositoryKey)
			throws IOException {
		File file = new File(path);
		byte[] content = readFile(file);
		uploadMedia(host, user, password, content, repositoryKey);
	}

	/**
	 * Uploads a file to the media repository. Example: URL url = new URL(
	 * "http://file.appsapk.com/wp-content/uploads/downloads/Sudoku%20Free.apk")
	 * ; uploadMedia("demo.perfectomobile.com", "john@perfectomobile.com",
	 * "123456", url, "PRIVATE:apps/ApiDemos.apk");
	 */
	public static void uploadMedia(String host, String user, String password, URL mediaURL, String repositoryKey)
			throws IOException {
		byte[] content = readURL(mediaURL);
		uploadMedia(host, user, password, content, repositoryKey);
	}

	/**
	 * Uploads content to the media repository. Example:
	 * uploadMedia("demo.perfectomobile.com", "john@perfectomobile.com",
	 * "123456", content, "PRIVATE:apps/ApiDemos.apk");
	 */
	public static void uploadMedia(String host, String user, String password, byte[] content, String repositoryKey)
			throws UnsupportedEncodingException, MalformedURLException, IOException {
		if (content != null) {
			String encodedUser = URLEncoder.encode(user, "UTF-8");
			String encodedPassword = URLEncoder.encode(password, "UTF-8");
			String urlStr = HTTPS + host + MEDIA_REPOSITORY + repositoryKey + "?" + UPLOAD_OPERATION + "&user="
					+ encodedUser + "&password=" + encodedPassword;
			URL url = new URL(urlStr);

			sendRequest(content, url);
		}
	}

	/**
	 * Sets the execution id capability
	 */
	public static void setExecutionIdCapability(DesiredCapabilities capabilities, String host) throws IOException {
		try {
			EclipseConnector connector = new EclipseConnector();
			String eclipseHost = connector.getHost();
			if ((eclipseHost == null) || (eclipseHost.equalsIgnoreCase(host))) {
				String executionId = connector.getExecutionId();
				capabilities.setCapability(EclipseConnector.ECLIPSE_EXECUTION_ID, executionId);
			}
		} catch (Exception e) {
			logger.warn(
					"Error connecting with the Eclipse connector - Resuming execution without the execution id capability");
		}
	}

	private static void sendRequest(byte[] content, URL url) throws IOException {
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();

		connection.setDoOutput(true);
		connection.setRequestProperty("Content-Type", "application/octet-stream");
		connection.connect();
		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		outStream.write(content);
		outStream.writeTo(connection.getOutputStream());
		outStream.close();
		int code = connection.getResponseCode();
		if (code > HttpURLConnection.HTTP_OK) {
			handleError(connection);
		}
	}

	private static void handleError(HttpURLConnection connection) throws IOException {
		String msg = "Failed to upload media.";
		InputStream errorStream = connection.getErrorStream();
		if (errorStream != null) {
			InputStreamReader inputStreamReader = new InputStreamReader(errorStream, UTF_8);
			BufferedReader bufferReader = new BufferedReader(inputStreamReader);
			try {
				StringBuilder builder = new StringBuilder();
				String outputString;
				while ((outputString = bufferReader.readLine()) != null) {
					if (builder.length() != 0) {
						builder.append("\n");
					}
					builder.append(outputString);
				}
				String response = builder.toString();
				msg += "Response: " + response;
			} finally {
				bufferReader.close();
			}
		}
		throw new RuntimeException(msg);
	}

	private static byte[] readFile(File path) throws FileNotFoundException, IOException {
		int length = (int) path.length();
		byte[] content = new byte[length];
		InputStream inStream = new FileInputStream(path);
		try {
			inStream.read(content);
		} finally {
			inStream.close();
		}
		return content;
	}

	private static byte[] readURL(URL url) throws IOException {
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setDoOutput(true);
		int code = connection.getResponseCode();
		if (code > HttpURLConnection.HTTP_OK) {
			handleError(connection);
		}
		InputStream stream = connection.getInputStream();

		if (stream == null) {
			throw new RuntimeException("Failed to get content from url " + url + " - no response stream");
		}
		byte[] content = read(stream);
		return content;
	}

	private static byte[] read(InputStream input) throws IOException {
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		try {
			byte[] buffer = new byte[1024];
			int nBytes = 0;
			while ((nBytes = input.read(buffer)) > 0) {
				output.write(buffer, 0, nBytes);
			}
			byte[] result = output.toByteArray();
			return result;
		} finally {
			try {
				input.close();
			} catch (IOException e) {

			}
		}
	}

	@QAFTestStep(description = "(open|launch) {appname application}")
	public static void openApplication(String appName) {
		openApplication(getDriver(), appName);
	}

	public static void openApplication(RemoteWebDriver driver, String appName) {

		
		String command = "mobile:application:open";

		/* Open application */
		driver.executeScript(command, ImmutableMap.of("name", appName));

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		switchToContext(driver, "NATIVE_APP");
		InstallAppiOS.handleLocationpopup(driver);
	}

	public static void closeApplication(RemoteWebDriver driver, String appName) {
		String command = "mobile:application:close";

		/* Close Application if already its opened */
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("name", appName);
		try {
			driver.executeScript(command, params);
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		} catch (Exception e) {
			System.err.println("Unable to close app: " + appName);
		}
	}

	public static void switchToContext(RemoteWebDriver driver, String context) {

		RemoteExecuteMethod executeMethod = new RemoteExecuteMethod(driver);
		Map<String, String> params = new HashMap<String, String>();
		params.put("name", context);
		executeMethod.execute(DriverCommand.SWITCH_TO_CONTEXT, params);
	}

	public static void switchToContext(String context) {
		switchToContext(getDriver(), context);
	}

	@QAFTestStep(description = "close {appname application}")
	public static void closeApplication(String appName) {
		String command = "mobile:application:close";

		/* Close application command */
		getDriver().executeScript(command, ImmutableMap.of("name", appName));
	}

	public static String getCurrentContextHandle() {
		RemoteExecuteMethod executeMethod = new RemoteExecuteMethod(getDriver());

		String context = (String) executeMethod.execute(DriverCommand.GET_CURRENT_CONTEXT_HANDLE, null);
		return context;
	}

	@SuppressWarnings("unchecked")
	public static List<String> getContextHandles() {
		RemoteExecuteMethod executeMethod = new RemoteExecuteMethod(getDriver());
		List<String> contexts = (List<String>) executeMethod.execute(DriverCommand.GET_CONTEXT_HANDLES, null);
		return contexts;
	}

	public static QAFExtendedWebDriver getDriver() {
		return new WebDriverTestBase().getDriver();
	}

	public static AppiumDriver<?> getAppiumDriver() {
		return (AppiumDriver<?>) new WebDriverTestBase().getDriver().getUnderLayingDriver();
	}

	public static void setLocation(String location) {

		try {
			java.util.Map<String, Object> params0 = new HashMap<String, Object>();
			Object result = getDriver().executeScript("mobile:location:reset", params0);

			java.util.Map<String, Object> params1 = new HashMap<String, Object>();
			params1.put("address", location);
			Object result1 = getDriver().executeScript("mobile:location:set", params1);
		} catch (Exception e) {
			Location loc = new Location(29.4241, 98.4936, 0.0); // San
																// antonio-->
																// 29.4241,98.4936
			PerfectoUtils.getAppiumDriver().setLocation(loc);
		}

	}

	public static QAFExtendedWebElement getScrollableElement(String loc) {
		return new ScrollableElement(loc);
	}

	public static void scrollAndClick(String loc) {
		QAFExtendedWebElement ele = new QAFExtendedWebElement(loc);
		scrollAndClick(ele);
	}

	public static void scrollAndClick(QAFExtendedWebElement ele) {
		if (ele.getMetaData().containsKey("scrollText")) {
			String text = (String) ele.getMetaData().get("scrollText");
			getAppiumDriver().scrollTo(text);
		}
		ele.click();
	}

	public static void androiddeviceback() {

		getAppiumDriver().navigate().back();
	}

	public static void verticalswipe() {

		Dimension size = getAppiumDriver().manage().window().getSize();

		System.out.println("Swiping...");
		int starty = (int) (size.height * 0.80);
		int endy = (int) (size.height * 0.20);
		int startx = size.width / 2;
		getAppiumDriver().swipe(startx, starty, startx, endy, 1);
	}

	public static void hidekeyboard() {
		getAppiumDriver().hideKeyboard();
	}

	public static void hidekeyboard_Test() {
		getAppiumDriver().hideKeyboard();
	}

	public static void horizontalswipe() {

		Dimension size = getAppiumDriver().manage().window().getSize();
		System.out.println("Swiping...");
		int starty = (int) (size.height * 0.20);
		int endy = (int) (size.height * 0.80);
		int startx = size.width / 2;
		getAppiumDriver().swipe(startx, starty, startx, endy, 1);
	}
	
	public static void horizontalswipeEmail() {

		getAppiumDriver().swipe(618, 850, 360, 850, 0);
	}

	public static void swipeUp(float startSize, float endSize, int swipeDuration) {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		int i = 0;
		int intX = 50;
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartY = (int) (size.height * (startSize / 100));
		int intEndY = (int) (size.height * (endSize / 100));

		while (!recipedetail.getRecipedetaillblinstructions().isPresent() && i < 20) {
			/* Swiping till half of the page */
			PerfectoUtils.getAppiumDriver().swipe(intX, intEndY, intX, intStartY, swipeDuration);
			i++;
		}
	}

	public static String currentTimeStamp() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String strTimeStmp = dateFormat.format(date).replace("/", "_").replace(":", "_");
		return strTimeStmp;
	}

	public static void imageInjection(String repositoryFile, String appName) {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		Map<String, Object> params2 = new HashMap<>();
		params2.put("repositoryFile", repositoryFile);
		params2.put("name", appName);

		Object result2 = androidcommon.getTestBase().getDriver().executeScript("mobile:image.injection:start", params2);
		params2.put("threshold", "70");

		PerfectoUtils.reportMessage("New Image Loaded", MessageTypes.Pass);
		androidcommon.waitForPageToLoad();
	}

	public static void scrollToString(String strname, float startSize, float endSize, int swipeDuration) {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		int i = 0;
		int intX = 50;
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartY = (int) (size.height * (startSize / 100));
		int intEndY = (int) (size.height * (endSize / 100));

		while (!weeklygrocery.getShopingListEntryByLable(strname).isPresent() && i < 20) {
			/* Swiping till half of the page */
			PerfectoUtils.getAppiumDriver().swipe(intX, intStartY, intX, intEndY, swipeDuration);
			i++;
		}

	}

	public static void verticalswipe(float startSize, float endSize, int swipeDuration) {
		int intX = 50;

		PerfectoUtils.reportMessage("Swiping..", MessageTypes.Pass);
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartY = (int) (size.height * (startSize / 100));
		int intEndY = (int) (size.height * (endSize / 100));
		PerfectoUtils.getAppiumDriver().swipe(intX, intStartY, intX, intEndY, swipeDuration);
		PerfectoUtils.reportMessage("Done Swiping.", MessageTypes.Pass);
	}

	public static void stopimageinjection() {
		Map<String, Object> params1 = new HashMap<>();
		Object result1 = PerfectoUtils.getAppiumDriver().executeScript("mobile:image.injection:stop", params1);
	}

	public static HashSet<String> scrollToStringuntilfindelement(QAFWebElement strname, float startSize, float endSize,
			int swipeDuration) {

		int i = 0;
		int intX = 50;
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartY = (int) (size.height * (startSize / 100));
		int intEndY = (int) (size.height * (endSize / 100));

		while (!strname.isPresent() && i < 20) {
			/* Swiping till half of the page */
			PerfectoUtils.getAppiumDriver().swipe(intX, intStartY, intX, intEndY, swipeDuration);
			i++;
		}
		return null;

	}

	public static void handleReloginPopup() {
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		PerfectoUtils.reportMessage("Handling re-Login popup", MessageTypes.Pass);
		appCrash.getReloginPassword().sendKeys(getBundle().getString("currentPassword"));
		appCrash.getReloginLoginBtn().waitForPresent(10000);
		appCrash.getReloginLoginBtn().click();
		PerfectoUtils.reportMessage("Click login button from re-login popup", MessageTypes.Pass);

		TouchActions touchAction = new TouchActions(getAppiumDriver());
		touchAction.click();
	}

	public static void scrollToLogoutInIos() {
		MyaccountTestPage myaccount = new MyaccountTestPage();

		PerfectoUtils.horizontalswipe();
		myaccount.getBtnMyprofile().waitForPresent(8000);
		int i = 0;

		Dimension size = PerfectoUtils.getAppiumDriver().manage().window().getSize();
		int starty = (int) (size.height * 0.80);
		int endy = (int) (size.height * 0.75);
		int startx = size.width / 2;
		PerfectoUtils.getAppiumDriver().swipe(startx, starty, startx, endy, 1);

		try {
			myaccount.getBtnLogout().waitForPresent(5000);
		} catch (Exception e) {
			// ignore
		}

		while ((!myaccount.getBtnLogout().isPresent()) && (i < 10)) {
			size = PerfectoUtils.getAppiumDriver().manage().window().getSize();
			starty = (int) (size.height * 0.80);
			endy = (int) (size.height * 0.75);
			startx = size.width / 2;
			PerfectoUtils.getAppiumDriver().swipe(startx, starty, startx, endy, 2);
			i++;
		}

		PerfectoUtils.swipeIfInBottom(myaccount.getBtnLogout());
		PerfectoUtils.reportMessage("Scrolling done.");
	}

	public static void scrollToSelectAllInIos() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		int i = 0;
		do {
			Dimension size = PerfectoUtils.getAppiumDriver().manage().window().getSize();
			int starty = (int) (size.height * 0.80);
			int endy = (int) (size.height * 0.75);
			int startx = size.width / 2;
			PerfectoUtils.getAppiumDriver().swipe(startx, starty, startx, endy, 1);
			i++;
		} while ((!recipedetail.getRecipedetailpagelblselectall().isPresent()) && (i < 10));

		PerfectoUtils.swipeIfInBottomForSelectAll(recipedetail.getRecipedetailpagelblselectall());
		PerfectoUtils.reportMessage("Scrolling done.");
	}

	public static void scrollToMobileElement(QAFWebElement element) {

		int i = 0;
		do {
			Dimension size = PerfectoUtils.getAppiumDriver().manage().window().getSize();
			int starty = (int) (size.height * 0.80);
			int endy = (int) (size.height * 0.10);
			int startx = size.width / 2;
			PerfectoUtils.getAppiumDriver().swipe(startx, starty, startx, endy, 2);
			i++;
		} while ((!element.isPresent()) && (i < 10));
		PerfectoUtils.reportMessage("Scrolling done.");
	}

	public static void scrollToElement(QAFWebElement element) {

		int i = 0;
		do {
			Dimension size = PerfectoUtils.getAppiumDriver().manage().window().getSize();
			int starty = (int) (size.height * 0.80);
			int endy = (int) (size.height * 0.75);
			int startx = size.width / 2;
			PerfectoUtils.getAppiumDriver().swipe(startx, starty, startx, endy, 2);
			i++;
		} while ((!element.isPresent()) && (i < 10));

		PerfectoUtils.swipeIfInBottom(element);
		PerfectoUtils.reportMessage("Scrolling done.");
	}

	public static void scrollToStringIOS(String strname, float startSize, float endSize, int swipeDuration) {
		ProductlandingTestPage productlanding = new ProductlandingTestPage();
		int i = 0;
		int intX = 50;
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartY = (int) (size.height * (startSize / 100));
		int intEndY = (int) (size.height * (endSize / 100));

		while (!productlanding.getCategoryNameByLable(strname).isPresent() && i < 20) {
			/* Swiping till half of the page */
			PerfectoUtils.getAppiumDriver().swipe(intX, intStartY, intX, intEndY, swipeDuration);
			i++;
		}
	}

	public static String randomName() {
		return UUID.randomUUID().toString();
	}

	public static String removeSpecialCharacters(String value) {
		StringBuilder myNumbers = new StringBuilder();

		for (int i = 0; i < value.length(); i++) {
			if (Character.isDigit(value.charAt(i))) {
				myNumbers.append(value.charAt(i));
			} else if (Character.isLetter(value.charAt(i))) {
				myNumbers.append(value.charAt(i));
			} else {
				System.out.println(value.charAt(i) + " not a digit or Character.");
			}
		}
		return myNumbers.toString();

	}

	public static void swipeIfInBottom(String lable) {
		ProductlandingTestPage productlanding = new ProductlandingTestPage();

		try {
			if (productlanding.getCategoryNameByLable(lable).isPresent()) {
				int locatorheight = Integer.parseInt(productlanding.getCategoryNameByLable(lable).getAttribute("Y"));
				Dimension screensize = PerfectoUtils.getAppiumDriver().manage().window().getSize();
				int screenheight = screensize.getHeight();
				int acceptheight = (int) (screenheight * 0.85);

				if (locatorheight > acceptheight) {
					PerfectoUtils.verticalswipe(80, 75, 2);
					PerfectoUtils.reportMessage("Swiping...");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static boolean validateTextIsPresent(String strText) {
		RegistrastionTestPage register = new RegistrastionTestPage();

		/* Validate the error messages */
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", strText);
		String isErrMsgVisible = (String) register.getTestBase().getDriver().executeScript("mobile:text:find", params1);

		if (isErrMsgVisible.equals("true")) {
			PerfectoUtils.reportMessage(strText + ": is present as expected.");
			return true;
		} else {
			PerfectoUtils.reportMessage(strText + ": is not present in the screen.");
			return false;
		}

	}

	public static void verticalswipeSlow() {

		Dimension size = getAppiumDriver().manage().window().getSize();
		System.out.println("Swiping...");
		int starty = (int) (size.height * 0.80);
		int endy = (int) (size.height * 0.65);
		int startx = size.width / 2;
		getAppiumDriver().swipe(startx, starty, startx, endy, 2);
	}

	public static void swipeIfInBottom(QAFWebElement element) {
		int acceptheight = 0, screenheight, locatorheight = 0, i = 0;
		try {
			do {
				if (element.isPresent()) {
					locatorheight = Integer.parseInt(element.getAttribute("Y"));
					Dimension screensize = PerfectoUtils.getAppiumDriver().manage().window().getSize();
					screenheight = screensize.getHeight();
					acceptheight = (int) (screenheight * 0.80);

					if (locatorheight > acceptheight) {
						Dimension size = PerfectoUtils.getAppiumDriver().manage().window().getSize();
						int starty = (int) (size.height * 0.85);
						int endy = (int) (size.height * 0.80);
						int startx = size.width / 2;
						PerfectoUtils.getAppiumDriver().swipe(startx, starty, startx, endy, 2);
						PerfectoUtils.reportMessage("Swiping...");
						locatorheight = Integer.parseInt(element.getAttribute("Y"));
						i++;
					}
				}
			} while (locatorheight > acceptheight && i < 10);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void swipeIfInBottomForSelectAll(QAFWebElement element) {
		int acceptheight = 0, screenheight, locatorheight = 0, i = 0;
		try {
			do {
				if (element.isPresent()) {
					locatorheight = Integer.parseInt(element.getAttribute("Y"));
					Dimension screensize = PerfectoUtils.getAppiumDriver().manage().window().getSize();
					screenheight = screensize.getHeight();
					acceptheight = (int) (screenheight * 0.90);

					if (locatorheight > acceptheight) {
						Dimension size = PerfectoUtils.getAppiumDriver().manage().window().getSize();
						int starty = (int) (size.height * 0.85);
						int endy = (int) (size.height * 0.80);
						int startx = size.width / 2;
						PerfectoUtils.getAppiumDriver().swipe(startx, starty, startx, endy, 2);
						PerfectoUtils.reportMessage("Swiping...");
						locatorheight = Integer.parseInt(element.getAttribute("Y"));
						i++;
					}
				}
			} while (locatorheight > acceptheight && i < 20);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void swipeIfInRightmost(WebElement element) {

		try {
			if (((QAFExtendedWebElement) element).isPresent()) {
				int locatorwidth = Integer.parseInt(((QAFExtendedWebElement) element).getAttribute("X"));
				Dimension screensize = PerfectoUtils.getAppiumDriver().manage().window().getSize();
				int screenwidth = screensize.getWidth();
				int acceptwidth = (int) (screenwidth * 0.90);

				if (locatorwidth > acceptwidth) {
					IOSStepdef.swipeAndCheckEmail();
					PerfectoUtils.reportMessage("Swiping...");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void getTimetoLoadApp(QAFExtendedWebDriver driver) {
		openApplication(driver, getBundle().getString("app.name"));

		// ReportiumClient.testStart("Validate IOS App has started", new
		// TestContext("IOSapptest"));

		// PMFunctions.textcheckpoint(driver, "body", "primary", 20,
		// MyEnvironmentSettings.AppText);

		long appfinishtime = WindTunnelUtils.timerGet(driver, "ux");

		String timetostartapp = new Long(appfinishtime).toString();

		// ReportiumClient.testStep("Add IOS app load time to report ");

		WindTunnelUtils.reportTimer(driver, appfinishtime, 2000, "Checkpoint load time for IOS app is:",
				timetostartapp);

	}

	/**
	 * Verify element1 is above element2
	 * 
	 * @param element1
	 * @param element2
	 * @return
	 */
	public static boolean verifyOrderOfElements(QAFWebElement element1, QAFWebElement element2) {
		boolean status = false;
		int element1height = 0, element2height = 0;

		element1height = Integer.parseInt(element1.getAttribute("Y"));
		element2height = Integer.parseInt(element2.getAttribute("Y"));

		if (element1height < element2height)
			status = true;

		return status;
	}

	public static void rightSwipe() {

		Dimension size = getAppiumDriver().manage().window().getSize();
		System.out.println("Swiping...");
		int starty = size.height / 2;
		int startx = (int) (size.width * 0.80);
		int endx = (int) (size.width * 0.40);

		getAppiumDriver().swipe(startx, starty, endx, starty, 2);
	}

	public static void verticalswipeSlow(double max, double min) {

		Dimension size = getAppiumDriver().manage().window().getSize();
		System.out.println("Swiping...");
		int starty = (int) (size.height * max);
		int endy = (int) (size.height * min);
		int startx = size.width / 2;
		getAppiumDriver().swipe(startx, starty, startx, endy, 2);
		PerfectoUtils.reportMessage("Swiping..");
	}

	public static ReportiumClient getReportiumClient() {

		ReportiumClient reportiumClient = new ReportiumClientFactory().createLoggerClient();
		return reportiumClient;
	}

	public static void reportMessage(String msg, MessageTypes result) {

		ReportiumClient reportClient = (ReportiumClient) getBundle().getObject(PERFECTO_REPORT_CLIENT);
		boolean asrtResult = false;

		if (result.equals(MessageTypes.Pass) || result.equals(MessageTypes.TestStepPass)) {
			asrtResult = true;
		} else if (result.equals(MessageTypes.Fail) || result.equals(MessageTypes.TestStepFail)) {
			asrtResult = false;
		} else if (result.equals(MessageTypes.Info) || result.equals(MessageTypes.TestStep)
				|| result.equals(MessageTypes.Warn)) {
			asrtResult = true;
		}

		reportClient.reportiumAssert(msg, asrtResult);
		Reporter.log(msg, result);
		assertTrue(asrtResult, msg);

	}

	public static void reportMessage(String msg) {
		PerfectoUtils.reportMessage(msg, MessageTypes.Info);
	}
	
	public static void rightSwipeforrecipes() {

		Dimension size = getAppiumDriver().manage().window().getSize();
		System.out.println("Swiping...");
		int starty = size.height /2;
		int startx = (int) (size.width * 0.80);
		int endx = (int) (size.width * 0.40);

		getAppiumDriver().swipe(startx, starty, endx, starty, 2);
	}
	
	public static void rightSwipeforrecipe() {

		Dimension size = getAppiumDriver().manage().window().getSize();
		System.out.println("Swiping...");
		int starty = size.height /3 ;
		int startx = (int) (size.width * 0.80);
		int endx = (int) (size.width * 0.40);

		getAppiumDriver().swipe(startx, starty, endx, starty, 2);
	}

}
