package com.heb.automation.ios.steps.recipes;

import static com.heb.automation.common.PerfectoUtils.getAppiumDriver;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static com.qmetry.qaf.automation.step.CommonStep.click;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.ShareTestPage;
import com.heb.automation.common.pages.recipes.QuickrecipefinderTestPage;
import com.heb.automation.common.pages.recipes.RecipeboxTestPage;
import com.heb.automation.common.pages.recipes.RecipeboxresultTestPage;
import com.heb.automation.common.pages.recipes.RecipedetailTestPage;
import com.heb.automation.common.pages.recipes.ReciperesultTestPage;
import com.heb.automation.common.pages.recipes.RecipeslandingTestPage;
import com.heb.automation.common.pages.recipes.RefineTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.pages.shoppinglist.ListdetailsTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriessearchresultTestPage;
import com.heb.automation.common.pages.storelocator.StoremapviewTestPage;
import com.heb.automation.common.steps.myaccount.CommonStepDefMyAccounts;
import com.heb.automation.common.steps.recipes.CommonStepDefRecipes;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.heb.automation.ios.steps.IOSStepdef;
import com.heb.automation.ios.steps.myaccount.IOSStepDefMyAccounts;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in Recipes

	I navigate to Recipes
	I see the selected ingredient on selecting single ingredient within corresponding check field
	I navigate back to recipe detail page
	I see scrolling selector appears with users available shopping lists
	I should be able to see the added recipe in my recipe Box
	I see the selected ingredient on selecting all ingredient within corresponding check field
	I delete newly created folder from My Recipe Box
	I create a new folder in My Recipe Box
	I should not see the deleted folder name
	I click on edit folder option
	I select the recipe box to rename
	I enter the new recipe box name
	I click on rename button from the pop-up
	I should see the renamed recipe box
	I revert back the recipe box name
	I select a recipe box
	I validate recipe refine page
	I delete a recipe from the recipe box
	I should not see the deleted recipe
	I see no results error message for search text
	I see no results error message for advance search
	I choose the recipe options {0}{1} in Advanced option
	I Change/Sort the result order of recipe search result page
	I delete all the recipe boxes
	I should able to add the recipe in the recipe Box
	I select the move button from the popup
	I verify the user is having atleast two recipe boxes
	I verify the selected recipe box is not empty
	I verify the moved recipe is present in the recipe box
	I navigate to the selected recipe box page
	I verify the user is having atleast one recipe box
	I verify If added recipe is present in the shopping list
	I select Add to List button
	I enter the existing recipe box name
	I see toast error message
	I click Add button on select shopping list from scrolling selector
	I select a recipe row from recipe box page
	I should see the list of share options
	I should see no result error message
	I navigate back to the recipes page
	I navigate to nutritions info tab in Recipe Detail page
	I select Add to List button from recipe detail page
	I click share button from recipe detail page
	I see My Recipebox page
	I navigate back to recipe page from login page
	I see registration page by clicking on Create an account
	I should see scrolling selector appears with weekly grocery shopping lists
	I navigate to my recipe Box page from recipe detail screen
	I navigate to registration page by clicking login and Register buttons
	I register new user and land in Recipe detail page
	I enter valid search term {0}and select Search button in Recipe screen
*/

public class IOSStepdefrecipes {

	/**
	 * Navigation to recipes from screen.Verifying the Recipe Landing page.
	 */
	@QAFTestStep(description = "I navigate to Recipes")
	public void iNavigateToRecipes() {
		HomeTestPage homepage = new HomeTestPage();
		RecipeslandingTestPage recipepage = new RecipeslandingTestPage();
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();

		ioscommonpage.getAppFooterHomeicon().waitForPresent(5000);
		ioscommonpage.getAppFooterHomeicon().click();

		PerfectoUtils.verticalswipe();

		try {
			PerfectoUtils.swipeIfInBottom(homepage.getHomeLblRecipes());
			homepage.getHomeLblRecipes().click();
			PerfectoUtils.reportMessage("Clicked on Recipes..");
			PerfectoUtils.getReportiumClient().reportiumAssert("Clicked on Recipes", true);

			if (!recipepage.getRecipesFeatured().isPresent()) {
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", "Recipes");
				Object result1 = recipepage.getTestBase().getDriver().executeScript("mobile:text:select", params1);

				if (recipepage.getRecipesFeatured().isPresent()) {
					PerfectoUtils.reportMessage("Navigated to recipe page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Not navigated to recipe page", MessageTypes.Fail);
				}
			} else {
				PerfectoUtils.reportMessage("Navigated to recipe page", MessageTypes.Pass);
			}

		} catch (Exception e) {

			PerfectoUtils.reportMessage("Error occured while navigating to Recipes.", MessageTypes.Fail);
		}
	}

	/**
	 * Selecting the ingredient check box for selecting single ingredient.
	 */
	@QAFTestStep(description = "I see the selected ingredient on selecting single ingredient within corresponding check field")
	public void iSeeTheSelectedIngredientOnSelectingSingleIngredientWithinCorrespondingCheckField() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		// Click on ingredient check box
		PerfectoUtils.verticalswipeSlow();

		if (!recipedetail.getRecipedetailpageAddtolist().isPresent())
			PerfectoUtils.verticalswipeSlow();

		PerfectoUtils.swipeIfInBottom(recipedetail.getRecipedetailpageAddtolist());
		String strIngredient = recipedetail.getRecipedetailpageIngChkbox1text().getText();
		getBundle().setProperty("Ingredient", strIngredient);
		getBundle().setProperty("ingSize", 1);
		recipedetail.getRecipedetailpageIngChkbox1().click();
		PerfectoUtils.reportMessage("Clicked on single ingrdient", MessageTypes.Pass);

	}

	/**
	 * Navigation to Recipe Detail page
	 */
	@QAFTestStep(description = "I navigate back to recipe detail page")
	public void iNavigateBackToRecipeDetailPage() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		// Click on device back button
		ioscommon.getAppBtnBackIOS().click();

		if (recipebox.getRecipeboxSelectbox().isPresent()) {
			ioscommon.getAppBtnBackIOS().click();
		}
	}

	/**
	 * Verification of scrolling selector with users available shopping list.
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I see scrolling selector appears with users available shopping lists")
	public void iSeeScrollingSelectorAppearsWithUsersAvailableShoppingLists() throws InterruptedException {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		recipedetail.getRecipedetailLstpopupHotuserLstname().verifyPresent();
		// Click on bottom list and compare
		String strNewlistName = getBundle().getString("NewListName");
		System.out.println(strNewlistName);
		boolean listSelect = false;
		int i = 0;
		String listName = recipedetail.getRecipedetailLstpopupHotuserLstname().getText();
		do {

			if (!listName.equals(strNewlistName)) {
				String bottomList = recipedetail.getRecipedetailLstpopupHotuserNextLstname().getText();
				recipedetail.getRecipedetailLstpopupHotuserNextLstname().click();
				System.out.println("bottom list:" + bottomList);
				recipedetail.waitForPageToLoad();
				listName = bottomList;
			} else {
				listSelect = true;
			}
			i++;
		} while (!listSelect && i < 30);
		if ((i == 30) && (listSelect = false)) {
			PerfectoUtils.reportMessage("Could not identify correct list!! Delete few lists and try again!!", MessageTypes.Fail);
		}
		String strListName = listName;
		getBundle().setProperty("listName", strListName);
		PerfectoUtils.reportMessage("Selected list: " + strListName, MessageTypes.Pass);
	}

	/**
	 * Clicking on Add recipe box button. Selecting the added recipe box.
	 */
	@QAFTestStep(description = "I should be able to see the added recipe in my recipe Box")
	public void iShouldBeAbleToSeeTheAddedRecipeInMyRecipeBox() {
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		WeeklygroceriesTestPage wGroceries = new WeeklygroceriesTestPage();

		// Click on added recipe box button in recipe detail page
		recipebox.getRecipeboxOpenbox().waitForPresent(3000);
		recipebox.getRecipeboxOpenbox().click();

		// Clicking on selected recipe box
		String strAddedRecipebox = getBundle().getString("AddingRecipebox");
		wGroceries.getShopingListEntryByLable(strAddedRecipebox).waitForPresent(5000);
		wGroceries.getShopingListEntryByLable(strAddedRecipebox).click();

		try {
			if (appcrash.getAppExceptionMsgTitle().isPresent()) {
				String MessageBody = appcrash.getAppExceptionMsg().getText();
				System.out.println("Inside receipe exception");
				System.out.println(MessageBody);

				if (MessageBody.contains("Unable to load Recipe Box")) {
					System.out.println("Unable to load Recipe Box at this time. Please try again.");
					PerfectoUtils.reportMessage("Unable to Load Receipe BOX Error Occured", MessageTypes.TestStepFail);
					appcrash.getExceptionBtnOk().click();
				}
			} else {
				try {
					// Verify if selected recipe is available
					if (wGroceries.getShopingListEntryByLable(getBundle().getString("recipeName")).isPresent()) {
						PerfectoUtils.reportMessage("Added recipe: " + getBundle().getString("recipeName")
								+ ": is present in the box: " + strAddedRecipebox, MessageTypes.Pass);
					} else {
						PerfectoUtils.verticalswipe();
						if (wGroceries.getShopingListEntryByLable(getBundle().getString("recipeName")).isPresent()) {
							if (wGroceries.getShopingListEntryByLable(getBundle().getString("recipeName"))
									.isPresent()) {
								PerfectoUtils.reportMessage("Added recipe: " + getBundle().getString("recipeName")
										+ ": is present in the box: " + strAddedRecipebox, MessageTypes.Pass);
							}
						}
					}
				} catch (Exception e) {
					PerfectoUtils.getAppiumDriver().scrollToExact(getBundle().getString("recipeName"));
					if (wGroceries.getShopingListEntryByLable(getBundle().getString("recipeName")).isPresent()) {
						PerfectoUtils.reportMessage("Added recipe: " + getBundle().getString("recipeName")
								+ ": is present in the box: " + strAddedRecipebox, MessageTypes.Pass);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Selecting All ingredients within corresponding check field.
	 */
	// Only available in iOS-steps available in BDD
	@QAFTestStep(description = "I see the selected ingredient on selecting all ingredient within corresponding check field")
	public void iSeeTheSelectedIngredientOnSelectingAllIngredientWithinCorrespondingCheckField() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		// Scrolling to SelectAll to be Visible
		try {
			PerfectoUtils.scrollToSelectAllInIos();
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured while scrolling to Select All button..", MessageTypes.Fail);
		}

		recipedetail.getRecipedetailpagelblselectall().click();

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Unselect All");
		Object result1 = recipedetail.getTestBase().getDriver().executeScript("mobile:text:find", params1);

		if (result1.equals("true")) {
			PerfectoUtils.reportMessage("Clicked on Selectall button..", MessageTypes.Pass);
		} else {

			// Clicking in Select ALl button Again using Text Object
			try {
				Map<String, Object> params2 = new HashMap<>();
				params2.put("content", "Select All");
				Object result2 = recipedetail.getTestBase().getDriver().executeScript("mobile:text:select", params2);

				// Checking whether the Unselect All option is present
				Map<String, Object> params3 = new HashMap<>();
				params3.put("content", "Unselect All");
				Object result3 = recipedetail.getTestBase().getDriver().executeScript("mobile:text:find", params3);

				if (result3.equals("true")) {
					PerfectoUtils.reportMessage("Clicked on Selectall button..", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Error occured while clicking on Selectall button..", MessageTypes.Fail);
				}

			} catch (Exception e) {
				PerfectoUtils.reportMessage("Error occured while clicking on Selectall button..", MessageTypes.Fail);
			}

		}

		int ingSize = recipedetail.getRecipedetailpageIngList().size();
		PerfectoUtils.reportMessage("Ingredients listed: " + ingSize, MessageTypes.Pass);
		PerfectoUtils.reportMessage("All " + ingSize + " Ingredients are selectedusing Select All option", MessageTypes.Pass);
		getBundle().setProperty("ingSize", ingSize);

		ArrayList<String> arrlist = new ArrayList<String>(ingSize);
		for (QAFWebElement product : recipedetail.getRecipedetailpageIngList()) {
			if ((product.getText()).equals("")) {
				continue;
			}
			arrlist.add(product.getText().trim());
		}
		arrlist.trimToSize();
		getBundle().setProperty("inglist", arrlist);

		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	}

	/**
	 * Deleting the newly created recipe box
	 * 
	 * @param newFolder
	 * @param intStartX
	 * @param intEndX
	 * @param intStartY
	 */
	@QAFTestStep(description = "I delete newly created folder from My Recipe Box")
	public void iDeleteNewlyCreatedFolderFromMyRecipeBox() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		// Delete new folder in android
		String newFolder = getBundle().getString("NewRecipeboxname");
		Dimension size = getAppiumDriver().manage().window().getSize();

		int intStartX = (int) (size.width * 0.90);
		int intEndX = Integer.parseInt(weeklygrocery.getShopingListEntryByLable(newFolder).getAttribute("X"));
		int intStartY = Integer.parseInt(weeklygrocery.getShopingListEntryByLable(newFolder).getAttribute("Y"));

		getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);
		PerfectoUtils.reportMessage("Swiping across the folder name: " + newFolder + " to delete", MessageTypes.Pass);
		click("name=Delete");
		PerfectoUtils.reportMessage("Clicked Delete for list name: " + newFolder + " ", MessageTypes.Pass);
	}

	/**
	 * Checking if no recipe boxes are available, except ALL folder. If no
	 * folder is there, crating a new one. Clicking on edit option.
	 */
	@QAFTestStep(description = "I create a new folder in My Recipe Box")
	public void iCreateANewFolderInMyRecipeBox() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		// Click on + icon
		recipebox.getRecipeboxBtnPlusicon().waitForPresent(7000);
		recipebox.getRecipeboxBtnPlusicon().click();

		// Enter new Recipe box folder
		recipebox.getRecipeboxFolderpopupTitle().waitForPresent(2000);

		// Getting the current time to form the unique recipe box name
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();
		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		String strRecipeboxname = "RB" + strTimeStmp;
		getBundle().setProperty("NewRecipeboxname", strRecipeboxname);

		// Entering the recipe box name in the text box
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(strRecipeboxname);
		recipebox.getRecipeboxFolderpopupBtnAdd().waitForPresent(5000);
		recipebox.getRecipeboxFolderpopupBtnAdd().verifyPresent();
		recipebox.getRecipeboxFolderpopupBtnAdd().click();
		PerfectoUtils.reportMessage("Created a recipe box " + strRecipeboxname, MessageTypes.Pass);

		if (weeklygrocery.getShopingListEntryByLable("Error").isPresent()) {
			PerfectoUtils.reportMessage("Recipe Box Error", MessageTypes.Info);
			weeklygrocery.getShopingListEntryByLable("Ok").click();
		}
	}

	/**
	 * Verifying whether the deleted folder is present or not
	 * 
	 * @param newFolder
	 */
	@QAFTestStep(description = "I should not see the deleted folder name")
	public void iShouldNotSeeTheDeletedFolderName() throws InterruptedException {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		RecipeslandingTestPage recipelandingpage = new RecipeslandingTestPage();

		String newFolder = getBundle().getString("Recipes.folderName");

		// Navigate back to Recipe landing page and enter again into Recipe Box
		ioscommon.getAppBtnBackIOS().click();
		recipelandingpage.getRecipesRecipeboxname().verifyPresent();
		recipelandingpage.getRecipesRecipeboxname().click();

		// Validate the deleted folder is not present
		weeklygrocery.getShopingListEntryByLable(newFolder).waitForNotPresent(5000);

		// Forming the dynamic object
		if (weeklygrocery.getShopingListEntryByLable(newFolder).verifyNotVisible()) {
			PerfectoUtils.reportMessage("Deleted Folder in My Recipe Box: " + newFolder + " is not displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Deleted Folder in My Recipe Box: " + newFolder + " is displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Checking if no recipe boxes are available, except ALL folder. If no
	 * folder is there, crating a new one. Clicking on edit option.
	 */
	@QAFTestStep(description = "I click on edit folder option")
	public void iClickOnEditFolderOption() {
		PerfectoUtils.reportMessage("Step not applicable for iOS", MessageTypes.Pass);
	}

	/**
	 * Selecting a recipe box to rename
	 */
	@QAFTestStep(description = "I select the recipe box to rename")
	public void iSelectTheRecipeBoxToRename() {
		PerfectoUtils.reportMessage("Step not applicable for iOS", MessageTypes.Pass);
	}

	/**
	 * Entering the new recipe box name
	 */
	@QAFTestStep(description = "I enter the new recipe box name")
	public void iEnterTheNewRecipeBoxName() {
		PerfectoUtils.reportMessage("Step not applicable for iOS", MessageTypes.Pass);
	}

	/**
	 * Updating the previous recipe box name
	 */
	@QAFTestStep(description = "I click on rename button from the pop-up")
	public void iClickOnRenameButtonFromThePopUp() {
		PerfectoUtils.reportMessage("Step not applicable for iOS", MessageTypes.Pass);
	}

	/**
	 * Verifying the new folder in my recipe box page
	 * 
	 * @param strNewRecipeboxname
	 */
	@QAFTestStep(description = "I should see the renamed recipe box")
	public void iShouldSeeTheRenamedRecipeBox() {
		PerfectoUtils.reportMessage("Step not applicable for iOS", MessageTypes.Pass);
	}

	/**
	 * CLicking on Edit folder for reverting back recipe box name. Updating the
	 * previous recipe box name
	 */
	@QAFTestStep(description = "I revert back the recipe box name")
	public void iRevertBackTheRecipeBoxName() {
		PerfectoUtils.reportMessage("Step not applicable for iOS", MessageTypes.Pass);
	}

	/**
	 * Selecting the first recipe box
	 */
	@QAFTestStep(description = "I select a recipe box")
	public void iSelectARecipeBox() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		RecipeboxresultTestPage recipeboxresult = new RecipeboxresultTestPage();

		int listsize = recipebox.getLblRecipenameslist().size();

		// Clicking on first recipe box
		String strRecipeboxname = recipebox.getLblRecipenameslist().get(listsize - 2).getText();
		getBundle().setProperty("Recipeboxname", strRecipeboxname);
		getBundle().setProperty("AddingRecipebox", strRecipeboxname);
		recipebox.getLblRecipenameslist().get(listsize - 2).click();
		PerfectoUtils.reportMessage("Selected recipe box: " + strRecipeboxname, MessageTypes.Pass);

		if (!recipeboxresult.getlblpagetitle(strRecipeboxname).isPresent()) {
			recipebox.getLblRecipenameslist().get(listsize - 2).click();
		}
		recipeboxresult.getlblpagetitle(strRecipeboxname).verifyPresent();
	}

	/**
	 * Verifying the recipe refine page
	 */
	@QAFTestStep(description = "I validate recipe refine page")
	public void iValidateRecipeRefinePage() {
		ReciperesultTestPage reciperesult = new ReciperesultTestPage();

		if (reciperesult.getRefineLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Able to see refine page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see refine page", MessageTypes.Fail);
		}
	}

	/**
	 * Selecting a recipe from recipe box to delete
	 */
	@QAFTestStep(description = "I delete a recipe from the recipe box")
	public void iDeleteARecipeFromTheRecipeBox() {
		RecipeboxresultTestPage recipeboxresult = new RecipeboxresultTestPage();
		WeeklygroceriesTestPage wgroceries = new WeeklygroceriesTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		String recipeName = "";

		try {

			// Deleting first recipe in the box
			PerfectoUtils.reportMessage("Deleting recipe " + recipeName + " from the recipe box..", MessageTypes.Info);
			int recipenamelistsize = recipeboxresult.getRecipeboxresultLblRecipename().size();
			String strDeletingRecipename = recipeboxresult.getRecipeboxresultLblRecipename().get(recipenamelistsize - 1)
					.getText();
			getBundle().setProperty("DeletingRecipename", strDeletingRecipename);
			System.out.println(strDeletingRecipename);
			recipeboxresult.getRecipeboxresultBtnDeleterecipe().get(recipenamelistsize - 1).click();
			recipeboxresult.getPopupBtndelete().waitForPresent(5000);
			recipeboxresult.getPopupBtndelete().click();

			// Navigating back and clicking on the selected recipe box for
			// verification
			ioscommon.getAppBtnBackIOS().waitForPresent(3000);
			ioscommon.getAppBtnBackIOS().verifyPresent();
			ioscommon.getAppBtnBackIOS().click();
			String straddedbox = getBundle().getString("AddingRecipebox");
			wgroceries.getShopingListEntryByLable(straddedbox).verifyPresent();
			getBundle().setProperty("Recipeboxname", straddedbox);
			wgroceries.getShopingListEntryByLable(straddedbox).click();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Verifying whether the deleted recipe is present in the recipe box or not
	 */
	@QAFTestStep(description = "I should not see the deleted recipe")
	public void iShouldNotSeeTheDeletedRecipe() {
		RecipeboxresultTestPage recipebox = new RecipeboxresultTestPage();
		String strDeletedRecipe = getBundle().getString("DeletingRecipename");
		String strRecipeboxname = getBundle().getString("Recipeboxname");

		int listsize = recipebox.getRecipeboxresultLblRecipename().size();

		// Checking if no items are available
		if (listsize != 0) {

			// Comparing the name of the first recipe with the deleted recipe
			if (!recipebox.getRecipeboxresultLblRecipename().get(listsize - 1).getText()
					.equalsIgnoreCase(strDeletedRecipe)) {
				PerfectoUtils.reportMessage("Deleted the recipe: " + strDeletedRecipe + "from recipe box: " + strRecipeboxname,
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Delete not successful!", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("Deleted the recipe: " + strDeletedRecipe + " from recipe box: " + strRecipeboxname,
					MessageTypes.Pass);
		}
	}

	/**
	 * Verifying the no result error message
	 */
	@QAFTestStep(description = "I see no results error message for search text")
	public void iSeeNoResultsErrorMessageForSearchText() {
		RecipeslandingTestPage recipelanding = new RecipeslandingTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		// Verify the landing page
		if (weeklygrocery.getShopingListEntryByLable("No results found").isPresent()) {
			PerfectoUtils.reportMessage("No Results found error message is displayed", MessageTypes.Pass);
		}

		if (recipelanding.getRecipesFeatured().isPresent()) {
			PerfectoUtils.reportMessage("No Results found for the entered search text", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Results found for the entered search text", MessageTypes.Fail);
		}
	}

	/**
	 * Verifying Recipe not found pop up is coming or not
	 */
	@QAFTestStep(description = "I see no results error message for advance search")
	public void iSeeNoResultsErrorMessageForAdvanceSearch() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		// Verify the landing page
		if (weeklygrocery.getShopingListEntryByLable("No results matched search terms").isPresent()) {
			PerfectoUtils.reportMessage("No Results found error message is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("No Results found error message is not displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking on Quick Recipe Finder button. Selecting a recipe by Meal and by
	 * Ingredients. Clicking on Find button.
	 * 
	 * @param strRecipeByMeal
	 * @param strRecipeByIng
	 */
	@QAFTestStep(description = "I choose the recipe options {0}{1} in Advanced option")
	public void iChooseTheRecipeOptionsInAdvancedOption(String strRecipeByMeal, String strRecipeByIng) {
		QuickrecipefinderTestPage recipefinder = new QuickrecipefinderTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		recipefinder.getQuickfinderBtnAdvancedtab().waitForPresent(3000);
		recipefinder.getQuickfinderBtnAdvancedtab().click();
		recipefinder.waitForPageToLoad();

		// Select Recipes in Advance search
		weeklygrocery.getShopingListEntryByLable(strRecipeByMeal).click();
		PerfectoUtils.reportMessage("Recipe by Meal has selected");
		IOSStepdef.scrollToListNameInMyList(strRecipeByIng);
		weeklygrocery.getShopingListEntryByLable(strRecipeByIng).click();
		PerfectoUtils.reportMessage("Recipe by Ingredient has selected");

		// Click on Find button
		recipefinder.getQuickfinderFind().click();
		PerfectoUtils.reportMessage("Clicked on Recipe Quick finder..");
	}

	/**
	 * Selecting the sort option for the recipes. Clicking on done button.
	 */
	@QAFTestStep(description = "I Change/Sort the result order of recipe search result page")
	public void iChangeSortTheResultOrderOfRecipeSearchResultPage() {
		RefineTestPage refinepage = new RefineTestPage();

		refinepage.getRefineLblPagetitle().verifyPresent();
		refinepage.getRefineLblBymeal().verifyPresent();
		refinepage.getLblFilterbymeal().click();
		PerfectoUtils.reportMessage("Clicked on Filter by Meal option..", MessageTypes.Pass);
		IOSStepdef.scrollToListNameInMyList("BY INGREDIENT");
		if (refinepage.getLblFilterbynutrition().isPresent())
			refinepage.getLblFilterbynutrition().click();
		else {
			PerfectoUtils.verticalswipeSlow();
			refinepage.getLblFilterbynutrition().click();
		}
		PerfectoUtils.reportMessage("Clicked on Filter by Nutrition option..");
		// PerfectoUtils.horizontalswipe();
		refinepage.getRefineBtnRefine().waitForPresent(3000);
		refinepage.getRefineBtnRefine().verifyPresent();
		refinepage.getRefineBtnRefine().click();
		PerfectoUtils.reportMessage("Clicked on Refine button..");
	}

	/**
	 * Swiping across the folder names to delete all the recipe boxes.
	 */
	@QAFTestStep(description = "I delete all the recipe boxes")
	public void iDeleteAllTheRecipeBoxes() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		int listsize = recipebox.getLblRecipenameslist().size();

		// Checking if no recipe boxes are available, except ALL folder
		if (listsize > 1) {
			for (int i = 1; i <= listsize; i++) {
				// Deleting the recipe boxes using swipe action
				if ((!recipebox.getRecipeboxnamelist(i).getText().equalsIgnoreCase("ALL"))
						&& (recipebox.getRecipeboxlist(i).getAttribute("hidden")).equals("false")) {
					String newFolder = recipebox.getRecipeboxnamelist(i).getText();
					Dimension size = getAppiumDriver().manage().window().getSize();

					int intStartX = (int) (size.width * 0.90);
					int intEndX = Integer
							.parseInt(weeklygrocery.getShopingListEntryByLable(newFolder).getAttribute("X"));
					int intStartY = Integer
							.parseInt(weeklygrocery.getShopingListEntryByLable(newFolder).getAttribute("Y"));
					getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);
					if (recipebox.getRecipeboxDelete().isPresent()) {
						recipebox.getRecipeboxDelete().click();
					}
					recipebox.getLblRecipenameslist().get(i - 1).waitForPresent(5000);
					PerfectoUtils.reportMessage("Swiping across the folder name: " + newFolder + " to delete", MessageTypes.Pass);
				}
			}
			PerfectoUtils.reportMessage("Deleted the recipe boxes.", MessageTypes.Info);
		}

		listsize = recipebox.getLblRecipenameslist().size();
		if (listsize < 2) {
			PerfectoUtils.reportMessage("No recipe boxes available.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("List in Recipe box is not deleted", MessageTypes.Pass);
		}
	}

	/**
	 * Adding the recipe in the recipe box.
	 */
	@QAFTestStep(description = "I should able to add the recipe in the recipe Box")
	public void iShouldAbleToAddTheRecipeInTheRecipeBox() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		// Click on Add to Box button
		recipedetail.getRecipedetailpageAddtoBox().waitForPresent(1000);
		recipedetail.getRecipedetailpageAddtoBox().click();
		PerfectoUtils.reportMessage("Clicked on Add to Recipe box button..");

		// Click add in choose folder pop up with default folder
		recipebox.getRecipeboxAddtobox().waitForPresent(3000);
		recipebox.getRecipeboxAddtobox().verifyPresent();
		int listsize = recipedetail.getLblPopuprecipeboxnameslist().size();
		String strAddingRecipebox = recipedetail.getLblPopuprecipeboxnameByLable(listsize).getText();
		getBundle().setProperty("AddingRecipebox", strAddingRecipebox);
		recipebox.getRecipeboxAddtobox().click();
		PerfectoUtils.reportMessage("Clicked On Done Button.");
		PerfectoUtils.reportMessage("Added the recipes to recipebox: " + strAddingRecipebox, MessageTypes.Pass);
	}

	/**
	 * Selecting move button form pop up
	 */
	@QAFTestStep(description = "I select the move button from the popup")
	public void iSelectTheMoveButtonFromThePopup() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		if (recipebox.getRecipeboxAddtobox().isPresent()) {

			// Click 'Move' in choose folder pop up with default folder
			int listsize = recipedetail.getLblPopuprecipeboxnameslist().size();
			System.out.println(listsize);
			String strAddingRecipebox = recipedetail.getLblPopuprecipeboxnameByLable(listsize).getText();
			getBundle().setProperty("AddingRecipebox", strAddingRecipebox);

			recipebox.getRecipeboxAddtobox().click();
			PerfectoUtils.reportMessage("Clicked On Done Button.", MessageTypes.Pass);
		}
	}

	/**
	 * Verifying whether two recipe box are there or not. If not, then creating
	 * new folder.
	 */
	@QAFTestStep(description = "I verify the user is having atleast two recipe boxes")
	public void iVerifyTheUserIsHavingAtleastTwoRecipeBoxes() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		RecipeslandingTestPage recipelandingpage = new RecipeslandingTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		int listsize = recipebox.getLblRecipenameslist().size();
		int count = 0;

		// Checking if user is having less than two recipe boxes, except ALL
		// folder
		if (listsize < 3) {

			while (listsize != 3) {
				// Creating a new recipe box
				iCreateANewFolderInMyRecipeBox();

				// Navigating back to My recipe box page to get the refreshed
				// size
				ioscommon.getAppBtnBackIOS().click();
				recipelandingpage.getRecipesRecipeboxname().waitForPresent(5000);
				recipelandingpage.getRecipesRecipeboxname().click();

				count++;
				listsize = recipebox.getLblRecipenameslist().size();
			}
			PerfectoUtils.reportMessage("Created" + count + " recipe boxes.", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("User is having" + (listsize - 1) + " recipe boxes", MessageTypes.Info);
		}
	}

	/**
	 * Navigating to recipe box. Getting the recipe name. Clicking on first
	 * recipe.
	 */
	@QAFTestStep(description = "I verify the selected recipe box is not empty")
	public void iVerifyTheSelectedRecipeBoxIsNotEmpty() {
		RecipeboxresultTestPage recipeboxresult = new RecipeboxresultTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		RecipedetailTestPage recipedetails = new RecipedetailTestPage();
		RecipeslandingTestPage recipelandingpage = new RecipeslandingTestPage();
		ReciperesultTestPage reciperesult = new ReciperesultTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		String strRecipeboxname = "";
		int listsize = recipeboxresult.getRecipeboxresultLblRecipename().size();

		try {
			if (listsize == 0) {
				PerfectoUtils.reportMessage("No recipes found! adding recipes to the recipe box.", MessageTypes.Info);

				// Navigating to recipes landing page
				ioscommon.getAppBtnBackIOS().click();
				ioscommon.getAppBtnBackIOS().waitForPresent(5000);
				ioscommon.getAppBtnBackIOS().click();

				// Adding the recipes to recipe box
				recipelandingpage.getRecipesFeatured().waitForPresent(10000);
				recipelandingpage.getRecipesFeatured().click();
				PerfectoUtils.reportMessage("Clicked on Recipe Featured Image from Recipe landing page.", MessageTypes.Pass);

				if (reciperesult.getReciperesultCount().isPresent()) {
					// Getting recipe name
					String recipeName = reciperesult.getReciperesultRecipename().getText();
					getBundle().setProperty("recipeName", recipeName);

					// Click on first recipe
					reciperesult.getReciperesultItem1().waitForPresent(3000);
					reciperesult.getReciperesultItem1().click();

					iShouldAbleToAddTheRecipeInTheRecipeBox();

					// Navigating back to My Recipe box page
					recipedetails.getRecipedetailpageHeaderRecipeboxbutton().click();

					// Clicking on first recipe box
					strRecipeboxname = getBundle().getString("AddingRecipebox");
					try {
						weeklygrocery.getShopingListEntryByLable(strRecipeboxname).click();
					} catch (Exception e) {
						e.printStackTrace();
						Map<String, Object> params1 = new HashMap<>();
						params1.put("content", strRecipeboxname);
						Object result1 = recipeboxresult.getTestBase().getDriver().executeScript("mobile:text:select",
								params1);
					}

					PerfectoUtils.reportMessage("Added the recipe " + recipeName + " in to the recipe box " + strRecipeboxname,
							MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Not Navigated to next page on Clicking featured Image from recipe landing page.",
							MessageTypes.Fail);
				}
			}

			listsize = recipeboxresult.getRecipeboxresultLblRecipename().size();

			// Getting recipe name
			String recipeName = recipeboxresult.getRecipeboxresultLblRecipename().get(listsize - 1).getText();
			getBundle().setProperty("recipeName", recipeName);
			PerfectoUtils.reportMessage("The recipe box " + strRecipeboxname + " is not empty.", MessageTypes.Pass);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Verifying whether the moved recipe is present in the recipe box or not.
	 */
	@QAFTestStep(description = "I verify the moved recipe is present in the recipe box")
	public void iVerifyTheMovedRecipeIsPresentInTheRecipeBox() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String strMovedRecipename = getBundle().getString("recipeName");
		System.out.println(strMovedRecipename);
		int i = 0;

		// Swiping to see the added recipe
		while ((!weeklygrocery.getShopingListEntryByLable(strMovedRecipename).isPresent()) && i < 5) {
			PerfectoUtils.verticalswipeSlow();
			i++;
		}

		if (weeklygrocery.getShopingListEntryByLable(strMovedRecipename).isPresent()) {
			PerfectoUtils.reportMessage("The moved recipe: " + strMovedRecipename + " is present in the recipe box.",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("The moved recipe: " + strMovedRecipename + " is not present in the recipe box.",
					MessageTypes.Fail);
		}
	}

	/**
	 * Navigating to the selected recipe box.
	 * 
	 * @param selectedBox
	 */
	@QAFTestStep(description = "I navigate to the selected recipe box page")
	public void iNavigateToTheSelectedRecipeBoxPage() {
		WeeklygroceriesTestPage wgroceries = new WeeklygroceriesTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		RecipeslandingTestPage recipelandingpage = new RecipeslandingTestPage();

		String selectedBox = "";

		// NaVigating back to make the recipe box icon in the header- visible
		ioscommon.getAppBtnBackIOS().click();
		selectedBox = getBundle().getString("AddingRecipebox");

		try {
			if (wgroceries.getShopingListEntryByLable(selectedBox).isPresent()) {
				wgroceries.getShopingListEntryByLable(selectedBox).click();
				recipelandingpage.getRecipesRecipeboxname().waitForNotPresent(5000);
				PerfectoUtils.reportMessage("Navigated to box: " + selectedBox, MessageTypes.Pass);
			} else {
				PerfectoUtils.verticalswipe();
				wgroceries.getShopingListEntryByLable(selectedBox).waitForPresent(3000);
				wgroceries.getShopingListEntryByLable(selectedBox).click();
				recipelandingpage.getRecipesRecipeboxname().waitForNotPresent(5000);
				PerfectoUtils.reportMessage("Navigated to box: " + selectedBox, MessageTypes.Pass);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Verifying atleast one recipe box is present or not If not, then creating
	 * the new folder
	 */
	@QAFTestStep(description = "I verify the user is having atleast one recipe box")
	public void iVerifyTheUserIsHavingAtleastOneRecipeBox() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		int listsize = recipebox.getLblRecipenameslist().size();

		// Checking if no recipe boxes are available, except ALL folder
		if (listsize <= 1) {
			iCreateANewFolderInMyRecipeBox();
		}
	}

	/**
	 * Clicking the selected shopping List. Verifying whether the added recipe
	 * is present in the shopping list or not.
	 */
	@QAFTestStep(description = "I verify If added recipe is present in the shopping list")
	public void iVerifyIfAddedRecipeIsPresentInTheShoppingList() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String strAddedIngredient = getBundle().getString("recipeName");

		// Click on selected shopping list
		try {
			weeklygrocery.getShopingListEntryByLable(getBundle().getString("listName")).click();
		} catch (Exception e) {
			IOSStepdef.scrollToListNameInMyList(getBundle().getString("listName"));
		}

		// Verify if selected ingredient is available
		if (weeklygrocery.getShopingListEntryByLable(strAddedIngredient).isPresent()) {
			PerfectoUtils.reportMessage("Added recipe: " + strAddedIngredient + ": is present.", MessageTypes.Pass);
		} else {
			PerfectoUtils.verticalswipe();
			if (weeklygrocery.getShopingListEntryByLable(strAddedIngredient).isPresent()) {
				PerfectoUtils.reportMessage("Added recipe: " + strAddedIngredient + ": is present.", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Added recipe: " + strAddedIngredient + ": not present", MessageTypes.Fail);
			}
		}
	}

	/**
	 * Clicking on Add to List button from recipe detail page.
	 */
	@QAFTestStep(description = "I select Add to List button")
	public void iSelectAddToListButton() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();
		int getsize = 0;

		try {
			recipedetail.waitForPageToLoad();
			getsize = recipedetail.getLblRecipelist().size();
			recipedetail.getBtnAddtolistListByLable(getsize).click();
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Add to List button has not found", MessageTypes.Fail);
		}
	}

	/**
	 * Entering the existing name in the rename pop up
	 */
	@QAFTestStep(description = "I enter the existing recipe box name")
	public void iEnterTheExistingRecipeBoxName() {
		PerfectoUtils.reportMessage("Step not applicable for iOS", MessageTypes.Pass);
	}

	/**
	 * Verifying the error toast message.
	 */
	@QAFTestStep(description = "I see toast error message")
	public void iSeeToastErrorMessage() {
		PerfectoUtils.reportMessage("Step not applicable for iOS", MessageTypes.Pass);

	}

	/**
	 * Clicking Add button from scrolling selector
	 */
	@QAFTestStep(description = "I click Add button on select shopping list from scrolling selector")
	public void iClickAddButtonOnSelectShoppingListFromScrollingSelector() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		// Clicking on add button
		ioscommon.getAddtolistBtnDone().isDisplayed();
		ioscommon.getAddtolistBtnDone().verifyPresent();
		ioscommon.getAddtolistBtnDone().click();
	}

	/**
	 * Getting the recipe name. Selecting the first recipe row.
	 */
	@QAFTestStep(description = "I select a recipe row from recipe box page")
	public void iSelectARecipeRowFromRecipeBoxPage() {
		RecipeboxresultTestPage recipeboxresult = new RecipeboxresultTestPage();

		int listsize = recipeboxresult.getRecipeboxresultLblRecipename().size();

		// Getting recipe name
		String recipeName = recipeboxresult.getRecipeboxresultLblRecipename().get(listsize - 1).getText();
		getBundle().setProperty("recipeName", recipeName);
		System.out.println(recipeName);

		// Click on first recipe
		recipeboxresult.getImgRecipeimage().get(listsize - 1).click();
	}

	/**
	 * Verification of Share options
	 */
	@QAFTestStep(description = "I should see the list of share options")
	public void iShouldSeeTheListOfShareOptions() {
		RecipedetailTestPage recipedetails = new RecipedetailTestPage();

		recipedetails.getRecipedetailLblShareemail().verifyPresent();
		recipedetails.getLblSharereminders().verifyPresent();
		recipedetails.getLblShareaddtonotes().verifyPresent();
		recipedetails.getLblSharemore().verifyPresent();
	}

	/**
	 * Verifying the error message of no result.
	 */
	@QAFTestStep(description = "I should see no result error message")
	public void iShouldSeeNoResultErrorMessage() {
		QuickrecipefinderTestPage quickfinder = new QuickrecipefinderTestPage();

		try {
			quickfinder.getQuickfinderBtnQuickfindertab().waitForNotPresent(5000);
			PerfectoUtils.reportMessage("Unable to see no result error message", MessageTypes.Fail);

		} catch (Exception e) {
			PerfectoUtils.reportMessage("Able to see no result error message", MessageTypes.Pass);
		}
	}

	/**
	 * Navigating back to recipes landing page.
	 */
	@QAFTestStep(description = "I navigate back to the recipes page")
	public void iNavigateBackToTheRecipesPage() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		RecipeslandingTestPage recipelanding = new RecipeslandingTestPage();

		// Navigating to recipes landing page
		ioscommon.getAppBtnBackIOS().click();

		if (recipelanding.getRecipesPagename().isPresent()) {
			PerfectoUtils.reportMessage("Able to see recipes page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see recipes page", MessageTypes.Fail);
		}
	}

	/**
	 * Navigation to nutrition tab.
	 */
	@QAFTestStep(description = "I navigate to nutritions info tab in Recipe Detail page")
	public void iNavigateToNutritionsInfoTabInRecipeDetailPage() {
		RecipedetailTestPage recipedetailpage = new RecipedetailTestPage();

		if (!recipedetailpage.getRecipedetailLblNutritioninfo().isPresent()) {
			IOSStepdef.scrollToElement("Nutrition Info");
		}

		recipedetailpage.getRecipedetailLblNutritioninfo().waitForPresent(5000);
		recipedetailpage.getRecipedetailLblNutritioninfo().click();
	}

	/**
	 * Clicking on Add to List button from recipe detail page.
	 */
	@QAFTestStep(description = "I select Add to List button from recipe detail page")
	public void iSelectAddToListButtonFromRecipeDetailPage() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		recipedetail.waitForPageToLoad();
		QAFWebElement addToLst = recipedetail.getRecipedetailpageAddtolist();

		recipedetail.waitForPageToLoad();
		if (!recipedetail.getRecipedetailpageAddtolist().isPresent())
			PerfectoUtils.verticalswipeSlow();

		PerfectoUtils.swipeIfInBottom(addToLst);

		recipedetail.getRecipedetailpageAddtolist().click();
	}

	/**
	 * Verifying the share button. Clicking on share button.
	 */
	@QAFTestStep(description = "I click share button from recipe detail page")
	public void iClickShareButtonFromRecipeDetailPage() {
		RecipedetailTestPage recipedetailpage = new RecipedetailTestPage();
		ShareTestPage sharepage = new ShareTestPage();

		// Click on share icon in the left hand side of recipe detail page
		recipedetailpage.getRecipedetailpageHeaderSharebutton().waitForPresent(3000);
		recipedetailpage.getRecipedetailpageHeaderSharebutton().click();

		if (!sharepage.getBtnCancel().isPresent()) {
			recipedetailpage.getRecipedetailpageHeaderSharebutton().click();
		}
	}

	/**
	 * Verifying the My Recipe box page title
	 */
	@QAFTestStep(description = "I see My Recipebox page")
	public void iSeeMyRecipeboxPage() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		recipebox.getRecipeboxLblPagetitle().waitForPresent(10000);
		recipebox.getRecipeboxLblPagetitle().verifyPresent("My Recipe Box");
		PerfectoUtils.reportMessage("Navigated to my recipe box page", MessageTypes.Info);
	}

	/**
	 * Navigating back to recipe page from login page
	 */
	@QAFTestStep(description = "I navigate back to recipe page from login page")
	public void iNavigateBackToRecipePageFromLoginPage() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		loginsplash.getLoginLblContinue().click();
		PerfectoUtils.reportMessage("Navigating back from Recipe page", MessageTypes.Info);
		PerfectoUtils.reportMessage("Clicked on Continue as Guest user", MessageTypes.Info);
	}

	/**
	 * Clicking on create account. Verifying the registration page.
	 */
	@QAFTestStep(description = "I see registration page by clicking on Create an account")
	public void iSeeRegistrationPageByClickingOnCreateAnAccount() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		RegistrastionTestPage registration = new RegistrastionTestPage();
		IOSStepDefMyAccounts iosmyaccount = new IOSStepDefMyAccounts();

		recipebox.getMyrecipeboxBtnCreateanaccount().verifyPresent();
		recipebox.getMyrecipeboxBtnCreateanaccount().click();
		PerfectoUtils.reportMessage("Clicked on Create ab Account..");

		iosmyaccount.byTappingAnywhereClickingDeviceBackButtonShouldDismissTheKeyboard();

		if (registration.getRegistrationTxtFirstname().isPresent()) {
			PerfectoUtils.reportMessage("Able to see registration page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see registration page", MessageTypes.Fail);
		}

	}

	/**
	 * Verifying the pop up title. Verifying the list name in add to list pop
	 * up.
	 */
	@QAFTestStep(description = "I should see scrolling selector appears with weekly grocery shopping lists")
	public void iShouldSeeScrollingSelectorAppearsWithWeekyGroceryShoppingLists() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		String strListName = "";

		// Verify list name is present
		recipedetail.getRecipedetailLstpopupHotuserNextLstname().waitForPresent(50000);
		recipedetail.getRecipedetailLstpopupHotuserNextLstname().verifyPresent();

		if (recipedetail.getRecipedetailLstpopupHotuserLstname().isPresent()) {
			strListName = recipedetail.getRecipedetailLstpopupHotuserLstname().getText();
		} else if (recipedetail.getRecipedetailLstpopupHotuserNextLstname().isPresent()) {
			strListName = recipedetail.getRecipedetailLstpopupHotuserNextLstname().getText();
		}

		getBundle().setProperty("listName", strListName);
	}

	/**
	 * Clicking and Validating My Recipe box page.
	 */
	@QAFTestStep(description = "I navigate to my recipe Box page from recipe detail screen")
	public void iNavigateToMyRecipeBoxPageFromRecipeDetailScreen() {
		RecipedetailTestPage recipedetailspage = new RecipedetailTestPage();
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		// Click on My Recipe Box
		recipedetailspage.getRecipedetailpageHeaderRecipeboxbutton().verifyPresent();
		recipedetailspage.getRecipedetailpageHeaderRecipeboxbutton().click();
		// Validate Login splash page
		loginsplash.getLoginTxtEmail().waitForPresent(3000);
		loginsplash.getLoginTxtEmail().verifyPresent();
		loginsplash.getLoginBtnRegister().verifyPresent();
	}

	/**
	 * Clicking and Validating My Recipe box page.
	 */
	@QAFTestStep(description = "I navigate to registration page by clicking login and Register buttons")
	public void iNavigateToRegistrationPageByClickingLoginAndRegisterButtons() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		recipedetail.getRecipedetailpageHeaderRecipeboxbutton().verifyPresent();
		recipedetail.getRecipedetailpageHeaderRecipeboxbutton().click();
		PerfectoUtils.reportMessage("Clicked: on login button", MessageTypes.Pass);

		loginsplash.getLoginBtnRegister().verifyPresent();
		loginsplash.getLoginBtnRegister().click();
		PerfectoUtils.reportMessage("Clicked: on Register button", MessageTypes.Pass);
		
	}
	
	/**
	 * I register new user and land in Recipe detail page
	 */
	@QAFTestStep(description = "I register new user and land in Recipe detail page")
	public void iRegisterNewUserAndLandInRecipeDetailPage() {
		IOSStepDefMyAccounts.iEnterAllRequiredFieldsInRegisterationPage();
		IOSStepdef.iSubmitTheRegisterationForm();
		CommonStepDefMyAccounts.iNavigateToWantMorePageOnClickingSkipForNow();
		CommonStepDefMyAccounts.iClickDoneFromWantMorePage();
		CommonStepDefRecipes.iShouldSeeTheRecipeDetailScreen();
	}
	
	/**
	 * Entering search term "productName" in Search text field, Click search
	 * button from keyboard. Wait till the loading image disappears. Handle
	 * store location error.
	 * 
	 * @param productName
	 *            search term or product name
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I enter valid search term {0}and select Search button in Recipe screen")
	public void iEnterValidSearchTermAndSelectSearchButtonInRecipeScreen(String productName) throws InterruptedException {

		IoscommonTestPage ioscommon = new IoscommonTestPage();
		StoremapviewTestPage mapview = new StoremapviewTestPage();
		RecipeslandingTestPage recipelanding = new RecipeslandingTestPage();

		try {
			recipelanding.getRecipesTxtSearchProducts().waitForPresent(10000);
			recipelanding.getRecipesTxtSearchProducts().click();

		} catch (Exception e) {
			mapview.getStorelocatorIconSearch().click();
		}
		
		getBundle().setProperty("productName", productName);

		// Enter input search term and click search button on keyboard
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(productName);

		// new search icon click function
		Map<String, Object> param1 = new HashMap<>();
		param1.put("keySequence", "KEYBOARD_SEARCH");
		PerfectoUtils.getAppiumDriver().executeScript("mobile:presskey", param1);

		try {
			ioscommon.getAppLblLoading().waitForPresent(3000);
			ioscommon.getAppLblLoading().waitForNotPresent(15000);
		} catch (Exception e) {
			// ignore..
		}
	}

}
