package com.heb.automation.common.components;

import com.heb.automation.common.pages.products.ProductdetailTestPage;
import com.heb.automation.common.pages.products.ProductsresultlistTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ProductResult extends QAFWebComponent {

	@FindBy(locator = "prodsearchresult.btn.addtolist")
	private QAFWebElement productresultBtnAddtolist;	
	@FindBy(locator = "productresult.lbl.childproductname")
	private QAFWebElement productresultLblProductname;
	@FindBy(locator = "productresult.lbl.productprize")
	private QAFWebElement productresultLblProductprize;
	@FindBy(locator = "productresult.img.productimage")
	private QAFWebElement productresultImgProductimage;
	@FindBy(locator = "productresult.img.productlocation")
	private QAFWebElement productresultImgProductlocation;
	@FindBy(locator = "productresult.lbl.allproducts")
	private QAFWebElement productresultLblAllproducts;
	@FindBy(locator = "productresult.lbl.allproductscount")
	private QAFWebElement productresultLblAllproductscount;
	@FindBy(locator = "productresult.lbl.inmystore")
	private QAFWebElement productresultLblInmystore;
	@FindBy(locator = "productresult.lbl.inmystorecount")
	private QAFWebElement productresultLblInmystorecount;
	@FindBy(locator = "productresult.lbl.ship2home")
	private QAFWebElement productresultLblShip2home;
	@FindBy(locator = "productresult.lbl.ship2homecount")
	private QAFWebElement productresultLblShip2homecount;

	public ProductResult(String locator) {
		super(locator);
	}

	public QAFWebElement getProductresultBtnAddtolist() {
		return productresultBtnAddtolist;
	}

	/*public QAFWebElement getProductresultBtnAddtocart() {
		return productresultBtnAddtocart;
	}*/

	public QAFWebElement getProductresultLblProductname() {
		return productresultLblProductname;
	}
	
	public QAFWebElement getProductresultLblProductprize() {
		return productresultLblProductprize;
	}

	public QAFWebElement getProductresultImgProductimage() {
		return productresultImgProductimage;
	}

	public QAFWebElement getProductresultImgProductlocation() {
		return productresultImgProductlocation;
	}

	public QAFWebElement getProductresultLblAllproducts() {
		return productresultLblAllproducts;
	}

	public QAFWebElement getProductresultLblAllproductscount() {
		return productresultLblAllproductscount;
	}

	public QAFWebElement getProductresultLblInmystore() {
		return productresultLblInmystore;
	}

	public QAFWebElement getProductresultLblInmystorecount() {
		return productresultLblInmystorecount;
	}

	public QAFWebElement getProductresultLblShip2home() {
		return productresultLblShip2home;
	}

	public QAFWebElement getProductresultLblShip2homecount() {
		return productresultLblShip2homecount;
	}

	public ProductdetailTestPage select() {
		click();
		ProductdetailTestPage productdetailTestPage = new ProductdetailTestPage();
		productdetailTestPage.waitForPageToLoad();
		return productdetailTestPage;
	}
	
	public String prdtName(int lable){
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();
		String productName = productresult.getPrdtNameWithRespectToCell(lable).getText();
		return productName;		
	}

	/*public WebDriverTestPage addToCart() {
		getProductresultBtnAddtocart().click();
		throw new NotYetImplementedException();
	}

	public WebDriverTestPage addToList() {
		getProductresultBtnAddtocart().click();
		throw new NotYetImplementedException();
	}*/
}
