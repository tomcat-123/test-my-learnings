package com.heb.automation.common.pages.myaccount;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MyaccountstoredetailsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "myaccstoredetails.lbl.changemyhebstore")
	private QAFWebElement myaccstoredetailsLblChangemyhebstore;
	@FindBy(locator = "myaccstoredetails.lbl.storename")
	private QAFWebElement myaccstoredetailsLblStorename;
	@FindBy(locator = "myaccstoredetails.lbl.storeaddress1")
	private QAFWebElement myaccstoredetailsLblStoreaddress1;
	@FindBy(locator = "myaccstoredetails.lbl.storeaddress2")
	private QAFWebElement myaccstoredetailsLblStoreaddress2;
	@FindBy(locator = "myaccstoredetails.lbl.storename1")
	private QAFWebElement myaccstoredetailsLblStorename1;
	@FindBy(locator = "myaccstoredetails.lbl.cells")
	private List<QAFWebElement> lblCells;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblChangemyhebstore() {
		return myaccstoredetailsLblChangemyhebstore;
	}

	public QAFWebElement getLblStorename() {
		return myaccstoredetailsLblStorename;
	}

	public QAFWebElement getLblStoreaddress1() {
		return myaccstoredetailsLblStoreaddress1;
	}

	public QAFWebElement getLblStoreaddress2() {
		return myaccstoredetailsLblStoreaddress2;
	}

	public QAFWebElement getLblStorename1() {
		return myaccstoredetailsLblStorename1;
	}
	
	public List<QAFWebElement> getLblCells() {
		return lblCells;
	}
	
	// DYNAMIC value declaring
		public QAFWebElement getStoreaddressbydynamic(int lable) {
			String loc = String.format(pageProps.getString("myaccstoredetails.lbl.storeaddress1"), lable);
			return new QAFExtendedWebElement(loc);
		}
}
