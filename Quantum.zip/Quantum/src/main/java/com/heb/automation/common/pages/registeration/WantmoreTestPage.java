package com.heb.automation.common.pages.registeration;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class WantmoreTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	
	@FindBy(locator = "wantmore.lbl.pageheader")
	private QAFWebElement LblPageHeader;
	@FindBy(locator = "wantmore.lbl.pagedescription")
	private QAFWebElement LblPageDescription;
	
	// Extra offers 
	@FindBy(locator = "wantmore.tab.ExtraOffers")
	private QAFWebElement LblExtraOffers;
	@FindBy(locator = "wantmore.tab.ExtraOffersDescription")
	private QAFWebElement LblExtraOffersDescription;
	
	// Digital Coupons
	@FindBy(locator = "wantmore.lbl.digitalcoupons")
	private QAFWebElement lblDigitalcoupons;

	@FindBy(locator = "wantmore.lbl.digitalcouponsstatus")
	private QAFWebElement lblDigitalcouponsstatus;
	
	// My Store 
	@FindBy(locator = "wantmore.lbl.mystore")
	private QAFWebElement LblMystore;
	@FindBy(locator = "wantmore.lbl.mystoreaddress")
	private QAFWebElement lblMystoreaddress;
	
	/*Email Notifications */
	@FindBy(locator = "wantmore.lbl.emailnotification")
	private QAFWebElement lblEmainotification;
	
	// Weekly Ad
	@FindBy(locator = "wantmore.lbl.weeklyad")
	private QAFWebElement LblWeeklyad;
	@FindBy(locator = "wantmore.lbl.weeklyadDescription")
	private QAFWebElement LblWeeklyadDescription;
	@FindBy(locator = "wantmore.lbl.weeklyad.switch")
	private QAFWebElement WeeklyadSwitch;
	
	
	//Promotional
	@FindBy(locator = "wantmore.lbl.promotional")
	private QAFWebElement LblPromotional;
	@FindBy(locator = "wantmore.lbl.promotionalDescription")
	private QAFWebElement LblPromotionalDescription;
	@FindBy(locator = "wantmore.lbl.promotional.switch")
	private QAFWebElement PromotionalSwitch;
	
	// Newsletter
	
	@FindBy(locator = "wantmore.lbl.newsletter")
	private QAFWebElement LblNewsletter;
	@FindBy(locator = "wantmore.lbl.newsletterDescriptionr")
	private QAFWebElement LblNewsletterDescription;
	@FindBy(locator = "wantmore.lbl.newsletter.switch")
	private QAFWebElement NewsletterSwitch;
	
	// DONE 
	@FindBy(locator = "wantmore.btn.done")
	private QAFWebElement BtnDone;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblMystore() {
		return LblMystore;
	}

	public QAFWebElement getLblWeeklyad() {
		return LblWeeklyad;
	}


	public QAFWebElement getLblPromotional() {
		return LblPromotional;
	}


	public QAFWebElement getLblNewsletter() {
		return LblNewsletter;
	}


	public QAFWebElement getBtnDone() {
		return BtnDone;
	}
	
	public QAFWebElement getLblEmainotification() {
		return lblEmainotification;
	}
	
	public QAFWebElement getLblMystoreaddress() {
		return lblMystoreaddress;
	}

	public QAFWebElement getLblPageHeader() {
		return LblPageHeader;
	}

	public QAFWebElement getLblPageDescription() {
		return LblPageDescription;
	}

	public QAFWebElement getLblExtraOffers() {
		return LblExtraOffers;
	}

	public QAFWebElement getLblExtraOffersDescription() {
		return LblExtraOffersDescription;
	}

	public QAFWebElement getLblWeeklyadDescription() {
		return LblWeeklyadDescription;
	}

	public QAFWebElement getWeeklyadSwitch() {
		return WeeklyadSwitch;
	}

	public QAFWebElement getLblPromotionalDescription() {
		return LblPromotionalDescription;
	}

	public QAFWebElement getPromotionalSwitch() {
		return PromotionalSwitch;
	}

	public QAFWebElement getLblNewsletterDescription() {
		return LblNewsletterDescription;
	}

	public QAFWebElement getNewsletterSwitch() {
		return NewsletterSwitch;
	}

	public QAFWebElement getLblDigitalcoupons() {
		return lblDigitalcoupons;
	}

	public QAFWebElement getLblDigitalcouponsstatus() {
		return lblDigitalcouponsstatus;
	}
}
