package com.heb.automation.android.steps.registeration;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.HashMap;
import java.util.Map;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.android.steps.AndroidStepDef;
import com.heb.automation.android.steps.storelocator.AndroidStepDefStoreLocator;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.myaccount.ChangepasswordTestPage;
import com.heb.automation.common.pages.registeration.ExtraOffersTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.steps.CommonSteps;
import com.heb.automation.common.steps.registeration.CommonStepDefRegisteration;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in Registration

	I validate hint is available for all text fields in Registration page
	I validate hint is available for all text fields in Login pages
	I validate hint is avaiable for all text fields in Coupon Registration page
	I validate hint is avaiable for all text fields in Profile pages
	I select a store as My store
	I validate required fields by entering invalid inputs
	I enter first name field {0}
	I enter password field {0}
	I enter email address field {0}
	I verify keyboard is opened and cursor is at the First Name field
	I enable/disable T&C button
	I navigate to more/help page
	I verify the Required and Optional fields in Registration page
	I verify the WhatsNew section*/

public class AndroidStepdefregisteration {

	/**
	 * Validation of hints in all text fields in registration page.
	 */
	@QAFTestStep(description = "I validate hint is available for all text fields in Registration page")
	public void iValidateHintIsAvailableForAllTextFieldsInRegistrationPage() {
		RegistrastionTestPage regpage = new RegistrastionTestPage();

		AndroidStepDef.validatehintfortext(regpage.getRegistrationTxtFirstname(), regpage.getLblTipfirstname(),
				"First Name");
		AndroidStepDef.validatehintfortext(regpage.getRegistrationTxtLastname(), regpage.getLblTiplastname(),
				"Last Name");
		AndroidStepDef.validatehintfortext(regpage.getRegistrationTxtEmail(), regpage.getLblTipemail(),
				"Email Address");
		AndroidStepDef.validatehintfortext(regpage.getRegistrationTxtPassword(), regpage.getLblTippassword(),
				"Password");
	}

	/**
	 * Validation of hints in all text fields in Login page.
	 */
	@QAFTestStep(description = "I validate hint is available for all text fields in Login pages")
	public void iValidateHintIsAvaiableForAllTextFieldsInLoginPages() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		AndroidStepDef.validatehintfortext(loginsplash.getLoginTxtEmail(), loginsplash.getLblTipemail(), "Email");
		AndroidStepDef.validatehintfortext(loginsplash.getLoginTxtPassword(), loginsplash.getLblTippassword(),
				"Password");
	}

	/**
	 * Validation of hints in all text fields in Coupon Registration page.
	 */
	@QAFTestStep(description = "I validate hint is avaiable for all text fields in Coupon Registration page")
	public void iValidateHintIsAvaiableForAllTextFieldsInCouponRegistrationPage() {
		ExtraOffersTestPage offers = new ExtraOffersTestPage();

		AndroidStepDef.validatehintfortext(offers.getEdtMobilenum(), offers.getEdtMobilenum(), "Mobile Number");
	}

	/**
	 * Validation of hints in all text fields in in Profile page.
	 */
	@QAFTestStep(description = "I validate hint is avaiable for all text fields in Profile pages")
	public void iValidateHintIsAvaiableForAllTextFieldsInProfilePages() {
		ChangepasswordTestPage changepswd = new ChangepasswordTestPage();

		AndroidStepDef.validatehintfortext(changepswd.getChangepswdTxtEnteroldpass(), changepswd.getLblTipOldPassword(),
				"Old Password");
		AndroidStepDef.validatehintfortext(changepswd.getChangepswdTxtEnternewpass(),
				changepswd.getLblTipconfirmnewpwd(), "New Password");
	}

	/**
	 * Selecting a store as My store
	 */
	@QAFTestStep(description = "I select a store as My store")
	public void iSelectAStoreAsMyStore() throws Exception {
		AndroidStepDefStoreLocator storeloc = new AndroidStepDefStoreLocator();

		storeloc.iChooseAStoreFromTheStoreLocatorPage();
	}

	/**
	 * Validation of fields by entering invalid inputs.
	 */
	@QAFTestStep(description = "I validate required fields by entering invalid inputs")
	public void iValidateRequiredFieldsByEnteringInvalidInputs() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		CommonStepDefRegisteration commregister = new CommonStepDefRegisteration();

		String invalidEAddress = getBundle().getString("registration.InvalidEmailAddress");
		String invalidPwd = getBundle().getString("registration.InvalidPassword");
		String firstName = "TestFName";

		/* Passing Invalid input */
		iEnterFirstNameField(firstName);
		iEnterEmailAddressField(invalidEAddress);
		iEnterPasswordField(invalidPwd);
		iEnableDisableTCButton();
		commregister.iClickCreateAccount();

		/* Validate the error messages */
		CommonSteps.validaterrormessages("Email is not valid", register.getRegistrationTxtEmail());
		CommonSteps.validaterrormessages("Min 8 characters, 1#", register.getRegistrationTxtPassword());
	}

	/**
	 * Entering the First name.
	 * 
	 * @param FirstName
	 */
	@QAFTestStep(description = "I enter first name field {0}")
	public void iEnterFirstNameField(String FirstName) {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getRegistrationTxtFirstname().waitForPresent(3000);
		register.getRegistrationTxtFirstname().click();
		AndroidStepDef.enterValueIntoTheTextboxandClick(register, FirstName);
	}

	/**
	 * Entering the password field.
	 * 
	 * @param password
	 */
	@QAFTestStep(description = "I enter password field {0}")
	public void iEnterPasswordField(String password) {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getRegistrationTxtPassword().waitForPresent(3000);
		register.getRegistrationTxtPassword().click();
		AndroidStepDef.enterValueIntoTheTextboxandClick(register, password);
	}

	/**
	 * Entering the email.
	 * 
	 * @param email
	 */
	@QAFTestStep(description = "I enter email address field {0}")
	public void iEnterEmailAddressField(String email) {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getRegistrationTxtEmail().waitForPresent(3000);
		register.getRegistrationTxtEmail().click();
		AndroidStepDef.enterValueIntoTheTextboxandClick(register, email);
	}

	/**
	 * Verifying the Keyboard and cursor on first name field.
	 */
	@QAFTestStep(description = "I verify keyboard is opened and cursor is at the First Name field")
	public void iVerifyKeyboardIsOpenedAndCursorIsAtTheFirstNameField() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		String firstName = "test";

		register.getRegistrationTxtFirstname().verifyPresent();
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(firstName);
		PerfectoUtils.reportMessage("Search term entered: " + firstName, MessageTypes.Pass);
		String actualFN = register.getRegistrationTxtFirstname().getText();

		if (actualFN.equals(firstName)) {
			PerfectoUtils.reportMessage("Cursor is at the First Name field as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cursor is not at the First Name field", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking on Terms and Conditions check box.
	 */
	@QAFTestStep(description = "I enable/disable T&C button")
	public void iEnableDisableTCButton() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		PerfectoUtils.hidekeyboard();
		if (!register.getRegistrationChkIagree().isPresent()) {
			Map<String, Object> params = new HashMap<>();
			params.put("mode", "off");
			PerfectoUtils.getAppiumDriver().executeScript("mobile:keyboard:display", params);
			PerfectoUtils.verticalswipe();
		}
		PerfectoUtils.hidekeyboard();
		register.getRegistrationChkIagree().waitForPresent(2000);

		if (register.getRegistrationChkIagree().getAttribute("checked").equals("false")) {
			register.getRegistrationChkIagree().click();
		} else if (register.getRegistrationChkIagree().getAttribute("checked").equals("true")) {
			register.getRegistrationChkIagree().click();
		}
	}

	/**
	 * Navigation to more page.
	 */
	@QAFTestStep(description = "I navigate to more/help page")
	public void iNavigateToMoreHelpPage() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		androidcommon.getAppHamburger().waitForPresent(3000);
		androidcommon.getAppHamburger().click();
		PerfectoUtils.reportMessage("Clicked on hamburger button.", MessageTypes.Pass);

		/* Navigating to help page */
		PerfectoUtils.verticalswipe();
		androidcommon.getLblHelp().waitForPresent(5000);

		androidcommon.getLblHelp().click();
		PerfectoUtils.reportMessage("Clicked on Help from App slider options", MessageTypes.Pass);
	}

	/**
	 * Verification of Optional field in Registration page.
	 */
	@QAFTestStep(description = "I verify the Required and Optional fields in Registration page")
	public void iVerifyTheRequiredAndOptionalFieldsInRegistrationPage() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getRegistrationTxtFirstname().waitForPresent(3000);
		try {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "Last Name (Optional)");
			Object result1 = register.getTestBase().getDriver().executeScript("mobile:text:find", params1);
			PerfectoUtils.reportMessage("Last Name (Optional) text found..", MessageTypes.Pass);
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Last Name (Optional) text is not found..", MessageTypes.Fail);
		}
	}

	/*
	 * Verify what's new section page wise when auto enroll is true
	 */
	@QAFTestStep(description = "I verify the WhatsNew section")
	public void iVerifyTheWhatsNewSection() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		// verify first page and skip button
		if (register.getWhatsnewpage1().isPresent()) {
			String name = register.getWhatsnewpage1().getText();
			PerfectoUtils.reportMessage("Whatsnew section 1 page is present", MessageTypes.Pass);
			if (androidcommon.getBtnSkip().isPresent()) {
				PerfectoUtils.reportMessage("Skip button is present in the Whatsnew page 1", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Skip button is not present in the Whatsnew page 1", MessageTypes.Fail);
			}
			System.out.println(name);
			PerfectoUtils.rightSwipe();
		}

		else {
			PerfectoUtils.reportMessage("Whatsnew section 1 page is  not present", MessageTypes.Fail);
		}

		// verify 2 page and skip button
		if (register.getWhatsnewpage2().isPresent()) {
			String name2 = register.getWhatsnewpage2().getText();
			PerfectoUtils.reportMessage("Whatsnew section 2 page is present", MessageTypes.Pass);
			if (androidcommon.getBtnSkip().isPresent()) {
				PerfectoUtils.reportMessage("Skip button is present in the Whatsnew page 2", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Skip button is not present in the Whatsnew page 2", MessageTypes.Fail);
			}
			System.out.println(name2);
			PerfectoUtils.rightSwipe();

		} else {
			PerfectoUtils.reportMessage("Whatsnew section 2 page is not present", MessageTypes.Fail);
		}

		// verify 3 page and skip button
		if (register.getWhatsnewpage3().isPresent()) {
			String name3 = register.getWhatsnewpage3().getText();
			PerfectoUtils.reportMessage("Whatsnew section 3 page is present", MessageTypes.Pass);
			if (androidcommon.getBtnSkip().isDisplayed()) {
				PerfectoUtils.reportMessage("Skip button is present in the Whatsnew page 3", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Skip button is not present in the Whatsnew page 3", MessageTypes.Fail);
			}
			System.out.println(name3);
			PerfectoUtils.rightSwipe();
			// PerfectoUtils.rightSwipe();
		} else {
			PerfectoUtils.reportMessage("Whatsnew section 3 page is not present", MessageTypes.Fail);
		}

		// PerfectoUtils.rightSwipe();
		// Verify 4 page and no skip button
		if (register.getWhatsnewpage4().isPresent()) {
			register.getStartshoppinglnk().isPresent();
			String name4 = register.getWhatsnewpage4().getText();
			PerfectoUtils.reportMessage("Whatsnew section 4 page is present", MessageTypes.Pass);

			/// Image comparison ///////
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "SKIP");
			String isBtnSkipVisible = (String) register.getTestBase().getDriver()
					.executeScript("mobile:checkpoint:text", params1);

			if (isBtnSkipVisible.equalsIgnoreCase("false")) {
				PerfectoUtils.reportMessage("Skip button is not present in the Whatsnew page 4", MessageTypes.Pass);
				if (register.getStartshoppinglnk().isPresent()) {
					PerfectoUtils.reportMessage("Start Shopping link present in the Whatsnew page 4",
							MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Start shopping link is not present in the Whatsnew page 4",
							MessageTypes.Fail);
				}
			} else {
				PerfectoUtils.reportMessage("Skip button is  present in the Whatsnew page 4", MessageTypes.Fail);
			}
			System.out.println(name4);
		}

		else {
			PerfectoUtils.reportMessage("Whatsnew section 4 page is not present", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I navigate to Forgot Password page")
	public void iNavigateToForgotPasswordPage() {
		LoginsplashTestPage loginpage = new LoginsplashTestPage();

		loginpage.getTxtForgotPassword().waitForPresent(3000);
		loginpage.getTxtForgotPassword().verifyPresent();
	}

	@QAFTestStep(description = "I enter the email address and click on submit button")
	public void iEnterTheEmailAddressAndClickOnSubmitButton() {
		LoginsplashTestPage loginpage = new LoginsplashTestPage();

		loginpage.getLoginTxtEmail().verifyPresent();
		loginpage.getLoginTxtEmail().click();
		String email = ConfigurationManager.getBundle().getString("registration.ResetPassword.email");
		loginpage.getLoginTxtEmail().sendKeys(email);

		loginpage.getBtnResetPassword().verifyPresent();
		if (loginpage.getBtnResetPassword().isEnabled()) {
			loginpage.getBtnResetPassword().click();
			PerfectoUtils.reportMessage("Submit button is enabled and clicked", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Submit button is not enabled", MessageTypes.Fail);
		}
	}

}
