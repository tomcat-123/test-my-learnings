/**
 * 
 */
package com.heb.automation.common.steps.weeklyad;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static com.qmetry.qaf.automation.step.CommonStep.click;
import static com.qmetry.qaf.automation.step.CommonStep.waitForPresent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.StoreResult;
import com.heb.automation.common.pages.storelocator.StorelistviewresultTestPage;
import com.heb.automation.common.pages.weeklyad.WeeklyadslandingTestPage;
import com.heb.automation.common.pages.weeklyad.WeeklyadsresultlistTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in WeeklyAds

	I see Features deal page
	I see Blue checkmark in all ads after clicking on Select All button
	I verify the weekly ad for selected category
	I enter valid search term {0}
	I see Blue checkmark is removed in all ads after clicking on UnSelect All button
	I navigate back to Featured deals page
	I enter invalid search term {0}
	I verify the category results page */

public class CommonStepDefWeeklyAds {

	/**
	 * user see a feature deal and navigate to weekly add landing page
	 */
	@QAFTestStep(description = "I see Features deal page")
	public void iSeeFeaturesDealPage() {
		WeeklyadslandingTestPage weeklyadlanding = new WeeklyadslandingTestPage();

		if (weeklyadlanding.getWeeklyadLblPageTitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Weekly Ads landing page.", MessageTypes.Pass);
			weeklyadlanding.getWeeklyadBtnViewanotherstore().verifyPresent();
			weeklyadlanding.getWeeklyadBtnSelectall().verifyPresent();
			weeklyadlanding.getWeeklyadBtnCatagorydropdown().verifyPresent();
			weeklyadlanding.getWeeklyadLblDisplaystorename().verifyPresent();
			weeklyadlanding.getChkCheckbok().verifyPresent();
			weeklyadlanding.getImgAdimage().verifyPresent();
			weeklyadlanding.getLblProductdate().verifyPresent();
			weeklyadlanding.getLblProductdescription().verifyPresent();
		} else {
			PerfectoUtils.reportMessage("Not navigated to Weekly Ads landing page.", MessageTypes.Fail);
		}
	}

	/**
	 * User see Blue check mark in all ads after clicking on Select All button
	 */
	@QAFTestStep(description = "I see Blue checkmark in all ads after clicking on Select All button")
	public void iSeeBlueCheckmarkInAllAdsAfterClickingOnSelectAllButton() {
		WeeklyadslandingTestPage weeklyadslanding = new WeeklyadslandingTestPage();

		// Clicking on select all button
		weeklyadslanding.getWeeklyadBtnSelectall().waitForPresent(10000);
		weeklyadslanding.getWeeklyadBtnSelectall().click();

		try {
			weeklyadslanding.getLblUnselectall().waitForPresent(10000);
			PerfectoUtils.reportMessage("Clicked on Select All button..",MessageTypes.Pass);
		} catch (Exception e) {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "SELECT ALL");
			weeklyadslanding.getTestBase().getDriver().executeScript("mobile:text:select", params1);
			
			try {
				weeklyadslanding.getLblUnselectall().waitForPresent(10000);
				PerfectoUtils.reportMessage("Clicked on Select All button..",MessageTypes.Pass);
			} catch (Exception e1) {
				PerfectoUtils.reportMessage("Error occured while Clicking SelectAll button..",MessageTypes.Fail);
			}
			
		}
	}

	/**
	 * user verify the weekly ad for selected category
	 */
	@QAFTestStep(description = "I verify the weekly ad for selected category")
	public void iVerifyTheWeeklyAdForSelectedCategory() {
		WeeklyadslandingTestPage weeklyadslandingPage = new WeeklyadslandingTestPage();

		// weeklyadslandingPage.getWeeklyadLblPageTitle().verifyPresent();
		List<String> actualdweeklydeal = new ArrayList<String>();
		for (int i = 0; i < weeklyadslandingPage.getLblAdname().size(); i++) {
			actualdweeklydeal.add(weeklyadslandingPage.getLblAdname().get(i).getText());
		}
		int categoryCount=Integer.parseInt(getBundle().getString("WeeklyAds.categoryCount"));
		System.out.println(actualdweeklydeal.size());
		if(categoryCount==actualdweeklydeal.size())
			PerfectoUtils.reportMessage("Category ads count mathces..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("more than 4 product are getting displayed", MessageTypes.Info);
		
		getBundle().setProperty("actualweeklydeal", actualdweeklydeal);
		PerfectoUtils.reportMessage("Actual product name are" + actualdweeklydeal + "name", MessageTypes.Pass);
		// System.out.println(actualdweeklydeal);

	}

	/**
	 * user enter valid search term
	 */
	@QAFTestStep(description = "I enter valid search term {0}")
	public void iEnterValidSearchTerm(String str1) {
		
		// Enter product name in search field
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(str1);
	}

	/**
	 * user see Blue check mark is removed in all ads after clicking on UnSelect
	 * All button
	 */
	@QAFTestStep(description = "I see Blue checkmark is removed in all ads after clicking on UnSelect All button")
	public void iSeeBlueCheckmarkIsRemovedInAllAdsAfterClickingOnUnSelectAllButton() {
		WeeklyadslandingTestPage weeklyadslanding = new WeeklyadslandingTestPage();
		WeeklyadsresultlistTestPage weeklyadresults = new WeeklyadsresultlistTestPage();
		try {
			weeklyadresults.getWeeklyadLstDealname().get(1).waitForPresent(3000);
			if (weeklyadresults.getWeeklyadLstDealname().isEmpty()) {
				PerfectoUtils.reportMessage("Weekly ad deals are not listed for selected Store!!", MessageTypes.Fail);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		weeklyadslanding.getLblUnselectall().click();
		PerfectoUtils.reportMessage("Unselect all is being clicked:", MessageTypes.Pass);
	}

	/**
	 * user is navigate back to Featured deals page
	 */
	@QAFTestStep(description = "I navigate back to Featured deals page")
	public void iNavigateBackToFeaturedDealsPage() {
		PerfectoUtils.androiddeviceback();
	}

	/**
	 * user enter valid search term
	 */
	@QAFTestStep(description = "I enter invalid search term {0}")
	public void iEnterInvalidSearchTerm(String str1) {
		
		// Enter product name in search field
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(str1);
	}
	
	/**
	 * user verify the category results page
	 */
	@QAFTestStep(description = "I verify the category results page")
	public void iVerifyTheCategoryResultsPage() {
		WeeklyadslandingTestPage weeklyadlanding = new WeeklyadslandingTestPage();
		weeklyadlanding.waitForPageToLoad();
			
			String categoryName=ConfigurationManager.getBundle().getString("WeeklyAds.categoryName");
			int categoryItemCount=Integer.parseInt(ConfigurationManager.getBundle().getString("WeeklyAds.categoryCount"));
			
			if (weeklyadlanding.getWeeklyadLblPageTitle().getText().equals(categoryName)) {
				PerfectoUtils.reportMessage("Navigated to Weekly Ads landing page.", MessageTypes.Pass);
				
				int itemCount=weeklyadlanding.getLblAdname().size();
				if(categoryItemCount==itemCount)
					PerfectoUtils.reportMessage("Item count mathces with selected category..", MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("Item count not mathces with selected category..", MessageTypes.Fail);
				
				weeklyadlanding.getWeeklyadBtnViewanotherstore().verifyPresent();
				weeklyadlanding.getWeeklyadBtnSelectall().verifyPresent();
				weeklyadlanding.getWeeklyadBtnCatagorydropdown().verifyPresent();
				weeklyadlanding.getWeeklyadLblDisplaystorename().verifyPresent();
				weeklyadlanding.getChkCheckbok().verifyPresent();
				weeklyadlanding.getImgAdimage().verifyPresent();
				weeklyadlanding.getLblProductdate().verifyPresent();
				weeklyadlanding.getLblProductdescription().verifyPresent();
				
			} else {
				PerfectoUtils.reportMessage("Not navigated to Weekly Ads landing page.", MessageTypes.Fail);
			}
	
	}
	
	
}
