package com.heb.automation.common.pages.storelocator;

import java.util.List;
import com.heb.automation.common.components.StoreResult;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class StorelocatorTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "storelocator.lbl.store.locator")
	private QAFWebElement storelocatorLblStoreLocator;
	@FindBy(locator = "storelocator.img.home")
	private QAFWebElement storelocatorImgHome;
	@FindBy(locator = "storelocator.img.listswitch")
	private QAFWebElement storelocatorImgListswitch;
	@FindBy(locator = "storelocator.lbl.refine")
	private QAFWebElement storelocatorLblRefine;
	@FindBy(locator = "storelocator.choose.storename")
	private QAFWebElement storelocatorChooseStorename;
	@FindBy(locator = "storelocator.display.storename")
	private QAFWebElement storelocatorDisplayStorename;
	@FindBy(locator = "storelocator.choose.alternatestorename")
	private QAFWebElement storelocatorChooseAlternatestorename;
	@FindBy(locator = "storelocator.lnk.viewanotherstore")
	private QAFWebElement storelocatorViewanotherstore;
	@FindBy(locator = "storelocator.img.mapswitch")
	private QAFWebElement storelocatorImgMapswitch;
	@FindBy(locator = "storelocator.txt.searchicon")
	private QAFWebElement storelocatorTxtSearchicon;
	@FindBy(locator = "storelocator.txt.entersearch")
	private QAFWebElement storelocatorTxtEntersearch;
	@FindBy(locator = "storelocator.btn.collapsesearch")
	private QAFWebElement storelocatorBtnCollapsesearch;
	@FindBy(locator = "storelocator.lbl.refine.stores")
	private QAFWebElement storelocatorlblrefinestores;
	@FindBy(locator = "storelocator.chk.pharmacy")
	private QAFWebElement storelocatorchkpharmacy;
	@FindBy(locator = "storelocator.btn.done")
	private QAFWebElement storelocatorbtndone;
	@FindBy(locator = "storelocator.btn.apply")
	private QAFWebElement storelocatorbtnapply;
	@FindBy(locator = "storelocator.bubble.mapview")
	private QAFWebElement storelocatorbubblemapview;
	@FindBy(locator = "storelocator.img.imageview")
	private QAFWebElement storelocatorimgimageview;
	@FindBy(locator = "storelocator.cell.storelist")
	private List<StoreResult> storelocatorCellStorelistitems;
	@FindBy(locator = "storelocator.txt.popupmsg")
	private QAFWebElement storelocatorTxtPopupmsg;
	@FindBy(locator = "storelocator.btn.allow")
	private QAFWebElement storelocatorBtnAllow;
	@FindBy(locator = "storelocator.btn.deny")
	private QAFWebElement storelocatorBtnDeny;
	@FindBy(locator = "storelocator.bubble.storename")
	private QAFWebElement storelocatorbubblestorename;
	@FindBy(locator = "storedetail.lbl.storename")
	private QAFWebElement storedetaillblstorename;
	@FindBy(locator = "storedetail.lbl.pharmacy")
	private QAFWebElement storedetaillblpharmacy;
	@FindBy(locator = "storelocator.chk.fuel")
	private QAFWebElement storelocatorChkFuel;
	@FindBy(locator = "storelocator.chk.carwash")
	private QAFWebElement storelocatorChkCarwash;
	@FindBy(locator = "storelocator.chk.hebplus")
	private QAFWebElement storelocatorChkHebplus;
	@FindBy(locator = "storelocator.chk.openhr")
	private QAFWebElement storelocatorChkOpenhr;
	@FindBy(locator = "storelocator.chk.hrpharmacy")
	private QAFWebElement storelocatorChkHrpharmacy;
	@FindBy(locator = "storelocator.img.fuelicon")
	private QAFWebElement storelocatorImgFuelicon;
	@FindBy(locator = "storelocator.img.carwashicon")
	private QAFWebElement storelocatorImgCarwashicon;
	@FindBy(locator = "storelocator.map.selectstore2")
	private QAFWebElement storelocatorMapSelectstore2;
	
	@FindBy(locator = "storelocator.map.alert")
	private QAFWebElement mapAlert;
	@FindBy(locator = "storelocator.btn.ok")
	private QAFWebElement btnOk;
	@FindBy(locator = "storelocator.lbl.choosenewstore")
	private QAFWebElement lblChooseNewStore;
	@FindBy(locator = "storelocator.lbl.nearbystores")
	private QAFWebElement LblNearbyStores;

	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getStorelocatorLblStoreLocator() {
		return storelocatorLblStoreLocator;
	}

	public QAFWebElement getStorelocatorImgHome() {
		return storelocatorImgHome;
	}

	public QAFWebElement getStorelocatorImgListswitch() {
		return storelocatorImgListswitch;
	}

	public QAFWebElement getStorelocatorLblRefine() {
		return storelocatorLblRefine;
	}

	public QAFWebElement getStorelocatorChooseStorename() {
		return storelocatorChooseStorename;
	}

	public QAFWebElement getStorelocatorDisplayStorename() {
		return storelocatorDisplayStorename;
	}

	public QAFWebElement getStorelocatorChooseAlternatestorename() {
		return storelocatorChooseAlternatestorename;
	}

	public QAFWebElement getStorelocatorViewanotherstore() {
		return storelocatorViewanotherstore;
	}

	public QAFWebElement getStorelocatorImgMapswitch() {
		return storelocatorImgMapswitch;
	}

	public QAFWebElement getStorelocatorTxtSearchicon() {
		return storelocatorTxtSearchicon;
	}

	public QAFWebElement getStorelocatorTxtEntersearch() {
		return storelocatorTxtEntersearch;
	}

	public QAFWebElement getStorelocatorBtnCollapsesearch() {
		return storelocatorBtnCollapsesearch;
	}

	public QAFWebElement getstorelocatorlblrefinestores() {
		return storelocatorlblrefinestores;
	}

	public QAFWebElement getstorelocatorchkpharmacy() {
		return storelocatorchkpharmacy;
	}

	public QAFWebElement getstorelocatorbtndone() {
		return storelocatorbtndone;
	}

	public QAFWebElement getstorelocatorbtnapply() {
		return storelocatorbtnapply;
	}

	public QAFWebElement getstorelocatorbubblemapview() {
		return storelocatorbubblemapview;
	}

	public QAFWebElement getstorelocatorimgimageview() {
		return storelocatorimgimageview;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public List<StoreResult> getStorelocatorCellStorelistitems() {
		return storelocatorCellStorelistitems;
	}

	public QAFWebElement getStorelocatorTxtPopupmsg() {
		return storelocatorTxtPopupmsg;
	}

	public QAFWebElement getStorelocatorBtnAllow() {
		return storelocatorBtnAllow;
	}

	public QAFWebElement getStorelocatorBtnDeny() {
		return storelocatorBtnDeny;
	}

	public QAFWebElement getStorelocatorChkFuel() {
		return storelocatorChkFuel;
	}

	public QAFWebElement getStorelocatorChkCarwash() {
		return storelocatorChkCarwash;
	}

	public QAFWebElement getStorelocatorChkHebplus() {
		return storelocatorChkHebplus;
	}

	public QAFWebElement getStorelocatorChkOpenhr() {
		return storelocatorChkOpenhr;
	}

	public QAFWebElement getStorelocatorChkHrpharmacy() {
		return storelocatorChkHrpharmacy;
	}

	public QAFWebElement getStorelocatorImgFuelicon() {
		return storelocatorImgFuelicon;
	}

	public QAFWebElement getStorelocatorImgCarwashicon() {
		return storelocatorImgCarwashicon;
	}

	public QAFWebElement getStorelocatorBubbleStorename() {
		return storelocatorbubblestorename;
	}

	public QAFWebElement getStoreDetailLblStorename() {
		return storedetaillblstorename;
	}

	public QAFWebElement getStoreDetailLblPharmacy() {
		return storedetaillblpharmacy;
	}

	public QAFWebElement getStorelocatorMapSelectstore2() {
		return storelocatorMapSelectstore2;
	}
	
	public QAFWebElement getMapAlert() {
		return mapAlert;
	}

	public QAFWebElement getBtnOk() {
		return btnOk;
	}
	
	public QAFWebElement getLblChooseNewStore() {
		return lblChooseNewStore;
	}
	
	public QAFWebElement getLblNearbyStores() {
		return LblNearbyStores;
	}
}
