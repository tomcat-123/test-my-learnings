package com.heb.automation.common.pages.recipes;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RecipeboxresultTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "recipeboxresult.lbl.recipename")
	private List<QAFWebElement> recipeboxresultLblRecipename;
	@FindBy(locator = "recipeboxresult.btn.deleterecipe")
	private List<QAFWebElement> recipeboxresultBtnDeleterecipe;
	@FindBy(locator = "recipeboxresult.btn.recipebox")
	private QAFWebElement recipeboxresultBtnRecipebox;
	@FindBy(locator = "recipeboxresult.popup.btndelete")
	private QAFWebElement popupBtndelete;
	@FindBy(locator = "recipeboxresult.popup.titledelete")
	private QAFWebElement popupTitledelete;
	@FindBy(locator = "recipeboxresult.btn.moverecipe")
	private QAFWebElement btnMoverecipe;
	@FindBy(locator = "recipeboxresult.btn.popuptitle")
	private QAFWebElement btnPopuptitle;
	@FindBy(locator = "recipeboxresult.btn.popup.move")
	private QAFWebElement btnPopupmove;
	@FindBy(locator = "recipeboxresult.btn.popup.cancel")
	private QAFWebElement btnPopupcancel;
	@FindBy(locator = "recipeboxresult.lbl.popup.pickerbox")
	private QAFWebElement lblPopuppickerbox;
	@FindBy(locator = "recipeboxresult.lbl.popup.recipeboxnameslist")
	private QAFWebElement lblPopuprecipeboxnameslist;
	@FindBy(locator = "recipeboxresult.lbl.popup.recipeboxname")
	private QAFWebElement lblPopuprecipeboxname;
	@FindBy(locator = "recipeboxresult.img.recipeimage")
	private List<QAFWebElement> imgRecipeimage;
	@FindBy(locator = "recipeboxresult.btn.dynamicmoverecipe")
	private QAFWebElement btnDynamicmoverecipe;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public List<QAFWebElement> getRecipeboxresultLblRecipename() {
		return recipeboxresultLblRecipename;
	}

	public List<QAFWebElement> getRecipeboxresultBtnDeleterecipe() {
		return recipeboxresultBtnDeleterecipe;
	}

	public QAFWebElement getRecipeboxresultBtnRecipebox() {
		return recipeboxresultBtnRecipebox;
	}

	public QAFWebElement getPopupBtndelete() {
		return popupBtndelete;
	}

	public QAFWebElement getPopupTitledelete() {
		return popupTitledelete;
	}

	public QAFWebElement getBtnMoverecipe() {
		return btnMoverecipe;
	}

	public QAFWebElement getBtnPopuptitle() {
		return btnPopuptitle;
	}

	public QAFWebElement getBtnPopupmove() {
		return btnPopupmove;
	}

	public QAFWebElement getBtnPopupcancel() {
		return btnPopupcancel;
	}

	public QAFWebElement getLblPopuppickerbox() {
		return lblPopuppickerbox;
	}

	public QAFWebElement getLblPopuprecipeboxnameslist() {
		return lblPopuprecipeboxnameslist;
	}

	public QAFWebElement getLblPopuprecipeboxname() {
		return lblPopuprecipeboxname;
	}

	public List<QAFWebElement> getImgRecipeimage() {
		return imgRecipeimage;
	}

	public QAFWebElement getBtnDynamicmoverecipe() {
		return btnDynamicmoverecipe;
	}

	// DYNAMIC value declaring
	public QAFWebElement getBtnMovetoListByLable(int lable) {
		String loc = String.format(pageProps.getString("recipeboxresult.btn.dynamicmoverecipe"), lable);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getlblpagetitle(String lable) {
		String loc = String.format(pageProps.getString("recipeboxresult.lbl.pagetitle"), lable);
		return new QAFExtendedWebElement(loc);
	}
}
