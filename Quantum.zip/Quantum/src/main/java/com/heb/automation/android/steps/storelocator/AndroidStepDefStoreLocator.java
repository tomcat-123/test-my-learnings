package com.heb.automation.android.steps.storelocator;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.android.steps.myaccount.AndroidStepDefMyaccount;
import com.heb.automation.android.steps.products.AndroidStepdefProducts;
import com.heb.automation.android.steps.weeklyad.AndroidStepDefWeeklyAds;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.StoreResult;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.coupons.CouponsselectionTestPage;
import com.heb.automation.common.pages.myaccount.MyaccountTestPage;
import com.heb.automation.common.pages.products.ProductstoredetailsmodalTestPage;
import com.heb.automation.common.pages.recipes.RecipeslandingTestPage;
import com.heb.automation.common.pages.shoppinglist.MylistTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.storelocator.StoredetailsTestPage;
import com.heb.automation.common.pages.storelocator.StorelistviewresultTestPage;
import com.heb.automation.common.pages.storelocator.StorelocatorTestPage;
import com.heb.automation.common.pages.storelocator.StoremapviewTestPage;
import com.heb.automation.common.pages.weeklyad.WeeklyadslandingTestPage;
import com.heb.automation.common.steps.coupons.CommonStepDefCoupons;
import com.heb.automation.common.steps.recipes.CommonStepDefRecipes;
import com.heb.automation.common.steps.weeklyad.CommonStepDefWeeklyAds;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in StoreLocator

	I change my store and select a different store
	I navigate back to listview page
	I navigate back to mapview page and click on search icon
	I see Search Field is displayed by clicking on Search Icon in map view of storelocator
	I select a store in map view
	I click on done/Apply button after selecting stores
	I navigate back to listview page and click on search icon
	I navigate to StoreLocator
	I choose a store from the store locator page
	I verify filter options
	I navigate to the listed option in Store detail
	I verify refine result
	I select two refine filter and click on done button
	I navigate to store features and pharmacy number options
	I navigate back to list view and verify the refine results
	I select a store in map view for hotuser
	I validate the list view of store locator page
	I choose second store from the store locator page
	I navigate to List View page
	I should see store detail page
	I verify change store, weekly ad and store features in My Store
	I navigated to store details modal from More section of the app
	I verify the map view on the top of the page
	I validate Set as My H-E-B store option is not present in store detail
	I clicked on storelocator from home page
	I set the store as my heb store
	I navigate to my store page
	I verify the stores that are getting displayed
	I verify that different set of stores are getting displayed*/

public class AndroidStepDefStoreLocator {

	/**
	 * user change his current store and select a new store user selects a store
	 * number and the corresponding store is chosen from the list
	 */
	@QAFTestStep(description = "I change my store and select a different store")
	public void iChangeMyStoreAndSelectADifferentStore() {
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();

		storepage.getStorelocatorImgListswitch().waitForPresent(5000);
		storepage.getStorelocatorImgListswitch().click();
		int intChoosenStrOrder = getBundle().getInt("ChoosenStoreNumber");
		intChoosenStrOrder = intChoosenStrOrder + 1;
		StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(intChoosenStrOrder);
		String StoreName = store.getStorelocatorLblStorename().getText();
		PerfectoUtils.reportMessage("Store Name:" + StoreName);
		store.click();
	}

	/**
	 * user is navigated back to list view page
	 */
	@QAFTestStep(description = "I navigate back to listview page")
	public void iNavigateBackToListviewPage() {
		PerfectoUtils.androiddeviceback();
	}

	/**
	 * user navigates to map view page and click on the search icon
	 */
	@QAFTestStep(description = "I navigate back to mapview page and click on search icon")
	public void iNavigateBackToMapviewPage() {
		StoremapviewTestPage mapview = new StoremapviewTestPage();

		/* Click on device back button */
		PerfectoUtils.androiddeviceback();

		/* Click on search icon */
		mapview.getStorelocatorIconSearch().waitForPresent(1000);
		mapview.getStorelocatorIconSearch().click();

		/* Verifying Search icon text */
		mapview.getStorelocatorTxtSearch().waitForPresent(2000);
		mapview.getStorelocatorTxtSearch().verifyPresent();
		mapview.getStorelocatorTxtSearch().click();
	}

	/**
	 * check that search field is getting displayed when the search icon is
	 * clicked in map view
	 */
	@QAFTestStep(description = "I see Search Field is displayed by clicking on Search Icon in map view of storelocator")
	public void iSeeSearchFieldIsDisplayedByClickingOnSearchIconInMapViewOfStorelocator() {
		StoremapviewTestPage mapview = new StoremapviewTestPage();

		/* Click on search icon */
		mapview.getStorelocatorIconSearch().waitForPresent(1000);
		mapview.getStorelocatorIconSearch().click();

		/* Verifying Search icon text */
		mapview.getStorelocatorTxtSearch().waitForPresent(2000);
		mapview.getStorelocatorTxtSearch().verifyPresent();
	}

	/**
	 * user selects a store in the map view if store is not found report the
	 * information click on the store in map view click on the white bubble
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I select a store in map view")
	public void iSelectAStoreInMapView() throws InterruptedException {
		StoremapviewTestPage mapview = new StoremapviewTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		StorelocatorTestPage storepage = new StorelocatorTestPage();

		if (weeklygrocery.getShopingListEntryByLable("Store Location Not Found").isPresent()) {
			PerfectoUtils.reportMessage("Store Location Not Found", MessageTypes.Info);
			appcrash.getbtnStoreLocatorOK().verifyPresent();
			appcrash.getbtnStoreLocatorOK().click();
		}

		storepage.getStorelocatorImgMapswitch().verifyPresent();
		storepage.getStorelocatorImgMapswitch().click();

		/* Click on store in map view */
		mapview.getStorelocatorMapSelectstore().click();
		PerfectoUtils.reportMessage("Store clicked", MessageTypes.Pass);

		/* Click on white bubble */
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "H-E-B");
		params1.put("screen.top", "0%");
		params1.put("screen.height", "100%");
		params1.put("screen.left", "0%");
		params1.put("screen.width", "100%");
		Object result1 = mapview.getTestBase().getDriver().executeScript("mobile:text:select", params1);
	}

	/**
	 * user selects the pharmacy store after selecting a store user clicks on
	 * apply button to get his selected store
	 */
	@QAFTestStep(description = "I click on done/Apply button after selecting stores")
	public void iClickOnDoneApplyButtonAfterSelectingStores() {
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		// PerfectoUtils.setLocation("San antonio");
		storelocator.getstorelocatorchkpharmacy().click();
		storelocator.getstorelocatorbtndone().waitForPresent(2000);
		storelocator.getstorelocatorbtndone().click();
		PerfectoUtils.reportMessage("Clicked on done button.", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I navigate back to listview page and click on search icon")
	public void iNavigateBackToListviewPageAndClickOnSearchIcon() {
		StoremapviewTestPage mapview = new StoremapviewTestPage();
		StorelocatorTestPage storepage = new StorelocatorTestPage();

		/* Click on device back button */
		PerfectoUtils.androiddeviceback();

		/* Click on list view page */
		storepage.getStorelocatorImgListswitch().click();
		storepage.getStorelocatorImgListswitch().waitForPresent(5000);

		// Click on search icon
		mapview.getStorelocatorIconSearch().waitForPresent(5000);
		mapview.getStorelocatorIconSearch().click();
	}

	/**
	 * set location as san antonio if store is present then navigate to store
	 * locator page
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I navigate to StoreLocator")
	public void iNavigateToStoreLocator() throws InterruptedException {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		// PerfectoUtils.setLocation("san antonio");
		androidcommon.getAppHamburger().waitForPresent(5000);
		androidcommon.getAppHamburger().click();
		if (androidcommon.getAppSliderStorelocator().isPresent()) {

			androidcommon.getAppSliderStorelocator().waitForPresent(5000);
			androidcommon.getAppSliderStorelocator().click();
		} else {
			PerfectoUtils.scrollToElement(androidcommon.getAppSliderStorelocator());
			androidcommon.getAppSliderStorelocator().click();
		}
		AndroidStepDefStoreLocator.storelocatorErrorHandle();
		/*
		 * Verify whether navigated to Store Locator page
		 */
		if (storelocator.getStorelocatorLblStoreLocator().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Store Locator page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Store Locator page.", MessageTypes.Fail);
		}
	}

	/**
	 * user goes to store locator page user select a store
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I choose a store from the store locator page")
	public void iChooseAStoreFromTheStoreLocatorPage() throws Exception {
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		AndroidStepdefProducts androidstepdef = new AndroidStepdefProducts();
		// StoredetailsTestPage store detail = new StoredetailsTestPage();

		String storeName = null;

		try {
			storepage.getStorelocatorLblRefine().waitForPresent(20000);
		} catch (Exception e) {
			if (storepage.getStorelocatorTxtPopupmsg().isPresent()) {
				storepage.getStorelocatorTxtPopupmsg().verifyPresent();
				storepage.getStorelocatorBtnAllow().click();
			}
		}

		/*
		 * Selecting store
		 */
		if (storepage.getMapAlert().isPresent()) {
			storepage.getBtnOk().click();
			iSeeSearchFieldIsDisplayedByClickingOnSearchIconInMapViewOfStorelocator();
			androidstepdef.iEnterValidSearchTermAndSelectSearchButton("San Antonio");
		}
		storepage.getStorelocatorImgListswitch().waitForPresent(5000);
		storepage.getStorelocatorImgListswitch().click();
		storelistresult.launchPage(null);

		storelistresult.getStorelocatorLblStoreresults().get(1).waitForPresent(15000);
		StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(1);
		storelistresult.getStorelocatorLblStoreresults().get(1).verifyPresent();

		getBundle().setProperty("StoreName", store.getStorelocatorLblStorename().getText());
		getBundle().setProperty("StoreAddress", store.getStorelocatorLblStoreaddress().getText());
		getBundle().setProperty("StoreCity", store.getStorelocatorLblCityname().getText());
		storeName = store.getStorelocatorLblStorename().getText();
		store.click();
		// storedetail.getStoredetailsGetdirections().waitForPresent(50000);
		try {
			if (storepage.getStorelocatorImgListswitch().isPresent()) {
				store.click();
				PerfectoUtils.reportMessage("Selected Store: " + storeName, MessageTypes.Pass);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * user click on store in map view user click on white bubble verify the
	 * filters to check that correct store is displayed or not
	 */
	@QAFTestStep(description = "I verify filter options")
	public void iVerifyFilterOptions() {
		StoremapviewTestPage mapview = new StoremapviewTestPage();
		StoredetailsTestPage storedetail = new StoredetailsTestPage();

		/* Click on store in map view */

		mapview.getStorelocatorMapSelectstore().click();
		PerfectoUtils.reportMessage("Store clicked", MessageTypes.Pass);

		/* Click on white bubble */
		try {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "H-E-B");
			params1.put("screen.top", "0%");
			params1.put("screen.height", "100%");
			params1.put("screen.left", "0%");
			params1.put("screen.width", "100%");
			Object result1 = mapview.getTestBase().getDriver().executeScript("mobile:text:select", params1);

		} catch (Exception e) {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "H-E-B");
			params1.put("screen.top", "0%");
			params1.put("screen.height", "100%");
			params1.put("screen.left", "0%");
			params1.put("screen.width", "100%");
			Object result1 = mapview.getTestBase().getDriver().executeScript("mobile:text:select", params1);
		}
		storedetail.getStoreDetailsLblPharmacy().verifyPresent();
	}

	/**
	 * user verify the store details User verify the direction details user
	 * verify the phone num for the store verify that user sees weekely adds of
	 * store verify the other store details
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I navigate to the listed option in Store detail")
	public void iNavigateToTheListedOptionInStoreDetail() throws Exception {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		if (storelocator.getStorelocatorBtnAllow().isPresent()) {
			storelocator.getStorelocatorBtnAllow().click();
		}
		/* Verifying and clicking get direction */
		if (storedetail.getStoredetailsGetdirections().isPresent()) {
			storedetail.getStoredetailsGetdirections().click();
			storedetail.getStoreldetailsLblAlerttitle().isPresent();
			PerfectoUtils.reportMessage("Get Directions alert is displayed", MessageTypes.Pass);
			storedetail.getStoredetailsLblCancel().click();
			PerfectoUtils.reportMessage("clicked on cancel button", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("Get Direction is not present", MessageTypes.Fail);
		}

		/* Verifying and clicking view phone number */
		if (storedetail.getStoredetailsViewphonenumber().isPresent()) {
			storedetail.getStoredetailsViewphonenumber().click();
			storedetail.getStoreldetailsLblAlerttitle().isPresent();
			PerfectoUtils.reportMessage("Phone number dial alert is displayed", MessageTypes.Pass);
			storedetail.getStoredetailsLblCancel().click();
			PerfectoUtils.reportMessage("clicked on cancel button", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("View phone number is not present", MessageTypes.Fail);
		}

		/* Verifying and clicking weekly ad */
		PerfectoUtils.verticalswipe();
		if (storedetail.getStoredetailsViewweeklyad().isPresent()) {
			storedetail.getStoredetailsViewweeklyad().click();
		} else {
			PerfectoUtils.reportMessage("skipped click option", MessageTypes.Fail);
		}

		int listofdeals = storedetail.getLblFeaturedeals().size();
		if (listofdeals < 1) {
			storedetail.getBtnChangestore().waitForPresent(3000);
			storedetail.getBtnChangestore().click();
			iChooseAStoreFromTheStoreLocatorPage();
		}
		PerfectoUtils.androiddeviceback();

		/* See store features */
		PerfectoUtils.verticalswipe();
		storedetail.getStoreldetailsLblSeestore().waitForPresent(3000);
		storedetail.getStoreldetailsLblSeestore().click();
		storedetail.getStoreldetailsLblPgtitlestorefeature().waitForPresent(5000);
		storedetail.getStoreldetailsLblPgtitlestorefeature().verifyPresent();
		PerfectoUtils.reportMessage("Features Deals page is displayed as expected", MessageTypes.Pass);
		PerfectoUtils.androiddeviceback();
	}

	/**
	 * user verify the refine details User check the fuel image is available
	 * user checks the car wash image is available
	 */
	@QAFTestStep(description = "I verify refine result")
	public void iVerifyRefineResult() {
		StorelistviewresultTestPage listview = new StorelistviewresultTestPage();

		List<StoreResult> items = listview.getStorelocatorLblStoreresults();
		System.out.println("total no of product" + items.size());

		for (int i = 1; i <= items.size(); i++) {
			try {
				/* Check the fuel image is available */
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", "GROUP:Android\\store Locator\\Fuel_image.png");

				params1.put("screen.top", "0%");
				params1.put("screen.height", "100%");
				params1.put("screen.left", "0%");
				params1.put("screen.width", "100%");
				Object result1 = listview.getTestBase().getDriver().executeScript("mobile:image:find", params1);
				PerfectoUtils.reportMessage("Stores are filtered for fuel option", MessageTypes.Pass);
			} catch (Exception e) {
				PerfectoUtils.reportMessage("Stores with fuel is not filtered properly", MessageTypes.Fail);
			}
			try {
				/* Check the car wash image is available */
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", "GROUP:Android\\store Locator\\Carwash_image.png");
				params1.put("screen.top", "0%");
				params1.put("screen.height", "100%");
				params1.put("screen.left", "0%");
				params1.put("screen.width", "100%");
				Object result1 = listview.getTestBase().getDriver().executeScript("mobile:image:find", params1);
				PerfectoUtils.reportMessage("Stores are filtered for carwash option", MessageTypes.Pass);
			} catch (Exception e) {
				PerfectoUtils.reportMessage("Stores with carwash is not filtered properly", MessageTypes.Fail);
			}
		}
	}

	/**
	 * user selects two refine option and then search for the store
	 */
	@QAFTestStep(description = "I select two refine filter and click on done button")
	public void iSelectTwoRefineFilterAndClickOnDoneButton() {
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		/* Clicking on car wash and fuel */
		storelocator.getStorelocatorChkCarwash().click();
		storelocator.getStorelocatorChkFuel().click();
		storelocator.getstorelocatorbtndone().waitForPresent(2000);
		storelocator.getstorelocatorbtndone().click();
	}

	/**
	 * user clicks on clicked on See Store Features user verifies phrmacy phone
	 * number is avaialable or not
	 */
	@QAFTestStep(description = "I navigate to store features and pharmacy number options")
	public void iNavigateToStoreFeaturesAndPharmacyNumberOptions() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();

		/* Navigate to Pharmacy phone number */
		storedetail.getStoredetailsLnkPharmacyphonenumber().click();
		if (storedetail.getStoreldetailsLblAlerttitle().isPresent()) {
			PerfectoUtils.reportMessage("Pharmacy Phone number dial alert is displayed", MessageTypes.Pass);
			storedetail.getStoredetailsLblCancel().click();
			PerfectoUtils.reportMessage("clicked on cancel button", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("Pharmacy phone number is not present", MessageTypes.Fail);
		}

		/* Navigate to Store features */
		try {
			storedetail.getStoreldetailsLblSeestore().waitForPresent(3000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
		}
		if (storedetail.getStoreldetailsLblSeestore().isPresent()) {
			storedetail.getStoreldetailsLblSeestore().click();
			PerfectoUtils.reportMessage("clicked on See Store Features", MessageTypes.Pass);
			storedetail.getStoreldetailsLblPgtitlestorefeature().verifyPresent();
			PerfectoUtils.androiddeviceback();
		} else {
			PerfectoUtils.reportMessage("skipped click option", MessageTypes.Fail);
		}
	}

	/**
	 * user navigate to list view and verify the refine resulrs
	 */
	@QAFTestStep(description = "I navigate back to list view and verify the refine results")
	public void iNavigateBackToListViewAndVerifyTheRefineResults() {

		PerfectoUtils.androiddeviceback();
		iVerifyRefineResult();
	}

	/**
	 * if user dont find the store location
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I select a store in map view for hotuser")
	public void iSelectAStoreInMapViewForHotuser() throws InterruptedException {
		StoremapviewTestPage mapview = new StoremapviewTestPage();
		StoredetailsTestPage storedetail = new StoredetailsTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		if (weeklygrocery.getShopingListEntryByLable("Store Location Not Found").isPresent()) {
			PerfectoUtils.reportMessage("Store Location Not Found", MessageTypes.Info);
			appcrash.getExceptionBtnOk().verifyPresent();
			appcrash.getExceptionBtnOk().click();
		}

		/* Click on store in map view */
		mapview.getStorelocatorMapSelectstore().click();
		PerfectoUtils.reportMessage("Store clicked", MessageTypes.Pass);

		/* Click on white bubble */
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "H-E-B");
		params1.put("screen.top", "0%");
		params1.put("screen.height", "100%");
		params1.put("screen.left", "0%");
		params1.put("screen.width", "100%");
		Object result1 = mapview.getTestBase().getDriver().executeScript("mobile:text:select", params1);
		try {
			storedetail.waitForPageToLoad();
			storedetail.getStoredetailsSetasyourstore().waitForPresent(2000);
			storedetail.getStoredetailsSetasyourstore().verifyPresent();
		} catch (Exception e) {
			PerfectoUtils.getAppiumDriver().navigate().back();
			storelocator.getStorelocatorMapSelectstore2().click();
			PerfectoUtils.reportMessage("Store clicked", MessageTypes.Pass);
			/* Click on white bubble */
			Map<String, Object> params2 = new HashMap<>();
			params2.put("content", "H-E-B");
			params2.put("screen.top", "0%");
			params2.put("screen.height", "100%");
			params2.put("screen.left", "0%");
			params2.put("screen.width", "100%");
			Object result2 = mapview.getTestBase().getDriver().executeScript("mobile:text:select", params2);
		}
	}

	/**
	 * user is in the store locator page user navigate to list view user verify
	 * all the fields of list view
	 * 
	 */
	@QAFTestStep(description = "I validate the list view of store locator page")
	public void iValidateTheListViewOfStoreLocatorPage() {
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		StoremapviewTestPage mapview = new StoremapviewTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();

		/* Navigate to list view */
		storepage.getStorelocatorImgListswitch().waitForPresent(3000);
		storepage.getStorelocatorImgListswitch().click();
		try {
			/* Verify all fields of list view */
			storepage.getStorelocatorLblRefine().verifyPresent();
			mapview.getStorelocatorIconSearch().verifyPresent();
			storepage.getStorelocatorImgListswitch().verifyPresent();
			storepage.getStorelocatorImgMapswitch().verifyPresent();
			StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(0);
			store.getStorelocatorLblStorename().verifyPresent();
			PerfectoUtils.reportMessage("Validated store name: " + store.getStorelocatorLblStorename().getText(),
					MessageTypes.Info);
			store.getStorelocatorLblStoreaddress().verifyPresent();
			PerfectoUtils.reportMessage("Store Address: " + store.getStorelocatorLblStoreaddress().getText(),
					MessageTypes.Info);
			store.getStorelocatorLblMilesaway().verifyPresent();
			PerfectoUtils.reportMessage("Store MilesAway: " + store.getStorelocatorLblMilesaway().getText(),
					MessageTypes.Info);

			if (store.getStorelocatorLblCityname().isPresent()) {
				store.getStorelocatorLblCityname().verifyPresent();
				PerfectoUtils.reportMessage("Store City, State, Zip: " + store.getStorelocatorLblCityname().getText(),
						MessageTypes.Info);
			}

			PerfectoUtils.reportMessage("Store locator LIST view page is validated", MessageTypes.Pass);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Store locator LIST view page is validated and found errors",
					MessageTypes.Fail);
		}
	}

	/**
	 * user selects the second store from store locator page user verify store
	 * name and store city and address
	 */
	@QAFTestStep(description = "I choose second store from the store locator page")
	public void iChooseSecondStoreFromTheStoreLocatorPage() {

		StorelocatorTestPage storepage = new StorelocatorTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		AndroidStepdefProducts androidstep = new AndroidStepdefProducts();

		String storeName = null;

		try {
			storepage.getStorelocatorLblRefine().waitForPresent(10000);
		} catch (Exception e) {
			if (storepage.getStorelocatorTxtPopupmsg().isPresent()) {
				storepage.getStorelocatorTxtPopupmsg().verifyPresent();
				storepage.getStorelocatorBtnAllow().click();
			}
		}

		/* Selecting store */
		if (storepage.getMapAlert().isPresent()) {
			storepage.getBtnOk().click();
			iSeeSearchFieldIsDisplayedByClickingOnSearchIconInMapViewOfStorelocator();
			try {
				androidstep.iEnterValidSearchTermAndSelectSearchButton("San Antonio");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		storepage.getStorelocatorImgListswitch().waitForPresent(5000);
		storepage.getStorelocatorImgListswitch().click();
		storelistresult.launchPage(null);
		StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(1);
		storelistresult.getStorelocatorLblStoreresults().get(1).verifyPresent();

		getBundle().setProperty("StoreName", store.getStorelocatorLblStorename().getText());
		getBundle().setProperty("StoreAddress", store.getStorelocatorLblStoreaddress().getText());
		getBundle().setProperty("StoreCity", store.getStorelocatorLblCityname().getText());
		storeName = store.getStorelocatorLblStorename().getText();
		store.click();
		PerfectoUtils.reportMessage("Selected Store: " + storeName, MessageTypes.Pass);

	}

	/**
	 * store locator error handle
	 * 
	 */
	public static void storelocatorErrorHandle() {
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		/* Handling the store locator error */
		PerfectoUtils.reportMessage("Checking and Handling Popup...", MessageTypes.Pass);
		if (appcrash.getAppExceptionMsgTitle().isPresent()) {
			appcrash.getExceptionBtnOk().click();
			PerfectoUtils.reportMessage("Store Locator Currently Unavailable", MessageTypes.Info);
		} else if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
			PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Pass);
			storelocator.getStorelocatorBtnAllow().click();
			PerfectoUtils.reportMessage("Clicked Allow button.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("No popups found.", MessageTypes.Pass);
		}
	}

	/**
	 * Navigate to list page click on switch to list view
	 */
	@QAFTestStep(description = "I navigate to List View page")
	public static void iNavigateToListViewPage() {
		StorelocatorTestPage storepage = new StorelocatorTestPage();

		// storelocatorErrorHandle();
		/* Click on list view page */
		storepage.getStorelocatorImgListswitch().waitForPresent(3000);
		storepage.getStorelocatorImgListswitch().click();
		PerfectoUtils.reportMessage("Clicked on Switch to List View button.", MessageTypes.Pass);
		storepage.getStorelocatorImgListswitch().waitForPresent(5000);
	}

	/**
	 * user should see store detail page
	 */
	@QAFTestStep(description = "I should see store detail page")
	public void iShouldSeeStoreDetailPage() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();
		boolean storedtl;
		String StoreName;

		/* Verify store detail page */
		if (storedetail.getStoredetailsViewstorename().isPresent()) {
			storedtl = storedetail.getStoredetailsViewstorename().verifyPresent();
			StoreName = storedetail.getStoredetailsViewstorename().getText();
			getBundle().setProperty("SelectedStoreName", storedetail.getStoredetailsViewstorename().getText());

		} else {
			storedtl = storedetail.getlnkViewStoreName1().verifyPresent();
			StoreName = storedetail.getlnkViewStoreName1().getText();
			getBundle().setProperty("SelectedStoreName", storedetail.getlnkViewStoreName1().getText());

		}
		/*
		 * taking the store name to check it in my account
		 */
		// getBundle().setProperty("SelectedStoreName",
		// storedetail.getStoredetailsViewstorename().getText());
		if (storedtl) {
			PerfectoUtils.reportMessage("Store detail page is displayed for the store:" + StoreName, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Store detail page is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify change store, weekly ad and store features in My Store")
	public void iVerifyChangeStoreWeeklyAdAndStoreFeaturesInMyStore() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();

		PerfectoUtils.verticalswipe();
		try {
			storedetail.getlblchangestore().waitForPresent(3000);
			storedetail.getlblchangestore().verifyPresent();
			storedetail.getlblweeklyad().verifyPresent();
			storedetail.getlblstorefeatures().verifyPresent();
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
			storedetail.getlblchangestore().waitForPresent(3000);
			storedetail.getlblchangestore().verifyPresent();
			storedetail.getlblweeklyad().verifyPresent();
			storedetail.getlblstorefeatures().verifyPresent();
		}
	}

	/**
	 * Click on Hamburger after setting location Select my account and navigate
	 * to my store and verify store details is loaded
	 */
	@QAFTestStep(description = "I navigated to store details modal from More section of the app")
	public void iNavigatedToStoreDetailsModalFromMoreSectionOfTheApp() throws Exception {
		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		MyaccountTestPage myaccount = new MyaccountTestPage();
		AndroidStepDefMyaccount androidMyacc = new AndroidStepDefMyaccount();

		// Set location
		// PerfectoUtils.setLocation("San antonio");

		// Navigate to My account page
		androidcommon.getAppHamburger().waitForPresent(3000);
		androidcommon.getAppHamburger().click();
		androidcommon.getAppSliderMyAccount().waitForPresent(3000);
		androidcommon.getAppSliderMyAccount().verifyPresent();
		androidcommon.getAppSliderMyAccount().click();

		// Click on the my store
		myaccount.getLblPagetitle().waitForPresent(3000);
		myaccount.getLblSelectstore().waitForPresent(3000);

		// Select a store if not selected
		if ((myaccount.getLblSelectstore().getText()).equals("Select a Store")) {
			PerfectoUtils.reportMessage("Select a Store is displayed as expected!!", MessageTypes.Pass);
			androidMyacc.iSelectStoreFromMyStore();
		}

		myaccount.getBtnMystore().verifyPresent();
		myaccount.getBtnMystore().click();

		// Verify store details modal is displayed
		storedetailsmodal.getStoremodalLblStorename().waitForPresent(6000);

		if (storedetailsmodal.getStoremodalLblStorename().isPresent())
			PerfectoUtils.reportMessage("Store detail modal is displayed..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Store detail modal is not displayed..", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I verify the map view on the top of the page")
	public void iVerifyTheMapViewOnTheTopOfThePage() {

		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();

		// Verify map section
		storedetailsmodal.getStoremodalLblMapview().verifyPresent();
		storedetailsmodal.getStoremodalLblLocation().verifyPresent();
		storedetailsmodal.getStoremodalLblMappin().verifyPresent();

	}

	/**
	 * user verify the listed options in store detail page
	 */
	@QAFTestStep(description = "I validate Set as My H-E-B store option is not present in store detail")
	public void iValidateSetAsMyHEBStoreOptionIsNotPresentInStoreDetail() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();

		// storedetail.getStoredetailsSetasyourstore().verifyNotPresent();
		if (storedetail.getStoredetailsSetasyourstore().isPresent()) {
			String text = storedetail.getStoredetailsSetasyourstore().getText();
			if (text.equalsIgnoreCase("Change Store")) {
				PerfectoUtils.reportMessage("Set Store option is not available", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Able to see Set Store", MessageTypes.Fail);

			}
		} else {
			PerfectoUtils.reportMessage("unable to find locator", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I clicked on storelocator from home page")
	public void iclickedonstorelocatorfromhomepage() {
		HomeTestPage homepage = new HomeTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		homepage.waitForPageToLoad();
		try {
			homepage.getHomeLblStoreLocator().waitForPresent(10000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
		}
		homepage.getHomeLblStoreLocator().verifyPresent();
		homepage.getHomeLblStoreLocator().click();
		AndroidStepDefStoreLocator.storelocatorErrorHandle();

		/*
		 * Verify whether navigated to Store Locator page
		 */
		if (storelocator.getStorelocatorLblStoreLocator().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Store Locator page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Store Locator page.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I set the store as my heb store")
	public void isetthestoreasmyhebstore() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();
		try {
			storedetail.getStoredetailsSetasyourstore().isPresent();
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
		}
		PerfectoUtils.verticalswipe();
		storedetail.getStoredetailsSetasyourstore().verifyPresent();
		storedetail.getStoredetailsSetasyourstore().click();
		if (storedetail.getbtnmyhebstore().isPresent()) {
			PerfectoUtils.reportMessage("set as my heb store clickable", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("set as my heb store not clickable", MessageTypes.Info);
		}

	}

	@QAFTestStep(description = "I navigate to my store page")
	public void inavigatetomystorepage() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();
		MyaccountTestPage myaccount = new MyaccountTestPage();
		myaccount.getLblSelectstore().waitForPresent(3000);
		myaccount.getLblSelectstore().click();
		String StoreName = null;
		try {
			StoreName = storedetail.getlnkViewStoreName1().getText();
		} catch (Exception e) {
			StoreName = storedetail.getStoredetailsViewstorename().getText();
		}
		System.out.println(StoreName);
		String strselectedstore = getBundle().getString("SelectedStoreName");
		System.out.println(strselectedstore);
		if (StoreName.equals(strselectedstore)) {
			PerfectoUtils.reportMessage("Selected store is now my HEB store", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected store is not my HEB store", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the stores that are getting displayed")
	public void iverifythestoresthataregettingdisplayed() {
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();

		String Strname = storelistresult.getStorelocatorLblStoreresults().get(0).getStorelocatorLblStorename()
				.getText();
		String add = storelistresult.getStorelocatorLblStoreresults().get(0).getStorelocatorLblCityname().getText();
		String addzip = add.replaceAll("\\D", "").substring(0, 5);
		System.setProperty("Store Zip", addzip);
		System.out.println(Strname + addzip);
		PerfectoUtils.androiddeviceback();
		PerfectoUtils.androiddeviceback();
	}

	@QAFTestStep(description = "I verify that different set of stores are getting displayed")
	public void iverifythatdifferentsetofstoresaregettingdisplayed() {
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		String Strname2 = storelistresult.getStorelocatorLblStoreresults().get(0).getStorelocatorLblStorename()
				.getText();
		String add2 = storelistresult.getStorelocatorLblStoreresults().get(0).getStorelocatorLblCityname().getText();
		String newzip = add2.replaceAll("\\D", "").substring(0, 5);
		String oldzip = System.getProperty("Store Zip");
		System.out.println(newzip);
		System.out.println(oldzip);
		if (!oldzip.equals(newzip)) {
			PerfectoUtils.reportMessage("Different set of stores are displayed on changing zip", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Different set of stores are not displayed on changing zip", MessageTypes.Fail);

		}
	}

	@QAFTestStep(description = "I verify image redirects to the appropriate deep link for hot user")
	public void iVverifyImageRedirectsToTheAppropriateDeepLinkForHotUser() {
		AndroidStepDefWeeklyAds androidstepweeklyad = new AndroidStepDefWeeklyAds();
		CommonStepDefWeeklyAds commonstepweeklyad = new CommonStepDefWeeklyAds();
		HomeTestPage homePage = new HomeTestPage();
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		CommonStepDefCoupons commonstepcoupons = new CommonStepDefCoupons();
		RecipeslandingTestPage recipelanding = new RecipeslandingTestPage();
		CommonStepDefRecipes commonsteprecipes = new CommonStepDefRecipes();
		MylistTestPage mylistpage = new MylistTestPage();

		String deeplink = ConfigurationManager.getBundle().getString("deeplink");

		if (storepage.getStorelocatorBtnAllow().isPresent()) {
			storepage.getStorelocatorBtnAllow().click();
		}

		if (deeplink.equalsIgnoreCase("true")) {

			if (storepage.getStorelocatorImgListswitch().isPresent()) {
				PerfectoUtils.reportMessage("Deep link is navigated to Weekly Ad", MessageTypes.Info);

				androidstepweeklyad.iChooseAnStoreFromTheStoreListForGettingWeeklyads();
				commonstepweeklyad.iSeeFeaturesDealPage();

				PerfectoUtils.androiddeviceback();
				try {
					PerfectoUtils.androiddeviceback();
					if (homePage.getImgHomeHero().isPresent()) {
						PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
					} else {
						PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
					}
				} catch (Exception e) {
					PerfectoUtils.androiddeviceback();
					if (homePage.getImgHomeHero().isPresent()) {
						PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
					} else {
						PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
					}
				}

			} else if (couponsselection.getCouponsLblAvailable().isPresent()) {
				PerfectoUtils.reportMessage("Deep link is navigated to Total Available Coupons", MessageTypes.Info);
				commonstepcoupons.iValidateTotalAvailableSection();
				PerfectoUtils.androiddeviceback();

				if (homePage.getImgHomeHero().isPresent()) {
					PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
				}
			} else if (couponsselection.getCouponselectionLblAllcoupons().isPresent()) {
				PerfectoUtils.reportMessage("Deep link is navigated to Selected Coupons", MessageTypes.Info);
				commonstepcoupons.iValidateSelectedSavingsTab();
				PerfectoUtils.androiddeviceback();

				if (homePage.getImgHomeHero().isPresent()) {
					PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
				}
			} else if (recipelanding.getRecipesPagename().isPresent()) {
				PerfectoUtils.reportMessage("Deep link is navigated to Recipe Landing page", MessageTypes.Info);
				commonsteprecipes.iValidateTheElementsInTheRecipeLandingPage();
				PerfectoUtils.androiddeviceback();

				if (homePage.getImgHomeHero().isPresent()) {
					PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
				}
			} else if (mylistpage.getMyListLblPagetitle().isPresent()) {
				PerfectoUtils.reportMessage("Navigated to My lists page.", MessageTypes.Pass);
				mylistpage.getMyListLblPagetitle().verifyPresent();
				PerfectoUtils.androiddeviceback();

				if (homePage.getImgHomeHero().isPresent()) {
					PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
				}
			}

		} else {
			PerfectoUtils.reportMessage("User will not navigate to any page if Deep link is not there.",
					MessageTypes.Info);
			if (homePage.getImgHomeHero().isPresent()) {
				PerfectoUtils.reportMessage("User still is in homepage as no Deep link is associated.",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Navigated to other page in Deep Link is False.", MessageTypes.Fail);
			}
		}
	}

	@QAFTestStep(description = "I verify image redirects to the appropriate deep link")
	public void iVverifyImageRedirectsToTheAppropriateDeepLink() {
		AndroidStepDefWeeklyAds androidstepweeklyad = new AndroidStepDefWeeklyAds();
		CommonStepDefWeeklyAds commonstepweeklyad = new CommonStepDefWeeklyAds();
		HomeTestPage homePage = new HomeTestPage();
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		CommonStepDefCoupons commonstepcoupons = new CommonStepDefCoupons();
		RecipeslandingTestPage recipelanding = new RecipeslandingTestPage();
		CommonStepDefRecipes commonsteprecipes = new CommonStepDefRecipes();
		MylistTestPage mylistpage = new MylistTestPage();

		String deeplink = ConfigurationManager.getBundle().getString("deeplink");

		if (storepage.getStorelocatorBtnAllow().isPresent()) {
			storepage.getStorelocatorBtnAllow().click();
		}

		if (deeplink.equalsIgnoreCase("true")) {

			if (storepage.getStorelocatorImgListswitch().isPresent()) {
				PerfectoUtils.reportMessage("Deep link is navigated to Weekly Ad", MessageTypes.Info);

				androidstepweeklyad.iChooseAnStoreFromTheStoreListForGettingWeeklyads();
				commonstepweeklyad.iSeeFeaturesDealPage();

				PerfectoUtils.androiddeviceback();
				try {
					PerfectoUtils.androiddeviceback();
					if (homePage.getImgHomeHero().isPresent()) {
						PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
					} else {
						PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
					}
				} catch (Exception e) {
					PerfectoUtils.androiddeviceback();
					if (homePage.getImgHomeHero().isPresent()) {
						PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
					} else {
						PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
					}
				}

			} else if (couponsselection.getCouponselectionLblAllcoupons().isPresent()) {
				PerfectoUtils.reportMessage("Deep link is navigated to Total Available Coupons", MessageTypes.Info);
				commonstepcoupons.iValidateCouponsSelectionPage();
				PerfectoUtils.androiddeviceback();

				if (homePage.getImgHomeHero().isPresent()) {
					PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
				}
			} else if (recipelanding.getRecipesPagename().isPresent()) {
				PerfectoUtils.reportMessage("Deep link is navigated to Recipe Landing page", MessageTypes.Info);
				commonsteprecipes.iValidateTheElementsInTheRecipeLandingPage();
				PerfectoUtils.androiddeviceback();

				if (homePage.getImgHomeHero().isPresent()) {
					PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
				}
			} else if (mylistpage.getMyListLblPagetitle().isPresent()) {
				PerfectoUtils.reportMessage("Navigated to My lists page.", MessageTypes.Pass);
				mylistpage.getMyListLblPagetitle().verifyPresent();
				PerfectoUtils.androiddeviceback();

				if (homePage.getImgHomeHero().isPresent()) {
					PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
				}
			}

		} else {
			PerfectoUtils.reportMessage("User will not navigate to any page if Deep link is not there.",
					MessageTypes.Info);
			if (homePage.getImgHomeHero().isPresent()) {
				PerfectoUtils.reportMessage("User still is in homepage as no Deep link is associated.",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Navigated to other page in Deep Link is False.", MessageTypes.Fail);
			}
		}
	}

}
