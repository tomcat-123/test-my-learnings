package com.heb.automation.common.pages.products;

import java.util.List;

import com.heb.automation.common.components.StoreDetailModel;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ProductdetailTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	
	/** Product Details Page ****/
	@FindBy(locator = "pdp.btn.sharebutton")
	private QAFWebElement pdpBtnSharebutton;
	@FindBy(locator = "pdp.btn.shoppinglist")
	private QAFWebElement pdpBtnShoppinglist;
	@FindBy(locator = "pdp.btn.addtolist")
	private QAFWebElement pdpBtnAddtolist;
	@FindBy(locator = "pdp.btn.findinnearbystore")
	private QAFWebElement pdpBtnFindinnearbystore;
	@FindBy(locator = "pdp.lbl.productname")
	private QAFWebElement pdpLblProductname;
	@FindBy(locator = "pdp.lbl.productquantity")
	private QAFWebElement pdpLblProductquantity;
	@FindBy(locator = "pdp.lbl.productprize")
	private QAFWebElement pdpLblProductprize;
	@FindBy(locator = "pdp.img.productimage")
	private QAFWebElement pdpImgProductimage;
	@FindBy(locator = "pdp.lbl.ratings")
	private QAFWebElement pdpLblRatings;
	@FindBy(locator = "pdp.txt.pagetitle")
	private QAFWebElement pdpTxtPagetitle;
	@FindBy(locator = "pdp.lbl.productdetailsection")
	private QAFWebElement pdpLblProductDetailSection;
	@FindBy(locator = "pdp.lbl.specification")
	private QAFWebElement pdpLblSpecification;
	@FindBy(locator = "pdp.lbl.productdes")
	private QAFWebElement pdplblproductdes;
	@FindBy(locator = "pdp.btn.allow")
	private QAFWebElement pdpbtnallow;
	
	
	@FindBy(locator = "pdp.lbl.nutritionalfacts")
	private QAFWebElement pdpLblNutritionalfacts;
	@FindBy(locator = "pdp.img.hebgurantee")
	private QAFWebElement pdpImgHebgurantee;
	@FindBy(locator = "pdp.img.legaldisclamier")
	private QAFWebElement pdpImgLegaldisclamier;
	@FindBy(locator = "pdp.btn.addtocart")
	private QAFWebElement pdpBtnAddtocart;
	@FindBy(locator = "pdp.btn.outofstock")
	private QAFWebElement pdpBtnOutofstock;
	@FindBy(locator = "pdp.lbl.supplementfact")
	private QAFWebElement lblSupplementfact;
	@FindBy(locator = "pdp.lbl.productdetails")
	private QAFWebElement pdplblproductdetails;
	@FindBy(locator = "pdp.lbl.safetyandregulatory")
	private QAFWebElement pdplblsafetyandregulatory;
	@FindBy(locator = "pdp.lbl.safetytitle")
	private QAFWebElement pdplblsafetytitle;
	@FindBy(locator = "pdp.btn.email")
	private QAFWebElement pdpBtnEmail;
	@FindBy(locator = "pdp.btn.notes")
	private QAFWebElement pdpBtnNotes;
	@FindBy(locator = "pdp.btn.reminders")
	private QAFWebElement pdpBtnReminders;
	@FindBy(locator = "pdp.btn.googleplus")
	private QAFWebElement pdpBtnGoogleplus;
	@FindBy(locator = "pdp.btn.facebook")
	private QAFWebElement pdpBtnFacebook;

	
	/** Product Details \ Description section**/
	@FindBy(locator = "pdp.lbl.descriptionpgtitle")
	private QAFWebElement pdpLblDescriptionPgTitle;
	
	
	@FindBy(locator = "pdp.icon.nutritiontagslist")
	private List<QAFWebElement> iconNutritiontagslist;
	@FindBy(locator = "pdp.lbl.titlenutritionaltags")
	private QAFWebElement lblTitlenutritionaltags;
	@FindBy(locator = "pdp.lbl.nutritionaltagnames")
	private List<QAFWebElement> lblNutritionaltagnames;
	@FindBy(locator = "pdp.lbl.hearthealthy")
	private QAFWebElement lblHearthealthy;
	@FindBy(locator = "pdp.lbl.specificationspagetitle")
	private QAFWebElement lblSpecificationspagetitle;
	@FindBy(locator = "pdp.lbl.pdtdescriptionheading")
	private QAFWebElement lblPdtdescriptionheading;
	@FindBy(locator = "pdp.lbl.pdtdescriptionparagraph")
	private QAFWebElement lblPdtdescriptionparagraph;

	@FindBy(locator = "pdp.lbl.gmail")
	private QAFWebElement lblGmail;
	
	/**
	 * new sprint 14 coupon section pdp
	 */
	@FindBy(locator = "pdp.couponsection.txt.coupons")
	private QAFWebElement couponsectiontxtcoupons;
	@FindBy(locator = "pdp.couponssection.img.coupons")
	private List<QAFWebElement> couponssectionimgcoupons;
	@FindBy(locator = "pdp.couponssection.img.scissors")
	private List<QAFWebElement> couponssectionimgscissors;
	@FindBy(locator = "pdp.storemodal.distance")
	private List<QAFWebElement> pdpstoremodaldistance;
	
	/** Product Details \ Store Availability Section**/
	@FindBy(locator = "pdp.storeavailability.txt.storeavailability")
	private QAFWebElement txtstoreavailability;
	@FindBy(locator = "pdp.storeavailability.lnk.viewnearbystores")
	private QAFWebElement lnkviewnearbystores;
	@FindBy(locator = "pdp.storeavailability.lbl.storename")
	private QAFWebElement lblstorename;
	@FindBy(locator = "pdp.storeavailability.lbl.storeaddress")
	private QAFWebElement lblstoreaddress;
	@FindBy(locator = "pdp.storeavailability.lbl.storeicon")
	private QAFWebElement lblstoreicon;
	@FindBy(locator = "pdp.storeavailability.txt.milesnumber")
	private QAFWebElement txtmilesnumber;
	@FindBy(locator = "pdp.storeavailability.txt.miles")
	private QAFWebElement txtmiles;
	@FindBy(locator = "pdp.storeavailability.txt.storesnotloadederror")
	private QAFWebElement txtstoresnotloadederror;
	@FindBy(locator = "pdp.storeavailability.btn.tryagain")
	private QAFWebElement btntryagain;
	@FindBy(locator = "pdp.storeavailability.txt.notavailable")
	private QAFWebElement txtnotavailable;
	@FindBy(locator = "pdp.storepage.storefeature.lbl")
	private QAFWebElement pdpstorepagestorefeaturelbl;
	@FindBy(locator = "pdp.storefeature.txt.storefeature")
	private QAFWebElement pdpstorefeaturetxtstorefeature;
	@FindBy(locator = "pdp.storefeaturetxt.storedetailpage")
	private QAFWebElement pdpstorefeaturetxtstoredetailpage;
	@FindBy(locator = "pdp.storefeature.btn.back")
	private QAFWebElement pdpstorefeaturebtnback;
	@FindBy(locator = "pdp.storefeaturetxt")
	private QAFWebElement pdpstorefeaturetxt;
	@FindBy(locator = "pdp.storeavailability.txt.nostoreproduct")
	private QAFWebElement txtnostoreproduct;
	
	/** Product Details \ Store Modal Page**/
	@FindBy(locator = "pdp.storelistmodal.txt.nearbystores")
	private QAFWebElement txtnearbystores;
	@FindBy(locator = "pdp.storelistmodal.lbl.cancelicon")
	private QAFWebElement lblcancelicon;
	@FindBy(locator = "pdp.storelistmodal.lbl.productname")
	private QAFWebElement lblproductname;
	@FindBy(locator = "pdp.storelistmodal.lbl.storelist")
	private List<QAFWebElement> lblstorelist;
	@FindBy(locator = "pdp.lbl.uom")
	private QAFWebElement pdpLblUom;
	@FindBy(locator = "pdp.lbl.productdescription")
	private QAFWebElement LblProductDescription;
	@FindBy(locator = "pdp.lbl.centralmarketguarantee")
	private QAFWebElement LblCentralMarketGuarantee;
	@FindBy(locator = "pdp.lbl.paginationdots")
	private List<QAFWebElement> LblPaginationDots;
	@FindBy(locator = "pdp.img.secondproductimage")
	private List<QAFWebElement> ImgSecondProductImage;
	
	
	@FindBy(locator = "pdp.storemodal.storelist")
	private List<StoreDetailModel> storelist;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getPdpBtnSharebutton() {
		return pdpBtnSharebutton;
	}


	public QAFWebElement getPdpBtnShoppinglist() {
		return pdpBtnShoppinglist;
	}

	public QAFWebElement getPdpBtnAddtolist() {
		return pdpBtnAddtolist;
	}

	public QAFWebElement getPdpBtnFindinnearbystore() {
		return pdpBtnFindinnearbystore;
	}

	public QAFWebElement getPdpLblProductname() {
		return pdpLblProductname;
	}

	public QAFWebElement getPdpLblProductquantity() {
		return pdpLblProductquantity;
	}

	public QAFWebElement getPdpLblProductprize() {
		return pdpLblProductprize;
	}

	public QAFWebElement getPdpImgProductimage() {
		return pdpImgProductimage;
	}

	public QAFWebElement getPdpLblRatings() {
		return pdpLblRatings;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getPdpTxtPagetitle() {
		return pdpTxtPagetitle;
	}

	public QAFWebElement getPdpLblProductDetailSection() {
		return pdpLblProductDetailSection;
	}

	public QAFWebElement getPdpLblSpecification() {
		return pdpLblSpecification;
	}

	public QAFWebElement getPdpLblDescriptionPgTitle() {
		return pdpLblDescriptionPgTitle;
	}
	
	public QAFWebElement getPdpLblProductdes() {
		return pdplblproductdes;
	}

	public QAFWebElement getPdpLblNutritionalfacts() {
		return pdpLblNutritionalfacts;
	}

	public QAFWebElement getPdpImgHebgurantee() {
		return pdpImgHebgurantee;
	}

	public QAFWebElement getPdpImgLegaldisclamier() {
		return pdpImgLegaldisclamier;
	}

	public QAFWebElement getPdpBtnAddtocart() {
		return pdpBtnAddtocart;
	}

	public QAFWebElement getPdpBtnOutofstock() {
		return pdpBtnOutofstock;
	}

	public QAFWebElement getLblSupplementfact() {
		return lblSupplementfact;
	}

	public QAFWebElement getPdpLblProductDetails() {
		return pdplblproductdetails;
	}

	public QAFWebElement getPdpLblSafetyAndRegulatory() {
		return pdplblsafetyandregulatory;
	}

	public QAFWebElement getPdpLblSafetyTitle() {
		return pdplblsafetytitle;
	}

	public QAFWebElement getPdpBtnEmail() {
		return pdpBtnEmail;
	}

	public QAFWebElement getPdpBtnNotes() {
		return pdpBtnNotes;
	}

	public QAFWebElement getPdpBtnReminders() {
		return pdpBtnReminders;
	}

	public QAFWebElement getPdpBtnGoogleplus() {
		return pdpBtnGoogleplus;
	}

	public QAFWebElement getPdpBtnFacebook() {
		return pdpBtnFacebook;
	}

	public List<QAFWebElement> getIconNutritiontagslist() {
		return iconNutritiontagslist;
	}

	public QAFWebElement getLblTitlenutritionaltags() {
		return lblTitlenutritionaltags;
	}

	public List<QAFWebElement> getLblNutritionaltagnames() {
		return lblNutritionaltagnames;
	}

	public QAFWebElement getLblHearthealthy() {
		return lblHearthealthy;
	}

	public QAFWebElement getLblSpecificationspagetitle() {
		return lblSpecificationspagetitle;
	}

	public QAFWebElement getLblPdtdescriptionheading() {
		return lblPdtdescriptionheading;
	}

	public QAFWebElement getLblPdtdescriptionparagraph() {
		return lblPdtdescriptionparagraph;
	}


	
	public QAFWebElement getlblGmail() {
		return lblGmail;
	}
	
	
	
	public QAFWebElement gettxtstoreavailability() {
		return txtstoreavailability;
	}
	
	public QAFWebElement getlnkviewnearbystores() {
		return lnkviewnearbystores;
	}
	
	public QAFWebElement getlblstorename() {
		return lblstorename;
	}
	
	public QAFWebElement getlblstoreaddress() {
		return lblstoreaddress;
	}
	
	public QAFWebElement getlblstoreicon() {
		return lblstoreicon;
	}
	
	public QAFWebElement gettxtmilesnumber() {
		return txtmilesnumber;
	}
	
	public QAFWebElement gettxtmiles() {
		return txtmiles;
	}
	
	public QAFWebElement gettxtnearbystores() {
		return txtnearbystores;
	}
	
	public QAFWebElement getlblcancelicon() {
		return lblcancelicon;
	}
	
	public QAFWebElement getlblproductname() {
		return lblproductname;
	}
	
	public List<QAFWebElement> getlblstorelist() {
		return lblstorelist;
	}
	public QAFWebElement getcouponsectiontxtcoupons() {
		return couponsectiontxtcoupons;
	}
	
	public List<QAFWebElement> getcouponssectionimgcoupons() {
		return couponssectionimgcoupons;
	}
	public List<QAFWebElement> getcouponssectionimgscissors() {
		return couponssectionimgscissors;
	}
	
	public QAFWebElement gettxtstoresnotloadederror() {
		return txtstoresnotloadederror;
	}
	
	public QAFWebElement getbtntryagain() {
		return btntryagain;
	}
	
	public QAFWebElement getBtnAllow() {
		return pdpbtnallow;
	}
	
	public List<QAFWebElement> getpdpstoremodaldistance() {
		return pdpstoremodaldistance;
	}
		
	public QAFWebElement gettxtnotavailable() {
		return txtnotavailable;
	}
	
	public QAFWebElement getPdpLblUom() {
		return pdpLblUom;
	}
	public QAFWebElement getpdpstorepagestorefeaturelbl() {
		return pdpstorepagestorefeaturelbl;
	}

	public QAFWebElement getpdpstorefeaturetxtstorefeature() {
		return pdpstorefeaturetxtstorefeature;
	}
	public QAFWebElement getpdpstorefeaturebtnback() {
		return pdpstorefeaturebtnback;
	}
	public QAFWebElement getpdpstorefeaturetxtstoredetailpage() {
		return pdpstorefeaturetxtstoredetailpage;
	}
	
	public QAFWebElement getpdpstorefeaturetxt() {
		return pdpstorefeaturetxt;
	}
	
	public QAFWebElement gettxtnostoreproduct() {
		return txtnostoreproduct;
	}
	
	public List<StoreDetailModel> getStorelist() {
		return storelist;
	}
	public QAFWebElement getLblProductDescription() {
		return LblProductDescription;
	}
	
	public QAFWebElement getLblCentralMarketGuarantee() {
		return LblCentralMarketGuarantee;
	}
	
	public List<QAFWebElement> getLblPaginationDots() {
		return LblPaginationDots;
	}
	
	public List<QAFWebElement> getImgSecondProductImage() {
		return ImgSecondProductImage;
	}
}
