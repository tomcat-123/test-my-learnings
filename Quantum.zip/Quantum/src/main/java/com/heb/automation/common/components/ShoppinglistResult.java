package com.heb.automation.common.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ShoppinglistResult extends QAFWebComponent{

	public ShoppinglistResult(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(locator = "wg.list.itemname")
	private QAFWebElement wgListItemname;
	
	@FindBy(locator = "wg.list.selectsspecificitem")
	private QAFWebElement wgListSelectsspecificitem;
	
	@FindBy(locator = "wg.txt.shoppinglistqtychild")
	private QAFWebElement wgTxtShoppinglistquantity;
	
	@FindBy(locator = "wg.lbl.expirydate")
	private QAFWebElement wgLblExpirydate;
	
	public QAFWebElement getWgListItemname() {
		return wgListItemname;
	}
	
	public QAFWebElement getWgListSelectsspecificitem() {
		return wgListSelectsspecificitem;
	}
	

	public QAFWebElement getWgTxtShoppinglistquantity() {
		return wgTxtShoppinglistquantity;
	}
	
	public QAFWebElement getWgLblExpirydate() {
		return wgLblExpirydate;
	}
}
