package com.heb.automation.common.pages.shoppinglist;

import java.util.List;

//import com.heb.automation.common.components.MyListPage;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MylistTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "myLists.lbl.editlist")
	private QAFWebElement mylistsLblEditList;
	@FindBy(locator = "myLists.lbl.deletelist")
	private QAFWebElement mylistsLblDeleteList;
	@FindBy(locator = "myLists.btn.cancel")
	private QAFWebElement myListsBtnCancel;
	@FindBy(locator = "myLists.btn.save")
	private QAFWebElement mylistsbtnSave;
	@FindBy(locator = "myLists.img.plus")
	private QAFWebElement myListsImgPlus;
	@FindBy(locator = "myLists.lbl.weeklygroceries")
	private QAFWebElement mylistsLblWeeklygroceries;
	@FindBy(locator = "myList.lbl.pagetitle")
	private QAFWebElement myListLblPagetitle;
	@FindBy(locator = "myLists.btn.login")
	private QAFWebElement mylistsBtnLogin;
	@FindBy(locator = "myLists.icon.overflow")
	private QAFWebElement mylistsIconOverflow;
	@FindBy(locator = "myLists.btn.delete")
	private QAFWebElement mylistsBtnDelete;
	@FindBy(locator = "myLists.lbl.firstshoppinglist")
	private QAFWebElement mylistsLblFirstShoppingList;
	@FindBy(locator = "myLists.lbl.firstshoppinglist")
	private List<QAFWebElement> mylistsLblShoppingList;
	@FindBy(locator = "myLists.lbl.popuperror")
	private QAFWebElement myListsLblPopuperror;
	@FindBy(locator = "myLists.lbl.email")
	private QAFWebElement myListslblemail;
	@FindBy(locator = "myLists.txt.enternewlist")
	private QAFWebElement myListTxtEnterNewList;
	@FindBy(locator = "myLists.btn.Cancel")
	private QAFWebElement mylistsBtnCancel;
	@FindBy(locator = "myLists.lbl.pleaselogin")
	private QAFWebElement mylistsLblPleaselogin;
	@FindBy(locator = "myLists.lbl.createshoppinglist")
	private QAFWebElement mylistslblCreateShoppingList;
	@FindBy(locator = "myLists.btn.add")
	private QAFWebElement mylistsBtnadd;
	private List<QAFWebElement> mylistsLblNewlist;
	@FindBy(locator = "myLists.btn.login")
	private QAFWebElement myListsBtnLogin;
	@FindBy(locator = "myLists.btn.register")
	private QAFWebElement myListsBtnRegister;
	@FindBy(locator = "myList.lbl.lstnamehotuser")
	private QAFWebElement myListLblLstNameHotUser;
	@FindBy(locator = "myList.lbl.lstnamehotuser")
	private List<QAFWebElement> myListLblLstNameHotUserItems;
	@FindBy(locator = "myLists.lbl.popuptitle")
	private QAFWebElement myListsPopUpTitle;
	@FindBy(locator = "myLists.btn.rename")
	private QAFWebElement mylistBtnRename;
	@FindBy(locator = "myLists.txt.renamethelist")
	private QAFWebElement myListTxtRenameTheList;
	@FindBy(locator = "myLists.editlist.lbl.listpage")
	private QAFWebElement myListLblEditListPage;
	@FindBy(locator = "myLists.editlist.lbl.taprowstoedit")
	private QAFWebElement lblTaprowstoedit;
	@FindBy(locator = "myLists.deletelist.img.delete")
	private QAFWebElement myListsIconDelete;
	@FindBy(locator = "myLists.deletelist.btn.delete")
	private QAFWebElement myListsBtnDeleteInDelLstOverlay;
	@FindBy(locator = "myLists.deletelist.btn.cancel")
	private QAFWebElement myListsBtnCancelInDelLstOverlay;
	@FindBy(locator = "myLists.deletelist.lbl.title")
	private QAFWebElement myListsTitleDelLstTitleInDelLstOverlay;
	@FindBy(locator = "myLists.deletelist.btn.delmsg")
	private QAFWebElement myListsBtnDelMsgDelLstOverlay;
	@FindBy(locator = "myLists.lbl.copylist")
	private QAFWebElement myListsLblCopylist;
	@FindBy(locator = "myLists.lbl.copylistoverlay")
	private QAFWebElement myListsLblCopylistoverlay;
	@FindBy(locator = "myLists.lbl.selectedlist")
	private List<QAFWebElement> myListsLblSelectedlist;
	@FindBy(locator = "myLists.btn.add")
	private QAFWebElement myListsBtnAdd;
	@FindBy(locator = "myList.lbl.titlepleaselogin")
	private QAFWebElement myListLblTitlePleaseLogIn;
	@FindBy(locator = "myList.lbl.tocreatemultiplelstlogin")
	private QAFWebElement myListLblToCreateMultipleLstLogin;
	@FindBy(locator = "myLists.btn.done")
	private QAFWebElement myListsBtndone;
	@FindBy(locator = "myList.lbl.listname")
	private List<QAFWebElement> myListsLblListname;
	@FindBy(locator = "myLists.lbl.wishlist")
	private QAFWebElement myListsLblWishlist;
	@FindBy(locator = "myList.lbl.listiconarrow")
	private List<QAFWebElement> myListLblListIconArrow;
	@FindBy(locator = "myLists.list.listitemnames")
	private List<QAFWebElement> myListsListListItemNames;
	@FindBy(locator = "myLists.deletelist.lbl.taprowstodelete")
	private QAFWebElement lblTaprowstodelete;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getMylistsLblWeeklygroceries() {
		return mylistsLblWeeklygroceries;
	}

	public QAFWebElement getMyListLblPagetitle() {
		return myListLblPagetitle;
	}

	public QAFWebElement getMylistsLblEditList() {
		return mylistsLblEditList;
	}

	public QAFWebElement getmyListslblemail() {
		return myListslblemail;
	}

	public QAFWebElement getMylistsLblDeleteList() {
		return mylistsLblDeleteList;
	}

	public QAFWebElement getMylistsbtnSave() {
		return mylistsbtnSave;
	}

	public QAFWebElement getMylistsBtnCancel() {
		return mylistsBtnCancel;
	}

	public QAFWebElement getMylistsBtnLogin() {
		return mylistsBtnLogin;
	}

	public QAFWebElement getMylistsLblPleaselogin() {
		return mylistsLblPleaselogin;
	}

	public QAFWebElement getMylistslblCreateShoppingList() {
		return mylistslblCreateShoppingList;
	}

	public QAFWebElement getMylistsBtnadd() {
		return mylistsBtnadd;
	}

	public QAFWebElement getMyListsBtnLogin() {
		return myListsBtnLogin;
	}

	public QAFWebElement getMyListsBtnRegister() {
		return myListsBtnRegister;
	}

	public List<QAFWebElement> getMylistsLblNewlist() {
		return mylistsLblNewlist;
	}

	public QAFWebElement getMyListsImgPlus() {
		return myListsImgPlus;
	}

	public QAFWebElement getMyListsBtnCancel() {
		return myListsBtnCancel;
	}

	public QAFWebElement getMylistsIconOverflow() {
		return mylistsIconOverflow;
	}

	public QAFWebElement getMyListLblLstNameHotUser() {
		return myListLblLstNameHotUser;
	}

	public List<QAFWebElement> getMyListLblLstNameHotUserItems() {
		return myListLblLstNameHotUserItems;
	}

	public QAFWebElement getMyListsIconDelete() {
		return myListsIconDelete;
	}

	public QAFWebElement getMyListsBtnDeleteInDelLstOverlay() {
		return myListsBtnDeleteInDelLstOverlay;
	}

	public QAFWebElement getMyListsBtnCancelInDelLstOverlay() {
		return myListsBtnCancelInDelLstOverlay;
	}

	public QAFWebElement getMyListsTitleDelLstTitleInDelLstOverlay() {
		return myListsTitleDelLstTitleInDelLstOverlay;
	}

	public QAFWebElement getMyListsBtnDelMsgDelLstOverlay() {
		return myListsBtnDelMsgDelLstOverlay;
	}

	public QAFWebElement getMylistsLblFirstShoppingList() {
		return mylistsLblFirstShoppingList;
	}

	public List<QAFWebElement> getMylistsLblShoppingList() {
		return mylistsLblShoppingList;
	}

	public QAFWebElement getMylistsBtnDelete() {
		return mylistsBtnDelete;
	}

	public QAFWebElement getMyListTxtEnterNewList() {
		return myListTxtEnterNewList;
	}

	public QAFWebElement getMyListsPopUpTitle() {
		return myListsPopUpTitle;
	}

	public QAFWebElement getMylistBtnRename() {
		return mylistBtnRename;
	}

	public QAFWebElement getMyListTxtRenameTheList() {
		return myListTxtRenameTheList;
	}

	public QAFWebElement getMyListLblEditListPage() {
		return myListLblEditListPage;
	}

	public QAFWebElement getMyListsLblCopylist() {
		return myListsLblCopylist;
	}

	public QAFWebElement getMyListsLblCopylistoverlay() {
		return myListsLblCopylistoverlay;
	}

	public List<QAFWebElement> getMyListsLblSelectedlist() {
		return myListsLblSelectedlist;
	}

	public QAFWebElement getMyListsBtnadd() {
		return mylistsBtnadd;
	}

	public QAFWebElement getMyListLblTitlePleaseLogIn() {
		return myListLblTitlePleaseLogIn;
	}

	public QAFWebElement getMyListLblToCreateMultipleLstLogin() {
		return myListLblToCreateMultipleLstLogin;
	}

	public QAFWebElement getMyListsBtndone() {
		return myListsBtndone;
	}

	public QAFWebElement getMyListsLblWishlist() {
		return myListsLblWishlist;
	}

	public List<QAFWebElement> getMyListsLblListname() {
		return myListsLblListname;
	}

	// DYNAMIC value declaring
	public QAFWebElement getShopingListEntryByLable(String lable) {
		String loc = String.format(pageProps.getString("myList.lbl.listdynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public List<QAFWebElement> getMyListLblListIconArrow() {
		return myListLblListIconArrow;
	}

	public List<QAFWebElement> getMyListsListListItemNames() {
		return myListsListListItemNames;
	}

	// DYNAMIC value declaring
	public QAFWebElement getMyListLblListIconArrowByLable(String lable) {
		String loc = String.format(pageProps.getString("myList.icon.listiconarrow"), lable);
		return new QAFExtendedWebElement(loc);
	}

	// DYNAMIC value declaring
	public QAFWebElement getMyListsListListItemNamesByLable(int i) {
		String loc = String.format(pageProps.getString("myLists.list.listitemnames"), i);
		return new QAFExtendedWebElement(loc);
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getMyListsLblPopuperror() {
		return myListsLblPopuperror;
	}

	public QAFWebElement getLblTaprowstoedit() {
		return lblTaprowstoedit;
	}

	public QAFWebElement getLblTaprowstodelete() {
		return lblTaprowstodelete;
	}
	
}
