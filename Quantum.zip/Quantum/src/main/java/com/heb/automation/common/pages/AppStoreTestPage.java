package com.heb.automation.common.pages;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class AppStoreTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "appstore.lbl.heb")
	private QAFWebElement lblHeb;
	@FindBy(locator = "appstore.lbl.iphone")
	private QAFWebElement lblIphone;
	@FindBy(locator = "appstore.img.share")
	private QAFWebElement imgShare;
	
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}
	
	public QAFWebElement getLblHeb() {
		return lblHeb;
	}

	public QAFWebElement getLblIphone() {
		return lblIphone;
	}

	public QAFWebElement getImgShare() {
		return imgShare;
	}

}
