package com.heb.automation.android.steps.shoppinglist;

import static com.heb.automation.common.PerfectoUtils.getAppiumDriver;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.android.pages.EmailcontentTestPage;
import com.heb.automation.android.steps.AndroidStepDef;
import com.heb.automation.android.steps.weeklyad.AndroidStepDefWeeklyAds;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.ProductResult;
import com.heb.automation.common.components.ShoppinglistResult;
import com.heb.automation.common.components.ShoppinglistSearchResult;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.products.ProductdetailTestPage;
import com.heb.automation.common.pages.products.ProductlandingTestPage;
import com.heb.automation.common.pages.products.ProductsearchresultTestPage;
import com.heb.automation.common.pages.products.ProductsresultlistTestPage;
import com.heb.automation.common.pages.recipes.RecipedetailTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.pages.scanner.ScannerTestPage;
import com.heb.automation.common.pages.shoppinglist.AddtolistTestPage;
import com.heb.automation.common.pages.shoppinglist.ListdetailsTestPage;
import com.heb.automation.common.pages.shoppinglist.LoginpopupTestPage;
import com.heb.automation.common.pages.shoppinglist.MylistTestPage;
import com.heb.automation.common.pages.shoppinglist.PdtdetailspagefromlistTestPage;
import com.heb.automation.common.pages.shoppinglist.SendemailTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriessearchresultTestPage;
import com.heb.automation.common.pages.storelocator.StoredetailsTestPage;
import com.heb.automation.common.pages.storelocator.StorelocatorTestPage;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.heb.automation.ios.steps.IOSStepdef;
import com.heb.automation.ios.steps.myaccount.IOSStepDefMyAccounts;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in Scanner

	I swipe across the name of a Shopping list
	I validate the properties of Send Email page
	I navigate back to My Lists page
	I navigate back to Weekly Groceries page
	I click on Search to add products field
	I navigate to Weekly Groceries page
	I select <List Name> from mylist page
	I validate the displayed <List Name> page
	I see the Scan Receipt page on selecting Scan Receipt option
	I see Search Field is displayed by clicking on Search Icon
	I should see the checkmark in the checkbox
	I uncheck the Shopping list Items
	I should not see the checkmark in the checkbox
	I see the Product details page on selecting product from the list
	I see the Scroling selector page on selecting Qty field
	I see the Qty field updated on selecting quantity and click on Save button
	I see the entered notes updated in the Notes field on selecting and entering notes
	I see Weekly Groceries page on clicking device back button
	I should see All items are deleted from list
	I select device back button
	I should not see option to create new list
	I should see the added item in the list
	I validate the page properties as a hot user
	I validate the page properties as a cold user
	I select Delete All Items option
	I see the Product details page on selecting specific product from the list
	I see product item details page by clicking on see more details link
	I validate search products page
	I should see the popup to enter list name
	I select the Item first entry
	I click on Select Specific Product link
	I navigate back to selected list page
	I enter valid email address and click on Send or submit button
	I should see the checkboxes of all items Unchecked
	I select the Search box from list detail page
	I validate the Search Products page
	I see the <List name> page on selecting device back button
	I select and navigate to first list
	I check off shopping list items
	I select a UPC specific item
	I enter valid search term {0}and select Search button in weekly groceries page
	I should see the selected Item in the Weekly Groceries page
	I validate the search results page
	I see toaster message on selecting Add button in Add To List popup
	I click on Add/Done button
	I click the save/add button
	I Verify cold user is not able to delete the Weekly Grocery List
	I navigate to Uncheck All Items
	I navigate to Send Email page
	I click on Login/Submit button
	I enter the Shopping list name
	I search for product {0} from list details page
	I select newly added list name
	I swipe across the name of the product
	I should not see the product
	I see Enter Reciept No Pop-up
	I verify available products in List Details page
	I select the list which haivng item copied
	I select the Overflow/Edit icon from the action bar
	I should see Copy Items to List popup
	I see Add to List popup on selecting Add to List button
	I enter Reciept Number
	I see List detail page on clicking corresponding list name from My list page
	I navigate back to My List page from Registration page
	I should see the error toast message
	I enter invalid Reciept Number
	I select the Overflow icon from my lists page
	I should see the list of options
	I select delete list option
	I should see My Lists page in Edit mode
	I should see the List name highlighted in red
	I select delete icon
	I should see the Delete Lists popup
	I select the Delete button from delete list popup
	I should not see the list name
	I select Edit List option
	I should see the Rename <Shoping List> popup
	I edit the Shopping List name
	I click the Rename button
	I select a list to delete
	I enter existing List name to rename
	I select the first list
	I validate the Weekly Groceries page
	I click on plus from action bar
	I should see the Please Log In popup
	I verify if all ingredients added in selected shopping list
	I delete all items from weekly groceries shopping list
	I see error message for invalid email after click on Login/Submit button
	I should see the Product which is copied to this list
	I see the selected ingredient on selecting all ingredient within corresponding check field
	I should see the Search Results page
	I select product from CDP to PDP
	I enter Invalid email address and click on Send/ submit button
	I should see the error popup/ toast message
	I get the product name from list details page
	I change the sender email address and click on Send/ submit button
	I verify if ingredients added in selected shopping list of hot user
	I click on Search to add products field from CDP
	I navigate back to list details page
	I select few lists to delete
	I should not see the scanned product in the selected list
	I should see My Lists page in Delete mode
	I delete all items from wish list of shopping list
	I verify if ingredients added in selected shopping list
	I navigate to My List page
	I verify My List page is displayed
	I see weekly grocery list in My list page
	I click on plus icon to add list
	I verify the weekly grocery page
	I see error message for invalid password after click on Login/Submit button
	I see the list name is not deleted in Android
	I swipe across the name of a Shopping list and not clicking DELETE button
	I cancel the delete process by clicking on the same list
	I click Cancel button on login PopUp and see weekly grocery list in My list page
	I click continue without registering as guest and see weekly grocery list in My list page
	I see the list name is not deleted in IOS
	I select the Overflow/Edit icon from my list page in Android
	Verify the Search screen is not visible on selecting Cancel button
	I should see the list of options in list details page
	I see Search Field is displayed by clicking on Plus Icon
	Verify the Searched product is not added to the list
	I select Delete Item option
	I cancel the process of deleting element
	I cancel the process of sending an email
	I verify that the process is cancelled
	I cancel the process of replacing generic item
	I cancel the delete process by clicking on the same item name
	I swipe across the name of the first item
	I see list product details page on clicking device back button
	I see the <List name> page on selecting device back button once
	I see Weekly Groceries page on clicking device back button once*/

public class AndroidStepDefShoppingList {

	/**
	 * Swiping across a selected list 'DeletedListName' to delete Update the
	 * list name in a variable
	 * 
	 * @return DeletedListName
	 */
	@QAFTestStep(description = "I swipe across the name of a Shopping list")
	public void iSwipeAcrossTheNameOfAShoppingList() {
		MylistTestPage myListPage = new MylistTestPage();

		String strFirstListName = null;
		myListPage.waitForPageToLoad();
		myListPage.getMyListLblLstNameHotUser().waitForPresent(3000);
		strFirstListName = myListPage.getMyListLblLstNameHotUser().getText();
		getBundle().setProperty("DeletedListName", strFirstListName);

		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartX = Integer.parseInt(myListPage.getMyListLblLstNameHotUser().getAttribute("X"));
		int intEndX = (int) (size.width * 0.90);
		int intStartY = Integer.parseInt(myListPage.getMyListLblLstNameHotUser().getAttribute("Y"));
		getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);
		PerfectoUtils.reportMessage("Swiping across the list name: " + strFirstListName + " to delete");
	}

	/**
	 * Verify the fields - sender name, sender email, recipient email, send me
	 * copy & send button in send email template are present copy & send button
	 * in send email template are present
	 */

	@QAFTestStep(description = "I validate the properties of Send Email page")
	public void iValidateThePropertiesOfSendEmailPage() {
		SendemailTestPage sendemail = new SendemailTestPage();

		/* Validating send email page */
		try {
			sendemail.getSendemailTxtSendername().isPresent();
			sendemail.getSendemailTxtSenderemail().isPresent();
			sendemail.getSendemailTxtRecipientemail().isPresent();
			sendemail.getSendemailBtnSendmecopy().isPresent();
			sendemail.getSendemailBtnSend().isPresent();
			PerfectoUtils.reportMessage("Page Validated by clicking share button to send Email");
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Page validation not successful");
		}
	}

	/**
	 * Navigate back to previous page
	 */
	@QAFTestStep(description = "I navigate back to My Lists page")
	public void iNavigateBackToMyListsPage() {

		PerfectoUtils.androiddeviceback();
	}

	/**
	 * Navigate back to previous page Verify the Weekly groceries page is
	 * present
	 */
	@QAFTestStep(description = "I navigate back to Weekly Groceries page")
	public void iNavigateBackToWeeklyGroceriesPage() {
		WeeklygroceriesTestPage weeklygroceries = new WeeklygroceriesTestPage();

		try {
			PerfectoUtils.androiddeviceback();
			weeklygroceries.getWgBtnSearch().waitForPresent(3000);
			PerfectoUtils.reportMessage("Success: Navigated back to weekly groceries page.");
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Error: Not navigated back to weekly groceries page.");
		}
	}

	/**
	 * Verify and Click on the search field
	 */
	@QAFTestStep(description = "I click on Search to add products field")
	public void iClickOnSearchToAddProductsField() {
		WeeklygroceriesTestPage weeklyGroceries = new WeeklygroceriesTestPage();

		weeklyGroceries.getWgBtnSearch().verifyPresent();
		weeklyGroceries.getWgBtnSearch().click();
	}

	/**
	 * Navigate to weekly groceries page Verify the weekly groceries page is
	 * loaded
	 */
	@QAFTestStep(description = "I navigate to Weekly Groceries page")
	public void iNavigateToWeeklyGroceriesPage() {
		MylistTestPage mylistpage = new MylistTestPage();
		WeeklygroceriesTestPage weeklygroceries = new WeeklygroceriesTestPage();

		mylistpage.getMylistsLblWeeklygroceries().click();
		weeklygroceries.getWgImgMenuoverflow().waitForPresent(30000);
		weeklygroceries.getWgImgMenuoverflow().verifyPresent();
	}

	/**
	 * Look for a selected list from list of lists Select the respective list
	 * 'ListName'
	 * 
	 * @return ListName
	 */
	@QAFTestStep(description = "I select <List Name> from mylist page")
	public void iSelectListNameFromMylistPage() {
		MylistTestPage mylist = new MylistTestPage();

		List<QAFWebElement> mylistitems = mylist.getMyListLblLstNameHotUserItems();

		for (QAFWebElement mylistvalue : mylistitems) {
			String listname = mylistvalue.getText();
			getBundle().setProperty("ListName", listname);
			mylistvalue.click();
			PerfectoUtils.reportMessage("Clicked List: " + listname + " in My List page ", MessageTypes.Pass);
			break;
		}
	}

	/**
	 * Verify the list details page sections hamburger, search text, email
	 * button & overflow button are present in selected list
	 */
	@QAFTestStep(description = "I validate the displayed <List Name> page")
	public void iValidateTheDisplayedListNamePage() {
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		/* Validating List name page */
		androidcommon.getAppHamburger().verifyPresent();
		listDetailspage.getListpageTxtSearch().verifyPresent();
		listDetailspage.getListpageBtnEmail().verifyPresent();
		listDetailspage.getListpageBtnMenuoverflow().verifyPresent();
	}

	/**
	 * Selecting Scan receipt from list details search option Verify scan
	 * receipt page is displayed Handle access camera popup is displayed and
	 * allow
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I see the Scan Receipt page on selecting Scan Receipt option")
	public void iSeeTheScanReceiptPageOnSelectingScanReceiptOption() throws InterruptedException {
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		ScannerTestPage scanTest = new ScannerTestPage();

		listDetailspage.waitForPageToLoad();
		listDetailspage.getListpageLinkScanreciept().click();
		try {
			androidcommon.getScanreceiptBtnEnterreceiptnumber().waitForPresent(7000);
		} catch (Exception e) {
			try {
				if (scanTest.getLblAccesscamerapopuptitle().isPresent()) {
					PerfectoUtils.reportMessage("Allow H-E-B to take pictures and record video?", MessageTypes.Info);
					androidcommon.getAppPopupBtnAllowPermission().verifyPresent();
					androidcommon.getAppPopupBtnAllowPermission().click();
				}
			} catch (Exception f) {
				// ignore
			}
		}
		androidcommon.getScanreceiptBtnEnterreceiptnumber().waitForPresent(5000);
		androidcommon.getScanreceiptBtnEnterreceiptnumber().verifyPresent();
	}

	/**
	 * Click on Search icon and verify search text is displayed
	 */
	@QAFTestStep(description = "I see Search Field is displayed by clicking on Search Icon")
	public void iSeeSearchFieldIsDisplayedByClickingOnSearchIcon() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		/* Click on search icon */
		weeklygrocery.getWgBtnSearch().waitForPresent(5000);
		weeklygrocery.getWgBtnSearch().click();

		/* Verifying Search icon text */
		wgsearchresult.getWgLblSearchsrctext().waitForPresent(3000);
		wgsearchresult.getWgLblSearchsrctext().verifyPresent();
	}

	/**
	 * Verify a selected list checkbox is checked or not
	 */
	@QAFTestStep(description = "I should see the checkmark in the checkbox")
	public void iShouldSeeTheCheckmarkInTheCheckbox() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		List<QAFWebElement> items = weeklygrocery.getWgChkShoppingitemList();

		try {

			String chkSelected = null;

			chkSelected = items.get(items.size() - 1).getAttribute("checked");

			if (chkSelected.equals("true")) {
				PerfectoUtils.reportMessage("The Checkbox is selected", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("The Checkbox is not selected", MessageTypes.Fail);
			}
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("The Checkbox is not selected", MessageTypes.Fail);
		}

		// Check item moved to down
		if (items.size() > 1) {
			double itemPosition = getBundle().getDouble("itemPosition");
			double newPosition;
			int i = 0;

			while ((!items.get(items.size() - 1).isPresent()) && i < 5) {
				PerfectoUtils.verticalswipeSlow(0.8, 0.7);
				i++;
			}

			if (items.get(items.size() - 1).isPresent()) {
				newPosition = items.get(items.size() - 1).getLocation().getY();
				if (newPosition > itemPosition)
					PerfectoUtils.reportMessage("Item is moved to bottom..", MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("Item is not moved to bottom..", MessageTypes.Fail);
			} else
				PerfectoUtils.reportMessage("Unable to find item in list.. please delete some items..");

		} else
			PerfectoUtils.reportMessage("Only one item present cannot validate position..");

	}

	/**
	 * Uncheck a selected list's Checkbox
	 */
	@QAFTestStep(description = "I uncheck the Shopping list Items")
	public void iUncheckTheShoppingListItems() {
		WeeklygroceriesTestPage wGroceries = new WeeklygroceriesTestPage();

		List<QAFWebElement> items = wGroceries.getWgChkShoppingitemList();
		items.get(items.size() - 1).click();
	}

	/**
	 * Verify the Checkbox are not checked by comparing checked off count with
	 * no of items checked
	 */
	@QAFTestStep(description = "I should not see the checkmark in the checkbox")
	public void iShouldNotSeeTheCheckmarkInTheCheckbox() {
		WeeklygroceriesTestPage wGroceries = new WeeklygroceriesTestPage();

		String checkoffcount = null, checkboxoff = null;
		int checkOffCount = 0;
		List<QAFWebElement> items = wGroceries.getWgChkShoppingitemList();
		checkoffcount = wGroceries.getWgTxtCheckoffcount().getText().replace("Checked Off", "").trim();
		checkOffCount = Integer.parseInt(checkoffcount);
		checkboxoff = items.get(items.size() - checkOffCount - 1).getAttribute("checked");

		if (checkboxoff.equalsIgnoreCase("false")) {
			PerfectoUtils.reportMessage("Product has been unchecked as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Product has not been unchecked", MessageTypes.Fail);
		}
	}

	/**
	 * Select a generic product available in list Verify the product is generic
	 * item and Click on the product to navigate to product details page If
	 * products not available in list do the following: Verify search text is
	 * displayed on clicking search icon Enter valid search term
	 * 'products.productname'and search Select first item from search results
	 * and add to list Then click on the added product to navigate to product
	 * details page
	 * 
	 * @param products.productname
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I see the Product details page on selecting product from the list")
	public void iSeeTheProductDetailsPageOnSelectingProductFromTheList() throws InterruptedException {
		ListdetailsTestPage listdetailspage = new ListdetailsTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		AndroidStepDefShoppingList androidStepDefShoppingList = new AndroidStepDefShoppingList();

		boolean genericItem = false;
		String items = null;
		String productName = null;
		items = listdetailspage.getListpageLblShoppingitemcount().getText();

		if (items.contains("Items")) {
			items = items.replace("Items", "").trim();
		} else if (items.contains("Item")) {
			items = items.replace("Item", "").trim();
		}
		int itemcount = Integer.parseInt(items);

		/* Check the count of items listed */
		if (itemcount == 0) {
			listdetailspage.getListpageLblShoppingitemcount()
					.verifyText("0 " + getBundle().getString("ShoplistCountItems"));
		} else {
			/*
			 * If not 0 items, then verify whether they are generic or specific
			 * item
			 */
			listdetailspage.getListpageLblShoppingitemcount()
					.verifyNotText("0 " + getBundle().getString("ShoplistCountItems"));

			/* Click only the specific item */
			for (ShoppinglistResult product : weeklygrocery.getWgListItemlist()) {
				if ((!product.getWgListSelectsspecificitem().isPresent())) {
					PerfectoUtils.reportMessage("Generic Item is found", MessageTypes.Pass);
					product.getWgListItemname().click();
					genericItem = true;
					break;
				}
			}
		}
		if (!genericItem) {
			PerfectoUtils.reportMessage("No Items are available and adding items", MessageTypes.Info);
			iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
			iEnterValidSearchTermAndSelectSearchButtonInWeeklyGroceriesPage(
					getBundle().getString("products.productname"));
			androidStepDefShoppingList.iShouldSeeTheSearchResultsPage();
			iSelectASpecificItem(2);
			productName = listdetailspage.getListpageLblItemname().getText();
			PerfectoUtils.reportMessage("Generic Item is added: " + productName, MessageTypes.Pass);
			listdetailspage.getListpageLblItemname().click();
		}
	}

	/**
	 * Click on the product Qty field in product details page
	 */
	@QAFTestStep(description = "I see the Scroling selector page on selecting Qty field")
	public void iSeeTheScrolingSelectorPageOnSelectingQtyField() {
		PdtdetailspagefromlistTestPage productdetails = new PdtdetailspagefromlistTestPage();

		productdetails.getProductdetailsTxtProductquantity().waitForPresent(20000);
		productdetails.getProductdetailsTxtProductquantity().click();

	}

	/**
	 * Fetch the already displayed product Qty in product details page Update
	 * the new Qty for product Save the changes Verify the new updated Qty is
	 * displayed
	 */
	@QAFTestStep(description = "I see the Qty field updated on selecting quantity and click on Save button")
	public void iSeeTheQtyFieldUpdatedOnSelectingQuantityAndClickOnSaveButton() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		PdtdetailspagefromlistTestPage productdetails = new PdtdetailspagefromlistTestPage();
		try {

			int setQuantity = 0, getQuantity = 0;

			productdetails.waitForPageToLoad();
			String productQuantity = productdetails.getProductdetailsTxtProductquantity().getText();
			setQuantity = Integer.parseInt(productQuantity);
			String strgetQuantity = Integer.toString(setQuantity + 1);
			int setQuantityy = Integer.parseInt(strgetQuantity);
			try {
				productdetails.getProductdetailsTxtProductquantity().clear();
				productdetails.getProductdetailsTxtProductquantity().sendKeys("");
				productdetails.getProductdetailsTxtProductquantity().sendKeys(strgetQuantity);
			} catch (Exception e) {
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", strgetQuantity);
				Object result1 = androidcommon.getTestBase().getDriver().executeScript("mobile:text:select", params1);
			}

			productdetails.getProductdetailsBtnSave().waitForPresent(3000);
			productdetails.getProductdetailsBtnSave().click();
			String changedqty = productdetails.getProductdetailsTxtProductquantity().getText();
			getQuantity = Integer.parseInt(changedqty);

			if (setQuantityy != getQuantity) {
				PerfectoUtils.reportMessage("Quantity field is displayed as selected quantity", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Quantity field is not displayed as selected quantity", MessageTypes.Fail);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/**
	 * Click on the notes section and clear already available notes Enter the
	 * new notes(not null) in the notes section Verify the new notes get
	 * displayed
	 * 
	 * @param WeeklyGroceries.product.Notes
	 */
	@QAFTestStep(description = "I see the entered notes updated in the Notes field on selecting and entering notes")
	public void iSeeTheEnteredNotesUpdatedInTheNotesFieldOnSelectingAndEnteringNotes() {
		PdtdetailspagefromlistTestPage productdetails = new PdtdetailspagefromlistTestPage();

		String notes = getBundle().getString("WeeklyGroceries.product.Notes");
		String getNotes = null;

		if (!notes.equals("")) {
			productdetails.getProductdetailsEdtNotes().click();
			productdetails.getProductdetailsEdtNotes().clear();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(notes);
			PerfectoUtils.getAppiumDriver().hideKeyboard();
			getNotes = productdetails.getProductdetailsEdtNotes().getText();
			PerfectoUtils.reportMessage("The parameter value of notes is " + notes, MessageTypes.Pass);
			if (!getNotes.equals("")) {
				PerfectoUtils.reportMessage("Notes Fields is updated as expected", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Notes Fields is Empty", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("The parameter value of notes is empty", MessageTypes.Fail);
		}
	}

	/**
	 * Click device back button from product details page Verify the non empty
	 * list is displayed on back button, from where we navigated to product
	 * details page
	 */
	@QAFTestStep(description = "I see Weekly Groceries page on clicking device back button")
	public void iSeeWeeklyGroceriesPageOnClickingDeviceBackButton() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();

		String items = null;
		int itemcount = 0;
		PerfectoUtils.androiddeviceback();
		PerfectoUtils.androiddeviceback();
		listdetails.getListpageLblShoppingitemcount().waitForPresent(3000);
		items = listdetails.getListpageLblShoppingitemcount().getText();

		if (items.contains(getBundle().getString("ShoplistCountItems"))) {
			items = items.replace(getBundle().getString("ShoplistCountItems"), "").trim();
		} else if (items.contains(getBundle().getString("ShoplistCountItem"))) {
			items = items.replace(getBundle().getString("ShoplistCountItem"), "").trim();
		}
		itemcount = Integer.parseInt(items);

		if (itemcount >= 0) {
			PerfectoUtils.reportMessage("Weekly Groceries page is displayed successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Weekly Groceries page is not displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Verify the list is empty by comparing list item count with 0 item or 0
	 * items
	 */
	@QAFTestStep(description = "I should see All items are deleted from list")
	public void iShouldSeeAllItemsAreDeletedFromList() {
		ListdetailsTestPage listdetail = new ListdetailsTestPage();
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.waitForPageToLoad();
		if (listdetail.getListpageLblShoppingitemcount().verifyText("0 " + getBundle().getString("ShoplistCountItems"))
				|| listdetail.getListpageLblShoppingitemcount()
						.verifyText("0 " + getBundle().getString("ShoplistCountItem"))) {
			PerfectoUtils.reportMessage("No item is avaible", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Items are still there to delete");
		}
	}

	/**
	 * Click device back button
	 */
	@QAFTestStep(description = "I select device back button")
	public void iSelectDeviceBackButton() {

		PerfectoUtils.androiddeviceback();
	}

	/**
	 * Verify the plus icon to create new list in not available
	 */
	@QAFTestStep(description = "I should not see option to create new list")
	public void iShouldNotSeeOptionToCreateNewList() {
		MylistTestPage mylistpage = new MylistTestPage();

		/* Validating plus icon image is not displayed */
		if (!mylistpage.getMyListsImgPlus().isPresent()) {
			PerfectoUtils.reportMessage("Plus icon to create list is not displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Plus icon to create list is displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Verify chosen product 'ChoosenProduct' available in run time in available
	 * in the list Compares each item name in list with chosen item and return
	 * the result
	 * 
	 * @param ChoosenProduct
	 * @throws Exception
	 */
	@QAFTestStep(description = "I should see the added item in the list")
	public void iShouldSeeTheSelectedItemInTheSelectedListPage() throws Exception {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		/* Validate if selected item is listed in selected list detail page */
		boolean isPdtDisplayed = false;
		String choosenPdt = getBundle().getString("ChoosenProduct");
		String productName = "";
		int noOfSwipes = 0;

		/* Iteration to compare the selected pdt in the list details page */
		try {
			do {
				for (ShoppinglistResult product : weeklygrocery.getWgListItemlist()) {
					productName = product.getWgListItemname().getText();
					if (productName.contains("&quot;")) {
						productName = productName.replaceAll("&quot;", "\"");
					}
					if ((choosenPdt.contains(productName))) {
						isPdtDisplayed = true;
						break;
					}
				}

				if (!isPdtDisplayed) {
					PerfectoUtils.verticalswipe(80, 75, 2);
				}
				noOfSwipes++;
			} while (noOfSwipes < 10 && !isPdtDisplayed);

		} catch (Exception e) {
			/* Deleting All the items in the list, if found exception */
			AndroidStepDefWeeklyAds.iDeleteAllItemsFromTheAddedList();
		}

		if (isPdtDisplayed) {
			PerfectoUtils.reportMessage("Added item: " + productName + " present in the list details page",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Added item: " + productName + " is not present in the list details page",
					MessageTypes.Fail);
		}

	}

	/**
	 * Verify list page fields like hamburger, overflow icon, Page title as hot
	 * user And check list names are not empty
	 */
	@QAFTestStep(description = "I validate the page properties as a hot user")
	public void iValidateThePagePropertiesofHotUser() {
		MylistTestPage mylistpage = new MylistTestPage();
		AndroidcommonTestPage androidCommon = new AndroidcommonTestPage();

		String strListName = null;
		androidCommon.getAppHamburger().verifyPresent();
		mylistpage.getMylistsIconOverflow().verifyPresent();
		mylistpage.getMyListLblPagetitle().verifyPresent();

		for (QAFWebElement result1 : mylistpage.getMyListLblLstNameHotUserItems()) {
			/* Validating the list name is not empty */
			strListName = result1.getText();
			if (!strListName.isEmpty()) {
				PerfectoUtils.reportMessage("List: " + strListName + " is displayed", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("List not displayed", MessageTypes.Fail);
			}
		}
	}

	/**
	 * Verify list page fields like hamburger, overflow icon, Page title,
	 * Register button, login button as cold user And check Weekly grocery list
	 * is available
	 */
	@QAFTestStep(description = "I validate the page properties as a cold user")
	public void iValidateThePagePropertiesAsColdUser() {
		MylistTestPage myList = new MylistTestPage();
		AndroidcommonTestPage androidCommon = new AndroidcommonTestPage();

		try {
			if (androidCommon.getAppHamburger().verifyPresent() && myList.getMyListLblPagetitle().verifyPresent()
					&& myList.getMyListsBtnRegister().verifyPresent() && myList.getMylistsBtnLogin().verifyPresent()
					&& myList.getMylistsIconOverflow().verifyPresent()
					&& myList.getMylistsLblWeeklygroceries().verifyPresent()) {
				PerfectoUtils.reportMessage("Page validation successful.", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Page validation not successful.", MessageTypes.Fail);
			}
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Page validation not successful.", MessageTypes.Fail);
		}
	}

	/**
	 * Perform Delete all item action in list Verify cancel & ok button in
	 * delete confirmation popup Click ok button
	 */
	@QAFTestStep(description = "I select Delete All Items option")
	public void iSelectDeleteAllItemsOption() {
		ListdetailsTestPage listdetail = new ListdetailsTestPage();
		EmailcontentTestPage emailcontent = new EmailcontentTestPage();

		/* Validating DeleteAllItem and clicking */
		if (listdetail.getListpageLinkDeleteallitem().isPresent()) {
			listdetail.getListpageLinkDeleteallitem().click();
			PerfectoUtils.reportMessage("Item deleted successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Delete all item is not available", MessageTypes.Fail);
		}
		if (listdetail.getListpageLinkDeleteallitem().isPresent()) {
			PerfectoUtils.reportMessage("Delete all icon is present", MessageTypes.Pass);
		} else {
			listdetail.getListpageLinkDeleteallitem().click();
			PerfectoUtils.reportMessage("item deleted", MessageTypes.Fail);
		}

		/* Verifying Cancel and pop-up title */
		listdetail.getListpageBtnCancel().verifyPresent();
		listdetail.getListpageLblDeleteallitemoverlay().verifyPresent();

		/* Verifying ok button */
		if (emailcontent.getBtnOk().isPresent()) {
			emailcontent.getBtnOk().click();
			PerfectoUtils.reportMessage("Button ok is present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Button ok is not present", MessageTypes.Fail);
		}
	}

	/**
	 * Click on a generic item name available in the list If items not available
	 * in list, add item to list and click on the added item
	 */
	@QAFTestStep(description = "I see the Product details page on selecting specific product from the list")
	public void iSeeTheProductDetailsPageOnSelectingSpecificProductFromTheList() {
		ListdetailsTestPage listdetailspage = new ListdetailsTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		boolean specificItem = false;
		String items = null, getproductName = null, productNamefromlist = null;
		items = listdetailspage.getListpageLblShoppingitemcount().getText();

		/* Check the count of items listed */
		if (items.equalsIgnoreCase(getBundle().getString("ShoplistCountItems"))) {
			listdetailspage.getListpageLblShoppingitemcount().verifyText(getBundle().getString("ShoplistCountItems"));
		} else {
			/*
			 * If not 0 items, then verify whether they are generic or specific
			 * item
			 */
			listdetailspage.getListpageLblShoppingitemcount()
					.verifyNotText(getBundle().getString("ShoplistCountItems"));

			/* Click only the specific item */
			for (ShoppinglistResult product : weeklygrocery.getWgListItemlist()) {
				if (!(product.getWgListSelectsspecificitem().isPresent())) {
					if (!product.getWgLblExpirydate().isPresent()) {
						product.getWgListItemname().click();
						PerfectoUtils.reportMessage("Specific Item is found", MessageTypes.Pass);
						specificItem = true;
						break;
					}
				}
			}
		}
		/* If items are not found, then search and add specific item */
		if (!specificItem) {

			/* Click search icon */
			weeklygrocery.getWgBtnSearch().click();

			/* Enter product name in search field */
			getproductName = getBundle().getString("products.productname");
			getBundle().setProperty("productName", getproductName);
			AndroidStepDef.enterValueIntoTheTextboxandClick(wgsearchresult, wgsearchresult.getWgLblSearchsrctext(),
					getproductName);

			/* Click on second search item */
			if ((wgsearchresult.getWgListSearchlist().size()) > 2) {
				getBundle().setProperty("ChoosenProduct", wgsearchresult.getWgListSearchlist().get(1).getText());
				wgsearchresult.getWgListSearchlist().get(1).click();

				/* Select a specific product from list details page */
				for (ShoppinglistResult product : weeklygrocery.getWgListItemlist()) {
					productNamefromlist = product.getWgListItemname().getText();
					if ((getBundle().getString("ChoosenProduct").toLowerCase())
							.contains(productNamefromlist.toLowerCase().trim())) {
						product.getWgListItemname().click();
						break;
					}
				}
			} else if ((wgsearchresult.getWgListSearchlist().size()) < 2) {
				PerfectoUtils.reportMessage("No Result/Search product is displaying only Generic Items",
						MessageTypes.Fail);
			}
		}
	}

	/**
	 * Verify more details section in product details On clicking more details,
	 * verify PDP page is displayed
	 */
	@QAFTestStep(description = "I see product item details page by clicking on see more details link")
	public void iSeeProductItemDetailsPageByClickingOnSeeMoreDetailsLink() {
		PdtdetailspagefromlistTestPage pdtdetails = new PdtdetailspagefromlistTestPage();

		/* Verify see more details link and click on it */
		pdtdetails.getProductdetailsLblMoredetails().verifyPresent();
		pdtdetails.getProductdetailsLblMoredetails().click();

		/* Validate if PDP page is opened */
		ProductdetailTestPage PDPPage = new ProductdetailTestPage();
		PDPPage.getLblProductDescription().verifyText("Item Details");
	}

	/**
	 * Verify the Collapse button in search page
	 */
	@QAFTestStep(description = "I validate search products page")
	public void iValidateSearchProductsPage() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		androidcommon.getAppBtnCollapse().verifyPresent();
	}

	/**
	 * Verify popup to enter the list name is displayed
	 */
	@QAFTestStep(description = "I should see the popup to enter list name")
	public void iShouldSeeThePopupToEnterListName() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.getMyListsPopUpTitle().verifyPresent();
	}

	/**
	 * Select the first entry(product link) from search results
	 * 
	 * @return ChoosenProduct
	 */
	@QAFTestStep(description = "I select the Item first entry")
	public void iSelectTheItemFirstEntry() {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		/* Click on first search item */
		wgsearchresult.getWgLblSearchresultItemname().waitForPresent(2000);
		String itemName = wgsearchresult.getWgLblSearchresultItemname().getText();
		getBundle().setProperty("ChoosenProduct", itemName);
		wgsearchresult.getWgLblSearchresultItemname().click();

	}

	/**
	 * Search for already added product and click on it
	 * 
	 * @param ChoosenProduct
	 */
	@QAFTestStep(description = "I click on Select Specific Product link")
	public void iClickOnSelectSpecificProductLink() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String productName = null;

		/* Click on Specific Product link */
		for (ShoppinglistResult product : weeklygrocery.getWgListItemlist()) {
			productName = product.getWgListItemname().getText();
			if (productName.equalsIgnoreCase(getBundle().getString("ChoosenProduct"))) {
				product.getWgListSelectsspecificitem().click();
				break;
			}
		}
	}

	/**
	 * Select device back button
	 */
	@QAFTestStep(description = "I navigate back to selected list page")
	public void iNavigateBackToSelectedListPage() {
		PerfectoUtils.androiddeviceback();
	}

	/**
	 * Enter user email id in recipient email address field and Click in Send
	 * email button Verify Send email button is not present after clicking
	 * 
	 * @param default.user.email
	 */
	@QAFTestStep(description = "I enter valid email address and click on Send or submit button")
	public void iEnterValidEmailAddressAndClickOnSendSubmitButton() {
		SendemailTestPage sendemail = new SendemailTestPage();

		String recipientEmail = null;
		int i = 0;
		sendemail.waitForPageToLoad();
		recipientEmail = getBundle().getString("default.user.email");
		sendemail.getSendemailTxtRecipientemail().sendKeys(recipientEmail);

		PerfectoUtils.reportMessage("Entered Email: " + recipientEmail + " ");
		sendemail.getSendemailBtnSend().waitForPresent();
		sendemail.getSendemailBtnSend().verifyPresent();
		sendemail.getSendemailBtnSend().click();

		PerfectoUtils.reportMessage("Clicked Send");
		sendemail.waitForPageToLoad();
		do {
			try {
				sendemail.getSendemailBtnSend().waitForNotPresent(3000);
			} catch (Exception e) {
				i++;
			}
		} while (sendemail.getSendemailBtnSend().isPresent() && i < 20);
	}

	/**
	 * Verify checkboxes are all unchecked and return the status
	 */
	@QAFTestStep(description = "I should see the checkboxes of all items Unchecked")
	public void iShouldSeeTheCheckboxesOfAllItemsUnchecked() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();

		String strCheckoffCount = null;
		int checkoffCount = 0;
		strCheckoffCount = listdetails.getListpageLblShoppingitemcheckoffcount().getText().replaceAll("Checked Off", "")
				.trim();
		checkoffCount = Integer.parseInt(strCheckoffCount);

		if (checkoffCount == 0) {
			PerfectoUtils.reportMessage("Checkboxes of all items has been Unchecked", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Checkboxes of all items has not been Unchecked", MessageTypes.Fail);
		}
	}

	/**
	 * Verify search box is available in list and click on it
	 */
	@QAFTestStep(description = "I select the Search box from list detail page")
	public void iSelectTheSearchBoxFromListDetailPage() {
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();

		/* Clicking on search */
		listDetailspage.getListpageTxtSearch().verifyPresent();
		listDetailspage.getListpageTxtSearch().click();
	}

	/**
	 * Verify different sections such as collapse btn, Search text, Scan menu in
	 * search products page Click on scan menu and verify scan product and scan
	 * receipt options are present
	 */
	@QAFTestStep(description = "I validate the Search Products page")
	public void iValidateTheSearchProductsPage() {
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		/* Validating search product page */
		// listDetailspage.getListpageBtnCollapse().verifyPresent();
		listDetailspage.getListpageTxtSearch().verifyPresent();
		listDetailspage.getListpageBtnScanmenu().verifyPresent();
		listDetailspage.getListpageBtnScanmenu().click();
		androidcommon.getScanTxtScanreceipt().verifyPresent();
		androidcommon.getScanTxtScanproduct().verifyPresent();
	}

	/**
	 * Verify device navigated back to selected list page by verifying list item
	 * count is not null
	 */
	@QAFTestStep(description = "I see the <List name> page on selecting device back button")
	public void iSeeTheListNamePageOnSelectingDeviceBackButton() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();

		String items = null;
		int itemcount = 0;

		PerfectoUtils.androiddeviceback();
		PerfectoUtils.androiddeviceback();
		listdetails.getListpageLblShoppingitemcount().waitForPresent(5000);
		listdetails.getListpageLblShoppingitemcount().verifyPresent();
		items = listdetails.getListpageLblShoppingitemcount().getText();

		if (items.contains(getBundle().getString("ShoplistCountItems"))) {
			items = items.replace(getBundle().getString("ShoplistCountItems"), "").trim();
		} else if (items.contains(getBundle().getString("ShoplistCountItem"))) {
			items = items.replace(getBundle().getString("ShoplistCountItem"), "").trim();
		}
		itemcount = Integer.parseInt(items);

		if (itemcount >= 0) {
			PerfectoUtils.reportMessage("The page is navigated to List detail page as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("The page is not navigated to List detail page as expected", MessageTypes.Fail);
		}
	}

	/**
	 * Select on first available list Return if the list is empty
	 */
	@QAFTestStep(description = "I select and navigate to first list")
	public void iSelectAndNavigateToFirstList() {
		MylistTestPage mylistpage = new MylistTestPage();

		/* Click on first shopping list */
		mylistpage.getMyListLblLstNameHotUserItems().get(0).waitForPresent(5000);
		List<QAFWebElement> items = mylistpage.getMyListLblLstNameHotUserItems();

		if (items.size() > 0) {
			PerfectoUtils.reportMessage(items.size() + "lists", MessageTypes.Info);
			String listName = items.get(1).getText();
			getBundle().setProperty("selectedList", listName);
			items.get(1).click();
		} else {
			PerfectoUtils.reportMessage("List is Empty for Hot user", MessageTypes.Fail);
		}
	}

	/**
	 * Check off an item in list if it is non empty Verify list is not empty, if
	 * empty search for products Verify search results page and select UPC item
	 * from list Add to list and do the check off
	 * 
	 * @param products.productname
	 * @throws Exception
	 */
	@QAFTestStep(description = "I check off shopping list items")
	public void iCheckOffShoppingListItems() throws Exception {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		AndroidStepDefShoppingList androidStepDefShoppingList = new AndroidStepDefShoppingList();
		WeeklygroceriesTestPage wGroceries = new WeeklygroceriesTestPage();
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();

		int itemCount = 0;
		String strItemCount = listdetails.getListpageLblShoppingitemcount().getText().replace("Items", "")
				.replace("Item", "").trim();
		itemCount = Integer.parseInt(strItemCount);

		/* Adding product to list if item in not available */
		if (itemCount == 0) {
			String strPdtName = getBundle().getString("products.productname");
			androidStepDefShoppingList.iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
			androidStepDefShoppingList.iSearchForProductFromListDetailsPage(strPdtName);
			androidStepDefShoppingList.iShouldSeeTheSearchResultsPage();
			androidStepDefShoppingList.iSelectAUPCSpecificItem();
			androidStepDefShoppingList.iShouldSeeTheSelectedItemInTheSelectedListPage();
			androidcommonpage.getAppHamburger().waitForPresent(3000);
		}
		String strItemCount2 = listdetails.getListpageLblShoppingitemcount().getText().replace("Items", "")
				.replace("Item", "").trim();
		itemCount = Integer.parseInt(strItemCount2);
		if (itemCount == 1) {
			String strPdtName = getBundle().getString("products.productname");
			androidStepDefShoppingList.iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
			androidStepDefShoppingList.iSearchForProductFromListDetailsPage(strPdtName);
			androidStepDefShoppingList.iShouldSeeTheSearchResultsPage();
			androidStepDefShoppingList.iSelectASpecificItem(2);
			androidStepDefShoppingList.iShouldSeeTheSelectedItemInTheSelectedListPage();
			androidcommonpage.getAppHamburger().waitForPresent(3000);
		}

		List<QAFWebElement> items = wGroceries.getWgChkShoppingitemList();
		double itemPosition = items.get(0).getLocation().getY();
		getBundle().setProperty("itemPosition", itemPosition);
		items.get(0).click();
	}

	/**
	 * Select an UPC specific item from search list which is displayed as second
	 * item If the search result count is less than two, not selecting any item
	 * 
	 * @return ChoosenProduct
	 */
	@QAFTestStep(description = "I select a UPC specific item")
	public void iSelectAUPCSpecificItem() {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		int getcnt = wgsearchresult.getWgListSearchlist().size();

		if (getcnt > 2) {
			/*
			 * Click on specific item (2nd item) displays in search result page
			 */
			getBundle().setProperty("ChoosenProduct", wgsearchresult.getWgListSearchlist().get(1).getText());
			wgsearchresult.getWgListSearchlist().get(1).click();
		} else if (getcnt < 2) {
			PerfectoUtils.reportMessage("No Results/Search product is displaying only Generic Items",
					MessageTypes.Fail);
		}
	}

	/**
	 * Enter search term productName in search field and click search icon in
	 * weekly grocery list
	 * 
	 * @param productName
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I enter valid search term {0}and select Search button in weekly groceries page")
	public void iEnterValidSearchTermAndSelectSearchButtonInWeeklyGroceriesPage(String productName)
			throws InterruptedException {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		/* Enter product name in search field */
		getBundle().setProperty("productName", productName);

		/* Click search button on keyboard */
		AndroidStepDef.enterValueIntoTheTextboxandClick(wgsearchresult, wgsearchresult.getWgLblSearchsrctext(),
				productName);
	}

	/**
	 * Verify the select item 'ChoosenProduct' in available items in weekly
	 * grocery page
	 * 
	 * @param ChoosenProduct
	 */
	@QAFTestStep(description = "I should see the selected Item in the Weekly Groceries page")
	public void iShouldSeeTheSelectedItemInTheWeeklyGroceriesPage() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		boolean found = false;
		String choosenProduct = getBundle().getString("ChoosenProduct");
		String productName;

		/* Validate if selected item is listed in Weekly Groceries page */
		for (ShoppinglistResult product : weeklygrocery.getWgListItemlist()) {

			product.getWgListItemname().waitForPresent(2000);
			productName = product.getWgListItemname().getText();
			if (choosenProduct.length() >= productName.length()) {
				if (productName.equalsIgnoreCase(choosenProduct.substring(0, productName.length()))) {
					product.getWgListItemname().verifyPresent();
					PerfectoUtils.reportMessage("Selected item available in the weekly grocery page..",
							MessageTypes.Pass);
					found = true;
					break;
				}
			}
		}
		if (!found)
			PerfectoUtils.reportMessage("Selected item is not available in the weekly grocery page..",
					MessageTypes.Fail);
	}

	/**
	 * Verify different sections Hamburger, Scan option, search result count in
	 * search result page
	 */
	@QAFTestStep(description = "I validate the search results page")
	public void iValidateTheSearchResultsPage() {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		androidfun.getAppHamburger().verifyPresent();
		if (wgsearchresult.getWgBtnSearchresultScan().isPresent()) {
			wgsearchresult.getWgBtnSearchresultScan().verifyPresent();
		} else if (wgsearchresult.getWgBtnSearchresultScanhotuser().isPresent()) {
			wgsearchresult.getWgBtnSearchresultScanhotuser().verifyPresent();
		}
		wgsearchresult.getWgLblSearchresultItemcount().verifyPresent();
		wgsearchresult.getWgLblSearchresultCheckofcount().verifyPresent();
		String ItemsCount = wgsearchresult.getWgLblSearchresultItemcount().getText();
		PerfectoUtils.reportMessage("Items Count:" + ItemsCount);
		String CheckOfCount = wgsearchresult.getWgLblSearchresultCheckofcount().getText();
		PerfectoUtils.reportMessage("Items Count:" + CheckOfCount);
	}

	/**
	 * Compares the new list name 'NewListName' with all the available list name
	 * in list name picker by clicking on the next When matches, stop the
	 * comparison And click the Add to list button
	 * 
	 * @param NewListName
	 */
	@QAFTestStep(description = "I see toaster message on selecting Add button in Add To List popup")
	public void iSeeToasterMessageOnSelectingAddButtonInAddToListPopup() {
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();

		String pickerName = androidcommonpage.getAddtolistTxtNumberpicker().getText().replace(". Double tap to edit.",
				"");
		String newListNameValue = getBundle().getString("NewListName");
		int getSize = 0, actualSize = 0, i = 0;

		getSize = androidcommonpage.getAddtolistTxtNextpicker().size();

		while ((!pickerName.equals(newListNameValue) && i < 10)) {
			actualSize = getSize - 1;
			String nextPicker = androidcommonpage.getAddtolistTxtNextpicker().get(actualSize).getText();
			try {
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", nextPicker);
				Object result1 = androidcommonpage.getTestBase().getDriver().executeScript("mobile:text:select",
						params1);
			} catch (Exception e) {
				androidcommonpage.getAddtolistTxtNextpicker().get(actualSize).click();
			}
			pickerName = androidcommonpage.getAddtolistTxtNumberpicker().getText().replace(". Double tap to edit.", "");
			getSize = androidcommonpage.getAddtolistTxtNextpicker().size();
			i++;
		}
		PerfectoUtils.reportMessage("Selected List Name: " + pickerName + " from picker");
		androidcommonpage.getAddtolistBtnAdd().click();
		PerfectoUtils.reportMessage("Clicked 'Add' button", MessageTypes.Pass);
	}

	/**
	 * Click on Done\Add button in the add to list popup
	 */
	@QAFTestStep(description = "I click on Add/Done button")
	public void iClickOnAddDoneButton() {
		MylistTestPage mylistpage = new MylistTestPage();

		/* Clicking on Add button */
		mylistpage.getMylistsBtnadd().waitForPresent(5000);
		mylistpage.getMylistsBtnadd().click();
		mylistpage.getMylistsBtnadd().waitForNotPresent(5000);
	}

	/**
	 * Wait for presence & Click on Save\Add button
	 */
	@QAFTestStep(description = "I click the save/add button")
	public void iClickTheSaveButton() {
		MylistTestPage mylistpage = new MylistTestPage();

		/* Clicking on save button */
		mylistpage.getMylistsbtnSave().waitForPresent(3000);
		mylistpage.getMylistsbtnSave().click();
		PerfectoUtils.reportMessage("Clicked Save button.", MessageTypes.Pass);
	}

	/**
	 * Verify user not able to delete weekly groceries list by detecting its
	 * presence
	 */
	@QAFTestStep(description = "I Verify cold user is not able to delete the Weekly Grocery List")
	public void iVerifyColdUserIsNotAbleToDeleteTheWeeklyGroceryList() {
		ListdetailsTestPage listdetailspage = new ListdetailsTestPage();

		String strPageTitle = null;
		listdetailspage.waitForPageToLoad();
		listdetailspage.getListpageLblPagetitle().waitForPresent(50000);
		strPageTitle = listdetailspage.getListpageLblPagetitle().getText();

		if (strPageTitle.equalsIgnoreCase("Weekly Groceries")) {
			PerfectoUtils.reportMessage("User is not able to delete the Weekly Grocery List", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not able to navigate to Weekly Grocery List", MessageTypes.Fail);
		}
	}

	/**
	 * Check off the first item in list if the items are available If list is
	 * empty add item to list by searching 'products.productname' and then check
	 * off the first item
	 * 
	 * @param products.productname
	 */
	@QAFTestStep(description = "I navigate to Uncheck All Items")
	public void iNavigateToUncheckAllItems() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		ProductlandingTestPage productlanding = new ProductlandingTestPage();
		ProductsresultlistTestPage itemresult = new ProductsresultlistTestPage();
		WeeklygroceriesTestPage wGroceries = new WeeklygroceriesTestPage();

		String strItemCount = null, strItemCheckoffCount = null;
		int itemCount = 0, itemCheckoffCount = 0;
		String searchproduct = getBundle().getString("products.productname");
		strItemCount = listdetails.getListpageLblShoppingitemcount().getText()
				.replaceAll((getBundle().getString("ShoplistCountItems")), "")
				.replaceAll((getBundle().getString("ShoplistCountItem")), "").trim();
		itemCount = Integer.parseInt(strItemCount);

		/* Adding products to shopping list, if the list is empty. */
		if (itemCount == 0) {
			androidcommon.getAppIconSearchproducts().click();
			AndroidStepDef.enterValueIntoTheTextboxandClick(productlanding, wGroceries.getWgTxtSearchproducts(),
					searchproduct);

			String prdName = itemresult.getLblChildproductnamelist().get(1).getText().toString();
			PerfectoUtils.reportMessage("Product Name:" + prdName);
			getBundle().setProperty("ChoosenProduct", prdName);
			itemresult.getLblChildproductnamelist().get(1).click();
			PerfectoUtils.reportMessage("Selected Product: " + prdName);
		}
		strItemCount = listdetails.getListpageLblShoppingitemcount().getText()
				.replaceAll(getBundle().getString("ShoplistCountItems"), "")
				.replaceAll((getBundle().getString("ShoplistCountItem")), "").trim();
		strItemCheckoffCount = listdetails.getListpageLblShoppingitemcheckoffcount().getText()
				.replaceAll("Checked Off", "").trim();
		itemCount = Integer.parseInt(strItemCount);
		itemCheckoffCount = Integer.parseInt(strItemCheckoffCount);

		/*
		 * Checking the check box of first product, if no products are checked
		 * off
		 */
		if (itemCheckoffCount == 0) {
			List<QAFWebElement> items = wGroceries.getWgChkShoppingitemList();
			items.get(0).click();
			wGroceries.getWgChkShoppingitemList().get(0).verifyEnabled();
		}

		strItemCheckoffCount = listdetails.getListpageLblShoppingitemcheckoffcount().getText()
				.replaceAll("Checked Off", "").trim();
		itemCheckoffCount = Integer.parseInt(strItemCheckoffCount);

		/*
		 * Clicks on overflow icon from action bar to select the Uncheck all
		 * Items.
		 */

		if ((itemCount != 0) && (itemCheckoffCount != 0)) {
			PerfectoUtils.reportMessage("Item is checked successfully!", MessageTypes.Pass);
			listdetails.getListpageBtnMenuoverflow().click();
		} else {
			PerfectoUtils.reportMessage("Item is not checked! / Item is not available!", MessageTypes.Fail);
		}
	}

	/**
	 * Click in email option from list page when list is not empty If list is
	 * empty, search for a keyword, select UPC specific item, add to list and
	 * then click send email option
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I navigate to Send Email page")
	public void iNavigateToSendEmailPage() throws Exception {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		AndroidStepDefShoppingList androidStepDefShoppingList = new AndroidStepDefShoppingList();
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();

		/* Clicking on Overflow menu and email icon */
		String strItemCount = listdetails.getListpageLblShoppingitemcount().getText()
				.replaceAll((getBundle().getString("ShoplistCountItems")), "")
				.replaceAll((getBundle().getString("ShoplistCountItem")), "").trim();
		int itemCount = Integer.parseInt(strItemCount);

		if (itemCount == 0) {
			androidStepDefShoppingList.iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
			androidStepDefShoppingList.iSearchForProductFromListDetailsPage("milk");
			androidStepDefShoppingList.iShouldSeeTheSearchResultsPage();
			androidStepDefShoppingList.iSelectAUPCSpecificItem();
			androidStepDefShoppingList.iShouldSeeTheSelectedItemInTheSelectedListPage();
			androidcommonpage.getAppHamburger().waitForPresent(3000);
		}

		/* Clicking on email button */
		listdetails.getListpageBtnEmail().waitForPresent(4000);
		listdetails.getListpageBtnEmail().click();
		PerfectoUtils.reportMessage("Clicked Email");
	}

	/**
	 * Wait for and Click on Login\Submit button
	 */
	@QAFTestStep(description = "I click on Login/Submit button")
	public void iClickOnLoginSubmitButton() {
		LoginpopupTestPage loginpopup = new LoginpopupTestPage();
		LoginsplashTestPage loginsplashpage = new LoginsplashTestPage();

		/* Clicking on Login button */
		try {
			loginpopup.getLoginpopupBtnOverlaylogin().waitForPresent(3000);
			loginpopup.getLoginpopupBtnOverlaylogin().click();
			PerfectoUtils.reportMessage("Clicked on Login button.", MessageTypes.Pass);
		} catch (Exception e) {
			loginsplashpage.getLoginBtnLogin().waitForPresent(3000);
			PerfectoUtils.reportMessage("Clicking Login button from login splash page..", MessageTypes.Pass);
			loginsplashpage.getLoginBtnLogin().click();
			PerfectoUtils.reportMessage("Clicked on Login button.", MessageTypes.Pass);
		}
	}

	/**
	 * Enter a dynamic list name created using date class and concatenating with
	 * prefix in the create list popup
	 * 
	 * @return List name 'NewListName'
	 */
	@QAFTestStep(description = "I enter the Shopping list name")
	public void iEnterTheShoppingListName() {
		MylistTestPage mylistpage = new MylistTestPage();

		/* Getting the current time to form the unique list name */
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();
		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		String strListName = "List_" + strTimeStmp;
		getBundle().setProperty("NewListName", strListName);
		mylistpage.getMyListTxtEnterNewList().sendKeys(strListName);
		PerfectoUtils.reportMessage("Entered Shopping list name.", MessageTypes.Pass);
	}

	/**
	 * Search for the product using keyword "productName" by entering into
	 * search field and clicking search icon
	 * 
	 * @param productName
	 */
	@QAFTestStep(description = "I search for product {0} from list details page")
	public void iSearchForProductFromListDetailsPage(String productName) {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		/* Enter product name in search field */
		getBundle().setProperty("productName", productName);
		AndroidStepDef.enterValueIntoTheTextboxandClick(wgsearchresult, wgsearchresult.getWgLblSearchsrctext(),
				productName);
		PerfectoUtils.reportMessage("Searching products for " + productName, MessageTypes.Pass);
	}

	/**
	 * Check for a selected list name 'NewListName' from the available list name
	 * When matching list is found, respective list is selected When matching
	 * list is not found, return the message
	 * 
	 * @param NewListName
	 */
	@QAFTestStep(description = "I select newly added list name")
	public void iSelectNewlyAddedListName() {
		MylistTestPage mylist = new MylistTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		mylist.waitForPageToLoad();
		String strLstName = getBundle().getPropertyValue("NewListName");
		try {
			weeklygrocery.getShopingListEntryByLable(strLstName).click();
			PerfectoUtils.reportMessage("Clicked: " + strLstName + " ");
		} catch (Exception e) {
			try {
				AndroidStepDef.scrollToListNameInMyList(strLstName, 90, 70, 2);
				weeklygrocery.getShopingListEntryByLable(strLstName).click();
				PerfectoUtils.reportMessage("Clicked: " + strLstName + " ");
			} catch (Exception f) {
				PerfectoUtils.reportMessage("New list name is not available", MessageTypes.Fail);
			}
		}
	}

	/**
	 * Check the selected product 'ChoosenProduct' is available in list and
	 * return the status If available, swipe across the item name in the list
	 * 
	 * @return Swiped product 'DeletedProduct'
	 */
	@QAFTestStep(description = "I swipe across the name of the product")
	public void iSwipeAcrossTheNameOfTheProduct() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		weeklygrocery.waitForPageToLoad();
		String strPdtName = getBundle().getString("ChoosenProduct");
		getBundle().setProperty("DeletedProduct", strPdtName);

		/* Getting the object name with dynamic value */
		if (weeklygrocery.getShopingListEntryByLable(strPdtName).isDisplayed()) {
			PerfectoUtils.reportMessage("Selected product: " + strPdtName + " is displayed in list details page",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected product: " + strPdtName + " is not displayed in list details page",
					MessageTypes.Fail);
		}

		/* Getting dimensions to swipe */
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartX = Integer.parseInt(weeklygrocery.getShopingListEntryByLable(strPdtName).getAttribute("X"));
		int intEndX = (int) (size.width * 0.90);
		int intStartY = Integer.parseInt(weeklygrocery.getShopingListEntryByLable(strPdtName).getAttribute("Y"));
		getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);
		PerfectoUtils.reportMessage("Swiping across the product name: " + strPdtName + " to delete");
	}

	/**
	 * Check for a selected product 'DeletedProduct' not present in the list and
	 * return the status
	 * 
	 * @param Product
	 *            'DeletedProduct'
	 */
	@QAFTestStep(description = "I should not see the product")
	public void iShouldNotSeeTheProduct() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String strDeletedPdtName = null;
		weeklygrocery.waitForPageToLoad();
		strDeletedPdtName = getBundle().getPropertyValue("DeletedProduct");
		try {
			weeklygrocery.getShopingListEntryByLable(strDeletedPdtName).waitForNotPresent(10000);
			PerfectoUtils.reportMessage("Deleted product: " + strDeletedPdtName + " is not displayed",
					MessageTypes.Pass);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Deleted product: " + strDeletedPdtName + " is displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Wait for and click on the Enter receipt number button Verify the fields
	 * enter receipt overlay, image, message & receipt number textbox in the
	 * enter receipt number popup
	 */
	@QAFTestStep(description = "I see Enter Reciept No Pop-up")
	public void iSeeEnterRecieptNoPopUp() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		/* Click on Receipt number */
		androidcommon.getScanreceiptBtnEnterreceiptnumber().waitForPresent(3000);
		androidcommon.getScanreceiptBtnEnterreceiptnumber().click();

		/* Verification of pop-up */
		listdetails.getListpageLblEnterreceiptoverlay().waitForPresent(2000);
		listdetails.getListpageLblEnterreceiptoverlay().verifyPresent();
		listdetails.getListpageImgEnterreciept().verifyPresent();
		listdetails.getListpageLblRecieptmessage().verifyPresent();
		listdetails.getListpageTxtEnterrecieptnumber().verifyPresent();
	}

	/**
	 * Check the list is not empty, if not empty return the Actual item names
	 * 'arrActualItemname and the generic item names 'arrGenericItemname' in a
	 * List if the list is empty, search for products in list, add UPC specific
	 * item to list and do above step
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I verify available products in List Details page")
	public void iVerifyAvailableProductsInListDetailsPage() throws Exception {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		AndroidStepDefShoppingList androidStepDefShoppingList = new AndroidStepDefShoppingList();
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		listdetails.getListpageLblShoppingitemcount().waitForPresent(7000);
		String strItemCount = listdetails.getListpageLblShoppingitemcount().getText().split(" ")[0];
		int itemCount = Integer.parseInt(strItemCount);

		if (itemCount == 0) {
			androidStepDefShoppingList.iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
			androidStepDefShoppingList.iSearchForProductFromListDetailsPage("milk");
			androidStepDefShoppingList.iShouldSeeTheSearchResultsPage();
			androidStepDefShoppingList.iSelectAUPCSpecificItem();
			androidStepDefShoppingList.iShouldSeeTheSelectedItemInTheSelectedListPage();
			androidcommonpage.getAppHamburger().waitForPresent(3000);
		}
		/* Verifying the item count again */
		strItemCount = listdetails.getListpageLblShoppingitemcount().getText().split(" ")[0];
		itemCount = Integer.parseInt(strItemCount);
		if (itemCount != 0) {
			PerfectoUtils.reportMessage("List Details page displayed with item count: " + itemCount + "",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("List Details page displayed with item count: 0", MessageTypes.Fail);
		}

		/* Getting the available products in the list to compare */
		List<String> arrActualItemname = new ArrayList<String>();
		for (QAFWebElement temp : listdetails.getListpageLblItemNameListobj()) {
			arrActualItemname.add(temp.getText());
		}
		getBundle().setProperty("arrActualItemname", arrActualItemname);

		List<String> arrGenericItemname = new ArrayList<String>();
		for (ShoppinglistResult product : weeklygrocery.getWgListItemlist()) {
			if ((product.getWgListSelectsspecificitem().isPresent())) {
				arrGenericItemname.add(product.getWgListItemname().getText());
			}
		}
		getBundle().setProperty("arrGenericItemname", arrGenericItemname);
	}

	/**
	 * Check for a selected list name in available list name and click on the
	 * selected list if found
	 */
	@QAFTestStep(description = "I select the list which haivng item copied")
	public void iSelectTheListWhichHaivngItemCopied() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String newListNameValue = ConfigurationManager.getBundle().getString("SelectedList");

		/* Click on selected shopping list */
		try {
			weeklygrocery.getShopingListEntryByLable(newListNameValue).waitForPresent(2000);
			weeklygrocery.getShopingListEntryByLable(newListNameValue).click();
		} catch (Exception e) {
			PerfectoUtils.getAppiumDriver().scrollToExact(newListNameValue);
			weeklygrocery.getShopingListEntryByLable(newListNameValue).waitForPresent(1000);
			weeklygrocery.getShopingListEntryByLable(newListNameValue).click();
		}
		PerfectoUtils.reportMessage("Selected list: " + newListNameValue, MessageTypes.Pass);
	}

	/**
	 * Verify and click on the list overflow\edit icon in selected list page
	 */
	@QAFTestStep(description = "I select the Overflow/Edit icon from the action bar")
	public void iSelectTheOverflowIconFromTheActionBar() {
		MylistTestPage mylistpage = new MylistTestPage();

		/* Validating Overview icon and clicking */
		mylistpage.getMylistsIconOverflow().verifyPresent();
		mylistpage.getMylistsIconOverflow().click();
	}

	/**
	 * Verify the expected text 'Copy Items To List', and the buttons Cancel &
	 * Add are present in the popup
	 */
	@QAFTestStep(description = "I should see Copy Items to List popup")
	public void iShouldSeeCopyItemsToListPopup() {
		MylistTestPage mylistpage = new MylistTestPage();

		String strexpectedtitle = "Copy Items To List";
		String stractualtitle = null;
		mylistpage.waitForPageToLoad();
		stractualtitle = mylistpage.getMyListsLblCopylistoverlay().getText();

		if (stractualtitle.equals(strexpectedtitle)) {
			PerfectoUtils.reportMessage(
					"Expected msg: " + strexpectedtitle + " Actual msg: " + stractualtitle + " " + "matched");
		} else {
			PerfectoUtils.reportMessage(
					"Expected msg: " + strexpectedtitle + " Actual msg: " + stractualtitle + " " + " not matchd");
		}
		mylistpage.getMylistsBtnadd().verifyPresent();
		mylistpage.getMyListsBtnCancel().verifyPresent();
	}

	/**
	 * Verify the popup title matches the text 'Add to List' and return status
	 */
	@QAFTestStep(description = "I see Add to List popup on selecting Add to List button")
	public void iSeeAddToListPopupOnSelectingAddToListButton() {
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();

		String popupTitle = null;
		popupTitle = androidcommonpage.getAddtolistLblAlerttitle().getText();

		if (popupTitle.equals("Add to List")) {
			PerfectoUtils.reportMessage("Add To List pop up is displayed as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Add To List pop up is not displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Enter the receipt number 'ScanReceipt.ReciepNumber' in the receipt number
	 * field Verify all the entered 23 digits of receipt number is displayed or
	 * not Click Add button to add the receipt to list Check the alert is
	 * displayed with title 'Add to List' to verify add to list popup Click Add
	 * to list button in the popup if it is displayed Handle the error popup and
	 * display appropriate error message Verify app returned to list 'ListName'
	 * where the item is added and return the status
	 * 
	 * @param receipt
	 *            number 'ScanReceipt.ReciepNumber' and list name 'ListName'
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I enter Reciept Number")
	public void iEnterRecieptNumber() throws InterruptedException {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		AndroidcommonTestPage androidCommon = new AndroidcommonTestPage();

		listdetails.getListpageTxtEnterrecieptnumber().sendKeys(getBundle().getString("ScanReceipt.ReciepNumber"));
		try {
			androidCommon.getScanreceiptLblCharactercount().waitForPresent(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		String strCount = androidCommon.getScanreceiptLblCharactercount().getText().trim();

		if (strCount.equalsIgnoreCase("0")) {
			PerfectoUtils.reportMessage("Entered number count is 23", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Please try again and enter reciept number with 23 characters",
					MessageTypes.Fail);
		}
		listdetails.getListpageBtnAdd().click();
		listdetails.waitForPageToLoad();

		/* Validation of Alert Details */
		androidCommon.getAddtolistLblAlerttitle().waitForPresent(30000);
		if (androidCommon.getAddtolistLblAlerttitle().verifyText("Add to List")) {
			PerfectoUtils.reportMessage("Add to list pop up has been populated", MessageTypes.Pass);
			listdetails.getListpageBtnAdd().click();
		}
		if (weeklygrocery.getShopingListEntryByLable("Error").isPresent()) {
			weeklygrocery.getShopingListEntryByLable("Ok").click();
			PerfectoUtils.reportMessage("Invalid recipt number has been entered", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("Recipt number has been entered", MessageTypes.Pass);
		}

		/* Verify if it is landed in my list page */
		String listName = getBundle().getString("ListName");
		boolean isPageDisplayed = weeklygrocery.getShopingListEntryByLable(listName).verifyPresent();
		if (isPageDisplayed) {
			PerfectoUtils.reportMessage("Entering recipt number success and navigated back to My List Page",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Entering recipt number is not success and navigated back to My List Page",
					MessageTypes.Fail);
		}
	}

	/**
	 * Look for a selected list 'NewListName' or 'ChoosenList' in the available
	 * lists Scroll and check if the list is not available If match found, click
	 * on the list name and report
	 */
	@QAFTestStep(description = "I see List detail page on clicking corresponding list name from My list page")
	public void iSeeListDetailPageOnClickingCorrespondingListNameFromMyListPage() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String newListNameValue = ConfigurationManager.getBundle().getString("NewListName");

		if (newListNameValue == null) {
			newListNameValue = ConfigurationManager.getBundle().getString("ChoosenList");
		}

		/* Click on selected shopping list */
		try {
			weeklygrocery.getShopingListEntryByLable(newListNameValue).waitForPresent(3000);
			weeklygrocery.getShopingListEntryByLable(newListNameValue).click();
		} catch (Exception e) {
			AndroidStepDef.scrollToListNameInMyList(newListNameValue, 90, 80, 2);
			weeklygrocery.getShopingListEntryByLable(newListNameValue).waitForPresent(1000);
			weeklygrocery.getShopingListEntryByLable(newListNameValue).click();
		}
		PerfectoUtils.reportMessage("Selected list: " + newListNameValue, MessageTypes.Pass);
	}

	/**
	 * Navigate back to previous page that is My list page using device back
	 * button Verify my list page is landed properly
	 */
	@QAFTestStep(description = "I navigate back to My List page from Registration page")
	public void iNavigateBackToMyListPageFromRegistrationPage() {
		MylistTestPage mylistpage = new MylistTestPage();

		PerfectoUtils.androiddeviceback();

		/* Clicking Yes button from cancel registration pop-up */
		PerfectoUtils.reportMessage("Not Clicked on yes button, is no longer apperaing,sprint changes",
				MessageTypes.Info);
		mylistpage.getMyListLblPagetitle().verifyPresent();
	}

	/**
	 * Report toast message cannot be handled in android
	 */
	@QAFTestStep(description = "I should see the error toast message")
	public void iShouldSeeTheErrorToastMessage() {
		PerfectoUtils.reportMessage("Toast message cannot handle in Android", MessageTypes.Pass);
	}

	/**
	 * Enter the invalid receipt number 'ScanReceipt.InvalidReciepNumber' in the
	 * receipt number field Verify all the entered 23 digits of receipt number
	 * is displayed or not Click Add button to add the receipt to list Check the
	 * alert is not displayed with 'Add to List' text and fail if it is true
	 * Check the alert is displayed with 'Error' text for invalid receipt number
	 * Handle the error popup Verify app returned to enter receipt number page
	 * from where we entered the receipt number Navigate back to list page by
	 * clicking Hamburger
	 * 
	 * @param receipt
	 *            number 'ScanReceipt.InvalidReciepNumber'
	 */
	@QAFTestStep(description = "I enter invalid Reciept Number")
	public void iEnterInvalidRecieptNumber() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		AndroidcommonTestPage androidCommon = new AndroidcommonTestPage();

		listdetails.getListpageTxtEnterrecieptnumber()
				.sendKeys(getBundle().getString("ScanReceipt.InvalidReciepNumber"));
		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		String strCount = androidCommon.getScanreceiptLblCharactercount().getText().trim();

		if (strCount.equalsIgnoreCase("0")) {
			PerfectoUtils.reportMessage("Entered number count is 23", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Please try again and enter reciept number with 23 characters",
					MessageTypes.Fail);
		}
		listdetails.getListpageBtnAdd().click();
		listdetails.waitForPageToLoad();

		/* Validation of Alert Details */
		if (androidCommon.getAddtolistLblAlerttitle().isPresent()) {
			if (androidCommon.getAddtolistLblAlerttitle().verifyText("Add to List")) {
				PerfectoUtils.reportMessage("Add to list pop up has been populated", MessageTypes.Fail);
				listdetails.getListpageBtnAddtolist().click();
			}
		}
		if (weeklygrocery.getShopingListEntryByLable("Error").isPresent()) {
			PerfectoUtils.reportMessage("Error message has been populated for invalid reciept number",
					MessageTypes.Pass);
			try {
				weeklygrocery.getShopingListEntryByLable("Ok").click();
			} catch (Exception e) {
				weeklygrocery.getShopingListEntryByLable("OK").click();
			}
		}
		androidCommon.getScanreceiptBtnEnterreceiptnumber().waitForPresent(3000);

		if (androidCommon.getScanreceiptBtnEnterreceiptnumber().isPresent()) {
			PerfectoUtils.reportMessage("Scan Receipt page is populated upon entering invalid receipt number",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Scan Receipt page is not populated upon entering invalid receipt number",
					MessageTypes.Fail);
		}

		/* Navigate back to list details page */
		androidCommon.getAppHamburger().click();
	}

	/**
	 * Click on the overflow icon in the my list page if lists is available If
	 * list is not available, click plus icon, enter new list name and click
	 * save button then do the above step
	 */
	@QAFTestStep(description = "I select the Overflow icon from my lists page")
	public void iSelectTheOverflowIconFromMyListsPage() {
		MylistTestPage mylistpage = new MylistTestPage();
		AndroidStepDefShoppingList androidStepDefShoppingList = new AndroidStepDefShoppingList();

		int listSize = mylistpage.getMyListLblLstNameHotUserItems().size();
		if (listSize <= 1) {
			iClickOnPlusIconToAddList();
			androidStepDefShoppingList.iShouldSeeThePopupToEnterListName();
			androidStepDefShoppingList.iEnterTheShoppingListName();
			androidStepDefShoppingList.iClickTheSaveButton();
		}
		mylistpage.getMylistsIconOverflow().verifyPresent();
		mylistpage.getMylistsIconOverflow().click();

	}

	/**
	 * Verify the edit list options are displayed
	 */
	@QAFTestStep(description = "I should see the list of options")
	public void iShouldSeeTheListOfOptions() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.getMylistsLblEditList().verifyPresent();

	}

	/**
	 * Wait for and Select the delete list option
	 */
	@QAFTestStep(description = "I select delete list option")
	public void iSelectDeleteListOption() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.waitForPageToLoad();
		mylistpage.getMylistsLblDeleteList().waitForPresent(3000);
		mylistpage.getMylistsLblDeleteList().click();
	}

	/**
	 * Verify the my list is displayed in edit mode by verifying row edit option
	 * presence
	 */
	@QAFTestStep(description = "I should see My Lists page in Edit mode")
	public void iShouldSeeMyListsPageInEditMode() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.waitForPageToLoad();
		if (mylistpage.getLblTaprowstoedit().isPresent()) {
			PerfectoUtils.reportMessage("My Lists page displayed in Edit mode", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("My Lists page displayed in Edit mode", MessageTypes.Fail);
		}
	}

	/**
	 * Verify the selected list 'DeletedListName' is highlighted in red by
	 * verifying the list is selected or not
	 * 
	 * @param list
	 *            name 'DeletedListName'
	 */
	@QAFTestStep(description = "I should see the List name highlighted in red")
	public void iShouldSeeTheListNameHighlightedInRed() {
		AddtolistTestPage addtolistpage = new AddtolistTestPage();
		MylistTestPage mylistpage = new MylistTestPage();
		String strDeletedList = null;

		addtolistpage.waitForPageToLoad();
		mylistpage.getMyListLblPagetitle().waitForPresent(5000);
		strDeletedList = getBundle().getPropertyValue("DeletedListName");

		/* Forming the dynamic object using the list name */
		boolean isListDisplayed = addtolistpage.getShopingListEntryByLable(strDeletedList).isSelected();
		if (!isListDisplayed) {
			PerfectoUtils.reportMessage("Selected List name: " + strDeletedList + " is highlighted");
		} else {
			PerfectoUtils.reportMessage("Selected List name: " + strDeletedList + " is not highlighted");
		}
	}

	/**
	 * Wait for and click on the Delete icon
	 */
	@QAFTestStep(description = "I select delete icon")
	public void iSelectDeleteIcon() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.waitForPageToLoad();
		mylistpage.getMyListsIconDelete().waitForPresent(2000);
		mylistpage.getMyListsIconDelete().click();
	}

	/**
	 * Verify the delete list popup is displayed If displayed verify the Cancel
	 * & Delete button are available Also verify the predefined text with list
	 * name 'DeletedListName' is displayed in the popup
	 * 
	 * @param list
	 *            name 'DeletedListName'
	 */
	@QAFTestStep(description = "I should see the Delete Lists popup")
	public void iShouldSeeTheDeleteListsPopup() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.getMyListsTitleDelLstTitleInDelLstOverlay().verifyPresent();

		if (mylistpage.getMyListsTitleDelLstTitleInDelLstOverlay().isPresent()) {
			mylistpage.getMyListsBtnCancelInDelLstOverlay().verifyPresent();
			mylistpage.getMyListsBtnDeleteInDelLstOverlay().verifyPresent();

			/*
			 * Comparison of message displayed in delete list confirmation
			 * overlay
			 */
			String strExpConfirmationMsg = "Are you sure you want to delete the list: "
					+ getBundle().getPropertyValue("DeletedListName") + " ?";
			String strActConfirmationMsg = mylistpage.getMyListsBtnDelMsgDelLstOverlay().getText();

			if (strExpConfirmationMsg.equals(strActConfirmationMsg)) {
				PerfectoUtils.reportMessage("Expected msg: " + strExpConfirmationMsg + " Actual msg: "
						+ strActConfirmationMsg + " " + "matched");
			} else {
				PerfectoUtils.reportMessage("Expected msg: " + strExpConfirmationMsg + " Actual msg: "
						+ strActConfirmationMsg + " " + " not matchd");
			}
		} else {
			PerfectoUtils.reportMessage("There is no list is available to delete", MessageTypes.Fail);
		}
	}

	/**
	 * Click on the Delete button in delete list popup and report After clicking
	 * wait for Delete button not to present
	 */
	@QAFTestStep(description = "I select the Delete button from delete list popup")
	public void iSelectTheDeleteButtonFromDeleteListPopup() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.waitForPageToLoad();
		if (mylistpage.getMyListsBtnDeleteInDelLstOverlay().isPresent()) {
			mylistpage.getMyListsBtnDeleteInDelLstOverlay().click();
			PerfectoUtils.reportMessage("Clicked On Delete button from the popup.", MessageTypes.Pass);
			mylistpage.getMyListsBtnDeleteInDelLstOverlay().waitForNotPresent(10000);
		}
	}

	/**
	 * Verify the list 'DeletedListName' is present or not and report the status
	 * 
	 * @param list
	 *            name 'DeletedListName'
	 */
	@QAFTestStep(description = "I should not see the list name")
	public void iShouldNotSeeTheListName() {
		AddtolistTestPage addtolistpage = new AddtolistTestPage();

		addtolistpage.waitForPageToLoad();
		String strDeletedList = getBundle().getPropertyValue("DeletedListName");

		/* Forming the dynamic object */
		boolean isListDisplayed = addtolistpage.getShopingListEntryByLable(strDeletedList).isPresent();
		if (!isListDisplayed) {
			PerfectoUtils.reportMessage("Deleted List: " + strDeletedList + " is not displayed");
		} else {
			PerfectoUtils.reportMessage("Deleted List: " + strDeletedList + " is displayed");
		}
	}

	/**
	 * Wait for and click on the Edit list option
	 */
	@QAFTestStep(description = "I select Edit List option")
	public void iSelectEditListOption() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.getMylistsLblEditList().waitForPresent(3000);
		mylistpage.getMylistsLblEditList().click();
	}

	/**
	 * Verify the popup title is present and verify the Rename button is
	 * available in the popup
	 */
	@QAFTestStep(description = "I should see the Rename <Shoping List> popup")
	public void iShouldSeeTheRenameShopingListPopup() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.getMyListsPopUpTitle().isPresent();
		mylistpage.getMylistBtnRename().verifyPresent();
	}

	/**
	 * Enter new dynamic list name in the rename list field using date & format
	 * class
	 */
	@QAFTestStep(description = "I edit the Shopping List name")
	public void iEditTheShoppingListName() {
		MylistTestPage mylistpage = new MylistTestPage();

		String strListName = null, strTimeStmp = null;

		/* Getting the current time to form the unique list name */
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();
		strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		strListName = "List_" + strTimeStmp;
		mylistpage.getMyListTxtRenameTheList().sendKeys(strListName);
	}

	/**
	 * Verify Rename button is present and click on it
	 */
	@QAFTestStep(description = "I click the Rename button")
	public void iClickTheRenameButton() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.getMylistBtnRename().verifyPresent();
		mylistpage.getMylistBtnRename().click();
	}

	/**
	 * Select a list name to be deleted when list is available Select the list
	 * name only when the list name is not equal to 'Wish List'
	 * 
	 * @return selected list name 'DeletedListName'
	 */
	@QAFTestStep(description = "I select a list to delete")
	public void iSelectAListToDelete() {
		MylistTestPage mylistpage = new MylistTestPage();

		/* Click on first shopping list */
		List<QAFWebElement> items = mylistpage.getMyListLblLstNameHotUserItems();
		if (items.size() > 1) {
			if ((items.get(0).getText()).equals("Wish List")) {
				items.get(1).click();
				ConfigurationManager.getBundle().setProperty("DeletedListName", items.get(0).getText());
			} else {
				items.get(0).click();
				ConfigurationManager.getBundle().setProperty("DeletedListName", items.get(0).getText());
			}
		}
	}

	/**
	 * Enter the already existing list name 'Listname' as new list name
	 * 
	 * @param list
	 *            name 'Listname'
	 */
	@QAFTestStep(description = "I enter existing List name to rename")
	public void iEnterExistingListNameToRename() {
		MylistTestPage mylist = new MylistTestPage();

		String listname = getBundle().getString("Listname");
		mylist.getMyListTxtEnterNewList().clear();
		mylist.getMyListTxtEnterNewList().sendKeys(listname);
	}

	/**
	 * Get the total available list and select the first listed list and return
	 * the list name
	 * 
	 * @return 'Listname'
	 */
	@QAFTestStep(description = "I select the first list")
	public void iSelectTheFirstList() {
		MylistTestPage mylistpage = new MylistTestPage();

		/* Click on first shopping list */
		String listname = null;
		List<QAFWebElement> items = mylistpage.getMyListLblLstNameHotUserItems();
		listname = items.get(0).getText();
		items.get(0).click();
		getBundle().setProperty("Listname", listname);
	}

	/**
	 * Verify the different sections Plus icon, page title, search button, list
	 * item count, item checked off count and Hamburger are present in Weekly
	 * grocery page
	 */
	@QAFTestStep(description = "I validate the Weekly Groceries page")
	public void iValidateTheWeeklyGroceriesPage() {
		WeeklygroceriesTestPage weeklygroceries = new WeeklygroceriesTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		ListdetailsTestPage listdetail = new ListdetailsTestPage();

		weeklygroceries.getWgBtnPlusaction().verifyPresent();
		weeklygroceries.getLblPagetitle().verifyPresent();
		weeklygroceries.getWgBtnSearch().verifyPresent();
		weeklygroceries.getWgTxtShoppingitemcount().verifyPresent();
		weeklygroceries.getWgTxtCheckedOff().verifyPresent();
		androidcommon.getAppHamburger().verifyPresent();
		listdetail.getListpageBtnEmail().verifyNotPresent();

		weeklygroceries.getWgImgMenuoverflow().verifyPresent();
		weeklygroceries.getWgImgMenuoverflow().click();
		listdetail.getListpageLinkDeleteitem().verifyPresent();
		listdetail.getListpageLinkDeleteallitem().verifyPresent();
		listdetail.getListpageLinkUncheckitem().verifyPresent();
		listdetail.getListpageLinkCopytoanotherlist().verifyNotPresent();

	}

	/**
	 * Report this step is not applicable for android
	 */
	@QAFTestStep(description = "I click on plus from action bar")
	public void iClickOnPlusFromActionBar() {

		PerfectoUtils.reportMessage("Step Not Applicable for Android.", MessageTypes.Info);
	}

	/**
	 * Report this step is not applicable for android
	 */
	@QAFTestStep(description = "I should see the Please Log In popup")
	public void iShouldSeeThePleaseLogInPopup() {

		PerfectoUtils.reportMessage("Step Not Applicable for Android.", MessageTypes.Info);
	}

	/**
	 * Navigate to a selected list 'listName' Verify the selected ingredients
	 * 'inglist' are available in the list If ingredient is not available,
	 * scroll and verify
	 * 
	 * @param list
	 *            name 'listName' and ingredients list 'inglist'
	 */
	@QAFTestStep(description = "I verify if all ingredients added in selected shopping list")
	public void iVerifyIfAllIngredientsAddedInSelectedShoppingList() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		/* Click on selected shopping list */
		try {
			weeklygrocery.getShopingListEntryByLable(getBundle().getString("listName")).click();
		} catch (Exception e) {
			PerfectoUtils.getAppiumDriver().scrollToExact(getBundle().getString("listName"));
			weeklygrocery.getShopingListEntryByLable(getBundle().getString("listName")).click();
		}
		PerfectoUtils.reportMessage("Selected list: " + getBundle().getString("listName"), MessageTypes.Pass);

		/* Verify if selected ingredient is available */

		for (Object actualProduct : getBundle().getList("inglist")) {
			String actProduct = actualProduct.toString();
			try {
				weeklygrocery.getShopingListEntryByLable(actProduct).waitForPresent(3000);
				if (weeklygrocery.getShopingListEntryByLable(actProduct).isPresent()) {
					PerfectoUtils.reportMessage("Ingredient " + actProduct + " is available", MessageTypes.Pass);
				}
			} catch (Exception e) {
				try {
					IOSStepdef.scrollToListNameInMyList(actProduct);
					PerfectoUtils.reportMessage("Ingredient " + actProduct + " is available", MessageTypes.Pass);
				} catch (Exception f) {
					PerfectoUtils.reportMessage("Ingredient " + actProduct + " is not available", MessageTypes.Fail);
				}
			}
		}
	}

	/**
	 * Navigate to my list page and navigate to weekly grocery list Select
	 * overflow icon and select the Delete all option Verify all items get
	 * deleted in the list Click on hamburger and navigate to Home page
	 */
	@QAFTestStep(description = "I delete all items from weekly groceries shopping list")
	public void iDeleteAllItemsFromWeeklyGroceriesShoppingList() {
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();

		iNavigateToMyListPage();
		iNavigateToWeeklyGroceriesPage();
		iSelectTheOverflowIconFromTheActionBar();
		iSelectDeleteAllItemsOption();
		iShouldSeeAllItemsAreDeletedFromList();

		androidcommonpage.getAppHamburger().waitForPresent(3000);
		androidcommonpage.getAppHamburger().click();
		androidcommonpage.getAppSliderHome().click();
	}

	/**
	 * Click on submit button with invalid email address in login popup Verify
	 * the login failure happen with invalid email address and report the status
	 */
	@QAFTestStep(description = "I see error message for invalid email after click on Login/Submit button")
	public void iSeeErrorMessageForInvalidEmailAfterClickOnLoginSubmitButton() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		LoginpopupTestPage loginpopup = new LoginpopupTestPage();

		/* Clicking on Login button */
		loginpopup.getLoginpopupBtnOverlaylogin().waitForPresent(3000);
		loginpopup.getLoginpopupBtnOverlaylogin().click();

		PerfectoUtils.reportMessage("Toast Message for invalid email is not verified", MessageTypes.Info);

		weeklygrocery.getWgBtnLogIn().waitForPresent(5000);

		if (weeklygrocery.getWgBtnLogIn().isPresent()) {
			PerfectoUtils.reportMessage("Login Failure due to invalid email addess", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Login success due to invalid email addess", MessageTypes.Fail);
		}
	}

	/**
	 * Verify the selected list of items (arrActualItemname &
	 * arrGenericItemname) available in the selected list 'SelectedList' Get all
	 * the listed item in the list in a set 'arrExpItemname' And Verifies each
	 * 'arrActualItemname' items available in the selected list and if mathces
	 * add to set 'arrExpItemname' At the end we verify 'arrExpItemname'
	 * contains all 'arrActualItemname' return the result
	 * 
	 * @param SelectedList,
	 *            arrActualItemname, arrGenericItemname
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I should see the Product which is copied to this list")
	public void iShouldSeeTheProductWhichIsCopiedToThisList() throws InterruptedException {
		ListdetailsTestPage listdetail = new ListdetailsTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String strDestinationList = getBundle().getPropertyValue("SelectedList");
		List<String> arrActualItemname = new ArrayList(getBundle().getList("arrActualItemname"));
		Collections.sort(arrActualItemname);

		List<String> arrGenericItemname = new ArrayList(getBundle().getList("arrGenericItemname"));
		String strActualItemlast;

		if (arrGenericItemname.isEmpty()) {
			strActualItemlast = arrActualItemname.get(arrActualItemname.size() - 1);
		} else {
			strActualItemlast = arrGenericItemname.get(arrGenericItemname.size() - 1);
		}

		// Getting the expected item names
		HashSet<String> arrExpItemname = new HashSet<String>();

		for (QAFWebElement temp : listdetail.getListpageLblItemNameListobj()) {
			arrExpItemname.add(temp.getText());
		}

		try {
			weeklygrocery.getShopingListEntryByLable(strActualItemlast).waitForPresent(5000);
		} catch (Exception e) {
			try {
				for (String tempName : arrActualItemname) {
					PerfectoUtils.getAppiumDriver().scrollToExact(tempName);
					arrExpItemname.add(tempName);
				}
			} catch (Exception f) {
				for (String tempName : arrActualItemname) {
					AndroidStepDef.scrollToListNameInMyList(tempName, 90, 70, 2);
					arrExpItemname.add(tempName);
				}
			}

		}

		if (arrExpItemname.containsAll(arrActualItemname)) {
			PerfectoUtils.reportMessage("Items copied is present in the destination list: " + strDestinationList + " ",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Items copied is not present in the destination list: " + strDestinationList + " ",
					MessageTypes.Fail);
		}

	}

	/**
	 * Wait for or scroll to Select All button in recipe details page And click
	 * on the Select All button and get the items counts which got checkbox
	 * selected and save in 'ingSize'
	 * 
	 * @param item
	 *            count 'ingSize'
	 */
	@QAFTestStep(description = "I see the selected ingredient on selecting all ingredient within corresponding check field")
	public void iSeeTheSelectedIngredientOnSelectingAllIngredientWithinCorrespondingCheckField() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		QAFWebElement elename = recipedetail.getRecipedetailpagelblselectall();
		int intX = 50;
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartY = (int) (size.height * (0.8));
		int intEndY = (int) (size.height * (0.6));
		PerfectoUtils.getAppiumDriver().swipe(intX, intStartY, intX, intEndY, 2);

		PerfectoUtils.scrollToStringuntilfindelement(elename, 80, 70, 2);

		recipedetail.getRecipedetailpagelblselectall().waitForPresent(5000);

		recipedetail.getRecipedetailpagelblselectall().click();
		PerfectoUtils.reportMessage("Clicked Select All option.", MessageTypes.Pass);
		recipedetail.getLblUnselectall().waitForPresent(30000);

		if (recipedetail.getLblUnselectall().getText().equalsIgnoreCase("Unselect All")) {
			PerfectoUtils.reportMessage("Selected All products.", MessageTypes.Pass);
			int chkitem = recipedetail.getRecipedetailLblIngredientslistchecked().size();
			getBundle().setProperty("ingSize", chkitem);
		} else {
			recipedetail.getRecipedetailBtnSelectall().waitForPresent(1000);
			recipedetail.getRecipedetailBtnSelectall().click();
			if (recipedetail.getLblUnselectall().getText().equalsIgnoreCase("Unselect All")) {
				PerfectoUtils.reportMessage("Selected All products.", MessageTypes.Pass);
				int chkitem = recipedetail.getRecipedetailLblIngredientslistchecked().size();
				getBundle().setProperty("ingSize", chkitem);
			} else {

				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", "Select All");
				Object result1 = recipedetail.getTestBase().getDriver().executeScript("mobile:text:select", params1);
				recipedetail.getLblUnselectall().waitForPresent(30000);
				if (recipedetail.getLblUnselectall().getText().equalsIgnoreCase("Unselect All")) {
					PerfectoUtils.reportMessage("Selected All products.", MessageTypes.Pass);
					int chkitem = recipedetail.getRecipedetailLblIngredientslistchecked().size();
					getBundle().setProperty("ingSize", chkitem);
				} else {
					Map<String, Object> params2 = new HashMap<>();
					params2.put("content", "GROUP:Android/Browse/selectAllBtn.png");
					Object result2 = recipedetail.getTestBase().getDriver().executeScript("mobile:image:select",
							params2);
					recipedetail.getLblUnselectall().waitForPresent(30000);
					if (recipedetail.getLblUnselectall().getText().equalsIgnoreCase("Unselect All")) {
						PerfectoUtils.reportMessage("Selected All products.", MessageTypes.Pass);
						int chkitem = recipedetail.getRecipedetailLblIngredientslistchecked().size();
						getBundle().setProperty("ingSize", chkitem);
					} else
						PerfectoUtils.reportMessage("Not selected All products.", MessageTypes.Fail);
				}
			}
		}
	}

	/**
	 * Verify the search results is relevant to the search term
	 * 'products.productname' by verifying the result item name whether it
	 * contain the search term 'products.productname' or not
	 * 
	 * @param products.productname
	 */
	@QAFTestStep(description = "I should see the Search Results page")
	public void iShouldSeeTheSearchResultsPage() {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		wgsearchresult.waitForPageToLoad();
		// Validate relevant products are displayed
		String strValidProductname = getBundle().getString("products.productname");
		Boolean result = false;
		wgsearchresult.getWgLblSearchresultItemname().verifyPresent();
		result = (wgsearchresult.getWgLblSearchresultItemname().getText().toLowerCase())
				.contains(strValidProductname.toLowerCase());

		if (result) {
			PerfectoUtils.reportMessage("Searched Product " + strValidProductname + " is displayed in Result",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Searched Product " + strValidProductname + " is not displayed in Result",
					MessageTypes.Fail);
		}
	}

	/**
	 * Select a product from CDP page by navigating to All products tab and take
	 * the first item name and click on it Get the product name from PDP and
	 * save in 'ChoosenProduct'
	 * 
	 * @return product name 'ChoosenProduct'
	 */
	@QAFTestStep(description = "I select product from CDP to PDP")
	public static void selectProductFromCDPAndAdtolistFromPDP() {
		ProductsresultlistTestPage itemresult = new ProductsresultlistTestPage();
		ProductdetailTestPage pdp = new ProductdetailTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		ProductResult result = null;
		String prdName = null;

		if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
			PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Pass);
			storelocator.getStorelocatorBtnAllow().click();
		}

		/* Clicking single product from CDP page */
		// itemresult.getLblAllproducts().waitForPresent(5000);
		// itemresult.getLblAllproducts().click();
		itemresult.getDpdBMDownCarat().waitForPresent(5000);

		/* Clicking single product from CDP page */
		result = itemresult.getProductresultlist().get(0);
		prdName = result.getProductresultLblProductname().getText();
		PerfectoUtils.reportMessage("Product Name:" + prdName);
		getBundle().setProperty("ChoosenProduct", prdName);

		if (result.isPresent()) {
			result.select();
			PerfectoUtils.reportMessage("Clicked product:" + prdName + "from CDP page", MessageTypes.Pass);
		} else {
			IOSStepdef.scrollToListNameInMyList(prdName);
			PerfectoUtils.reportMessage("Clicked product:" + prdName + "from CDP page", MessageTypes.Info);
		}

		/* Getting Product Title from PDP page */
		pdp.waitForPageToLoad();
		pdp.getPdpLblProductname().waitForPresent(5000);
		String strProductName = pdp.getPdpLblProductname().getText();
		getBundle().setProperty("ChoosenProduct", strProductName);
		System.out.println(getBundle().getString("ChoosenProduct"));
	}

	/**
	 * Enter invalid emailId address 'SendEmail.InvalidEmailAddress' in
	 * recipient email field and click Send button
	 * 
	 * @param 'SendEmail.InvalidEmailAddress'
	 */
	@QAFTestStep(description = "I enter Invalid email address and click on Send/ submit button")
	public void iEnterInvalidEmailAddressAndClickOnSendSubmitButton() {
		SendemailTestPage sendemail = new SendemailTestPage();

		String recipientEmail = null;
		sendemail.waitForPageToLoad();
		recipientEmail = getBundle().getString("SendEmail.InvalidEmailAddress");
		sendemail.getSendemailTxtRecipientemail().sendKeys(recipientEmail);

		PerfectoUtils.reportMessage("Entered Email: " + recipientEmail + " ");
		sendemail.getSendemailBtnSend().click();
		PerfectoUtils.reportMessage("Clicked Send");

	}

	/**
	 * Report toast message cannot be handled in android
	 */
	@QAFTestStep(description = "I should see the error popup/ toast message")
	public void iShouldSeeTheErrorPopupToastMessage() {
		PerfectoUtils.reportMessage("Toast message cannot handle in Android", MessageTypes.Pass);
	}

	/**
	 * If the list is not empty, get the first item name in the list and save in
	 * 'ChoosenProduct' If the list is empty, search for a keyword, select an
	 * item from search result and add to list and do the above step
	 * 
	 * @return Item name 'ChoosenProduct'
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I get the product name from list details page")
	public void iGetTheProductNameFromListDetailsPage() throws InterruptedException {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();

		String count = listdetails.getListpageLblShoppingitemcount().getText();
		if (!count.equalsIgnoreCase("0 " + getBundle().getString("ShoplistCountItems"))) {
			PerfectoUtils.reportMessage("An item is found in the list.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("No Item is found in the list.", MessageTypes.Info);
			iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
			iEnterValidSearchTermAndSelectSearchButtonInWeeklyGroceriesPage(
					getBundle().getString("products.productname"));
			iShouldSeeTheSearchResultsPage();
			iSelectTheItemFirstEntry();
			PerfectoUtils.reportMessage("An item is added to the list.", MessageTypes.Pass);
		}

		getBundle().setProperty("ChoosenProduct", listdetails.getListpageLblItemNameListobj().get(0).getText());
	}

	/**
	 * Enter recipient email id 'default.user.email' and change the sender email
	 * id by entering new email id 'SendEmail.senderemail' and click send button
	 * 
	 * @param 'default.user.email'
	 *            and 'SendEmail.senderemail'
	 */
	@QAFTestStep(description = "I change the sender email address and click on Send/ submit button")
	public void iChangeTheSenderEmailAddressAndClickOnSendSubmitButton() {
		SendemailTestPage sendemail = new SendemailTestPage();

		String senderemail = null;
		String recipientEmail = null;
		sendemail.waitForPageToLoad();
		recipientEmail = getBundle().getString("default.user.email");
		sendemail.getSendemailTxtRecipientemail().sendKeys(recipientEmail);

		senderemail = getBundle().getString("SendEmail.senderemail");
		sendemail.getSendemailTxtSenderemail().sendKeys(senderemail);

		PerfectoUtils.reportMessage("Entered Email: " + senderemail + " ");
		sendemail.getSendemailBtnSend().click();
		PerfectoUtils.reportMessage("Clicked Send");

	}

	/**
	 * Verify the search results is relevant to the search term 'productname' by
	 * verifying the result item name whether it contain the search term
	 * 'productname' or not
	 * 
	 * @param productname
	 */
	public void iShouldSeeTheSearchResultsPage(String productname) {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		wgsearchresult.waitForPageToLoad();
		// Validate relevant products are displayed
		Boolean result = false;
		wgsearchresult.getWgLblSearchresultItemname().verifyPresent();
		result = (wgsearchresult.getWgLblSearchresultItemname().getText().toLowerCase())
				.contains(productname.toLowerCase());

		if (result) {
			PerfectoUtils.reportMessage("Searched Product " + productname + " is displayed in Result",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Searched Product " + productname + " is not displayed in Result",
					MessageTypes.Fail);
		}
	}

	/**
	 * Verify the list 'listName' to which item added is the newly created list
	 * 'NewListName' and result the status as info Navigate to the list
	 * 'addedList' if available and if not available scroll and check for the
	 * list Verify the added ingredients 'ingSize' are available in list by
	 * comparing 'ingSize' with list item count and return the status
	 * 
	 * @param list
	 *            names 'NewListName', 'listName' and ingredient count 'ingSize'
	 */
	@QAFTestStep(description = "I verify if ingredients added in selected shopping list of hot user")
	public void iVerifyIfIngredientsAddedInSelectedShoppingListOfHotUser() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String selectedListName = getBundle().getString("NewListName");
		String addedList = getBundle().getString("listName");
		if (!selectedListName.equalsIgnoreCase(addedList)) {
			PerfectoUtils.reportMessage("List name is selected is not newly created one: Selected: " + addedList,
					MessageTypes.Info);
			selectedListName = addedList;
		}

		/* Click on selected shopping list */
		try {
			weeklygrocery.getShopingListEntryByLable(addedList).waitForPresent(2000);
			weeklygrocery.getShopingListEntryByLable(addedList).click();
		} catch (Exception e) {
			PerfectoUtils.scrollToString(addedList, 80, 70, 2);
			weeklygrocery.getShopingListEntryByLable(addedList).waitForPresent(1000);
			weeklygrocery.getShopingListEntryByLable(addedList).click();
		}

		PerfectoUtils.reportMessage("Selected list: " + selectedListName, MessageTypes.Pass);

		String strCount = weeklygrocery.getWgTxtShoppingitemcount().getText();

		if (strCount.contains("Items")) {
			strCount = strCount.replace("Items", "").trim();
		} else if (strCount.contains("Item")) {
			strCount = strCount.replace("Item", "").trim();
		}

		int intCount = Integer.parseInt(strCount);
		if (intCount == getBundle().getInt("ingSize")) {
			PerfectoUtils.reportMessage("All " + intCount + " ingredients are added to list", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("All " + intCount + " ingredients are not added to list", MessageTypes.Fail);
		}
	}

	/**
	 * Verify search icon is present and if present click on it
	 */
	@QAFTestStep(description = "I click on Search to add products field from CDP")
	public void iClickOnSearchToAddProductsFieldFromCDP() {
		ProductsearchresultTestPage productsearchresult = new ProductsearchresultTestPage();

		if (productsearchresult.getProdsearchresultTxtProductsearchmenuitem().isPresent()) {
			productsearchresult.getProdsearchresultTxtProductsearchmenuitem().click();
		} else {
			PerfectoUtils.reportMessage("Search icon not found.", MessageTypes.Fail);
		}
	}

	/**
	 * Navigate back to previous page that is list page by device back button
	 */
	@QAFTestStep(description = "I navigate back to list details page")
	public void iNavigateBackToListDetailsPage() {

		PerfectoUtils.androiddeviceback();
	}

	/**
	 * Select few list in the available list if their name not matches 'my list'
	 * or 'wish list'
	 */
	@QAFTestStep(description = "I select few lists to delete")
	public void iSelectFewListsToDelete() {
		MylistTestPage mylistpage = new MylistTestPage();

		/* Click on first shopping list */
		List<QAFWebElement> items = mylistpage.getMyListLblLstNameHotUserItems();
		for (QAFWebElement temp : items) {
			if ((!temp.getText().toLowerCase().contains("my list"))
					&& (!temp.getText().toLowerCase().contains("wish list"))) {
				temp.click();
			}
		}
	}

	/**
	 * Verify the scanned product is not added to list after clicking cancel by
	 * verifying the page is list page and list item count is 0 Get the item
	 * count by parsing 'Items' or Item' from the item count text
	 */
	@QAFTestStep(description = "I should not see the scanned product in the selected list")
	public void iShouldNotSeeTheScannedProductInTheSelectedList() {
		WeeklygroceriesTestPage weeklygroceries = new WeeklygroceriesTestPage();

		/* Checking whether the page has been navigated to List name page */
		if (weeklygroceries.getLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to " + weeklygroceries.getLblPagetitle().getText() + " page.",
					MessageTypes.Pass);

			String strItemCount = weeklygroceries.getWgTxtShoppingitemcount().getText().replaceAll("Items", "")
					.replaceAll("Item", "").trim();
			int itemCount = Integer.parseInt(strItemCount);

			/* Checking whether the scanned product is available in the list */
			if (itemCount == 0) {
				PerfectoUtils.reportMessage("Scanned product is not added in the list", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Scanned product is added in the list", MessageTypes.Fail);
			}

		} else {
			String strItemCount = weeklygroceries.getWgTxtShoppingitemcount().getText().replaceAll("Items", "")
					.replaceAll("Item", "").trim();
			int itemCount = Integer.parseInt(strItemCount);

			/* Checking whether the scanned product is available in the list */
			if (itemCount == 0) {
				PerfectoUtils.reportMessage("Scanned product is not added in the list", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Scanned product is added in the list", MessageTypes.Fail);
			}
		}

	}

	/**
	 * Verify my list is displayed in delete mode
	 */
	@QAFTestStep(description = "I should see My Lists page in Delete mode")
	public void iShouldSeeMyListsPageInDeleteMode() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.waitForPageToLoad();
		if (mylistpage.getLblTaprowstodelete().isPresent()) {
			PerfectoUtils.reportMessage("My Lists page displayed in delete mode", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("My Lists page displayed in delete mode", MessageTypes.Fail);
		}
	}

	/**
	 * Navigate to first list in the available lists and delete all the item in
	 * the list using overflow icon and delete all items options Navigate to
	 * home page using hamburger
	 */
	@QAFTestStep(description = "I delete all items from wish list of shopping list")
	public void iDeleteAllItemsFromWishListOfShoppingList() {
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();

		iNavigateToMyListPage();
		iSelectAndNavigateToFirstList();
		iSelectTheOverflowIconFromTheActionBar();
		iSelectDeleteAllItemsOption();
		iShouldSeeAllItemsAreDeletedFromList();

		androidcommonpage.getAppHamburger().waitForPresent(3000);
		androidcommonpage.getAppHamburger().click();
		androidcommonpage.getAppSliderHome().click();
	}

	/**
	 * Navigate to selected list 'listName' from list of available lists Verify
	 * the selected ingredient 'IngredientName' is available in selected list
	 * 'listName'
	 * 
	 * @param 'listName'
	 *            and ingredient name 'IngredientName'
	 */
	@QAFTestStep(description = "I verify if ingredients added in selected shopping list")
	public void iVerifyIfIngredientsAddedInSelectedShoppingList() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		boolean isFound = false;

		String selectedListname = getBundle().getString("listName");

		/* Click on selected shopping list */
		try {
			weeklygrocery.getShopingListEntryByLable(selectedListname).click();
		} catch (Exception e) {
			PerfectoUtils.getAppiumDriver().scrollToExact(selectedListname);
			weeklygrocery.getShopingListEntryByLable(selectedListname).click();
		}

		/* Verify if selected ingredient is available */
		for (ShoppinglistResult product : weeklygrocery.getWgListItemlist()) {
			String productName = product.getWgListItemname().getText();

			if (productName.equalsIgnoreCase(getBundle().getString("IngredientName"))) {
				PerfectoUtils.reportMessage("Added ingredient is available in shopping list", MessageTypes.Pass);
				isFound = true;
				break;
			}
		}

		if (!isFound) {
			PerfectoUtils.reportMessage("Added ingredient is not available in shopping list", MessageTypes.Fail);
		}
	}

	/**
	 * Navigate to My list page using My list option in home page if we are in
	 * home page If not navigated to list page, click the Hamburger option and
	 * select shopping list option from hamburger
	 */
	@QAFTestStep(description = "I navigate to My List page")
	public void iNavigateToMyListPage() {
		HomeTestPage homepage = new HomeTestPage();
		MylistTestPage mylistpage = new MylistTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		androidcommon.getAppHamburger().waitForPresent(5000);
		androidcommon.getAppHamburger().click();
		androidcommon.getAppSliderHome().waitForPresent(3000);
		androidcommon.getAppSliderHome().click();

		homepage.waitForPageToLoad();
		homepage.getHomeLblProduct().waitForPresent(20000);

		// PerfectoUtils.verticalswipe();
		homepage.getHomeLblShoppingList().waitForPresent(5000);
		homepage.getHomeLblShoppingList().click();
		PerfectoUtils.reportMessage("Clicked on My Lists.", MessageTypes.Pass);

		if (mylistpage.getMyListLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to My lists page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to My lists page. Selecting My List from hamburger button.",
					MessageTypes.Pass);

			PerfectoUtils.horizontalswipe();
			androidcommon.getAppHamburger().waitForPresent(1000);
			androidcommon.getAppHamburger().click();

			if (androidcommon.getAppSliderShoppinglist().isPresent()) {
				PerfectoUtils.reportMessage("Clicking on My Lists..", MessageTypes.Pass);
				androidcommon.getAppSliderShoppinglist().click();
				PerfectoUtils.reportMessage("Clicked on My Lists.", MessageTypes.Pass);
			} else {
				PerfectoUtils.verticalswipe(80, 75, 2);
				PerfectoUtils.reportMessage("Clicking on My Lists..", MessageTypes.Pass);
				androidcommon.getAppSliderShoppinglist().click();
				PerfectoUtils.reportMessage("Clicked on My Lists.", MessageTypes.Pass);
			}
		}
	}

	/**
	 * Verify my list page is loaded by verifying the my list page title
	 */
	@QAFTestStep(description = "I verify My List page is displayed")
	public void iVerifyMyListPageIsDisplayed() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.waitForPageToLoad();
		mylistpage.getMyListLblPagetitle().waitForPresent(3000);

		if (mylistpage.getMyListLblPagetitle().isPresent())
			PerfectoUtils.reportMessage("Navigated to My lists page.", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not Navigated to My lists page.", MessageTypes.Fail);

	}

	/**
	 * Verify weekly grovery list is present and click on it
	 */
	@QAFTestStep(description = "I see weekly grocery list in My list page")
	public void iSeeWeeklyGroceryListInMyListPage() {
		MylistTestPage mylist = new MylistTestPage();

		mylist.getMylistsLblWeeklygroceries().verifyPresent();
		mylist.getMylistsLblWeeklygroceries().click();
	}

	/**
	 * Delete some of the available list if we have more than 5 list Click on
	 * the + icon to create new list
	 */
	@QAFTestStep(description = "I click on plus icon to add list")
	public void iClickOnPlusIconToAddList() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.getMyListsImgPlus().waitForPresent(5000);
		mylistpage.getMyListsImgPlus().click();
		PerfectoUtils.reportMessage("Clicked on Plus icon to Create a Shoppinglist.", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I verify the weekly grocery page")
	public void iVerifyTheWeeklyGroceryPage() {
		MylistTestPage mylist = new MylistTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		if (mylist.getMylistsLblWeeklygroceries().isPresent()) {
			PerfectoUtils.reportMessage("Able to see selected ads", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see selected ads", MessageTypes.Fail);
			// Click on selected shopping list
			try {
				weeklygrocery.getShopingListEntryByLable(getBundle().getString("listName")).click();
			} catch (Exception e) {
				PerfectoUtils.getAppiumDriver().scrollToExact(getBundle().getString("listName"));
				weeklygrocery.getShopingListEntryByLable(getBundle().getString("listName")).click();
			}
			PerfectoUtils.reportMessage("Selected list: " + getBundle().getString("listName"), MessageTypes.Pass);

			// verify if selected ingredient is available
			// ArrayList<String> arrlist = new ArrayList<String>
			// (getBundle().getList("inglist"));
			for (Object actualProduct : getBundle().getList("inglist")) {
				String actProduct = actualProduct.toString();
				try {
					weeklygrocery.getShopingListEntryByLable(actProduct).verifyPresent();
					PerfectoUtils.reportMessage("Ingredient " + actProduct + " is available", MessageTypes.Pass);
				} catch (Exception e) {
					try {
						PerfectoUtils.getAppiumDriver().scrollToExact(actProduct);
						PerfectoUtils.reportMessage("Ingredient " + actProduct + " is available", MessageTypes.Pass);
					} catch (Exception f) {
						PerfectoUtils.reportMessage("Ingredient " + actProduct + " is not available",
								MessageTypes.Fail);
					}
				}
			}
		}
	}

	/**
	 * Click on submit button with invalid email address in login popup Verify
	 * the login failure happen with invalid email address and report the status
	 */
	@QAFTestStep(description = "I see error message for invalid password after click on Login/Submit button")
	public void iSeeErrorMessageForInvalidPasswordAfterClickOnLoginSubmitButton() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		LoginpopupTestPage loginpopup = new LoginpopupTestPage();

		/* Clicking on Login button */
		loginpopup.getLoginpopupBtnOverlaylogin().waitForPresent(3000);
		loginpopup.getLoginpopupBtnOverlaylogin().click();

		PerfectoUtils.reportMessage("Toast Message for invalid email is not verified", MessageTypes.Info);

		weeklygrocery.getWgBtnLogIn().waitForPresent(5000);

		if (weeklygrocery.getWgBtnLogIn().isPresent()) {
			PerfectoUtils.reportMessage("Login Failure due to invalid email addess", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Login success due to invalid email addess", MessageTypes.Fail);
		}
	}

	/**
	 * Verify the list 'DeletedListName' is present or not and report the status
	 * 
	 * @param list
	 *            name 'DeletedListName'
	 */
	@QAFTestStep(description = "I see the list name is not deleted in Android")
	public void iSeeTheListNameIsNotDeletedInAndroid() {
		AddtolistTestPage addtolistpage = new AddtolistTestPage();

		addtolistpage.waitForPageToLoad();
		String strDeletedList = getBundle().getPropertyValue("DeletedListName");

		/* Forming the dynamic object */
		boolean isListDisplayed = addtolistpage.getShopingListEntryByLable(strDeletedList).isPresent();
		if (isListDisplayed) {
			PerfectoUtils.reportMessage("List: " + strDeletedList + " is not deleted", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("List: " + strDeletedList + " is deleted", MessageTypes.Fail);
		}
	}

	/**
	 * Report this step not applicable for Android
	 */
	@QAFTestStep(description = "I swipe across the name of a Shopping list and not clicking DELETE button")
	public void iSwipeAcrossTheNameOfAShoppingListAndNotClickingDELETEButton() {

		PerfectoUtils.reportMessage("Step Not Applicable for Android.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for Android
	 */
	@QAFTestStep(description = "I cancel the delete process by clicking on the same list")
	public void ICancelTheDeleteProcessByClickingOnTheSameList() {

		PerfectoUtils.reportMessage("Step Not Applicable for Android.", MessageTypes.Pass);
	}

	/**
	 * Clicks on Cancel button from the Login pop up
	 */
	@QAFTestStep(description = "I click Cancel button on login PopUp and see weekly grocery list in My list page")
	public void iClickCancelButtonOnLoginPopUp() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();

		if (storedetail.getstoredetailsLblCancel().isPresent()) {
			storedetail.getstoredetailsLblCancel().click();
		}

		iSeeWeeklyGroceryListInMyListPage();
	}

	/**
	 * Report this step not applicable for Android
	 */
	@QAFTestStep(description = "I click continue without registering as guest and see weekly grocery list in My list page")
	public void iClickContinueWithoutRegisteringAsGuest() {
		PerfectoUtils.reportMessage("Step Not Applicable for Android.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for Android
	 */
	@QAFTestStep(description = "I see the list name is not deleted in IOS")
	public void iSeeTheListNameIsNotDeletedInIOS() {
		PerfectoUtils.reportMessage("Step Not Applicable for Android.", MessageTypes.Pass);
	}

	/**
	 * Verify and click on the list overflow\edit icon in selected list page
	 */
	@QAFTestStep(description = "I select the Overflow/Edit icon from my list page in Android")
	public void iSelectTheOverflowIconFromMyListPageInAndroid() {
		MylistTestPage mylistpage = new MylistTestPage();

		/* Validating Overview icon and clicking */
		mylistpage.getMylistsIconOverflow().verifyPresent();
		mylistpage.getMylistsIconOverflow().click();
	}

	@QAFTestStep(description = "Verify the Search screen is not visible on selecting Cancel button")
	public void verifyTheSearchScreenIsNotVisibleOnSelectingCancelButton() {
		PerfectoUtils.reportMessage("NA for android.");
	}

	/**
	 * Verify the overflow icon options are displayed
	 */
	@QAFTestStep(description = "I should see the list of options in list details page")
	public void iShouldSeeTheListOfOptionsInListDetailsPage() {
		MylistTestPage mylistpage = new MylistTestPage();
		ListdetailsTestPage listdetail = new ListdetailsTestPage();

		listdetail.getListpageLinkDeleteitem().verifyPresent();
		listdetail.getListpageLinkDeleteallitem().verifyPresent();
		listdetail.getListpageLinkUncheckitem().verifyPresent();
		listdetail.getListpageLinkCopytoanotherlist().verifyPresent();
	}

	/**
	 * Select an UPC specific item from search list which is displayed as second
	 * item If the search result count is less than two, not selecting any item
	 * 
	 * @return ChoosenProduct
	 */
	public void iSelectASpecificItem(int i) {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		int getcnt = wgsearchresult.getWgListSearchlist().size();

		if (getcnt > 2) {
			/*
			 * Click on specific item (2nd item) displays in search result page
			 */
			getBundle().setProperty("ChoosenProduct", wgsearchresult.getWgListSearchlist().get(i).getText());
			wgsearchresult.getWgListSearchlist().get(i).click();
		} else if (getcnt < 2) {
			PerfectoUtils.reportMessage("No Results/Search product is displaying only Generic Items",
					MessageTypes.Fail);
		}
	}

	/**
	 * Click on Plus icon and verify search text is displayed
	 */
	@QAFTestStep(description = "I see Search Field is displayed by clicking on Plus Icon")
	public void iSeeSearchFieldIsDisplayedByClickingOnPlusIcon() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		/* Click on search icon */
		weeklygrocery.getWgBtnPlusaction().waitForPresent(5000);
		weeklygrocery.getWgBtnPlusaction().click();
		PerfectoUtils.reportMessage("Clicked on Plus icon to Add items to list..");

		/* Verifying Search icon text */
		wgsearchresult.getWgLblSearchsrctext().waitForPresent(3000);
		wgsearchresult.getWgLblSearchsrctext().verifyPresent();
	}

	@QAFTestStep(description = "Verify the Searched product is not added to the list")
	public void verifyTheSearchedProductIsNotAddedToTheList() throws Exception {
		MylistTestPage mylistpage = new MylistTestPage();
		WeeklygroceriesTestPage weeklygroceries = new WeeklygroceriesTestPage();

		if (weeklygroceries.getWgImgMenuoverflow().isPresent()) {
			PerfectoUtils.reportMessage("Navigated back to List page.", MessageTypes.Pass);
			PerfectoUtils.reportMessage("Searched Product not added to the list.");
		} else {
			PerfectoUtils.reportMessage("Error occured while navigating back.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I select Delete Item option")
	public void iselectDeleteItemoption() {
		EmailcontentTestPage emailcontent = new EmailcontentTestPage();
		ListdetailsTestPage listdetail = new ListdetailsTestPage();
		MylistTestPage mylistpage = new MylistTestPage();
		AndroidStepDefShoppingList androidstepdefshoppinglist = new AndroidStepDefShoppingList();
		ListdetailsTestPage listdetailsTestPage = new ListdetailsTestPage();
		int itemCount;
		String strItemCount = listdetailsTestPage.getListpageLblShoppingitemcount().getText().replaceAll("Items", "")
				.replaceAll("Item", "").trim();
		System.out.println((strItemCount.replaceAll("Items", "")).replaceAll("Item", ""));
		itemCount = Integer.parseInt(strItemCount);

		if (itemCount > 0) {
			androidstepdefshoppinglist.iSelectTheOverflowIconFromTheActionBar();
			listdetail.getListpageLinkDeleteitem().isPresent();
			listdetail.getListpageLinkDeleteitem().click();
			if (listdetail.getListpageLblPopuptitledeleteallitem().isPresent()) {
				listdetail.getListpageBtnDeleteitempopupok().click();
			}

			listdetail.getListpageLblSelectrowstodelete().isPresent();
			listdetail.getListpageLblItemNameListobj().get(0).click();
			listdetail.getListpageImgDeleteicon().click();
			listdetail.getListpageBtnDeleteitempopupok().click();

			String strnewItemCount = listdetailsTestPage.getListpageLblShoppingitemcount().getText()
					.replaceAll("Items", "").replaceAll("Item", "").trim();
			int itemCount2 = Integer.parseInt(strItemCount);
			if (itemCount > itemCount2) {

				PerfectoUtils.reportMessage("Item is deleted successfully", MessageTypes.Pass);
			}
		} else {
			PerfectoUtils.reportMessage("No items found.", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I cancel the process of deleting element")
	public void icanceltheprocessofdeletingelement() {

		EmailcontentTestPage emailcontent = new EmailcontentTestPage();
		ListdetailsTestPage listdetail = new ListdetailsTestPage();
		MylistTestPage mylistpage = new MylistTestPage();
		AndroidStepDefShoppingList androidstepdefshoppinglist = new AndroidStepDefShoppingList();
		ListdetailsTestPage listdetailsTestPage = new ListdetailsTestPage();
		int itemCount;
		String strItemCount = listdetailsTestPage.getListpageLblShoppingitemcount().getText().replaceAll("Items", "")
				.replaceAll("Item", "").trim();
		System.out.println((strItemCount.replaceAll("Items", "")).replaceAll("Item", ""));
		itemCount = Integer.parseInt(strItemCount);
		if (itemCount > 0) {
			androidstepdefshoppinglist.iSelectTheOverflowIconFromTheActionBar();
			listdetail.getListpageLinkDeleteitem().isPresent();
			listdetail.getListpageLinkDeleteitem().click();
			if (listdetail.getListpageLblPopuptitledeleteallitem().isPresent()) {
				listdetail.getListpageBtnDeleteitempopupok().click();
			}

			listdetail.getListpageLblSelectrowstodelete().isPresent();
			listdetail.getListpageLblItemNameListobj().get(0).click();
			listdetail.getListpageImgDeleteicon().click();
			listdetail.getListpageBtnCancel().click();
			if (!listdetail.getListpageLblPopuptitledeleteallitem().isPresent()) {
				PerfectoUtils.reportMessage("Deletion processed cancelled successfully", MessageTypes.Pass);

			}
		}
	}

	@QAFTestStep(description = "I cancel the process of sending an email")
	public void icanceltheprocessofsendinganemail() {

		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		PerfectoUtils.androiddeviceback();
		if (listdetails.getListpageBtnEmail().isDisplayed()) {
			PerfectoUtils.reportMessage("Email process is cancelled", MessageTypes.Pass);
		}

	}

	@QAFTestStep(description = "I verify that the process is cancelled")
	public void iverifythattheprocessiscancelled() {
		ListdetailsTestPage listdetailspage = new ListdetailsTestPage();
		if (!listdetailspage.getListpageBtnAdd().isPresent()) {
			PerfectoUtils.reportMessage("Copy process cancelled ", MessageTypes.Pass);
		}

	}

	@QAFTestStep(description = "I cancel the process of replacing generic item")
	public void icanceltheprocessofreplacinggenericitem() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		wgsearchresult.getWgLblSearchresultItemname().waitForPresent(10000);
		PerfectoUtils.reportMessage("Clicking Android back option to cancel replace..", MessageTypes.Info);
		PerfectoUtils.androiddeviceback();
		weeklygrocery.getWgListSelectsspecificitem().waitForPresent(10000);
		if (weeklygrocery.getWgListSelectsspecificitem().isPresent()) {
			PerfectoUtils.reportMessage("Replacing generic item process is cancelled", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I cancel the delete process by clicking on the same item name")
	public void icancelthedeleteprocessbyclickingonthesameitemname() {
		PerfectoUtils.reportMessage("NA for Android", MessageTypes.Info);
	}

	@QAFTestStep(description = "I swipe across the name of the first item")
	public void iswipeacrossthenameofthefirstitem() {
		PerfectoUtils.reportMessage("NA for Android", MessageTypes.Info);
	}

	/**
	 * Click device back button from product details page Verify the list item
	 * details page is displayed on back button, from where we navigated to
	 * product details page
	 */
	@QAFTestStep(description = "I see list product details page on clicking device back button")
	public void iSeeListProductDetailsPageOnClickingDeviceBackButton() {
		PdtdetailspagefromlistTestPage productdetails = new PdtdetailspagefromlistTestPage();

		PerfectoUtils.androiddeviceback();

		productdetails.getProductdetailsTxtPagetitle().waitForPresent(10000);
		productdetails.getProductdetailsTxtPagetitle().verifyPresent();

	}

	/**
	 * Verify device navigated back to selected list page by verifying list item
	 * count is not null
	 */
	@QAFTestStep(description = "I see the <List name> page on selecting device back button once")
	public void iSeeTheListNamePageOnSelectingDeviceBackButtonOnce() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();

		String items = null;
		int itemcount = 0;

		PerfectoUtils.androiddeviceback();
		listdetails.getListpageLblShoppingitemcount().waitForPresent(5000);
		listdetails.getListpageLblShoppingitemcount().verifyPresent();
		items = listdetails.getListpageLblShoppingitemcount().getText();

		if (items.contains(getBundle().getString("ShoplistCountItems"))) {
			items = items.replace(getBundle().getString("ShoplistCountItems"), "").trim();
		} else if (items.contains(getBundle().getString("ShoplistCountItem"))) {
			items = items.replace(getBundle().getString("ShoplistCountItem"), "").trim();
		}
		itemcount = Integer.parseInt(items);

		if (itemcount >= 0) {
			PerfectoUtils.reportMessage("The page is navigated to List detail page as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("The page is not navigated to List detail page as expected", MessageTypes.Fail);
		}
	}

	/**
	 * Click device back button from product details page Verify the non empty
	 * list is displayed on back button, from where we navigated to product
	 * details page
	 */
	@QAFTestStep(description = "I see Weekly Groceries page on clicking device back button once")
	public void iSeeWeeklyGroceriesPageOnClickingDeviceBackButtonOnce() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();

		String items = null;
		int itemcount = 0;
		PerfectoUtils.androiddeviceback();
		listdetails.getListpageLblShoppingitemcount().waitForPresent(3000);
		items = listdetails.getListpageLblShoppingitemcount().getText();

		if (items.contains(getBundle().getString("ShoplistCountItems"))) {
			items = items.replace(getBundle().getString("ShoplistCountItems"), "").trim();
		} else if (items.contains(getBundle().getString("ShoplistCountItem"))) {
			items = items.replace(getBundle().getString("ShoplistCountItem"), "").trim();
		}
		itemcount = Integer.parseInt(items);

		if (itemcount >= 0) {
			PerfectoUtils.reportMessage("Weekly Groceries page is displayed successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Weekly Groceries page is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify products with multiple images")
	public void iVerifyProductsWithMultipleImages() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		if (productdetails.getLblPaginationDots().get(0).isPresent()) {
			productdetails.getPdpImgProductimage().verifyPresent();
			PerfectoUtils.reportMessage("Image is present ", MessageTypes.Pass);

			PerfectoUtils.rightSwipe();
			productdetails.getLblPaginationDots().get(0).verifyPresent();
			productdetails.getPdpImgProductimage().verifyPresent();
		} else {
			PerfectoUtils.reportMessage("Pagination dots are not available", MessageTypes.Fail);
		}
	}

}
