package com.heb.automation.common.pages;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class AppcrashhandlerTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "exception.btn.ok")
	private QAFWebElement exceptionBtnOk;
	@FindBy(locator = "exception.lbl.StoreLocError")
	private QAFWebElement exceptionLblStoreLocError;
	@FindBy(locator = "exception.lbl.loginError")
	private QAFWebElement exceptionLblloginError;
	@FindBy(locator = "exception.lbl.continueWithoutStore")
	private QAFWebElement exceptionLblContinueWithoutStore;
	@FindBy(locator = "exception.btn.skipcoupons")
	private QAFWebElement exceptionSkipCoupons;
	@FindBy(locator = "exception.txt.loginrequired")
	private QAFWebElement exceptionTxtLoginrequired;
	@FindBy(locator = "exception.btn.cancel")
	private QAFWebElement exceptionBtnCancel;
	@FindBy(locator = "exception.txt.appcrashmsg")
	private QAFWebElement AppcrashMsg;
	@FindBy(locator = "exception.txt.alertcontent")
	private QAFWebElement AppExceptionMsg;
	@FindBy(locator = "exception.txt.alerttitle")
	private QAFWebElement AppExceptionMsgTitle;
	@FindBy(locator = "exception.lbl.swipetodiscover")
	private QAFWebElement AppExceptionLblSwipetodiscover;
	@FindBy(locator = "exception.btn.close")
	private QAFWebElement AppExceptionBtnClose;
	@FindBy(locator = "exception.txt.re-loginpassword")
	private QAFWebElement ReloginPassword;
	@FindBy(locator = "exception.lbl.re-login")
	private QAFWebElement ReloginTitle;
	@FindBy(locator = "exception.btn.login")
	private QAFWebElement ReloginLoginBtn;
	@FindBy(locator = "exception.txt.re-loginemailid")
	private QAFWebElement ReloginEmailID;
	@FindBy(locator = "exception.lbl.loginrequired")
	private QAFWebElement LoginrequiredPopup;
	@FindBy(locator = "exception.txt.loginemailid")
	private QAFWebElement EnterEmailID;
	@FindBy(locator = "exception.txt.loginpassword")
	private QAFWebElement EnterPassword;
	@FindBy(locator = "exception.btn.submit")
	private QAFWebElement SubmitLogincredentials;
	@FindBy(locator = "exception.lbl.softwareupdate")
	private QAFWebElement SoftwareUpdatePopup;
	@FindBy(locator = "exception.btn.software.updatelater")
	private QAFWebElement SoftwareUpdateLater;
	@FindBy(locator = "exception.lbl.loadingmore")
	private QAFWebElement LblLoadingmore;
	@FindBy(locator = "exception.btn.Allow")
	private QAFWebElement AllowPopup;
	@FindBy(locator = "exception.btn.storeLocatorok")
	private QAFWebElement btnStoreLocatorOK;	
	@FindBy(locator = "exception.lbl.error")
	private QAFWebElement lblError;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getAppExceptionMsgTitle() {
		return AppExceptionMsgTitle;
	}

	public QAFWebElement getAppExceptionMsg() {
		return AppExceptionMsg;
	}

	public void setAppExceptionMsg(QAFWebElement appExceptionMsg) {
		AppExceptionMsg = appExceptionMsg;
	}

	public QAFWebElement getExceptionBtnOk() {
		return exceptionBtnOk;
	}

	public QAFWebElement getAppcrashMsg() {
		return AppcrashMsg;
	}

	public QAFWebElement getExceptionLblloginError() {
		return exceptionLblloginError;
	}

	public QAFWebElement getExceptionLblStoreLocError() {
		return exceptionLblStoreLocError;
	}

	public QAFWebElement getExceptionLblContinueWithoutStore() {
		return exceptionLblContinueWithoutStore;
	}

	public QAFWebElement getExceptionSkipCoupons() {
		return exceptionSkipCoupons;
	}

	public QAFWebElement getExceptionTxtLoginrequired() {
		return exceptionTxtLoginrequired;
	}

	public QAFWebElement getExceptionBtnCancel() {
		return exceptionBtnCancel;
	}

	public QAFWebElement getAppExceptionLblSwipetodiscover() {
		return AppExceptionLblSwipetodiscover;
	}

	public QAFWebElement getAppExceptionBtnClose() {
		return AppExceptionBtnClose;
	}

	public QAFWebElement getReloginPassword() {
		return ReloginPassword;
	}

	public QAFWebElement getReloginTitle() {
		return ReloginTitle;
	}

	public QAFWebElement getReloginLoginBtn() {
		return ReloginLoginBtn;
	}

	public QAFWebElement getReloginEmailID() {
		return ReloginEmailID;
	}

	public QAFWebElement getLoginrequiredPopup() {
		return LoginrequiredPopup;
	}

	public QAFWebElement getEnterEmailID() {
		return EnterEmailID;
	}

	public QAFWebElement getEnterPassword() {
		return EnterPassword;
	}

	public QAFWebElement getSubmitLogincredentials() {
		return SubmitLogincredentials;
	}

	public QAFWebElement getSoftwareUpdatePopup() {
		return SoftwareUpdatePopup;
	}

	public void setSoftwareUpdatePopup(QAFWebElement softwareUpdatePopup) {
		SoftwareUpdatePopup = softwareUpdatePopup;
	}

	public QAFWebElement getSoftwareUpdateLater() {
		return SoftwareUpdateLater;
	}

	public void setSoftwareUpdateLater(QAFWebElement softwareUpdateLater) {
		SoftwareUpdateLater = softwareUpdateLater;
	}

	public QAFWebElement getLblLoadingmore() {
		return LblLoadingmore;
	}

	public QAFWebElement getAllowPopup() {
		return AllowPopup;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getbtnStoreLocatorOK() {
		return btnStoreLocatorOK;
	}

	public QAFWebElement getLblError() {
		return lblError;
	}
}
