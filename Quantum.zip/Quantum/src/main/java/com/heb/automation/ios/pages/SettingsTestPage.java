package com.heb.automation.ios.pages;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SettingsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {


@FindBy(locator = "settings.lbl.beta")
private QAFWebElement settingslblbeta;
@FindBy(locator = "settings.lbl.location")
private QAFWebElement settingslbllocation;
@FindBy(locator = "settings.lbl.never")
private QAFWebElement settingslblnever;
@FindBy(locator = "settings.lbl.whileusingapp")
private QAFWebElement settingslblwhileusingapp;
@FindBy(locator = "settings.txt.settings")
private QAFWebElement settingstxtsettings;


@Override
protected void openPage(PageLocator pageLocator, Object... args) {
}


public QAFWebElement getsettingslblbeta() {
	return settingslblbeta;
}

public QAFWebElement getsettingslblnever() {
	return settingslblnever;
}

public QAFWebElement getsettingslbllocation() {
	return settingslbllocation;
}

public QAFWebElement getsettingslblwhileusingapp() {
	return settingslblwhileusingapp;
}


public QAFWebElement getsettingstxtsettings() {
	return settingstxtsettings;
}
}