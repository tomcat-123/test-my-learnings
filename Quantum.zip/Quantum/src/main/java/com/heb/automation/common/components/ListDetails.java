package com.heb.automation.common.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ListDetails extends QAFWebComponent {

	
	@FindBy(locator = "listpage.btn.checkbox")
	private QAFWebElement listpageBtnCheckbox;
	
	@FindBy(locator = "listpage.lbl.itemname")
	private QAFWebElement listpageLblItemname;
	
	@FindBy(locator = "listpage.txt.shoppinglistquantity")
	private QAFWebElement listpageTxtShoppinglistquantity;


	public QAFWebElement getListpageBtnCheckbox() {
		return listpageBtnCheckbox;
	}
	public QAFWebElement getListpageLblItemname() {
		return listpageLblItemname;
	}
	public QAFWebElement getListpageTxtShoppinglistquantity() {
		return listpageTxtShoppinglistquantity;
	}
	
	public ListDetails(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}
	
}