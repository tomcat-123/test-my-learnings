package com.heb.automation.ios.steps.shoppinglist;

import static com.heb.automation.common.PerfectoUtils.getAppiumDriver;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static com.qmetry.qaf.automation.step.CommonStep.click;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.ShoppinglistResult;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.products.ProductdetailTestPage;
import com.heb.automation.common.pages.products.ProductlandingTestPage;
import com.heb.automation.common.pages.products.ProductsresultlistTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.pages.scanner.ScannerTestPage;
import com.heb.automation.common.pages.shoppinglist.AddtolistTestPage;
import com.heb.automation.common.pages.shoppinglist.ListdetailsTestPage;
import com.heb.automation.common.pages.shoppinglist.LoginpopupTestPage;
import com.heb.automation.common.pages.shoppinglist.MylistTestPage;
import com.heb.automation.common.pages.shoppinglist.PdtdetailspagefromlistTestPage;
import com.heb.automation.common.pages.shoppinglist.SendemailTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriessearchresultTestPage;
import com.heb.automation.common.pages.storelocator.StoredetailsTestPage;
import com.heb.automation.common.steps.shoppinglist.CommonStepDefShoppingList;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.heb.automation.ios.steps.IOSStepdef;
import com.heb.automation.ios.steps.myaccount.IOSStepDefMyAccounts;
import com.heb.automation.ios.steps.products.IOSStepdefproducts;
import com.heb.automation.ios.steps.registeration.IOSStepdefregisteration;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in ShoppingList

	I click on Search to add products field
	I navigate back to Weekly Groceries page
	I validate the properties of Send Email page
	I navigate to Weekly Groceries page
	I should see the error toast message
	I select <List Name> from mylist page
	I validate the displayed <List Name> page
	I see the Scan Receipt page on selecting Scan Receipt option
	I see the Product details page on selecting product from the list
	I see the Scroling selector page on selecting Qty field
	I see the entered notes updated in the Notes field on selecting and entering notes
	I see Weekly Groceries page on clicking device back button
	I select the Overflow/Edit icon from the action bar
	I navigate back to My List page from Registration page
	I select and navigate to first list
	I validate the page properties as a hot user
	I validate the page properties as a cold user
	I validate search products page
	I should see the Please Log In popup
	I should see the added item in the list
	I navigate back to selected list page
	I enter valid email address and click on Send or submit button
	I should see the checkboxes of all items Unchecked
	I select the Search box from list detail page
	I validate the Search Products page
	I see the <List name> page on selecting device back button
	I select Delete All Items option
	I should see the popup to enter list name
	I see the Product details page on selecting specific product from the list
	I see product item details page by clicking on see more details link
	I click the save/add button
	I click on Select Specific Product link
	I select the Item first entry
	I should see the selected Item in the Weekly Groceries page
	I validate the search results page
	I see the Qty field updated on selecting quantity and click on Save button
	I click on Add/Done button
	I select device back button
	I Verify cold user is not able to delete the Weekly Grocery List
	I navigate to Uncheck All Items
	I navigate to Send Email page
	I check off shopping list items
	I should see the checkmark in the checkbox
	I uncheck the Shopping list Items
	I should not see the checkmark in the checkbox
	I see Search Field is displayed by clicking on Search Icon
	I enter valid search term {0}and select Search button in weekly groceries page
	I select a UPC specific item
	I select newly added list name
	I search for product {0} from list details page
	I click on Login/Submit button
	I see Enter Reciept No Pop-up
	I enter the Shopping list name
	I swipe across the name of a Shopping list
	I swipe across the name of the product
	I should not see the product
	I see Add to List popup on selecting Add to List button
	I see toaster message on selecting Add button in Add To List popup
	I verify if ingredients added in selected shopping list
	I verify available products in List Details page
	I should see Copy Items to List popup
	I select the list which haivng item copied
	I enter Reciept Number
	I see List detail page on clicking corresponding list name from My list page
	I navigate back to My Lists page
	I enter invalid Reciept Number
	I should see All items are deleted from list
	I select the Overflow icon from my lists page
	I should see the list of options
	I select delete list option
	I should see My Lists page in Edit mode
	I should see the List name highlighted in red
	I select delete icon
	I should see the Delete Lists popup
	I select the Delete button from delete list popup
	I should not see the list name
	I select Edit List option
	I should see the Rename <Shoping List> popup
	I edit the Shopping List name
	I click the Rename button
	I should not see option to create new list
	I select a list to delete
	I enter existing List name to rename
	I select the first list
	I validate the Weekly Groceries page
	I should see the Search Results page
	I click on plus from action bar
	I verify if all ingredients added in selected shopping list
	I delete all items from weekly groceries shopping list
	I see error message for invalid email after click on Login/Submit button
	I should see the Product which is copied to this list
	I select product from CDP to PDP
	I enter Invalid email address and click on Send/ submit button
	I should see the error popup/ toast message
	I get the product name from list details page
	I change the sender email address and click on Send/ submit button
	I verify if ingredients added in selected shopping list of hot user
	I navigate back to list details page
	I should not see the scanned product in the selected list
	I delete all items from wish list of shopping list
	I navigate to My List page
	I verify My List page is displayed
	I see weekly grocery list in My list page
	I verify the weekly grocery page
	I click on plus icon to add list
	I see error message for invalid password after click on Login/Submit button
	I see the list name is not deleted in Android
	I swipe across the name of a Shopping list and not clicking DELETE button
	I cancel the delete process by clicking on the same list
	I click Cancel button on login PopUp and see weekly grocery list in My list page
	I click continue without registering as guest and see weekly grocery list in My list page
	I see the list name is not deleted in IOS
	I select the Overflow/Edit icon from my list page in Android
	Verify the Search screen is not visible on selecting Cancel button
	I should see the list of options in list details page
	I see Search Field is displayed by clicking on Plus Icon
	Verify the Searched product is not added to the list
	I verify the error popup for invalid scan
	I verify that the process is cancelled
	I cancel the process of sending an email
	I cancel the process of replacing generic item
	I swipe across the name of the first item
	I cancel the delete process by clicking on the same item name
	I select Delete Item option
	I cancel the process of deleting element
	I see list product details page on clicking device back button
	I see the <List name> page on selecting device back button once
	I see Weekly Groceries page on clicking device back button once*/

public class IOSStepdefshopinglist {

	/**
	 * Verify the search field\icon is present and Click on the search
	 * field\icon if available
	 */
	@QAFTestStep(description = "I click on Search to add products field")
	public void iClickOnSearchToAddProductsField() {

		WeeklygroceriesTestPage weeklyGroceries = new WeeklygroceriesTestPage();
		ProductlandingTestPage productlandingpage = new ProductlandingTestPage();

		productlandingpage.waitForPageToLoad();
		if (weeklyGroceries.getWgBtnSearch().isPresent()) {
			weeklyGroceries.getWgBtnSearch().click();
		} else if (productlandingpage.getProductsBtnSearchicon().isPresent()) {
			productlandingpage.getProductsBtnSearchicon().click();
		}
	}

	/**
	 * Navigate back to previous page Verify the Weekly groceries page is
	 * present
	 */
	@QAFTestStep(description = "I navigate back to Weekly Groceries page")
	public void iNavigateBackToWeeklyGroceriesPage() {
		WeeklygroceriesTestPage weeklygroceries = new WeeklygroceriesTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		try {
			ioscommon.getAppBtnBackIOS().waitForVisible(5000);
			ioscommon.getAppBtnBackIOS().click();
			weeklygroceries.getWgTxtSearchproducts().isPresent();
			PerfectoUtils.reportMessage("Success: Navigated back to weekly groceries page", MessageTypes.Pass);
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Error: Not navigated back to weekly groceries page", MessageTypes.Fail);
		}
	}

	/**
	 * Verify various fields sender name, sender email, recipient email, send me
	 * copy & send button in send email template are present
	 */
	@QAFTestStep(description = "I validate the properties of Send Email page")
	public void iValidateThePropertiesOfSendEmailPage() {
		SendemailTestPage sendemail = new SendemailTestPage();

		try {
			sendemail.getSendemailTxtSendername().isPresent();
			sendemail.getSendemailTxtSenderemail().isPresent();
			sendemail.getSendemailTxtRecipientemail().isPresent();
			sendemail.getSendemailBtnSendmecopy().isPresent();
			sendemail.getSendemailBtnSend().isPresent();

			sendemail.getSendemailBtnCancel().click();
			PerfectoUtils.reportMessage("Page validation successful");

		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Page validation not successful");
		}

	}

	/**
	 * Navigate to weekly groceries page Verify the weekly groceries page is
	 * loaded
	 */
	@QAFTestStep(description = "I navigate to Weekly Groceries page")
	public void iNavigateToWeeklyGroceriesPage() {
		MylistTestPage mylistpage = new MylistTestPage();
		WeeklygroceriesTestPage weeklygroceries = new WeeklygroceriesTestPage();

		mylistpage.getMylistsLblWeeklygroceries().waitForPresent(50000);
		mylistpage.getMylistsLblWeeklygroceries().click();
		weeklygroceries.getBtnMore().waitForVisible(3000);
		weeklygroceries.getBtnMore().verifyPresent();
		// Getting count of list items
		getItemCountFromListPage();
	}

	/**
	 * Verify the 'Shopping List Error' toast message and click on the ok button
	 */
	@QAFTestStep(description = "I should see the error toast message")
	public void iShouldSeeTheErrorToastMessage() {
		WeeklygroceriesTestPage weeklygroceries = new WeeklygroceriesTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();

		// Verify error message
		weeklygroceries.waitForPageToLoad();
		weeklygroceries.getShopingListEntryByLable("Shopping List Error").waitForVisible(3000);
		weeklygroceries.getShopingListEntryByLable("Shopping List Error").verifyPresent();
		appcrash.getExceptionBtnOk().verifyPresent();
		appcrash.getExceptionBtnOk().click();
	}

	/**
	 * Look for a selected list from list of lists Select the respective list
	 * 'ListName'
	 * 
	 * @return ListName
	 */
	@QAFTestStep(description = "I select <List Name> from mylist page")
	public void iSelectListNameFromMylistPage() {
		MylistTestPage mylist = new MylistTestPage();
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		String mylistName = "";

		// Clicking on the list name
		int size = mylist.getMyListLblLstNameHotUserItems().size();
		while (size > 5) {
			iSwipeAcrossTheNameOfAShoppingList();
			ioscommon.getAppFooterHomeicon().click();
			ioscommon.getAppFooterShoppinglist().click();
			size = mylist.getMyListLblLstNameHotUserItems().size();
		}
		mylistName = mylist.getMyListLblLstNameHotUserItems().get(size - 1).getText();
		mylist.getMyListLblLstNameHotUserItems().get(size - 1).click();
		PerfectoUtils.reportMessage("Clicked List: " + mylistName + " in My List page ");

		// Comparing the list name with list details page title
		listDetailspage.getListpageLblPagetitle().waitForVisible(3000);
		String pageTitle = listDetailspage.getListpageLblPagetitle().getText();

		if (pageTitle.equals(mylistName)) {
			PerfectoUtils.reportMessage("List Details page if List Name: " + mylistName + "  is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("List Details page if List Name: " + mylistName + "  is not displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Verify the list details page sections more & back options are present in
	 * selected list Click on search icon and verify scan product, scan receipt,
	 * search text & back option are present in selected list
	 */
	@QAFTestStep(description = "I validate the displayed <List Name> page")
	public void iValidateTheDisplayedListNamePage() {
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();

		ioscommonpage.getAppBtnBackIOS().verifyPresent();
		listDetailspage.getListpageBtnMore().verifyPresent();
		listDetailspage.getBtnSearchicon().click();
		listDetailspage.getListpageTxtSearch().verifyPresent();
		listDetailspage.getPageLinkScanproduct().verifyPresent();
		listDetailspage.getListpageLinkScanreciept().verifyPresent();
		ioscommonpage.getAppBtnBackIOS().click();
	}

	/**
	 * Selecting Scan receipt from list details search option Verify scan
	 * receipt page is displayed Handle access camera popup is displayed and
	 * allow
	 */
	@QAFTestStep(description = "I see the Scan Receipt page on selecting Scan Receipt option")
	public void iSeeTheScanReceiptPageOnSelectingScanReceiptOption() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		listDetailspage.getListpageLinkScanreciept().click();
		try {
			weeklygrocery.waitForPageToLoad();
			if (ioscommon.getScanPopupEnablecamera().isPresent()
					&& ((ioscommon.getScanPopupEnablecamera().getAttribute("hidden")).equals("false"))) {
				PerfectoUtils.reportMessage("Camera is not enabled for HEB app in this device", MessageTypes.Info);
				ioscommon.getScanBtnOkEnablecamera().click();
			} else {
				ioscommon.getScanreceiptBtnEnterreceiptnumber().waitForVisible(5000);
				ioscommon.getScanreceiptBtnEnterreceiptnumber().verifyPresent();
			}
		} catch (Exception e1) {
			ioscommon.getScanreceiptBtnEnterreceiptnumber().waitForVisible(5000);
			ioscommon.getScanreceiptBtnEnterreceiptnumber().verifyPresent();
		}
	}

	/**
	 * Select a generic product available in list Verify the product is generic
	 * item and Click on the product to navigate to product details page If
	 * products not available in list do the following: Verify search text is
	 * displayed on clicking search icon Enter valid search term
	 * 'products.productname'and search Select first item from search results
	 * and add to list Then click on the added product to navigate to product
	 * details page
	 * 
	 * @param products.productname
	 * @throws Exception
	 */
	@QAFTestStep(description = "I see the Product details page on selecting product from the list")
	public void iSeeTheProductDetailsPageOnSelectingProductFromTheList() throws Exception {

		PdtdetailspagefromlistTestPage productdetails = new PdtdetailspagefromlistTestPage();
		ListdetailsTestPage listdetailspage = new ListdetailsTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		IOSStepdefshopinglist iosStepDefShopList = new IOSStepdefshopinglist();

		int itemcount = 0;
		String product = ConfigurationManager.getBundle().getString("products.productname");
		int intListSize = 0;
		boolean genericItem = false;
		String itemName1 = null;

		if (!listdetailspage.getListpageLblShoppingitemcount().isPresent()) {
			PerfectoUtils.reportMessage("No Items are present. Needs to be added");
		} else {
			itemcount = listdetailspage.getListpageCellShoppingitem().size();
			if (itemcount > 0) {
				intListSize = weeklygrocery.getWgListItemlist().size();
				System.out.println("size:" + intListSize);

				for (int i = 1; i <= intListSize; i++) {
					ShoppinglistResult product1 = weeklygrocery.getWgListItemlist().get(i - 1);
					if (product1.getWgTxtShoppinglistquantity().getText().contains("Qty")
							|| product1.getWgTxtShoppinglistquantity().getText().contains("QTY")) {
						System.out.println(product1);
						itemName1 = weeklygrocery.getShopingListitemNameByLable(i).getText();
						System.out.println(itemName1);
						if ((product1.getWgListSelectsspecificitem().isPresent())) {
							PerfectoUtils.reportMessage("Generic Item is found", MessageTypes.Pass);
							weeklygrocery.getShopingListitemNameByLable(i).click();
							genericItem = true;
							break;
						}
					}
				}
			}
		}

		if (!genericItem) {
			iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
			iEnterValidSearchTermAndSelectSearchButtonInWeeklyGroceriesPage(product);
			iosStepDefShopList.iShouldSeeTheSearchResultsPage();
			iSelectTheItemFirstEntry();

			// select product from list detail page
			PerfectoUtils.reportMessage("Generic Item is Added: " + product, MessageTypes.Pass);
			weeklygrocery.getShopingListEntryByLable(product).verifyPresent();
			weeklygrocery.getShopingListEntryByLable(product).click();
			itemName1 = product;
		}

		productdetails.getProductdetailsEdtNotes().waitForPresent(50000);
		productdetails.getProductdetailsTxtPagetitle().waitForPresent(10000);
		String productName = productdetails.getProductdetailsTxtPagetitle().getText();
		productdetails.getProductdetailsTxtPagetitle().waitForVisible(10000);
		if (itemName1.equals(productName)) {
			PerfectoUtils.reportMessage("The Product details page title is displayed as product name as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("The Product details page title is not displayed as product name", MessageTypes.Fail);
		}
	}

	/**
	 * Click on the product Qty field in product details page
	 */
	@QAFTestStep(description = "I see the Scroling selector page on selecting Qty field")
	public void iSeeTheScrolingSelectorPageOnSelectingQtyField() {
		PdtdetailspagefromlistTestPage productdetails = new PdtdetailspagefromlistTestPage();

		productdetails.getProductdetailsTxtProductquantity().waitForVisible(15000);
		productdetails.waitForPageToLoad();
		productdetails.getProductdetailsTxtProductquantity().click();
		productdetails.waitForPageToLoad();
	}

	/**
	 * Click on the notes section and clear already available notes Enter the
	 * new notes(not null) in the notes section Verify the new notes get
	 * displayed
	 * 
	 * @param WeeklyGroceries.product.Notes
	 */
	@QAFTestStep(description = "I see the entered notes updated in the Notes field on selecting and entering notes")
	public void iSeeTheEnteredNotesUpdatedInTheNotesFieldOnSelectingAndEnteringNotes() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		PdtdetailspagefromlistTestPage productdetails = new PdtdetailspagefromlistTestPage();

		String notes = ConfigurationManager.getBundle().getString("WeeklyGroceries.product.Notes");
		String getNotes = null;

		if (!notes.equals("")) {
			productdetails.getProductdetailsEdtNotes().click();
			productdetails.getProductdetailsEdtNotes().sendKeys(notes);

			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "Done");
			String result1 = (String) listdetails.getTestBase().getDriver().executeScript("mobile:text:find", params1);

			if (result1.equals("true")) {
				listdetails.getTestBase().getDriver().executeScript("mobile:text:select", params1);
			}

			getNotes = productdetails.getProductdetailsEdtNotes().getText();
			if (!getNotes.equals("")) {
				PerfectoUtils.reportMessage("Notes Fields is updated as expected", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Notes Fields is Empty", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("The parameter value of notes is empty", MessageTypes.Fail);
		}
	}

	/**
	 * Click device back button from product details page Verify the non empty
	 * list is displayed on back button, from where we navigated to product
	 * details page
	 */
	@QAFTestStep(description = "I see Weekly Groceries page on clicking device back button")
	public void iSeeWeeklyGroceriesPageOnClickingDeviceBackButton() {
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();
		MylistTestPage mylist = new MylistTestPage();

		ioscommonpage.getAppBtnBackIOS().verifyPresent();
		ioscommonpage.getAppBtnBackIOS().click();

		mylist.getMylistsLblWeeklygroceries().waitForVisible(5000);

		String getPageTitle = mylist.getMylistsLblWeeklygroceries().getText();
		if (getPageTitle.equals("Weekly Grocery List")) {
			PerfectoUtils.reportMessage("Weekly Groceries page is displayed successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Weekly Groceries page is not displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Verify and click on the list overflow\edit icon in selected list page
	 */
	@QAFTestStep(description = "I select the Overflow/Edit icon from the action bar")
	public void iSelectTheOverviewIconFromTheActionBar() {
		ListdetailsTestPage listDetailsPage = new ListdetailsTestPage();

		listDetailsPage.getListpageBtnMore().waitForVisible(5000);
		listDetailsPage.getListpageBtnMore().click();
	}

	/**
	 * Navigate back to previous page that is My list page using skip and
	 * continue as guest button
	 */
	@QAFTestStep(description = "I navigate back to My List page from Registration page")
	public void iNavigateBackToMyListPageFromRegistrationPage() {
		IOSStepdefregisteration iosregistration = new IOSStepdefregisteration();

		iosregistration.iClickSkipAndContinueAsGuest();
	}

	/**
	 * Click on first available list Return if the list is empty
	 */
	@QAFTestStep(description = "I select and navigate to first list")
	public static void iSelectAndNavigateToFirstList() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.getMylistsLblWeeklygroceries().waitForNotVisible(5000);
		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		List<QAFWebElement> items = mylistpage.getMyListLblLstNameHotUserItems();

		// Clicks on First shopping list
		items.get(items.size() - 1).waitForPresent(5000);
		items.get(items.size() - 1).verifyPresent();
		items.get(items.size() - 1).click();
		mylistpage.waitForPageToLoad();

		// Getting count of items available
		getItemCountFromListPage();
	}

	/**
	 * Verify list page fields like + icon, Page title, list name arrow icon as
	 * hot user And check list names are not empty
	 */
	@QAFTestStep(description = "I validate the page properties as a hot user")
	public void iValidateThePagePropertiesforHotUser() {
		MylistTestPage myList = new MylistTestPage();

		myList.getMyListLblPagetitle().verifyPresent();
		myList.getMyListsImgPlus().verifyPresent();

		// Iterating through all the displayed list names
		for (QAFWebElement temp : myList.getMyListLblLstNameHotUserItems()) {
			String strListName = temp.getText();

			// Validating the list name is not empty
			if (!strListName.isEmpty()) {
				PerfectoUtils.reportMessage("List: " + strListName + " is displayed", MessageTypes.Pass);
				Boolean isArrowPresent = myList.getMyListLblListIconArrowByLable(strListName).isPresent();

				// Validating the arrow icon presence
				if (isArrowPresent) {
					PerfectoUtils.reportMessage("List: " + strListName + " is displayed with arrow icon", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("List: " + strListName + " is displayed without arrow icon", MessageTypes.Fail);
				}

			} else {
				PerfectoUtils.reportMessage("Empty list name is displayed", MessageTypes.Fail);
			}
		}
	}

	/**
	 * Verify list page fields like Page title, list name arrow icon, Register
	 * button, login button as cold user And check Weekly grocery list is
	 * available
	 */
	@QAFTestStep(description = "I validate the page properties as a cold user")
	public void iValidateThePagePropertiesAsColdUser() {
		MylistTestPage myList = new MylistTestPage();

		try {
			if (myList.getMyListLblPagetitle().verifyPresent() && myList.getMyListsBtnRegister().verifyPresent()
					&& myList.getMylistsBtnLogin().verifyPresent()
					&& myList.getMylistsLblWeeklygroceries().verifyPresent()) {
				PerfectoUtils.reportMessage("Page validation successful", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Page validation not successful", MessageTypes.Fail);
			}
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Page validation not successful", MessageTypes.Fail);
		}
	}

	/**
	 * Verify the fields scan name & cancel button in search page
	 */
	@QAFTestStep(description = "I validate search products page")
	public void iValidateSearchProductsPage() {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		wgsearchresult.getWgTxtSearchresultScanname().verifyPresent();
		wgsearchresult.getWgBtnSearchresultCancel().verifyPresent();
	}

	/**
	 * Verify the login popup is present with cancel, login buttons
	 */
	@QAFTestStep(description = "I should see the Please Log In popup")
	public void iShouldSeeThePleaseLogInPopup() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.waitForPageToLoad();
		mylistpage.getMyListsBtnCancel().waitForVisible(5000);

		// Validation of 'Please Log In' overlay elements
		mylistpage.getMyListLblTitlePleaseLogIn().verifyPresent();
		mylistpage.getMyListLblToCreateMultipleLstLogin().verifyPresent();
		mylistpage.getMyListsBtnCancel().verifyPresent();
		mylistpage.getMylistsBtnLogin().verifyPresent();
	}

	/**
	 * Verify chosen product 'ChoosenProduct' available in run time in available
	 * in the list Compares each item name in list with chosen item and return
	 * the result
	 * 
	 * @param ChoosenProduct
	 */
	@QAFTestStep(description = "I should see the added item in the list")
	public void iShouldSeeTheSelectedItemInTheSelectedListPage() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		String strPdtName = null;

		// Validate if selected item is listed in selected list detail page
//		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		strPdtName = getBundle().getString("ChoosenProduct");

		// Getting the object name with dynamic value
		if (weeklygrocery.getShopingListEntryByLable(strPdtName).isPresent()) {
			PerfectoUtils.reportMessage("Added item: " + strPdtName + " is present in list details page", MessageTypes.Pass);
		} else {
			try {
				IOSStepdef.scrollToElement(strPdtName);
				weeklygrocery.getShopingListEntryByLable(strPdtName).waitForPresent(5000);
			} catch (Exception e) {
				PerfectoUtils.getAppiumDriver().scrollTo(strPdtName);
			}
		}
	}

	/**
	 * Navigate back by selecting Cancel button
	 */
	@QAFTestStep(description = "I navigate back to selected list page")
	public void iNavigateBackToSelectedListPage() {
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();

		// click on device back button
		listDetailspage.getListpageBtnCancel().waitForVisible(5000);
		listDetailspage.getListpageBtnCancel().click();
	}

	/**
	 * Enter user email id in recipient email address field and Click in Send
	 * email button Verify Send email button is not present after clicking
	 * 
	 * @param default.user.email
	 */
	@QAFTestStep(description = "I enter valid email address and click on Send or submit button")
	public void iEnterValidEmailAddressAndClickOnSendSubmitButton() {
		SendemailTestPage sendemail = new SendemailTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();

		String recipientEmail = ConfigurationManager.getBundle().getString("default.user.email");

		sendemail.getSendemailTxtRecipientemail().waitForPresent(4000);
		sendemail.getSendemailTxtRecipientemail().click();

		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys("");
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(recipientEmail);

		PerfectoUtils.reportMessage("Entered Email: " + recipientEmail + " ");

		// Hide Keyboard
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");
		Object result1 = sendemail.getTestBase().getDriver().executeScript("mobile:text:select", params1);

		sendemail.getSendemailBtnSubmit().click();
		PerfectoUtils.reportMessage("Clicked Sumbit");

		if (appcrash.getbtnStoreLocatorOK().isPresent()) {
			appcrash.getbtnStoreLocatorOK().click();
		}
	}

	/**
	 * Verify checkboxes are all unchecked and return the status
	 */
	@QAFTestStep(description = "I should see the checkboxes of all items Unchecked")
	public void iShouldSeeTheCheckboxesOfAllItemsUnchecked() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();

		boolean checkedOffStatus = false;
		checkedOffStatus = listdetails.getListpageLblCheckedOff().isPresent();

		if (!checkedOffStatus) {
			PerfectoUtils.reportMessage("Checkboxes of all items have been Unchecked.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Checkboxes of all items have not been Unchecked.", MessageTypes.Fail);
		}
	}

	/**
	 * Verify search icon & search box is available in list and click on it
	 */
	@QAFTestStep(description = "I select the Search box from list detail page")
	public void iSelectTheSearchBoxFromListDetailPage() {
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();

		// select the search icon
		listDetailspage.getBtnSearchicon().verifyPresent();
		listDetailspage.getBtnSearchicon().click();
		// Clicking on search box
		listDetailspage.getListpageTxtSearch().verifyPresent();
		listDetailspage.getListpageTxtSearch().click();
	}

	/**
	 * Verify different sections such as cancel button, scan product and scan
	 * receipt options in search products page
	 */
	@QAFTestStep(description = "I validate the Search Products page")
	public void iValidateTheSearchProductsPage() {
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();

		listDetailspage.getListpageBtnCancel().verifyPresent();
		listDetailspage.getListpageLinkScanreciept().verifyPresent();
		ioscommonpage.getScanTxtScanproduct().verifyPresent();
	}

	/**
	 * Verify device navigated back to selected list page by clicking cancel
	 * button and verifying list search icon
	 */
	@QAFTestStep(description = "I see the <List name> page on selecting device back button")
	public void iSeeTheListNamePageOnSelectingDeviceBackButton() {
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();

		if (listDetailspage.getListpageBtnCancel().isPresent()) {
			listDetailspage.getListpageBtnCancel().click();
		} else if (ioscommonpage.getAppBtnBackIOS().isPresent()) {
			ioscommonpage.getAppBtnBackIOS().click();
		}

		if (listDetailspage.getBtnSearchicon().isPresent()) {
			PerfectoUtils.reportMessage("List Details Page is dispalyed successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("List Details Page is not displayed", MessageTypes.Fail);
		}

	}

	/**
	 * Perform Delete all item action in list and report
	 */
	@QAFTestStep(description = "I select Delete All Items option")
	public void iSelectDeleteAllItemsOption() {
		ListdetailsTestPage listdetail = new ListdetailsTestPage();

		// Validating DeleteAllItem and clicking
		if (listdetail.getListpageLinkDeleteallitem().isPresent()) {
			listdetail.getListpageLinkDeleteallitem().click();
			PerfectoUtils.reportMessage("item deleted", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Delete all item is not avaible", MessageTypes.Fail);
		}
	}

	/**
	 * Verify popup to enter the list name is displayed when we click + icon
	 */
	@QAFTestStep(description = "I should see the popup to enter list name")
	public void iShouldSeeThePopupToEnterListName() {
		MylistTestPage mylistpage = new MylistTestPage();

		try {
			if ((mylistpage.getMylistslblCreateShoppingList().isPresent())
					&& ((mylistpage.getMylistslblCreateShoppingList().getAttribute("hidden")).equals("false"))) {
				PerfectoUtils.reportMessage("Can see Create Shopping List Pop-up");
			}
		} catch (Exception e) {
			mylistpage.getMyListsImgPlus().waitForPresent(5000);
			mylistpage.getMyListsImgPlus().click();
		}
		mylistpage.getMylistslblCreateShoppingList().waitForVisible(5000);
		mylistpage.getMylistslblCreateShoppingList().verifyPresent();
	}

	/**
	 * Click on a generic item name available in the list If items not available
	 * in list, add item to list and click on the added item
	 */
	@QAFTestStep(description = "I see the Product details page on selecting specific product from the list")
	public void iSeeTheProductDetailsPageOnSelectingSpecificProductFromTheList() throws InterruptedException {
		ListdetailsTestPage listdetailspage = new ListdetailsTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		MylistTestPage mylistpage = new MylistTestPage();

		boolean specificItem = false;
		String ProductName, strItemCount;
		int intListSize = 0;

		if (listdetailspage.getListpageLblShoppingitemcount().getAttribute("hidden").equals("false")) {
			strItemCount = listdetailspage.getListpageLblShoppingitemcount().getText().replace(" Items", "")
					.replace(" Item", "");
		} else {
			strItemCount = listdetailspage.getLblHcitemcount().getText().replace("Items", "").replace("Item", "")
					.trim();
		}

		// Check the count of items listed
		if (strItemCount.equalsIgnoreCase("0")) {
			PerfectoUtils.reportMessage("No Items are present. Needs to be added");

			// if items are not found, then search and add specific item
			iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
			iEnterValidSearchTermAndSelectSearchButtonInWeeklyGroceriesPage(
					getBundle().getString("products.productname"));
			iShouldSeeTheSearchResultsPage();
			iSelectAUPCSpecificItem();
			specificItem = true;
		}

		// if items are not found, then search and add specific item
		if (!specificItem) {
			if (mylistpage.getMylistsLblWeeklygroceries().isPresent()) {
				mylistpage.getMylistsLblWeeklygroceries().click();
			}
			intListSize = weeklygrocery.getWgListItemlist().size();
			// Search for the selected item and click its specific item link
			// (child element)
			for (int i = 1; i <= intListSize; i++) {
				ShoppinglistResult product = weeklygrocery.getWgListItemlist().get(i - 1);
				ProductName = weeklygrocery.getShopingListitemNameByLable(i).getText();
				if (product.getWgListSelectsspecificitem().isPresent()) {
					PerfectoUtils.reportMessage("Specific Item is found", MessageTypes.Pass);
					weeklygrocery.getShopingListitemNameByLable(i).waitForVisible(5000);
					weeklygrocery.getShopingListitemNameByLable(i).click();
					specificItem = true;
					break;
				}
			}
		} else {
			// select a specific product from list details page
			int intListSize1 = weeklygrocery.getWgListItemlist().size();
			// Searching for selected item in Weekly groceries page
			for (int i = 1; i <= intListSize1; i++) {
				weeklygrocery.getShopingListitemNameByLable(i).waitForVisible(3000);
				String productName = weeklygrocery.getShopingListitemNameByLable(i).getText();
				if ((productName.toLowerCase().trim())
						.contains(getBundle().getString("products.productname").toLowerCase())) {
					weeklygrocery.getShopingListitemNameByLable(i).waitForVisible(5000);
					weeklygrocery.getShopingListitemNameByLable(i).click();
					break;
				}
			}
		}
	}

	/**
	 * Verify see more details section in product details On clicking more
	 * details, verify PDP page is displayed
	 */
	@QAFTestStep(description = "I see product item details page by clicking on see more details link")
	public void iSeeProductItemDetailsPageByClickingOnSeeMoreDetailsLink() {
		PdtdetailspagefromlistTestPage pdtdetails = new PdtdetailspagefromlistTestPage();
		ProductdetailTestPage PDPPage = new ProductdetailTestPage();

		// verify see more details link and click on it
		String strPageTitle = null;
		pdtdetails.getProductdetailsLblMoredetails().verifyPresent();
		pdtdetails.getProductdetailsLblMoredetails().click();

		// Validate if PDP page is opened
		PDPPage.getPdpTxtPagetitle().waitForPresent(1000);
		strPageTitle = PDPPage.getPdpTxtPagetitle().getText();
		PDPPage.getPdpTxtPagetitle().verifyPresent();
		PerfectoUtils.reportMessage("Page Title of PDP page:" + strPageTitle);
	}

	/**
	 * Click on Save\Add button and wait for my list page to visible
	 */
	@QAFTestStep(description = "I click the save/add button")
	public void iClickTheAddButton() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.getMylistsBtnadd().click();
		mylistpage.waitForPageToLoad();

		mylistpage.getMyListLblPagetitle().waitForVisible(5000);
		mylistpage.getMyListLblPagetitle().verifyPresent();
	}

	/**
	 * Search for already added product and click on it
	 * 
	 * @param ChoosenProduct
	 */
	@QAFTestStep(description = "I click on Select Specific Product link")
	public void iClickOnSelectSpecificProductLink() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		// click on Specific Product link
		int intListSize = weeklygrocery.getWgListItemlist().size();
		getItemCountFromListPage();

		// Search for the selected item and click its specific item link (child
		// element)
		for (int i = 1; i <= intListSize; i++) {
			ShoppinglistResult product = weeklygrocery.getWgListItemlist().get(i - 1);
			if ((weeklygrocery.getShopingListitemNameByLable(i).getText())
					.equalsIgnoreCase(getBundle().getString("productName"))) {
				product.getWgListSelectsspecificitem().click();
				break;
			}
		}
		wgsearchresult.waitForPageToLoad();
	}

	/**
	 * Select the first entry(product link) from search results
	 * 
	 * @return ChoosenProduct
	 */
	@QAFTestStep(description = "I select the Item first entry")
	public void iSelectTheItemFirstEntry() {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		// Click on first search item
		wgsearchresult.getShopingListItemEntryByLable(getBundle().getString("productName")).waitForPresent(4000);
		wgsearchresult.getShopingListItemEntryByLable(getBundle().getString("productName")).click();
		getBundle().setProperty("ChoosenProduct", getBundle().getString("productName"));
		wgsearchresult.waitForPageToLoad();
	}

	/**
	 * Verify the select item 'productName' in available items in weekly grocery
	 * page
	 * 
	 * @param 'productName'
	 */
	@QAFTestStep(description = "I should see the selected Item in the Weekly Groceries page")
	public void iShouldSeeTheSelectedItemInTheWeeklyGroceriesPage() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		// Validate if selected item is listed in Weekly Groceries page
		int intListSize = weeklygrocery.getWgListItemlist().size();

		// getBundle().setProperty("ItemCount", intListSize);
		getItemCountFromListPage();
		int actualSize = intListSize - 1;

		// Searching for selected item in Weekly groceries page
		for (int i = 1; i <= actualSize; i++) {

			if ((weeklygrocery.getShopingListitemNameByLable(i).getText())
					.equalsIgnoreCase(getBundle().getString("productName"))) {
				weeklygrocery.getShopingListitemNameByLable(i).verifyVisible();
				PerfectoUtils.reportMessage("Selected product is displayed in Weekly Groceries page", MessageTypes.Pass);
				break;
			}
		}
	}

	/**
	 * Verify search result page is displayed by verifying the item name contain
	 * search term 'productName'
	 * 
	 * @param 'productName'
	 */
	@QAFTestStep(description = "I validate the search results page")
	public void iValidateTheSearchResultsPage() {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();
		wgsearchresult.getWgBtnSearchresultCancel().verifyPresent();

		// check if item name contains searched product name
		if (wgsearchresult.getWgLblSearchresultItemname().isPresent()) {
			String itemName1 = wgsearchresult.getWgLblSearchresultItemname().getText();
			if ((itemName1.toLowerCase()).contains(getBundle().getString("productName").toLowerCase())) {
				PerfectoUtils.reportMessage("Serached item is listed in Results page", MessageTypes.Pass);
			}
		}
	}

	/**
	 * Fetch the already displayed product Qty in product details page Update
	 * the new Qty for product Save the changes Verify the new updated Qty is
	 * displayed
	 */
	@QAFTestStep(description = "I see the Qty field updated on selecting quantity and click on Save button")
	public void iSeeTheQtyFieldUpdatedOnSelectingQuantityAndClickOnSaveButton() {
		PdtdetailspagefromlistTestPage productdetails = new PdtdetailspagefromlistTestPage();
		String strQuantity = null, strUpdateQuantity = null;
		int intQuanity = 0;

		productdetails.getProductdetailsTxtProductquantity().clear();
		strQuantity = productdetails.getProductdetailsTxtProductquantity().getText();
		intQuanity = Integer.parseInt(strQuantity);
		strUpdateQuantity = Integer.toString(intQuanity + 1);

		productdetails.getProductdetailsTxtProductquantity().sendKeys(strUpdateQuantity);

		int actQty = Integer.parseInt(strUpdateQuantity);
		int expQty = Integer.parseInt(productdetails.getProductdetailsTxtProductquantity().getText());

		if (actQty == expQty) {
			PerfectoUtils.reportMessage("Quantity field is displayed as selected quantity", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Quantity field is not displayed as selected quantity", MessageTypes.Fail);
		}
		PerfectoUtils.reportMessage("Quantity field is updated", MessageTypes.Pass);
	}

	/**
	 * Click on Done\Add button in the add to list popup
	 */
	@QAFTestStep(description = "I click on Add/Done button")
	public void iClickOnAddDoneButton() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		// Clicking on Done button
		ioscommon.getAddtolistBtnDone().waitForPresent(5000);
		ioscommon.getAddtolistBtnDone().click();
		PerfectoUtils.reportMessage("Clicked on Done button", MessageTypes.Pass);
	}

	/**
	 * Click device back button
	 */
	@QAFTestStep(description = "I select device back button")
	public void iSelectDeviceBackButton() {
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();

		// Clicking on Device back button
		if (ioscommonpage.getAppBtnBackIOS().isPresent()) {
			ioscommonpage.getAppBtnBackIOS().waitForPresent(8000);
			ioscommonpage.getAppBtnBackIOS().click();
			PerfectoUtils.reportMessage("Clicked on Back button..");
		} else {
			PerfectoUtils.reportMessage("back button not found.", MessageTypes.Info);
		}
	}

	/**
	 * Verify user not able to delete weekly groceries list by detecting its
	 * presence
	 */
	@QAFTestStep(description = "I Verify cold user is not able to delete the Weekly Grocery List")
	public void iVerifyColdUserIsNotAbleToDeleteTheWeeklyGroceryList() {
		ListdetailsTestPage listdetailspage = new ListdetailsTestPage();

		String strPageTitle = listdetailspage.getListpageLblPagetitle().getText();
		if (strPageTitle.equalsIgnoreCase("Weekly Grocery List")) {
			PerfectoUtils.reportMessage("User is not able to delete the Weekly Grocery List", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not to navigate to Weekly Grocery List", MessageTypes.Pass);
		}
	}

	/**
	 * Check off the first item in list if the items are available If list is
	 * empty add item to list by searching 'products.productname' and then check
	 * off the first item
	 * 
	 * @param products.productname
	 */
	@QAFTestStep(description = "I navigate to Uncheck All Items")
	public void iNavigateToUncheckAllItems() throws InterruptedException {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		WeeklygroceriesTestPage wGroceries = new WeeklygroceriesTestPage();

		int itemCount = 0, itemCheckoffCount = 0;
		String strItemCount = null, strItemCheckoffCount = null;
		String product = ConfigurationManager.getBundle().getString("products.productname");

		// Adding products to shopping list, if the list is empty.

		String count = listdetails.getListpageLblShoppingitemcount().getText();

		if (listdetails.getListpageLblShoppingitemcount().getAttribute("hidden").equals("false")) {
			strItemCount = listdetails.getListpageLblShoppingitemcount().getText().replace(" Items", "")
					.replace(" Item", "");
		} else {
			strItemCount = listdetails.getLblHcitemcount().getText().replace("Items", "").replace("Item", "").trim();
		}
		itemCount = Integer.parseInt(strItemCount);

		if (itemCount == 0) {
			iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
			iEnterValidSearchTermAndSelectSearchButtonInWeeklyGroceriesPage(product);
			iShouldSeeTheSearchResultsPage();
			iSelectTheItemFirstEntry();
			listdetails.getListpageLblItemname().waitForVisible(5000);
			listdetails.getLblHcitemcount().waitForPresent(3000);
			strItemCount = listdetails.getLblHcitemcount().getText().replaceAll("Items", "").replaceAll("Item", "")
					.trim();
			itemCount = Integer.parseInt(strItemCount);

		}

		strItemCheckoffCount = listdetails.getListpageLblShoppingitemcheckoffcount().getText()
				.replaceAll("Checked Off", "").trim();
		itemCheckoffCount = Integer.parseInt(strItemCheckoffCount);

		// Checking the check box of the first non- specific Item, if no items
		// are checked off.
		if (itemCheckoffCount == 0) {
			List<QAFWebElement> items = wGroceries.getWgChkShoppingitemList();
			items.get(items.size() - 1).click();
		}

		strItemCheckoffCount = listdetails.getListpageLblShoppingitemcheckoffcount().getText()
				.replaceAll("Checked Off", "").trim();

		itemCheckoffCount = Integer.parseInt(strItemCheckoffCount);

		if (itemCheckoffCount != 0) {
			PerfectoUtils.reportMessage("Checked off item successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Check off item is failed", MessageTypes.Fail);
		}

		// Clicks on Edit Icon from Action bar to select the Uncheck all Items
		// option.
		if ((itemCount != 0) && (itemCheckoffCount != 0)) {
			listdetails.getListpageBtnMore().waitForPresent(5000);
			listdetails.getListpageBtnMore().click();
		} else {
			PerfectoUtils.reportMessage("Either Items count or Check off count is not zero. please check and confirm.",
					MessageTypes.Fail);
		}
	}

	/**
	 * Click in email option from list page when list is not empty from more
	 * option If list is empty, search for a keyword, select UPC specific item,
	 * add to list and then click send email option
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I navigate to Send Email page")
	public void iNavigateToSendEmailPage() throws InterruptedException {
		ListdetailsTestPage listdetailspage = new ListdetailsTestPage();
		IOSStepdefshopinglist iosStepDefShopList = new IOSStepdefshopinglist();
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();

		boolean boolShopItemCntIsDisplayed = listdetailspage.getListpageLblShoppingitemcount().isPresent();
		if (!boolShopItemCntIsDisplayed) {

			iosStepDefShopList.iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
			iosStepDefShopList.iSearchForProductFromListDetailsPage("milk");
			iosStepDefShopList.iShouldSeeTheSearchResultsPage();
			iosStepDefShopList.iSelectAUPCSpecificItem();
			iosStepDefShopList.iShouldSeeTheSelectedItemInTheSelectedListPage();
			ioscommonpage.getAppFooterHomeicon().waitForPresent(3000);
		}

		listdetailspage.getListpageBtnMore().click();
		PerfectoUtils.reportMessage("Clicked Edit button from List Details page");

		listdetailspage.getListpageBtnEmail().waitForPresent(5000);
		listdetailspage.getListpageBtnEmail().click();
		PerfectoUtils.reportMessage("Clicked Email share from List Details page");
	}

	/**
	 * Check off an item in list if it is non empty Verify list is not empty, if
	 * empty search for products Verify search results page and select UPC item
	 * from list Add to list and do the check off
	 * 
	 * @param products.productname
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I check off shopping list items")
	public void iCheckOffShoppingListItems() throws InterruptedException {
		ListdetailsTestPage lstDetailsPage = new ListdetailsTestPage();
		IOSStepdefshopinglist iosStepDefShopList = new IOSStepdefshopinglist();
		WeeklygroceriesTestPage wGroceries = new WeeklygroceriesTestPage();

		// Checking whether the Item count is 0
		lstDetailsPage.waitForPageToLoad();

		getItemCountFromListPage();

		int convertitemcount = getBundle().getInt("ItemCount");

		// Adding products to the Shopping list if products are not available
		if (convertitemcount == 0) {
			String strPdtName = getBundle().getString("products.productname");
			iosStepDefShopList.iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
			iosStepDefShopList.iSearchForProductFromListDetailsPage(strPdtName);
			iosStepDefShopList.iShouldSeeTheSearchResultsPage();
			iosStepDefShopList.iSelectAUPCSpecificItem();
			iosStepDefShopList.iShouldSeeTheSelectedItemInTheSelectedListPage();
		}
		getItemCountFromListPage();
		convertitemcount = getBundle().getInt("ItemCount");

		if (convertitemcount == 1) {
			String strPdtName = getBundle().getString("products.productname");
			iosStepDefShopList.iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
			iosStepDefShopList.iSearchForProductFromListDetailsPage(strPdtName);
			iosStepDefShopList.iShouldSeeTheSearchResultsPage();
			iosStepDefShopList.iSelectASpecificItem(2);
			iosStepDefShopList.iShouldSeeTheSelectedItemInTheSelectedListPage();
		}
		getItemCountFromListPage();
		convertitemcount = getBundle().getInt("ItemCount");

		if (convertitemcount == 2) {
			String strPdtName = getBundle().getString("products.productname");
			iosStepDefShopList.iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
			iosStepDefShopList.iSearchForProductFromListDetailsPage(strPdtName);
			iosStepDefShopList.iShouldSeeTheSearchResultsPage();
			iosStepDefShopList.iSelectASpecificItem(3);
			iosStepDefShopList.iShouldSeeTheSelectedItemInTheSelectedListPage();
		}
		lstDetailsPage.getListpageLblPagetitle().waitForVisible(5000);
		PerfectoUtils.verticalswipe();
		int itemSize = lstDetailsPage.getListpageLblItemNameList().size();
		String strCheckedPdt = lstDetailsPage.getListpageLblItemNameList().get(itemSize - 1).getText();

		// Getting checked off count
		String strCheckedOffCount = wGroceries.getWgTxtCheckoffcount().getText().split(" ")[0];
		getBundle().setProperty("CheckedoffCount", strCheckedOffCount);

		getBundle().setProperty("CheckedProduct", strCheckedPdt);

		// Clicking the object with respect to product name
		double itemLocation = wGroceries.getShopingListItemChkBoxEntryByLable(strCheckedPdt).getLocation().getY();
		getBundle().setProperty("itemLocation", itemLocation);
		getBundle().setProperty("checkedOFFItem", strCheckedPdt);
		wGroceries.getShopingListItemChkBoxEntryByLable(strCheckedPdt).click();
	}

	/**
	 * Verify a selected list checkbox is checked or not
	 */
	@QAFTestStep(description = "I should see the checkmark in the checkbox")
	public void iShouldSeeTheCheckmarkInTheCheckbox() {
		WeeklygroceriesTestPage wGroceries = new WeeklygroceriesTestPage();

		wGroceries.waitForPageToLoad();
		// Verification of checked off count
		String strActCheckedOffCount = wGroceries.getWgTxtCheckoffcount().getText().split(" ")[0];
		int intActCheckedOffCount = Integer.parseInt(strActCheckedOffCount);
		int intExpCheckedOffCount = getBundle().getInt("CheckedoffCount") + 1;

		if (intExpCheckedOffCount == intActCheckedOffCount) {
			PerfectoUtils.reportMessage(" " + intActCheckedOffCount + " Checked off count is increased", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Checked off count is not increased. Expected: " + intExpCheckedOffCount + " Actual: "
					+ intActCheckedOffCount + " ", MessageTypes.Fail);
		}

		String checkedOFFItem = getBundle().getString("checkedOFFItem");
		double itemLocation = getBundle().getDouble("itemLocation");

		getItemCountFromListPage();
		int itemCount = getBundle().getInt("ItemCount");

		double newLocation = wGroceries.getShopingListItemChkBoxEntryByLable(checkedOFFItem).getLocation().getY();
		if (newLocation > itemLocation)
			PerfectoUtils.reportMessage("Checked off item moved to botton.", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Checked off item not moved to botton.", MessageTypes.Fail);
	}

	/**
	 * Uncheck a selected list's checkbox
	 */
	@QAFTestStep(description = "I uncheck the Shopping list Items")
	public void iUncheckTheShoppingListItems() {
		WeeklygroceriesTestPage wGroceries = new WeeklygroceriesTestPage();

		// Clicking the object with respect to product name
		String strCheckedPdt = getBundle().getPropertyValue("CheckedProduct");
		wGroceries.getShopingListItemChkBoxEntryByLable(strCheckedPdt).click();
	}

	/**
	 * Verify the checkbox are not checked by comparing checked off count with
	 * no of items checked
	 */
	@QAFTestStep(description = "I should not see the checkmark in the checkbox")
	public void iShouldNotSeeTheCheckmarkInTheCheckbox() {
		WeeklygroceriesTestPage wGroceries = new WeeklygroceriesTestPage();

		wGroceries.waitForPageToLoad();
		// Verification of checked off count
		String strActCheckedOffCount = wGroceries.getWgTxtCheckoffcount().getText().split(" ")[0];
		int intActCheckedOffCount = Integer.parseInt(strActCheckedOffCount);
		int intExpCheckedOffCount = getBundle().getInt("CheckedoffCount");

		if (intExpCheckedOffCount == intActCheckedOffCount) {
			PerfectoUtils.reportMessage(" " + intActCheckedOffCount + " Checked off count is decreased", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Checked off count is not decreased. Expected: " + intExpCheckedOffCount + " Actual: "
					+ intActCheckedOffCount + " ", MessageTypes.Fail);
		}
	}

	/**
	 * Click on Search icon and verify search text is displayed
	 */
	@QAFTestStep(description = "I see Search Field is displayed by clicking on Search Icon")
	public void iSeeSearchFieldIsDisplayedByClickingOnSearchIcon() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		// Click on search icon
		weeklygrocery.getWgBtnSearch().waitForVisible(3000);
		weeklygrocery.getWgBtnSearch().click();
		// Verifying Search icon text
		wgsearchresult.getWgLblSearchsrctext().waitForVisible(5000);
		wgsearchresult.getWgLblSearchsrctext().verifyPresent();

	}

	/**
	 * Enter search term productName in search field and click search icon in
	 * weekly grocery list
	 * 
	 * @param productName
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I enter valid search term {0}and select Search button in weekly groceries page")
	public void iEnterValidSearchTermAndSelectSearchButtonInWeeklyGroceriesPage(String productName)
			throws InterruptedException {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		// Enter product name in search field
		getBundle().setProperty("productName", productName);

		wgsearchresult.getWgLblSearchsrctext().click();
		// Enter input search term and click search button on keyboard
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(productName);

		// new search icon click function
		Map<String, Object> param1 = new HashMap<>();
		param1.put("keySequence", "KEYBOARD_SEARCH");
		PerfectoUtils.getAppiumDriver().executeScript("mobile:presskey", param1);
		wgsearchresult.waitForPageToLoad();
	}

	/**
	 * Select an UPC specific item from search list which is displayed as second
	 * item If the search result count is less than two, not selecting any item
	 * 
	 * @return ChoosenProduct
	 */
	@QAFTestStep(description = "I select a UPC specific item")
	public void iSelectAUPCSpecificItem() throws InterruptedException {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		// click on specific item (2nd item) displays in search result page
		String strSpecificPdtName = null;

		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		try {
			wgsearchresult.getListSearchListName().get(1).waitForPresent(80000);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Page didnt load, server issue!!", MessageTypes.Fail);
		}

		int intListSize = wgsearchresult.getListSearchListName().size();
		wgsearchresult.getListSearchListName().get(intListSize - 1).waitForPresent(3000);
		strSpecificPdtName = wgsearchresult.getListSearchListName().get(intListSize - 1).getText();

		getBundle().setProperty("ChoosenProduct", strSpecificPdtName);
		getBundle().setProperty("productName", strSpecificPdtName);
		click("name=" + strSpecificPdtName);
	}

	/**
	 * Check for a selected list name 'NewListName' from the available list name
	 * When matching list is found, respective list is selected When matching
	 * list is not found, return the message
	 * 
	 * @param NewListName
	 */
	@QAFTestStep(description = "I select newly added list name")
	public void iSelectNewlyAddedListName() {
		MylistTestPage mylist = new MylistTestPage();

		mylist.waitForPageToLoad();
		String strLstName = getBundle().getPropertyValue("NewListName");
		try {
			mylist.getShopingListEntryByLable(strLstName).click();
			PerfectoUtils.reportMessage("Clicked: " + strLstName + " ");
		} catch (Exception e) {
			IOSStepdef.scrollToListNameInMyList(strLstName);
			PerfectoUtils.reportMessage("Clicked: " + strLstName + " ");
		}
	}

	/**
	 * Search for the product using keyword "productName" by entering into
	 * search field and clicking search icon
	 * 
	 * @param productName
	 */
	@QAFTestStep(description = "I search for product {0} from list details page")
	public void iSearchForProductFromListDetailsPage(String productName) throws InterruptedException {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		// Enter product name in search field
		wgsearchresult.waitForPageToLoad();
		wgsearchresult.getWgLblSearchsrctext().click();
		getBundle().setProperty("productName", productName);
		IOSStepdef.enterValueIntoTheTextboxandClick(wgsearchresult, productName);
		PerfectoUtils.reportMessage("Searching for " + productName, MessageTypes.Pass);
		wgsearchresult.waitForPageToLoad();
	}

	/**
	 * Wait for and Click on Login\Submit button Hadle login errors
	 */
	@QAFTestStep(description = "I click on Login/Submit button")
	public void iClickOnLoginSubmitButton() {
		LoginsplashTestPage loginsplashpage = new LoginsplashTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		LoginpopupTestPage loginpopup = new LoginpopupTestPage();

		IOSStepdef.clickKeyboardDone();

		// Clicking on Submit button
		if (loginpopup.getLoginpopupBtnSubmit().isPresent()) {
			PerfectoUtils.reportMessage("Clicking submit button from the login popup..", MessageTypes.Pass);
			loginpopup.getLoginpopupBtnSubmit().click();
			PerfectoUtils.reportMessage("Clicked Submit button.");
		} else if (loginsplashpage.getLoginBtnLogin().isPresent()) {
			PerfectoUtils.reportMessage("Clicking Login button from login splash page..", MessageTypes.Pass);
			loginsplashpage.getLoginBtnLogin().click();
			PerfectoUtils.reportMessage("Clicked on Login button.", MessageTypes.Pass);

			// Handling the login Error in iOS
			try {
				appCrash.getExceptionLblloginError().waitForVisible(6000);
				if (appCrash.getExceptionLblloginError().isPresent()) {
					appCrash.getExceptionBtnOk().click();
					PerfectoUtils.reportMessage("Log in Error occured, try entering credential again");
				}
				loginsplashpage.getLoginBtnLogin().waitForVisible(8000);
				loginsplashpage.getLoginBtnLogin().click();
			} catch (Exception e) {
				if (loginsplashpage.getLoginBtnLogin().isPresent()) {
					loginsplashpage.getLoginBtnLogin().click();
				}
				e.printStackTrace();
			}

		} else {
			PerfectoUtils.reportMessage("Error occured while clicking Login/Submit button", MessageTypes.Pass);
		}

		if (weeklygrocery.getShopingListEntryByLable("Log In Error").isPresent()) {
			PerfectoUtils.reportMessage("Log in Error occured, try entering valid credential", MessageTypes.Fail);
			appCrash.getExceptionBtnOk().click();
		}

		if (appCrash.getExceptionLblloginError().isPresent()) {
			PerfectoUtils.reportMessage("Log in Error occured, try entering valid credential", MessageTypes.Fail);
			appCrash.getExceptionBtnOk().click();
		}

		if (appCrash.getExceptionSkipCoupons().isPresent()) {
			PerfectoUtils.reportMessage("Swipe to Discover", MessageTypes.Pass);
			appCrash.getExceptionSkipCoupons().click();
		}
	}

	/**
	 * Wait for and click on the Enter receipt number button Verify the fields
	 * enter receipt overlay, image, message & receipt number textbox in the
	 * enter receipt number popup
	 */
	@QAFTestStep(description = "I see Enter Reciept No Pop-up")
	public void iSeeEnterRecieptNoPopUp() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();

		// click on Receipt number button
		listdetails.getListpageLinkEnterreciept().click();

		// Verifying the Add Receipt page
		listdetails.getListpageLblEnterreceiptoverlay().waitForVisible(3000);
		listdetails.getListpageLblEnterreceiptoverlay().verifyPresent();
		listdetails.getListpageLblRecieptmessage().verifyPresent();
		listdetails.getListpageTxtEnterrecieptnumber().verifyPresent();
	}

	/**
	 * Enter a dynamic list name created using date class and concatenating with
	 * prefix in the create list popup
	 * 
	 * @return List name 'NewListName'
	 */
	@QAFTestStep(description = "I enter the Shopping list name")
	public void iEnterTheShoppingListName() {
		// Getting the current time to form the unique list name
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();

		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		String strListName = "List_" + strTimeStmp;
		getBundle().setProperty("NewListName", strListName);
		/*
		 * Using the perfecto utill method since after entering the list name in
		 * ios add button not getting enabled
		 */
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(strListName);
		PerfectoUtils.reportMessage("List name Entered: " + strListName, MessageTypes.Pass);
	}

	/**
	 * Swiping across a selected list 'DeletedListName' to delete Update the
	 * list name in a variable If no list is available create new list and do
	 * the operation
	 * 
	 * @return DeletedListName
	 */
	@QAFTestStep(description = "I swipe across the name of a Shopping list")
	public void iSwipeAcrossTheNameOfAShoppingList() {
		MylistTestPage myListPage = new MylistTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		myListPage.waitForPageToLoad();
		myListPage.getMyListLblLstNameHotUser().waitForVisible(3000);

		List<QAFWebElement> lstHotUSer = myListPage.getMyListLblLstNameHotUserItems();
		int intSize = lstHotUSer.size();

		if (intSize < 2) {
			iClickOnPlusIconToAddList();
			iShouldSeeThePopupToEnterListName();
			iEnterTheShoppingListName();
			iClickTheAddButton();
			ioscommon.getAppFooterShoppinglist().click();
		}

		intSize = myListPage.getMyListLblLstNameHotUserItems().size();
		String strFirstListName = myListPage.getMyListLblLstNameHotUserItems().get(intSize - 1).getText();
		getBundle().setProperty("DeletedListName", strFirstListName);
		Dimension size = getAppiumDriver().manage().window().getSize();

		int intStartX = (int) (size.width * 0.90);
		if (myListPage.getMyListLblLstNameHotUserItems().get(intSize - 1).getText().contains("Wish List")) {
			int intStartY = Integer.parseInt(myListPage.getMyListLblLstNameHotUserItems().get(0).getAttribute("Y"));
			int intEndX = Integer.parseInt(myListPage.getMyListLblLstNameHotUserItems().get(0).getAttribute("X"));
			strFirstListName = myListPage.getMyListLblLstNameHotUserItems().get(0).getText();
		}

		int intStartY = Integer
				.parseInt(myListPage.getMyListLblLstNameHotUserItems().get(intSize - 1).getAttribute("Y"));
		int intEndX = Integer.parseInt(myListPage.getMyListLblLstNameHotUserItems().get(intSize - 1).getAttribute("X"));

		getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);
		PerfectoUtils.reportMessage("Swiping across the list name: " + strFirstListName + " to delete");
		click("name=Delete");
		PerfectoUtils.reportMessage("Clicked Delete for list name: " + strFirstListName + " ");
	}

	/**
	 * Check the selected product 'ChoosenProduct' is available in list and
	 * return the status If available, swipe across the item name in the list
	 * 
	 * @return Swiped product 'DeletedProduct'
	 */
	@QAFTestStep(description = "I swipe across the name of the product")
	public void iSwipeAcrossTheNameOfTheProduct() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		weeklygrocery.waitForPageToLoad();
		String strPdtName = getBundle().getString("ChoosenProduct");

		// Getting the object name with dynamic value
		if (weeklygrocery.getShopingListEntryByLable(strPdtName).isDisplayed()) {
			PerfectoUtils.reportMessage("Selected product: " + strPdtName + " is displayed in list details page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected product: " + strPdtName + " is not displayed in list details page",
					MessageTypes.Fail);
		}

		// Getting dimension to swipe
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartX = (int) (size.width * 0.90);
		int intStartY = Integer.parseInt(weeklygrocery.getShopingListEntryByLable(strPdtName).getAttribute("Y"));
		int intEndX = Integer.parseInt(weeklygrocery.getShopingListEntryByLable(strPdtName).getAttribute("X"));

		getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);
		PerfectoUtils.reportMessage("Swiping across the product name: " + strPdtName + " to delete");
		click("name=Delete");
		PerfectoUtils.reportMessage("Clicked Delete for product name: " + strPdtName + " ");
	}

	/**
	 * Check for a selected product 'DeletedProduct' not present in the list and
	 * return the status
	 * 
	 * @param Product
	 *            'DeletedProduct'
	 */
	@QAFTestStep(description = "I should not see the product")
	public void iShouldNotSeeTheProduct() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		MylistTestPage mylistpage = new MylistTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		weeklygrocery.waitForPageToLoad();
		String strDeletedPdtName = getBundle().getPropertyValue("ChoosenProduct");

		ioscommon.getAppBtnBackIOS().click();
		if (mylistpage.getMylistsLblWeeklygroceries().isPresent()) {
			mylistpage.getMylistsLblWeeklygroceries().waitForPresent(7000);
			mylistpage.getMylistsLblWeeklygroceries().click();
		} else {
			iSelectAndNavigateToFirstList();
		}
		// Forming the dynamic object
		boolean isListDisplayed = weeklygrocery.getShopingListEntryByLable(strDeletedPdtName).isPresent();
		if (!isListDisplayed) {
			PerfectoUtils.reportMessage("Deleted product: " + strDeletedPdtName + " is not displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Deleted product: " + strDeletedPdtName + " is displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Verify the popup title matches the text 'Add to List' and return status
	 */
	@QAFTestStep(description = "I see Add to List popup on selecting Add to List button")
	public void iSeeAddToListPopupOnSelectingAddToListButton() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		ioscommon.waitForPageToLoad();
		ioscommon.getAddtolistBtnDone().verifyPresent();
	}

	/**
	 * Compares the new list name 'NewListName' with all the available list name
	 * in list name picker by clicking on the next When matches, stop the
	 * comparison And click the Add to list button
	 * 
	 * @param NewListName
	 */
	@QAFTestStep(description = "I see toaster message on selecting Add button in Add To List popup")
	public void iSeeToasterMessageOnSelectingAddButtonInAddToListPopup() {
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();

		int i = 0;
		ioscommonpage.waitForPageToLoad();
		String numberPicker = ioscommonpage.getAddtolistTxtNumberpicker().getText();
		String newListNameValue = ConfigurationManager.getBundle().getString("NewListName");

		if (!(newListNameValue == null)) {

			// Selecting the picker Value
			while ((!numberPicker.equals(newListNameValue)) && (i < 50)) {
				ioscommonpage.getAddtolistTxtNextpicker().get(0).click();
				PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
				ioscommonpage.getAddtolistTxtNumberpicker().waitForVisible(3000);
				numberPicker = ioscommonpage.getAddtolistTxtNumberpicker().getText();
				i++;
			}
			ioscommonpage.getAddtolistBtnDone().click();
		} else {
			numberPicker = ioscommonpage.getAddtolistTxtNumberpicker().getText();
			ConfigurationManager.getBundle().setProperty("NewListName", numberPicker);
			ioscommonpage.getAddtolistBtnDone().click();
		}
	}

	/**
	 * Verify the list 'listName' to which item added is the newly created list
	 * 'NewListName' and result the status as info Navigate to the list
	 * 'addedList' if available and if not available scroll and check for the
	 * list Verify the added ingredients 'ingSize' are available in list by
	 * comparing 'ingSize' with list item count and return the status
	 * 
	 * @param list
	 *            names 'NewListName', 'listName' and ingredient count 'ingSize'
	 */
	@QAFTestStep(description = "I verify if ingredients added in selected shopping list")
	public void iVerifyIfIngredientsAddedInSelectedShoppingList() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		// Click on selected shopping list
		try {
			weeklygrocery.getShopingListEntryByLable(getBundle().getString("listName")).click();
		} catch (Exception e) {
			IOSStepdef.scrollToListNameInMyList(getBundle().getString("listName"));
		}

		// Verify if selected ingredient is available
		if (weeklygrocery.getShopingListEntryByLable(getBundle().getString("Ingredient")).isPresent()) {
			PerfectoUtils.reportMessage("Added Ingredient: " + getBundle().getString("Ingredient") + ": is present.",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.verticalswipe();
			if (weeklygrocery.getShopingListEntryByLable(getBundle().getString("Ingredient")).isPresent()) {
				PerfectoUtils.reportMessage("Added Ingredient: " + getBundle().getString("Ingredient") + ": is present.",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Added Ingredient: " + getBundle().getString("Ingredient") + ": not present",
						MessageTypes.Fail);
			}
		}

	}

	/**
	 * Check the list is not empty, if not empty return the Actual item names
	 * 'arrActualItemname and the generic item names 'arrGenericItemname' in a
	 * List if the list is empty, search for products in list, add UPC specific
	 * item to list and do above step
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I verify available products in List Details page")
	public void iVerifyAvailableProductsInListDetailsPage() throws InterruptedException {
		ListdetailsTestPage listdetailspage = new ListdetailsTestPage();
		IOSStepdefshopinglist iosStepDefShopList = new IOSStepdefshopinglist();
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();

		listdetailspage.waitForPageToLoad();
		getItemCountFromListPage();

		int getitemcnt = getBundle().getInt("ItemCount");

		if (getitemcnt < 1) {

			iosStepDefShopList.iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
			iosStepDefShopList.iSearchForProductFromListDetailsPage("milk");
			iosStepDefShopList.iShouldSeeTheSearchResultsPage();
			iosStepDefShopList.iSelectAUPCSpecificItem();
			iosStepDefShopList.iShouldSeeTheSelectedItemInTheSelectedListPage();
			ioscommonpage.getAppFooterHomeicon().waitForPresent(3000);
			ioscommonpage.getAppBtnBackIOS().click();
			IOSStepdefshopinglist.iSelectAndNavigateToFirstList();
		}

		// Verifying the item count again
		String strItemCount = listdetailspage.getLblHcitemcount().getText().split(" ")[0];
		int itemCount = Integer.parseInt(strItemCount);

		if (itemCount != 0) {
			PerfectoUtils.reportMessage("List Details page displayed with item count: " + itemCount + "", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("List Details page displayed with item count: 0", MessageTypes.Fail);
		}

		// Getting the available products in the list to compare
		List<String> arrActualItemname = new ArrayList<String>();
		for (QAFWebElement temp : listdetailspage.getListpageLblItemNameList()) {
			arrActualItemname.add(temp.getText());
		}
		getBundle().setProperty("arrActualItemname", arrActualItemname);
	}

	/**
	 * Verify the List pickerwheel pop-up is displayed
	 */
	@QAFTestStep(description = "I should see Copy Items to List popup")
	public void iShouldSeeCopyItemsToListPopup() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.waitForPageToLoad();
		int listSize = mylistpage.getMyListsLblSelectedlist().size();
		mylistpage.getMyListsLblSelectedlist().get(listSize - 1).waitForPresent(3000);

		boolean boolListname = mylistpage.getMyListsLblSelectedlist().get(listSize - 1).isPresent();
		if (boolListname) {
			PerfectoUtils.reportMessage("List pickerwheel pop-up is displayed");
		} else {
			PerfectoUtils.reportMessage("List pickerwheel pop-up is not displayed");
		}
	}

	/**
	 * Check for a selected list name in available list name and click on the
	 * selected list if found
	 */
	@QAFTestStep(description = "I select the list which haivng item copied")
	public void iSelectTheListWhichHaivngItemCopied() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		MylistTestPage mylistpage = new MylistTestPage();

		String newListNameValue = ConfigurationManager.getBundle().getString("SelectedList");
		// ioscommonpage.getAppBtnBackIOS().click();

		// Verify my list page
		mylistpage.getMyListLblPagetitle().waitForPresent(5000);
		if (mylistpage.getMyListLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to My lists page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to My lists page. ", MessageTypes.Fail);
		}

		// Click on selected shopping list
		try {
			weeklygrocery.getShopingListEntryByLable(newListNameValue).waitForVisible(2000);
			weeklygrocery.getShopingListEntryByLable(newListNameValue).click();

		} catch (Exception e) {
			IOSStepdef.scrollToListNameInMyList(getBundle().getString("listName"));
			weeklygrocery.getShopingListEntryByLable(newListNameValue).waitForVisible(1000);
			weeklygrocery.getShopingListEntryByLable(newListNameValue).click();
		}
		PerfectoUtils.reportMessage("Selected list: " + newListNameValue, MessageTypes.Pass);
	}

	/**
	 * Enter the receipt number 'ScanReceipt.ReciepNumber' in the receipt number
	 * field Click Add button to add the receipt to list Check the alert is
	 * displayed for 'Invalid recipt number' If no error displayed report
	 * success
	 * 
	 * @param receipt
	 *            number 'ScanReceipt.ReciepNumber'
	 */
	@QAFTestStep(description = "I enter Reciept Number")
	public void iEnterRecieptNumber() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		// Verify the entered recipe number is of 23 in length
		listdetails.getListpageTxtEnterrecieptnumber().click();
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(getBundle().getString("ScanReceipt.ReciepNumber"));

		// Clicking on Submit button
		listdetails.getListpageBtnSubmit().waitForVisible(5000);
		listdetails.getListpageBtnSubmit().click();
		listdetails.waitForPageToLoad();

		// validation
		if (weeklygrocery.getShopingListEntryByLable("Error").isPresent()) {
			PerfectoUtils.reportMessage("Invalid recipt number has been entered", MessageTypes.Fail);
			weeklygrocery.getShopingListEntryByLable("OK").click();
			ioscommon.getAppBtnBackIOS().click();
		} else {
			PerfectoUtils.reportMessage("Recipt number has been entered", MessageTypes.Pass);
		}
	}

	/**
	 * Look for a selected list 'NewListName' or 'ChoosenList' in the available
	 * lists Scroll and check if the list is not available If match found, click
	 * on the list name and report
	 */
	@QAFTestStep(description = "I see List detail page on clicking corresponding list name from My list page")
	public void iSeeListDetailPageOnClickingCorrespondingListNameFromMyListPage() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String newListNameValue = ConfigurationManager.getBundle().getString("NewListName");
		if (newListNameValue == null) {
			newListNameValue = ConfigurationManager.getBundle().getString("ChoosenList");
		}

		// Click on selected shopping list
		try {

			weeklygrocery.getShopingListEntryByLable(newListNameValue).waitForVisible(3000);
			if (weeklygrocery.getShopingListEntryByLable(newListNameValue).getAttribute("hidden")
					.equalsIgnoreCase("false")) {
				PerfectoUtils.swipeIfInBottom(newListNameValue);
				weeklygrocery.getShopingListEntryByLable(newListNameValue).click();
			} else {
				IOSStepdef.scrollToListNameInMyList(newListNameValue, 90, 80, 2);
				weeklygrocery.getShopingListEntryByLable(newListNameValue).waitForVisible(1000);
				PerfectoUtils.swipeIfInBottom(newListNameValue);
				weeklygrocery.getShopingListEntryByLable(newListNameValue).click();
			}

		} catch (Exception e) {
			IOSStepdef.scrollToListNameInMyList(newListNameValue, 90, 80, 2);
			weeklygrocery.getShopingListEntryByLable(newListNameValue).waitForVisible(1000);
			weeklygrocery.getShopingListEntryByLable(newListNameValue).click();
		}
		PerfectoUtils.reportMessage("Selected list: " + newListNameValue, MessageTypes.Pass);
	}

	/**
	 * Navigate back to previous page
	 */
	@QAFTestStep(description = "I navigate back to My Lists page")
	public void iNavigateBackToMyListsPage() {
		IoscommonTestPage iosCommon = new IoscommonTestPage();

		iosCommon.getAppBtnBackIOS().waitForPresent(5000);
		iosCommon.getAppBtnBackIOS().click();
	}

	/**
	 * Enter the invalid receipt number 'ScanReceipt.InvalidReciepNumber' in the
	 * receipt number field Click submit button to add the receipt to list Check
	 * the alert is not displayed with 'Add to List' text and fail if it is true
	 * Check the alert is displayed with 'Error' text for invalid receipt number
	 * Handle the error popup Navigate back to list page by clicking back option
	 * 
	 * @param receipt
	 *            number 'ScanReceipt.InvalidReciepNumber'
	 */
	@QAFTestStep(description = "I enter invalid Reciept Number")
	public void iEnterInvalidRecieptNumber() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		// Verify the entered recipe number is of 23 in length
		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		listdetails.getListpageTxtEnterrecieptnumber().click();

		PerfectoUtils.getAppiumDriver().getKeyboard()
				.sendKeys(getBundle().getString("ScanReceipt.InvalidReciepNumber"));

		// Clicking on Submit button
		listdetails.getListpageBtnSubmit().waitForVisible(5000);
		listdetails.getListpageBtnSubmit().click();
		listdetails.waitForPageToLoad();

		PerfectoUtils.reportMessage("Clicked on submit button", MessageTypes.Pass);
		if (weeklygrocery.getLblScanReceipterrorpopuptitle().isPresent()) {
			PerfectoUtils.reportMessage("Error message has been populated for invalid reciept number", MessageTypes.Pass);
			if (weeklygrocery.getShopingListEntryByLable("Ok").isPresent()) {
				weeklygrocery.getShopingListEntryByLable("Ok").click();
			} else {
				weeklygrocery.getShopingListEntryByLable("OK").click();
			}
		} else {
			PerfectoUtils.reportMessage("Error message is not populated for invalid reciept number", MessageTypes.Fail);
		}
		// Navigate back to scan receipt page
		ioscommon.getAppBtnBackIOS().click();
	}

	/**
	 * Verify the list is empty by comparing list item count with 0 item or 0
	 * items
	 */
	@QAFTestStep(description = "I should see All items are deleted from list")
	public void iShouldSeeAllItemsAreDeletedFromList() {
		ListdetailsTestPage listdetail = new ListdetailsTestPage();

		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

		String strItemCount = listdetail.getListpageLblShoppingitemcount().getText().replaceAll(" Item", "")
				.replaceAll(" Items", "").replaceAll("s", "").trim();

		if (strItemCount.equalsIgnoreCase("0")) {
			PerfectoUtils.reportMessage("No item is avaible", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Items are still there to delete", MessageTypes.Fail);
		}
	}

	/**
	 * Get the item count from list details page and save in 'ItemCount
	 * 
	 * @return ItemCount
	 */
	public static void getItemCountFromListPage() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();

		String items = null;
		int itemcount = 0;
		listdetails.waitForPageToLoad();
		listdetails.getListpageLblShoppingitemcount().waitForPresent(3000);
		QAFWebElement getelename = listdetails.getListpageLblShoppingitemcount();
		getelename.waitForVisible(3000);
		items = getelename.getText();

		if (items.contains("0")) {
			if (listdetails.getLblHcitemcount().isPresent()) {
				items = listdetails.getLblHcitemcount().getText();
			}
		}
		if (items.contains("Items")) {
			items = items.replace("Items", "").trim();
		} else if (items.contains("Item")) {
			items = items.replace("Item", "").trim();
		}

		itemcount = Integer.parseInt(items);
		getBundle().setProperty("ItemCount", itemcount);
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I select the Overflow icon from my lists page")
	public void iSelectTheOverflowIconFromMyListsPage() {
		/*
		 * ListdetailsTestPage listDetailsPage = new ListdetailsTestPage();
		 * 
		 * listDetailsPage.getListpageBtnMore().waitForVisible(5000);
		 * listDetailsPage.getListpageBtnMore().click();
		 */

		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I should see the list of options")
	public void iShouldSeeTheListOfOptions() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);

	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I select delete list option")
	public void iSelectDeleteListOption() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);

	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I should see My Lists page in Edit mode")
	public void iShouldSeeMyListsPageInEditMode() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I should see the List name highlighted in red")
	public void iShouldSeeTheListNameHighlightedInRed() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I select delete icon")
	public void iSelectDeleteIcon() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I should see the Delete Lists popup")
	public void iShouldSeeTheDeleteListsPopup() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I select the Delete button from delete list popup")
	public void iSelectTheDeleteButtonFromDeleteListPopup() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I should not see the list name")
	public void iShouldNotSeeTheListName() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I select Edit List option")
	public void iSelectEditListOption() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I should see the Rename <Shoping List> popup")
	public void iShouldSeeTheRenameShopingListPopup() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I edit the Shopping List name")
	public void iEditTheShoppingListName() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I click the Rename button")
	public void iClickTheRenameButton() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I should not see option to create new list")
	public void iShouldNotSeeOptionToCreateNewList() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I select a list to delete")
	public void iSelectAListToDelete() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I enter existing List name to rename")
	public void iEnterExistingListNameToRename() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I select the first list")
	public void iSelectTheFirstList() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Verify the different sections search button, back option, page title and
	 * more are present in Weekly grocery page
	 */
	@QAFTestStep(description = "I validate the Weekly Groceries page")
	public void iValidateTheWeeklyGroceriesPage() {
		WeeklygroceriesTestPage weeklygroceries = new WeeklygroceriesTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		ListdetailsTestPage listdetail = new ListdetailsTestPage();

		weeklygroceries.getWgBtnSearch().verifyPresent();
		ioscommon.getAppBtnBackIOS().verifyPresent();
		weeklygroceries.getLblPagetitle().verifyPresent();
		weeklygroceries.getBtnMore().verifyPresent();

		weeklygroceries.getBtnMore().click();
		listdetail.getListpageLinkDeleteitem().verifyPresent();
		listdetail.getListpageLinkDeleteallitem().verifyPresent();
		listdetail.getListpageLinkUncheckitem().verifyPresent();
		listdetail.getListpageLinkCopytoanotherlist().verifyNotPresent();
	}

	/**
	 * Verify the search results is relevant to the search term
	 * 'products.productname' by verifying the result item name whether it
	 * contain the search term 'products.productname' or not
	 * 
	 * @param products.productname
	 */
	@QAFTestStep(description = "I should see the Search Results page")
	public void iShouldSeeTheSearchResultsPage() {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();
		IoscommonTestPage ioscommonTestPage = new IoscommonTestPage();

		// Validate relevant products are displayed
		String strValidProductname = getBundle().getString("products.productname");
		Boolean result = false;
		String strSpecificPdtName = null;
		int intListSize = 0;
		ioscommonTestPage.getAppLblLoading().waitForNotPresent(25000);

		try {
			intListSize = wgsearchresult.getWgListSpecificitemname().size();
		} catch (Exception e) {
			intListSize = wgsearchresult.getWgListSpecificitemname().size();
			e.printStackTrace();
		}
		if (intListSize == 0) {
			PerfectoUtils.reportMessage("No Items found", MessageTypes.Fail);
		} else {
			strSpecificPdtName = wgsearchresult.getShopingListItemnameEntryByLable(intListSize - 1).getText();
		}

		result = (strSpecificPdtName.toLowerCase()).contains(strValidProductname.toLowerCase());

		if (result) {
			PerfectoUtils.reportMessage("Searched Product " + strValidProductname + " is displayed in Result", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Searched Product " + strValidProductname + " is not displayed in Result", MessageTypes.Fail);
		}
	}

	/**
	 * Verify present and click on the Plus icon
	 */
	@QAFTestStep(description = "I click on plus from action bar")
	public void iClickOnPlusFromActionBar() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.getMyListsImgPlus().verifyPresent();
		mylistpage.getMyListsImgPlus().click();
	}

	/**
	 * Navigate to a selected list 'listName' Verify the selected ingredients
	 * 'inglist' are available in the list If ingredient is not available,
	 * scroll and verify
	 * 
	 * @param list
	 *            name 'listName' and ingredients list 'inglist'
	 */
	@QAFTestStep(description = "I verify if all ingredients added in selected shopping list")
	public void iVerifyIfAllIngredientsAddedInSelectedShoppingList() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		// Click on selected shopping list
		try {
			weeklygrocery.getShopingListEntryByLable(getBundle().getString("listName")).click();
		} catch (Exception e) {
			PerfectoUtils.getAppiumDriver().scrollToExact(getBundle().getString("listName"));
			weeklygrocery.getShopingListEntryByLable(getBundle().getString("listName")).click();
		}
		PerfectoUtils.reportMessage("Selected list: " + getBundle().getString("listName"), MessageTypes.Pass);

		// Verify if selected ingredient is available

		for (Object actualProduct : getBundle().getList("inglist")) {
			String actProduct = actualProduct.toString();
			try {
				weeklygrocery.getShopingListEntryByLable(actProduct).waitForPresent(3000);
				if (weeklygrocery.getShopingListEntryByLable(actProduct).isPresent()) {
					PerfectoUtils.reportMessage("Ingredient " + actProduct + " is available", MessageTypes.Pass);
				}
			} catch (Exception e) {
				try {
					IOSStepdef.scrollToListNameInMyList(actProduct);
					PerfectoUtils.reportMessage("Ingredient " + actProduct + " is available", MessageTypes.Pass);
				} catch (Exception f) {
					PerfectoUtils.reportMessage("Ingredient " + actProduct + " is not available", MessageTypes.Fail);
				}
			}
		}
	}

	/**
	 * Navigate to my list page and navigate to weekly grocery list Select more
	 * icon and select the Delete all option Verify all items get deleted in the
	 * list Click on hamburger and navigate to Home page
	 */
	@QAFTestStep(description = "I delete all items from weekly groceries shopping list")
	public void iDeleteAllItemsFromWeeklyGroceriesShoppingList() {
		HomeTestPage homepage = new HomeTestPage();

		iNavigateToMyListPage();
		iNavigateToWeeklyGroceriesPage();

		int strItemCount = getBundle().getInt("ItemCount");

		if (strItemCount != 0) {

			iSelectTheOverviewIconFromTheActionBar();
			iSelectDeleteAllItemsOption();
			iShouldSeeAllItemsAreDeletedFromList();

			homepage.getAppFooterHomeicon().click();

		} else {
			PerfectoUtils.reportMessage("No Items available to delete.", MessageTypes.Pass);
			homepage.getAppFooterHomeicon().click();
		}

	}

	/**
	 * Click on submit button with invalid email address in login popup Verify
	 * the login failure happen with invalid email address and report the status
	 */
	@QAFTestStep(description = "I see error message for invalid email after click on Login/Submit button")
	public void iSeeErrorMessageForInvalidEmailAfterClickOnLoginSubmitButton() {
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		IOSStepdef.clickKeyboardDone();

		// Clicking on Submit button
		loginsplash.getLoginBtnLogin().waitForVisible(3000);
		loginsplash.getLoginBtnLogin().click();

		try {
			weeklygrocery.getShopingListEntryByLable("Login Error").waitForVisible(7000);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (weeklygrocery.getShopingListEntryByLable("Login Error").isPresent()) {
			PerfectoUtils.reportMessage("Log in Error occured Pop up is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Log In Error occured Pop up is not displayed", MessageTypes.Fail);
		}

		appCrash.getExceptionBtnOk().click();
		PerfectoUtils.reportMessage("Clicked Ok button in Login Error Popup", MessageTypes.Info);

	}

	/**
	 * Verify the selected list of items (arrActualItemname &
	 * arrGenericItemname) available in the selected list 'SelectedList' Get all
	 * the listed item in the list in a set 'arrExpItemname' And Verifies each
	 * 'arrActualItemname' items available in the selected list and if mathces
	 * add to set 'arrExpItemname' At the end we verify 'arrExpItemname'
	 * contains all 'arrActualItemname' return the result
	 * 
	 * @param SelectedList,
	 *            arrActualItemname, arrGenericItemname
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I should see the Product which is copied to this list")
	public void iShouldSeeTheProductWhichIsCopiedToThisList() throws InterruptedException {
		ListdetailsTestPage listdetail = new ListdetailsTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String strDestinationList = getBundle().getPropertyValue("SelectedList");
		List<String> arrActualItemname = new ArrayList(getBundle().getList("arrActualItemname"));
		Collections.sort(arrActualItemname);
		String strActualItemlast = arrActualItemname.get(arrActualItemname.size() - 1);

		// Getting the expected item names
		HashSet<String> arrExpItemname = new HashSet<String>();

		for (QAFWebElement temp : listdetail.getListpageLblItemNameListobj()) {
			arrExpItemname.add(temp.getText());
		}

		try {
			weeklygrocery.waitForPageToLoad();
			weeklygrocery.getShopingListEntryByLable(strActualItemlast).waitForPresent(5000);
		} catch (Exception e) {
			IOSStepdef.scrollToItemInList(strActualItemlast);
			for (QAFWebElement temp : listdetail.getListpageLblItemNameListobj()) {
				arrExpItemname.add(temp.getText());
			}
		}

		if (arrExpItemname.containsAll(arrActualItemname)) {
			PerfectoUtils.reportMessage("Items copied is present in the destination list: " + strDestinationList + " ",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Items copied is not present in the destination list: " + strDestinationList + " ",
					MessageTypes.Fail);
		}

	}

	/**
	 * Select a product from CDP page by navigating to All products tab and take
	 * the first item name and click on it Get the product name from PDP and
	 * save in 'ChoosenProduct'
	 * 
	 * @return product name 'ChoosenProduct'
	 */
	@QAFTestStep(description = "I select product from CDP to PDP")
	public static void selectProductFromCDPAndAdtolistFromPDP() {
		ProductsresultlistTestPage itemresult = new ProductsresultlistTestPage();
		ProductdetailTestPage pdp = new ProductdetailTestPage();

		// Clicking single product from CDP page
		itemresult.getFiltermodalLblAllStores().waitForVisible(5000);

		int listSize = itemresult.getProductresultlist().size();
		if (listSize != 0) {
			IOSStepdefproducts.selectPdtFromCDP();
		} else {
			try {
				PerfectoUtils.reportMessage("No products displayed for the catogory navigation. Switching to All products tab.",
						MessageTypes.Pass);
				itemresult.getFiltermodalLblAllStores().waitForPresent(3000);
				itemresult.getFiltermodalLblAllStores().click();
				PerfectoUtils.reportMessage("Clicked on All products section.");
				IOSStepdefproducts.selectPdtFromCDP();
			} catch (Exception e) {
				PerfectoUtils.reportMessage("Error Occured while navigating to ALL Products tab.", MessageTypes.Fail);
			}
		}

		// Getting Product Title from PDP page
		pdp.waitForPageToLoad();
		pdp.getPdpLblProductname().waitForVisible(5000);
		String strProductName = pdp.getPdpLblProductname().getText();
		getBundle().setProperty("ChoosenProduct", strProductName);
	}

	/**
	 * Enter invalid emailId address 'SendEmail.InvalidEmailAddress' in
	 * recipient email field and click Send button
	 * 
	 * @param 'SendEmail.InvalidEmailAddress'
	 */
	@QAFTestStep(description = "I enter Invalid email address and click on Send/ submit button")
	public void iEnterInvalidEmailAddressAndClickOnSendSubmitButton() {
		SendemailTestPage sendemail = new SendemailTestPage();

		String recipientEmail = ConfigurationManager.getBundle().getString("SendEmail.InvalidEmailAddress");
		sendemail.getSendemailTxtRecipientemail().waitForPresent(4000);
		sendemail.getSendemailTxtRecipientemail().click();
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys("");
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(recipientEmail);

		PerfectoUtils.reportMessage("Entered Email: " + recipientEmail + " ");
		// Hide Keyboard
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");
		Object result1 = sendemail.getTestBase().getDriver().executeScript("mobile:text:select", params1);

		sendemail.getSendemailBtnSubmit().click();
		PerfectoUtils.reportMessage("Clicked Sumbit");
	}

	/**
	 * Verify the error message is displayed by checking the exception is
	 * present or not Handle the exception
	 */
	@QAFTestStep(description = "I should see the error popup/ toast message")
	public void iShouldSeeTheErrorPopupToastMessage() {
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		
		appcrash.getExceptionBtnOk().waitForPresent(5000);
		// Verify error message
		if (appcrash.getExceptionBtnOk().isPresent()) {
			PerfectoUtils.reportMessage("Error message recieved as expected.", MessageTypes.Pass);
			if (appcrash.getExceptionBtnOk().isPresent()) {
				appcrash.getExceptionBtnOk().click();
			}
			PerfectoUtils.reportMessage("Clicked Ok button from the popup.", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("Error message not recieved as expected.", MessageTypes.Fail);
		}
	}

	/**
	 * If the list is not empty, get the first item name in the list and save in
	 * 'ChoosenProduct' If the list is empty, search for a keyword, select an
	 * item from search result and add to list and do the above step
	 * 
	 * @return Item name 'ChoosenProduct'
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I get the product name from list details page")
	public void iGetTheProductNameFromListDetailsPage() throws InterruptedException {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();

		int listsize = listdetails.getListpageLblItemNameListobj().size();
		if (listsize > 0) {
			getBundle().setProperty("ChoosenProduct",
					listdetails.getListpageLblItemNameListobj().get(listsize - 1).getText());
		} else {
			PerfectoUtils.reportMessage("No Items found in the list. Adding the product..", MessageTypes.Info);

			// Adding the products to the list
			iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
			iSearchForProductFromListDetailsPage("milk");
			iShouldSeeTheSearchResultsPage();
			iSelectAUPCSpecificItem();
			iShouldSeeTheSelectedItemInTheSelectedListPage();

			// getting the name of the product
			listsize = listdetails.getListpageLblItemNameListobj().size();
			getBundle().setProperty("ChoosenProduct",
					listdetails.getListpageLblItemNameListobj().get(listsize - 1).getText());
		}
	}

	/**
	 * Enter recipient email id 'default.user.email' and change the sender email
	 * id by entering new email id 'SendEmail.senderemail' and click send button
	 * 
	 * @param 'default.user.email'
	 *            and 'SendEmail.senderemail'
	 */
	@QAFTestStep(description = "I change the sender email address and click on Send/ submit button")
	public void iChangeTheSenderEmailAddressAndClickOnSendSubmitButton() {
		SendemailTestPage sendemail = new SendemailTestPage();

		String recipientEmail = null;
		String senderEmail = ConfigurationManager.getBundle().getString("SendEmail.senderemail");

		// Entering the recipient email id
		recipientEmail = getBundle().getString("default.user.email");
		sendemail.getSendemailTxtRecipientemail().waitForVisible(3000);
		sendemail.getSendemailTxtRecipientemail().click();
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys("");
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(recipientEmail);

		// Changing the sender email id
		sendemail.getSendemailTxtSenderemail().waitForVisible(2000);
		sendemail.getSendemailTxtSenderemail().click();
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys("");
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(senderEmail);

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");
		Object result1 = sendemail.getTestBase().getDriver().executeScript("mobile:text:select", params1);

		PerfectoUtils.reportMessage("Entered Email: " + senderEmail + " ");
		sendemail.getSendemailBtnSubmit().click();
		PerfectoUtils.reportMessage("Clicked Sumbit");
	}

	/**
	 * Verify the list 'listName' to which item added is the newly created list
	 * 'NewListName' and result the status as info Navigate to the list
	 * 'addedList' if available and if not available scroll and check for the
	 * list Verify the added ingredients 'ingSize' are available in list by
	 * comparing 'ingSize' with list item count and return the status
	 * 
	 * @param list
	 *            names 'NewListName', 'listName' and ingredient count 'ingSize'
	 */
	@QAFTestStep(description = "I verify if ingredients added in selected shopping list of hot user")
	public void iVerifyIfIngredientsAddedInSelectedShoppingListOfHotUser() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String listName = getBundle().getString("NewListName");

		// Click on selected shopping list
		try {
			weeklygrocery.getShopingListEntryByLable(listName).waitForVisible(2000);
			weeklygrocery.getShopingListEntryByLable(listName).click();
		} catch (Exception e) {
			IOSStepdef.scrollToListNameInMyList(listName);
			weeklygrocery.getShopingListEntryByLable(listName).waitForVisible(1000);
			weeklygrocery.getShopingListEntryByLable(listName).click();
		}

		PerfectoUtils.reportMessage("Selected list: " + listName, MessageTypes.Pass);

		String strCount = weeklygrocery.getWgTxtShoppingitemcount().getText();

		if (strCount.contains("Items")) {
			strCount = strCount.replaceAll("Items", "").trim();
		} else if (strCount.contains("Item")) {
			strCount = strCount.replaceAll("Item", "").trim();
		}

		int intCount = Integer.parseInt(strCount);
		if (intCount == getBundle().getInt("ingSize")) {
			PerfectoUtils.reportMessage("All " + intCount + " ingredients are added to list", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("All " + intCount + " ingredients are not added to list", MessageTypes.Fail);
		}
	}

	/**
	 * Navigate back to previous page that is list page by device back option
	 */
	@QAFTestStep(description = "I navigate back to list details page")
	public void iNavigateBackToListDetailsPage() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		ioscommon.getAppBtnBackIOS().waitForPresent(5000);
		ioscommon.getAppBtnBackIOS().click();
	}

	/**
	 * Verify the scanned product is not added to list after clicking cancel by
	 * verifying the page is list page and checking the item name
	 * 'scannedItemname' not present in the list
	 * 
	 * @param item
	 *            name 'scannedItemname'
	 */
	@QAFTestStep(description = "I should not see the scanned product in the selected list")
	public void iShouldNotSeeTheScannedProductInTheSelectedList() {
		WeeklygroceriesTestPage weeklygroceries = new WeeklygroceriesTestPage();

		String scannedPdtname = ConfigurationManager.getBundle().getString("scannedItemname");

		// Checking whether the page has been navigated to List name page
		if (weeklygroceries.getLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to " + weeklygroceries.getLblPagetitle().getText() + " page.", MessageTypes.Pass);

			// Checking whether the scanned product is available in the list
			if (!weeklygroceries.getShopingListEntryByLable(scannedPdtname).isPresent()) {
				PerfectoUtils.reportMessage("Scanned product: " + scannedPdtname + ", is not available in the list",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Scanned product: " + scannedPdtname + ", is available in the list", MessageTypes.Fail);
			}

		} else {
			PerfectoUtils.reportMessage("Not navigated to " + weeklygroceries.getLblPagetitle().getText() + " page.",
					MessageTypes.Fail);
		}
	}

	/**
	 * Navigate to first list in the available lists and delete all the item in
	 * the list using overflow icon and delete all items options Navigate to
	 * home page using home option
	 */
	@QAFTestStep(description = "I delete all items from wish list of shopping list")
	public void iDeleteAllItemsFromWishListOfShoppingList() {

		IOSStepdefshopinglist iosshoppinglist = new IOSStepdefshopinglist();
		HomeTestPage homepage = new HomeTestPage();

		iosshoppinglist.iNavigateToMyListPage();
		IOSStepdefshopinglist.iSelectAndNavigateToFirstList();

		int strItemCount = getBundle().getInt("ItemCount");

		if (strItemCount != 0) {
			iSelectTheOverviewIconFromTheActionBar();
			iSelectDeleteAllItemsOption();
			iShouldSeeAllItemsAreDeletedFromList();
			homepage.getAppFooterHomeicon().click();
		} else {
			PerfectoUtils.reportMessage("No Items available to delete.", MessageTypes.Pass);
			homepage.getAppFooterHomeicon().click();
		}

	}

	/**
	 * Navigate to My list page using My list option in footer Verify list page
	 * is loaded
	 */
	@QAFTestStep(description = "I navigate to My List page")
	public void iNavigateToMyListPage() {
		MylistTestPage mylistpage = new MylistTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		ioscommon.getAppFooterShoppinglist().waitForPresent(5000);
		ioscommon.getAppFooterShoppinglist().click();
		PerfectoUtils.reportMessage("Clicked on My Lists.", MessageTypes.Pass);

		if (mylistpage.getMyListLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to My lists page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to My lists page. ", MessageTypes.Fail);
		}

	}

	/**
	 * Verify my list page is loaded by verifying the my list page title
	 */
	@QAFTestStep(description = "I verify My List page is displayed")
	public void iVerifyMyListPageIsDisplayed() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.waitForPageToLoad();
		mylistpage.getMyListLblPagetitle().waitForPresent(3000);

		if (mylistpage.getMyListLblPagetitle().isPresent())
			PerfectoUtils.reportMessage("Navigated to My lists page.", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not Navigated to My lists page.", MessageTypes.Fail);
	}

	/**
	 * Verify weekly grocery list is present and click on it
	 */
	@QAFTestStep(description = "I see weekly grocery list in My list page")
	public void iSeeWeeklyGroceryListInMyListPage() {
		MylistTestPage mylist = new MylistTestPage();

		mylist.getMylistsLblWeeklygroceries().waitForPresent(3000);
		mylist.getMylistsLblWeeklygroceries().verifyPresent();
		mylist.getMylistsLblWeeklygroceries().click();
		PerfectoUtils.reportMessage("Clicked Weekly Grocery List.", MessageTypes.Pass);
	}

	/**
	 * Verify weekly grocery page is displayed and report
	 */
	@QAFTestStep(description = "I verify the weekly grocery page")
	public void iVerifyTheWeeklyGroceryPage() {
		MylistTestPage mylist = new MylistTestPage();

		if (mylist.getMylistsLblWeeklygroceries().isPresent()) {
			PerfectoUtils.reportMessage("Able to see selected ads", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see selected ads", MessageTypes.Fail);
		}
	}

	/**
	 * Click on the + icon to create new list
	 */
	@QAFTestStep(description = "I click on plus icon to add list")
	public void iClickOnPlusIconToAddList() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.getMyListsImgPlus().waitForPresent(5000);
		mylistpage.getMyListsImgPlus().click();
		PerfectoUtils.reportMessage("Clicked on Plus icon to Create a Shoppinglist.", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I see error message for invalid password after click on Login/Submit button")
	public void iSeeErrorMessageForInvalidPasswordAfterClickOnLoginSubmitButton() {
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		IOSStepdef.clickKeyboardDone();

		// Clicking on Submit button
		loginsplash.getLoginBtnLogin().waitForVisible(3000);
		loginsplash.getLoginBtnLogin().click();

		try {
			weeklygrocery.getShopingListEntryByLable("Login Error").waitForVisible(7000);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (weeklygrocery.getShopingListEntryByLable("Login Error").isPresent()) {
			PerfectoUtils.reportMessage("Log in Error occured Pop up is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Log In Error occured Pop up is not displayed", MessageTypes.Fail);
		}

		appCrash.getExceptionBtnOk().click();
		PerfectoUtils.reportMessage("Clicked Ok button in Login Error Popup", MessageTypes.Info);

	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I see the list name is not deleted in Android")
	public void iSeeTheListNameIsNotDeletedInAndroid() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Swiping across a selected list 'DeletedListName' to delete Update the
	 * list name in a variable If no list is available create new list and do
	 * the operation
	 * 
	 * @return DeletedListName
	 */
	@QAFTestStep(description = "I swipe across the name of a Shopping list and not clicking DELETE button")
	public void iSwipeAcrossTheNameOfAShoppingListAndNotClickingDELETEButton() {
		MylistTestPage myListPage = new MylistTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		myListPage.waitForPageToLoad();
		myListPage.getMyListLblLstNameHotUser().waitForVisible(3000);

		List<QAFWebElement> lstHotUSer = myListPage.getMyListLblLstNameHotUserItems();
		int intSize = lstHotUSer.size();

		if (intSize < 2) {
			iClickOnPlusIconToAddList();
			iShouldSeeThePopupToEnterListName();
			iEnterTheShoppingListName();
			iClickTheAddButton();
			ioscommon.getAppFooterShoppinglist().click();
		}

		intSize = myListPage.getMyListLblLstNameHotUserItems().size();
		String strFirstListName = myListPage.getMyListLblLstNameHotUserItems().get(intSize - 1).getText();
		getBundle().setProperty("DeletedListName", strFirstListName);
		Dimension size = getAppiumDriver().manage().window().getSize();

		int intStartX = (int) (size.width * 0.90);
		if (myListPage.getMyListLblLstNameHotUserItems().get(intSize - 1).getText().contains("Wish List")) {
			int intStartY = Integer.parseInt(myListPage.getMyListLblLstNameHotUserItems().get(0).getAttribute("Y"));
			int intEndX = Integer.parseInt(myListPage.getMyListLblLstNameHotUserItems().get(0).getAttribute("X"));
			strFirstListName = myListPage.getMyListLblLstNameHotUserItems().get(0).getText();
		}

		int intStartY = Integer
				.parseInt(myListPage.getMyListLblLstNameHotUserItems().get(intSize - 1).getAttribute("Y"));
		int intEndX = Integer.parseInt(myListPage.getMyListLblLstNameHotUserItems().get(intSize - 1).getAttribute("X"));

		getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);
		PerfectoUtils.reportMessage("Swiping across the list name: " + strFirstListName + " to delete");
	}

	/**
	 * Selecting the same list to cancel delete process
	 */
	@QAFTestStep(description = "I cancel the delete process by clicking on the same list")
	public void ICancelTheDeleteProcessByClickingOnTheSameList() {
		MylistTestPage myListPage = new MylistTestPage();

		int intSize = myListPage.getMyListLblLstNameHotUserItems().size();
		String strFirstListName = myListPage.getMyListLblLstNameHotUserItems().get(intSize - 1).getText();
		myListPage.getMyListLblLstNameHotUserItems().get(intSize - 1).click();
		PerfectoUtils.reportMessage("Clicked on the list name: " + strFirstListName + "  to cancel Delete process");

	}

	/**
	 * Clicks on Cancel button from the Login pop up
	 */
	@QAFTestStep(description = "I click Cancel button on login PopUp and see weekly grocery list in My list page")
	public void iClickCancelButtonOnLoginPopUp() {

		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Clicking on Skip and Continue as guest from login splash page.
	 */
	@QAFTestStep(description = "I click continue without registering as guest and see weekly grocery list in My list page")
	public void iClickContinueWithoutRegisteringAsGuest() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		IOSStepDefMyAccounts.hidekeypad();
		PerfectoUtils.verticalswipe();
		PerfectoUtils.verticalswipe();
		loginsplash.getLoginLblContinue().waitForVisible(5000);
		loginsplash.getLoginLblContinue().click();
		PerfectoUtils.reportMessage("Clicked Continue without registering as guest option..", MessageTypes.Pass);

		iSeeWeeklyGroceryListInMyListPage();
	}

	/**
	 * Verify the list 'DeletedListName' is present or not and report the status
	 * 
	 * @param list
	 *            name 'DeletedListName'
	 */
	@QAFTestStep(description = "I see the list name is not deleted in IOS")
	public void iSeeTheListNameIsNotDeletedInIOS() {
		AddtolistTestPage addtolistpage = new AddtolistTestPage();

		addtolistpage.waitForPageToLoad();
		String strDeletedList = getBundle().getPropertyValue("DeletedListName");

		/* Forming the dynamic object */
		boolean isListDisplayed = addtolistpage.getShopingListEntryByLable(strDeletedList).isPresent();
		if (isListDisplayed) {
			PerfectoUtils.reportMessage("List: " + strDeletedList + " is not deleted", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("List: " + strDeletedList + " is deleted", MessageTypes.Fail);
		}
	}

	/**
	 * Report this step not applicable for ios
	 */
	@QAFTestStep(description = "I select the Overflow/Edit icon from my list page in Android")
	public void iSelectTheOverflowIconFromMyListPageInAndroid() {
		PerfectoUtils.reportMessage("Step Not Applicable for iOS.", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify the Search screen is not visible on selecting Cancel button")

	public void verifyTheSearchScreenIsNotVisibleOnSelectingCancelButton() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		wgsearchresult.getWgLblSearchsrctext().waitForVisible(3000);
		wgsearchresult.getWgLblSearchsrctext().verifyPresent();

		if (listdetails.getListpageBtnCancel().isPresent()) {
			listdetails.getListpageBtnCancel().click();
			PerfectoUtils.reportMessage("Clicked on Cancel Search button.", MessageTypes.Pass);

			wgsearchresult.getWgLblSearchsrctext().waitForNotPresent(5000);

			if (!wgsearchresult.getWgLblSearchsrctext().isPresent()) {
				PerfectoUtils.reportMessage("Search screen is not visible on clicking Cancel button.", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Cancel Search failed.", MessageTypes.Fail);
			}

		} else {
			PerfectoUtils.reportMessage("Search Cancel button/option not found.", MessageTypes.Fail);
		}
	}

	/**
	 * Verify the more options are displayed
	 */
	@QAFTestStep(description = "I should see the list of options in list details page")
	public void iShouldSeeTheListOfOptionsInListDetailsPage() {
		ListdetailsTestPage listdetail = new ListdetailsTestPage();

		listdetail.getListpageLinkDeleteitem().verifyPresent();
		listdetail.getListpageLinkDeleteallitem().verifyPresent();
		listdetail.getListpageLinkUncheckitem().verifyPresent();
		listdetail.getListpageLinkCopytoanotherlist().verifyPresent();
		listdetail.getListpageBtnCancel().verifyPresent();
	}

	@QAFTestStep(description = "I see Search Field is displayed by clicking on Plus Icon")
	public void iSeeSearchFieldIsDisplayedByClickingOnPlusIcon() {

		ListdetailsTestPage obj = new ListdetailsTestPage();
		obj.getBtnsearchglass().click();
		PerfectoUtils.reportMessage("NA for iOS.", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify the Searched product is not added to the list")
	public void verifyTheSearchedProductIsNotAddedToTheList() {
		WeeklygroceriesTestPage weeklygroceries = new WeeklygroceriesTestPage();

		if (weeklygroceries.getBtnMore().isPresent()) {
			PerfectoUtils.reportMessage("Navigated back to List page.", MessageTypes.Pass);
			PerfectoUtils.reportMessage("Searched Product not added to the list.");
		} else {
			PerfectoUtils.reportMessage("Error occured while navigating back.", MessageTypes.Fail);
		}
	}

	public void iSelectASpecificItem(int i) throws InterruptedException {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();

		// click on specific item (2nd item) displays in search result page
		String strSpecificPdtName = null;

		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		try {
			wgsearchresult.getListSearchListName().get(i).waitForPresent(80000);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Page didnt load, server issue!!", MessageTypes.Fail);
		}

		int intListSize = wgsearchresult.getListSearchListName().size();
		wgsearchresult.getListSearchListName().get(intListSize - i).waitForPresent(3000);
		strSpecificPdtName = wgsearchresult.getListSearchListName().get(intListSize - i).getText();

		getBundle().setProperty("ChoosenProduct", strSpecificPdtName);
		getBundle().setProperty("productName", strSpecificPdtName);
		click("name=" + strSpecificPdtName);
	}

	/**
	 * verify the my list page is not displayed
	 */
	@QAFTestStep(description = "I verify the error popup for invalid scan")
	public void iVerifyTheErrorPopupForInvalidScan() {
		ScannerTestPage scanner = new ScannerTestPage();
		ListdetailsTestPage listdetails = new ListdetailsTestPage();

		if (scanner.getLblProductnotfound().isPresent()) {
			PerfectoUtils.reportMessage("Product Not Found popup is displayed..", MessageTypes.Pass);
			scanner.getAppscanBtnCanceladdtolist().click();

			listdetails.getPageLinkScanproduct().waitForVisible(3000);
			PerfectoUtils.reportMessage("Scan prouduct page is displayed..");
		} else
			PerfectoUtils.reportMessage("popup not found.", MessageTypes.Fail);

	}

	@QAFTestStep(description = "I verify that the process is cancelled")
	public void iverifythattheprocessiscancelled() {

		IoscommonTestPage ioscommon = new IoscommonTestPage();
		if (!ioscommon.getAddtolistBtnDone().isPresent()) {
			PerfectoUtils.reportMessage("Copy process cancelled ", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I cancel the process of sending an email")
	public void icanceltheprocessofsendinganemail() {
		SendemailTestPage sendemail = new SendemailTestPage();

		try {
			sendemail.getSendemailBtnCancel().waitForPresent(30000);
			sendemail.getSendemailBtnCancel().click();
			PerfectoUtils.reportMessage("Email process is cancelled", MessageTypes.Pass);
		} catch (Exception e) {
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("content", "Cancel");
			String isClicked = (String) sendemail.getTestBase().getDriver().executeScript("mobile:text:select", param);

			if (isClicked.equals("true"))
				PerfectoUtils.reportMessage("Email process is cancelled", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Email process is not cancelled", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I cancel the process of replacing generic item")
	public void icanceltheprocessofreplacinggenericitem() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();
		wgsearchresult.getWgBtnSearchresultCancel().waitForVisible(2000);

		wgsearchresult.getWgBtnSearchresultCancel().click();
		int intListSize = weeklygrocery.getWgListItemlist().size();
		getItemCountFromListPage();
		for (int i = 1; i <= intListSize; i++) {
			ShoppinglistResult product = weeklygrocery.getWgListItemlist().get(i - 1);
			if ((weeklygrocery.getShopingListitemNameByLable(i).getText())
					.equalsIgnoreCase(getBundle().getString("productName"))) {
				if (product.getWgListSelectsspecificitem().isPresent()) {
					PerfectoUtils.reportMessage("Replacing process cancelled ", MessageTypes.Pass);
				}
				break;
			}

		}
	}

	@QAFTestStep(description = "I swipe across the name of the first item")
	public void iswipeacrossthenameofthefirstitem() {

		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		int count = weeklygrocery.getWgChkShoppingitemList().size();
		System.out.println(count);
		Dimension size = getAppiumDriver().manage().window().getSize();
		String prod = weeklygrocery.getWgChkShoppingitemList().get(count - 1).getText();
		// System.out.println(prod);
		int intStartX = (int) (size.width * 0.90);

		int intStartY = Integer.parseInt(weeklygrocery.getWgChkShoppingitemList().get(count - 1).getAttribute("Y"));
		int intEndX = Integer.parseInt(weeklygrocery.getWgChkShoppingitemList().get(count - 1).getAttribute("X"));

		getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);

	}

	@QAFTestStep(description = "I cancel the delete process by clicking on the same item name")
	public void icancelthedeleteprocessbyclickingonthesameitemname() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		int arrowSize = weeklygrocery.getBtnRightarrow().size();
		weeklygrocery.getBtnRightarrow().get(arrowSize - 1).waitForPresent(3000);
		weeklygrocery.getBtnRightarrow().get(arrowSize - 1).click();
		PerfectoUtils.reportMessage("Deleting process cancelled ", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I select Delete Item option")
	public void iselectDeleteItemoption() {
		PerfectoUtils.reportMessage("NA for IOS", MessageTypes.Info);
	}

	@QAFTestStep(description = "I cancel the process of deleting element")
	public void icanceltheprocessofdeletingelement() {
		PerfectoUtils.reportMessage("NA for IOS", MessageTypes.Info);
	}

	/**
	 * Click device back button from product details page Verify the list item
	 * details page is displayed on back button, from where we navigated to
	 * product details page
	 */
	@QAFTestStep(description = "I see list product details page on clicking device back button")
	public void iSeeListProductDetailsPageOnClickingDeviceBackButton() {
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();
		PdtdetailspagefromlistTestPage productdetails = new PdtdetailspagefromlistTestPage();

		ioscommonpage.getAppBtnBackIOS().verifyPresent();
		ioscommonpage.getAppBtnBackIOS().click();

		productdetails.getProductdetailsTxtPagetitle().waitForVisible(10000);
		productdetails.getProductdetailsTxtPagetitle().verifyPresent();

	}

	/**
	 * Verify device navigated back to selected list page by clicking cancel
	 * button and verifying list search icon
	 */
	@QAFTestStep(description = "I see the <List name> page on selecting device back button once")
	public void iSeeTheListNamePageOnSelectingDeviceBackButtonOnce() {
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();

		if (listDetailspage.getListpageBtnCancel().isPresent()) {
			listDetailspage.getListpageBtnCancel().click();
		} else if (ioscommonpage.getAppBtnBackIOS().isPresent()) {
			ioscommonpage.getAppBtnBackIOS().click();
		}

		if (listDetailspage.getBtnSearchicon().isPresent()) {
			PerfectoUtils.reportMessage("List Details Page is dispalyed successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("List Details Page is not displayed", MessageTypes.Fail);
		}

	}

	/**
	 * Click device back button from product details page Verify the non empty
	 * list is displayed on back button, from where we navigated to product
	 * details page
	 */
	@QAFTestStep(description = "I see Weekly Groceries page on clicking device back button once")
	public void iSeeWeeklyGroceriesPageOnClickingDeviceBackButtonOnce() {
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();
		MylistTestPage mylist = new MylistTestPage();

		ioscommonpage.getAppBtnBackIOS().verifyPresent();
		ioscommonpage.getAppBtnBackIOS().click();

		mylist.getMylistsLblWeeklygroceries().waitForVisible(5000);

		String getPageTitle = mylist.getMylistsLblWeeklygroceries().getText();
		if (getPageTitle.equals("Weekly Grocery List")) {
			PerfectoUtils.reportMessage("Weekly Groceries page is displayed successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Weekly Groceries page is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify products with multiple images")
	public void iVerifyProductsWithMultipleImages() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		int size = productdetails.getLblPaginationDots().size();
		int i = 0;
		while (i < size) {
			if (productdetails.getLblPaginationDots().get(i).isPresent()) {
				productdetails.getImgSecondProductImage().get(i).verifyPresent();
				PerfectoUtils.reportMessage("Image is present ", MessageTypes.Pass);
				PerfectoUtils.rightSwipe();
				i++;
				productdetails.getLblPaginationDots().get(i).waitForPresent(3000);
			} else {
				PerfectoUtils.reportMessage("Pagination dots are not available", MessageTypes.Fail);
			}
		}

	}

}
