package com.heb.automation.common.pages.registeration;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class DCEnrollmentTestPage extends WebDriverBaseTestPage<com.qmetry.qaf.automation.ui.api.WebDriverTestPage> {

	@FindBy(locator = "dc.lbl.pagetitle")
	private QAFWebElement lblPagetitle;
	@FindBy(locator = "dc.txt.mobilenumber")
	private QAFWebElement txtMobilenumber;
	@FindBy(locator = "dc.txt.4digitpin")
	private QAFWebElement txt4digitpin;
	@FindBy(locator = "dc.chk.termsandconditions")
	private QAFWebElement chkTermsandconditions;
	@FindBy(locator = "dc.btn.submit")
	private QAFWebElement btnSubmit;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblPagetitle() {
		return lblPagetitle;
	}

	public QAFWebElement getTxtMobilenumber() {
		return txtMobilenumber;
	}

	public QAFWebElement getTxt4digitpin() {
		return txt4digitpin;
	}

	public QAFWebElement getChkTermsandconditions() {
		return chkTermsandconditions;
	}

	public QAFWebElement getBtnSubmit() {
		return btnSubmit;
	}
}
