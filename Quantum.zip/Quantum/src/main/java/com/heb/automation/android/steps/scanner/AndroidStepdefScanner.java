package com.heb.automation.android.steps.scanner;

import java.util.HashMap;
import java.util.Map;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.android.steps.AndroidStepDef;
import com.heb.automation.android.steps.shoppinglist.AndroidStepDefShoppingList;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.scanner.ScanProductsTestPage;
import com.heb.automation.common.pages.scanner.ScannerTestPage;
import com.heb.automation.common.pages.shoppinglist.ListdetailsTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in Scanner

	I navigate to Scan Products screen
	Verify the elements in Scan products screen
	I should see the scanned product in the selected list
	I click on Cancel button from the add to list popup
	I click on add to list buttom from the popup
	Verify the Scan receipt option is not present for cold user
	I click on add to list buttom from the popup for receipt*/


public class AndroidStepdefScanner {

	/**
	 * Navigating to Scan product screen
	 */
	@QAFTestStep(description = "I navigate to Scan Products screen")
	public void iNavigateToScanProductsScreen() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();
		ScannerTestPage scantest = new ScannerTestPage();

		listDetailspage.getListpageBtnScanmenu().waitForPresent();
		listDetailspage.getListpageBtnScanmenu().click();
		if (androidcommon.getScanTxtScanproduct().isPresent())
			androidcommon.getScanTxtScanproduct().click();

		PerfectoUtils.reportMessage("Clicked on Scan product", MessageTypes.Info);

		if (scantest.getLblAccesscamerapopuptitle().isPresent()) {
			PerfectoUtils.reportMessage("Allow H-E-B to take pictures and record video?", MessageTypes.Info);
			androidcommon.getAppPopupBtnAllowPermission().verifyPresent();
			androidcommon.getAppPopupBtnAllowPermission().click();
		}

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Unfortunately, H-E-B has stopped.");
		String errmsg1 = (String) androidcommon.getTestBase().getDriver().executeScript("mobile:text:find", params1);

		if (errmsg1.equals("true")) {
			PerfectoUtils.reportMessage("Scan Product Failed due to 'Unfortunately, H-E-B has stopped.'", MessageTypes.Fail);
			params1.put("content", "OK");
			androidcommon.getTestBase().getDriver().executeScript("mobile:text:select", params1);
		}

		if (androidcommon.getScanLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Scan Products page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Scan Products page", MessageTypes.Fail);
		}
	}
	
	/**
	 * Validating the elements in Scan products page
	 */
	@QAFTestStep(description = "Verify the elements in Scan products screen")
	public void verifyTheElementsInScanProductsScreen() {
		ScanProductsTestPage scanprdts = new ScanProductsTestPage();
		
		scanprdts.getLblPagetitle().verifyPresent();
		scanprdts.getLblScandescription().verifyPresent();
		scanprdts.getLblMultiscanswitch().verifyPresent();
		
	}

	/**
	 * Verification of scanned product in selected list.
	 */
	@QAFTestStep(description = "I should see the scanned product in the selected list")
	public void iShouldSeeTheScannedProductInTheSelectedList() {
		WeeklygroceriesTestPage weeklygroceries = new WeeklygroceriesTestPage();
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		/*Checking whether the page has been navigated to List Details page*/
		if (listdetails.getListpageLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to " + listdetails.getListpageLblPagetitle().getText() + " page.",
					MessageTypes.Pass);

			int getitemcount = weeklygroceries.getWgListItemlist().size();
			
			/*Checking whether the scanned product is available in the list*/
			if (getitemcount == 1) {
				PerfectoUtils.reportMessage("Scanned product is available in the list", MessageTypes.Pass);
			} else {
				try {

				} catch (Exception e) {
					PerfectoUtils.reportMessage("Scanned product is not available in the list", MessageTypes.Fail);
				}
			}
		} else {
			String strCount = weeklygrocery.getWgTxtShoppingitemcount().getText();
			if (strCount.contains("Items")) {
				strCount = strCount.replace("Items", "").trim();
			} else if (strCount.contains("Item")) {
				strCount = strCount.replace("Item", "").trim();
			}
			int intCount = Integer.parseInt(strCount);
			if (intCount == 1) {
				PerfectoUtils.reportMessage("Scanned product is available in the list", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Scanned product is not available in the list", MessageTypes.Fail);
			}
		}

		/*Stopping Image injection*/
		PerfectoUtils.stopimageinjection();
	}

	/**
	 * Clicking on Cancel button. Verification of Add to List pop up.
	 */
	@QAFTestStep(description = "I click on Cancel button from the add to list popup")
	public void iClickOnCancelButtonFromTheAddToListPopup() {
		ScannerTestPage scanner = new ScannerTestPage();
		String repositoryFile = ConfigurationManager.getBundle().getString("scanner.reporitoryimage.scanproducts1");

		if (!scanner.getAppscanBtnAddtolist().isPresent()
				&& ((scanner.getAppscanBtnAddtolist().getAttribute("hidden")).equals("false"))) {
			PerfectoUtils.androiddeviceback();
			AndroidStepDef.iNavigateAndScanTheItemFromScanProductsScreen(repositoryFile);
		}
		
		try{
			scanner.getAppscanBtnAddtolist().waitForPresent(50000);
		}catch(Exception e){
			// Ignore
		}

		/*Verify whether the "Add to list" pop-up is present*/
		if (scanner.getAppscanBtnAddtolist().isPresent()) {
			scanner.getAppscanBtnCanceladdtolist().click();
			PerfectoUtils.reportMessage("Clicked Cancel button from the popup.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Add to list popup not present.", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking on Add to List from Pop up.Handling the error pop up.
	 */
	@QAFTestStep(description = "I click on add to list buttom from the popup")
	public void iClickOnAddToListButtomFromThePopup() {
		ScannerTestPage scanner = new ScannerTestPage();
		String repositoryFile = ConfigurationManager.getBundle().getString("scanner.reporitoryimage.scanproducts1");

		try {
			scanner.getAppscanBtnAddtolist().waitForPresent(10000);
		} catch (Exception e) {
			if (!scanner.getAppscanBtnAddtolist().isPresent()) {
				PerfectoUtils.androiddeviceback();
				AndroidStepDef.iNavigateAndScanTheItemFromScanProductsScreen(repositoryFile);
			}
		}
	

		/*Verify whether the "Add to list" pop-up is present*/
		if (scanner.getAppscanBtnAddtolist().isPresent()
				&& ((scanner.getAppscanBtnAddtolist().getAttribute("hidden")).equals("false"))) {
			scanner.getAppscanBtnAddtolist().click();
			PerfectoUtils.reportMessage("Clicked Add to list button from the popup.", MessageTypes.Pass);
			if (scanner.getAppscanBtnAddtolist().isPresent()) {
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", "ADD TO LIST");
				scanner.getTestBase().getDriver().executeScript("mobile:text:select", params1);
			}
			if (scanner.getScanlblTitle().isPresent()) {
				PerfectoUtils.reportMessage("Please provide a valid receipt id.we are unable to find receipt number.",
						MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("Add to list popup not present.", MessageTypes.Fail);
		}

		/* Handling the error pop-up */
		if (scanner.getLblErrorpopuptitle().isPresent()) {
			PerfectoUtils.reportMessage("Error occured!" + scanner.getLblErrorpopupcontent().getText(), MessageTypes.Fail);
			scanner.getBtnOkbtnerrorpopup().click();
		}

	}
	
	/**
	 * Validating the elements in Scan products page
	 */
	@QAFTestStep(description = "Verify the Scan receipt option is not present for cold user")
	public void verifyTheScanReceiptOptionIsNotPresentForColdUser() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		
		listdetails.getListpageBtnScanmenu().waitForPresent(1000);
		listdetails.getListpageBtnScanmenu().click();
		
		if(!listdetails.getListpageLinkScanreciept().isPresent()){
			PerfectoUtils.reportMessage("Scan Receipt option not available for cold user as expected.",MessageTypes.Pass);
		} else{
			PerfectoUtils.reportMessage("Found Scan Receipt option for cold user.",MessageTypes.Fail);
		}
		
	}
	
	/**
	 * Clicking on Add to List from Pop up.Handling the error pop up.
	 */
	@QAFTestStep(description = "I click on add to list buttom from the popup for receipt")
	public void iClickOnAddToListButtomFromThePopupForReceipt() {
		ScannerTestPage scanner = new ScannerTestPage();
		AndroidStepDefShoppingList andStepDefShop = new AndroidStepDefShoppingList();
		AndroidStepDef andStepDef = new AndroidStepDef();
		String repositoryFile = ConfigurationManager.getBundle().getString("scanner.reporitoryimage.scanproducts1");

		try {
			scanner.getAppscanBtnAddtolist().waitForPresent(10000);
		} catch (Exception e) {
			if (!scanner.getAppscanBtnAddtolist().isPresent()) {
				PerfectoUtils.androiddeviceback();
				andStepDefShop.iSelectTheSearchBoxFromListDetailPage();
				andStepDef.iNavigateAndScanTheReceiptFromScanReceiptScreen();
			}
		}
	

		/*Verify whether the "Add to list" pop-up is present*/
		if (scanner.getAppscanBtnAddtolist().isPresent()
				&& ((scanner.getAppscanBtnAddtolist().getAttribute("hidden")).equals("false"))) {
			scanner.getAppscanBtnAddtolist().click();
			PerfectoUtils.reportMessage("Clicked Add to list button from the popup.", MessageTypes.Pass);
			if (scanner.getAppscanBtnAddtolist().isPresent()) {
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", "ADD TO LIST");
				scanner.getTestBase().getDriver().executeScript("mobile:text:select", params1);
			}
			if (scanner.getScanlblTitle().isPresent()) {
				PerfectoUtils.reportMessage("Please provide a valid receipt id.we are unable to find receipt number.",
						MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("Add to list popup not present.", MessageTypes.Fail);
		}

		/* Handling the error pop-up */
		if (scanner.getLblErrorpopuptitle().isPresent()) {
			PerfectoUtils.reportMessage("Error occured!" + scanner.getLblErrorpopupcontent().getText(), MessageTypes.Fail);
			scanner.getBtnOkbtnerrorpopup().click();
		}

	}
}
