package com.heb.automation.common.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class StoreDetailModel extends QAFWebComponent {

	@FindBy(locator = "pdp.storemodal.storename")
	private QAFWebElement storename;
	@FindBy(locator = "pdp.storemodal.storeaddress")
	private QAFWebElement storeaddress;
	@FindBy(locator = "pdp.storemodal.storemiles")
	private QAFWebElement storemiles;
	@FindBy(locator = "pdp.storemodal.storeaisle")
	private QAFWebElement storeaisle;

	public StoreDetailModel(String locator) {
		super(locator);
	}

	public QAFWebElement getstorename() {
		return storename;
	}

	public QAFWebElement getstoreaddress() {
		return storeaddress;
	}

	public QAFWebElement getstoremiles() {
		return storemiles;
	}

	public QAFWebElement getstoreaisle() {
		return storeaisle;
	}
}
