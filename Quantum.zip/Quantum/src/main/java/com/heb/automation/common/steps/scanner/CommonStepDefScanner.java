/**
 * 
 */
package com.heb.automation.common.steps.scanner;

import com.heb.automation.android.steps.AndroidStepDef;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.products.ProductdetailTestPage;
import com.heb.automation.common.pages.shoppinglist.ListdetailsTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in Common Scanner
	
	I should see the PDP page of scanned product
	I should see the scanned receipt items in the selected list*/



public class CommonStepDefScanner {

	/**
	 * Verifying the PDP page after scanning the product
	 */
	@QAFTestStep(description = "I should see the PDP page of scanned product")
	public void iShouldSeeThePDPPageOfScannedProduct() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();
		String repositoryFile = ConfigurationManager.getBundle().getString("scanner.reporitoryimage.scanproducts1");

		productdetails.getPdpLblProductname().waitForPresent(50000);

		if (!productdetails.getPdpLblProductname().isPresent()) {
			PerfectoUtils.androiddeviceback();
			AndroidStepDef.iNavigateAndScanTheItemFromScanProductsScreen(repositoryFile);
		}

		if (productdetails.getPdpLblProductname().isPresent()) {
			PerfectoUtils.reportMessage("Scanned the product successfully and navigated to PDP page.", MessageTypes.Pass);
			PerfectoUtils.reportMessage("Product name:" + productdetails.getPdpLblProductname().getText(), MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to the PDP page.", MessageTypes.Fail);
		}
	}

	/**
	 * Verifying the scanned items for scanned receipt.
	 */
	@QAFTestStep(description = "I should see the scanned receipt items in the selected list")
	public void iShouldSeeTheScannedReceiptItemsInTheSelectedList() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();

		// Checking whether the page has been navigated to List Details page
		if (listdetails.getListpageLblItemNameList().size() > 0) {
			PerfectoUtils.reportMessage("Navigated to " + listdetails.getListpageLblPagetitle() + " page.", MessageTypes.Pass);

			if (listdetails.getListpageLblShoppingitemcount().isPresent())
				PerfectoUtils.reportMessage("Scanned Receipt items are present in the list: " + listdetails.getListpageLblPagetitle(),
						MessageTypes.Pass);

		} else {
			PerfectoUtils.reportMessage("Items not added to the list...", MessageTypes.Fail);
		}
	}

}
