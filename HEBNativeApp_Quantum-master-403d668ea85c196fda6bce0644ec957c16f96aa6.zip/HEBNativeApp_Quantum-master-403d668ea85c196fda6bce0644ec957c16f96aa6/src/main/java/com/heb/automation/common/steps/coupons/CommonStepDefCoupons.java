package com.heb.automation.common.steps.coupons;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.ShareTestPage;
import com.heb.automation.common.pages.coupons.CouponsdetailsTestPage;
import com.heb.automation.common.pages.coupons.CouponssearchresultTestPage;
import com.heb.automation.common.pages.coupons.CouponsselectionTestPage;
import com.heb.automation.common.pages.coupons.LifetimeSavingsBannerTestPage;
import com.heb.automation.common.pages.registeration.CancelregistrationTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.pages.shoppinglist.LoginpopupTestPage;
import com.heb.automation.ios.steps.IOSStepdef;
import com.heb.automation.ios.steps.shoppinglist.IOSStepdefshopinglist;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in Common Coupons

	I click Selected option in Details page
	I should see the Register and LogIn button in coupon selection page
	I Click on Register
	I validate Coupons selection page
	I validate Total Available section
	I validate coupons detail page
	I enter valid credential {0} and {1}
	I navigate to login page after clicking login button
	I navigate back to Coupons page from login page
	I click on yes button
	I should see the signup or login popup
	I should see the Coupons details page
	I select the sort button
	I click on SELECT from coupons detail page
	I validate the message after clickng on Select button
	I navigate to registration page from coupons selection page
	I verify user registered account
	I click on Login from coupons details page
	I validate the limit description
	I validate digital coupons page
	I validate coupons landing page for Resend Confirmation user
	I validate the sort button
	I navigate to email page on clicking share icon
	I Click on Register from Coupons details page
	I should not see Add to List option
	I navigate to Product List modal
	I verify the Product List modal page
	I navigate back to coupon detail page by closing out the modal
	I add a product to the list
	I verify product added to list message
	I click on any row in the product list
	I verify that sign up now button is not present in the page
	I verify redeem button on selected tab
	I should see Selected Savings tab
	I see Unselect All button in coupon selection page
	I see All Coupons are checked
	I select Unselect button
	I see All coupons are unchecked
	I verify the various sort option
	I validate Selected Savings tab
	Verify Lifetime Coupon Savings banner is static
	Verify the banner amount is zero when no coupons have been redeemed
	Verify the banner amount is zero after first enrolling in Digital Coupons
	Verify the amount is preceded by a dollar sign on Lifetime Coupon Savings banner
	I verify the Lifetime Coupons Savings banner is not present
	I verify the static icon on the Lifetime Coupons Savings banner
	I verify Your Lifetime Savings text on the banner
	I verify the dollar amount saved on the banner
	I verify division line is between the Lifetime Coupon Savings banner and the Coupons page
	I verify Lifetime Coupon Savings banner on the Available tab
	I verify Lifetime Coupon Savings banner on the Selected tab
*/


public class CommonStepDefCoupons {
	/**
	 * user clicks selected option in details page
	 */
	@QAFTestStep(description = "I click Selected option in Details page")
	public void iClickSelectedOptionInDetailsPage() {
		CouponsdetailsTestPage couponsdetail = new CouponsdetailsTestPage();

		couponsdetail.getCoupondetailsBtnSelect().click();
		PerfectoUtils.androiddeviceback();
	}

	/**
	 * user should see the Register and LogIn button in coupon selection page
	 */
	@QAFTestStep(description = "I should see the Register and LogIn button in coupon selection page")
	public void iShouldSeeTheRegisterAndLogInButtonInCouponSelectionPage() {
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		CouponsselectionTestPage selectcoupons = new CouponsselectionTestPage();

		if (!appcrash.getExceptionSkipCoupons().isPresent()) {
			selectcoupons.getCouponsBtnLogin().verifyPresent();
			selectcoupons.getCouponsBtnRegister().verifyPresent();
		} else {
			System.out.println("skipper is present");
			appcrash.getExceptionSkipCoupons().click();
		}
	}

	/**
	 * user clicks on register
	 */
	@QAFTestStep(description = "I Click on Register")
	public void iClickOnRegister() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponsBtnRegister().waitForPresent(5000);
		couponsselection.getCouponsBtnRegister().click();
		PerfectoUtils.reportMessage("Clicked on Register.");
	}

	/**
	 * user validated the coupon selection page
	 */
	@QAFTestStep(description = "I validate Coupons selection page")
	public void iValidateCouponsSelectionPage() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponselectionLblAllcoupons().verifyPresent();
		couponsselection.getCouponsLblCoupondesc().verifyPresent();
		couponsselection.getLblYouMustLoginText().verifyPresent();

		String strTtlavailCount = couponsselection.getCouponselectionLblAllcoupons().getText();
		strTtlavailCount = strTtlavailCount.replaceAll("All Coupons", "");
		strTtlavailCount = strTtlavailCount.replaceAll("\\(", "").replaceAll("\\)", "");

		if (couponsselection.getCouponsLblAvailable().isPresent()) {
			PerfectoUtils.reportMessage("Coupons Selection Page is validated and total available coupons are: " + strTtlavailCount,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons Selection Page is not applicable with the latest build", MessageTypes.Fail);
		}
	}

	/**
	 * user validate total available section
	 */
	@QAFTestStep(description = "I validate Total Available section")
	public void iValidateTotalAvailableSection() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponsLblCoupondesc().verifyPresent();
		String strTtlavailCount = couponsselection.getCouponselectionLblAllcoupons().getText();

		strTtlavailCount = strTtlavailCount.replaceAll("All Coupons ", "");
		strTtlavailCount = strTtlavailCount.replaceAll("\\(", "").replaceAll("\\)", "");

		if (couponsselection.getCouponsLblAvailable().verifyPresent()) {
			PerfectoUtils.reportMessage("Available section is validated and total available coupons are: " + strTtlavailCount,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Available section is not populated", MessageTypes.Fail);
		}
	}

	/**
	 * User validate coupons detail page
	 */
	@QAFTestStep(description = "I validate coupons detail page")
	public void iValidateCouponsDetailPage() {
		CouponsdetailsTestPage couponsdetailspage = new CouponsdetailsTestPage();

		couponsdetailspage.getLblPagetitle().verifyPresent();
		couponsdetailspage.getCouponsdetailBtnShare().verifyPresent();
		couponsdetailspage.getCouponsdetailLblImageview().verifyPresent();

		couponsdetailspage.getCouponsdetailLblCoupontitle().verifyPresent();
		couponsdetailspage.getCouponsdetailLblCouponexpirationlabel().verifyPresent();
		PerfectoUtils.verticalswipe();
		couponsdetailspage.getCouponsdetailLblCouponterms().verifyPresent();
	}

	/**
	 * user enter valid credential and logs in
	 * 
	 * @param username
	 * @param password
	 */
	@QAFTestStep(description = "I enter valid credential {0} and {1}")
	public static void iEnterValidCredentialAnd(String username, String password) {
		LoginpopupTestPage loginpopup = new LoginpopupTestPage();
		LoginsplashTestPage loginspalshpage = new LoginsplashTestPage();
		loginpopup.waitForPageToLoad();

		// Passing user name and password
		if (loginpopup.getLoginpopupTxtfldEmail().isPresent()) {
			loginpopup.getLoginpopupTxtfldEmail().sendKeys(username);
			loginpopup.getLoginpopupTxtfldPassword().sendKeys(password);
			PerfectoUtils.reportMessage("Entering credential in login pop up", MessageTypes.Pass);
		} else if (loginspalshpage.getLoginTxtEmail().isPresent()) {
			// Passing user name and password
			loginspalshpage.getLoginTxtEmail().sendKeys(username);
			loginspalshpage.getLoginTxtPassword().sendKeys(password);
			PerfectoUtils.reportMessage("Entering credential in login splash page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Error occured while entering the credentials.", MessageTypes.Pass);
		}
	}

	/**
	 * user is navigated to login page after clicking login button
	 */
	@QAFTestStep(description = "I navigate to login page after clicking login button")
	public void iNavigateToLoginPageAfterClickingLoginButton() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		LoginsplashTestPage loginpage = new LoginsplashTestPage();

		// Clicking on Login Button
		couponsselection.getCouponsBtnLogin().waitForPresent(5000);
		couponsselection.getCouponsBtnLogin().click();

		if (loginpage.getLblPopuplogin().isPresent()) {
			PerfectoUtils.reportMessage("Login page is displayed successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Login page is not displayed", MessageTypes.Fail);
		}
	}

	/**
	 * user navigate back to Coupons page from login page
	 */
	@QAFTestStep(description = "I navigate back to Coupons page from login page")
	public void iNavigateBackToCouponsPageFromLoginPage() {
		CouponsselectionTestPage couponselection = new CouponsselectionTestPage();
		CancelregistrationTestPage cancelregistration = new CancelregistrationTestPage();

		PerfectoUtils.hidekeyboard();
		PerfectoUtils.androiddeviceback();
		cancelregistration.waitForPageToLoad();

		if (couponselection.getCouponselectionLblAllcoupons().isPresent()) {
			PerfectoUtils.reportMessage("Navigated back to Coupons selection page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated back to Coupons selection page.", MessageTypes.Fail);
		}
	}

	/**
	 * user click on yes button
	 */
	@QAFTestStep(description = "I click on yes button")
	public void iClickOnYesButton() {
		CancelregistrationTestPage cancelregisteration = new CancelregistrationTestPage();
		if (cancelregisteration.getCancelregistrationBtnYes().isPresent()) {
			cancelregisteration.getCancelregistrationBtnYes().click();
			PerfectoUtils.reportMessage("clicked:", MessageTypes.Pass);
		}
	}

	/**
	 * user should see the signup or login popu
	 */
	@QAFTestStep(description = "I should see the signup or login popup")
	public void iShouldSeeTheSignupOrLoginPopup() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		try {
			couponsselection.getCouponsPopupSignupOrSignin().waitForPresent(5000);
			if (couponsselection.getCouponsPopupSignupOrSignin().isPresent()) {
				PerfectoUtils.reportMessage("The pop-up has been displayed as expected", MessageTypes.Pass);
				PerfectoUtils.reportMessage("Message" + couponsselection.getCouponsPopupSignupOrSignin().getText(), MessageTypes.Info);
				appcrash.getExceptionBtnOk().click();
				couponsselection.getCouponsLblSelected().waitForPresent(5000);
			} else {
				PerfectoUtils.reportMessage("The pop-up has not been displayed as expected!!", MessageTypes.Fail);
			}
		} catch (Exception e) {
			if (couponsselection.getCouponsPopupSignupOrSignin().isPresent()) {
				appcrash.getExceptionBtnOk().click();
				couponsselection.getCouponsLblSelected().waitForPresent(5000);
			}
		}

	}

	/**
	 * user should see the Coupons details page
	 */
	@QAFTestStep(description = "I should see the Coupons details page")
	public void iShouldSeeTheCouponsDetailsPage() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();

		couponsdetails.getCouponsdetailLblPagetitle().waitForPresent(4000);
		if (couponsdetails.getCouponsdetailLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to coupons details page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to coupons details page.", MessageTypes.Fail);
		}
	}

	/**
	 * user select the sort button
	 */
	@QAFTestStep(description = "I select the sort button")
	public static void iSelectTheSortButton() {

		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponsBtnSort().waitForPresent(5000);
		couponsselection.getCouponsBtnSort().click();
	}

	/**
	 * user click on SELECT from coupons detail page
	 */
	@QAFTestStep(description = "I click on SELECT from coupons detail page")
	public void iClickOnSELECTFromCouponsDetailPage() {
		CouponsdetailsTestPage couponsdetail = new CouponsdetailsTestPage();
		CouponssearchresultTestPage couponsSearchresultPage = new CouponssearchresultTestPage();

		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		if (dcAutoEnrolFlag.contains("true")) {
			PerfectoUtils.verticalswipe();
			couponsdetail.getCoupondetailsBtnSelect().waitForPresent(5000);
			couponsdetail.getCoupondetailsBtnSelect().click();
			couponsdetail.waitForPageToLoad();

			if (couponsdetail.getLblPopupdcerrortitle().isPresent()) {
				PerfectoUtils.reportMessage("Popup found- Digital Coupons Error", MessageTypes.Fail);
				couponsdetail.getBtnPopupdcerrorok().click();
				PerfectoUtils.reportMessage("Clicked Ok buton from the popup");
			}
		} else {
			PerfectoUtils.reportMessage("DCAutoEnrol flag is false");
			if (couponsSearchresultPage.getBtnsignupnow().isPresent())
				PerfectoUtils.reportMessage("Cannot select the coupon..Need to signup..");
			else {
				PerfectoUtils.verticalswipe();
				couponsdetail.getCoupondetailsBtnSelect().waitForPresent(5000);
				couponsdetail.getCoupondetailsBtnSelect().click();
				couponsdetail.waitForPageToLoad();

				if (couponsdetail.getLblPopupdcerrortitle().isPresent()) {
					PerfectoUtils.reportMessage("Popup found- Digital Coupons Error", MessageTypes.Fail);
					couponsdetail.getBtnPopupdcerrorok().click();
					PerfectoUtils.reportMessage("Clicked Ok buton from the popup");
				}
			}
		}
	}

	/**
	 * User validate the message after clickng on Select button
	 */
	@QAFTestStep(description = "I validate the message after clickng on Select button")
	public void iValidateTheMessageAfterClickngOnSelectButton() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		CouponssearchresultTestPage couponResult = new CouponssearchresultTestPage();

		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		if (dcAutoEnrolFlag.contains("true")) {
			couponsdetails.getCoupondetailsBtnSelect().waitForPresent(5000);
			PerfectoUtils.verticalswipe();
			if (!couponsdetails.getCoupondetailsBtnSelect().isPresent()) {
				PerfectoUtils.verticalswipe();
			}
			couponsdetails.getCoupondetailsBtnSelect().click();

			// Wait for Select button to be invisible
			couponsdetails.getCoupondetailsBtnSelect().waitForPresent(5000);
			if ((couponsdetails.getCoupondetailsBtnSelect().getAttribute("enabled")).equals("false")) {
				PerfectoUtils.reportMessage("Coupon is selected", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Coupon is not selected", MessageTypes.Fail);
			}

		} else {
			if (!couponResult.getBtnsignupnow().isPresent()) {
				couponsdetails.getCoupondetailsBtnSelect().click();

				// Wait for Select button to be invisible
				couponsdetails.getCoupondetailsBtnSelect().waitForPresent(5000);
				if ((couponsdetails.getCoupondetailsBtnSelect().getAttribute("enabled")).equals("false")) {
					PerfectoUtils.reportMessage("Coupon is selected", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Coupon is not selected", MessageTypes.Fail);
				}
			} else {
				if (couponResult.getBtnsignupnow().isPresent())
					PerfectoUtils.reportMessage("Cannot select coupon, sign up for coupon..", MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("Signup now button is not displayed", MessageTypes.Fail);
			}
		}
	}

	/**
	 * user is navigated to registration page from coupons selection page
	 */
	@QAFTestStep(description = "I navigate to registration page from coupons selection page")
	public void iNavigateToRegistrationPageFromCouponsSelectionPage() {
		CouponsselectionTestPage Couponsselection = new CouponsselectionTestPage();

		Couponsselection.getCouponsBtnRegister().verifyPresent();
		Couponsselection.getCouponsBtnRegister().click();
	}

	/**
	 * verify that user account is registered or not
	 */
	@QAFTestStep(description = "I verify user registered account")
	public void iVerifyUserRegisteredAccount() {
		CouponsselectionTestPage Couponsselection = new CouponsselectionTestPage();
		RegistrastionTestPage registerpage = new RegistrastionTestPage();

		Couponsselection.getCouponsBtnRegister().waitForNotPresent(5000);
		PerfectoUtils.verticalswipe();
		if (registerpage.getLblErrmsg().isPresent()) {
			PerfectoUtils.reportMessage("Sever Issue!!Error Occured..", MessageTypes.Fail);
		} else if (!Couponsselection.getCouponsBtnRegister().isPresent()) {
			PerfectoUtils.reportMessage("Able to see user registered account", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not able to see user registered account", MessageTypes.Fail);
		}
	}

	/**
	 * user Login from coupons details page
	 */
	@QAFTestStep(description = "I click on Login from coupons details page")
	public void iClickOnLoginFromCouponsDetailsPage() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();

		couponsdetails.getCouponsdetailBtnLogin().waitForPresent(5000);
		couponsdetails.getCouponsdetailBtnLogin().click();

	}

	/**
	 * user validate the limit description
	 */
	@QAFTestStep(description = "I validate the limit description")
	public void iValidateTheLimitDescription() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();

		couponsdetails.waitForPageToLoad();

		try {
			couponsdetails.getCouponsdetailLblCouponterms().isPresent();
			PerfectoUtils.reportMessage("Able to see limit description", MessageTypes.Pass);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
			if (couponsdetails.getCouponsdetailLblCouponterms().isPresent()) {
				PerfectoUtils.reportMessage("Able to see limit description", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Unable to see limit description", MessageTypes.Fail);
			}
		}
	}

	/**
	 * user validate digital coupons page
	 */
	@QAFTestStep(description = "I validate digital coupons page")
	public void iValidateDigitalCouponsPage() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponselectionLblAllcoupons().verifyPresent();
		couponsselection.getCouponsBtnSort().verifyPresent();
	}

	/**
	 * user validate coupons landing page for Resend Confirmation user
	 */
	@QAFTestStep(description = "I validate coupons landing page for Resend Confirmation user")
	public void iValidateCouponsLandingPageForResendConfirmationUser() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponselectionLblAllcoupons().verifyPresent();
		couponsselection.getCouponselectionLblAllcoupons().verifyPresent();
	}

	/**
	 * user click on share button"
	 */
	// @QAFTestStep(description = "I click share button")
	// public void iClickShareButton() {
	// CouponsdetailsTestPage couponsdetailspage = new CouponsdetailsTestPage();
	// ShareTestPage sharepage = new ShareTestPage();
	//
	// couponsdetailspage.getCouponsdetailBtnShare().verifyPresent();
	// couponsdetailspage.getCouponsdetailBtnShare().click();
	//
	// try {
	// sharepage.getSharelblTitle().verifyPresent();
	// } catch (Exception e) {
	// couponsdetailspage.getCouponsdetailBtnShare().waitForPresent(2000);
	// couponsdetailspage.getCouponsdetailBtnShare().click();
	// }
	// }

	/**
	 * user validate the sort button
	 */
	@QAFTestStep(description = "I validate the sort button")
	public static void iValidateTheSortButton() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponsBtnSort().waitForPresent(5000);
		if (couponsselection.getCouponsBtnSort().isPresent()) {
			PerfectoUtils.reportMessage("Sort button is diplayed as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Sort button is not diplayed", MessageTypes.Fail);
		}
	}

	/**
	 * user is navigated to email page on clicking share icon
	 *
	 */
	@QAFTestStep(description = "I navigate to email page on clicking share icon")
	public void iNavigateToEmailPageOnClickingShareIcon() {
		CouponsdetailsTestPage couponsdetailspage = new CouponsdetailsTestPage();

		couponsdetailspage.getCouponsdetailBtnShare().verifyPresent();
		couponsdetailspage.getCouponsdetailBtnShare().click();
		couponsdetailspage.getLblShareemail().verifyPresent();
		couponsdetailspage.getLblShareemail().click();
	}

	/**
	 * user click on Register from Coupons details page
	 */
	@QAFTestStep(description = "I Click on Register from Coupons details page")
	public void iClickOnRegisterFromCouponsDetailsPage() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();

		PerfectoUtils.verticalswipe();
		couponsdetails.getCouponsdetailBtnRegister().waitForPresent(3000);
		couponsdetails.getCouponsdetailBtnRegister().click();
		PerfectoUtils.reportMessage("Clicked on Register button.");
	}

	/**
	 * Verify the Add to List option is not available in Coupons page
	 */
	@QAFTestStep(description = "I should not see Add to List option")
	public void iShouldNotSeeAddToListOption() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();

		// Verify Add to List option is not available in Coupons details page
		couponsdetails.getCouponsdetailLblPagetitle().waitForPresent(3000);
		couponsdetails.getCoupondetailsBtnAddtolist().verifyNotPresent();
	}

	@QAFTestStep(description = "I navigate to Product List modal")
	public void iNavigateToProductListModal() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();

		try {
			couponsdetails.getimgheblogo().verifyPresent();
			couponsdetails.getlblviewallproducts().verifyPresent();
		} catch (Exception e) {
			PerfectoUtils.swipeIfInBottomForSelectAll(couponsdetails.getimgheblogo());
			if (couponsdetails.gettxtproducts().isPresent()) {
				couponsdetails.getlblviewallproducts().verifyPresent();
			} else {
				PerfectoUtils.reportMessage("Products section is not present", MessageTypes.Fail);
			}
		}
		couponsdetails.getimgheblogo().click();
	}

	@QAFTestStep(description = "I verify the Product List modal page")
	public void iVerifyTheProductListModalPage() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();

		couponsdetails.gettxtproducts().waitForPresent(3000);
		couponsdetails.gettxtproducts().verifyPresent();
		couponsdetails.getbtncancel().verifyPresent();
		couponsdetails.gettxtcouponbubble().verifyPresent();
		couponsdetails.gettxtcoupondescription().verifyPresent();

		int productsize = couponsdetails.gettxtproductsnamelist().size();
		System.out.println(productsize);
		PerfectoUtils.reportMessage("Number of products are: " + productsize, MessageTypes.Info);
		couponsdetails.getbtncancel().click();
	}

	@QAFTestStep(description = "I navigate back to coupon detail page by closing out the modal")
	public void iNavigateBackToCouponDetailPageByClosingOutTheModal() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();

		couponsdetails.getbtncancel().verifyPresent();
		couponsdetails.getbtncancel().click();
		couponsdetails.getimgheblogo().waitForPresent(5000);
		if (couponsdetails.getimgheblogo().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to coupons details page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to coupons details page.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I add a product to the list")
	public void iAddAProductToTheList() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();
		IOSStepdefshopinglist shopinglist = new IOSStepdefshopinglist();

		couponsdetails.getbtnaddtolist().get(1).verifyPresent();
		String prodName = couponsdetails.getbtnaddtolist().get(1).getText();
		getBundle().setProperty("ChoosenProduct", prodName);
		couponsdetails.getbtnaddtolist().get(1).click();
		shopinglist.iSeeToasterMessageOnSelectingAddButtonInAddToListPopup();
		couponsdetails.getbtncancel().waitForPresent(5000);
		couponsdetails.getbtncancel().click();
	}

	@QAFTestStep(description = "I verify product added to list message")
	public void iVerifyProductAddedToListMessage() {
		IOSStepdef iosstepdef = new IOSStepdef();
		IOSStepdefshopinglist shopinglist = new IOSStepdefshopinglist();

		iosstepdef.iNavigateToShoppingList();
		shopinglist.iSeeListDetailPageOnClickingCorrespondingListNameFromMyListPage();
		shopinglist.iShouldSeeTheSelectedItemInTheSelectedListPage();
	}

	@QAFTestStep(description = "I click on any row in the product list")
	public void iClickOnAnyRowInTheProductList() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();

		String prodctname = couponsdetails.gettxtproductsnamelist().get(1).getText();
		getBundle().setProperty("SelectedProduct", prodctname);
		couponsdetails.gettxtproductsnamelist().get(1).click();
		PerfectoUtils.reportMessage("Clicked on a product", MessageTypes.Pass);
	}

	/**
	 * Verification of sign up now button is not present
	 */
	@QAFTestStep(description = "I verify that sign up now button is not present in the page")
	public void iVerifyThatSignUpNowButtonIsNotPresentInThePage() {
		CouponssearchresultTestPage couponsearchresult = new CouponssearchresultTestPage();
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (dcAutoEnrolFlag.contains("true")) {
			if (!couponsearchresult.getBtnsignupnow().isPresent()) {
				PerfectoUtils.reportMessage("Sign up now button is not present", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Sign up now button is present", MessageTypes.Fail);
			}
		} else {
			if (couponsearchresult.getBtnsignupnow().isPresent())
				PerfectoUtils.reportMessage("Sign up now button is present", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Sign up now button is not present", MessageTypes.Fail);
		}
	}

	/**
	 * Verify redeem button is displayed
	 */
	@QAFTestStep(description = "I verify redeem button on selected tab")
	public void iVerifyRedeemButtonInSelectedTab() {
		CouponsselectionTestPage couponSelection = new CouponsselectionTestPage();
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (dcAutoEnrolFlag.contains("true")) {
			// Verify redeem button is displayed
			if (couponSelection.getCouponsBtnRedeem().isPresent())
				PerfectoUtils.reportMessage("Redeem button is displayed in selected tab..", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Redeem button is not displayed in selected tab..", MessageTypes.Fail);
		} else {
			if (!couponSelection.getCouponsBtnRedeem().isPresent())
				PerfectoUtils.reportMessage("Redeem button is not displayed in selected tab..", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Redeem button is displayed in selected tab..", MessageTypes.Fail);
		}

	}

	/**
	 * user validate Selected Savings tab
	 */
	@QAFTestStep(description = "I should see Selected Savings tab")
	public void iShouldSeeSelectedSavings() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (dcAutoEnrolFlag.equals("true")) {
			couponsselection.getCouponsLblPgtitlecoupons().waitForPresent(5000);
			if (couponsselection.getCouponsLblPgtitlecoupons().isPresent()) {
				couponsselection.getCouponsLblCoupondesc().verifyPresent();
				PerfectoUtils.reportMessage("SELECTED section is displayed...", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("SELECTED section is not displayed..", MessageTypes.Fail);
			}
		} else
			PerfectoUtils.reportMessage("DC auto enrol flag is off, Cannot validate selected saving");
	}

	@QAFTestStep(description = "I see Unselect All button in coupon selection page")
	public void iSeeUnselectAllButtonInCouponSelectionPage() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		if (couponsselection.getCouponsBtnUnSelectall().isPresent()) {
			PerfectoUtils.reportMessage("Unselect All button is present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unselect All button is not present", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I see All Coupons are checked")
	public void iSeeAllCouponsAreChecked() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		if (couponsselection.getLstSelectedTabcheckbox().get(0).getAttribute("checked").equals("true")) {
			PerfectoUtils.reportMessage("Checkboxes are checked", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Checkboxes are not checked", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I select Unselect button")
	public void iSelectUnselectButton() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponsBtnUnSelectall().verifyPresent();
		couponsselection.getCouponsBtnUnSelectall().click();
	}

	@QAFTestStep(description = "I see All coupons are unchecked")
	public void iSeeAllCouponsAreUnchecked() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		if (couponsselection.getLstSelectedTabcheckbox().get(0).getAttribute("checked").equals("false")) {
			PerfectoUtils.reportMessage("Checkboxes are unchecked", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Checkboxes are checked", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the various sort option")
	public void iverifythevarioussortoption() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		// couponsselection.getLblSortpopupSecondoption().waitForPresent(5000);
		int size = couponsselection.getLblSortpopupoption().size();
		for (int i = 0; i <= size; i++) {
			String strSelectedOption = couponsselection.getLblSortpopupoption().get(i).getText();
			ArrayList<String> alt = new ArrayList<String>(size);
			alt.add(strSelectedOption);
			System.out.println(alt);

		}
	}

	/**
	 * user validate Selected Savings tab
	 */
	@QAFTestStep(description = "I validate Selected Savings tab")
	public void iValidateSelectedSavingsTab() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		couponsselection.getCouponsLblPgtitlecoupons().waitForPresent(5000);
		if (couponsselection.getCouponsLblPgtitlecoupons().isPresent()) {
			couponsselection.getCouponsLblCoupondesc().verifyPresent();
			couponsselection.getLblSelectedsavingswhenselected().verifyPresent();
			PerfectoUtils.reportMessage("SELECTED section in Digital Coupons page is validated.", MessageTypes.Pass);
		}
		
		/*if (couponsselection.getLblSelectedsavingswhenselected().isPresent()
				|| (couponsselection.getLblSelectedsavingswhenselected().getAttribute("Selected")).equals("true")) {
			PerfectoUtils.reportMessage("SELECTED section in Digital Coupons page is validated.", MessageTypes.Pass);*/

		else {
			PerfectoUtils.reportMessage("SELECTED section in Digital Coupons page is not validated.", MessageTypes.Fail);
		}

		if (dcAutoEnrolFlag.contains("true")) {
			iVerifyRedeemButtonInSelectedTab();
		} else {
			couponsselection.getCouponsBtnRedeem().verifyNotPresent();
		}
	}
	
	/**
	 * Verify LifeTime Banner is static after vertical swipe 
	 */
	@QAFTestStep(description = "Verify Lifetime Coupon Savings banner is static")
	public void verifyLifetimeCouponSavingsBannerisstatic() {
		LifetimeSavingsBannerTestPage lifeTimeSavings = new LifetimeSavingsBannerTestPage();

		lifeTimeSavings.getImgStaticicon().waitForPresent(5000);
		System.out.println(lifeTimeSavings.getImgBannersection().isPresent());
		PerfectoUtils.verticalswipe();
		System.out.println(lifeTimeSavings.getImgBannersection().isPresent());
		
		if (!lifeTimeSavings.getImgBannersection().isPresent()){
			PerfectoUtils.reportMessage("LifeTime Savings Banner is not Static", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("LifeTime Savings Banner is Static", MessageTypes.Fail);
		}
		
	}
	
	@QAFTestStep(description = "Verify the banner amount is zero when no coupons have been redeemed")
	public void verifyTheBannerAmountIsZeroWhenNoCouponsHaveBeenRedeemed() {
		LifetimeSavingsBannerTestPage banner = new LifetimeSavingsBannerTestPage();
		
		String savingsAmountFrombanner = banner.getLblTotalsavings().getText();
		
		if(savingsAmountFrombanner.contains("$0")){
			PerfectoUtils.reportMessage("The banner amount is zero when no coupons have been redeemed",MessageTypes.Pass);
		} else{
			PerfectoUtils.reportMessage("The banner amount is not zero when no coupons have been redeemed",MessageTypes.Fail);
		}
		
	}
	
	@QAFTestStep(description = "Verify the banner amount is zero after first enrolling in Digital Coupons")
	public void verifyTheBannerAmountIsZeroAfterFirstEnrollingInDigitalCoupons() {
		LifetimeSavingsBannerTestPage banner = new LifetimeSavingsBannerTestPage();
		
		String savingsAmountFrombanner = banner.getLblTotalsavings().getText();
		
		if(savingsAmountFrombanner.contains("$0")){
			PerfectoUtils.reportMessage("The banner amount is zero after first enrolling in Digital Coupons",MessageTypes.Pass);
		} else{
			PerfectoUtils.reportMessage("The banner amount is not zero after first enrolling in Digital Coupons",MessageTypes.Fail);
		}
	}
	
	/**
	 * Verify the amount is preceded by a dollar sign on Lifetime Coupon Savings banner 
	 */
	@QAFTestStep(description = "Verify the amount is preceded by a dollar sign on Lifetime Coupon Savings banner")
	public void verifyTheAmountIsPrecededByADollarSignOnLifetimeCouponSavingsBanner() {
		LifetimeSavingsBannerTestPage lifeTimeSavings = new LifetimeSavingsBannerTestPage();

		lifeTimeSavings.getImgStaticicon().waitForPresent(5000);
		String Amt = lifeTimeSavings.getLblTotalsavings().getText();
		
		if (Amt.startsWith("$")){
			PerfectoUtils.reportMessage("Savings Amount is preceded by a dollar sign", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Savings Amount is preceded by a dollar sign", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the Lifetime Coupons Savings banner is not present")
	public void iVerifyTheLifetimeCouponsSavingsBannerIsNotPresent() {
		LifetimeSavingsBannerTestPage lifetimesavings = new LifetimeSavingsBannerTestPage();

		if (!lifetimesavings.getLblYourlifetimesavings().isPresent()) {
			PerfectoUtils.reportMessage("Lifetime Coupons Savings banner is not present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Able to see Lifetime Coupons Savings banner", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the static icon on the Lifetime Coupons Savings banner")
	public void iVerifyTheStaticIconOnTheLifetimeCouponsSavingsBanner() {
		LifetimeSavingsBannerTestPage lifetimesavings = new LifetimeSavingsBannerTestPage();

		if (lifetimesavings.getImgStaticicon().isPresent()) {
			PerfectoUtils.reportMessage("static icon on the Lifetime Coupons Savings banner is present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("static icon on the Lifetime Coupons Savings banner is not present", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify Your Lifetime Savings text on the banner")
	public void iVerifyYourLifetimeSavingsTextOnTheBanner() {
		LifetimeSavingsBannerTestPage lifetimesavings = new LifetimeSavingsBannerTestPage();

		if (lifetimesavings.getLblYourlifetimesavings().isPresent()) {
			PerfectoUtils.reportMessage("Your Lifetime Savings text is present on the banner", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Your Lifetime Savings text is not present on the banner", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the dollar amount saved on the banner")
	public void iVerifyTheDollarAmountSavedOnTheBanner() {
		LifetimeSavingsBannerTestPage lifetimesavings = new LifetimeSavingsBannerTestPage();

		if (lifetimesavings.getLblTotalsavings().isPresent()) {
			PerfectoUtils.reportMessage("dollar amount is saved on the banner", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("dollar amount is not present on the banner", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify division line is between the Lifetime Coupon Savings banner and the Coupons page")
	public void iVerifyDivisionLineIsBetweenTheLifetimeCouponSavingsBannerAndTheCouponsPage() {
		LifetimeSavingsBannerTestPage lifetimesavings = new LifetimeSavingsBannerTestPage();

		if (lifetimesavings.getImgDivisionline().isPresent()) {
			PerfectoUtils.reportMessage("division line is present between banner and coupons page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("division line is not present between banner and coupons page", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I verify Lifetime Coupon Savings banner on the Available tab")
	public void iVerifyLifetimeCouponSavingsBannerOnTheAvailableTab() {
		LifetimeSavingsBannerTestPage lifetimesavings = new LifetimeSavingsBannerTestPage();

		if (lifetimesavings.getLblYourlifetimesavings().isPresent()) {
			PerfectoUtils.reportMessage("Lifetime Coupon Savings banner is present on the Available tab", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Lifetime Coupon Savings banner is not present on the Available tab", MessageTypes.Fail);
		}
	}
	
	@QAFTestStep(description = "I verify Lifetime Coupon Savings banner on the Selected tab")
	public void iVerifyLifetimeCouponSavingsBannerOnTheSelectedTab() {
		LifetimeSavingsBannerTestPage lifetimesavings = new LifetimeSavingsBannerTestPage();

		if (lifetimesavings.getLblYourlifetimesavings().isPresent()) {
			PerfectoUtils.reportMessage("Lifetime Coupon Savings banner is present on the Selected tab", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Lifetime Coupon Savings banner is not present on the Selected tab", MessageTypes.Fail);
		}
	}
}
