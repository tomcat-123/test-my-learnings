package com.heb.automation.common.pages.coupons;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class LifetimeSavingsBannerTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "cbanner.img.staticicon")
	private QAFWebElement imgStaticicon;
	@FindBy(locator = "cbanner.lbl.totalsavings")
	private QAFWebElement lblTotalsavings;
	@FindBy(locator = "cbanner.lbl.yourlifetimesavings")
	private QAFWebElement lblYourlifetimesavings;
	@FindBy(locator = "cbanner.img.divisionline")
	private QAFWebElement imgDivisionline;
	@FindBy(locator = "cbanner.img.bannersection")
	private QAFWebElement imgBannersection;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getImgStaticicon() {
		return imgStaticicon;
	}

	public QAFWebElement getLblTotalsavings() {
		return lblTotalsavings;
	}

	public QAFWebElement getLblYourlifetimesavings() {
		return lblYourlifetimesavings;
	}

	public QAFWebElement getImgDivisionline() {
		return imgDivisionline;
	}

	public QAFWebElement getImgBannersection() {
		return imgBannersection;
	}
}
