package com.heb.automation.common.pages.storelocator;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class StoremapviewTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "storelocmapview.img.selectstore")
	private QAFWebElement storelocatorMapSelectstore;
	@FindBy(locator = "storelocmapview.img.mylocation")
	private QAFWebElement androidWidgetImageview;
	@FindBy(locator = "storelocmapview.img.zoomin")
	private QAFWebElement androidWidgetImageview1;
	@FindBy(locator = "storelocmapview.img.zoomout")
	private QAFWebElement androidWidgetImageview2;
	@FindBy(locator = "storelocmapview.txt.search")
	private QAFWebElement storelocatorTxtSearch;
	@FindBy(locator = "storelocmapview.icon.search")
	private QAFWebElement storelocatorIconSearch;
	@FindBy(locator = "storelocmapview.icon.closesearch")
	private QAFWebElement storelocatorIconClosesearch;
	@FindBy(locator = "storelocmapview.img.selectanotherstore")
	private QAFWebElement storelocatorMapSelectanotherstore;
	@FindBy(locator = "storelocmapview.img.info")
	private QAFWebElement imgInfo;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getStorelocatorMapSelectstore() {
		return storelocatorMapSelectstore;
	}

	public QAFWebElement getAndroidWidgetImageview() {
		return androidWidgetImageview;
	}

	public QAFWebElement getAndroidWidgetImageview1() {
		return androidWidgetImageview1;
	}

	public QAFWebElement getAndroidWidgetImageview2() {
		return androidWidgetImageview2;
	}

	public QAFWebElement getStorelocatorTxtSearch() {
		return storelocatorTxtSearch;
	}

	public QAFWebElement getStorelocatorIconSearch() {
		return storelocatorIconSearch;
	}

	public QAFWebElement getStorelocatorIconClosesearch() {
		return storelocatorIconClosesearch;
	}

	public QAFWebElement getStorelocatorMapSelectanotherstore() {
		return storelocatorMapSelectanotherstore;
	}
	
	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
	
	public QAFWebElement getImgInfo() {
		return imgInfo;
	}
	
	
	// DYNAMIC value declaring
	public QAFWebElement getStoreFromMap(int lable) {
		String loc = String.format(pageProps.getString("storelocmapview.img.selectstoredynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}
}
