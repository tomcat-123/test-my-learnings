package com.heb.automation.ios.steps.cartncheckout;

import java.util.HashMap;
import java.util.Map;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.cartncheckout.CartTestPage;
import com.heb.automation.common.pages.cartncheckout.CheckoutTestPage;
import com.heb.automation.common.pages.cartncheckout.CreditcardTestPage;
import com.heb.automation.common.pages.cartncheckout.NewshippingdetailsTestPage;
import com.heb.automation.common.pages.cartncheckout.ShippingaddressTestPage;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in CartAndCheckOut

	I naviagte to cart page
	I modify the product quantity
	I see updated quantity and price
	I enter as guest checkout from Login Splash page
	I add Credit card details
	I enter new shipping address
	I choose shipping address
	I enter shipping address*/


public class IOSStepDefCartncheckout {

	@QAFTestStep(description = "I naviagte to cart page")
	public void iNaviagteToCartPage() {
		CartTestPage cartpage = new CartTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		//ioscommon.getAppFooterCart().click();
		cartpage.getCartpageLblEstimatedtotal().waitForPresent(5000);
		cartpage.getCartpageLblEstimatedtotal().verifyPresent();
		boolean isCartDisplayed = cartpage.getCartpageLblEstimatedtotal().isPresent();

		if (isCartDisplayed) {
			PerfectoUtils.reportMessage("Cart Page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cart Page is not displayed", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I modify the product quantity")
	public void iModifyTheProductQuantity() throws InterruptedException {
		PerfectoUtils.reportMessage("Picker wheel is not identifiable", MessageTypes.Info);
	}

	@QAFTestStep(description = "I see updated quantity and price")
	public void iSeeUpdatedQuantityAndPrice() {
		PerfectoUtils.reportMessage("Picker is not identifiable for Qty. Yet to implement this step", MessageTypes.Info);
	}

	@QAFTestStep(description = "I enter as guest checkout from Login Splash page")
	public void iEnterAsGuestCheckoutFromLoginSplashPage() {
		CheckoutTestPage chekoutpage = new CheckoutTestPage();

		chekoutpage.getCheckoutLinkContinue().click();
		PerfectoUtils.reportMessage("Clicked: on continue as guest user", MessageTypes.Pass);
	}

	

	@QAFTestStep(description = "I add Credit card details")
	public void iAddCreditCardDetails() {
		// TODO: call test steps

		CheckoutTestPage checkout = new CheckoutTestPage();
		checkout.waitForPageToLoad();
		
		checkout.getCheckoutLblCreditcard().click();

		CreditcardTestPage creditcard = new CreditcardTestPage();
		
		creditcard.waitForPageToLoad();
		
		creditcard.getCreditcardTxtCardholder().sendKeys("VIJAYAKARTHI");
		creditcard.getCreditcardTxtCardnumber().sendKeys("373235387881015");
		creditcard.getCreditcardTxtCvc().sendKeys("543");
		creditcard.getCreditcardTxtExpiration().sendKeys("02/18");
		
		Map<String, Object> params1 = new HashMap<>();

		params1.put("content", "Done");
		Object result1 = PerfectoUtils.getAppiumDriver().executeScript("mobile:text:select", params1);

		
		creditcard.getCreditcardBtnAdd().click();

	}

	@QAFTestStep(description = "I enter new shipping address")
	public void iEnterNewShippingAddress() {
		// TODO: call test steps
		NewshippingdetailsTestPage newshipping = new NewshippingdetailsTestPage();

		ShippingaddressTestPage shippingAddrss = new ShippingaddressTestPage();
		shippingAddrss.getShippingLblAddnewaddress().waitForPresent(5000);
		shippingAddrss.getShippingLblAddnewaddress().click();

		newshipping.waitForPageToLoad();
		// newshipping.getNewshippingTxtFirstname().click();
		newshipping.getNewshippingTxtFirstname().sendKeys("qwwerw");

		newshipping.getNewshippingTxtLastname().waitForPresent(5000);

		newshipping.getNewshippingTxtLastname().sendKeys("dgert");
		newshipping.getNewshippingTxtPhnumber().sendKeys("(210)-789-9129");
		newshipping.getNewshippingTxtAddress1().sendKeys("3177 Medical DR");
		newshipping.getNewshippingTxtAddress2().sendKeys("Apt 512");
		newshipping.getNewshippingTxtCity().sendKeys("San Antonio");
		newshipping.getNewshippingTxtState().sendKeys("TX");
		newshipping.getNewshippingTxtZipcode().sendKeys("78299");
		Map<String, Object> params1 = new HashMap<>();

		params1.put("content", "Done");
		Object result1 = PerfectoUtils.getAppiumDriver().executeScript("mobile:text:select", params1);

		newshipping.getNewshippingBtnSave().waitForPresent(5000);

		newshipping.getNewshippingBtnSave().click();

		if (newshipping.getAddressErrorPopup().isPresent()) {

			newshipping.getAddressErrorYes().click();

		}

	}

	@QAFTestStep(description = "I choose shipping address")
	public void iChooseShippingAddress() {
		CheckoutTestPage checkout = new CheckoutTestPage();
		checkout.getCheckoutBtnShippingaddress().waitForPresent(5000);
		checkout.getCheckoutBtnShippingaddress().click();

		
		NewshippingdetailsTestPage newshipping = new NewshippingdetailsTestPage();

		if (newshipping.getNewshippingBtnSave().isPresent()) {
			newshipping.getNewshippingBtnSave().click();
		}
	}
	
	@QAFTestStep(description = "I enter shipping address")
	public void iEnterShippingAddress() {
		// TODO: call test steps

		PerfectoUtils.reportMessage("Locator for picker will is disabled", MessageTypes.Info);
	}
}
