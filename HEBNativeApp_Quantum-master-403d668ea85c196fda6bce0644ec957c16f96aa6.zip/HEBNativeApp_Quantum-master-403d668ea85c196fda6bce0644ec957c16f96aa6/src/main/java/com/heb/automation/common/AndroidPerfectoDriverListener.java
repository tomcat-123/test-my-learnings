/**
 * 
 */
package com.heb.automation.common;

import static com.heb.automation.common.PerfectoUtils.closeApplication;
import static com.heb.automation.common.PerfectoUtils.openApplication;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.DriverCommand;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.webdriver.CommandTracker;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriverCommandAdapter;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.StringUtil;
import com.perfectomobile.selenium.util.EclipseConnector;

public class AndroidPerfectoDriverListener extends QAFWebDriverCommandAdapter {

	@Override
	public void beforeCommand(QAFExtendedWebDriver driver, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.QUIT)) {
			try {
				closeApp();
				driver.executeScript("mobile:logs:stop", getBundle().getProperty("deviceLogMapObject"));
				stopVitals(driver);
				driver.close();
			} catch (Exception e) {

			}
		}
	}

	@Override
	public void afterCommand(QAFExtendedWebDriver driver, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.CLOSE)) {
			try {
				// Download report and other activities
			} catch (Exception e) {
				// ignore
			}
		}
	}

	private String getExecutionId() {
		try {
			Class<?> cls = Class.forName("com.perfectomobile.selenium.util.EclipseConnector");

			Object connector = cls.newInstance();
			Method getExecutionId = cls.getMethod("getExecutionId");
			getExecutionId.setAccessible(true);

			return (String) getExecutionId.invoke(connector);

		} catch (Exception e) {
			// ignore it.....
		}
		return "";
	}

	@Override
	public void beforeInitialize(Capabilities desiredCapabilities) {
		try {
			EclipseConnector connector = new EclipseConnector();
			String executionId = connector.getExecutionId();
			if (getBundle().getString("remote.server", "").contains("perfecto")) {
				if (StringUtil.isNotBlank(executionId)) {
					((DesiredCapabilities) desiredCapabilities).setCapability(EclipseConnector.ECLIPSE_EXECUTION_ID,
							executionId);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
//		((DesiredCapabilities)desiredCapabilities).setCapability("windTunnelPersona", "Georgia");
		//((DesiredCapabilities)desiredCapabilities).setCapability("windTunnelPersona", "Georgia");


	}

	@Override
	public void onFailure(QAFExtendedWebDriver driver, CommandTracker commandTracker) {
	/*	super.onFailure(driver, commandTracker);
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();
		System.out.println("executing listner");

		if (appCrash.getReloginTitle().isPresent()) {
			PerfectoUtils.reportMessage("Handling re-Login popup", MessageTypes.Pass);
			appCrash.getReloginPassword().sendKeys(getBundle().getString("currentPassword"));
			appCrash.getReloginLoginBtn().waitForPresent(10000);
			appCrash.getReloginLoginBtn().click();

			TouchActions touchAction = new TouchActions(PerfectoUtils.getAppiumDriver());
			touchAction.click();
		}

		if (appCrash.getAppcrashMsg().isPresent()) {
			PerfectoUtils.reportMessage("Unexpected error in Application. Click Ok button");
			appCrash.getExceptionBtnOk().click();
		}

		if (appCrash.getSoftwareUpdatePopup().isPresent()) {
			appCrash.getSoftwareUpdateLater().click();
		}

		if (appCrash.getAllowPopup().isPresent()) {
			appCrash.getAllowPopup().click();
			PerfectoUtils.reportMessage("Allow is enabled");
		}*/
	}

	@Override
	public void onInitialize(QAFExtendedWebDriver driver) {

		System.out.println("------------Opening application -----------");

		startAppVitals(driver, getBundle().getString("app.name"), true);
/*
		 Setting Wi-Fi connection 
		java.util.Map<String, Object> params2 = new HashMap<>();
		params2.put("wifi", "disabled");
		driver.executeScript("mobile:network.settings:set", params2);
		params2.put("wifi", "enabled");
		driver.executeScript("mobile:network.settings:set", params2);
*/
		/* Starting the device log */
		java.util.Map<String, Object> deviceLog = new HashMap<String, Object>();
		driver.executeScript("mobile:logs:start", deviceLog);
		getBundle().setProperty("deviceLogMapObject", deviceLog);

		/* Report View for Graph */
		/*
		 * ATUReports.setWebDriver(driver); ATUReports.indexPageDescription =
		 * "HEB Project Description";
		 */

		/* Open Application */
		openApplication(driver, getBundle().getString("app.name"));
		closeApplication(driver, getBundle().getString("app.name"));
		openApplication(driver, getBundle().getString("app.name"));
	//	PerfectoUtils.getTimetoLoadApp(driver);

		String setlocationNeeded = getBundle().getString("setLocation");
		
		/* Set location */
		
		java.util.Map<String, Object> params1 = new HashMap<String, Object>();
		params1.put("address", "San Antonio, TX");
		driver.executeScript("mobile:location:set", params1);
		
	}

	public static String startAppVitals(QAFExtendedWebDriver driver, String app, boolean startDeviceVitals) {
		Map<String, Object> params = new HashMap<>();
		List<String> vitals = new ArrayList<>();
		vitals.add("all");
		params.put("vitals", vitals);
		params.put("interval", Long.toString(1));
		List<String> sources = new ArrayList<>();
		sources.add(getBundle().getString("app.name"));
		if (startDeviceVitals)
			sources.add("device");
		params.put("sources", sources);
		return (String) driver.executeScript("mobile:monitor:start", params);
	}

	/* Stop vitals */
	public static String stopVitals(QAFExtendedWebDriver driver) {
		Map<String, Object> params = new HashMap<>();
		List<String> vitals = new ArrayList<>();
		vitals.add("all");
		params.put("vitals", vitals);
		return (String) driver.executeScript("mobile:monitor:stop", params);
	}

	private void closeApp() {
		try {
			try {
				AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
				androidcommon.logoutApp();
			} catch (Exception e) {
				e.printStackTrace();
			}
			closeApplication(getBundle().getString("app.name"));
		} catch (Exception e) {

		}
	}
	
	

}
