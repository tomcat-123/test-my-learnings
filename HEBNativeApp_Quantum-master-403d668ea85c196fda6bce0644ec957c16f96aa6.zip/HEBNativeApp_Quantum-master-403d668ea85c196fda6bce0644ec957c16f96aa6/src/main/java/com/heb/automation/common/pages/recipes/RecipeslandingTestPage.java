package com.heb.automation.common.pages.recipes;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RecipeslandingTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "recipeslanding.btn.quickfinder")
	private QAFWebElement recipesQuickfinderBtn;
	@FindBy(locator = "recipeslanding.lbl.pagetitle")
	private QAFWebElement recipesPagename;
	@FindBy(locator = "recipeslanding.btn.recipebox")
	private QAFWebElement recipesRecipeboxname;
	@FindBy(locator = "recipeslanding.img.featuredcontent")
	private QAFWebElement recipesFeatured;
	@FindBy(locator = "recipeslanding.txt.searchproducts")
	private QAFWebElement recipesTxtSearchProducts;
	@FindBy(locator = "recipeslanding.btn.searchproducts")
	private QAFWebElement recipesIconSearchProducts;

	@FindBy(locator = "recipeslanding.btn.scaninsearchbox")
	private QAFWebElement btnScaninsearchbox;

	@FindBy(locator = "recipeslanding.btn.scannerbutton")
	private QAFWebElement btnScannerbutton;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getRecipesFeatured() {
		return recipesFeatured;
	}

	public QAFWebElement getRecipesQuickfinderBtn() {
		return recipesQuickfinderBtn;
	}

	public QAFWebElement getRecipesPagename() {
		return recipesPagename;
	}

	public QAFWebElement getRecipesRecipeboxname() {
		return recipesRecipeboxname;
	}

	public QAFWebElement getRecipesTxtSearchProducts() {
		return recipesTxtSearchProducts;
	}

	public QAFWebElement getRecipesIconSearchProducts() {
		return recipesIconSearchProducts;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getBtnScaninsearchbox() {
		return btnScaninsearchbox;
	}

	public QAFWebElement getBtnScannerbutton() {
		return btnScannerbutton;
	}

}
