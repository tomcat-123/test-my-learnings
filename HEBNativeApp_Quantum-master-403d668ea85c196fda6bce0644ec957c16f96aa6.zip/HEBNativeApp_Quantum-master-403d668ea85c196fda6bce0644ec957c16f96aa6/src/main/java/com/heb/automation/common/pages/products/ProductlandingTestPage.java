package com.heb.automation.common.pages.products;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ProductlandingTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "productslanding.lbl.pagename")
	private QAFWebElement productsLblPagename;
	@FindBy(locator = "productslanding.btn.searchicon")
	private QAFWebElement productsBtnSearchicon;
	@FindBy(locator = "productslanding.btn.shoppinglisticon")
	private QAFWebElement productsBtnShoppinglisticon;
	@FindBy(locator = "productslanding.txt.categoryname")
	private QAFWebElement productsCategoryname;
	@FindBy(locator = "productslanding.txt.entersearchtext")
	private QAFWebElement productsTxtEntersearchtext;
	@FindBy(locator = "productslanding.lbl.categorynamedynamic")
	private QAFWebElement lblCategorynamedynamic;
	@FindBy(locator = "productslanding.txt.productsearchbox")
	private QAFWebElement productsSearchBox;
	@FindBy(locator = "productslanding.lbl.errmsg")
	private QAFWebElement lblErrmsg;
	@FindBy(locator = "productslanding.lbl.noresults")
	private QAFWebElement lblNoresults;
	@FindBy(locator = "productslanding.lbl.pagetitle")
	private QAFWebElement lblPageTitle;
	@FindBy(locator = "productslanding.lbl.categorylist")
	private List<QAFWebElement> lblCategoryList;
	
	@FindBy(locator = "productslanding.btn.searchclose")
	private QAFWebElement btnSearchclose;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getProductsLblPagename() {
		return productsLblPagename;
	}

	public QAFWebElement getProductsBtnSearchicon() {
		return productsBtnSearchicon;
	}

	public QAFWebElement getProductsBtnShoppinglisticon() {
		return productsBtnShoppinglisticon;
	}

	public QAFWebElement getProductsCategoryname() {
		return productsCategoryname;
	}

	public QAFWebElement getProductsTxtEntersearchtext() {
		return productsTxtEntersearchtext;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	// DYNAMIC value declaring
	public QAFWebElement getCategoryNameByLable(String lable) {
		String loc = String.format(pageProps.getString("productslanding.lbl.categorydynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getCategoryNameByString(String lable) {
		String loc = String.format(pageProps.getString("productslanding.lbl.categorynamedynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getTxtProductsSearchBox() {
		return productsSearchBox;
	}

	public QAFWebElement getLblErrmsg() {
		return lblErrmsg;
	}

	public QAFWebElement getLblNoresults() {
		return lblNoresults;
	}

	public QAFWebElement getPageheader(String lable) {
		String loc = String.format(pageProps.getString("productslanding.lbl.pagetitledynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getLblPageTitle() {
		return lblPageTitle;
	}
	public List<QAFWebElement> getLblCategoryList() {
		return lblCategoryList;
	}
	public QAFWebElement getBtnSearchclose() {
		return btnSearchclose;
	}
}
