package com.heb.automation.common.pages.recipes;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RecipeinstructionsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "recipeinstructions.btn.instructions")
	private QAFWebElement recipeinstructionsBtnInstructions;
	@FindBy(locator = "recipeingredients.lbl.review")
	private QAFWebElement recipeingredientsLblReview;
	@FindBy(locator = "recipestructions.btn.readmore")
	private QAFWebElement recipestructionsBtnReadmore;
	@FindBy(locator = "recipeinstructions.lbl.instructions")
	private QAFWebElement recipeinstructionsLblInstructions;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getRecipeinstructionsBtnInstructions() {
		return recipeinstructionsBtnInstructions;
	}

	public QAFWebElement getRecipeingredientsLblReview() {
		return recipeingredientsLblReview;
	}

	public QAFWebElement getRecipestructionsBtnReadmore() {
		return recipestructionsBtnReadmore;
	}

	public QAFWebElement getRecipeinstructionsLblInstructions() {
		return recipeinstructionsLblInstructions;
	}

}
