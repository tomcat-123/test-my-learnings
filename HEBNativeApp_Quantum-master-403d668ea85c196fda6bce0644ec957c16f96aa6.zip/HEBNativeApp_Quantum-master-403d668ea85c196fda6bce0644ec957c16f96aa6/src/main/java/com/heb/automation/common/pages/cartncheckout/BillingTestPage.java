package com.heb.automation.common.pages.cartncheckout;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class BillingTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "billing.txt.email")
	private QAFWebElement billingTxtEmail;
	@FindBy(locator = "billing.txt.confirmemail")
	private QAFWebElement billingTxtConfirmemail;
	@FindBy(locator = "billing.lbl.emailaddress")
	private QAFWebElement billingLblEmailaddress;
	@FindBy(locator = "billing.lbl.pgtitlebilling")
	private QAFWebElement billingLblPgtitlebilling;
	@FindBy(locator = "billing.chkbox.sameasshipping")
	private QAFWebElement billingChkboxSameasshipping;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getBillingTxtEmail() {
		return billingTxtEmail;
	}

	public QAFWebElement getBillingTxtConfirmemail() {
		return billingTxtConfirmemail;
	}

	public QAFWebElement getBillingLblEmailaddress() {
		return billingLblEmailaddress;
	}

	public QAFWebElement getBillingLblPgtitlebilling() {
		return billingLblPgtitlebilling;
	}

	public QAFWebElement getBillingChkboxSameasshipping() {
		return billingChkboxSameasshipping;
	}
	
	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

}
