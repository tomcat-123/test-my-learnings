/**
 * 
 */
package com.heb.automation.common.steps.shoppinglist;

import static com.heb.automation.common.PerfectoUtils.getAppiumDriver;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static com.qmetry.qaf.automation.step.CommonStep.click;
import static com.qmetry.qaf.automation.step.CommonStep.waitForPresent;

import java.util.List;

import org.openqa.selenium.Dimension;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.ProductResult;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.products.ProductdetailTestPage;
import com.heb.automation.common.pages.products.ProductlandingTestPage;
import com.heb.automation.common.pages.products.ProductsresultlistTestPage;
import com.heb.automation.common.pages.shoppinglist.ForgotpasswordTestPage;
import com.heb.automation.common.pages.shoppinglist.ListdetailsTestPage;
import com.heb.automation.common.pages.shoppinglist.LoginpopupTestPage;
import com.heb.automation.common.pages.shoppinglist.MylistTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.storelocator.StorelocatorTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in ShoppingList

	I should see the new Shopping List name in the My Lists page
	I enter an already existing Shopping List name
	I select Copy List option
	I select a List from Copy Items overlay
	I should see the success toast message
	I try to delete the Weekly Grocery List
	I try to delete the Wish List
	I Verify Hot user is not able to delete the Wish List
	I select Uncheck All Items
	I see My List page
	I see PDP page by navigating {0} items
	I click add to list from PDP page
	I click on Login from Shopping List page
	I click Forgot Password link from Login overlay
	I see Forgot Password page
	I see PDP page by navigating {0} items under All Products
	I should see the My Lists page
	I check my list page is not displayed
	I verify the error popup for invalid scan
	Get all the available Shoppinglists*/

public class CommonStepDefShoppingList {

	/**
	 * Verify the list name is displayed in the my list page
	 */
	@QAFTestStep(description = "I should see the new Shopping List name in the My Lists page")
	public void iShouldSeeTheNewShoppingListNameInTheMyListsPage() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.getMyListLblLstNameHotUser().verifyPresent();
	}

	/**
	 * Enter the already existing list name 'ShoppingList.listname' in the list
	 * name field
	 * 
	 * @param List
	 *            name 'ShoppingList.listname'
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I enter an already existing Shopping List name")
	public void iEnterAnAlreadyExistingShoppingListName() throws InterruptedException {
		MylistTestPage mylist = new MylistTestPage();

		String mylistName = getBundle().getString("ShoppingList.listname");
		mylist.getMyListTxtEnterNewList().sendKeys(mylistName);
		PerfectoUtils.reportMessage("Existing list name is entered as: " + mylistName, MessageTypes.Pass);
	}

	/**
	 * Click on the Copy list option
	 */
	@QAFTestStep(description = "I select Copy List option")
	public void iSelectCopyListOption() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.waitForPageToLoad();
		mylistpage.getMyListsLblCopylist().waitForPresent(5000);
		mylistpage.getMyListsLblCopylist().click();
	}

	/**
	 * Select a list (first list) from the available list and save the list name
	 * in a variable 'SelectedList'
	 * 
	 * @return list name 'SelectedList'
	 */
	@QAFTestStep(description = "I select a List from Copy Items overlay")
	public void iSelectAList() {
		MylistTestPage mylistpage = new MylistTestPage();

		int listSize = 0;
		String strListname = null;

		listSize = mylistpage.getMyListsLblSelectedlist().size();
		strListname = mylistpage.getMyListsLblSelectedlist().get(listSize - 1).getText();
		getBundle().setProperty("SelectedList", strListname);
		mylistpage.getMyListsLblSelectedlist().get(listSize - 1).click();
		PerfectoUtils.reportMessage("Selected List: " + strListname + " to copy items");
	}

	/**
	 * Report the toast message yet to be implemented
	 */
	@QAFTestStep(description = "I should see the success toast message")
	public void iShouldSeeTheSuccessToastMessage() {
		PerfectoUtils.reportMessage("Toast Message yet to be implemented", MessageTypes.Pass);
	}

	/**
	 * Get the first list name and save in a variable 'DeletedListName' Swipe
	 * across the list name 'DeletedListName' and report
	 * 
	 * @return list name 'DeletedListName'
	 */
	@QAFTestStep(description = "I try to delete the Weekly Grocery List")
	public void iTryToDeleteTheWeeklyGroceryList() {
		MylistTestPage myListPage = new MylistTestPage();

		// Performing Swipe operation to delete the Weekly groceries list
		String strFirstListName = null;

		myListPage.waitForPageToLoad();
		myListPage.getMyListLblLstNameHotUser().waitForPresent(3000);
		strFirstListName = myListPage.getMyListLblLstNameHotUser().getText();
		getBundle().setProperty("DeletedListName", strFirstListName);

		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartX = Integer.parseInt(myListPage.getMyListLblLstNameHotUser().getAttribute("X"));
		int intEndX = (int) (size.width * 0.90);
		int intStartY = Integer.parseInt(myListPage.getMyListLblLstNameHotUser().getAttribute("Y"));
		getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);

		PerfectoUtils.reportMessage("Swiping across the list name: " + strFirstListName + " to delete",
				MessageTypes.Pass);
	}

	/**
	 * Scroll to Wish list and swipe across the Wish list to delete Update the
	 * wish list name in 'DeletedListName'
	 * 
	 * @return 'DeletedListName'
	 */
	@QAFTestStep(description = "I try to delete the Wish List")
	public void iTryToDeleteTheWishList() {
		MylistTestPage myListPage = new MylistTestPage();

		// Performing Swipe operation to delete the Wish List
		String strFirstListName = null;
		int i = 0;
		myListPage.waitForPageToLoad();

		while ((!myListPage.getMyListsLblWishlist().isPresent()) && (i < 5)) {
			PerfectoUtils.verticalswipe();
			i++;
		}

		// Swiping again to handle the partial visibility of Wish list
		PerfectoUtils.verticalswipe();
		myListPage.getMyListsLblWishlist().waitForPresent(3000);
		strFirstListName = myListPage.getMyListsLblWishlist().getText();
		getBundle().setProperty("DeletedListName", strFirstListName);

		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartX = Integer.parseInt(myListPage.getMyListsLblWishlist().getAttribute("X"));
		int intEndX = (int) (size.width * 0.90);
		int intStartY = Integer.parseInt(myListPage.getMyListsLblWishlist().getAttribute("Y"));
		getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);

		PerfectoUtils.reportMessage("Swiping across the list name: " + strFirstListName + " to delete",
				MessageTypes.Pass);
	}

	/**
	 * Verify wish list is not deleted by comparing current list name list is
	 * 'Wish List'
	 */
	@QAFTestStep(description = "I Verify Hot user is not able to delete the Wish List")
	public void iVerifyHotUserIsNotAbleToDeleteTheWishList() {
		ListdetailsTestPage listdetailspage = new ListdetailsTestPage();

		listdetailspage.getListpageTitleWishlistpage().waitForPresent(5000);
		listdetailspage.getListpageTitleWishlistpage().verifyPresent();
		String strPageTitle = listdetailspage.getListpageTitleWishlistpage().getText();

		if (strPageTitle.equalsIgnoreCase("Wish List")) {
			PerfectoUtils.reportMessage("Unable to delete the Wish List as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not able navigate to the Wish List", MessageTypes.Pass);
		}
	}

	/**
	 * Click on the uncheck all items if the uncheck all items field is present
	 */
	@QAFTestStep(description = "I select Uncheck All Items")
	public void iSelectUncheckAllItems() {
		ListdetailsTestPage listdetails = new ListdetailsTestPage();

		listdetails.getListpageLinkUncheckitem().waitForPresent(10000);

		if (listdetails.getListpageLinkUncheckitem().isPresent()) {
			listdetails.getListpageLinkUncheckitem().click();
			PerfectoUtils.reportMessage("Navigated to Uncheck all Items", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Uncheck all Items", MessageTypes.Fail);
		}
	}

	/**
	 * Verify my list page by checking list name
	 */
	@QAFTestStep(description = "I see My List page")
	public void iSeeMyListPage() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.waitForPageToLoad();
		mylistpage.getMyListLblPagetitle().waitForPresent(35000);
		mylistpage.getMyListLblPagetitle().verifyPresent();
		String pgtitle = mylistpage.getMyListLblPagetitle().getText();
	}

	/**
	 * Navigate through the category 'items' and land in a category page Click
	 * on the first listed item and update the list name in variable
	 * 'ChoosenProduct'
	 * 
	 * @return 'ChoosenProduct'
	 * @param items
	 */
	@QAFTestStep(description = "I see PDP page by navigating {0} items")
	public void iSeePDPPageByNavigatingItems(List<String> items) {
		ProductlandingTestPage productlanding = new ProductlandingTestPage();
		ProductsresultlistTestPage itemresult = new ProductsresultlistTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		productlanding.waitForPageToLoad();

		// Navigating through the category page
		for (String lable : items) {

			try {
				weeklygrocery.getShopingListEntryByLable(lable).waitForPresent(10000);
			} catch (Exception e) {
				PerfectoUtils.verticalswipe();
				weeklygrocery.getShopingListEntryByLable(lable).waitForPresent(20000);
			}

			waitForPresent("name=" + lable);
			click("name=" + lable);
			if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
				PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Pass);
				storelocator.getStorelocatorBtnAllow().click();
			}
			PerfectoUtils.reportMessage("Clicked Catagory Name: " + lable + " ", MessageTypes.Info);
		}

		itemresult.getProductresultlist().get(0).waitForPresent(50000);

		// Clicking single product from CDP page
		if (itemresult.getProductresultlist().size() != 0) {
			ProductResult result = itemresult.getProductresultlist().get(0);
			String prdName = result.getProductresultLblProductname().getText();
			getBundle().setProperty("ChoosenProduct", prdName);
			ProductdetailTestPage pdp = result.select();
			PerfectoUtils.reportMessage("Clicked product:" + prdName + "from CDP page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("No products displayed for the catogory navigation", MessageTypes.Fail);
		}
	}

	/**
	 * Click on the add to list list button and save the product name in
	 * variable 'ChoosenProduct'
	 * 
	 * @return ChoosenProduct
	 */
	@QAFTestStep(description = "I click add to list from PDP page")
	public void iClickAddToListFromPDPPage() {
		ProductdetailTestPage pdpTestPage = new ProductdetailTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
			PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Pass);
			storelocator.getStorelocatorBtnAllow().click();
		}

		// Getting Product Title from PDP page
		pdpTestPage.getPdpLblProductname().waitForPresent(5000);
		String strProductName = pdpTestPage.getPdpLblProductname().getText();
		getBundle().setProperty("ChoosenProduct", strProductName);

		// clicking Add to list button from PDP Page
		PerfectoUtils.scrollToElement(pdpTestPage.getPdpBtnAddtolist());
		pdpTestPage.getPdpBtnAddtolist().click();
		PerfectoUtils.reportMessage("Clicked Add To List button", MessageTypes.Pass);
	}

	/**
	 * Click on login from shopping list page
	 */
	@QAFTestStep(description = "I click on Login from Shopping List page")
	public void iClickOnLoginFromList() {
		WeeklygroceriesTestPage wgTestPage = new WeeklygroceriesTestPage();

		wgTestPage.getWgBtnLogIn().waitForPresent(3000);
		wgTestPage.getWgBtnLogIn().click();
		PerfectoUtils.reportMessage("Clicked: Login button", MessageTypes.Pass);
	}

	/**
	 * Click on forgot password link from login overlay
	 */
	@QAFTestStep(description = "I click Forgot Password link from Login overlay")
	public void iClickForgotPasswordLinkFromLoginOverlay() {
		LoginsplashTestPage loginsplashpage = new LoginsplashTestPage();

		loginsplashpage.getLoginLblForgotPassword().waitForPresent(5000);
		loginsplashpage.getLoginLblForgotPassword().click();
		PerfectoUtils.reportMessage("Click Forgot Password Link", MessageTypes.Pass);
	}

	/**
	 * Verify forgot password page title & email field are displayed
	 */
	@QAFTestStep(description = "I see Forgot Password page")
	public void iSeeForgotPasswordPage() {
		ForgotpasswordTestPage forgotpwd = new ForgotpasswordTestPage();

		forgotpwd.getLblTitle().waitForPresent(5000);
		forgotpwd.getLblTitle().verifyPresent();
		forgotpwd.getTxtEmail().verifyPresent();
	}

	/**
	 * Navigate to respective category page using 'items' Click on All prodcuts
	 * tab and select the first listed item Save the item name in
	 * 'ChoosenProduct'
	 * 
	 * @param items
	 * @return ChoosenProduct
	 */
	@QAFTestStep(description = "I see PDP page by navigating {0} items under All Products")
	public void iSeePDPPageByNavigatingItemsUnderAllProducts(List<String> items) {
		ProductlandingTestPage productlanding = new ProductlandingTestPage();
		ProductsresultlistTestPage itemresult = new ProductsresultlistTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		productlanding.waitForPageToLoad();

		// Navigating through the category page
		for (String lable : items) {

			try {
				PerfectoUtils.horizontalswipe();
				productlanding.waitForPageToLoad();
				weeklygrocery.getShopingListEntryByLable(lable).waitForPresent(50000);
			} catch (Exception e) {
				PerfectoUtils.verticalswipe();
				weeklygrocery.getShopingListEntryByLable(lable).waitForPresent(30000);
			}

			waitForPresent("name=" + lable);
			// click("name=" + lable);
			weeklygrocery.getShopingListEntryByLable(lable).click();

			if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
				PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Pass);
				storelocator.getStorelocatorBtnAllow().click();
			}
			PerfectoUtils.reportMessage("Clicked Catagory Name: " + lable + " ", MessageTypes.Info);
		}

		// Clicking single product from CDP page
		itemresult.getDpdBMDownCarat().waitForPresent(50000);
		int cellcnt = itemresult.getProductresultlist().size();

		if (cellcnt != 0) {
			for (ProductResult result : itemresult.getProductresultlist()) {
				String prdName = result.getProductresultLblProductname().getText();
				getBundle().setProperty("ChoosenProduct", prdName);
				ProductdetailTestPage pdp = result.select();
				PerfectoUtils.reportMessage("Clicked product:" + prdName + "from CDP page", MessageTypes.Pass);
				break;
			}
		} else {
			PerfectoUtils.reportMessage("No products displayed for the catogory navigation", MessageTypes.Fail);
		}
	}

	/**
	 * verify the my list page title is displayed
	 */
	@QAFTestStep(description = "I should see the My Lists page")
	public void iShouldSeeTheMyListsPage() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.getMyListLblPagetitle().verifyPresent();
	}

	/**
	 * verify the my list page is not displayed
	 */
	@QAFTestStep(description = "I check my list page is not displayed")
	public void iCheckMyListPageIsNotDisplayed() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String selectedlist = getBundle().getString("selectedList");
		if (!weeklygrocery.getShopingListEntryByLable(selectedlist).isPresent())
			PerfectoUtils.reportMessage("Selected list page is not displayed..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Selected list page is displayed..", MessageTypes.Fail);

	}

	/**
	 * verify the my list page is not displayed
	 */
	@QAFTestStep(description = "I verify the error popup for invalid scan")
	public void iVerifyTheErrorPopupForInvalidScan() {
		LoginpopupTestPage popup = new LoginpopupTestPage();
		AppcrashhandlerTestPage appCrashHandler = new AppcrashhandlerTestPage();
		ListdetailsTestPage listdetails = new ListdetailsTestPage();
		System.out.println(popup.getLoginpopupTxtAlerttitle().getText());
		if (popup.getLoginpopupTxtAlerttitle().getText().contains("Product Not Found")) {
			PerfectoUtils.reportMessage("Product Not Found popup is displayed..", MessageTypes.Pass);

			if (appCrashHandler.getExceptionBtnOk().isPresent())
				appCrashHandler.getExceptionBtnOk().click();
			else if (appCrashHandler.getExceptionBtnCancel().isPresent())
				appCrashHandler.getExceptionBtnCancel().click();

			listdetails.getPageLinkScanproduct().waitForPresent(3000);
			PerfectoUtils.reportMessage("Scan prouduct page is displayed..");
		} else
			PerfectoUtils.reportMessage("popup not found.", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Get all the available Shoppinglists")
	public void getAllTheAvailableShoppinglists() {
		MylistTestPage mylists = new MylistTestPage();

		int ShoppinglistsCount = mylists.getMyListsLblListname().size();
		System.out.println("**********" + ShoppinglistsCount);
		getBundle().setProperty("ListCount_FromMyListsPage", ShoppinglistsCount);

	}

}