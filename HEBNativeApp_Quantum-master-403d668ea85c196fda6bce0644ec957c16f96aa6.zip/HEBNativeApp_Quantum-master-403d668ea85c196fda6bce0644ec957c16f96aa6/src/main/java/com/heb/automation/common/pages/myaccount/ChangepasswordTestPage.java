package com.heb.automation.common.pages.myaccount;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ChangepasswordTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "changepswd.lbl.pageheader")
	private QAFWebElement lblPagetitle;
	
	@FindBy(locator = "changepswd.txt.enteroldpass")
	private QAFWebElement changepswdTxtEnteroldpass;
	@FindBy(locator = "changepswd.txt.enternewpass")
	private QAFWebElement changepswdTxtEnternewpass;
	
	@FindBy(locator = "changepswd.lbl.tipOldPassword")
	private QAFWebElement lblTipOldPassword;
	@FindBy(locator = "changepswd.lbl.tipconfirmnewpwd")
	private QAFWebElement lblTipconfirmnewpwd;
	
	@FindBy(locator = "changepswd.btn.save")
	private QAFWebElement changepswdBtnSave;
	
	@FindBy(locator = "changepswd.lbl.pswderrormsg")
	private QAFWebElement changepswdLblPswderrormsg;
	
	@FindBy(locator = "changepswd.btn.back")
	private QAFWebElement changepswdBtnBackIOS;	
	@FindBy(locator = "changepswd.btn.warningok")
	private QAFWebElement btnWarningok;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getChangepswdTxtEnteroldpass() {
		return changepswdTxtEnteroldpass;
	}

	public QAFWebElement getChangepswdTxtEnternewpass() {
		return changepswdTxtEnternewpass;
	}
	
	public QAFWebElement getLblTipOldPassword() {
		return lblTipOldPassword;
	}

	public QAFWebElement getLblTipconfirmnewpwd() {
		return lblTipconfirmnewpwd;
	}
	
	public QAFWebElement getChangepswdBtnSave() {
		return changepswdBtnSave;
	}

	public QAFWebElement getChangepswdBtnBackIOS() {
		changepswdBtnBackIOS.waitForPresent(7000);
		return changepswdBtnBackIOS;
	}

	public QAFWebElement getLblPageTitle() {
		return lblPagetitle;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
	
	public QAFWebElement getChangepswdLblPswderrormsg() {
		return changepswdLblPswderrormsg;
	}
	
	// DYNAMIC value declaring
	public QAFWebElement getChangepswdSaveEnableByLable(int label) {
		String loc = String.format(pageProps.getString("changepswd.btn.enablesave"), label);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getBtnWarningok() {
		return btnWarningok;
	}
	
}
