package com.heb.automation.common.pages;

import java.util.List;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.myaccount.MyaccountTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class FAQTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "app.lbl.faqpagetitle")
	private QAFWebElement appfaqlblpagetitle;
	@FindBy(locator = "app.lbl.faqcommonques")
	private QAFWebElement lblFaqcommonques;
	@FindBy(locator = "app.lbl.faqproduct")
	private QAFWebElement lblFaqproduct;
	@FindBy(locator = "app.lbl.faqproductques")
	private QAFWebElement lblFaqproductques;
	@FindBy(locator = "app.lbl.faqmylist")
	private QAFWebElement lblFaqmylist;
	@FindBy(locator = "app.lbl.faqmylistques")
	private QAFWebElement lblFaqmylistques;
	@FindBy(locator = "app.lbl.faqpharmacy")
	private QAFWebElement lblFaqpharmacy;
	@FindBy(locator = "app.lbl.faqpharmacyques")
	private QAFWebElement lblFaqpharmacyques;
	@FindBy(locator = "app.lbl.faqdigcoup")
	private QAFWebElement lblFaqdigcoup;
	@FindBy(locator = "app.lbl.faqdigcoupques")
	private QAFWebElement lblFaqdigcoupques;
	
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}
	
	public QAFWebElement getAppFaqsblbPageTitle() {
		return appfaqlblpagetitle;
	}

	public QAFWebElement getLblFaqcommonques() {
		return lblFaqcommonques;
	}

	public QAFWebElement getLblFaqproduct() {
		return lblFaqproduct;
	}

	public QAFWebElement getLblFaqproductques() {
		return lblFaqproductques;
	}

	public QAFWebElement getLblFaqmylist() {
		return lblFaqmylist;
	}

	public QAFWebElement getLblFaqmylistques() {
		return lblFaqmylistques;
	}

	public QAFWebElement getLblFaqpharmacy() {
		return lblFaqpharmacy;
	}

	public QAFWebElement getLblFaqpharmacyques() {
		return lblFaqpharmacyques;
	}

	public QAFWebElement getLblFaqdigcoup() {
		return lblFaqdigcoup;
	}

	public QAFWebElement getLblFaqdigcoupques() {
		return lblFaqdigcoupques;
	}

}
