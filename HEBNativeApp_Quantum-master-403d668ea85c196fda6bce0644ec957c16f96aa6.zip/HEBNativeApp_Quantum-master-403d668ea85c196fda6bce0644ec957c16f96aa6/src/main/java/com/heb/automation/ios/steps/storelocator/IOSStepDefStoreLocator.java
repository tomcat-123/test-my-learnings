/**
 * 
 */
package com.heb.automation.ios.steps.storelocator;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.heb.automation.android.steps.AndroidStepDef;
import com.heb.automation.android.steps.weeklyad.AndroidStepDefWeeklyAds;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.StoreResult;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.coupons.CouponsselectionTestPage;
import com.heb.automation.common.pages.myaccount.MyaccountTestPage;
import com.heb.automation.common.pages.products.ProductstoredetailsmodalTestPage;
import com.heb.automation.common.pages.recipes.RecipeslandingTestPage;
import com.heb.automation.common.pages.shoppinglist.MylistTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.storelocator.StoredetailsTestPage;
import com.heb.automation.common.pages.storelocator.StorelistviewresultTestPage;
import com.heb.automation.common.pages.storelocator.StorelocatorTestPage;
import com.heb.automation.common.pages.storelocator.StoremapviewTestPage;
import com.heb.automation.common.pages.weeklyad.WeeklyadslandingTestPage;
import com.heb.automation.common.steps.coupons.CommonStepDefCoupons;
import com.heb.automation.common.steps.recipes.CommonStepDefRecipes;
import com.heb.automation.common.steps.weeklyad.CommonStepDefWeeklyAds;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.heb.automation.ios.steps.coupons.IOSStepdefCoupons;
import com.heb.automation.ios.steps.weeklyad.IOSStepdefWeeklyAd;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in StoreLocator 

	I should see the store name in my Store Locator page as default
	I change my store and select a different store
	I choose an store from the store list
	I navigate back to listview page
	I navigate back to mapview page and click on search icon
	I see Search Field is displayed by clicking on Search Icon in map view of storelocator
	I select a store in map view
	I click on done/Apply button after selecting stores
	I choose a store from the store locator page
	I navigate back to listview page and click on search icon
	I verify List view  page
	I verify filter options
	I navigate to the listed option in Store detail
	I select two refine filter and click on done button
	I verify refine result
	I navigate back to list view and verify the refine results
	I select a store in map view for hotuser
	I should see store detail page
	I validate the list view of store locator page
	I choose second store from the store locator page
	I navigate to List View page
	I navigate to StoreLocator
	I navigated to store details modal from More section of the app
	I verify the map view on the top of the page
	I verify change store, weekly ad and store features in My Store
	I validate Set as My H-E-B store option is not present in store detail
	I clicked on storelocator from home page
	I verify the stores that are getting displayed
	I verify that different set of stores are getting displayed
	I set the store as my heb store
	I navigate to my store page*/

public class IOSStepDefStoreLocator {
	/**
	 * user should see the store name in my Store Locator page as default
	 */
	@QAFTestStep(description = "I should see the store name in my Store Locator page as default")
	public void iShouldSeeTheStoreNameInMyStoreLocatorPageAsDefault() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		HomeTestPage homepage = new HomeTestPage();

		ioscommon.getAppMoreMore().click();
		ioscommon.waitForPageToLoad();
		ioscommon.getAppMoreMystorename().waitForPresent(5000);
		ioscommon.getAppMoreMystorename().verifyPresent();
		// Click Home icon in footer
		homepage.getAppFooterHomeicon().click();
		homepage.waitForPageToLoad();
		if (!homepage.getHomeLblWelcomeUser().isPresent()) {
			homepage.getAppFooterHomeicon().click();
			homepage.waitForPageToLoad();
		}
		homepage.waitForPageToLoad();
		homepage.getHomeLblWelcomeUser().waitForPresent(5000);
		// Navigating to Store locator page
		PerfectoUtils.verticalswipe();
		homepage.getHomeLblStoreLocator().waitForPresent();
		homepage.getHomeLblStoreLocator().click();
	}

	/**
	 * user change a store and select a different store
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I change my store and select a different store")
	public void iChangeMyStoreAndSelectADifferentStore() throws InterruptedException {
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		StoredetailsTestPage storedetail = new StoredetailsTestPage();

		storepage.getStorelocatorImgListswitch().waitForPresent(5000);
		storepage.getStorelocatorImgListswitch().click();
		storelistresult.waitForPageToLoad();
		int intChoosenStrOrder = getBundle().getInt("ChoosenStoreNumber");
		if (intChoosenStrOrder == 2) {
			intChoosenStrOrder = intChoosenStrOrder - 1;
		} else {
			intChoosenStrOrder = intChoosenStrOrder + 1;
		}
		StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(intChoosenStrOrder);
		store.click();
		storedetail.getStoredetailsViewstorename().waitForPresent(5000);
		String StoreName = storedetail.getStoredetailsViewstorename().getText();
		PerfectoUtils.reportMessage("Store Name:" + StoreName);
	}

	/**
	 * user choose an store from the store lis
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I choose an store from the store list")
	public void iChooseAnStoreFromTheStoreList() throws InterruptedException {
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		StoredetailsTestPage storedetail = new StoredetailsTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		storepage.getStorelocatorImgListswitch().waitForPresent(5000);
		storepage.getStorelocatorImgListswitch().click();
		storelistresult.launchPage(null);
		System.out.println(storelistresult.getStorelocatorLblStoreresults().size());
		StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(2);
		store.click();
		storedetail.getStoredetailsViewstorename().waitForPresent(5000);
		String StoreName = storedetail.getStoredetailsViewstorename().getText();
		PerfectoUtils.reportMessage("Store Name:" + StoreName);
		getBundle().setProperty("ChoosenStoreNumber", "2");
		PerfectoUtils.reportMessage("Selected Store: " + StoreName, MessageTypes.Pass);

		try {
			storedetail.waitForPageToLoad();
			PerfectoUtils.verticalswipe(80, 75, 2);
			storedetail.getStoredetailsSetasyourstore().waitForPresent(10000);
			storedetail.getStoredetailsSetasyourstore().verifyPresent();
			getBundle().setProperty("ChoosenStoreNumber", "2");
			System.out.println(getBundle().getProperty("ChoosenStoreNumber"));
			PerfectoUtils.horizontalswipe();
		} catch (Exception e) {
			ioscommon.getScanBtnBack().click();
			storelistresult.waitForPageToLoad();
			System.out.println(storelistresult.getStorelocatorLblStoreresults().size());
			StoreResult store1 = storelistresult.getStorelocatorLblStoreresults().get(1);
			store1.click();
			storedetail.getStoredetailsViewstorename().waitForPresent(5000);
			StoreName = storedetail.getStoredetailsViewstorename().getText();
			PerfectoUtils.reportMessage("Store Name:" + StoreName);
			storedetail.waitForPageToLoad();
			PerfectoUtils.verticalswipe(80, 75, 2);
			storedetail.getStoredetailsSetasyourstore().waitForPresent(20000);
			storedetail.getStoredetailsSetasyourstore().verifyPresent();
			getBundle().setProperty("ChoosenStoreNumber", "1");
		}
	}

	@QAFTestStep(description = "I navigate back to listview page")
	public void iNavigateBackToListviewPage() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		ioscommon.getAppBtnBackIOS().click();
		ioscommon.waitForPageToLoad();
	}

	/**
	 * user navigate back to mapview page and click on search icon
	 */
	@QAFTestStep(description = "I navigate back to mapview page and click on search icon")
	public void iNavigateBackToMapviewPage() {
		StoremapviewTestPage mapview = new StoremapviewTestPage();

		// click on device back button
		iNavigateBackToListviewPage();
		// click on search icon
		mapview.getStorelocatorIconClosesearch().waitForPresent(1000);
		mapview.getStorelocatorIconClosesearch().click();
		mapview.getStorelocatorTxtSearch().click();
		PerfectoUtils.reportMessage("Entering zip code", MessageTypes.Pass);
	}

	/**
	 * user verifies that Search Field is displayed by clicking on Search Icon
	 * in map view
	 */
	@QAFTestStep(description = "I see Search Field is displayed by clicking on Search Icon in map view of storelocator")
	public void iSeeSearchFieldIsDisplayedByClickingOnSearchIconInMapViewOfStorelocator() {
		StoremapviewTestPage mapview = new StoremapviewTestPage();

		// Click on search icon
		mapview.getStorelocatorIconSearch().waitForPresent(5000);
		mapview.getStorelocatorTxtSearch().verifyPresent();
		mapview.getStorelocatorTxtSearch().click();
		PerfectoUtils.reportMessage("Clicked on Search field.", MessageTypes.Pass);
	}

	/**
	 * user selects a store from the map view
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I select a store in map view")
	public void iSelectAStoreInMapView() throws InterruptedException {
		StoremapviewTestPage mapview = new StoremapviewTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		int i = 14;
		// click on store in map view
		storelocator.getStorelocatorImgMapswitch().waitForPresent(3000);
		storelocator.getStorelocatorImgMapswitch().click();
		try {
			mapview.getStoreFromMap(i).waitForPresent(5000);
			mapview.getStoreFromMap(i).click();
			PerfectoUtils.reportMessage("Store selected: " + storelocator.getStorelocatorBubbleStorename().getText(),
					MessageTypes.Pass);
		} catch (Exception g) {
			try {
				i = 64;
				mapview.getStoreFromMap(i).waitForPresent(5000);
				mapview.getStoreFromMap(i).click();
				PerfectoUtils.reportMessage("Store selected: " + storelocator.getStorelocatorBubbleStorename().getText(),
						MessageTypes.Pass);
			} catch (Exception h) {
				i = 6;
				mapview.getStoreFromMap(i).waitForPresent(5000);
				mapview.getStoreFromMap(i).click();
				PerfectoUtils.reportMessage("Store selected: " + storelocator.getStorelocatorBubbleStorename().getText(),
						MessageTypes.Pass);
			}
		}

		try {
			mapview.getImgInfo().waitForPresent(3000);
			mapview.getImgInfo().click();
		} catch (Exception f) {

			Map<String, Object> params1 = new HashMap<>();
			// params1.put("content", "GROUP:iOS\\Store
			// locator\\info_icon.png");
			params1.put("content", "GROUP:iOS\\Store locator\\infoicon1_image.png");
			params1.put("screen.top", "0%");
			params1.put("screen.height", "50%");
			params1.put("screen.left", "0%");
			params1.put("screen.width", "100%");
			params1.put("context", "all");
			params1.put("timeout", "20");
			params1.put("threshold", "20");
			params1.put("duration", "20");
			params1.put("interval", "4");
			try {
				String result1 = (String) mapview.getTestBase().getDriver().executeScript("mobile:image:select",
						params1);
				System.out.println(result1);
			} catch (Exception e) {
				e.printStackTrace();
				PerfectoUtils.reportMessage("Unable to select store", MessageTypes.Fail);
			}
		}
	}

	/**
	 * user clicks on done/Apply button after selecting stores
	 */
	@QAFTestStep(description = "I click on done/Apply button after selecting stores")
	public void iClickOnDoneApplyButtonAfterSelectingStores() {
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		// Clicking on apply button
		storelocator.getstorelocatorchkpharmacy().waitForPresent(3000);
		storelocator.getstorelocatorchkpharmacy().click();
		PerfectoUtils.reportMessage("Slected Pharmacy from the Refine options.", MessageTypes.Pass);
		storelocator.getstorelocatorbtnapply().waitForPresent();
		storelocator.getstorelocatorbtnapply().click();
		PerfectoUtils.reportMessage("Clicked Apply button.", MessageTypes.Pass);
		storelocator.getstorelocatorbubblemapview().verifyPresent();
	}

	/**
	 * user choose a store from the store locator page
	 */
	@QAFTestStep(description = "I choose a store from the store locator page")
	public void iChooseAStoreFromTheStoreLocatorPage() {
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();

		storepage.getStorelocatorImgListswitch().waitForPresent(5000);
		storepage.getStorelocatorImgListswitch().click();
		StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(1);
		getBundle().setProperty("StoreAddress", store.getStorelocatorLblStorename().getText());
		getBundle().setProperty("StoreName", store.getStorelocatorLblStorename().getText());
		PerfectoUtils.reportMessage("Selected Store: " + store.getStorelocatorLblStorename().getText(), MessageTypes.Pass);
		store.click();
	}

	/**
	 * user navigate back to list view page and click on search icon
	 */
	@QAFTestStep(description = "I navigate back to listview page and click on search icon")
	public void iNavigateBackToListviewPageAndClickOnSearchIcon() {
		StoremapviewTestPage mapview = new StoremapviewTestPage();

		// click on device back button
		iNavigateBackToListviewPage();
		// click on search icon
		mapview.getStorelocatorIconClosesearch().waitForPresent(1000);
		mapview.getStorelocatorIconClosesearch().click();
		mapview.getStorelocatorTxtSearch().waitForPresent(8000);
		mapview.getStorelocatorTxtSearch().click();
		mapview.waitForPageToLoad();
		PerfectoUtils.reportMessage("Entering zip code", MessageTypes.Pass);
	}

	/**
	 * user verify List view page
	 */
	@QAFTestStep(description = "I verify List view  page")
	public void iVerifyListViewPage() {
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		StorelistviewresultTestPage storelist = new StorelistviewresultTestPage();

		storelocator.getStorelocatorTxtSearchicon().verifyPresent();
		storelocator.getStorelocatorLblRefine().verifyPresent();
		storelist.getStoreresult().verifyPresent();
	}

	/**
	 * User verify filter options
	 */
	@QAFTestStep(description = "I verify filter options")
	public void iVerifyFilterOptions() {
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		StoremapviewTestPage mapview = new StoremapviewTestPage();

		storelocator.getstorelocatorbubblemapview().click();
		storelocator.getStorelocatorBubbleStorename().waitForPresent(2000);
		storelocator.getStorelocatorBubbleStorename().verifyPresent();
		PerfectoUtils.reportMessage("Store selected:" + storelocator.getStorelocatorBubbleStorename().getText(), MessageTypes.Pass);
		storelocator.getStorelocatorBubbleStorename().click();
		storelocator.getStoreDetailLblPharmacy().waitForPresent(2000);
		storelocator.getStoreDetailLblPharmacy().verifyPresent();
	}

	/**
	 * user verify the listed options in store detail page
	 */
	@QAFTestStep(description = "I navigate to the listed option in Store detail")
	public void iNavigateToTheListedOptionInStoreDetail() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();
		WeeklyadslandingTestPage weeklylanding = new WeeklyadslandingTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		// Verifying and clicking get direction
		if (storedetail.getStoredetailsGetdirections().isPresent()) {
			storedetail.getStoredetailsGetdirections().click();
			storedetail.getStoreldetailsLblAlerttitle().isPresent();
			PerfectoUtils.reportMessage("Get Directions alert is displayed", MessageTypes.Pass);
			storedetail.getStoredetailsLblCancel().waitForPresent(20000);
			storedetail.getStoredetailsLblCancel().click();
			storedetail.waitForPageToLoad();
			PerfectoUtils.reportMessage("clicked on cancel button", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("Get Direction is not present", MessageTypes.Fail);
		}

		// Verifying and clicking view phone number
		if (storedetail.getStoreldetailsLblHotuserphoneno().isPresent()) {
			storedetail.getStoreldetailsLblHotuserphoneno().click();
			storedetail.getStoreldetailsLblAlerttitle().isPresent();
			PerfectoUtils.reportMessage("Phone number dial alert is displayed", MessageTypes.Pass);
			storedetail.getStoredetailsLblCancel().waitForPresent(20000);
			storedetail.getStoredetailsLblCancel().click();
			storedetail.waitForPageToLoad();
			PerfectoUtils.reportMessage("clicked on cancel button", MessageTypes.Pass);
		} else if (storedetail.getStoredetailsViewphonenumber().isPresent()) {
			// Cold user validation
			storedetail.getStoredetailsViewphonenumber().click();
			storedetail.getStoreldetailsLblAlerttitle().isPresent();
			PerfectoUtils.reportMessage("Phone number dial alert is displayed", MessageTypes.Pass);
			storedetail.getStoredetailsLblCancel().waitForPresent(20000);
			storedetail.getStoredetailsLblCancel().click();
			storedetail.waitForPageToLoad();
			PerfectoUtils.reportMessage("clicked on cancel button", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("View phone number is not present", MessageTypes.Fail);
		}

		// Verifying and clicking weekly ad
		// PerfectoUtils.verticalswipe(80, 75, 2);
		PerfectoUtils.verticalswipe();
		if (storedetail.getStoredetailsViewweeklyad().isPresent()) {
			storedetail.getStoredetailsViewweeklyad().click();
			weeklylanding.getLandingPageTitle().verifyPresent();
			PerfectoUtils.reportMessage("clicked on weekly ad button", MessageTypes.Pass);
			ioscommon.getAppBtnBackIOS().click();
		} else {
			PerfectoUtils.reportMessage("skipped click option", MessageTypes.Fail);
		}
		storedetail.waitForPageToLoad();

		// See store features
		if (storedetail.getStoreldetailsLblSeestore().isPresent()) {
			storedetail.getStoreldetailsLblSeestore().click();
			storedetail.getStoreldetailsLblPgtitlestorefeature().verifyPresent();
			PerfectoUtils.reportMessage("clicked on See Store Features", MessageTypes.Pass);
			ioscommon.getAppBtnBackIOS().click();
		} else {
			PerfectoUtils.reportMessage("skipped click option", MessageTypes.Fail);
		}
	}

	/**
	 * user select two refine filter and click on done button
	 */
	@QAFTestStep(description = "I select two refine filter and click on done button")
	public void iSelectTwoRefineFilterAndClickOnDoneButton() {
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		// Clicking on Car Wash and fuel option from refine page
		storelocator.waitForPageToLoad();
		storelocator.getStorelocatorChkCarwash().waitForPresent(20000);
		storelocator.getStorelocatorChkCarwash().click();
		storelocator.getStorelocatorChkFuel().click();
		storelocator.getstorelocatorbtnapply().waitForPresent();
		storelocator.getstorelocatorbtnapply().click();
	}

	/**
	 * user verify refine result
	 */
	@QAFTestStep(description = "I verify refine result")
	public void iVerifyRefineResult() {
		StorelistviewresultTestPage listview = new StorelistviewresultTestPage();

		// Verifying refine option
		List<StoreResult> items = listview.getStorelocatorLblStoreresults();
		System.out.println("total no of product" + items.size());

		try {
			listview.getStoreloclistviewImgFuel().get(1).verifyPresent();
			listview.getStoreloclistviewImgCarwash().get(1).verifyPresent();
			PerfectoUtils.reportMessage("Stores are filtered for fuel and Car wash option", MessageTypes.Pass);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Stores are not filtered for fuel and Car wash option", MessageTypes.Fail);
		}

	}

	/**
	 * user navigate back to list view and verify the refine results
	 */
	@QAFTestStep(description = "I navigate back to list view and verify the refine results")
	public void iNavigateBackToListViewAndVerifyTheRefineResults() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		ioscommon.getAppBtnBackIOS().click();
		iVerifyRefineResult();
	}

	/**
	 * hot user selects a store in map view
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I select a store in map view for hotuser")
	public void iSelectAStoreInMapViewForHotuser() throws InterruptedException {
		StoremapviewTestPage mapview = new StoremapviewTestPage();
		StoredetailsTestPage storedetail = new StoredetailsTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		// click on store in map view
		mapview.getStorelocatorMapSelectstore().click();
		PerfectoUtils.reportMessage("Store clicked", MessageTypes.Pass);

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "GROUP:iOS\\Store locator\\infoicon1_image.png");
		params1.put("screen.top", "0%");
		params1.put("screen.height", "50%");
		params1.put("screen.left", "0%");
		params1.put("screen.width", "100%");
		params1.put("context", "all");
		params1.put("threshold", "20");
		params1.put("duration", "20");
		params1.put("interval", "4");
		Object result1 = mapview.getTestBase().getDriver().executeScript("mobile:image:select", params1);

		try {
			storedetail.waitForPageToLoad();
			storedetail.getStoredetailsSetasyourstore().waitForPresent(20000);
			storedetail.getStoredetailsSetasyourstore().verifyPresent();
		} catch (Exception e) {
			ioscommon.getAppBtnBackIOS().click();
			mapview.waitForPageToLoad();
			/*
			 * mapview.getStorelocatorMapSelectanotherstore().waitForPresent(
			 * 50000); mapview.getStorelocatorMapSelectanotherstore().click();
			 * PerfectoUtils.reportMessage("Store clicked", MessageTypes.Pass);
			 * mapview.waitForPageToLoad();
			 * 
			 * Map<String, Object> params3 = new HashMap<>();
			 * params3.put("content", "GROUP:iOS\\Store locator\\info_icon.png"
			 * ); //params3.put("timeout", "10"); params3.put("interval", "5");
			 * params3.put("match", "similar"); params3.put("screen.top",
			 * "20%"); params3.put("screen.height", "80%");
			 * params3.put("screen.left", "0%"); params3.put("screen.width",
			 * "100%"); Object result3 =
			 * mapview.getTestBase().getDriver().executeScript(
			 * "mobile:image:select", params3);
			 */
			getBundle().setProperty("ChoosenStoreNumber", 2);
			iChangeMyStoreAndSelectADifferentStore();
		}
	}

	/**
	 * user should see store detail page
	 */
	@QAFTestStep(description = "I should see store detail page")
	public void iShouldSeeStoreDetailPage() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();

		// Verify store detail page
		storedetail.getStoredetailsViewstorename().waitForPresent(50000);
		boolean storedtl = storedetail.getStoredetailsViewstorename().verifyPresent();
		String StoreName = storedetail.getStoredetailsViewstorename().getText();
		getBundle().setProperty("SelectedStoreName", storedetail.getStoredetailsViewstorename().getText());
		if (storedtl) {
			PerfectoUtils.reportMessage("Store detail page is displayed for the store:" + StoreName, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Store detail page is not displayed", MessageTypes.Fail);
		}
	}

	/**
	 * user validate the list view of store locator page
	 */
	@QAFTestStep(description = "I validate the list view of store locator page")
	public void iValidateTheListViewOfStoreLocatorPage() {
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		StoremapviewTestPage mapview = new StoremapviewTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();

		// Navigate to list view
		storepage.getStorelocatorImgListswitch().waitForPresent(3000);
		storepage.getStorelocatorImgListswitch().click();
		try {
			// Verify all fields of list view
			storepage.getStorelocatorLblRefine().verifyPresent();
			mapview.getStorelocatorIconSearch().verifyPresent();
			storepage.getStorelocatorImgListswitch().verifyPresent();
			storepage.getStorelocatorImgMapswitch().verifyPresent();
			StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(0);
			store.getStorelocatorLblStorename().verifyPresent();
			PerfectoUtils.reportMessage("Validated store name: " + store.getStorelocatorLblStorename().getText(), MessageTypes.Info);
			store.getStorelocatorLblStoreaddress().verifyPresent();
			PerfectoUtils.reportMessage("Store Address: " + store.getStorelocatorLblStoreaddress().getText(), MessageTypes.Info);
			store.getStorelocatorLblMilesaway().verifyPresent();
			PerfectoUtils.reportMessage("Store MilesAway: " + store.getStorelocatorLblMilesaway().getText(), MessageTypes.Info);
			PerfectoUtils.reportMessage("Store locator LIST view page is validated", MessageTypes.Pass);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Store locator LIST view page is validated and found errors", MessageTypes.Fail);
		}
	}

	/**
	 * user choose second store from the store locator page
	 */
	@QAFTestStep(description = "I choose second store from the store locator page")
	public void iChooseSecondStoreFromTheStoreLocatorPage() {
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();

		storepage.getStorelocatorImgListswitch().waitForPresent(5000);
		storepage.getStorelocatorImgListswitch().click();
		storelistresult.launchPage(null);
		StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(2);
		getBundle().setProperty("StoreAddress", store.getStorelocatorLblStorename().getText());
		getBundle().setProperty("StoreName", store.getStorelocatorLblStorename().getText());
		PerfectoUtils.reportMessage("Selected Store: " + store.getStorelocatorLblStorename().getText(), MessageTypes.Pass);
		store.click();
	}

	public static void storelocatorErrorHandle() {
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		// Handling the store locator error
		if (!storelocator.getStorelocatorLblStoreLocator().isPresent()) {

			PerfectoUtils.reportMessage("Checking and Handling Popup...", MessageTypes.Pass);
			if (appcrash.getAppExceptionMsgTitle().isPresent()) {
				appcrash.getExceptionBtnOk().click();
				PerfectoUtils.reportMessage("Store Locator Currently Unavailable", MessageTypes.Info);
			} else if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
				PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Pass);
				storelocator.getStorelocatorBtnAllow().click();
				PerfectoUtils.reportMessage("Clicked Allow button.", MessageTypes.Pass);
			} else if (appcrash.getExceptionLblStoreLocError().isPresent()) {
				PerfectoUtils.reportMessage("Store Location Error: Unable to search for stores. Please try again.");
				appcrash.getExceptionLblContinueWithoutStore().click();
			} else if (weeklygrocery.getShopingListEntryByLable("access your location").isPresent()) {
				PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Info);
				ioscommon.getAppPopupBtnAllowPermission().verifyPresent();
				ioscommon.getAppPopupBtnAllowPermission().click();
			}
		} else {
			PerfectoUtils.reportMessage("No popups found.", MessageTypes.Pass);
		}
	}

	/**
	 * user Clicked on Switch to List View button
	 */
	@QAFTestStep(description = "I navigate to List View page")
	public static void iNavigateToListViewPage() {
		StorelocatorTestPage storepage = new StorelocatorTestPage();

		// Click on list view page
		storepage.getStorelocatorImgListswitch().waitForPresent(3000);
		storepage.getStorelocatorImgListswitch().click();
		PerfectoUtils.reportMessage("Clicked on Switch to List View button.", MessageTypes.Pass);
		// storelocatorErrorHandle();
		storepage.getStorelocatorImgListswitch().waitForPresent(5000);
	}

	/**
	 * Navigation to StoreLocator page.Handling store locator error
	 */
	@QAFTestStep(description = "I navigate to StoreLocator")
	public void iNavigateToStoreLocator() {
		HomeTestPage homepage = new HomeTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		homepage.getAppFooterHomeicon().waitForPresent(5000);
		homepage.getAppFooterHomeicon().click();
		PerfectoUtils.verticalswipe();
		try {
			homepage.getHomeLblStoreLocator().waitForPresent(5000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
			homepage.getHomeLblStoreLocator().waitForPresent();
		}

		// PerfectoUtils.setLocation("San antonio");
		homepage.getHomeLblStoreLocator().click();
		PerfectoUtils.reportMessage("Clicked on Store locator.", MessageTypes.Pass);

		/* Store locator error handle */
		storelocatorErrorHandle();
		/*
		 * Checking whether navigated to Store locator page successfully Else,
		 * handling the error pop up, navigating to home page, and navigating
		 * back to Store locator
		 */
		try {
			if (!storelocator.getStorelocatorLblRefine().isPresent()) {
				homepage.getAppFooterHomeicon().click();
				// PerfectoUtils.setLocation("San antonio");
				PerfectoUtils.verticalswipe();
				try {
					homepage.getHomeLblStoreLocator().waitForPresent(5000);
				} catch (Exception e) {
					PerfectoUtils.verticalswipe();
					homepage.getHomeLblStoreLocator().waitForPresent();
				}
				homepage.getHomeLblStoreLocator().click();

			} else {
				PerfectoUtils.reportMessage("Navigated to Store locator page.", MessageTypes.Pass);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Click on more section after setting location Select my store option from
	 * more and verify store details is loaded
	 */
	@QAFTestStep(description = "I navigated to store details modal from More section of the app")
	public void iNavigatedToStoreDetailsModalFromMoreSectionOfTheApp() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();

		// Set location
		// PerfectoUtils.setLocation("San antonio");

		// Navigate to more page
		ioscommon.getAppMoreMore().click();
		ioscommon.waitForPageToLoad();

		// Click on the my store
		ioscommon.getAppMoreMystorename().waitForPresent(8000);
		ioscommon.getAppMoreMystorename().verifyPresent();
		ioscommon.getAppMoreMystorename().click();

		// Verify store details modal is displayed
		storedetailsmodal.getStoremodalLblStorename().waitForPresent(6000);

		if (storedetailsmodal.getStoremodalLblStorename().isPresent())
			PerfectoUtils.reportMessage("Store detail modal is displayed..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Store detail modal is not displayed..", MessageTypes.Fail);

	}

	/**
	 * Verify the map view in store detail modal
	 */
	@QAFTestStep(description = "I verify the map view on the top of the page")
	public void iVerifyTheMapViewOnTheTopOfThePage() {

		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();

		// Verify map section
		storedetailsmodal.getStoremodalLblMapview().verifyPresent();
		storedetailsmodal.getStoremodalLblLocation().verifyPresent();
		storedetailsmodal.getStoremodalLblMappin().verifyPresent();

	}

	/*
	 * Verify the section change store, weekly ad and store features in store
	 * details modal And verify corresponding page is loaded
	 */
	@QAFTestStep(description = "I verify change store, weekly ad and store features in My Store")
	public void iVerifyChangeStoreWeeklyAdAndStoreFeaturesInMyStore() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();
		WeeklyadslandingTestPage weeklylanding = new WeeklyadslandingTestPage();
		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		// Verifying and clicking weekly ad
		PerfectoUtils.verticalswipe();
		if (storedetail.getStoredetailsViewweeklyad().isPresent()) {
			storedetail.getStoredetailsViewweeklyad().click();
			weeklylanding.getLandingPageTitle().waitForPresent(3000);
			weeklylanding.getLandingPageTitle().verifyPresent();
			PerfectoUtils.reportMessage("clicked on view weekly ad button", MessageTypes.Pass);
			ioscommon.getAppBtnBackIOS().click();
		} else {
			PerfectoUtils.reportMessage("Weekly add is not available", MessageTypes.Fail);
		}
		storedetail.waitForPageToLoad();
		PerfectoUtils.verticalswipe();

		// Verify Store features
		if (storedetailsmodal.getStoremodalLnkStorefeature().isPresent()) {
			storedetailsmodal.getStoremodalLnkStorefeature().click();
			storedetail.getStoreldetailsLblPgtitlestorefeature().verifyPresent();
			PerfectoUtils.reportMessage("clicked on Store Features", MessageTypes.Pass);
			ioscommon.getAppBtnBackIOS().click();
		} else {
			PerfectoUtils.reportMessage("Store feature is not available", MessageTypes.Fail);
		}

		// Verify Change store
		PerfectoUtils.verticalswipe();
		if (storedetailsmodal.getStoremodalLblChangemystore().isPresent()) {
			storedetailsmodal.getStoremodalLblChangemystore().verifyPresent();
			storedetailsmodal.getStoremodalLblChangemystore().click();
			storelocatorErrorHandle();

			storelocator.getStorelocatorLblRefine().waitForPresent(3000);
			if (storelocator.getStorelocatorLblRefine().isPresent())
				PerfectoUtils.reportMessage("Store locator page is displayed..", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Store locator page is not displayed..", MessageTypes.Fail);
		} else
			PerfectoUtils.reportMessage("Change store option is not available..", MessageTypes.Fail);

	}

	/**
	 * user verify the listed options in store detail page
	 */
	@QAFTestStep(description = "I validate Set as My H-E-B store option is not present in store detail")
	public void iValidateSetAsMyHEBStoreOptionIsNotPresentInStoreDetail() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();

		// storedetail.getStoredetailsSetasyourstore().verifyNotPresent();
		if (storedetail.getStoredetailsSetasyourstore().isPresent()) {
			PerfectoUtils.reportMessage("Able to see Set Store", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("Set Store option is not available", MessageTypes.Pass);
		}

	}

	@QAFTestStep(description = "I clicked on storelocator from home page")
	public void iclickedonstorelocatorfromhomepage() {

		HomeTestPage homepage = new HomeTestPage();
		homepage.waitForPageToLoad();
		try {
			homepage.getHomeLblStoreLocator().waitForPresent(10000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
		}
		homepage.getHomeLblStoreLocator().verifyPresent();
		homepage.getHomeLblStoreLocator().click();

	}

	@QAFTestStep(description = "I verify the stores that are getting displayed")
	public void iverifythestoresthataregettingdisplayed() {
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();

		StoredetailsTestPage storedetail = new StoredetailsTestPage();
		StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(2);
		int len = storelistresult.getStorelocatorLblStorenamelist().size();
		System.out.println(len);
		String Strname = storelistresult.getStorelocatorLblStoreresults().get(len - 1).getStorelocatorLblStorename()
				.getText();
		System.out.println(Strname);
		getBundle().setProperty("Store name 1", Strname);

	}

	@QAFTestStep(description = "I verify that different set of stores are getting displayed")
	public void iverifythatdifferentsetofstoresaregettingdisplayed() {
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		int len = storelistresult.getStorelocatorLblStorenamelist().size();
		String Strname2 = storelistresult.getStorelocatorLblStoreresults().get(len - 1).getStorelocatorLblStorename()
				.getText();
		System.out.println(Strname2);

		String Oldstrname = (String) getBundle().getProperty("Store name 1");
		System.out.println(Oldstrname);

		if (!Strname2.equalsIgnoreCase(Oldstrname)) {
			PerfectoUtils.reportMessage("Different set of stores are displayed on changing zip", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Different set of stores are not displayed on changing zip", MessageTypes.Fail);

		}

	}

	@QAFTestStep(description = "I set the store as my heb store")
	public void isetthestoreasmyhebstore() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();
		try {

			storedetail.getStoredetailsSetasyourstore().assertVisible();
			PerfectoUtils.swipeIfInBottom(storedetail.getStoredetailsSetasyourstore());
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
		}
		storedetail.getStoredetailsSetasyourstore().isPresent();
		storedetail.getStoredetailsSetasyourstore().click();
		if (storedetail.getbtnmyhebstore().isPresent()) {
			PerfectoUtils.reportMessage("set as my heb store clickable", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("set as my heb store not clickable", MessageTypes.Info);
		}

	}

	@QAFTestStep(description = "I navigate to my store page")
	public void inavigatetomystorepage() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();
		MyaccountTestPage myaccount = new MyaccountTestPage();

		myaccount.getBtnMystore().waitForPresent(3000);
		myaccount.getBtnMystore().click();
		String StoreName = null;
		try {
			StoreName = storedetail.getStoredetailsViewstorename().getText();
		} catch (Exception e) {
			StoreName = storedetail.getlnkViewStoreName1().getText();
		}
		System.out.println(StoreName);
		String strselectedstore = getBundle().getString("SelectedStoreName");
		System.out.println(strselectedstore);
		if (StoreName.equals(strselectedstore)) {
			PerfectoUtils.reportMessage("Selected store is now my HEB store", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected store is not my HEB store", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify image redirects to the appropriate deep link for hot user")
	public void iVverifyImageRedirectsToTheAppropriateDeepLinkForHotUser() {
		IOSStepdefWeeklyAd iosstepweeklyad = new IOSStepdefWeeklyAd();
		CommonStepDefWeeklyAds commonstepweeklyad = new CommonStepDefWeeklyAds();
		HomeTestPage homePage = new HomeTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		CommonStepDefCoupons commonstepcoupons = new CommonStepDefCoupons();
		IOSStepdefCoupons iosstepcoupons = new IOSStepdefCoupons();
		RecipeslandingTestPage recipelanding = new RecipeslandingTestPage();
		CommonStepDefRecipes commonsteprecipes = new CommonStepDefRecipes();
		MylistTestPage mylistpage = new MylistTestPage();

		String deeplink = ConfigurationManager.getBundle().getString("deeplink");

		try {
			AndroidStepDef.storelocatorErrorHandle();
		} catch (Exception e) {
			// ignore
		}

		if (deeplink.equalsIgnoreCase("true")) {

			if (storepage.getStorelocatorImgListswitch().isPresent()) {
				PerfectoUtils.reportMessage("Deep link is navigated to Weekly Ad", MessageTypes.Info);

				iosstepweeklyad.iChooseAnStoreFromTheStoreListForGettingWeeklyads();
				commonstepweeklyad.iSeeFeaturesDealPage();

				ioscommon.getAppBtnBackIOS().click();
				try {
					ioscommon.getAppBtnBackIOS().click();
					if (homePage.getImgHomeHero().isPresent()) {
						PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
					}
				} catch (Exception e) {
					ioscommon.getAppBtnBackIOS().click();
					if (homePage.getImgHomeHero().isPresent()) {
						PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
					}
				}
			} else if (couponsselection.getCouponsLblAvailable().isPresent()) {
				PerfectoUtils.reportMessage("Deep link is navigated to Total Available Coupons", MessageTypes.Info);
				commonstepcoupons.iValidateTotalAvailableSection();
				ioscommon.getAppBtnBackIOS().click();

				if (homePage.getImgHomeHero().isPresent()) {
					PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
				}
			} else if (couponsselection.getLblSelectedsavingswhenselected().isPresent()) {
				PerfectoUtils.reportMessage("Deep link is navigated to Selected Coupons", MessageTypes.Info);
				iosstepcoupons.iValidateSelectedSavingsTab();
				ioscommon.getAppBtnBackIOS().click();

				if (homePage.getImgHomeHero().isPresent()) {
					PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
				}
			} else if (recipelanding.getRecipesPagename().isPresent()) {
				PerfectoUtils.reportMessage("Deep link is navigated to Recipe Landing page", MessageTypes.Info);
				commonsteprecipes.iValidateTheElementsInTheRecipeLandingPage();
				ioscommon.getAppBtnBackIOS().click();

				if (homePage.getImgHomeHero().isPresent()) {
					PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
				}
			} else if (mylistpage.getMyListLblPagetitle().isPresent()) {
				PerfectoUtils.reportMessage("Navigated to My lists page.", MessageTypes.Pass);
				mylistpage.getMyListLblPagetitle().verifyPresent();
				PerfectoUtils.androiddeviceback();

				if (homePage.getImgHomeHero().isPresent()) {
					PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
				}
			}

		} else {
			PerfectoUtils.reportMessage("User will not navigate to any page if Deep link is not there.", MessageTypes.Info);
			if (homePage.getImgHomeHero().isPresent()) {
				PerfectoUtils.reportMessage("User still is in homepage.", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Navigated to other page in Deep Link is False.", MessageTypes.Fail);
			}
		}

	}

	@QAFTestStep(description = "I verify image redirects to the appropriate deep link")
	public void iVverifyImageRedirectsToTheAppropriateDeepLink() {
		IOSStepdefWeeklyAd iosstepweeklyad = new IOSStepdefWeeklyAd();
		CommonStepDefWeeklyAds commonstepweeklyad = new CommonStepDefWeeklyAds();
		HomeTestPage homePage = new HomeTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		CommonStepDefCoupons commonstepcoupons = new CommonStepDefCoupons();
		IOSStepdefCoupons iosstepcoupons = new IOSStepdefCoupons();
		RecipeslandingTestPage recipelanding = new RecipeslandingTestPage();
		CommonStepDefRecipes commonsteprecipes = new CommonStepDefRecipes();
		MylistTestPage mylistpage = new MylistTestPage();

		String deeplink = ConfigurationManager.getBundle().getString("deeplink");

		try {
			AndroidStepDef.storelocatorErrorHandle();
		} catch (Exception e) {
			// ignore
		}

		if (deeplink.equalsIgnoreCase("true")) {

			if (storepage.getStorelocatorImgListswitch().isPresent()) {
				PerfectoUtils.reportMessage("Deep link is navigated to Weekly Ad", MessageTypes.Info);

				iosstepweeklyad.iChooseAnStoreFromTheStoreListForGettingWeeklyads();
				commonstepweeklyad.iSeeFeaturesDealPage();

				ioscommon.getAppBtnBackIOS().click();
				try {
					ioscommon.getAppBtnBackIOS().click();
					if (homePage.getImgHomeHero().isPresent()) {
						PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
					}
				} catch (Exception e) {
					ioscommon.getAppBtnBackIOS().click();
					if (homePage.getImgHomeHero().isPresent()) {
						PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
					}
				}
			} else if (couponsselection.getCouponsLblAvailable().isPresent()) {
				PerfectoUtils.reportMessage("Deep link is navigated to Total Available Coupons", MessageTypes.Info);
				commonstepcoupons.iValidateTotalAvailableSection();
				ioscommon.getAppBtnBackIOS().click();

				if (homePage.getImgHomeHero().isPresent()) {
					PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
				}

			} else if (recipelanding.getRecipesPagename().isPresent()) {
				PerfectoUtils.reportMessage("Deep link is navigated to Recipe Landing page", MessageTypes.Info);
				commonsteprecipes.iValidateTheElementsInTheRecipeLandingPage();
				ioscommon.getAppBtnBackIOS().click();

				if (homePage.getImgHomeHero().isPresent()) {
					PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
				}
			} else if (mylistpage.getMyListLblPagetitle().isPresent()) {
				PerfectoUtils.reportMessage("Navigated to My lists page.", MessageTypes.Pass);
				mylistpage.getMyListLblPagetitle().verifyPresent();
				PerfectoUtils.androiddeviceback();

				if (homePage.getImgHomeHero().isPresent()) {
					PerfectoUtils.reportMessage("Navigated to home page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Unable to see home page", MessageTypes.Fail);
				}
			}

		} else {
			PerfectoUtils.reportMessage("User will not navigate to any page if Deep link is not there.", MessageTypes.Info);
			if (homePage.getImgHomeHero().isPresent()) {
				PerfectoUtils.reportMessage("User still is in homepage.", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Navigated to other page in Deep Link is False.", MessageTypes.Fail);
			}
		}

	}
}
