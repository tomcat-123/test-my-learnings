package com.heb.automation.common.pages.pharmacy;

import java.util.List;

import com.heb.automation.common.components.ProductResult;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class PharmacyTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "pharmacy.lbl.pharmacy")
	private QAFWebElement LblPharmacy;

	@FindBy(locator = "pharmacy.lbl.alerttitle")
	private QAFWebElement LblAlertTitle;

	@FindBy(locator = "pharmacy.lbl.ok")
	private QAFWebElement LblOk;

	@FindBy(locator = "pharmacy.lbl.cancel")
	private QAFWebElement LblCancel;

	@FindBy(locator = "pharmacy.btn.welcomelogin")
	private QAFWebElement BtnWelcomeLogin;

	@FindBy(locator = "pharmacy.lbl.skip")
	private QAFWebElement LblSkip;

	@FindBy(locator = "pharmacy.img.pharmacy")
	private QAFWebElement ImgPharmacy;

	@FindBy(locator = "pharmacy.lbl.hebpharmacy")
	private QAFWebElement LblHebPharmacy;

	@FindBy(locator = "pharmacy.btn.install")
	private QAFWebElement BtnInstall;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getLblPharmacy() {
		return LblPharmacy;
	}

	public QAFWebElement getLblAlertTitle() {
		return LblAlertTitle;
	}

	public QAFWebElement getLblOk() {
		return LblOk;
	}

	public QAFWebElement getLblCancel() {
		return LblCancel;
	}

	public QAFWebElement getBtnWelcomeLogin() {
		return BtnWelcomeLogin;
	}

	public QAFWebElement getLblSkip() {
		return LblSkip;
	}

	public QAFWebElement getImgPharmacy() {
		return ImgPharmacy;
	}

	public QAFWebElement getLblHebPharmacy() {
		return LblHebPharmacy;
	}

	public QAFWebElement getBtnInstall() {
		return BtnInstall;
	}

}
