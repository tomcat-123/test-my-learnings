package com.heb.automation.common.pages.coupons;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CouponsemailTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "couponsemail.btn.cancel")
	private QAFWebElement BtnCancel;
	@FindBy(locator = "couponsemail.lbl.pagetitle")
	private QAFWebElement LblPagetitle;
	@FindBy(locator = "couponsemail.btn.submit")
	private QAFWebElement BtnSubmit;
	@FindBy(locator = "couponsemail.edt.name")
	private QAFWebElement EdtName;
	@FindBy(locator = "couponsemail.edt.senderemail")
	private QAFWebElement EdtSenderemail;
	@FindBy(locator = "couponsemail.edt.recipientemail")
	private QAFWebElement EdtRecipientemail;
	@FindBy(locator = "couponsemail.edt.message")
	private QAFWebElement EdtMessage;
	@FindBy(locator = "couponsemail.lbl.selectedcouponsname")
	private QAFWebElement LblSelectedcouponsname;
	@FindBy(locator = "couponsemail.img.selectedcouponsimage")
	private QAFWebElement ImgSelectedcouponsimage;
	@FindBy(locator = "couponsemail.chk.sendcopy")
	private QAFWebElement ChkSendcopy;
	@FindBy(locator = "couponsemail.lbl.sendcopy")
	private QAFWebElement LblSendcopy;
	@FindBy(locator = "couponsemail.lbl.nameandemail")
	private QAFWebElement LblNameandemail;	
	@FindBy(locator = "couponsemail.btn.send")
	private QAFWebElement btnSend;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getBtnCancel() {
		return BtnCancel;
	}

	public QAFWebElement getLblPagetitle() {
		return LblPagetitle;
	}

	public QAFWebElement getBtnSubmit() {
		return BtnSubmit;
	}

	public QAFWebElement getEdtName() {
		return EdtName;
	}

	public QAFWebElement getEdtSenderemail() {
		return EdtSenderemail;
	}

	public QAFWebElement getEdtRecipientemail() {
		return EdtRecipientemail;
	}

	public QAFWebElement getEdtMessage() {
		return EdtMessage;
	}

	public QAFWebElement getLblSelectedcouponsname() {
		return LblSelectedcouponsname;
	}

	public QAFWebElement getImgSelectedcouponsimage() {
		return ImgSelectedcouponsimage;
	}

	public QAFWebElement getChkSendcopy() {
		return ChkSendcopy;
	}

	public QAFWebElement getLblSendcopy() {
		return LblSendcopy;
	}

	public QAFWebElement getLblNameandemail() {
		return LblNameandemail;
	}
	
	public QAFWebElement getBtnSend() {
		return btnSend;
	}


}
