package com.heb.automation.common.pages.products;

import java.util.List;

import com.heb.automation.common.components.ProductResult;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ProductsresultlistTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "productresult.list.srchresult")
	private List<ProductResult> productresultlist;
	@FindBy(locator = "productresult.lbl.productname")
	private List<QAFWebElement> productresultLblProductnameList;
	@FindBy(locator = "productresult.lbl.productname")
	private QAFWebElement productresultLblProductname;
	@FindBy(locator = "prodsearchresult.txt.allproductscount")
	private QAFWebElement prodsearchresultTxtAllproductscount;

	@FindBy(locator = "productresult.btn.addtolist")
	private QAFWebElement BtnAddtolist;
	@FindBy(locator = "productresult.lbl.productprize")
	private QAFWebElement LblProductprize;
	@FindBy(locator = "productresult.img.productimage")
	private QAFWebElement ImgProductimage;

	@FindBy(locator = "productresult.img.productlocation")
	private QAFWebElement ImgProductlocation;
	@FindBy(locator = "productresult.lbl.allproducts")
	private QAFWebElement LblAllproducts;
	@FindBy(locator = "productresult.lbl.selectastore")
	private QAFWebElement lblSelectastore;
	@FindBy(locator = "productresult.lbl.selectedstore")
	private QAFWebElement lblSelectedStrore;
	@FindBy(locator = "productresult.lbl.changestore")
	private QAFWebElement lblChangestore;
	@FindBy(locator = "productresult.lbl.chooseanotherstore")
	private QAFWebElement lblChooseanotherstore;
	@FindBy(locator = "productresult.lbl.childproductname")
	private List<QAFWebElement> lblChildproductnamelist;

	@FindBy(locator = "productresult.lbl.bestmatch")
	private QAFWebElement lblbestmatch;
	@FindBy(locator = "productresult.lbl.allstores")
	private QAFWebElement lblallstores;
	@FindBy(locator = "productresult.dpd.bmdowncarat")
	private QAFWebElement dpdbmdowncarat;
	@FindBy(locator = "productresult.dpd.asdowncarat")
	private QAFWebElement dpdasdowncarat;
	@FindBy(locator = "productresult.txt.sortmodal")
	private QAFWebElement txtsortmodal;
	@FindBy(locator = "productresult.txt.filtermodal")
	private QAFWebElement txtfiltermodal;
	@FindBy(locator = "productresult.btn.closemodal")
	private QAFWebElement btnclosemodal;
	@FindBy(locator = "productresult.txt.selbrandname")
	private QAFWebElement txtselbrandname;
	@FindBy(locator = "productresult.lbl.bmcheckmark")
	private QAFWebElement lblbmcheckmark;
	@FindBy(locator = "productresult.img.touchoutside")
	private QAFWebElement imgtouchoutside;
	@FindBy(locator = "productresult.sortmodal.txt.newest")
	private QAFWebElement lblnewest;
	@FindBy(locator = "productresult.sortmodal.txt.bestmach")
	private QAFWebElement sortmodaltxtbestmach;
	@FindBy(locator = "productresult.sortmodal.txt.atoz")
	private QAFWebElement sortmodaltxtatoz;
	@FindBy(locator = "productresult.sortmodal.txt.ztoa")
	private QAFWebElement sortmodaltxtztoa;
	@FindBy(locator = "productresult.sortmodal.txt.hightolow")
	private QAFWebElement sortmodaltxthightolow;
	@FindBy(locator = "productresult.sortmodal.txt.lowtohigh")
	private QAFWebElement sortmodaltxtlowtohigh;
	@FindBy(locator = "productresult.sortmodal.txt.ratings")
	private QAFWebElement sortmodaltxtratings;
	@FindBy(locator = "productresult.img.ratingsbar")
	private QAFWebElement imgratingsbar;
	@FindBy(locator = "productresult.txt.pricelist")
	private List<QAFWebElement> txtpricelist;
	@FindBy(locator = "productresult.btn.closefiltermodal")
	private QAFWebElement CloseFilterModal;

	@FindBy(locator = "productresult.lbl.allproductscount")
	private QAFWebElement lblallproductscount;
	@FindBy(locator = "productresult.lbl.inmystore")
	private QAFWebElement lblInmystore;
	@FindBy(locator = "productresult.lbl.inmystorecount")
	private QAFWebElement lblInmystorecount;
	@FindBy(locator = "productresult.lbl.tabs")
	private List<QAFWebElement> lblTabs;

	@FindBy(locator = "productresult.lbl.filtertab")
	private QAFWebElement lblFilterTab;
	@FindBy(locator = "productresult.filtermodal.lbl.filters")
	private QAFWebElement filtermodalLblFilters;
	@FindBy(locator = "productresult.filtermodal.btn.dismiss")
	private QAFWebElement filtermodalBtnDismiss;
	@FindBy(locator = "productresult.filtermodal.btn.clear")
	private QAFWebElement filtermodalBtnClear;
	@FindBy(locator = "productresult.filtermodal.btn.done")
	private QAFWebElement filtermodalBtnDone;
	@FindBy(locator = "productresult.filtermodal.lbl.storeselection")
	private QAFWebElement filtermodalLblStoreSelection;
	@FindBy(locator = "productresult.filtermodal.lbl.allstores")
	private QAFWebElement filtermodalLblAllStores;
	@FindBy(locator = "productresult.filtermodal.lbl.brand")
	private QAFWebElement filtermodalLblBrand;
	@FindBy(locator = "productresult.filtermodal.lbl.lifestyles")
	private QAFWebElement filtermodalLblLifeStyles;
	@FindBy(locator = "productresult.filtermodal.lbl.price")
	private QAFWebElement filtermodalLblPrice;
	@FindBy(locator = "productresult.filtermodal.lbl.bottomsheetTitle")
	private QAFWebElement filtermodalLblBottomSheetTitle;
	@FindBy(locator = "productresult.filtermodal.lis.filtername")
	private List<QAFWebElement> filtermodalLisBrandName;
	@FindBy(locator = "productresult.filtermodal.lis.selectedbrandname")
	private List<QAFWebElement> FiltermodalListSelectedBrandName;
	@FindBy(locator = "productresult.filtermodal.lbl.selstore")
	private QAFWebElement filtermodallblselstore;
	@FindBy(locator = "productresult.filtermodal.lbl.store")
	private QAFWebElement filtermodallblstore;
	@FindBy(locator = "productresult.filtermodal.lbl.checkmark")
	private List<QAFWebElement> FiltermodalLblCheckmark;
	@FindBy(locator = "productresult.storeselection.lbl.closestheb")
	private QAFWebElement storeselectionLblClosestHEB;
	@FindBy(locator = "productresult.storeselection.lbl.hebdistance")
	private QAFWebElement storeselectionLblHEBDistance;
	@FindBy(locator = "productresult.storeselection.lbl.storename")
	private QAFWebElement storeselectionLblStorename;
	@FindBy(locator = "productresult.storeselection.lbl.hebaddress")
	private QAFWebElement storeselectionLblHEBAddress;
	@FindBy(locator = "productresult.storeselection.lbl.selectastore")
	private QAFWebElement storeselectionLblSelectastore;
	@FindBy(locator = "productresult.storeselection.lbl.myheb")
	private QAFWebElement storeselectionLblMyHEB;
	@FindBy(locator = "productresult.storeselection.lis.selectedStoreName")
	private List<QAFWebElement> storeselectionListSelectedStoreName;
	@FindBy(locator = "productresult.storeselection.lis.selectedStoreAddress")
	private List<QAFWebElement> storeselectionListSelectedStoreAddress;
	@FindBy(locator = "productresult.storeselection.lis.selectedStoreDistance")
	private List<QAFWebElement> storeselectionListSelectedStoreDistance;
	@FindBy(locator = "productresult.filtermodal.txt.brandafterclear")
	private QAFWebElement filtermodalTxtBrandAfterClear;
	@FindBy(locator = "productresult.filtermodal.lbl.back")
	private QAFWebElement FilterModalLblBack;
	
	@FindBy(locator = "productresult.storeselection.lbl.hebaddress1")
	private QAFWebElement storeselectionLblHEBAddress1;
	
	@FindBy(locator = "productresult.storeselection.lbl.hebaddress2")
	private QAFWebElement storeselectionLblHEBAddress2;
	@FindBy(locator = "productresult.storeselection.lbl.myhebstorename")
	private QAFWebElement storeselectionLblMyHEBStorename;
	@FindBy(locator = "productresult.filtermodal.lbl.selectedstore")
	private QAFWebElement filtermodalLblSelectedstore;
	
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public List<ProductResult> getProductresultlist() {
		return productresultlist;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public List<QAFWebElement> getProductresultLblProductnameList() {
		return productresultLblProductnameList;
	}

	// DYNAMIC value declaring
	public QAFWebElement getAddToLstBtnWithRespectToPdtName(String lable) {
		String loc = String.format(pageProps.getString("productresult.chkbox.addtolistpdtname"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getProductresultLblProductname() {
		return productresultLblProductname;
	}

	public QAFWebElement getProdsearchresultTxtAllproductscount() {
		return prodsearchresultTxtAllproductscount;
	}

	// DYNAMIC value declaring
	public QAFWebElement getAddToCartBtnWithRespectToCell(int lable) {
		String loc = String.format(pageProps.getString("productresult.btn.addtocartdynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}

	// DYNAMIC value declaring
	public QAFWebElement getPrdtNameWithRespectToCell(int lable) {
		String loc = String.format(pageProps.getString("productresult.lbl.productnamedynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getBtnAddtolist() {
		return BtnAddtolist;
	}

	public QAFWebElement getLblProductprize() {
		return LblProductprize;
	}

	public QAFWebElement getImgProductimage() {
		return ImgProductimage;
	}

	public QAFWebElement getImgProductlocation() {
		return ImgProductlocation;
	}

	public QAFWebElement getLblAllproducts() {
		return LblAllproducts;
	}

	public QAFWebElement getLblSelectastore() {
		return lblSelectastore;
	}

	public QAFWebElement getLblSelectedStrore() {
		return lblSelectedStrore;
	}

	public QAFWebElement getLblChangestore() {
		return lblChangestore;
	}

	public QAFWebElement getLblChooseanotherstore() {
		return lblChooseanotherstore;
	}

	public List<QAFWebElement> getLblChildproductnamelist() {
		return lblChildproductnamelist;
	}

	public QAFWebElement getLblallproductscount() {
		return lblallproductscount;
	}

	public QAFWebElement getLblInmystore() {
		return lblInmystore;
	}

	public QAFWebElement getLblInmystorecount() {
		return lblInmystorecount;
	}

	public List<QAFWebElement> getLblTabs() {
		return lblTabs;
	}

	public QAFWebElement getLblBestMatch() {
		return lblbestmatch;
	}

	public QAFWebElement getLblAllStores() {
		return lblallstores;
	}

	public QAFWebElement getDpdBMDownCarat() {
		return dpdbmdowncarat;
	}

	public QAFWebElement getDpdAsDownCarat() {
		return dpdasdowncarat;
	}

	public QAFWebElement getTxtSortModal() {
		return txtsortmodal;
	}

	public QAFWebElement getTxtFilterModal() {
		return txtfiltermodal;
	}

	public QAFWebElement getBtnCloseModal() {
		return btnclosemodal;
	}

	public QAFWebElement getLblFilterTab() {
		return lblFilterTab;
	}

	public QAFWebElement getFiltermodalLblFilters() {
		return filtermodalLblFilters;
	}

	public QAFWebElement getFiltermodalBtnDismiss() {
		return filtermodalBtnDismiss;
	}

	public QAFWebElement getFiltermodalBtnClear() {
		return filtermodalBtnClear;
	}

	public QAFWebElement getFiltermodalBtnDone() {
		return filtermodalBtnDone;
	}

	public QAFWebElement getFiltermodalLblStoreSelection() {
		return filtermodalLblStoreSelection;
	}

	public QAFWebElement getFiltermodalLblAllStores() {
		return filtermodalLblAllStores;
	}

	public QAFWebElement getFiltermodalLblBrand() {
		return filtermodalLblBrand;
	}

	public QAFWebElement getFiltermodalLblLifeStyles() {
		return filtermodalLblLifeStyles;
	}

	public QAFWebElement getFiltermodalLblPrice() {
		return filtermodalLblPrice;
	}

	public QAFWebElement getFiltermodalLblBottomSheetTitle() {
		return filtermodalLblBottomSheetTitle;
	}

	public List<QAFWebElement> getFiltermodalLisBrandName() {
		return filtermodalLisBrandName;
	}

	public List<QAFWebElement> getFiltermodalListSelectedBrandName() {
		return FiltermodalListSelectedBrandName;
	}

	public QAFWebElement getTxtSelBrandName() {
		return txtselbrandname;
	}

	public QAFWebElement getFiltermodalLblSelStore() {
		return filtermodallblselstore;
	}

	public QAFWebElement getFilterModalLblStore() {
		return filtermodallblstore;
	}

	public List<QAFWebElement> getFiltermodalLblCheckmark() {
		return FiltermodalLblCheckmark;
	}

	public QAFWebElement getStoreselectionLblClosestHEB() {
		return storeselectionLblClosestHEB;
	}

	public QAFWebElement getStoreselectionLblHEBDistance() {
		return storeselectionLblHEBDistance;
	}

	public QAFWebElement getStoreselectionLblStorename() {
		return storeselectionLblStorename;
	}

	public QAFWebElement getStoreselectionLblHEBAddress() {
		return storeselectionLblHEBAddress;
	}

	public QAFWebElement getStoreselectionLblSelectastore() {
		return storeselectionLblSelectastore;
	}

	public QAFWebElement getStoreselectionLblMyHEB() {
		return storeselectionLblMyHEB;
	}

	public QAFWebElement getLblBmCheckMark() {
		return lblbmcheckmark;
	}

	public QAFWebElement getImgTouchOutSide() {
		return imgtouchoutside;
	}

	public QAFWebElement getLblNewest() {
		return lblnewest;
	}

	public QAFWebElement getSortModalTxtBestMach() {
		return sortmodaltxtbestmach;
	}

	public QAFWebElement getSortModalTxtAtoZ() {
		return sortmodaltxtatoz;
	}

	public QAFWebElement getSortModalTxtZtoA() {
		return sortmodaltxtztoa;
	}

	public QAFWebElement getSortModalTxtHightoLow() {
		return sortmodaltxthightolow;
	}

	public QAFWebElement getSortModalTxtLowtoHigh() {
		return sortmodaltxtlowtohigh;
	}

	public QAFWebElement getSortModalTxtRatings() {
		return sortmodaltxtratings;
	}

	public QAFWebElement getImgRatingsBar() {
		return imgratingsbar;
	}

	public List<QAFWebElement> getTxtPriceList() {
		return txtpricelist;
	}

	public List<QAFWebElement> getStoreselectionListSelectedStoreName() {
		return storeselectionListSelectedStoreName;
	}

	public List<QAFWebElement> getStoreselectionListSelectedStoreAddress() {
		return storeselectionListSelectedStoreAddress;
	}

	public List<QAFWebElement> getStoreselectionListSelectedStoreDistance() {
		return storeselectionListSelectedStoreDistance;
	}

	public QAFWebElement getFiltermodalTxtBrandAfterClear() {
		return filtermodalTxtBrandAfterClear;
	}

	public QAFWebElement getCloseFilterModal() {
		return CloseFilterModal;
	}

	public QAFWebElement getFilterModalLblBack() {   
		return FilterModalLblBack;
	}
	
	public QAFWebElement getStoreselectionLblHEBAddress1() {
		return storeselectionLblHEBAddress1;
	}
	
	public QAFWebElement getStoreselectionLblHEBAddress2() {
		return storeselectionLblHEBAddress2;
	}
	
	public QAFWebElement getStoreselectionLblMyHEBStorename() {
		return storeselectionLblMyHEBStorename;
	}
	
	public QAFWebElement getFiltermodalLblSelectedstore() {
		return filtermodalLblSelectedstore;
	}
}
