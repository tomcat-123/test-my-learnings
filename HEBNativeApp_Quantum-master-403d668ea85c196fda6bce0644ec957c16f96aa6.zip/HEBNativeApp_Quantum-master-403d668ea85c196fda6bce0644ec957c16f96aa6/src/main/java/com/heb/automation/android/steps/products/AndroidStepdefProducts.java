
package com.heb.automation.android.steps.products;

import static com.heb.automation.common.PerfectoUtils.getAppiumDriver;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static com.qmetry.qaf.automation.step.CommonStep.click;
import static com.qmetry.qaf.automation.step.CommonStep.waitForPresent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.Dimension;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.android.pages.EmailcontentTestPage;
import com.heb.automation.android.steps.AndroidStepDef;
import com.heb.automation.android.steps.shoppinglist.AndroidStepDefShoppingList;
import com.heb.automation.android.steps.storelocator.AndroidStepDefStoreLocator;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.ProductResult;
import com.heb.automation.common.components.ShoppinglistResult;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.coupons.CouponsdetailsTestPage;
import com.heb.automation.common.pages.products.LegalDisclaimerTestPage;
import com.heb.automation.common.pages.products.ProductdetailTestPage;
import com.heb.automation.common.pages.products.ProductlandingTestPage;
import com.heb.automation.common.pages.products.ProductsearchresultTestPage;
import com.heb.automation.common.pages.products.ProductsresultlistTestPage;
import com.heb.automation.common.pages.products.RefineTestPage;
import com.heb.automation.common.pages.recipes.RecipedetailTestPage;
import com.heb.automation.common.pages.scanner.ScanProductsTestPage;
import com.heb.automation.common.pages.shoppinglist.AddtolistTestPage;
import com.heb.automation.common.pages.shoppinglist.MylistTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriessearchresultTestPage;
import com.heb.automation.common.pages.storelocator.StorelocatorTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

/*List of Steps in Products

	I enter invalid search term {0} within search text field
	I see Search field is displayed correctly
	I click search button
	I click on search icon
	I enter valid search term and select the search button
	I should see the selected product in the weekly groceries page
	I select the product and click Add to list button from search result page
	I navigate to Products Page
	I click Add to list button for a product
	I see CDP page of searched product
	I enter valid email address and click on Send button
	I verify PDP page
	I click on done/refine button
	I select filter {0} and {1}
	I select any nutritional tags from PDP
	I verify the user navigated to Nutritional tags page
	I verify the healthy icon is available
	I click on Product details from PDP
	I see Store locator page opened
	I navigate back to CDP page
	I see CDP page by navigating {0} items
	I validate share page for PDP page
	I click select a store from CDP page
	I verify the selected store in CDP
	I click Change store from CDP page
	I click on Search Field
	I enter valid search term {0}and select Search button
	I verify the store availablity section
	I verify that Unit of Measure is in lower case in both Qty and Price / Qty
	I navigate to Products page without setting location
	I verify that stores are displayed in chronological orders
	I taps on back button and verify navigated back to store modal page
	I reset the location
	I verify that Store Availability section is not present after denying location
	I reset the location from device settings
	I navigate to products page by android 3 bar and ios home menu
	I see CDP page by navigating {0} items with category page validation
	Verify the properties of Product Information Disclaimer page
	Verify all the Shopping lists are available in Add to list popup
	Verify only Weekly Groceries list is available in the add to list popup
	I verify that choose another store is not present on PDP
	I verify that choose another store is present on CDP
	I verify the product count getting displayed in my store tab
	Verify the user not able to see the Weekly Groceries list
	Verify the Scan got cancelled on clicking Back Or Cancel icon
	I verify the CDP page without any store selected
	I verify the CDP page with store selected
	Select Send button without entering the Mandatory fields
	Verify the search terms gets cleared on clicking X icon
	Validate the error message without entering the Mandatory fields
	I enter valid search term {0}and select Search button in Recipe screen*/

public class AndroidStepdefProducts {

	/**
	 * Entering invalid search term str1 in search text field
	 * 
	 * @param str1
	 *            the invalid search term
	 */
	@QAFTestStep(description = "I enter invalid search term {0} within search text field")
	public void iEnterInvalidSearchTermWithinSearchTextField(String str1) {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		androidcommon.getAppTxtSearchproducts().waitForPresent(5000);
		androidcommon.getAppTxtSearchproducts().sendKeys(str1);
		PerfectoUtils.reportMessage("Entered invalid search term: " + str1, MessageTypes.Pass);
	}

	/**
	 * Validating whether the search field is displayed correctly to enter
	 * search term
	 */
	@QAFTestStep(description = "I see Search field is displayed correctly")
	public void iSeeSearchFieldIsDisplayedCorrectly() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		try {
			androidcommon.getAppTxtSearchproducts().isDisplayed();
			PerfectoUtils.reportMessage("Navigated to search screen successfully.", MessageTypes.Pass);
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Unable to navigate to Search screen.", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking the search button using Perfecto mobile key event command
	 */
	@QAFTestStep(description = "I click search button")
	public void iselectButtonInBottomRightHandOfKeyboard() {
		Map<String, Object> EnterKeyEvent = new HashMap<>();

		EnterKeyEvent.put("key", "66");
		PerfectoUtils.getDriver().executeScript("mobile:key:event", EnterKeyEvent);
	}

	/**
	 * Verifying the search icon and clicking it
	 */
	@QAFTestStep(description = "I click on search icon")
	public void iClickOnSearchIcon() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		androidcommon.getAppIconSearchproducts().verifyPresent();
		androidcommon.getAppIconSearchproducts().click();
		PerfectoUtils.reportMessage("Clicked on Search Icon.", MessageTypes.Pass);
	}

	/**
	 * Entering valid search term in search field and clicking search button on
	 * keyboard
	 */
	@QAFTestStep(description = "I enter valid search term and select the search button")
	public void iEnterValidSerachTermAndSelectTheSearchButton() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		String strValidProductname = getBundle().getString("products.productname");
		AndroidStepDef.enterValueIntoTheTextboxandClick(androidcommon, androidcommon.getAppTxtSearchproducts(),
				strValidProductname);
		PerfectoUtils.reportMessage("Entered value: " + strValidProductname + " in the search box", MessageTypes.Pass);
	}

	/**
	 * Navigating to weekly groceries page by clicking Hamburger icon.
	 * Validating whether the selected item is listed in weekly groceries list.
	 * Selected item is carried by the string "ChoosenProduct"
	 */
	@QAFTestStep(description = "I should see the selected product in the weekly groceries page")
	public void iShouldSeeTheSelectedProductInTheWeeklyGroceriesPage() {
		MylistTestPage mylistpage = new MylistTestPage();
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		AndroidStepDefShoppingList androidstepdef = new AndroidStepDefShoppingList();

		boolean isPdtAddedToList = false;
		String productName = "";

		// Navigating to Weekly groceries page
		androidcommonpage.getAppHamburger().waitForPresent(3000);
		androidcommonpage.getAppHamburger().click();
		androidcommonpage.getAppSliderHome().click();
		androidstepdef.iNavigateToMyListPage();
		mylistpage.getMylistsLblWeeklygroceries().click();

		// Validating if selected item is listed in weekly groceries list
		weeklygrocery.waitForPageToLoad();

		for (ShoppinglistResult product : weeklygrocery.getWgListItemlist()) {
			productName = product.getWgListItemname().getText();
			if (productName.contains("&quot;")) {
				productName = productName.replaceAll("&quot;", "\"");
			}
			if (getBundle().getString("ChoosenProduct").contains(productName)) {
				isPdtAddedToList = true;
				break;
			}
		}

		// Condition to validate the product
		if (isPdtAddedToList) {
			PerfectoUtils.reportMessage("The product: " + productName + " is added to weekly groceries list",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("The product: " + productName + " is not added to weekly groceries list",
					MessageTypes.Fail);
		}
	}

	/**
	 * Get the name of first product from product search result page and save it
	 * to getBundle property as "ChoosenProduct". Clicking Add to list button
	 * and verifying whether Add to list is populated.
	 */
	@QAFTestStep(description = "I select the product and click Add to list button from search result page")
	public void iSelectTheProductAndClickAddToListButtonFromPDPPage() {
		ProductsearchresultTestPage productsearchresult = new ProductsearchresultTestPage();
		ProductsresultlistTestPage itemresult = new ProductsresultlistTestPage();
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();

		itemresult.waitForPageToLoad();
		int productCount = itemresult.getProductresultlist().size();

		if (productCount > 0) {
			List<ProductResult> result = itemresult.getProductresultlist();

			for (ProductResult singleProduct : result) {
				String prdName = singleProduct.getProductresultLblProductname().getText();
				PerfectoUtils.reportMessage("Product Name:" + prdName);
				getBundle().setProperty("ChoosenProduct", prdName);
				singleProduct.getProductresultBtnAddtolist().click();
				String popupTitle = androidcommonpage.getAddtolistLblAlerttitle().getText();

				if (popupTitle.equals("Add to List")) {
					PerfectoUtils.reportMessage("Add To List pop up is displayed as expected", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Add To List pop up is not displayed", MessageTypes.Fail);
				}
				break;
			}

		} else {
			String errorContent = productsearchresult.getProdsearchresultLblMaincontent().getText();
			PerfectoUtils.reportMessage(errorContent, MessageTypes.Fail);
		}
	}

	/**
	 * Wait for Home page to get populated. Swipe if products tab is not
	 * present. Select product tab.
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I navigate to Products Page")
	public void iNavigateToProductsPage() throws Exception {
		HomeTestPage homepage = new HomeTestPage();

		homepage.getHomeLblWeeklyAd().waitForPresent(3000);

		Thread.sleep(20000);

		// Verify product label is present
		if (!homepage.getHomeLblProduct().isPresent()) {
			PerfectoUtils.verticalswipe();
		}

		homepage.getHomeLblProduct().click();
		PerfectoUtils.reportMessage("Clicked on Products from Home Homepage", MessageTypes.Pass);
	}

	/**
	 * Get the name of first product from product list and save it to getBundle
	 * property as "ChoosenProduct". Clicking Add to list button. Failing the
	 * step if there are no products available.
	 */
	@QAFTestStep(description = "I click Add to list button for a product")
	public void iClickAddToListButtonForAProduct() {
		ProductsearchresultTestPage productsearchresult = new ProductsearchresultTestPage();
		ProductsresultlistTestPage itemresult = new ProductsresultlistTestPage();

		int productCount = itemresult.getProductresultlist().size();

		if (productCount > 0) {
			List<ProductResult> result = itemresult.getProductresultlist();
			for (ProductResult singleProduct : result) {
				String prdName = singleProduct.getProductresultLblProductname().getText();
				PerfectoUtils.reportMessage("Product Name:" + prdName);
				getBundle().setProperty("ChoosenProduct", prdName);
				singleProduct.getProductresultBtnAddtolist().click();
				break;
			}
		} else {
			String errorContent = productsearchresult.getProdsearchresultLblMaincontent().getText();
			PerfectoUtils.reportMessage(errorContent, MessageTypes.Fail);
		}
	}

	/**
	 * Wait for All products tab of CDP page to load, Click on All Products tab.
	 * Verifying Add to list button, product image, product location, product
	 * prize, product name.
	 */
	@QAFTestStep(description = "I see CDP page of searched product")
	public void iSeeCDPPageOfSearchedProduct() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		productresult.getDpdBMDownCarat().waitForPresent(5000);
		// productresult.getLblAllproducts().click();
		productresult.getBtnAddtolist().verifyPresent();
		productresult.getImgProductimage().verifyPresent();

		if (productresult.getImgProductlocation().isPresent()) {
			PerfectoUtils.reportMessage("Location is present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Location is not present as cold user", MessageTypes.Pass);
		}

		productresult.getLblProductprize().verifyPresent();
		productresult.getProductresultLblProductname().verifyPresent();
	}

	/**
	 * Validate Sort and Filter options in CDP Page
	 */
	@QAFTestStep(description = "I validate CDP page")
	public void iValidateCDPPage() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		productresult.getDpdBMDownCarat().waitForPresent(50000);
		// Verify the In My Store and All Products tabs are removed from the PCP

		productresult.getLblAllproducts().verifyNotPresent();
		productresult.getLblInmystore().verifyNotPresent();

		// Verify the My Store header is removed from the top of the PCP

		productresult.getLblSelectastore().verifyNotPresent();

		// Verify the Sort and Filter tabs are at the top of the PCP

		productresult.getLblAllStores().verifyPresent();
		productresult.getLblBestMatch().verifyPresent();

		// Verify after a product search or drilldown that Best Match is the
		// default for the Sort tab
		// and All Stores is the default for the Filter tab on the PCP

		String bestMatch = productresult.getLblBestMatch().getText();
		String allStores = productresult.getLblAllStores().getText();

		if (bestMatch.equalsIgnoreCase("BEST MATCH") && allStores.equalsIgnoreCase("ALL STORES")) {
			PerfectoUtils.reportMessage("Best Match and All Stores is the default", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Best Match and All Stores is not the default", MessageTypes.Fail);
		}

		// COLD Verify when the product list is scrolled that
		// the Sort and Filter tabs remain at the header of the PCP

		PerfectoUtils.verticalswipe();
		productresult.getLblBestMatch().verifyPresent();
		PerfectoUtils.verticalswipe();
		productresult.getLblAllStores().verifyPresent();

		// Verify a down carat is displayed on the Sort and Filter tabs located
		// at the top of the PCP

		productresult.getDpdBMDownCarat().verifyPresent();
		productresult.getDpdAsDownCarat().verifyPresent();

		// Verify the left nav drawer is accessible by tapping
		// the upper-left hamburger icon while on the PCP
		AndroidStepDef.iNavigateToCouponsPage();
	}

	/**
	 * Verify tapping on the Sort and Filter tab opens the Sort and Filter Modal
	 */
	@QAFTestStep(description = "I tapping on the Sort and Filter tab opens the Sort and Filter Modal")
	public void iTappingOnTheSortAndFilterTabOpensTheSortAndFilterModal() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		productresult.getDpdBMDownCarat().waitForPresent(50000);
		// Verify tapping on the Sort tab opens the Sort Modal
		productresult.getLblBestMatch().click();
		productresult.getTxtSortModal().waitForPresent(5000);
		productresult.getTxtSortModal().verifyPresent();
		productresult.getBtnCloseModal().click();

		// Verify tapping on the Filter tab opens the Filter Modal
		productresult.getLblAllStores().click();
		productresult.getTxtFilterModal().waitForPresent(5000);
		productresult.getTxtFilterModal().verifyPresent();
		productresult.getBtnCloseModal().click();
	}

	/**
	 * Verify tapping on the Sort opens the Sort Modal
	 */
	@QAFTestStep(description = "I tapping on the Sort opens the Sort Modal")
	public void iTappingOnTheSortOpensTheSortModal() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		productresult.getDpdBMDownCarat().waitForPresent(50000);

		// Get the first product name to Check the changes
		String product1st = productresult.getProductresultLblProductnameList().get(0).getText();
		getBundle().setProperty("FirstProductName", product1st);

		// Verify tapping on the Sort tab opens the Sort Modal
		productresult.getLblBestMatch().click();
		productresult.getTxtSortModal().waitForPresent(5000);
		productresult.getTxtSortModal().verifyPresent();
	}

	/**
	 * Verify Best Match is displayed with a check mark
	 */
	@QAFTestStep(description = "I Verify Best Match is displayed with a checkmark")
	public void iVerifyBestMatchIsDisplayedWithCheckmark() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		productresult.getTxtSortModal().waitForPresent(5000);
		productresult.getLblBmCheckMark().verifyPresent();
	}

	/**
	 * Tapping on the X of the Sort Modal
	 */
	@QAFTestStep(description = "I tapping on the X of the Sort Modal")
	public void iTappingOnTheXOfTheSortModal() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();
		productresult.getFiltermodalBtnDismiss().click();
	}

	/**
	 * Tapping outside of the Sort Modal
	 */
	@QAFTestStep(description = "I tapping outside of the Sort Modal")
	public void iTappingOutsideOfTheSortModal() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();
		// productresult.getImgTouchOutSide().click();
		// PerfectoUtils.androiddeviceback();

		Dimension size = getAppiumDriver().manage().window().getSize();
		int height = (size.height) / 10;
		System.out.println(size.height);

		Map<String, Object> params1 = new HashMap<>();
		params1.put("location", "0, " + Integer.toString(height));
		Object result1 = PerfectoUtils.getDriver().executeScript("mobile:touch:tap", params1);
	}

	@QAFTestStep(description = "I see CDP page")
	public void iSeeCDPPage() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();
		productresult.getLblBestMatch().waitForPresent(5000);
		productresult.getLblBestMatch().verifyPresent();
	}

	@QAFTestStep(description = "I select Newest on Sort Modal")
	public void iSelectNewestOnSortModal() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();
		productresult.getLblNewest().click();
	}

	/**
	 * verify the changes reflected in product list by comparing provious firt
	 * product name
	 */
	@QAFTestStep(description = "I verify the changes reflected in product list")
	public void iVerifyTheChangesReflectedInProductList() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		// Get the first product name to Check the changes
		String newest = productresult.getProductresultLblProductnameList().get(0).getText();

		if (newest.equals(getBundle().getProperty("FirstProductName")))
			PerfectoUtils.reportMessage("Changes are not refelected ", MessageTypes.Fail);
		else
			PerfectoUtils.reportMessage("Changes are reflected ", MessageTypes.Pass);

		System.out.println(newest + "  " + getBundle().getProperty("FirstProductName"));
	}

	/**
	 * I validate products sorted by different options available in the Sort
	 * Modal
	 */
	@QAFTestStep(description = "I validate products sorted by different options available in the Sort Modal")
	public void iValidateProductsSortedByDifferentOptionsAvailableInTheSortModal() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		// Validate Best Match selected
		productresult.getSortModalTxtBestMach().click();
		productresult.getLblBestMatch().verifyPresent();

		// Validate Newest selected
		productresult.getLblBestMatch().click();
		productresult.getLblNewest().click();
		String nwst = productresult.getLblBestMatch().getText();

		if (nwst.equalsIgnoreCase("NEWEST"))
			PerfectoUtils.reportMessage("Newest Filter Selected", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Newest Filter Not Selected", MessageTypes.Fail);

		// Validate A-Z filter Selection and Product sort
		productresult.getLblBestMatch().click();
		productresult.getSortModalTxtAtoZ().click();
		String aToZ = productresult.getLblBestMatch().getText();

		if (aToZ.equalsIgnoreCase("A-Z"))
			PerfectoUtils.reportMessage("A-Z Filter Selected", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("A-Z Filter Not Selected", MessageTypes.Fail);

		ArrayList<String> al = new ArrayList<String>();
		boolean isAscending = false;

		for (QAFWebElement productName : productresult.getProductresultLblProductnameList()) {
			al.add(productName.getText());
		}

		for (int i = 0; i < al.size() - 1; i++) {
			if (al.get(i).compareToIgnoreCase(al.get(i + 1)) < 0) {
				System.out.println(al.get(i) + " ; " + al.get(i + 1) + " ; " + al.get(i).compareTo(al.get(i + 1)));
				isAscending = true;
			} else {
				System.out.println(al.get(i) + " ; " + al.get(i + 1) + " ; " + al.get(i).compareTo(al.get(i + 1)));
				isAscending = false;
				break;
			}

			if (isAscending) {
				PerfectoUtils.reportMessage("Products are sorted in Ascending order", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Recipes are not sorted in Ascending order", MessageTypes.Fail);
			}
		}

		// Validate Z-A filter Selection and Product sort
		productresult.getLblBestMatch().click();
		productresult.getSortModalTxtZtoA().click();
		String zToA = productresult.getLblBestMatch().getText();

		if (zToA.equalsIgnoreCase("Z-A"))
			PerfectoUtils.reportMessage("Z-A Filter Selected", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Z-A Filter Not Selected", MessageTypes.Fail);

		ArrayList<String> alz = new ArrayList<String>();
		boolean isDecending = false;

		for (QAFWebElement productNam : productresult.getProductresultLblProductnameList()) {
			alz.add(productNam.getText());
		}

		for (int j = 0; j < alz.size() - 1; j++) {
			if (alz.get(j).compareTo(alz.get(j + 1)) > 0) {
				System.out.println(alz.get(j) + " ; " + alz.get(j + 1) + " ; " + alz.get(j).compareTo(alz.get(j + 1)));
				isDecending = true;
			} else {
				isDecending = false;
				break;
			}
		}

		if (isDecending) {
			PerfectoUtils.reportMessage("Products are sorted in Decending order", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Recipes are not sorted in Decending order", MessageTypes.Fail);
		}

		// Validate Rating selected and Verify Ratings
		productresult.getLblBestMatch().click();
		productresult.getSortModalTxtRatings().click();
		String rating = productresult.getLblBestMatch().getText();
		productresult.getImgRatingsBar().verifyPresent();

		if (rating.equalsIgnoreCase("Ratings"))
			PerfectoUtils.reportMessage("Ratings Filter Selected", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Ratings Filter Not Selected", MessageTypes.Fail);

		// Validate Price from High to Low

		productresult.getLblBestMatch().click();
		productresult.getSortModalTxtHightoLow().click();
		String hitoLow = productresult.getLblBestMatch().getText();

		if (hitoLow.equalsIgnoreCase("PRICE: HIGH TO LOW"))
			PerfectoUtils.reportMessage("HIGH TO LOW Filter Selected", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("HIGH TO LOW Filter Not Selected", MessageTypes.Fail);

		ArrayList<String> alp = new ArrayList<String>();

		for (QAFWebElement priceHigh : productresult.getTxtPriceList()) {
			alp.add(priceHigh.getText());
		}

		for (int k = 0; k < alp.size() - 1; k++) {
			String pric1 = alp.get(k).replace("$", "");
			String pric2 = alp.get(k + 1).replace("$", "");

			double a = Double.parseDouble(pric1);
			double b = Double.parseDouble(pric2);

			if (a > b) {
				PerfectoUtils.reportMessage("Product List Price is High to Low", MessageTypes.Pass);
				break;
			} else if (a == b) {
				PerfectoUtils.reportMessage("Product List Price is Same", MessageTypes.Info);
			} else {
				PerfectoUtils.reportMessage("Product List Price is not High to Low", MessageTypes.Fail);
				break;
			}
		}

		// Validate Price from Low to High

		productresult.getLblBestMatch().click();
		productresult.getSortModalTxtLowtoHigh().click();
		String lowtoHi = productresult.getLblBestMatch().getText();

		if (lowtoHi.equalsIgnoreCase("PRICE: LOW TO HIGH"))
			PerfectoUtils.reportMessage("Low to High Filter Selected", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Low to High Filter Not Selected", MessageTypes.Fail);

		ArrayList<String> allow = new ArrayList<String>();

		for (QAFWebElement priceLow : productresult.getTxtPriceList()) {
			allow.add(priceLow.getText());
		}

		for (int l = 0; l < alp.size() - 1; l++) {
			String pricLow1 = allow.get(l).replace("$", "");
			String pricLow2 = allow.get(l + 1).replace("$", "");

			double a = Double.parseDouble(pricLow1);
			double b = Double.parseDouble(pricLow2);

			if (a < b) {
				PerfectoUtils.reportMessage("Product List Price is Low to High", MessageTypes.Pass);
				break;
			} else if (a == b) {
				PerfectoUtils.reportMessage("Product List Price is Same", MessageTypes.Info);
			} else {
				PerfectoUtils.reportMessage("Product List Price is not Low to High", MessageTypes.Fail);
				break;
			}
		}

	}

	/**
	 * Verify if the sort order or filter name are too long, they will truncate
	 * in their respective tabs on the PCP
	 */
	@QAFTestStep(description = "I validate if the filter name are too long will truncate")
	public void iValidateIfTheFilterNameAreTooLongWillTruncate() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		productresult.getDpdBMDownCarat().waitForPresent(50000);
		productresult.getFiltermodalLblAllStores().click();
		productresult.getTxtFilterModal().waitForPresent(5000);
		productresult.getFiltermodalLblBrand().click();
		String brand1 = productresult.getFiltermodalLisBrandName().get(0).getText();
		productresult.getFiltermodalLisBrandName().get(0).click();
		String brand2 = productresult.getFiltermodalLisBrandName().get(1).getText();
		productresult.getFiltermodalLisBrandName().get(1).click();
		String brand3 = productresult.getFiltermodalLisBrandName().get(2).getText();
		productresult.getFiltermodalLisBrandName().get(2).click();
		productresult.getBtnCloseModal().click();
		String selected = productresult.getTxtSelBrandName().getText();

		if (selected.contains(brand1) && selected.contains(brand2) && selected.contains(brand3))
			PerfectoUtils.reportMessage("Selected Brand Names are truncate ", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Selected Brand Names are not truncate ", MessageTypes.Fail);
	}

	/**
	 * Choose a store from Filter tap And Verify when a store is already
	 * selected that Best Match is the default for the Sort tab and the chosen
	 * H-E-B store is displayed on the Filter tab on the PCP
	 */
	@QAFTestStep(description = "I validate Best Match and chosen store is default")
	public void iChooseAStoreFromFilterTap() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		productresult.getDpdBMDownCarat().waitForPresent(50000);
		productresult.getFiltermodalLblAllStores().click();
		productresult.getFiltermodalLblStoreSelection().click();
		productresult.getFiltermodalLblSelStore().click();
		String store = productresult.getFilterModalLblStore().getText();
		productresult.getFilterModalLblStore().click();
		PerfectoUtils.androiddeviceback();
		productresult.getFiltermodalBtnDismiss().click();
		productresult.getFiltermodalBtnDone().click();
		String selectedStore = productresult.getLblFilterTab().getText();
		productresult.getLblBestMatch().verifyPresent();

		if (store.equals(selectedStore))
			PerfectoUtils.reportMessage("Selected store is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Selected store is not displayed", MessageTypes.Fail);
	}

	/**
	 * I validate bottom menu item is accessible This step in not applicable for
	 * Android Hence creating dummy step implementation
	 */
	@QAFTestStep(description = "I validate bottom menu item is accessible")
	public void iValidateBottomMenuItemIsAccessible() {

		PerfectoUtils.reportMessage("This Step is Not applicable for Android", MessageTypes.Info);

	}

	/**
	 * Entering email id, hide keyboard and click send button. Validating the
	 * send button us not present after that.
	 */
	@QAFTestStep(description = "I enter valid email address and click on Send button")
	public void iEnterValidEmailAddressAndClickOnSendButton() {
		EmailcontentTestPage emailcontent = new EmailcontentTestPage();
		ProductdetailTestPage productdetail = new ProductdetailTestPage();
		CouponsdetailsTestPage couponspage = new CouponsdetailsTestPage();
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		String recipientEmail = null;
		int i = 0;
		emailcontent.waitForPageToLoad();
		recipientEmail = getBundle().getString("default.user.email");

		// Entering RecipientTo and clicking send button
		emailcontent.getEdtRecipientto().sendKeys(recipientEmail);
		PerfectoUtils.getAppiumDriver().hideKeyboard();
		emailcontent.getBtnSend().click();

		do {
			try {
				emailcontent.getBtnSend().waitForNotPresent(3000);
			} catch (Exception e) {
				i++;
			}
		} while (emailcontent.getBtnSend().isPresent() && i < 20);

		// Checking the Toast Message
		if (productdetail.getPdpTxtPagetitle().isPresent() || couponspage.getCouponsdetailLblPagetitle().isPresent()
				|| recipedetail.getRecipedetailpageRecipename().isPresent()) {
			PerfectoUtils.reportMessage("Product has been shared via email", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Product has not been shared via email", MessageTypes.Fail);
		}
	}

	/**
	 * Verifying the PDP page for title, Add to list button, find near by store
	 * button, share button, produce image, prize and quantity, Ratings, product
	 * details, Specification, HEB guarantee image, legal disclaimer image.
	 */
	@QAFTestStep(description = "I verify PDP page")
	public void iVerifyPDPPage() {
		ProductdetailTestPage productdetail = new ProductdetailTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
			PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Pass);
			storelocator.getStorelocatorBtnAllow().click();
		}

		productdetail.getPdpTxtPagetitle().verifyPresent();
		productdetail.getPdpBtnAddtolist().verifyPresent();
		if (productdetail.getPdpBtnOutofstock().isPresent()) {
			PerfectoUtils.reportMessage("Item is out of stock", MessageTypes.Pass);
		}
		productdetail.getPdpBtnSharebutton().verifyPresent();
		productdetail.getPdpImgProductimage().verifyPresent();
		productdetail.getPdpLblProductprize().verifyPresent();
		productdetail.getPdpLblProductquantity().verifyPresent();

		PerfectoUtils.verticalswipe();

		productdetail.getPdpBtnFindinnearbystore().verifyPresent();
		if (productdetail.getPdpLblRatings().isPresent()) {
			PerfectoUtils.reportMessage("Rating is avaible", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Rating is not avaible", MessageTypes.Pass);
		}

		productdetail.getPdpLblProductDetails().verifyPresent();
		productdetail.getPdpLblProductDetails().click();

		if (productdetail.getPdpLblSpecification().isPresent()) {
			PerfectoUtils.reportMessage("Specification is avaible", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Specification is not avaible", MessageTypes.Pass);
		}
		PerfectoUtils.androiddeviceback();

		PerfectoUtils.verticalswipe();
		PerfectoUtils.verticalswipe();
		if (productdetail.getPdpImgHebgurantee().isPresent()) {
			PerfectoUtils.reportMessage("H-E-B is avaible", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("H-E-B is not avaible", MessageTypes.Pass);
		}
		productdetail.getPdpImgLegaldisclamier().verifyPresent();
	}

	/**
	 * Wait for Done button and clicking it
	 */
	@QAFTestStep(description = "I click on done/refine button")
	public void iClickOnDoneRefineButton() {
		RefineTestPage refinepage = new RefineTestPage();

		refinepage.getBtnDone().waitForPresent(3000);
		refinepage.getBtnDone().click();
		PerfectoUtils.reportMessage("Clicked on Refine Done button.", MessageTypes.Pass);
	}

	/**
	 * Swipe and click on refine filter value
	 * 
	 * @param key
	 *            filter key
	 * @param value
	 *            filter value
	 */
	@QAFTestStep(description = "I select filter {0} and {1}")
	public void iSelectFilterAnd(String key, String value) {
		RefineTestPage refinepage = new RefineTestPage();

		PerfectoUtils.horizontalswipe();

		if (refinepage.getdynamicheader(value).isPresent()) {
			refinepage.getdynamicheader(value).click();
			PerfectoUtils.reportMessage("Refine Filter selected", MessageTypes.Pass);
		} else {
			try {
				AndroidStepDef.scrollToListNameInMyList(value, 80, 60, 2);
				refinepage.getdynamicheader(value).waitForPresent(3000);
				refinepage.getdynamicheader(value).click();
				PerfectoUtils.reportMessage("Refine Filter selected", MessageTypes.Pass);
			} catch (Exception e) {
				try {
					PerfectoUtils.getAppiumDriver().scrollTo(value).click();
					PerfectoUtils.reportMessage("Refine Filter selected", MessageTypes.Pass);
				} catch (Exception f) {
					PerfectoUtils.reportMessage("Refine Filter is not selected", MessageTypes.Fail);
				}
			}
		}
	}

	/**
	 * Selecting first nutrition tag
	 */
	@QAFTestStep(description = "I select any nutritional tags from PDP")
	public void iSelectAnyNutritionalTagsFromPDP() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		int size = productdetails.getIconNutritiontagslist().size();

		/* Checking if Nutritional tags are available */
		if (size != 0) {
			/* Clicking on first Nutritional tag */
			productdetails.getIconNutritiontagslist().get(0).click();
		} else {
			PerfectoUtils.reportMessage("No nutritional tags found. Please select different product.",
					MessageTypes.Fail);
		}
	}

	/**
	 * Validation of Nutritional tags page for title
	 */
	@QAFTestStep(description = "I verify the user navigated to Nutritional tags page")
	public void iVerifyTheUserNavigatedToNutritionalTagsPage() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		if (productdetails.getLblTitlenutritionaltags().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Nutritional tags page.", MessageTypes.Pass);
			PerfectoUtils.reportMessage("Title: " + productdetails.getLblTitlenutritionaltags().getText(),
					MessageTypes.Info);
		}
	}

	/**
	 * Validation of Healthy icon
	 */
	@QAFTestStep(description = "I verify the healthy icon is available")
	public void iVerifyTheHealthyIconIsAvailable() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		// Checking if the Heart healthy option is available
		if (productdetails.getLblHearthealthy().isPresent()) {
			PerfectoUtils.reportMessage("Heart Healthy option is available.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Heart Healthy option is not available. Please choose another product.",
					MessageTypes.Fail);
		}
	}

	/**
	 * Verify if Product details label is present and click
	 */
	@QAFTestStep(description = "I click on Product details from PDP")
	public void iClickOnProductDetailsFromPDP() {
		ProductdetailTestPage productdetail = new ProductdetailTestPage();

		PerfectoUtils.verticalswipe();

		productdetail.getPdpLblProductDetails().verifyPresent();
		productdetail.getPdpLblProductDetails().click();
	}

	/**
	 * Wait for store locator label and handle the "Allow device location" pop
	 * up. And navigate back to PDP page.
	 */
	@QAFTestStep(description = "I see Store locator page opened")
	public void iSeeStoreLocatorPageOpened() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		// Handling the store locator error
		try {
			storelocator.getLblNearbyStores().waitForPresent(10000);
		} catch (Exception e) {
			weeklygrocery.getShopingListEntryByLable("Allow H-E-B to access this device's location?")
					.waitForPresent(5000);
			if (weeklygrocery.getShopingListEntryByLable("Allow H-E-B to access this device's location?").isPresent()) {
				PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Info);
				androidcommon.getAppPopupBtnAllowPermission().verifyPresent();
				androidcommon.getAppPopupBtnAllowPermission().click();
			}
		}
		storelocator.waitForPageToLoad();
		storelocator.getLblNearbyStores().verifyPresent();

		/* Navigate back to PDP page */
		PerfectoUtils.androiddeviceback();
	}

	/**
	 * Navigate back to CDP page and validate if it moved to last category of
	 * variable "product.OfficeAndSchool.nav".
	 */
	@QAFTestStep(description = "I navigate back to CDP page")
	public void iNavigateBackToCDPPage() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		/* Navigate back to CDP page */
		PerfectoUtils.androiddeviceback();

		List<String> Category = getBundle().getList("product.OfficeAndSchool.nav");
		String LastCatgry = Category.get(Category.size() - 1);

		weeklygrocery.getShopingListEntryByLable(LastCatgry).verifyPresent();
	}

	/**
	 * Navigate to CDP page by clicking on list "items"
	 * 
	 * @param items
	 *            navigation list from products page to CDP
	 */
	@QAFTestStep(description = "I see CDP page by navigating {0} items")
	public void iSeeCDPPageByNavigatingItems(List<String> items) {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		/* Navigating through the category page */
		for (String lable : items) {

			if (weeklygrocery.getShopingListEntryByLable(lable).isPresent()) {
				PerfectoUtils.reportMessage("Found label: " + lable);
			} else {
				PerfectoUtils.scrollToString(lable, 80, 75, 2);
			}

			waitForPresent("name=" + lable);
			click("name=" + lable);

			if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
				PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Pass);
				storelocator.getStorelocatorBtnAllow().click();
			}

			PerfectoUtils.reportMessage("Clicked Catagory Name: " + lable + " ", MessageTypes.Info);

		}
	}

	/**
	 * Validation of share page - Email, Google+ and Facebook. And navigate
	 * back.
	 */
	@QAFTestStep(description = "I validate share page for PDP page")
	public void iValidateSharePageForPDPPage() {
		ProductdetailTestPage productdetail = new ProductdetailTestPage();

		if (productdetail.getPdpBtnEmail().isPresent()) {
			PerfectoUtils.reportMessage("Email option is available", MessageTypes.Pass);
		} else if (productdetail.getlblGmail().isPresent()) {
			PerfectoUtils.reportMessage("Email option is available", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Email option is not available", MessageTypes.Fail);
		}

		if (productdetail.getPdpBtnGoogleplus().isPresent()) {
			PerfectoUtils.reportMessage("Google+ option is available", MessageTypes.Pass);
		}

		if (productdetail.getPdpBtnFacebook().isPresent()) {
			PerfectoUtils.reportMessage("Facebook option is available", MessageTypes.Pass);
		}

		PerfectoUtils.androiddeviceback();
	}

	/**
	 * Clicking select a store label from CDP page. Validate Store locator
	 * currently unavailable pop up. Handle "Allow device location" pop up.
	 * Verify if Choose new store page is present.
	 */
	@QAFTestStep(description = "I click select a store from CDP page")
	public void iClickSelectAStoreFromCDPPage() {
		ProductsresultlistTestPage productresultpage = new ProductsresultlistTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();

		productresultpage.waitForPageToLoad();
		productresultpage.getLblSelectastore().waitForPresent(3000);

		if (productresultpage.getLblSelectastore().isPresent()) {
			productresultpage.getLblSelectastore().click();
			PerfectoUtils.reportMessage("Clicked on Select a store option..", MessageTypes.Pass);
		} else
			PerfectoUtils.reportMessage("Select a store option is not available", MessageTypes.Fail);

		if (appcrash.getAppExceptionMsgTitle().isPresent()) {
			appcrash.getExceptionBtnOk().click();
			PerfectoUtils.reportMessage("Store Locator Currently Unavailable", MessageTypes.Info);
		}

		try {
			if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
				storelocator.getStorelocatorTxtPopupmsg().verifyPresent();
				storelocator.getStorelocatorBtnAllow().click();
			}

			storelocator.getLblChooseNewStore().waitForPresent(2000);
		} catch (Exception e) {
			if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
				PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Pass);
				storelocator.getStorelocatorBtnAllow().click();
				PerfectoUtils.reportMessage("Clicked Allow button.", MessageTypes.Pass);
			}
		}
		storelocator.waitForPageToLoad();
		storelocator.getLblChooseNewStore().waitForPresent(2000);

		if (storelocator.getLblChooseNewStore().isPresent())
			PerfectoUtils.reportMessage("Choose new store page is displayed..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Choose new store page is not displayed..", MessageTypes.Fail);

	}

	/**
	 * Verify if selected store is displayed in CDP page. Selected store is
	 * carried out by getbundle property "StoreName". Compare this name and
	 * existing store name.
	 */
	@QAFTestStep(description = "I verify the selected store in CDP")
	public void iVerifyTheSelectedStoreInCDP() {
		ProductsresultlistTestPage itemresult = new ProductsresultlistTestPage();

		String displayedStore = null;
		String selectedStore = getBundle().getString("StoreName");
		selectedStore = PerfectoUtils.removeSpecialCharacters(selectedStore);

		itemresult.getLblSelectedStrore().waitForPresent(5000);
		itemresult.getLblSelectedStrore().verifyPresent();

		displayedStore = PerfectoUtils.removeSpecialCharacters(itemresult.getLblSelectedStrore().getText());
		if (selectedStore.contains(displayedStore))
			PerfectoUtils.reportMessage("Selected store " + selectedStore + " is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Selected store " + selectedStore + " is not displayed", MessageTypes.Fail);

	}

	/**
	 * Wait for Change store label to be present and Click it. If store
	 * unavailable pop up comes, select OK button. Handle
	 * "Allow device location" pop up. Verify if Choose new store page is
	 * present.
	 */
	@QAFTestStep(description = "I click Change store from CDP page")
	public void iClickChangeStoreFromCDPPage() {
		ProductsresultlistTestPage productresultpage = new ProductsresultlistTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();

		productresultpage.waitForPageToLoad();
		productresultpage.getLblChangestore().waitForPresent(3000);

		if (productresultpage.getLblChangestore().isPresent()) {
			productresultpage.getLblChangestore().click();
			PerfectoUtils.reportMessage("Clicked on Change store option..", MessageTypes.Pass);
		} else
			PerfectoUtils.reportMessage("Change option is not available", MessageTypes.Fail);

		if (appcrash.getAppExceptionMsgTitle().isPresent()) {
			appcrash.getExceptionBtnOk().click();
			PerfectoUtils.reportMessage("Store Locator Currently Unavailable", MessageTypes.Info);
		}

		try {
			if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
				storelocator.getStorelocatorTxtPopupmsg().verifyPresent();
				storelocator.getStorelocatorBtnAllow().click();
			}

			storelocator.getLblChooseNewStore().waitForPresent(2000);
		} catch (Exception e) {
			if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
				PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Pass);
				storelocator.getStorelocatorBtnAllow().click();
				PerfectoUtils.reportMessage("Clicked Allow button.", MessageTypes.Pass);
			}
		}
		storelocator.waitForPageToLoad();
		storelocator.getLblChooseNewStore().waitForPresent(2000);

		if (storelocator.getLblChooseNewStore().isPresent())
			PerfectoUtils.reportMessage("Choose new store page is displayed..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Choose new store page is not displayed..", MessageTypes.Fail);

	}

	/**
	 * Waiting for search field to be present and click it
	 */
	@QAFTestStep(description = "I click on Search Field")
	public void iClickOnSearchField() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		androidcommon.getAppIconSearchproducts().waitForPresent(50000);
		androidcommon.getAppIconSearchproducts().click();
		PerfectoUtils.reportMessage("Clicked Search icon");
	}

	/**
	 * Enter search term productName in search field and click search icon Hande
	 * the search error popup & exception popup
	 * 
	 * @param productName
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I enter valid search term {0}and select Search button")
	public void iEnterValidSearchTermAndSelectSearchButton(String productName) throws InterruptedException {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();
		WeeklygroceriesTestPage wgroceries = new WeeklygroceriesTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		int i = 0;

		System.out.println(productName);

		/*
		 * Enter product name in search field and click search button on
		 * keyboard
		 */
		wgsearchresult.waitForPageToLoad();

		storelocator.getStorelocatorTxtSearchicon().click();

		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys("");
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(productName);
		Map<String, Object> EnterKeyEvent = new HashMap<>();
		EnterKeyEvent.put("key", "66");
		wgroceries.getTestBase().getDriver().executeScript("mobile:key:event", EnterKeyEvent);

		while (i < 2) {
			if (wgroceries.getShopingListEntryByLable("Search Error").isPresent()
					|| wgroceries.getShopingListEntryByLable("Store Location Not Found").isPresent()) {
				PerfectoUtils.reportMessage("Search error: Unable to load search results!!", MessageTypes.Info);

				try {
					appcrash.getExceptionBtnOk().waitForPresent(5000);
					appcrash.getExceptionBtnOk().click();
				} catch (Exception e) {
					wgroceries.getShopingListEntryByLable("OK").waitForPresent(5000);
					wgroceries.getShopingListEntryByLable("OK").click();
				}

				/* Click search button on keyboard */
				PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys("");
				PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(productName);
				wgroceries.getTestBase().getDriver().executeScript("mobile:key:event", EnterKeyEvent);

			} else {
				break;
			}
			i++;
		}
		PerfectoUtils.reportMessage("Search term entered");

	}

	@QAFTestStep(description = "I verify the store availablity section")
	public void iVerifyTheStoreAvailablitySection() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		// Handle store location allow popup
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
			PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Pass);
			storelocator.getStorelocatorBtnAllow().click();
		}
		AndroidStepDefStoreLocator.storelocatorErrorHandle();

		if (!productdetails.gettxtstoreavailability().isDisplayed()) {
			PerfectoUtils.scrollToElement(productdetails.gettxtstoreavailability());
			if (productdetails.gettxtstoreavailability().isPresent()) {
				PerfectoUtils.reportMessage("Store Availabilty section is present", MessageTypes.Pass);
				productdetails.gettxtstoreavailability().verifyPresent();
				productdetails.getlnkviewnearbystores().verifyPresent();
				productdetails.getlblstorename().verifyPresent();
				productdetails.getlblstoreaddress().verifyPresent();
				productdetails.getlblstoreicon().verifyPresent();
				productdetails.gettxtmiles().verifyPresent();
			} else {
				PerfectoUtils.reportMessage("Store Availabilty section is not present", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.verticalswipe();
			// Verifying the store availability section
			if (productdetails.gettxtstoreavailability().isPresent()) {
				PerfectoUtils.reportMessage("Store Availabilty section is present", MessageTypes.Pass);
				productdetails.gettxtstoreavailability().verifyPresent();
				productdetails.getlnkviewnearbystores().verifyPresent();
				productdetails.getlblstorename().verifyPresent();
				productdetails.getlblstoreaddress().verifyPresent();
				productdetails.getlblstoreicon().verifyPresent();
				productdetails.gettxtmiles().verifyPresent();
			} else {
				PerfectoUtils.reportMessage("Store Availabilty section is not present", MessageTypes.Fail);
			}
		}
	}

	/**
	 * Verify price and unit of measure are in lower case
	 */
	@QAFTestStep(description = "I verify that Unit of Measure is in lower case in both Qty and Price / Qty")
	public void iVerifyThatUnitOfMeasureIsInLowerCaseInBothQtyAndPriceQty() {
		ProductdetailTestPage productDetails = new ProductdetailTestPage();

		AndroidStepDefStoreLocator.storelocatorErrorHandle();

		// Verify Price and UOM have lower case
		productDetails.getPdpLblProductprize().waitForPresent(3000);
		String price = productDetails.getPdpLblProductprize().getText();
		String priceperunit = productDetails.getPdpLblUom().getText();

		if (!(checkStringContainUppercase(price) && checkStringContainUppercase(priceperunit)))
			PerfectoUtils.reportMessage("Price does not contain Upper case character ..", MessageTypes.Pass);
		else {
			if (!checkStringContainUppercase(price))
				PerfectoUtils.reportMessage("Price contain Upper case character ..", MessageTypes.Fail);

			if (!checkStringContainUppercase(priceperunit))
				PerfectoUtils.reportMessage("Priceperunit contain Upper case character ..", MessageTypes.Fail);
		}

	}

	/**
	 * Verify given string containg uppercase
	 * 
	 * @param price
	 * @return
	 */
	public boolean checkStringContainUppercase(String price) {
		price = PerfectoUtils.removeSpecialCharacters(price);
		System.out.println(price);
		int j;
		boolean isupper = false;
		for (j = 0; j < price.length(); j++) {
			if (Character.isLowerCase(price.charAt(j)))
				System.out.println(price.charAt(j) + " is Lower case");
			else
				isupper = true;
		}
		return isupper;
	}

	@QAFTestStep(description = "I navigate to Products page without setting location")
	public void iNavigateToProductsPageWithoutSettingLocation() {
		HomeTestPage homepage = new HomeTestPage();

		homepage.getHomeLblWeeklyAd().waitForPresent(3000);

		// Verify product label is present
		if (!homepage.getHomeLblProduct().isPresent()) {
			PerfectoUtils.verticalswipe();
		}

		homepage.getHomeLblProduct().click();
		PerfectoUtils.reportMessage("Clicked on Products from Home Homepage", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I verify that stores are displayed in chronological orders")
	public void iVerifyThatStoresAreDisplayedInChronologicalOrders() {
		ProductdetailTestPage productdetail = new ProductdetailTestPage();

		LinkedList<Integer> Li = new LinkedList<Integer>();
		LinkedList<Integer> Dup = new LinkedList<Integer>();
		int c = 0;
		int lstmiles = productdetail.getpdpstoremodaldistance().size();

		List<QAFWebElement> milesval = productdetail.getpdpstoremodaldistance();

		for (int i = 0; i <= lstmiles - 1; i++) {
			milesval.get(i).waitForPresent(3000);
			String sigmileval1 = milesval.get(i).getText();
			int dis = Integer.parseInt(sigmileval1.replaceAll("\\D", ""));
			Li.add(dis);
			Dup.add(dis);
			System.out.println(dis);
		}

		Collections.sort(Li);

		Iterator<Integer> Ltr = Li.iterator();
		Iterator<Integer> Ltr2 = Dup.iterator();
		while (Ltr.hasNext() && Ltr2.hasNext()) {
			if (Ltr.next().equals(Ltr2.next())) {
				c = c + 1;
			}
		}
		System.out.println(c);
		System.out.println(lstmiles);
		if (c == lstmiles) {
			PerfectoUtils.reportMessage("Store are in chronological order", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Store are not in chronological order", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I taps on back button and verify navigated back to store modal page")
	public void iTapsOnBackButtonAndVerifyNavigatedBackToStoreModalPage() {
		ProductdetailTestPage productdetail = new ProductdetailTestPage();
		PerfectoUtils.androiddeviceback();
		PerfectoUtils.scrollToElement(productdetail.getpdpstorepagestorefeaturelbl());
		productdetail.getpdpstorepagestorefeaturelbl().waitForPresent(2000);
		if (productdetail.getpdpstorepagestorefeaturelbl().isPresent()) {
			PerfectoUtils.reportMessage("navigated back to store detail page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated back to store detail page", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I reset the location")
	public void iResetTheLocation() {
		Map<String, Object> params = new HashMap<>();
		Object result = PerfectoUtils.getAppiumDriver().executeScript("mobile:location:reset", params);
	}

	@QAFTestStep(description = "I verify that Store Availability section is not present after denying location")
	public void iVerifyThatStoreAvailabilitySectionIsNotPresentAfterDenyingLocation() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		PerfectoUtils.verticalswipe();
		PerfectoUtils.verticalswipe();
		if (!productdetails.gettxtstoreavailability().isPresent()) {
			PerfectoUtils.reportMessage("Unable to see store availability section", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("store availability section is still present", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I reset the location from device settings")
	public void iResetTheLocationFromDeviceSettings() {
		Map<String, Object> params = new HashMap<>();
		Object result = PerfectoUtils.getAppiumDriver().executeScript("mobile:location:reset", params);
	}

	/**
	 * Navigate to products page using 3 bar menu.
	 */
	@QAFTestStep(description = "I navigate to products page by android 3 bar and ios home menu")
	public void iNavigateToProductsPageByAndroid3BarAndIosHomeMenu() {
		HomeTestPage homepage = new HomeTestPage();
		AndroidcommonTestPage comTestPage = new AndroidcommonTestPage();
		ProductlandingTestPage prodLanding = new ProductlandingTestPage();

		comTestPage.getAppHamburger().verifyPresent();
		comTestPage.getAppHamburger().click();

		comTestPage.getAppSliderProducts().waitForPresent(3000);
		String optionNam = comTestPage.getAppSliderProducts().getText();
		comTestPage.getAppSliderProducts().verifyPresent();

		comTestPage.getAppSliderProducts().click();
		PerfectoUtils.reportMessage("Clicked on products option from 3 bar menu..");

		prodLanding.getLblPageTitle().waitForPresent(5000);
		if (prodLanding.getLblPageTitle().getText().equals(optionNam))
			PerfectoUtils.reportMessage("Products page is loaded ...", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Products page is not loaded ...", MessageTypes.Fail);

	}

	/**
	 * Navigate to CDP page by clicking on list "items"
	 * 
	 * @param items
	 *            navigation list from products page to CDP
	 */
	@QAFTestStep(description = "I see CDP page by navigating {0} items with category page validation")
	public void iSeeCDPPageByNavigatingItemsWithCategoryPageValidation(List<String> items) {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		ProductlandingTestPage productlandingPage = new ProductlandingTestPage();

		/* Navigating through the category page */
		for (String lable : items) {

			if (weeklygrocery.getShopingListEntryByLable(lable).isPresent()) {
				PerfectoUtils.reportMessage("Found label: " + lable);
			} else {
				PerfectoUtils.scrollToString(lable, 80, 75, 2);
			}

			waitForPresent("name=" + lable);
			click("name=" + lable);

			PerfectoUtils.reportMessage("Clicked Catagory Name: " + lable + " ", MessageTypes.Info);

			weeklygrocery.getShopingListEntryByLable(lable).waitForPresent(3000);
			weeklygrocery.getShopingListEntryByLable(lable).verifyPresent();
			List<QAFWebElement> categoryList = new ArrayList<QAFWebElement>(productlandingPage.getLblCategoryList());
			boolean found = false;
			for (int i = 0; i < categoryList.size(); i++) {
				if (categoryList.get(i).getText().equals(lable)) {
					PerfectoUtils.reportMessage("Category page is not loaded...", MessageTypes.Fail);
					found = true;
				}
			}
			if ((!found) && weeklygrocery.getShopingListEntryByLable(lable).isPresent())
				PerfectoUtils.reportMessage("Category page is displayed..", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Category page is not loaded...", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the properties of Product Information Disclaimer page")
	public void verifyThePropertiesOfProductInformationDisclaimerPage() {
		LegalDisclaimerTestPage legaldisclaimer = new LegalDisclaimerTestPage();

		legaldisclaimer.getLblPageheader().verifyPresent();
		legaldisclaimer.getLblLegalmessage().verifyPresent();
		legaldisclaimer.getBtnOk().verifyPresent();
	}

	@QAFTestStep(description = "Verify all the Shopping lists are available in Add to list popup")
	public void verifyAllTheShoppingListsAreAvailableInAddToListPopup() {

		int ListCount_FromAddtolistpopup = getAllShoppinglistsCount_FromAddtolistPopup();
		int ListCount_FromMyListsPage = getBundle().getInt("ListCount_FromMyListsPage");

		System.out.println("  **" + ListCount_FromAddtolistpopup + " ***" + ListCount_FromMyListsPage);

		if (ListCount_FromAddtolistpopup == ListCount_FromMyListsPage) {
			PerfectoUtils.reportMessage("All Available Shoppinglists are available in the Add to list popup.",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Validation failed.", MessageTypes.Fail);
			PerfectoUtils.reportMessage("ListCount_FromMyListsPage: " + ListCount_FromMyListsPage);
			PerfectoUtils.reportMessage("ListCount_FromAddtolistpopup: " + ListCount_FromAddtolistpopup);
		}
	}

	public int getAllShoppinglistsCount_FromAddtolistPopup() {

		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();

		int ListCount_FromMyListsPage = getBundle().getInt("ListCount_FromMyListsPage");

		Set<String> strList = new HashSet<>();

		String firstListName = androidcommonpage.getAddtolistTxtNumberpicker().getText();
		strList.add(firstListName);

		String pickerName = "";
		int getSize = 0, count = 0, i = 0;

		getSize = androidcommonpage.getAddtolistTxtNextpicker().size();

		do {
			String nextPicker = androidcommonpage.getAddtolistTxtNextpicker().get(getSize - 1).getText();
			strList.add(nextPicker);
			try {
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", nextPicker);
				Object result1 = androidcommonpage.getTestBase().getDriver().executeScript("mobile:text:select",
						params1);
			} catch (Exception e) {
				androidcommonpage.getAddtolistTxtNextpicker().get(getSize - 1).click();
			}
			pickerName = androidcommonpage.getAddtolistTxtNumberpicker().getText();
			strList.add(pickerName);

			getSize = androidcommonpage.getAddtolistTxtNextpicker().size();
			count++;
			i++;
		} while (!pickerName.equals(firstListName) && (i <= ListCount_FromMyListsPage));

		return strList.size();

	}

	@QAFTestStep(description = "Verify only Weekly Groceries list is available in the add to list popup")
	public void verifyOnlyWeeklyGroceriesListIsAvailableInTheAddToListPopup() {
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();

		String firstListName = androidcommonpage.getAddtolistTxtNumberpicker().getText();
		int getSize = androidcommonpage.getAddtolistTxtNextpicker().size();

		if ((firstListName.equalsIgnoreCase("Weekly Groceries")) && getSize == 0) {
			PerfectoUtils.reportMessage("Only Weekly Groceries List is available in the Add to list popup",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Validation failed.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify that choose another store is not present on PDP")
	public void iverifythatchooseanotherstoreisnotpresentonPDP() {

		ProductsresultlistTestPage productresultpage = new ProductsresultlistTestPage();
		if (!productresultpage.getLblSelectastore().isPresent()) {
			PerfectoUtils.reportMessage("Choose another store is not present", MessageTypes.Pass);
		}

	}

	@QAFTestStep(description = "I verify that choose another store is present on CDP")
	public void iverifythatchooseanotherstoreispresentonCDP() {
		ProductsresultlistTestPage productresultpage = new ProductsresultlistTestPage();
		if (productresultpage.getLblSelectastore().isPresent()) {
			PerfectoUtils.reportMessage("Choose another store is not present", MessageTypes.Pass);
		}

	}

	@QAFTestStep(description = "I verify the product count getting displayed in my store tab")
	public void iverifytheproductcountgettingdisplayedinmystoretab() {
		ProductsresultlistTestPage itemresult = new ProductsresultlistTestPage();
		String count = itemresult.getLblallproductscount().getText();
		Pattern p = Pattern.compile("\\d");
		Matcher m = p.matcher(count);
		if (m.find()) {

			PerfectoUtils.reportMessage("Item count is displayed", MessageTypes.Pass);

		} else {
			PerfectoUtils.reportMessage("Item count is not displayed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the user not able to see the Weekly Groceries list")
	public void verifyTheUserNotAbleToSeeTheWeeklyGroceriesList() {
		AddtolistTestPage addtolist = new AddtolistTestPage();

		if (!addtolist.getLblWeeklygroceries().isPresent()) {
			PerfectoUtils.reportMessage("User not able to see the Weekly Groceries list in the Add to list popup",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Validation failed.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the Scan got cancelled on clicking Back Or Cancel icon")
	public void verifyTheScanGotCancelledOnClickingBackOrCancelIcon() {
		ScanProductsTestPage scanpdts = new ScanProductsTestPage();

		scanpdts.getBtnBack().waitForPresent(5000);

		if (scanpdts.getBtnBack().isPresent()) {
			scanpdts.getBtnBack().click();
			PerfectoUtils.reportMessage("Clicked on Back button.", MessageTypes.Pass);

			if (!scanpdts.getLblPagetitle().isPresent()) {
				PerfectoUtils.reportMessage("Navigated back from Scan Products page.", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Not navigated back from Scan Products page.", MessageTypes.Fail);
			}

		} else {
			PerfectoUtils.reportMessage("Cancel button not found.", MessageTypes.Fail);
		}

	}

	/**
	 * Verify the CDP page without any store selected
	 */
	@QAFTestStep(description = "I verify the CDP page without any store selected")
	public void iVerifyTheCdpPageWithoutAnyStoreSelected() {
		ProductsresultlistTestPage productresultpage = new ProductsresultlistTestPage();

		productresultpage.getLblAllproducts().verifyPresent();
		productresultpage.getLblSelectastore().verifyPresent();
		String activeTabColor = productresultpage.getLblAllproducts().getAttribute("selected");
		if (activeTabColor.equals("true"))
			PerfectoUtils.reportMessage("All tab is displayed as active tab..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("All tab is displayed as not active tab..", MessageTypes.Fail);

		List<QAFWebElement> tabs = new ArrayList<QAFWebElement>(productresultpage.getLblTabs());

		for (int i = 0; i < tabs.size(); i++) {

			if (tabs.get(i).getText().equalsIgnoreCase("IN MY STORE")) {
				activeTabColor = tabs.get(i).getAttribute("selected");
				if (activeTabColor.equals("false"))
					PerfectoUtils.reportMessage("In my Store tab is not displayed as active tab..", MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("In my Store tab is displayed as active tab..", MessageTypes.Fail);

				break;
			}
		}

	}

	/**
	 * Verify the CDP page with any store selected
	 */
	@QAFTestStep(description = "I verify the CDP page with store selected")
	public void iVerifyTheCdpPageWithStoreSelected() {
		ProductsresultlistTestPage productresultpage = new ProductsresultlistTestPage();

		productresultpage.getLblAllproducts().verifyPresent();
		productresultpage.getLblSelectastore().verifyNotPresent();
		productresultpage.getLblChangestore().verifyPresent();
		String activeTabColor = productresultpage.getLblAllproducts().getAttribute("selected");
		if (activeTabColor.equals("true"))
			PerfectoUtils.reportMessage("All tab is displayed as active tab..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("All tab is displayed as not active tab..", MessageTypes.Fail);

		// PerfectoUtils.reportMessage("Clicked In my store tab..");

		List<QAFWebElement> tabs = new ArrayList<QAFWebElement>(productresultpage.getLblTabs());

		for (int i = 0; i < tabs.size(); i++) {
			System.out.println(tabs.get(i).getText());
			if (tabs.get(i).getText().equalsIgnoreCase("IN MY STORE")) {
				tabs.get(i).click();
				PerfectoUtils.reportMessage("Clicked In my store tab..");
				activeTabColor = tabs.get(i).getAttribute("selected");
				if (activeTabColor.equals("true"))
					PerfectoUtils.reportMessage("In my Store tab is displayed as active tab..", MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("In my Store tab is displayed as not active tab..", MessageTypes.Fail);

				break;
			}
		}

	}

	@QAFTestStep(description = "Select Send button without entering the Mandatory fields")
	public void selectSendButtonWithoutEnteringTheMandatoryFields() {
		EmailcontentTestPage emailcontent = new EmailcontentTestPage();

		if (emailcontent.getBtnSend().isPresent()) {
			PerfectoUtils.getAppiumDriver().hideKeyboard();
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "Enter at least one valid recipient");
			emailcontent.getBtnSend().click();
			String errorText = (String) emailcontent.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
					params1);
			PerfectoUtils.reportMessage("Selected Send button");
			ConfigurationManager.getBundle().setProperty("errorText", errorText);
		} else {
			PerfectoUtils.reportMessage("Send button not found.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify the search terms gets cleared on clicking X icon")
	public void verifyTheSearchTermsGetsClearedOnClickingXIcon() {
		ProductlandingTestPage pdtlanding = new ProductlandingTestPage();

		if (pdtlanding.getBtnSearchclose().isPresent()) {
			pdtlanding.getBtnSearchclose().click();
			PerfectoUtils.reportMessage("Clicked on Search close button.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Search close button not found.", MessageTypes.Fail);
		}

		if (pdtlanding.getTxtProductsSearchBox().getText().equalsIgnoreCase("Search products")) {
			PerfectoUtils.reportMessage("Search term cleared successfully.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Close Search failed.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Validate the error message without entering the Mandatory fields")
	public void validateTheErrorMessageWithoutEnteringTheMandatoryFields() {
		EmailcontentTestPage emailcontent = new EmailcontentTestPage();

		String errorText = ConfigurationManager.getBundle().getString("errorText");

		if (errorText.equalsIgnoreCase("true")) {
			PerfectoUtils.reportMessage("Error message validated.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Toast message cannot be validated.", MessageTypes.Info);
		}
	}

	/**
	 * Entering search term "productName" in Search text field, Click search
	 * button from keyboard. Wait till the loading image disappears. Handle
	 * store location error.
	 * 
	 * @param productName
	 *            search term or product name
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I enter valid search term {0}and select Search button in Recipe screen")
	public void iEnterValidSearchTermAndSelectSearchButtonInRecipeScreen(String productName)
			throws InterruptedException {

		iEnterValidSearchTermAndSelectSearchButton(productName);
	}

	@QAFTestStep(description = "I verify Product title by scrolling out of view appears in the header")
	public void iVerifyProductTitleByScrollingOutOfViewAppearsInTheHeader() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		productdetails.getPdpLblProductname().waitForPresent(5000);
		PerfectoUtils.verticalswipe();
		productdetails.getPdpTxtPagetitle().waitForPresent(3000);
		if (productdetails.getPdpTxtPagetitle().isPresent()) {
			String pdt = productdetails.getPdpTxtPagetitle().getText();
			PerfectoUtils.reportMessage("Able to see Product Title by scrolling out. " + pdt, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see Product Title.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I open Filter tab")
	public void iOpenFilterTab() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
			PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Pass);
			storelocator.getStorelocatorBtnAllow().click();
		}

		productresult.getLblFilterTab().verifyPresent();
		productresult.getLblFilterTab().click();
	}

	@QAFTestStep(description = "I verify modal will close after tapping device back button")
	public void iVerifyModalWillCloseAfterTappingDeviceBackButton() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		// Selecting a Brand
		productresult.getFiltermodalLblBrand().verifyPresent();
		productresult.getFiltermodalLblBrand().click();
		productresult.getFiltermodalLblBottomSheetTitle().waitForPresent(2000);
		productresult.getFiltermodalLblBottomSheetTitle().verifyPresent();
		productresult.getFiltermodalLisBrandName().get(0).verifyPresent();
		String brandName = productresult.getFiltermodalLisBrandName().get(0).getText();
		productresult.getFiltermodalLisBrandName().get(0).click();
		PerfectoUtils.androiddeviceback();

		productresult.getFiltermodalListSelectedBrandName().get(1).waitForPresent(2000);
		String selectedBrandName = productresult.getFiltermodalListSelectedBrandName().get(1).getText();

		if (brandName.equals(selectedBrandName)) {
			PerfectoUtils.reportMessage("Selected Brand is present in the modal", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected Brand is not present in the modal", MessageTypes.Fail);
		}

		// Tapping device back button
		PerfectoUtils.androiddeviceback();
		if (productresult.getFiltermodalLblFilters().isPresent()) {
			PerfectoUtils.reportMessage("Filter modal is still visible", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("Filter modal is not present", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I navigate to store selection page")
	public void iNavigateToStoreSelectionPage() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		productresult.getFiltermodalLblStoreSelection().verifyPresent();
		productresult.getFiltermodalLblStoreSelection().click();

		productresult.getFiltermodalLblFilters().waitForPresent(3000);
		if (productresult.getFiltermodalLblFilters().isPresent()) {
			PerfectoUtils.reportMessage("navigated to Store Selection page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Store Selection page is not present", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify Store Selection screen")
	public void iVerifyStoreSelectionScreen() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		if (productresult.getStoreselectionLblClosestHEB().isPresent()) {
			productresult.getStoreselectionLblClosestHEB().verifyPresent();
			PerfectoUtils.reportMessage("The Closest H-E-B to you is present");

			String distance = productresult.getStoreselectionLblHEBDistance().getText();
			String storeName = productresult.getStoreselectionLblStorename().getText();
			String storeAdd = productresult.getStoreselectionLblHEBAddress().getText();

			PerfectoUtils
					.reportMessage("Store name " + storeName + ", Distance " + distance + " and Address " + storeAdd);
			PerfectoUtils.reportMessage("All fields are present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Closest HEB is not present", MessageTypes.Fail);
		}
		productresult.getStoreselectionLblSelectastore().verifyPresent();
	}

	@QAFTestStep(description = "I navigate back to CDP page from Select a Store screen")
	public void iNavigateBackToCDPPageFromSelectAStoreScreen() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		// Navigating back to CDP page
		productresult.getFiltermodalLblFilters().verifyPresent();
		productresult.getFiltermodalBtnDismiss().click();
		productresult.getFiltermodalLblFilters().verifyPresent();
		productresult.getFiltermodalBtnDismiss().click();
		productresult.getFiltermodalLblFilters().verifyPresent();
		productresult.getFiltermodalBtnDismiss().click();

		// Verifying CDP page
		if (productresult.getLblAllStores().isPresent()) {
			productresult.getLblAllStores().verifyPresent();
			PerfectoUtils.reportMessage("CDP page is visible", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("CDP page is not visible", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify store is displayed under My H-E-B")
	public void iVerifyStoreIsDisplayedUnderMyHEB() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		String storeName = getBundle().getString("StoreName");
		if (productresult.getStoreselectionLblMyHEB().isPresent()) {
			PerfectoUtils.reportMessage("My Heb is visible");
			String storeNameinMyHEB = productresult.getStoreselectionLblStorename().getText();
			if (storeNameinMyHEB.equalsIgnoreCase(storeName)) {
				PerfectoUtils.reportMessage("Same Store is Present under My HEB", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Store is not matching", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("My Heb is not present", MessageTypes.Info);
		}
	}

	@QAFTestStep(description = "I navigate back after selecting a store")
	public void iNavigateBackAfterSelectingAStore() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		productresult.getStoreselectionListSelectedStoreName().get(0).verifyPresent();
		String firstStoreName = productresult.getStoreselectionListSelectedStoreName().get(0).getText();
		productresult.getStoreselectionListSelectedStoreName().get(0).click();
		PerfectoUtils.reportMessage("store selected " + firstStoreName);

		productresult.getFiltermodalBtnDismiss().click();
		productresult.getStoreselectionLblSelectastore().waitForPresent(3000);

		String selStoreName = productresult.getStoreselectionListSelectedStoreName().get(0).getText();
		if (selStoreName.equals(firstStoreName)) {
			PerfectoUtils.reportMessage("Store selected Successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Store name mismatched", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I open Filter tab with denying location services")
	public void iOpenFilterTabWithDenyingLocationServices() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
			PerfectoUtils.reportMessage("Denying H-E-B to access device location", MessageTypes.Pass);
			storelocator.getStorelocatorBtnDeny().click();
		}

		productresult.getLblFilterTab().verifyPresent();
		productresult.getLblFilterTab().click();
	}

	@QAFTestStep(description = "I see CDP page by navigating {0}")
	public void iSeeCDPPageByNavigating(List<String> items) {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		/* Navigating through the category page */
		for (String lable : items) {

			if (weeklygrocery.getShopingListEntryByLable(lable).isPresent()) {
				PerfectoUtils.reportMessage("Found label: " + lable);
			} else {
				PerfectoUtils.scrollToString(lable, 80, 75, 2);
			}

			waitForPresent("name=" + lable);
			click("name=" + lable);

			PerfectoUtils.reportMessage("Clicked Catagory Name: " + lable + " ", MessageTypes.Info);

		}
	}

	@QAFTestStep(description = "I verify the filter tab for hot user")
	public void iVerifyTheFilterTabForHotUser() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		if (productresult.getLblAllStores().isPresent()) {
			productresult.getLblAllStores().verifyPresent();
			String storeName = productresult.getLblAllStores().getText();
			ConfigurationManager.getBundle().setProperty("StoreName", storeName);
			PerfectoUtils.reportMessage("Store name is.." + storeName, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("no Store is present..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I validate Clear button after a filter selection")
	public void iValidateClearButtonAfterAFilterSelection() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		// Selecting a Brand
		productresult.getFiltermodalLblBrand().verifyPresent();
		productresult.getFiltermodalLblBrand().click();
		productresult.getFiltermodalLblBottomSheetTitle().waitForPresent(2000);
		productresult.getFiltermodalLblBottomSheetTitle().verifyPresent();
		productresult.getFiltermodalLisBrandName().get(0).verifyPresent();
		String brandName = productresult.getFiltermodalLisBrandName().get(0).getText();
		productresult.getFiltermodalLisBrandName().get(0).click();
		productresult.getFiltermodalBtnDismiss().click();

		productresult.getFiltermodalListSelectedBrandName().get(1).waitForPresent(2000);
		String selectedBrandName = productresult.getFiltermodalListSelectedBrandName().get(1).getText();

		if (brandName.equals(selectedBrandName)) {
			PerfectoUtils.reportMessage("Selected Brand is present in the modal", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected Brand is not present in the modal", MessageTypes.Fail);
		}

		// Clearing the selected brand
		productresult.getFiltermodalBtnClear().verifyPresent();
		productresult.getFiltermodalBtnClear().click();
		String brand = productresult.getFiltermodalTxtBrandAfterClear().getText();
		if (!selectedBrandName.equals(brand)) {
			PerfectoUtils.reportMessage("Selected Brand is removed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected Brand is still present in the modal", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I validate X button after a filter selection")
	public void iValidateXButtonAfterAFilterSelection() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		// Selecting a Brand
		productresult.getFiltermodalLblBrand().verifyPresent();
		productresult.getFiltermodalLblBrand().click();
		productresult.getFiltermodalLblBottomSheetTitle().waitForPresent(2000);
		productresult.getFiltermodalLblBottomSheetTitle().verifyPresent();
		productresult.getFiltermodalLisBrandName().get(0).verifyPresent();
		String brandName = productresult.getFiltermodalLisBrandName().get(0).getText();
		productresult.getFiltermodalLisBrandName().get(0).click();
		productresult.getFiltermodalBtnDismiss().click();

		productresult.getFiltermodalListSelectedBrandName().get(1).waitForPresent(2000);
		String selectedBrandName = productresult.getFiltermodalListSelectedBrandName().get(1).getText();

		if (brandName.equals(selectedBrandName)) {
			PerfectoUtils.reportMessage("Selected Brand is present in the modal", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Selected Brand is not present in the modal", MessageTypes.Fail);
		}

		// Tapping X button
		productresult.getFiltermodalBtnDismiss().click();
		if (productresult.getFiltermodalLblFilters().isPresent()) {
			PerfectoUtils.reportMessage("Filter modal is still visible", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("Filter modal is not present", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I select a multiple filters")
	public void iSelectAMultipleFilters() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		// Selecting a Brand
		productresult.getFiltermodalLblBrand().verifyPresent();
		productresult.getFiltermodalLblBrand().click();
		productresult.getFiltermodalLblBottomSheetTitle().waitForPresent(2000);

		if (productresult.getFiltermodalLblBottomSheetTitle().isPresent()) {
			String brandName = productresult.getFiltermodalLisBrandName().get(1).getText();
			ConfigurationManager.getBundle().setProperty("BrandName", brandName);
			productresult.getFiltermodalLisBrandName().get(1).click();
			PerfectoUtils.reportMessage("Brand Selected");
		} else {
			PerfectoUtils.reportMessage("Sheet Title is not present", MessageTypes.Info);
		}
		productresult.getFiltermodalBtnDismiss().click();

		// Selecting a Life Style
		productresult.getFiltermodalLblLifeStyles().verifyPresent();
		productresult.getFiltermodalLblLifeStyles().click();
		productresult.getFiltermodalLblBottomSheetTitle().waitForPresent(2000);
		productresult.getFiltermodalLblBottomSheetTitle().verifyPresent();
		productresult.getFiltermodalLisBrandName().get(0).verifyPresent();
		productresult.getFiltermodalLisBrandName().get(0).click();
		PerfectoUtils.reportMessage("Life Style Selected");
		productresult.getFiltermodalBtnDismiss().click();

		// Selecting a Price
		productresult.getFiltermodalLblPrice().verifyPresent();
		productresult.getFiltermodalLblPrice().click();
		productresult.getFiltermodalLblBottomSheetTitle().waitForPresent(2000);
		productresult.getFiltermodalLblBottomSheetTitle().verifyPresent();
		productresult.getFiltermodalLisBrandName().get(1).verifyPresent();
		productresult.getFiltermodalLisBrandName().get(1).click();
		PerfectoUtils.reportMessage("Price Selected");
		productresult.getFiltermodalBtnDismiss().click();
	}

	@QAFTestStep(description = "I verify Select a Store screen")
	public void iVerifySelectAStoreScreen() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		int storeNameSize = productresult.getStoreselectionListSelectedStoreName().size();
		int storeAddSize = productresult.getStoreselectionListSelectedStoreAddress().size();
		int storeDisSize = productresult.getStoreselectionListSelectedStoreDistance().size();

		PerfectoUtils.reportMessage("total Stores are " + storeNameSize);
		PerfectoUtils.reportMessage("First Store Name "
				+ productresult.getStoreselectionListSelectedStoreName().get(storeNameSize - 1).getText()
				+ " and Address is "
				+ productresult.getStoreselectionListSelectedStoreAddress().get(storeNameSize - 1).getText());

		if (storeDisSize > 0) {
			orderedListOfDistanceInSelectAStoreScreen();
			PerfectoUtils.reportMessage("Distance present");
		} else {
			PerfectoUtils.reportMessage("Distance is not present");
		}

	}

	@QAFTestStep(description = "Ordered List of Distance in Select a Store Screen")
	public void orderedListOfDistanceInSelectAStoreScreen() {
		ProductsresultlistTestPage productresult = new ProductsresultlistTestPage();

		int storeDisSize = productresult.getStoreselectionListSelectedStoreDistance().size();

		// Comparing Stores Distances
		List<String> distance = new ArrayList<String>();

		for (QAFWebElement dis : productresult.getStoreselectionListSelectedStoreDistance()) {
			String storeDistance = dis.getText();
			distance.add(storeDistance);
		}

		for (int i = 0; i < storeDisSize - 1; i++) {
			if (distance.get(i).compareTo(distance.get(i + 1)) < 0) {
				PerfectoUtils.reportMessage("Distance is in order", MessageTypes.Pass);
			} else if (distance.get(i).compareTo(distance.get(i + 1)) == 0) {
				PerfectoUtils.reportMessage("Equal Distance", MessageTypes.Info);
			} else {
				PerfectoUtils.reportMessage("Distance is not in order", MessageTypes.Fail);
			}
		}
	}

}
