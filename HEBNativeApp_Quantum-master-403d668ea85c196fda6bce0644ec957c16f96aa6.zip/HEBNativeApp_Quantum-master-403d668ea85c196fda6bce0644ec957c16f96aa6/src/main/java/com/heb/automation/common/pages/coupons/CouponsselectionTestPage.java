package com.heb.automation.common.pages.coupons;

import java.util.List;

import com.heb.automation.common.components.CouponsSelected;
import com.heb.automation.common.components.Couponssearchresult;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CouponsselectionTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "couponselection.lbl.allcoupons")
	private QAFWebElement couponselectionLblAllcoupons;
	@FindBy(locator = "couponselection.lbl.pgtitlecoupons")
	private QAFWebElement couponsLblPgtitlecoupons;
	@FindBy(locator = "couponselection.btn.sort")
	private QAFWebElement couponsBtnSort;
	@FindBy(locator = "couponselection.lbl.selectcategory")
	private QAFWebElement couponSelectCategory;
	@FindBy(locator = "couponselection.lbl.available")
	private QAFWebElement couponsLblAvailable;
	@FindBy(locator = "couponselection.lbl.selected")
	private QAFWebElement couponsLblSelected;
	@FindBy(locator = "couponselection.dropdown.selectcatagory")
	private QAFWebElement dropdownSelectcatagory;
	@FindBy(locator = "couponselection.btn.login")
	private QAFWebElement couponsBtnLogin;
	@FindBy(locator = "couponselection.btn.register")
	private QAFWebElement couponsBtnRegister;
	@FindBy(locator = "couponselection.lst.selectcheckbox")
	private List<QAFWebElement> LstSelectcheckbox;
	@FindBy(locator = "couponselection.btn.selectall")
	private QAFWebElement couponsBtnSelectall;
	@FindBy(locator = "couponselection.icon.plus")
	private QAFWebElement couponsIconPlus;
	@FindBy(locator = "couponselection.lbl.addtolist")
	private QAFWebElement couponsLblAddtolist;
	@FindBy(locator = "couponselection.popup.signuporsignin")
	private QAFWebElement couponsPopupSignupOrSignin;
	@FindBy(locator = "couponselection.txt.addtolistnumberpicker")
	private QAFWebElement couponsaddtolistTxtNumberpicker;
	@FindBy(locator = "couponselection.lbl.sortpopupoption")
	private QAFWebElement lblSortpopupSecondoption;
	@FindBy(locator = "couponselection.lbl.sortpopupoption")
	private List<QAFWebElement> lblSortpopupoption;
	@FindBy(locator = "couponselection.lbl.sortcells")
	private List<QAFWebElement> lblSortcells;
	@FindBy(locator = "couponselection.lbl.searchresult")
	private QAFWebElement lblSearchresult;
	@FindBy(locator = "couponselection.lbl.searchresult")
	private List<Couponssearchresult> lblSearchresultlist;
	@FindBy(locator = "couponselection.lbl.searchresult")
	private List<QAFWebElement> lblSearchresultlistiOS;
	@FindBy(locator = "couponselection.lst.itemlist")
	private List<QAFWebElement> lstItemlist;
	@FindBy(locator = "couponselection.lbl.toastmsgcross")
	private QAFWebElement LblToastmsgcross;
	@FindBy(locator = "couponselection.btn.filterApply")
	private QAFWebElement BtnFilterApply;
	@FindBy(locator = "couponselection.lbl.categorytitle")
	private QAFWebElement lblCategorytitle;
	@FindBy(locator = "couponselection.lbl.selectedsavingswhenselected")
	private QAFWebElement lblSelectedsavingswhenselected;
	@FindBy(locator = "couponselection.btn.unselectall")
	private QAFWebElement couponsBtnUnSelectall;

	@FindBy(locator = "couponselection.lst.selectedcoupons")
	private List<CouponsSelected> lstSelectedcoupons;
	@FindBy(locator = "couponselection.lbl.coupondesc")
	private QAFWebElement couponsLblCoupondesc;

	@FindBy(locator = "couponselection.lbl.couponsicon")
	private QAFWebElement couponselectionlblcouponsicon;

	@FindBy(locator = "couponselection.btn.redeem")
	private QAFWebElement couponsBtnRedeem;

	@FindBy(locator = "couponselection.lbl.itemdescwithclipicon")
	private List<QAFWebElement> couponsLblItemWithClip;

	@FindBy(locator = "couponselection.lst.Selectedtabcheckbox")
	private List<QAFWebElement> LstSelectedTabcheckbox;

	@FindBy(locator = "couponselection.lbl.coupondesclist")
	private List<QAFWebElement> couponsListCoupondesc;
	@FindBy(locator = "couponselection.lbl.couponnamelist")
	private List<QAFWebElement> lblCouponnamelist;
	@FindBy(locator = "couponselection.lbl.youmustlogintext")
	private QAFWebElement lblYouMustLoginText;
	@FindBy(locator = "couponselection.lst.Selectedtabselectedcheckbox")
	private List<QAFWebElement> LstSelectedTabSelectedcheckbox;
	@FindBy(locator = "couponselection.lbl.coupondropdown")
	private QAFWebElement couponsLblDropDown;
	@FindBy(locator = "couponselection.lst.couponslistwithclipicon")
	private List<QAFWebElement> lstCouponslistwithclipicon;
	@FindBy(locator = "couponselection.img.couponsclipiconlist")
	private List<QAFWebElement> imgCouponsclipiconlist;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getCouponsLblAvailable() {
		return couponsLblAvailable;
	}

	public QAFWebElement getCouponsLblSelected() {
		return couponsLblSelected;
	}

	public QAFWebElement getCouponsBtnSort() {
		return couponsBtnSort;
	}

	public QAFWebElement getCouponsBtnLogin() {
		return couponsBtnLogin;
	}

	public QAFWebElement getCouponsBtnRegister() {
		return couponsBtnRegister;
	}

	public QAFWebElement getCouponsLblCoupondesc() {
		return couponsLblCoupondesc;
	}

	public QAFWebElement getCouponsLblPgtitlecoupons() {
		return couponsLblPgtitlecoupons;
	}

	public QAFWebElement getCouponsBtnSelectall() {
		return couponsBtnSelectall;
	}

	public QAFWebElement getCouponsIconPlus() {
		return couponsIconPlus;
	}

	public QAFWebElement getCouponSelectCategory() {
		return couponSelectCategory;
	}

	public QAFWebElement getCouponsPopupSignupOrSignin() {
		return couponsPopupSignupOrSignin;
	}

	public List<Couponssearchresult> getCouponsLblSearchresult() {
		return lblSearchresultlist;
	}

	public List<QAFWebElement> getCouponsLblSearchresultlist() {
		return lblSearchresultlistiOS;
	}

	public QAFWebElement getCouponsLblAddtolist() {
		return couponsLblAddtolist;
	}

	public QAFWebElement getCouponsaddtolistTxtNumberpicker() {
		return couponsaddtolistTxtNumberpicker;
	}

	public QAFWebElement getCouponselectionLblAllcoupons() {
		return couponselectionLblAllcoupons;
	}

	public List<QAFWebElement> getLblSortpopupoption() {
		return lblSortpopupoption;
	}

	public QAFWebElement getLblSortpopupSecondoption() {
		return lblSortpopupSecondoption;
	}

	public List<QAFWebElement> getLblSortcells() {
		return lblSortcells;
	}

	public QAFWebElement getLblSearchresult() {
		return lblSearchresult;
	}

	public List<QAFWebElement> getLstItemlist() {
		return lstItemlist;
	}

	public List<QAFWebElement> getLstSelectcheckbox() {
		return LstSelectcheckbox;
	}

	public QAFWebElement getBtnFilterApply() {
		return BtnFilterApply;
	}

	public QAFWebElement getLblToastmsgcross() {
		return LblToastmsgcross;
	}

	public QAFWebElement getLblCategorytitle() {
		return lblCategorytitle;
	}

	public QAFWebElement getLblSelectedsavingswhenselected() {
		return lblSelectedsavingswhenselected;
	}

	public QAFWebElement getDropdownSelectcatagory() {
		return dropdownSelectcatagory;
	}

	public QAFWebElement getCouponsBtnUnSelectall() {
		return couponsBtnUnSelectall;
	}

	public List<CouponsSelected> getLstSelectedcoupons() {
		return lstSelectedcoupons;
	}

	public QAFWebElement getCouponselectionlblcouponsicon() {
		return couponselectionlblcouponsicon;
	}

	public QAFWebElement getCouponsBtnRedeem() {
		return couponsBtnRedeem;
	}

	public List<QAFWebElement> getCouponsLblItemWithClip() {
		return couponsLblItemWithClip;
	}

	public List<QAFWebElement> getLstSelectedTabcheckbox() {
		return LstSelectedTabcheckbox;
	}

	public List<QAFWebElement> getCouponsListCoupondesc() {
		return couponsListCoupondesc;
	}

	public List<QAFWebElement> getLblCouponnamelist() {
		return lblCouponnamelist;
	}

	public QAFWebElement getLblYouMustLoginText() {
		return lblYouMustLoginText;
	}

	public List<QAFWebElement> getLstSelectedTabSelectedcheckbox() {
		return LstSelectedTabSelectedcheckbox;
	}

	public QAFWebElement getCouponsLblDropDown() {
		return couponsLblDropDown;
	}

	public List<QAFWebElement> getLstCouponslistwithclipicon() {
		return lstCouponslistwithclipicon;
	}

	public List<QAFWebElement> getImgCouponsclipiconlist() {
		return imgCouponsclipiconlist;
	}
}
