package com.heb.automation.common.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ShoppinglistSearchResult extends QAFWebComponent{

	public ShoppinglistSearchResult(String locator) {
		super(locator);
	}
	
	@FindBy(locator = "wgsr.lbl.searchresult.itemname")
	private QAFWebElement wgLblSearchresultItemname;
	
	@FindBy(locator = "wgsr.lbl.searchresult.itemimage")
	private QAFWebElement wgLblSearchresultItemimage;
	
	public QAFWebElement getWgLblSearchresultItemname() {
		return wgLblSearchresultItemname;
	}
	
	public QAFWebElement getWgLblSearchresultItemimage() {
		return wgLblSearchresultItemimage;
	}

}
