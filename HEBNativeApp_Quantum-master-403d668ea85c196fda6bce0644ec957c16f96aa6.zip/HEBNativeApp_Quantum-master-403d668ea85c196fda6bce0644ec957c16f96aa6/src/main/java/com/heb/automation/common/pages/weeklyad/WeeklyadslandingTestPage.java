package com.heb.automation.common.pages.weeklyad;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class WeeklyadslandingTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "weeklyadlanding.lbl.displaystorename")
	private QAFWebElement weeklyadLblDisplaystorename;
	@FindBy(locator = "weeklyadlanding.btn.viewanotherstore")
	private QAFWebElement weeklyadBtnViewanotherstore;
	@FindBy(locator = "weeklyadlanding.btn.catagorydropdown")
	private QAFWebElement weeklyadBtnCatagorydropdown;
	@FindBy(locator = "weeklyadlanding.btn.searchdeals")
	private QAFWebElement weeklyadBtnSearchdeals;
	@FindBy(locator = "weeklyadlanding.btn.selectall")
	private QAFWebElement weeklyadBtnSelectall;
	@FindBy(locator = "weeklyadlanding.btn.addbutton")
	private QAFWebElement weeklyadBtnAddbutton;
	@FindBy(locator = "weeklyadlanding.txt.entersearch")
	private QAFWebElement weeklyadTxtEntersearch;
	@FindBy(locator = "weeklyadlanding.btn.collapsetextsearch")
	private QAFWebElement weeklyadBtnCollapsetextsearch;
	@FindBy(locator = "weeklyadlanding.lbl.pagetitle")
	private QAFWebElement LandingPageTitle;
	@FindBy(locator = "weeklyadlanding.txt.popupmsg")
	private QAFWebElement weeklyadTxtPopupmsg;
	@FindBy(locator = "weeklyadlanding.btn.allow")
	private QAFWebElement weeklyadBtnAllow;
	@FindBy(locator = "weeklyadlanding.btn.dontallow")
	private QAFWebElement weeklyadBtnDontallow;
	@FindBy(locator = "weeklyadlanding.lbl.pagetitle")
	private QAFWebElement weeklyadLblPageTitle;
	@FindBy(locator = "weeklyadlanding.popup.titleweeklyaderror")
	private QAFWebElement weeklyadPopupTitleWeeklyaderror;
	@FindBy(locator = "weeklyadlanding.popup.okbtnweeklyaderror")
	private QAFWebElement weeklyadPopupOkBtnWeeklyaderror;
	@FindBy(locator = "weeklyadlanding.lbl.adname")
	private List<QAFWebElement> LblAdname;
	@FindBy(locator = "weeklyadlanding.img.adimage")
	private QAFWebElement ImgAdimage;
	@FindBy(locator = "weeklyadlanding.chk.checkbok")
	private QAFWebElement ChkCheckbok;
	@FindBy(locator = "weeklyadlanding.lbl.productdate")
	private QAFWebElement LblProductdate;
	@FindBy(locator = "weeklyadlanding.lbl.productdescription")
	private QAFWebElement LblProductdescription;
	@FindBy(locator = "weeklyadlanding.lbl.dealstitle")
	private QAFWebElement LblDealstitle;
	@FindBy(locator = "weeklyadlanding.img.plus")
	private QAFWebElement ImgPlus;	
	@FindBy(locator = "weeklyadlanding.lbl.popcontent")
	private QAFWebElement LblPopcontent;
	@FindBy(locator = "weeklyadlanding.btn.closebutton")
	private QAFWebElement BtnClosebutton;
	@FindBy(locator = "weeklyadlanding.lbl.searchcontent")
	private QAFWebElement LblSearchcontent;

	@FindBy(locator = "weeklyadlanding.lbl.unselectall")
	private QAFWebElement LblUnselectall;
	
	@FindBy(locator = "weeklyadlanding.btn.addtolist")
	private QAFWebElement btnAddtolist;
	@FindBy(locator = "weeklyadlanding.lbl.pagetitle")
	private QAFWebElement lblPagetitle;
	@FindBy(locator = "weeklyadlanding.lbl.categorycount")
	private QAFWebElement lblCategoryCount;
	@FindBy(locator = "weeklyadlanding.lbl.categoryname")
	private List<QAFWebElement> lblCategoryName;
	@FindBy(locator = "weeklyadlanding.lbl.categoryitemcount")
	private List<QAFWebElement> lblCategoryItemCount;
	
	@FindBy(locator = "weeklyadlanding.btn.cancel")
	private QAFWebElement btnCancel;
	@FindBy(locator = "weeklyadlanding.btn.ADD")
	private QAFWebElement btnADD;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getWeeklyadLblDisplaystorename() {
		return weeklyadLblDisplaystorename;
	}


	public QAFWebElement getWeeklyadBtnViewanotherstore() {
		return weeklyadBtnViewanotherstore;
	}

	public QAFWebElement getWeeklyadBtnCatagorydropdown() {
		return weeklyadBtnCatagorydropdown;
	}

	public QAFWebElement getWeeklyadBtnSearchdeals() {
		return weeklyadBtnSearchdeals;
	}

	public QAFWebElement getWeeklyadBtnSelectall() {
		return weeklyadBtnSelectall;
	}

	public QAFWebElement getWeeklyadBtnAddbutton() {
		return weeklyadBtnAddbutton;
	}

	public QAFWebElement getWeeklyadTxtEntersearch() {
		return weeklyadTxtEntersearch;
	}

	public QAFWebElement getWeeklyadBtnCollapsetextsearch() {
		return weeklyadBtnCollapsetextsearch;
	}

	public QAFWebElement getLandingPageTitle() {
		return LandingPageTitle;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getWeeklyadTxtPopupmsg() {
		return weeklyadTxtPopupmsg;
	}

	public QAFWebElement getWeeklyadBtnAllow() {
		return weeklyadBtnAllow;
	}

	public QAFWebElement getWeeklyadBtnDontallow() {
		return weeklyadBtnDontallow;
	}

	public QAFWebElement getWeeklyadLblPageTitle() {
		return weeklyadLblPageTitle;
	}

	public QAFWebElement getWeeklyadPopupTitleWeeklyaderror() {
		return weeklyadPopupTitleWeeklyaderror;
	}

	public QAFWebElement getWeeklyadPopupOkBtnWeeklyaderror() {
		return weeklyadPopupOkBtnWeeklyaderror;
	}
	public List<QAFWebElement> getLblAdname() {
		return LblAdname;
	}

	public QAFWebElement getImgAdimage() {
		return ImgAdimage;
	}

	public QAFWebElement getChkCheckbok() {
		return ChkCheckbok;
	}

	public QAFWebElement getLblProductdate() {
		return LblProductdate;
	}

	public QAFWebElement getLblProductdescription() {
		return LblProductdescription;
	}
	
	public QAFWebElement getLblDealstitle() {
		return LblDealstitle;
	}
	
	public QAFWebElement getImgPlus() {
		return ImgPlus;
	}

	public QAFWebElement getLblPopcontent() {
		return LblPopcontent;
	}
	
	public QAFWebElement getLblUnselectall() {
		return LblUnselectall;
	}

	public QAFWebElement getBtnClosebutton() {
		return BtnClosebutton;
	}
	
	public QAFWebElement getLblSearchcontent() {
		return LblSearchcontent;
	}

	public QAFWebElement getBtnAddtolist() {
		return btnAddtolist;
	}

	public QAFWebElement getLblPagetitle() {
		return lblPagetitle;
	}
	
	// DYNAMIC value declaring
	public QAFWebElement getLblCategoryCount(String lable) {
		String loc = String.format(pageProps.getString("weeklyadlanding.lbl.categorycount"), lable);
		return new QAFExtendedWebElement(loc);
	}
	public List<QAFWebElement> getLblCategoryName() {
		return lblCategoryName;
	}
	
	public List<QAFWebElement> getLblCategoryItemCount() {
		return lblCategoryItemCount;
	}
	
	public QAFWebElement getBtnCancel() {
		return btnCancel;
	}
	
	public QAFWebElement getBtnADD() {
		return btnADD;
	}
	
	public QAFWebElement getSubCategoryCount(String lable) {
		String loc = String.format(pageProps.getString("weeklyadlanding.lbl.subcategorycount"), lable);
		return new QAFExtendedWebElement(loc);
	}
}
