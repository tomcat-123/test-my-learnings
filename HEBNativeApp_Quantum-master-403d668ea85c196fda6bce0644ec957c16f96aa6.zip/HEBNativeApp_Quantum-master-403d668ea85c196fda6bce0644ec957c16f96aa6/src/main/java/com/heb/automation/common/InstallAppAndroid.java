package com.heb.automation.common;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;

public class InstallAppAndroid {

	@Parameters({ "deviceName_", "repository_url", "application_name", "user", "password", "app_instrument",
			"sensor_instrument" })
	@Test
	public static void InstallApp_Android(String deviceName_, String repository_url, String application_name,
			String user, String password, String app_instrument, String sensor_instrument) throws IOException {
		System.out.println("Run started");

		DesiredCapabilities capabilities = new DesiredCapabilities("", "", Platform.ANY);
		String host = "heb.perfectomobile.com";

		capabilities.setCapability("user", user);
		capabilities.setCapability("password", password);
		capabilities.setCapability("deviceName", deviceName_);
		PerfectoUtils.setExecutionIdCapability(capabilities, host);

		AndroidDriver<WebElement> driver = new AndroidDriver<WebElement>(
				new URL("https://" + host + "/nexperience/perfectomobile/wd/hub"), capabilities);
		
		System.out.println("Device launched using "+ user);
		
		installApp(driver, repository_url, app_instrument, sensor_instrument);
		openApp(driver, application_name);
		driver.quit();
	}

	@Parameters({ "application_name" })
	public
	static void openApp(AndroidDriver<WebElement> driver, String application_name) {

		Map<String, Object> params1 = new HashMap<>();
		params1.put("name", application_name);
		Object result1 = driver.executeScript("mobile:application:open", params1);
		System.out.println("Application Launched");
	}

	@Parameters({ "repository_url", "app_instrument", "sensor_instrument" })
	public
	static void installApp(AndroidDriver<WebElement> driver, String repository_url, String app_instrument,
			String sensor_instrument) {
		System.out.println("Installing the application");

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("file", repository_url);

		params.put("instrument", app_instrument);
		params.put("sensorInstrument", sensor_instrument);

		String resultStr = (String) driver.executeScript("mobile:application:install", params);
		System.out.println("Install completed");

	}

	public static void InstallApp_AndroidWithoutDriverQuit(String deviceName_, String repository_url,
			String application_name, String user, String password, String app_instrument, String cam_instrument)
			throws IOException {
		System.out.println("Run started");

		DesiredCapabilities capabilities = new DesiredCapabilities("", "", Platform.ANY);
		String host = "heb.perfectomobile.com";

		capabilities.setCapability("user", user);
		capabilities.setCapability("password", password);
		capabilities.setCapability("deviceName", deviceName_);
		PerfectoUtils.setExecutionIdCapability(capabilities, host);

		AndroidDriver<WebElement> driver = new AndroidDriver<WebElement>(
				new URL("https://" + host + "/nexperience/perfectomobile/wd/hub"), capabilities);
		installApp(driver, repository_url, app_instrument, cam_instrument);
		driver.quit();
	}

	public void uninstallApp(AndroidDriver<WebElement> driver, String application_name) {
		System.out.println("Un-Installing the application");

		Map<String, Object> params = new HashMap<>();
		params.put("name", application_name);
		Object result1 = driver.executeScript("mobile:application:uninstall", params);

		System.out.println("Un-Install completed");

	}
}
