package com.heb.automation.common.pages.products;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ProductsearchresultTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "prodsearchresult.txt.pagetitle")
	private QAFWebElement prodsearchresultTxtPagetitle;
	@FindBy(locator = "prodsearchresult.txt.productsearchmenuitem")
	private QAFWebElement prodsearchresultTxtProductsearchmenuitem;
	@FindBy(locator = "prodsearchresult.txt.filtericon")
	private QAFWebElement prodsearchresultTxtFiltericon;
	@FindBy(locator = "prodsearchresult.img.addtocrticon")
	private QAFWebElement prodsearchresultImgAddtocrticon;
	@FindBy(locator = "prodsearchresult.txt.onlineproductscount")
	private QAFWebElement prodsearchresultTxtOnlineproductscount;
	@FindBy(locator = "prodsearchresult.txt.onlineproductslabel")
	private QAFWebElement prodsearchresultTxtOnlineproductslabel;
	@FindBy(locator = "prodsearchresult.txt.mystoreproductscount")
	private QAFWebElement prodsearchresultTxtMystoreproductscount;
	@FindBy(locator = "prodsearchresult.txt.allproductscount")
	private QAFWebElement prodsearchresultTxtAllproductscount;
	@FindBy(locator = "prodsearchresult.txt.allproductslabel")
	private QAFWebElement prodsearchresultTxtAllproductslabel;
	@FindBy(locator = "prodsearchresult.txt.mystoreproductslabel")
	private QAFWebElement prodsearchresultTxtMystoreproductslabel;
	@FindBy(locator = "prodsearchresult.btn.addtolist")
	private QAFWebElement prodsearchresultBtnAddtolist;
	@FindBy(locator = "productresult.lbl.pagename")
	private QAFWebElement productresultLblPagename;
	@FindBy(locator = "prodsearchresult.lbl.maincontent")
	private QAFWebElement prodsearchresultLblMaincontent;
	@FindBy(locator = "prodsearchresult.lbl.selectedproduct")
	private QAFWebElement prodsearchresultLblSelectedproduct;
	@FindBy(locator = "prodsearchresult.btn.map")
	private QAFWebElement BtnMap;

	@FindBy(locator = "prodsearchresult.txt.searchbox")
	private QAFWebElement txtSearchbox;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	
	public QAFWebElement getProdsearchresultTxtPagetitle() {
		return prodsearchresultTxtPagetitle;
	}

	public QAFWebElement getProdsearchresultTxtProductsearchmenuitem() {
		return prodsearchresultTxtProductsearchmenuitem;
	}

	public QAFWebElement getProdsearchresultTxtFiltericon() {
		return prodsearchresultTxtFiltericon;
	}

	public QAFWebElement getProdsearchresultImgAddtocrticon() {
		return prodsearchresultImgAddtocrticon;
	}

	public QAFWebElement getProdsearchresultTxtOnlineproductscount() {
		return prodsearchresultTxtOnlineproductscount;
	}

	public QAFWebElement getProdsearchresultTxtOnlineproductslabel() {
		return prodsearchresultTxtOnlineproductslabel;
	}

	public QAFWebElement getProdsearchresultTxtMystoreproductscount() {
		return prodsearchresultTxtMystoreproductscount;
	}

	public QAFWebElement getProdsearchresultTxtAllproductscount() {
		return prodsearchresultTxtAllproductscount;
	}

	public QAFWebElement getProdsearchresultTxtAllproductslabel() {
		return prodsearchresultTxtAllproductslabel;
	}

	public QAFWebElement getProdsearchresultTxtMystoreproductslabel() {
		return prodsearchresultTxtMystoreproductslabel;
	}

	public QAFWebElement getProdsearchresultBtnAddtolist() {
		return prodsearchresultBtnAddtolist;
	}

	public QAFWebElement getProductresultLblPagename() {
		return productresultLblPagename;
	}

	public QAFWebElement getProdsearchresultLblMaincontent() {
		return prodsearchresultLblMaincontent;
	}

	public QAFWebElement getProdsearchresultLblSelectedproduct() {
		return prodsearchresultLblSelectedproduct;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
	
	
	public QAFWebElement getBtnMap() {
		return BtnMap;
	}

	public QAFWebElement getTxtSearchbox() {
		return txtSearchbox;
	}

}
