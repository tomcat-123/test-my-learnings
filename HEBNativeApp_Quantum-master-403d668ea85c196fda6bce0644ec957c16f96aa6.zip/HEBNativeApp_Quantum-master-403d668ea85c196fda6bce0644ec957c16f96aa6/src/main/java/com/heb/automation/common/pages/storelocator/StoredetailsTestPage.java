package com.heb.automation.common.pages.storelocator;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class StoredetailsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "storedetails.btn.setasyourstore")
	private QAFWebElement storedetailsSetasyourstore;
	@FindBy(locator = "storedetails.lnk.getdirections")
	private QAFWebElement storedetailsGetdirections;
	@FindBy(locator = "storedetails.lnk.viewweeklyad")
	private QAFWebElement storedetailsViewweeklyad;
	@FindBy(locator = "storedetails.lnk.viewstorename")
	private QAFWebElement storedetailsViewstorename;
	@FindBy(locator = "storedetails.lnk.viewphonenumber")
	private QAFWebElement storedetailsViewphonenumber;
	@FindBy(locator = "storedetails.lnk.viewstoreaddress")
	private QAFWebElement storedetailsViewstoreaddress;
	@FindBy(locator = "storedetails.lnk.viewstorecitystatezip")
	private QAFWebElement storedetailsViewstorecitystatezip;
	@FindBy(locator = "storedetails.lbl.hotuseroption")
	private QAFWebElement storedetailsHotuseroption;
	@FindBy(locator = "storedetails.lbl.pharmacy")
	private QAFWebElement storedetailslblpharmacy;
	@FindBy(locator = "storedetails.lbl.cancel")
	private QAFWebElement storedetailsLblCancel;
	@FindBy(locator = "storedetails.lbl.alerttitle")
	private QAFWebElement storeldetailsLblAlerttitle;
	@FindBy(locator = "storedetails.lbl.seestore")
	private QAFWebElement storeldetailsLblSeestore;
	@FindBy(locator = "storedetails.storefeature.lbl.pgtitle")
	private QAFWebElement storeldetailsLblPgtitlestorefeature;
	@FindBy(locator = "storedetails.lbl.alertmessage")
	private QAFWebElement storeldetailsLblAlertmessage;
	@FindBy(locator = "storedetails.lbl.hotuserphoneno")
	private QAFWebElement storeldetailsLblHotuserphoneno;
	@FindBy(locator = "storedetails.lnk.pharmacyphonenumber")
	private QAFWebElement storedetailsLnkPharmacyphonenumber;
	
	@FindBy(locator = "storedetails.lbl.popupstoreupdaterrortitle")
	private QAFWebElement lblPopupstoreupdaterrortitle;
	@FindBy(locator = "storedetails.lbl.popupstoreupdaterrormsg")
	private QAFWebElement lblPopupstoreupdaterrormsg;
	@FindBy(locator = "storedetails.btn.popupstoreupdaterrorok")
	private QAFWebElement btnPopupstoreupdaterrorok;
	@FindBy(locator = "storedetails.lnk.viewstorename1")
	private QAFWebElement lnkViewStoreName1;
	@FindBy(locator = "storedetails.lbl.featuredeals")
	private List<QAFWebElement> lblFeaturedeals;
	@FindBy(locator = "storedetails.btn.changestore")
	private QAFWebElement btnChangestore;	
	@FindBy(locator = "storedetails.lbl.changestore")
	private QAFWebElement lblchangestore;
	@FindBy(locator = "storedetails.lbl.weeklyad")
	private QAFWebElement lblweeklyad;
	@FindBy(locator = "storedetails.lbl.storefeatures")
	private QAFWebElement lblstorefeatures;
	
	@FindBy(locator = "storedetails.btn.myhebstore")
	private QAFWebElement btnmyhebstore;
	@FindBy(locator = "storedetails.btn.chnagestore")
	private QAFWebElement btnChnageStore;
	
	
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getStoredetailsSetasyourstore() {
		return storedetailsSetasyourstore;
	}

	public QAFWebElement getStoredetailsGetdirections() {
		return storedetailsGetdirections;
	}

	public QAFWebElement getStoredetailsViewweeklyad() {
		return storedetailsViewweeklyad;
	}

	public QAFWebElement getStoredetailsViewstorename() {
		return storedetailsViewstorename;
	}

	public QAFWebElement getStoredetailsViewphonenumber() {
		return storedetailsViewphonenumber;
	}

	public QAFWebElement getStoredetailsViewstoreaddress() {
		return storedetailsViewstoreaddress;
	}

	public QAFWebElement getStoredetailsViewstorecitystatezip() {
		return storedetailsViewstorecitystatezip;
	}

	public QAFWebElement getStoredetailsHotuseroption() {
		return storedetailsHotuseroption;
	}

	public QAFWebElement getStoredetailsLblCancel() {
		return storedetailsLblCancel;
	}

	public QAFWebElement getStoreldetailsLblAlerttitle() {
		return storeldetailsLblAlerttitle;
	}

	public QAFWebElement getStoreldetailsLblSeestore() {
		return storeldetailsLblSeestore;
	}

	public QAFWebElement getStoreldetailsLblPgtitlestorefeature() {
		return storeldetailsLblPgtitlestorefeature;
	}

	public QAFWebElement getStoreldetailsLblAlertmessage() {
		return storeldetailsLblAlertmessage;
	}

	public QAFWebElement getStoreDetailsLblPharmacy() {
		return storedetailslblpharmacy;
	}

	public QAFWebElement getstoredetailsLblCancel() {
		return storedetailsLblCancel;
	}

	public QAFWebElement getStoreldetailsLblHotuserphoneno() {
		return storeldetailsLblHotuserphoneno;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
	
	public QAFWebElement getStoredetailsLnkPharmacyphonenumber() {
		return storedetailsLnkPharmacyphonenumber;
	}
	
	public QAFWebElement getLblPopupstoreupdaterrortitle() {
		return lblPopupstoreupdaterrortitle;
	}

	public QAFWebElement getLblPopupstoreupdaterrormsg() {
		return lblPopupstoreupdaterrormsg;
	}

	public QAFWebElement getBtnPopupstoreupdaterrorok() {
		return btnPopupstoreupdaterrorok;
	}

	public QAFWebElement getlnkViewStoreName1() {
		return lnkViewStoreName1;
	}
	
	public List<QAFWebElement> getLblFeaturedeals() {
		return lblFeaturedeals;
	}

	public QAFWebElement getBtnChangestore() {
		return btnChangestore;
	}
	
	public QAFWebElement getlblchangestore() {
		return lblchangestore;
	}
	
	public QAFWebElement getlblweeklyad() {
		return lblweeklyad;
	}
	
	public QAFWebElement getlblstorefeatures() {
		return lblstorefeatures;
	}

	public QAFWebElement getbtnmyhebstore() {
		return btnmyhebstore;
	}

	public QAFWebElement getbtnChnageStore() {
		return btnChnageStore;
	}

	

}
