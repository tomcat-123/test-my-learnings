package com.heb.automation.common.pages.storelocator;

import java.util.List;

import com.heb.automation.common.components.StoreResult;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class StorelistviewresultTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "storeloclistview.lbl.storeresults")
	private List<StoreResult> storelocatorLblStoreresults;
	@FindBy(locator = "storeloclistview.lbl.storeresults")
	private StoreResult Storeresult1;
	@FindBy(locator = "storeloclistview.lbl.storenamelist")
	private List<QAFWebElement> storelocatorLblStorenamelist;
	@FindBy(locator = "storeloclistview.lbl.storeaddressdynamic")
	private QAFWebElement storelocatorLblStoreaddressdynamic;
	@FindBy(locator = "storeloclistview.lbl.storenamedynamic")
	private QAFWebElement storelocatorLblStorenamedynamic;
	@FindBy(locator = "storeloclistview.img.fuel")
	private List<QAFWebElement> storeloclistviewImgFuel;
	@FindBy(locator = "storeloclistview.img.carwash")
	private List<QAFWebElement> storeloclistviewImgCarwash;
	@FindBy(locator = "storeloclistview.lbl.curbsidestore")
	private QAFWebElement storeloclistviewlblcurbsidestore;
	
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public List<StoreResult> getStorelocatorLblStoreresults() {
		return storelocatorLblStoreresults;
	}

	public StoreResult getStoreresult() {
		return Storeresult1;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public List<QAFWebElement> getStorelocatorLblStorenamelist() {
		return storelocatorLblStorenamelist;
	}

	// DYNAMIC value declaring to get exact name
	public QAFWebElement getStorenameEntryByLable(int lable) {
		String loc = String.format(pageProps.getString("storeloclistview.lbl.storenamedynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}

	// DYNAMIC value declaring to get exact address
	public QAFWebElement getStoreaddressEntryByLable(int lable) {
		String loc = String.format(pageProps.getString("storeloclistview.lbl.storeaddressdynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getStoreresultEntryByLable(int lable) {
		String loc = String.format(pageProps.getString("storeloclistview.lbl.storeresults"), lable);
		return new QAFExtendedWebElement(loc);
	}
	
	public List<QAFWebElement> getStoreloclistviewImgFuel() {
		return storeloclistviewImgFuel;
	}
	
	public List<QAFWebElement> getStoreloclistviewImgCarwash() {
		return storeloclistviewImgCarwash;
	}

	public QAFWebElement getstoreloclistviewlblcurbsidestore() {
		return storeloclistviewlblcurbsidestore;
	}

}
