package com.heb.automation.common.pages.shoppinglist;

import java.util.List;
import com.heb.automation.common.components.ShoppinglistResult;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class WeeklygroceriesTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "wg.txt.searchproducts")
	private QAFWebElement wgTxtSearchproducts;
	@FindBy(locator = "wg.img.menuoverflow")
	private QAFWebElement wgImgMenuoverflow;
	@FindBy(locator = "wg.txt.shoppingitemcount")
	private QAFWebElement wgTxtShoppingitemcount;
	@FindBy(locator = "wg.chk.shoppingitem")
	private QAFWebElement wgChkShoppingitem;
	@FindBy(locator = "wg.txt.shoppinglistquantity")
	private QAFWebElement wgTxtShoppinglistquantity;
	@FindBy(locator = "wg.btn.plusaction")
	private QAFWebElement wgBtnPlusaction;
	@FindBy(locator = "wg.list.itemname")
	private QAFWebElement wgListItemname;
	@FindBy(locator = "wg.list.selectsspecificitem")
	private QAFWebElement wgListSelectsspecificitem;
	@FindBy(locator = "wg.txt.checkoffcount")
	private QAFWebElement wgTxtCheckoffcount;
	@FindBy(locator = "wg.chk.shoppingitem")
	private List<QAFWebElement> wgChkShoppingitemList;
	@FindBy(locator = "wg.list.itemlist")
	private List<ShoppinglistResult> wgListItemlist;
	@FindBy(locator = "wg.txt.itemname1")
	private QAFWebElement wgTxtItemname1;
	@FindBy(locator = "wg.btn.login")
	private QAFWebElement wgBtnLogIn;
	@FindBy(locator = "wg.btn.search")
	private QAFWebElement wgbtnsearch;
	@FindBy(locator = "wg.txt.checkedoff")
	private QAFWebElement wgtxtcheckedoff;
	@FindBy(locator = "wg.btn.edit")
	private QAFWebElement wgbtnedit;
	@FindBy(locator = "wg.chk.chkBoxWithRespectToItem")
	private QAFWebElement wgChkChkBoxWithRespectToItem;
	@FindBy(locator = "wg.btn.more")
	private QAFWebElement btnMore;
	@FindBy(locator = "wg.lbl.pagetitle")
	private QAFWebElement lblPagetitle;
	@FindBy(locator = "wg.scanreceipt.lbl.errorpopuptitle")
	private QAFWebElement lblScanReceipterrorpopuptitle;
	@FindBy(locator = "wg.list.recipename")
	private List<QAFWebElement> listRecipename;
	@FindBy(locator = "wg.list.scanproductname")
	private List<QAFWebElement> ListScanproductname;
	@FindBy(locator = "wg.btn.rightarrow")
	private List<QAFWebElement> btnRightarrow ;
	@FindBy(locator = "wg.li.itemnameslist")
	private List<QAFWebElement> liItemnameslist;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getWgTxtSearchproducts() {
		return wgTxtSearchproducts;
	}

	public QAFWebElement getWgImgMenuoverflow() {
		return wgImgMenuoverflow;
	}

	public QAFWebElement getWgTxtShoppingitemcount() {
		return wgTxtShoppingitemcount;
	}

	public QAFWebElement getWgChkShoppingitem() {
		return wgChkShoppingitem;
	}

	public QAFWebElement getWgTxtShoppinglistquantity() {
		return wgTxtShoppinglistquantity;
	}

	public QAFWebElement getWgBtnPlusaction() {
		return wgBtnPlusaction;
	}

	public QAFWebElement getWgListItemname() {
		return wgListItemname;
	}

	public List<ShoppinglistResult> getWgListItemlist() {
		return wgListItemlist;
	}

	public QAFWebElement getWgListSelectsspecificitem() {
		return wgListSelectsspecificitem;
	}

	public QAFWebElement getWgTxtCheckoffcount() {
		return wgTxtCheckoffcount;
	}

	public List<QAFWebElement> getWgChkShoppingitemList() {
		return wgChkShoppingitemList;
	}

	public QAFWebElement getWgBtnSearch() {
		return wgbtnsearch;
	}

	public QAFWebElement getWgTxtCheckedOff() {
		return wgtxtcheckedoff;
	}

	// DYNAMIC value declaring
	public QAFWebElement getShopingListEntryByLable(String lable) {
		String loc = String.format(pageProps.getString("wg.txt.itemname"), lable);
		return new QAFExtendedWebElement(loc);
	}
	
	// DYNAMIC value declaring
	public QAFWebElement getShopingListitemNameByLable(int lable) {
		String loc = String.format(pageProps.getString("wg.list.itemnamedynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}

	// DYNAMIC value declaring to get the check box
	public QAFWebElement getShopingListItemChkBoxEntryByLable(int lable) {
		String loc = String.format(pageProps.getString("wg.chk.chkBoxWithRespecToItem"), lable);
		return new QAFExtendedWebElement(loc);
	}

	// DYNAMIC value declaring
	public QAFWebElement getShopingListItemChkBoxEntryByLable(String lable) {
		String loc = String.format(pageProps.getString("wg.chk.chkboxwithrespecttotem"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getWgTxtItemname1() {
		return wgTxtItemname1;
	}

	public QAFWebElement getWgBtnLogIn() {
		return wgBtnLogIn;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getWgChkChkBoxWithRespectToItem() {
		return wgChkChkBoxWithRespectToItem;
	}

	public QAFWebElement getLblPagetitle() {
		return lblPagetitle;
	}

	public QAFWebElement getBtnMore() {
		return btnMore;
	}

	public QAFWebElement getLblScanReceipterrorpopuptitle() {
		return lblScanReceipterrorpopuptitle;
	}
	
	public List<QAFWebElement> getListRecipename() {
		return listRecipename;
	}

	public List<QAFWebElement> getListScanproductname() {
		return ListScanproductname;
	}
	
	public List<QAFWebElement> getBtnRightarrow() {
		return btnRightarrow;
	}

	public List<QAFWebElement> getLiItemnameslist() {
		return liItemnameslist;
	}
}
