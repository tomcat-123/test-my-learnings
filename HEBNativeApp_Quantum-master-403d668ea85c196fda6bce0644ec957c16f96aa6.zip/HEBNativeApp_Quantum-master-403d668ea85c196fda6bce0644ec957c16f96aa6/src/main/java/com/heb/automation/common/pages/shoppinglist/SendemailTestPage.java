package com.heb.automation.common.pages.shoppinglist;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SendemailTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "sendemail.lbl.pagetitle")
	private QAFWebElement sendemailLblPagetitle;
	@FindBy(locator = "sendemail.txt.sendername")
	private QAFWebElement sendemailTxtSendername;
	@FindBy(locator = "sendemail.txt.senderemail")
	private QAFWebElement sendemailTxtSenderemail;
	@FindBy(locator = "sendemail.txt.recipientemail")
	private QAFWebElement sendemailTxtRecipientemail;
	@FindBy(locator = "sendemail.btn.sendmecopy")
	private QAFWebElement sendemailBtnSendmecopy;
	@FindBy(locator = "sendemail.btn.send")
	private QAFWebElement sendemailBtnSend;
	@FindBy(locator = "sendemail.btn.cancel")
	private QAFWebElement sendemailBtnCancel;
	@FindBy(locator = "sendemail.btn.submit")
	private QAFWebElement sendemailBtnSubmit;
	
	/*GMail Locator*/
	@FindBy(locator = "sendgmail.edit.to")
	private QAFWebElement editTo;
	@FindBy(locator = "sendgmail.btn.send")
	private QAFWebElement BtnSend;

	public QAFWebElement getSendemailBtnCancel() {
		return sendemailBtnCancel;
	}

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getSendemailLblPagetitle() {
		return sendemailLblPagetitle;
	}

	public QAFWebElement getSendemailTxtSendername() {
		return sendemailTxtSendername;
	}

	public QAFWebElement getSendemailTxtSenderemail() {
		return sendemailTxtSenderemail;
	}

	public QAFWebElement getSendemailTxtRecipientemail() {
		return sendemailTxtRecipientemail;
	}

	public QAFWebElement getSendemailBtnSendmecopy() {
		return sendemailBtnSendmecopy;
	}

	public QAFWebElement getSendemailBtnSend() {
		return sendemailBtnSend;
	}

	public QAFWebElement getSendemailBtnSubmit() {
		return sendemailBtnSubmit;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getEditTo() {
		return editTo;
	}

	public QAFWebElement getBtnSend() {
		return BtnSend;
	}
}
