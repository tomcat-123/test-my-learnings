package com.heb.automation.common.pages;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ContactUsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "contactus.txt.pagetitle")
	private QAFWebElement txtPagetitle;
	@FindBy(locator = "contactus.img.rate")
	private QAFWebElement imgRate;
	@FindBy(locator = "contactus.edt.comments")
	private QAFWebElement edtComments;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}
	
	public QAFWebElement getTxtPagetitle() {
		return txtPagetitle;
	}

	public QAFWebElement getImgRate() {
		return imgRate;
	}

	public QAFWebElement getEdtComments() {
		return edtComments;
	}

}
