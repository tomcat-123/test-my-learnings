package com.heb.automation.common.pages.scanner;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ScannerTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "appscan.btn.addtolist")
	private QAFWebElement appscanBtnAddtolist;
	@FindBy(locator = "appscan.lbl.itemname")
	private QAFWebElement appscanLblItemname;
	@FindBy(locator = "appscan.btn.canceladdtolist")
	private QAFWebElement appscanBtnCanceladdtolist;
	@FindBy(locator = "appscan.btn.scaninsearchbox")
	private QAFWebElement appscanBtnScaninsearchbox;

	@FindBy(locator = "appscan.lbl.norecipesfound")
	private QAFWebElement lblNorecipesfound;
	@FindBy(locator = "appscan.btn.oknorecipesfound")
	private QAFWebElement btnOknorecipesfound;
	@FindBy(locator = "appscan.lbl.productnotfound")
	private QAFWebElement lblProductnotfound;
	@FindBy(locator = "appscan.btn.cancelproductnotfound")
	private QAFWebElement btnCancelproductnotfound;
	@FindBy(locator = "appscan.lbl.errorpopuptitle")
	private QAFWebElement lblErrorpopuptitle;
	@FindBy(locator = "appscan.lbl.errorpopupcontent")
	private QAFWebElement lblErrorpopupcontent;
	@FindBy(locator = "appscan.btn.okbtnerrorpopup")
	private QAFWebElement btnOkbtnerrorpopup;
	@FindBy(locator = "appscan.btn.okproductnotfound")
	private QAFWebElement btnOkproductnotfound;
	
	@FindBy(locator = "appscan.lbl.accesscamerapopuptitle")
	private QAFWebElement lblAccesscamerapopuptitle;
	@FindBy(locator = "appscan.btn.accesscamerapopupok")
	private QAFWebElement btnAccesscamerapopupok;
	
	@FindBy(locator = "appscan.lbl.enablecamerapopuptitle")
	private QAFWebElement lblEnablecamerapopuptitle;

	@FindBy(locator = "appscan.btn.enablecamerapopupok")
	private QAFWebElement btnEnablecamerapopupok;
	
	@FindBy(locator = "appscan.lbl.norecipefoundpopuptitle")
	private QAFWebElement lblNorecipefoundpopuptitle;
	@FindBy(locator = "appscan.btn.norecipefoundpopupok")
	private QAFWebElement btnNorecipefoundpopupok;
	@FindBy(locator = "appscan.lbl.title")
	private QAFWebElement scanlblTitle;
	@FindBy(locator = "appscan.lbl.allowpictures")
	private QAFWebElement scanlblAllowPicture;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getAppscanBtnAddtolist() {
		return appscanBtnAddtolist;
	}
	

	public QAFWebElement getAppscanLblItemname() {
		return appscanLblItemname;
	}

	public QAFWebElement getAppscanBtnCanceladdtolist() {
		return appscanBtnCanceladdtolist;
	}

	public QAFWebElement getAppscanBtnScaninsearchbox() {
		return appscanBtnScaninsearchbox;
	}

	public QAFWebElement getLblNorecipesfound() {
		return lblNorecipesfound;
	}

	public QAFWebElement getBtnOknorecipesfound() {
		return btnOknorecipesfound;
	}

	public QAFWebElement getLblProductnotfound() {
		return lblProductnotfound;
	}

	public QAFWebElement getBtnCancelproductnotfound() {
		return btnCancelproductnotfound;
	}

	public QAFWebElement getLblErrorpopuptitle() {
		return lblErrorpopuptitle;
	}

	public QAFWebElement getLblErrorpopupcontent() {
		return lblErrorpopupcontent;
	}

	public QAFWebElement getBtnOkbtnerrorpopup() {
		return btnOkbtnerrorpopup;
	}

	public QAFWebElement getBtnOkproductnotfound() {
		return btnOkproductnotfound;
	}

	public QAFWebElement getLblAccesscamerapopuptitle() {
		return lblAccesscamerapopuptitle;
	}

	public QAFWebElement getBtnAccesscamerapopupok() {
		return btnAccesscamerapopupok;
	}

	public QAFWebElement getLblEnablecamerapopuptitle() {
		return lblEnablecamerapopuptitle;
	}

	public QAFWebElement getBtnEnablecamerapopupok() {
		return btnEnablecamerapopupok;
	}

	public QAFWebElement getLblNorecipefoundpopuptitle() {
		return lblNorecipefoundpopuptitle;
	}

	public QAFWebElement getBtnNorecipefoundpopupok() {
		return btnNorecipefoundpopupok;
	}
	
	public QAFWebElement getScanlblTitle() {
		return scanlblTitle;
	}
	
	/*public QAFWebElement getlblAllowPicture() {
		return scanlblAllowPicture;
	}*/
}
