package com.heb.automation.android.pages;

import java.util.List;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.ScrollableElement;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class AndroidcommonTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	
	/** 1) App Slider Menu  **/
	
	@FindBy(locator = "app.btn.hamburger")
	private QAFWebElement appHamburger;
	@FindBy(locator = "app.slider.shoppinglist")
	private QAFWebElement appSliderShoppinglist;
	@FindBy(locator = "app.slider.products")
	private QAFWebElement appSliderProducts;
	@FindBy(locator = "app.slider.coupons")
	private QAFWebElement appSliderCoupons;
	@FindBy(locator = "app.slider.weeklyad")
	private QAFWebElement appSliderWeeklyad;
	@FindBy(locator = "app.slider.home")
	private QAFWebElement appSliderHome;
	@FindBy(locator = "app.slider.mobilewallet")
	private QAFWebElement appSliderMobilewallet;
	@FindBy(locator = "app.slider.recipes")
	private QAFWebElement appSliderRecipes;
	@FindBy(locator = "app.slider.pharmacy")
	private QAFWebElement appSliderPharmacy;
	@FindBy(locator = "app.slider.storelocator")
	private QAFWebElement appSliderStorelocator;
	@FindBy(locator = "app.slider.logout")
	private QAFWebElement appSliderLogout;
	@FindBy(locator = "app.slider.settings")
	private QAFWebElement appSliderSettings;
	@FindBy(locator = "app.slider.myaccount")
	private ScrollableElement appSliderMyAccount;
	@FindBy(locator = "app.slider.login")
	private QAFWebElement appSliderLogin;
	@FindBy(locator = "app.slider.whysignup")
	private ScrollableElement appSliderWhysignup;
	@FindBy(locator = "app.slider.register")
	private QAFWebElement appSliderRegister;
	@FindBy(locator = "app.slider.appsettings")
	private QAFWebElement appsliderappsettings;
	@FindBy(locator = "app.slider.donations")
	private QAFWebElement appsliderdonations;
	
	/** Scan Products
	 * 1) Product Page 
	 * 2) Recipe Page
	 * 3) Shopping List
	 *
	 */
	
	@FindBy(locator = "app.btn.scanproducts")
	private QAFWebElement headerBtnScanProducts;
	@FindBy(locator = "appscan.lbl.pagetitle")
	private QAFWebElement scanLblPagetitle;
	@FindBy(locator = "appscan.txt.scanproduct")
	private QAFWebElement scanTxtScanproduct;
	@FindBy(locator = "appscan.btn.enterreceiptnumber")
	private QAFWebElement scanreceiptBtnEnterreceiptnumber;
	@FindBy(locator = "appscan.txt.scanreceipt")
	private QAFWebElement scanTxtScanreceipt;
	@FindBy(locator = "appscan.lbl.scanreceiptcharcount")
	private QAFWebElement scanreceiptLblCharactercount;
	@FindBy(locator = "appscan.popup.lbl.enablecamera")
	private QAFWebElement lblPopupenablecamera;
	
	/** Search Products
	 * 1) Product Page 
	 * 2) Recipe Page
	 * 3) Shopping List Page
	 * 4) Coupons Page
	 * 5) WeeklyAd Page
	 */
	
	@FindBy(locator = "app.txt.searchproducts")
	private QAFWebElement appTxtSearchproducts;
	@FindBy(locator = "app.btn.searchproducts")
	private QAFWebElement appIconSearchproducts;
	@FindBy(locator = "app.btn.collapse")
	private QAFWebElement appBtnCollapse;
	
	/** Add to List
	 * 1) Product Page 
	 * 2) Recipe Page
	 * 3) Shopping List Page
	 * 4) Coupons Page
	 */
	
	@FindBy(locator = "addtolist.lbl.alerttitle")
	private QAFWebElement addtolistLblAlerttitle;
	@FindBy(locator = "addtolist.txt.numberpicker")
	private QAFWebElement addtolistTxtNumberpicker;
	@FindBy(locator = "addtolist.btn.add")
	private QAFWebElement addtolistBtnAdd;
	@FindBy(locator = "addtolist.btn.cancel")
	private QAFWebElement addtolistBtnCancel;
	@FindBy(locator = "addtolist.txt.pickerbottom")
	private QAFWebElement addtolistTxtPickerbottom;
	@FindBy(locator = "addtolist.txt.nextpicker")
	private List<QAFWebElement> addtolistTxtNextpicker;
	@FindBy(locator = "app.btn.nextpicker")
	private QAFWebElement appBtnNextpicker;
	
	/** Store Locator **/
	
	@FindBy(locator = "app.allowpopup.lbl.title")
	private QAFWebElement appPopupAllowPermission;
	@FindBy(locator = "app.allowpopup.btn.allow")
	private QAFWebElement appPopupBtnAllowPermission;
	@FindBy(locator = "app.allowpopup.btn.deny")
	private QAFWebElement appPopupBtnDenyPermission;
	
	
	/** My Account || More Page
	 * 
	 */
	
	@FindBy(locator = "app.lbl.faqsetting")
	private QAFWebElement appsettinglblfaq;
	@FindBy(locator = "app.lbl.faqpagetitle")
	private QAFWebElement appfaqlblpagetitle;
	@FindBy(locator = "app.lbl.privacypolicypagetitle")
	private QAFWebElement appprivacypolicylblpagetitle;
	@FindBy(locator = "app.lbl.termsandconditionspagetitle")
	private QAFWebElement apptermsandconditionslblpagetitle;

	@FindBy(locator = "app.lbl.alert")
	private QAFWebElement lblAlert;
	@FindBy(locator = "app.img.progress")
	private QAFWebElement imgProgress;
	@FindBy(locator = "app.lbl.relogin")
	private QAFWebElement lblRelogin;
	@FindBy(locator = "app.btn.login")
	private QAFWebElement btnLogin;
	@FindBy(locator = "app.rdb.envcert1")
	private QAFWebElement rdbEnvcert1;
	@FindBy(locator = "app.rdb.envcert2")
	private QAFWebElement rdbEnvcert2;
	@FindBy(locator = "appslider.lbl.help")
	private QAFWebElement lblHelp;
	@FindBy(locator = "app.btn.skip")
	private QAFWebElement BtnSkip;
	@FindBy(locator = "app.btn.done")
	private QAFWebElement BtnDone;	
	@FindBy(locator = "app.lbl.webpage")
	private QAFWebElement LblWebpage;

	@FindBy(locator = "appslider.lbl.menulist")
	private List<QAFWebElement> lblAppsliderMenuList;
	@FindBy(locator = "app.slider.redeemcoupons")
	private QAFWebElement appsliderredeemcoupons;
	
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getAppSliderLogout() {
		return appSliderLogout;
	}


	public void logoutApp() {

		if(getAppHamburger().isPresent()){
			getAppHamburger().click();
			PerfectoUtils.verticalswipe();
		try {
			appSliderLogout.waitForPresent(5000);
			appSliderLogout.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	}

	public QAFWebElement getAppSliderSettings() {
		return appSliderSettings;
	}

	public QAFWebElement getAppSliderMyAccount() {
		return appSliderMyAccount;
	}

	public QAFWebElement getAppHamburger() {
		return appHamburger;
	}

	public void openAppHamburger() {

		getAppHamburger().waitForPresent(12000);
		getAppHamburger().click();
		try {
			getAppSliderHome().waitForPresent(5000);
		} catch (Exception e) {
			// Give it another try
			getAppHamburger().click();
		}
	}

	public QAFWebElement getAppSliderShoppinglist() {
		return appSliderShoppinglist;
	}

	public QAFWebElement getAppSliderProducts() {
		return appSliderProducts;
	}

	public QAFWebElement getAppSliderCoupons() {
		return appSliderCoupons;
	}

	public QAFWebElement getAppSliderWeeklyad() {
		return appSliderWeeklyad;
	}

	public QAFWebElement getAppSliderHome() {
		return appSliderHome;
	}

	public QAFWebElement getAppSliderMobilewallet() {
		return appSliderMobilewallet;
	}

	public QAFWebElement getAppSliderRecipes() {
		return appSliderRecipes;
	}

	public QAFWebElement getAppSliderPharmacy() {
		return appSliderPharmacy;
	}

	public QAFWebElement getAppSliderStorelocator() {
		return appSliderStorelocator;
	}

	public QAFWebElement getAppSliderRegister() {
		return appSliderRegister;
	}

	public QAFWebElement getAppSliderLogin() {
		return appSliderLogin;
	}

	public ScrollableElement getAppSliderWhysignup() {
		return appSliderWhysignup;
	}

	public QAFWebElement getScanLblPagetitle() {
		return scanLblPagetitle;
	}

	public QAFWebElement getHeaderBtnScanProducts() {
		return headerBtnScanProducts;
	}

	public QAFWebElement getAppBtnCollapse() {
		return appBtnCollapse;
	}

	public QAFWebElement getScanreceiptBtnEnterreceiptnumber() {
		return scanreceiptBtnEnterreceiptnumber;
	}

	public QAFWebElement getAppTxtSearchproducts() {
		return appTxtSearchproducts;
	}

	public QAFWebElement getAppIconSearchproducts() {
		return appIconSearchproducts;
	}

	public QAFWebElement getAddtolistLblAlerttitle() {
		return addtolistLblAlerttitle;
	}

	public QAFWebElement getAddtolistTxtNumberpicker() {
		return addtolistTxtNumberpicker;
	}

	public QAFWebElement getAddtolistBtnAdd() {
		return addtolistBtnAdd;
	}

	public QAFWebElement getAddtolistBtnCancel() {
		return addtolistBtnCancel;
	}

	public QAFWebElement getScanTxtScanproduct() {
		return scanTxtScanproduct;
	}

	public QAFWebElement getScanTxtScanreceipt() {
		return scanTxtScanreceipt;
	}

	public QAFWebElement getAppPopupAllowPermission() {
		return appPopupAllowPermission;
	}

	public QAFWebElement getAppPopupBtnAllowPermission() {
		return appPopupBtnAllowPermission;
	}

	public QAFWebElement getAppPopupBtnDenyPermission() {
		return appPopupBtnDenyPermission;
	}

	public List<QAFWebElement> getAddtolistTxtNextpicker() {
		return addtolistTxtNextpicker;
	}

	public QAFWebElement getAddtolistTxtPickerbottom() {
		return addtolistTxtPickerbottom;
	}

	public QAFWebElement getScanreceiptLblCharactercount() {
		return scanreceiptLblCharactercount;
	}

	public QAFWebElement getAppSliderAppSettings() {
		return appsliderappsettings;
	}

	public QAFWebElement getAppSettingFaq() {
		return appsettinglblfaq;
	}

	public QAFWebElement getAppFaqTitle() {
		return appfaqlblpagetitle;
	}

	public QAFWebElement getAppPrivacyPolicy() {
		return appprivacypolicylblpagetitle;
	}

	public QAFWebElement getAppTermsAndConditions() {
		return apptermsandconditionslblpagetitle;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getAppBtnNextpicker() {
		return appBtnNextpicker;
	}

	public QAFWebElement getLblAlert() {
		return lblAlert;
	}

	public QAFWebElement getImgProgress() {
		return imgProgress;
	}

	public QAFWebElement getLblPopupenablecamera() {
		return lblPopupenablecamera;
	}

	public QAFWebElement getLblRelogin() {
		return lblRelogin;
	}

	public QAFWebElement getBtnLogin() {
		return btnLogin;
	}

	public QAFWebElement getRdbEnvcert1() {
		return rdbEnvcert1;
	}

	public QAFWebElement getRdbEnvcert2() {
		return rdbEnvcert2;
	}
	
	public QAFWebElement getLblHelp() {
		return lblHelp;
	}
	public QAFWebElement getBtnSkip() {
		return BtnSkip;
	}
	public QAFWebElement getBtnDone() {
		return BtnDone;
	}
	
	public QAFWebElement getLblWebpage() {
		return LblWebpage;
	}
	public List<QAFWebElement> getLblAppsliderMenuList() {
		return lblAppsliderMenuList;
	}

	public QAFWebElement getAppSliderRedeemCoupons() {
		return appsliderredeemcoupons;
	}
	
	public QAFWebElement getAppSliderDonations() {
		return appsliderdonations;
	}
}
