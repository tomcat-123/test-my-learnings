package com.heb.automation.common.steps.cartncheckout;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.cartncheckout.BillingTestPage;
import com.heb.automation.common.pages.cartncheckout.CartTestPage;
import com.heb.automation.common.pages.cartncheckout.CheckoutTestPage;

import com.heb.automation.common.pages.products.ProductdetailTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in Common CartAndCheckout

	I select CHECKOUT
	I enter credit card detail
	I see billing address
	I see order confirmation page by clicking on submit Order
	I click add to cart from PDP page */

public class CommonStepDefcartncheckout {

	@QAFTestStep(description = "I select CHECKOUT")
	public void iSelectCHECKOUT() {
		CartTestPage cartpage = new CartTestPage();

		cartpage.getCartpageBtnCheckout().click();
	
		try {
			AppcrashhandlerTestPage apphandler = new AppcrashhandlerTestPage();
			if(apphandler.getLoginrequiredPopup().isPresent()){
				
				apphandler.getEnterPassword().sendKeys("testing@123");
				apphandler.getSubmitLogincredentials().click();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@QAFTestStep(description = "I enter credit card detail")
	public void iEnterCreditCardDetail() {
		CheckoutTestPage chekoutpage = new CheckoutTestPage();

		chekoutpage.getCheckoutLblPayementtitle().verifyPresent();
		chekoutpage.getCheckoutImgPayementmethod().click();

		String cardholdername = ConfigurationManager.getBundle().getString("carddetails.cardholdername");
		chekoutpage.getCheckoutTxtCardholdername().sendKeys(cardholdername);
		String numeber = ConfigurationManager.getBundle().getString("carddetails.amexcard.numeber");
		chekoutpage.getCheckoutTxtCardnumber().sendKeys(numeber);

		String cvv = ConfigurationManager.getBundle().getString("carddetails.amexcard.cvv");
		chekoutpage.getCheckoutTxtCardcvv().sendKeys(cvv);
		chekoutpage.getCheckoutTxtCardcvv().waitForPresent(5000);
		chekoutpage.getCheckoutTxtCardexp().click();
		chekoutpage.getCheckoutLblExpiryset().waitForPresent(5000);
		PerfectoUtils.verticalswipe();
		chekoutpage.getCheckoutLblExpiryset().click();
		chekoutpage.getCheckoutBtn().click();
	}
/*
	@QAFTestStep(description = "I see billing address")
	public void iSeeBillingAddress() {
		ShippingaddTestPage shippingaddress = new ShippingaddTestPage();
		BillingTestPage billingaddress = new BillingTestPage();

		String email = "";
		shippingaddress.getShippingLblTitlebillingaddress().verifyPresent();
		shippingaddress.getShippingLblEnteredbillingaddress().verifyPresent();
		shippingaddress.getShippingImgBilling().verifyPresent();

		email = ConfigurationManager.getBundle().getString("hotuser1.user.email");
		billingaddress.getBillingLblEmailaddress().sendKeys(email);
		billingaddress.getBillingTxtConfirmemail().sendKeys(email);
		billingaddress.getBillingChkboxSameasshipping().click();
		shippingaddress.getShippingBtnSelect().click();
	}
*/
	@QAFTestStep(description = "I see order confirmation page by clicking on submit Order")
	public void iSeeOrderConfirmationPageByClickingOnSubmitOrder() {
		CheckoutTestPage checkoutpage = new CheckoutTestPage();

		checkoutpage.getCheckoutBtnSubmitorder().waitForPresent(5000);
		checkoutpage.getCheckoutBtnSubmitorder().click();
		checkoutpage.getCheckoutLblTitleconfirmation().verifyPresent();
		checkoutpage.getCheckoutLblThankyou().verifyPresent();
	}

	@QAFTestStep(description = "I click add to cart from PDP page")
	public void iClickAddToCartFromPDPPage() {
		ProductdetailTestPage pdpTestPage = new ProductdetailTestPage();
		CartTestPage cartpage = new CartTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		pdpTestPage.waitForPageToLoad();
		pdpTestPage.getPdpLblProductname().waitForPresent(5000);
		String strProductName = pdpTestPage.getPdpLblProductname().getText();
		getBundle().setProperty("ChoosenProduct", strProductName);
		System.out.println(getBundle().getString("ChoosenProduct"));

		// Clicking add to cart from PDP page
		if (cartpage.getCartpageBtnAddtocart().isPresent()) {
			cartpage.getCartpageBtnAddtocart().click();
			PerfectoUtils.reportMessage("Clicked Add To Cart button", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Add To Cart button is not found", MessageTypes.Fail);
		}
		
		//Error handle
		if(weeklygrocery.getShopingListEntryByLable("Service unavailable").isPresent()){
			PerfectoUtils.reportMessage("Service Unavailable. Product can not add to Cart!!", MessageTypes.Fail);
		}
	}
}
