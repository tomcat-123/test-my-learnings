package com.heb.automation.common.pages.recipes;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RecipeboxTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "recipebox.btn.createanaccount")
	private QAFWebElement myrecipeboxBtnCreateanaccount;
	@FindBy(locator = "recipebox.lbl.saveandorganize")
	private QAFWebElement myrecipeboxLblSaveandorganize;
	@FindBy(locator = "recipebox.img.myrecipebox")
	private QAFWebElement myrecipeboxImgMyrecipebox;
	@FindBy(locator = "recipebox.img.recipes")
	private QAFWebElement myrecipeboxImgRecipes;
	@FindBy(locator = "recipebox.btn.login")
	private QAFWebElement myrecipeboxBtnLogin;
	@FindBy(locator = "recipebox.lbl.addtoboxdefault")
	private QAFWebElement recipeboxDefaultbox;
	@FindBy(locator = "recipebox.btn.addtoboxdone")
	private QAFWebElement recipeboxAddtobox;
	@FindBy(locator = "recipebox.btn.addtoboxcancel")
	private QAFWebElement recipeboxCancel;
	@FindBy(locator = "recipebox.lbl.errortitle")
	private QAFWebElement recipeboxErrorhandler;
	@FindBy(locator = "recipebox.btn.openbox")
	private QAFWebElement recipeboxOpenbox;
	@FindBy(locator = "recipebox.lbl.breakfast")
	private QAFWebElement recipeboxSelectbox;
	@FindBy(locator = "recipebox.btn.addtolist")
	private QAFWebElement recipeboxOptionsAddtolist;
	@FindBy(locator = "recipebox.btn.moverecipe")
	private QAFWebElement recipeboxOptionsMoverecipe;
	@FindBy(locator = "recipebox.btn.deleterecipe")
	private QAFWebElement recipeboxOptionsDeleterecipe;
	@FindBy(locator = "recipebox.btn.popupdelete")
	private QAFWebElement recipeboxDelete;
	@FindBy(locator = "recipebox.lbl.firstrecipename")
	private QAFWebElement recipeboxLblRecipename1;
	@FindBy(locator = "recipebox.lbl.pagetitle")
	private QAFWebElement recipeboxLblPagetitle;
	@FindBy(locator = "recipebox.btn.plusicon")
	private QAFWebElement recipeboxBtnPlusicon;
	@FindBy(locator = "recipebox.lbl.folderpopuptitle")
	private QAFWebElement recipeboxFolderpopupTitle;
	@FindBy(locator = "recipebox.txt.folderpopupfldrname")
	private QAFWebElement recipeboxFolderpopupTxtFoldername;
	@FindBy(locator = "recipebox.btn.folderpopupadd")
	private QAFWebElement recipeboxFolderpopupBtnAdd;
	@FindBy(locator = "recipebox.btn.folderpopupcancel")
	private QAFWebElement recipeboxFolderpopupBtnCancel;
	@FindBy(locator = "recipebox.btn.loginpopupsubmit")
	private QAFWebElement recipeboxbtnloginpopupsubmit;
/*	@FindBy(locator = "recipebox.btn.loginpopupcancel")
	private QAFWebElement recipeboxbtnloginpopupcancel;*/
	@FindBy(locator = "recipebox.btn.loginpopuplogin")
	private QAFWebElement recipeboxbtnloginpopuplogin;
	@FindBy(locator = "recipebox.btn.editfolder")
	private QAFWebElement btnEditfolder;
	@FindBy(locator = "recipebox.lbl.recipenameslist")
	private List<QAFWebElement> lblRecipenameslist;
	@FindBy(locator = "recipebox.txt.renamepopup")
	private QAFWebElement txtRenamepopup;
	@FindBy(locator = "recipebox.btn.done")
	private QAFWebElement btnDone;
	@FindBy(locator = "recipebox.lbl.all")
	private QAFWebElement LblAll;
	@FindBy(locator = "recipebox.lbl.recipeboxlist")
	private QAFWebElement LblRecipeboxlist;
	@FindBy(locator = "recipebox.lbl.allcount")
	private QAFWebElement LblAllCount;
	
	
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getMyrecipeboxBtnCreateanaccount() {
		return myrecipeboxBtnCreateanaccount;
	}

	public QAFWebElement getMyrecipeboxLblSaveandorganize() {
		return myrecipeboxLblSaveandorganize;
	}

	public QAFWebElement getMyrecipeboxImgMyrecipebox() {
		return myrecipeboxImgMyrecipebox;
	}

	public QAFWebElement getMyrecipeboxImgRecipes() {
		return myrecipeboxImgRecipes;
	}

	public QAFWebElement getMyrecipeboxBtnLogin() {
		return myrecipeboxBtnLogin;
	}

	public QAFWebElement getRecipeboxDefaultbox() {
		return recipeboxDefaultbox;
	}

	public QAFWebElement getRecipeboxAddtobox() {
		return recipeboxAddtobox;
	}

	public QAFWebElement getRecipeboxCancel() {
		return recipeboxCancel;
	}

	public QAFWebElement getRecipeboxErrorhandler() {
		return recipeboxErrorhandler;
	}

	public QAFWebElement getRecipeboxOpenbox() {
		return recipeboxOpenbox;
	}

	public QAFWebElement getRecipeboxSelectbox() {
		return recipeboxSelectbox;
	}

	public QAFWebElement getRecipeboxOptionsAddtolist() {
		return recipeboxOptionsAddtolist;
	}

	public QAFWebElement getRecipeboxOptionsMoverecipe() {
		return recipeboxOptionsMoverecipe;
	}

	public QAFWebElement getRecipeboxOptionsDeleterecipe() {
		return recipeboxOptionsDeleterecipe;
	}

	public QAFWebElement getRecipeboxDelete() {
		return recipeboxDelete;
	}

	public QAFWebElement getRecipeboxLblRecipename1() {
		return recipeboxLblRecipename1;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getRecipeboxLblPagetitle() {
		return recipeboxLblPagetitle;
	}

	public QAFWebElement getRecipeboxBtnPlusicon() {
		return recipeboxBtnPlusicon;
	}

	public QAFWebElement getRecipeboxFolderpopupTitle() {
		return recipeboxFolderpopupTitle;
	}

	public QAFWebElement getRecipeboxFolderpopupTxtFoldername() {
		return recipeboxFolderpopupTxtFoldername;
	}

	public QAFWebElement getRecipeboxFolderpopupBtnAdd() {
		return recipeboxFolderpopupBtnAdd;
	}

	public QAFWebElement getRecipeboxFolderpopupBtnCancel() {
		return recipeboxFolderpopupBtnCancel;
	}

	public QAFWebElement getRecipeboxBtnLoginpopupSubmit() {
		return recipeboxbtnloginpopupsubmit;
	}

	/*public QAFWebElement getRecipeboxBtnLoginpopupCancel() {
		return recipeboxbtnloginpopupcancel;
	}*/

	public QAFWebElement getRecipeboxBtnLoginpopupLogin() {
		return recipeboxbtnloginpopuplogin;
	}

	public QAFWebElement getBtnEditfolder() {
		return btnEditfolder;
	}

	public List<QAFWebElement> getLblRecipenameslist() {
		return lblRecipenameslist;
	}

	public QAFWebElement getTxtRenamepopup() {
		return txtRenamepopup;
	}

	// DYNAMIC value declaring
	public QAFWebElement getRecipeboxTxtRenamepopupByLable(String lable) {
		String loc = String.format(pageProps.getString("recipebox.txt.renamepopupdynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}

	// DYNAMIC value declaring
	public QAFWebElement getRecipeboxlist(int lable) {
		String loc = String.format(pageProps.getString("recipebox.lbl.recipeboxlist"), lable);
		return new QAFExtendedWebElement(loc);
	}

	// DYNAMIC value declaring
	public QAFWebElement getRecipeboxnamelist(int lable) {
		String loc = String.format(pageProps.getString("recipebox.lbl.recipedynamicnameslist"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getBtnDone() {
		return btnDone;
	}

	public QAFWebElement getLblAll() {
		return LblAll;
	}

	public QAFWebElement getLblRecipeboxlist() {
		return LblRecipeboxlist;
	}

	public QAFWebElement getLblAllCount() {
		return LblAllCount;
	}
	
}
