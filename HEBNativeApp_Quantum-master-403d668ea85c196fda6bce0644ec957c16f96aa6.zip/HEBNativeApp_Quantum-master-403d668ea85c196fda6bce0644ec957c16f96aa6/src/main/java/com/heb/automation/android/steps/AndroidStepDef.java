package com.heb.automation.android.steps;

import static com.heb.automation.common.PerfectoUtils.getAppiumDriver;
import static com.heb.automation.common.PerfectoUtils.openApplication;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.android.pages.EmailcontentTestPage;
import com.heb.automation.android.steps.myaccount.AndroidStepDefMyaccount;
import com.heb.automation.android.steps.shoppinglist.AndroidStepDefShoppingList;
import com.heb.automation.android.steps.weeklyad.AndroidStepDefWeeklyAds;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.FAQTestPage;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.ShareTestPage;
import com.heb.automation.common.pages.coupons.CouponsdetailsTestPage;
import com.heb.automation.common.pages.coupons.CouponsselectionTestPage;
import com.heb.automation.common.pages.myaccount.HelpmoreTestPage;
import com.heb.automation.common.pages.myaccount.MyaccountTestPage;
import com.heb.automation.common.pages.products.ProductlandingTestPage;
import com.heb.automation.common.pages.products.ProductsearchresultTestPage;
import com.heb.automation.common.pages.products.RefineTestPage;
import com.heb.automation.common.pages.recipes.RecipedetailTestPage;
import com.heb.automation.common.pages.recipes.RecipeslandingTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.pages.scanner.ScannerTestPage;
import com.heb.automation.common.pages.shoppinglist.ListdetailsTestPage;
import com.heb.automation.common.pages.shoppinglist.LoginpopupTestPage;
import com.heb.automation.common.pages.shoppinglist.MylistTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.storelocator.StorelocatorTestPage;
import com.heb.automation.common.pages.weeklyad.WeeklyadslandingTestPage;
import com.heb.automation.common.steps.CommonSteps;
import com.heb.automation.common.steps.productfinder.CommonStepDefProductFinder;
import com.heb.automation.common.steps.registeration.CommonStepDefRegisteration;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in AdriodStepDef

	I am an Cold User
	I navigate to Coupons page
	I am a hot user using {0}{1} credential
	I navigate to shopping list
	I navigate to Weekly ad from homepage
	I am a hot user using {0}{1} with new list added
	I am a cold user with product added in list
	I submit the registeration form
	I see homepage
	I see Registration page on clicking the Register button
	I am on Login splash page
	I delete the newly created list
	I navigate to FAQ
	I validate FAQ page
	I navigate to Privacy Policy
	I validate Privacy Policy page
	I naviagate to Terms & Conditions
	I validate Terms & Conditions page
	I validate logout
	I logout the application
	I select Add to List button
	I validate the error message for invalid product
	I validate the refine filter options
	I validate share page
	I validate email content
	I navigate to email page
	I navigate to social media page
	I validate content of social media
	I click on search field from homepage
	I navigate and scan the receipt from Scan Receipt screen
	I enter valid credentials {0}{1}
	I am logging in as a hot user using {0}{1} credential from guest user
	I should see the Search Products screen
	I verify the added coupons
	I am a hot user for Email update
	I click on Cancel/ device back button
	I navigate to Coupons page from footer
	I click Continue without registering link/Cancel button
	I validate sections in more/help page
	I click Register button from Hamburger or More
	I validate the Orginating page browse
	I should see the Homepage/ More screen
	I navigate and scan the item {0} from scan products screen
	I see home page
	I verify the home hero image
	I verify the top slot
	I verify the sub menu order as cold user
	I verify the sub menu order as hot user with curbside store
	I verify the sub menu order as hot user without curbside store
	I verify the sub menu navigations as hot user
	I verify the sub menu navigations as cold user
	I verify the tool bar as cold user
	I verify the tool bar as hot user
	I verify the app slider as hot user
	I verify the app slider as cold user
	I navigate to home page
	I validate the show password functionality
	I click login button from Hamburger or More
	I am a VPP user using {0}{1} credential
	I navigate to donation page
	Verify donations Second item in the list
	Verify donations first item in the list*/

public class AndroidStepDef {

	/**
	 * Handle Skip, wait for Continue without Register button, if it is not
	 * present, wait for Hamburger. Click the Hamburger and Click on Logout if
	 * it is available. Handle Relogin pop up. And wait for Continue without
	 * Register button and click on it.
	 */
	@QAFTestStep(description = "I am an Cold User")
	public void iAmAnColdUser() {

		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();
		// settingEnvironmentinApp();

		try {
			loginsplash.getLoginLblContinue().waitForPresent(5000);
		} catch (Exception e) {
			try {
				androidfun.getAppHamburger().waitForPresent(5000);
			} catch (Exception e1) {
				handlePopup();
			}

			/**************** Setting Environment before execution ***********/

			if (androidfun.getAppHamburger().isPresent()
					&& ((androidfun.getAppHamburger().getAttribute("hidden")).equals("false"))) {
				PerfectoUtils.reportMessage("User has an Pre-existing session.", MessageTypes.Pass);
				androidfun.getAppHamburger().click();
				PerfectoUtils.verticalswipe();
				if (!androidfun.getAppSliderLogout().isPresent()) {
					PerfectoUtils.verticalswipe();
				}
				androidfun.getAppSliderLogout().waitForPresent(5000);
				androidfun.getAppSliderLogout().click();

			} else if (loginsplash.getLoginLblContinue().isPresent()) {
				PerfectoUtils.reportMessage("User is in Login splash page.", MessageTypes.Pass);
			}
		}

		loginsplash.getLoginLblContinue().waitForPresent(10000);
		loginsplash.getLoginLblContinue().click();
		PerfectoUtils.reportMessage("Logged in as a cold user.", MessageTypes.Pass);
	}

	/**
	 * Verify Hamburger icon and click on it, Verify Coupons and click on it. If
	 * Coupons slider is present, Skip it.
	 */
	@QAFTestStep(description = "I navigate to Coupons page")
	public static void iNavigateToCouponsPage() {
		CouponsselectionTestPage obj = new CouponsselectionTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();

		androidcommon.getAppHamburger().verifyPresent();
		androidcommon.getAppHamburger().click();

		androidcommon.getAppSliderCoupons().verifyPresent();
		androidcommon.getAppSliderCoupons().click();

		// obj.getCouponselectionlblcouponsicon().verifyPresent();
		// obj.getCouponselectionlblcouponsicon().click();

		/* Checking the skipper for 1st navigation */
		if (appcrash.getExceptionSkipCoupons().isPresent()) {
			appcrash.getExceptionSkipCoupons().click();
		}
	}

	/**
	 * Handle Skip - Skip Slider. If login button is present, enter credentials
	 * and login. Else, if Hamburger is present, Check for logout option and
	 * click on it. Handle relogin pop up. Enter credentials and login.
	 * 
	 * @param username
	 *            User name for HEB app
	 * @param pswd
	 *            Password for HEB app
	 */
	@QAFTestStep(description = "I am a hot user using {0}{1} credential")
	public static void iAmAHotUserUsingCredential(String username, String pswd) {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		getBundle().setProperty("CurrentPassword", pswd);

		/* Setting Environment before execution */

		if (androidfun.getBtnSkip().isPresent()) {
			androidfun.getBtnSkip().click();
			PerfectoUtils.reportMessage("Clicking on Skip button to see login splash page", MessageTypes.Info);
		}
		// settingEnvironmentinApp();

		// PerfectoUtils.getAppiumDriver().context("NATIVE_APP");
		try {
			loginsplash.getLoginBtnLogin().waitForPresent(3000);
			;
		} catch (Exception e) {
			try {
				androidfun.getAppHamburger().waitForPresent(3000);
			} catch (Exception e1) {
				handlePopup();
			}
		}

		if (loginsplash.getLoginBtnLogin().isPresent()) {
			PerfectoUtils.reportMessage("User is in Login splash page.", MessageTypes.Pass);
			EnterCredentialsAndLogin(username, pswd);
		} else if (androidfun.getAppHamburger().isPresent()) {
			PerfectoUtils.reportMessage("User has an Pre-existing session.", MessageTypes.Pass);
			androidfun.getAppHamburger().click();
			if (!androidfun.getAppSliderLogout().isPresent()) {
				PerfectoUtils.verticalswipe();
			}
			androidfun.getAppSliderLogout().waitForPresent(3000);
			androidfun.getAppSliderLogout().click();
			PerfectoUtils.reportMessage("Logged out.", MessageTypes.Pass);

			/* Handle re-login pop up */
			if (appCrash.getReloginTitle().isPresent()) {
				PerfectoUtils.handleReloginPopup();
			}

			/* Logging In */
			EnterCredentialsAndLogin(username, pswd);
		} else {
			PerfectoUtils.reportMessage("Unexpected error occured. Pls try again.", MessageTypes.Fail);
		}
	}

	/**
	 * Click and Send Keys to Email and Password fields. Verify Login button and
	 * click it. Check for Hamburger icon. If login is still visible, click
	 * again.
	 * 
	 * @param username
	 *            User name for HEB app
	 * @param pswd
	 *            Password for HEB app
	 */
	public static void EnterCredentialsAndLogin(String username, String pswd) {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		loginsplash.getLoginTxtEmail().waitForPresent(3000);
		loginsplash.getLoginTxtEmail().click();
		loginsplash.getLoginTxtEmail().sendKeys(username);
		loginsplash.getLoginTxtPassword().click();
		getBundle().setProperty("currentPassword", pswd);
		loginsplash.getLoginTxtPassword().sendKeys(pswd);
		loginsplash.getLoginBtnLogin().verifyPresent();
		loginsplash.getLoginBtnLogin().click();

		PerfectoUtils.reportMessage("Clicked Login button.", MessageTypes.Pass);
		loginsplash.waitForPageToLoad();

		try {
			androidfun.getAppHamburger().waitForPresent(20000);
		} catch (Exception e) {

			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "LOG IN");
			String result1 = (String) androidfun.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
					params1);

			if (result1.equalsIgnoreCase("true")) {
				androidfun.getTestBase().getDriver().executeScript("mobile:text:select", params1);
				PerfectoUtils.reportMessage("Clicked Login button Again!!.", MessageTypes.Pass);
			}

			if (androidfun.getAppHamburger().isPresent()) {
				PerfectoUtils.reportMessage("Login Successful.", MessageTypes.Pass);
			} else if (loginsplash.getLoginBtnLogin().isPresent()) {
				loginsplash.getLoginBtnLogin().click();
				PerfectoUtils.reportMessage("Clicked Login button Again!!.", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Login not successful.", MessageTypes.Info);
			}

		}
	}

	/**
	 * Wait, Verify and Click Hamburger icon. Click on Hambuger again if it is
	 * not visible. Wait and Click on Shopping list tab.
	 */
	@QAFTestStep(description = "I navigate to shopping list")
	public void iNavigateToShoppingList() {
		AndroidcommonTestPage androidfunction = new AndroidcommonTestPage();

		/* Click hamburger */
		androidfunction.getAppHamburger().waitForPresent(8000);
		androidfunction.getAppHamburger().verifyPresent();
		androidfunction.getAppHamburger().click();

		androidfunction.getAppSliderHome().waitForPresent(3000);
		if (!androidfunction.getAppSliderHome().isPresent()) {
			androidfunction.getAppHamburger().waitForPresent(3000);
			androidfunction.getAppHamburger().click();
		}

		/* Click shopping list */
		androidfunction.getAppSliderShoppinglist().waitForPresent(3000);
		androidfunction.getAppSliderShoppinglist().click();
		PerfectoUtils.reportMessage("Clicked on Shopping list.", MessageTypes.Pass);
	}

	/**
	 * Verify Weekly Ad is present in Home page. Swipe it does not present and
	 * Click.Handle Store locator Allow pop up. If store locator refine button
	 * is present, Select a store for Weekly Ad.
	 */
	@QAFTestStep(description = "I navigate to Weekly ad from homepage")
	public void iNavigateToWeeklyAdFromHomepage() {
		HomeTestPage homepage = new HomeTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		AndroidStepDefWeeklyAds androidStepDefWeeklyAd = new AndroidStepDefWeeklyAds();

		homepage.getHomeLblWeeklyAd().verifyPresent();
		if (!homepage.getHomeLblWeeklyAd().isPresent()) {
			PerfectoUtils.verticalswipe();
		}
		homepage.getHomeLblWeeklyAd().click();

		if (storelocator.getStorelocatorBtnAllow().isPresent()) {
			storelocator.getStorelocatorBtnAllow().click();
		}

		try {
			storelocatorErrorHandle();
		} catch (Exception e) {
			// ignore..
		}
		if (storelocator.getStorelocatorLblRefine().isPresent()) {
			androidStepDefWeeklyAd.iChooseAnStoreFromTheStoreListForGettingWeeklyads();
		}

	}

	/**
	 * Click and Send Keys to Email and Password fields. Verify Login button and
	 * click it. Check for Hamburger icon. If login is still visible, click
	 * again. Navigate to My List page Delete existing shopping lists, Click Add
	 * to Plus icon, Enter the shopping list and Save it. Wait and Click
	 * Hamburger icon and Wait and Click Home icon.
	 * 
	 * @param username
	 *            User name for HEB app
	 * @param pswd
	 *            Password for HEB app
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I am a hot user using {0}{1} with new list added")
	public void iAmAHotUserUsingWithNewList(String user, String pswd) throws InterruptedException {
		AndroidStepDefShoppingList androidStepDefShoppingList = new AndroidStepDefShoppingList();
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();

		AndroidStepDef.iAmAHotUserUsingCredential(user, pswd);
		androidStepDefShoppingList.iNavigateToMyListPage();

		/* Delete few lists steps added */
		deleteShoppingLists();

		/*
		 * Adds new list
		 */
		androidStepDefShoppingList.iClickOnPlusIconToAddList();
		androidStepDefShoppingList.iShouldSeeThePopupToEnterListName();
		androidStepDefShoppingList.iEnterTheShoppingListName();
		androidStepDefShoppingList.iClickTheSaveButton();
		androidcommonpage.getAppHamburger().waitForPresent(10000);
		androidcommonpage.getAppHamburger().click();
		androidcommonpage.getAppSliderHome().waitForPresent(3000);
		androidcommonpage.getAppSliderHome().click();
	}

	/**
	 * Click on Continue without Register button. Navigate to Weekly grocery
	 * list page. Search and add a product to Weekly Grocery list. Click
	 * Hamburger icon and Click Home icon.
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I am a cold user with product added in list")
	public void iAmAColdUserWithProductAddedInList() throws Exception {
		AndroidStepDefShoppingList androidStepDefShoppingList = new AndroidStepDefShoppingList();
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();

		iAmAnColdUser();
		androidStepDefShoppingList.iNavigateToMyListPage();
		androidStepDefShoppingList.iNavigateToWeeklyGroceriesPage();
		androidStepDefShoppingList.iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
		androidStepDefShoppingList.iSearchForProductFromListDetailsPage("milk");
		androidStepDefShoppingList.iShouldSeeTheSearchResultsPage();

		androidStepDefShoppingList.iSelectTheItemFirstEntry();
		androidStepDefShoppingList.iShouldSeeTheSelectedItemInTheSelectedListPage();
		androidcommonpage.getAppHamburger().waitForPresent(3000);
		androidcommonpage.getAppHamburger().click();
		androidcommonpage.getAppSliderHome().click();
	}

	/**
	 * Click on Element "ElementProperty" and send keys "inputValue" and click
	 * keyboard Search / Enter button
	 * 
	 * @param driver
	 *            WebDriverTestPage
	 * @param ElementProperty
	 *            Element to be clicked and enter value into it
	 * @param inputValue
	 *            Value to be entered
	 */
	public static void enterValueIntoTheTextboxandClick(WebDriverTestPage driver, QAFWebElement ElementProperty,
			String inputValue) {

		ElementProperty.waitForPresent(10000);
		ElementProperty.click();
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys("");
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(inputValue);
		ElementProperty.waitForPresent(1000);
		PerfectoUtils.reportMessage("Entered text: " + inputValue, MessageTypes.Pass);
		Map<String, Object> EnterKeyEvent = new HashMap<>();
		EnterKeyEvent.put("key", "66");
		driver.getTestBase().getDriver().executeScript("mobile:key:event", EnterKeyEvent);
		PerfectoUtils.reportMessage("Clicked ENTER from key board.", MessageTypes.Pass);
	}

	/**
	 * Send Keys of "inputValue" using Appium driver Keyboard and click keyboard
	 * Search / Enter button
	 * 
	 * @param driver
	 *            WebDriverTestPage
	 * @param inputValue
	 *            Value to be entered
	 */
	public static void enterValueIntoTheTextboxandClick(WebDriverTestPage driver, String inputValue) {

		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(inputValue);
		PerfectoUtils.reportMessage("Search term entered: " + inputValue, MessageTypes.Pass);

		Map<String, Object> EnterKeyEvent = new HashMap<>();
		EnterKeyEvent.put("key", "66");
		Object result1 = driver.getTestBase().getDriver().executeScript("mobile:key:event", EnterKeyEvent);
		PerfectoUtils.reportMessage("Selected Search button from keyboard: ", MessageTypes.Pass);
		PerfectoUtils.hidekeyboard();
	}

	/**
	 * Swipe and click submit Registration
	 */
	@QAFTestStep(description = "I submit the registeration form")
	public void iSubmitTheRegisterationForm() {
		CommonStepDefRegisteration commonregister = new CommonStepDefRegisteration();

		PerfectoUtils.verticalswipe();
		commonregister.iClickCreateAccount();
	}

	/**
	 * Wait and Verify Home page Weekly ad tab. Check the text of "Weekly Ad"
	 * and Pass the step. Fail the step if it does not match.
	 */
	@QAFTestStep(description = "I see homepage")
	public void iSeeHomepage() {
		HomeTestPage homepage = new HomeTestPage();

		homepage.waitForPageToLoad();
		homepage.getHomeLblWeeklyAd().waitForPresent(20000);
		homepage.getHomeLblWeeklyAd().verifyPresent();
		String homeoption = homepage.getHomeLblWeeklyAd().getText();
		homepage.getHomeLblWeeklyAd().waitForPresent(5000);
		String actualoption = "Weekly Ad";
		if (homeoption.equalsIgnoreCase(actualoption)) {
			PerfectoUtils.reportMessage("User is navigated back to homepage", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User is not navigated back to homepage", MessageTypes.Fail);
		}
	}

	/**
	 * Wait and click Register button from My List page. Verify Email,
	 * FirstName, LastName, Password fields, T&C check box and Submit button.
	 */
	@QAFTestStep(description = "I see Registration page on clicking the Register button")
	public void iSeeRegistrationPageOnClickingTheRegisterButton() {
		MylistTestPage mylist = new MylistTestPage();
		RegistrastionTestPage registerPage = new RegistrastionTestPage();

		mylist.getMyListsBtnRegister().waitForPresent(3000);
		mylist.getMyListsBtnRegister().click();

		registerPage.getRegistrationTxtEmail().verifyPresent();
		registerPage.getRegistrationTxtFirstname().verifyPresent();
		registerPage.getRegistrationTxtLastname().verifyPresent();
		PerfectoUtils.hidekeyboard();
		registerPage.getRegistrationTxtPassword().verifyPresent();
		registerPage.getRegistrationChkIagree().verifyPresent();
		if (!registerPage.getRegistrationBtnSubmit().isPresent()) {
			PerfectoUtils.verticalswipe();
		}
		registerPage.getRegistrationBtnSubmit().verifyPresent();
		PerfectoUtils.reportMessage("Registration done:", MessageTypes.Info);
	}

	/**
	 * Handle Skip, If Hamburger icon is present, Click and logout, Handle Re
	 * login pop up. Wait and Verify Continue Without Register button.
	 */
	@QAFTestStep(description = "I am on Login splash page")
	public void iAmOnLoginSplashPage() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		/* Setting Environment before execution */
		// settingEnvironmentinApp();

		try {
			androidfun.getAppHamburger().waitForPresent(10000);
			System.out.println("hamburger present");
		} catch (Exception e) {
			try {
				loginsplash.getLoginLblContinue().waitForPresent(5000);

				// new step
				// loginsplash.getLoginLblContinue().click();

			} catch (Exception e1) {
				handlePopup();
			}
		}
		if (androidfun.getAppHamburger().isPresent()
				&& ((androidfun.getAppHamburger().getAttribute("hidden")).equals("false"))) {

			PerfectoUtils.reportMessage("User has an Pre-existing session.");
			androidfun.getAppHamburger().click();
			PerfectoUtils.verticalswipe();
			if (!androidfun.getAppSliderLogout().isPresent()) {
				PerfectoUtils.verticalswipe();
			}
			androidfun.getAppSliderLogout().waitForPresent(5000);
			androidfun.getAppSliderLogout().click();

		}
		loginsplash.getLoginLblContinue().waitForPresent(10000);
		loginsplash.getLoginLblContinue().verifyPresent();
	}

	/**
	 * Click android device back button. Wait for Hot user list to present in My
	 * list page. Swipe horizontally on List name and delete the list.
	 */
	@QAFTestStep(description = "I delete the newly created list")
	public void iDeleteTheNewlyCreatedList() {
		MylistTestPage myListPage = new MylistTestPage();

		/* Clicking on device back button */
		PerfectoUtils.androiddeviceback();
		myListPage.waitForPageToLoad();
		myListPage.getMyListLblLstNameHotUser().waitForPresent(3000);
		String strDeleteListName = getBundle().getPropertyValue("NewListName");

		try {
			myListPage.getShopingListEntryByLable(strDeleteListName).waitForPresent(3000);
		} catch (Exception e) {
			scrollToListNameInMyList(strDeleteListName, 90, 70, 2);
		}

		/* Getting the x and y co-ordinates */
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartX = Integer.parseInt(myListPage.getShopingListEntryByLable(strDeleteListName).getAttribute("X"));
		int intEndX = (int) (size.width * 0.90);
		int intStartY = Integer.parseInt(myListPage.getShopingListEntryByLable(strDeleteListName).getAttribute("Y"));
		getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);
		PerfectoUtils.reportMessage("Swiping across the list name: " + strDeleteListName + " to delete");
	}

	/**
	 * If Hero image is present, swipe inverse vertically.
	 */
	public static void handleHeroImage() {
		HomeTestPage homepage = new HomeTestPage();

		/* Handling new Ship to Home slider */
		try {
			homepage.getHomeImgShipToHomeSlide().waitForPresent(3000);
			if (homepage.getHomeImgShipToHomeSlide().isPresent()) {
				PerfectoUtils.horizontalswipe();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Click Hamburger icon, Swipe and check for Setting tab. Click on Settings
	 * tab. Wait and click on SettingFAQ tab.
	 */
	@QAFTestStep(description = "I navigate to FAQ")
	public void iValidateFAQ() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		androidcommon.getAppHamburger().click();
		PerfectoUtils.verticalswipe();
		if (!androidcommon.getAppSliderAppSettings().isPresent())
			PerfectoUtils.verticalswipe();
		if (!androidcommon.getAppSliderAppSettings().isPresent())
			PerfectoUtils.verticalswipeSlow();

		androidcommon.getAppSliderAppSettings().waitForPresent(3000);
		androidcommon.getAppSliderAppSettings().click();
		androidcommon.getAppSettingFaq().waitForPresent(3000);
		androidcommon.getAppSettingFaq().click();
	}

	/**
	 * Verify FAQ page title is present
	 */
	@QAFTestStep(description = "I validate FAQ page")
	public void iNavigateToFAQPage() {
		FAQTestPage FAQPage = new FAQTestPage();

		boolean faqpage;

		/* Verifying FAQ page title */
		faqpage = FAQPage.getAppFaqsblbPageTitle().verifyPresent();

		if (faqpage) {
			PerfectoUtils.reportMessage("FAQ Page has displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("FAQ Page has not displayed", MessageTypes.Fail);
		}

		FAQPage.getLblFaqcommonques().verifyPresent();
		if (!FAQPage.getLblFaqproduct().isPresent())
			PerfectoUtils.verticalswipeSlow();
		FAQPage.getLblFaqproduct().waitForPresent(3000);
		FAQPage.getLblFaqproduct().verifyPresent();
		PerfectoUtils.scrollToStringuntilfindelement(FAQPage.getLblFaqproductques(), 80, 60, 2);
		FAQPage.getLblFaqproductques().verifyPresent();

		PerfectoUtils.scrollToStringuntilfindelement(FAQPage.getLblFaqmylistques(), 80, 60, 2);
		FAQPage.getLblFaqmylist().waitForPresent(3000);
		FAQPage.getLblFaqmylist().verifyPresent();
		FAQPage.getLblFaqmylistques().verifyPresent();

		PerfectoUtils.scrollToStringuntilfindelement(FAQPage.getLblFaqpharmacyques(), 80, 60, 2);
		FAQPage.getLblFaqpharmacy().waitForPresent(4000);
		FAQPage.getLblFaqpharmacy().verifyPresent();
		FAQPage.getLblFaqpharmacyques().verifyPresent();

		PerfectoUtils.scrollToStringuntilfindelement(FAQPage.getLblFaqdigcoup(), 80, 60, 2);
		FAQPage.getLblFaqdigcoup().waitForPresent(3000);
		FAQPage.getLblFaqdigcoup().verifyPresent();
		PerfectoUtils.scrollToStringuntilfindelement(FAQPage.getLblFaqdigcoupques(), 80, 60, 2);
		FAQPage.getLblFaqdigcoupques().verifyPresent();
	}

	/**
	 * Click Hamburger, Swipe and wait and Click App Settings tab. Wait and
	 * CLick Privacy Policy.
	 */
	@QAFTestStep(description = "I navigate to Privacy Policy")
	public void iValidatePrivacyPolicy() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		androidcommon.getAppHamburger().click();
		PerfectoUtils.verticalswipe();
		try {
			androidcommon.getAppSliderAppSettings().waitForPresent(2000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
			androidcommon.getAppSliderAppSettings().waitForPresent(2000);
		}
		androidcommon.getAppSliderAppSettings().click();
		androidcommon.getAppPrivacyPolicy().waitForPresent(3000);
		androidcommon.getAppPrivacyPolicy().click();
	}

	/**
	 * Handle leave page pop up, If Chrome option is present to open browser,
	 * select it.
	 */
	@QAFTestStep(description = "I validate Privacy Policy page")
	public void iNavigateToPrivacyPolicyPage() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		handleleaveapp();

		if (weeklygrocery.getShopingListEntryByLable("Chrome").isPresent()) {
			weeklygrocery.getShopingListEntryByLable("Chrome").click();
			weeklygrocery.getShopingListEntryByLable("Always").click();
		}

		CommonSteps.validatExploreText("Explore My");

		/* Verifying Privacy Policy page title */
		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(5, TimeUnit.MINUTES);
		CommonSteps.validattextinpage("Privacy Policy");
		weeklygrocery.waitForTextPresent("PERSONAL INFORMATION");
		CommonSteps.validattextinpage("PERSONAL INFORMATION");
		openApplication(PerfectoUtils.getAppiumDriver(), getBundle().getString("app.name"));
	}

	/**
	 * If login button is available, click it or else, Select OK from Pop up to
	 * leave the page
	 */
	public void handleleaveapp() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		if (androidcommon.getBtnLogin().isPresent()) {
			androidcommon.getBtnLogin().click();
		} else {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "OK");
			androidcommon.getTestBase().getDriver().executeScript("mobile:text:select", params1);
		}
	}

	/**
	 * Click Hamburger, Swipe, Wait and click App settings tab. Wait for Privacy
	 * policy and click T&C.
	 */
	@QAFTestStep(description = "I naviagate to Terms & Conditions")
	public void iNavigateToTermsConditionsPage() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		androidcommon.getAppHamburger().click();
		PerfectoUtils.verticalswipe();
		try {
			androidcommon.getAppSliderAppSettings().waitForPresent(2000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
			androidcommon.getAppSliderAppSettings().waitForPresent(2000);
		}
		androidcommon.getAppSliderAppSettings().click();
		androidcommon.getAppPrivacyPolicy().waitForPresent(2000);
		androidcommon.getAppTermsAndConditions().click();
	}

	/**
	 * Handle leave page pop up, If Chrome option is present to open browser,
	 * select it. Validate Terms and Conditions page title. Open application
	 * again.
	 */
	@QAFTestStep(description = "I validate Terms & Conditions page")
	public void iValidateTermsConditions() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		handleleaveapp();

		if (weeklygrocery.getShopingListEntryByLable("Chrome").isPresent()) {
			weeklygrocery.getShopingListEntryByLable("Chrome").click();
			weeklygrocery.getShopingListEntryByLable("Always").click();
		}

		CommonSteps.validatExploreText("Explore My");

		/* Verifying Terms & Conditions page title */
		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(30, TimeUnit.MINUTES);
		CommonSteps.validattextinpage("H-E-B Terms & Conditions");
		// CommonSteps.validattextinpage("heb.com Terms of Use");
		openApplication(PerfectoUtils.getAppiumDriver(), getBundle().getString("app.name"));
	}

	/**
	 * If Hamburger is present, click and do vertical swipe till logout is
	 * present. Click Logout button. Handle relogin pop up. Else, if logout is
	 * present, click it. Verify if continue without register is present.
	 */
	@QAFTestStep(description = "I validate logout")
	public void iValidateLogout() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();
		MyaccountTestPage myaccountpage = new MyaccountTestPage();

		if (androidfun.getAppHamburger().isPresent()) {
			androidfun.getAppHamburger().click();
			PerfectoUtils.verticalswipe();

			if (!androidfun.getAppSliderLogout().isPresent()) {
				PerfectoUtils.verticalswipe();
			}
			androidfun.getAppSliderLogout().waitForPresent(3000);
			PerfectoUtils.reportMessage("Logging out from the application", MessageTypes.Pass);
			androidfun.getAppSliderLogout().click();

			/* Handle re-login pop up */
			if (appCrash.getReloginTitle().isPresent()) {
				PerfectoUtils.handleReloginPopup();
			}
		} else if (myaccountpage.getBtnLogout().isPresent()) {
			myaccountpage.getBtnLogout().click();
		}

		/* Validate the result page */
		if (loginsplash.getLoginLblContinue().verifyPresent()) {
			PerfectoUtils.reportMessage("Logged out successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not Logged out successfully", MessageTypes.Fail);
		}
	}

	/**
	 * Wait for page to load, Wait for Hamburger and click it. Do vertical
	 * swipe, Wait for Logout and click it. Handle relogin pop up.
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I logout the application")
	public void iLogoutTheApplication() throws InterruptedException {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		androidcommon.waitForPageToLoad();
		androidcommon.openAppHamburger();
		PerfectoUtils.verticalswipe();
		androidcommon.getAppSliderLogout().waitForPresent(10000);
		androidcommon.getAppSliderLogout().click();

		/* Handle re-login pop up */
		if (appCrash.getReloginTitle().isPresent()) {
			PerfectoUtils.handleReloginPopup();
		}

	}

	/**
	 * Get Device Size, Define Start swiping point as startSize% in total height
	 * and Ending swiping point as endSize% in total height, Wait for String
	 * "strname", If it is not available, Do swipe for duration "swipeDuration"
	 * till the String is present or maximum 30 times.
	 * 
	 * @param strname
	 *            String name till which swipe requires
	 * @param startSize
	 *            % in Total height from where swipe should be started
	 * @param endSize
	 *            % in Total height from where swipe should be ended
	 * @param swipeDuration
	 *            Duration in seconds for ow long it should swipe
	 */
	public static void scrollToListNameInMyList(String strname, float startSize, float endSize, int swipeDuration) {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		int i = 0;
		int intX = 50;
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartY = (int) (size.height * (startSize / 100));
		int intEndY = (int) (size.height * (endSize / 100));
		try {
			weeklygrocery.getShopingListEntryByLable(strname).waitForPresent(6000);
		} catch (Exception e1) {
			do {

				/* Swiping till half of the page */
				PerfectoUtils.getAppiumDriver().swipe(intX, intStartY, intX, intEndY, swipeDuration);
				i++;
				System.out.println(weeklygrocery.getShopingListEntryByLable(strname).isPresent());
			} while (!weeklygrocery.getShopingListEntryByLable(strname).isPresent() && i < 30);
		}
	}

	/**
	 * Get Device Size, Define Start swiping point as startSize% in total height
	 * and Ending swiping point as endSize% in total height, Wait for element
	 * "element", If it is not available, Do swipe for duration "swipeDuration"
	 * till the element is present or maximum 20 times and get all ingeredients
	 * till it swipes.
	 * 
	 * @param element
	 *            QAFWebelement till which swipe requires
	 * @param objectText
	 *            Not used
	 * @param startSize
	 *            % in Total height from where swipe should be started
	 * @param endSize
	 *            % in Total height from where swipe should be ended
	 * @param swipeDuration
	 *            Duration in seconds for ow long it should swipe
	 * @return String HashSet which contains Ingredient list
	 */
	public static HashSet<String> scrollToIngredients(QAFWebElement element, String objectText, float startSize,
			float endSize, int swipeDuration) {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();
		HashSet<String> arrlist = new HashSet<String>();
		int i = 0;
		int intX = 0;
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartY = (int) (size.height * (startSize / 100));
		int intEndY = (int) (size.height * (endSize / 100));

		try {
			for (QAFWebElement product : recipedetail.getRecipedetailpageIngList()) {
				arrlist.add(product.getText());
			}
			element.waitForPresent(6000);
			element.isDisplayed();
		} catch (Exception e1) {
			do {
				/* Swiping till half of the page */
				PerfectoUtils.getAppiumDriver().swipe(intX, intStartY, intX, intEndY, 1);
				try {

					for (QAFWebElement product : recipedetail.getRecipedetailpageIngList()) {
						arrlist.add(product.getText());
					}
					element.waitForPresent(6000);
				} catch (Exception e) {
					e.printStackTrace();
				}
				i++;
			} while (!element.isPresent() && (i < 20));
		}

		return (arrlist);
	}

	/**
	 * Scroll till "Add to List" and Click Add to List button
	 */
	@QAFTestStep(description = "I select Add to List button")
	public void iSelectAddToListButton() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		try {
			AndroidStepDef.scrollToListNameInMyList("Add to List", 90, 85, 2);
			if (recipedetail.getRecipedetailpageAddtolist().isPresent()) {
				recipedetail.getRecipedetailpageAddtolist().click();
			} else {
				PerfectoUtils.verticalswipe();
				recipedetail.getBtnFirstAddtolistlist().isPresent();
				recipedetail.getBtnFirstAddtolistlist().click();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Wait for Store oc Refine button, If it fails, Check for
	 * "Allow HEB to access" pop up. Select Allow permission button. Verify
	 * Refine button is present.
	 */
	public static void storelocatorErrorHandle() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		/* Handling the store locator error */
		try {
			storelocator.getStorelocatorLblRefine().waitForPresent(10000);
		} catch (Exception e) {
			weeklygrocery.getShopingListEntryByLable("Allow H-E-B to access").waitForPresent(5000);
			if (weeklygrocery.getShopingListEntryByLable("Allow H-E-B to access").isPresent()) {
				PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Info);
				androidcommon.getAppPopupBtnAllowPermission().verifyPresent();
				androidcommon.getAppPopupBtnAllowPermission().click();
			}
		}
		storelocator.waitForPageToLoad();
		storelocator.getStorelocatorLblRefine().verifyPresent();
	}

	/**
	 * Verify if No results label is present in product landing page. Else, back
	 * ground text message as "No results" must be present.
	 */
	@QAFTestStep(description = "I validate the error message for invalid product")
	public void iValidateTheErrorMessageForInvalidProduct() {
		ProductlandingTestPage productlanding = new ProductlandingTestPage();

		if (productlanding.getLblNoresults().isPresent()) {
			PerfectoUtils.reportMessage("Error: No result found for search term", MessageTypes.Pass);
		} else {
			String ErrMessage = "No results";
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", ErrMessage);
			String isBtnPlayVisible = (String) productlanding.getTestBase().getDriver()
					.executeScript("mobile:checkpoint:text", params1);
			if (isBtnPlayVisible.equalsIgnoreCase("false")) {
				PerfectoUtils.reportMessage("Able to see the searched product", MessageTypes.Fail);
			} else {
				PerfectoUtils.reportMessage("Error: No result found for search term", MessageTypes.Pass);
			}
		}
	}

	/**
	 * Verify whether the Refine Filter icon is present and Click on it. Verify
	 * Refine Page title, Click A to Z button, Verify Refine Done button is
	 * present and click. Wait for Product search result page title. Fail if
	 * it's not present.
	 */
	@QAFTestStep(description = "I validate the refine filter options")
	public void iValidateTheRefineFilterOptions() {
		ProductsearchresultTestPage productsearchresult = new ProductsearchresultTestPage();
		RefineTestPage refine = new RefineTestPage();
		int i = 0;
		/* Clicking on Filter icon */
		productsearchresult.getProdsearchresultTxtFiltericon().verifyPresent();
		productsearchresult.getProdsearchresultTxtFiltericon().click();

		/* Selecting the filter */
		refine.waitForPageToLoad();
		refine.getRefineTxtPagetitle().verifyPresent();

		do {

			PerfectoUtils.verticalswipe();
			;
			i++;
		} while (!refine.getRefineBtnAtoz().isPresent() && i <= 15);

		refine.getRefineBtnAtoz().click();
		refine.getRefineBtnDone().verifyPresent();
		refine.getRefineBtnDone().click();

		/* Verifying the Filter */
		productsearchresult.getProdsearchresultTxtPagetitle().waitForPresent(7000);
		if (productsearchresult.getProdsearchresultTxtPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Filter is selected successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Filter is not selected successfully", MessageTypes.Fail);
		}
	}

	/**
	 * Get Device Size, Define Start swiping point as startSize% in total height
	 * and Ending swiping point as endSize% in total height, Do swipe for
	 * duration "swipeDuration" till the element is present for numberOfTimes
	 * till it swipes.
	 * 
	 * @param numberOfTimes
	 *            number of times swipe needs to be performed
	 * @param startSize
	 *            % in Total height from where swipe should be started
	 * @param endSize
	 *            % in Total height from where swipe should be ended
	 * @param swipeDuration
	 *            Duration in seconds for ow long it should swipe
	 */
	public static void scrollToWithNumberOfTimes(int numberOfTimes, float startSize, float endSize, int swipeDuration) {

		int i = 0;
		int intX = 50;
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartY = (int) (size.height * (startSize / 100));
		int intEndY = (int) (size.height * (endSize / 100));
		do {
			/* Swiping till half of the page */
			PerfectoUtils.getAppiumDriver().swipe(intX, intStartY, intX, intEndY, swipeDuration);
			i++;
		} while (i < numberOfTimes);
	}

	/**
	 * Wait for HEB pop up to take pictures. If it is present, Click on allow
	 * permission button
	 */
	public static void handleHEBTakePicPopUp() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		try {
			androidcommon.getAppPopupBtnAllowPermission().waitForPresent(3000);
			if (weeklygrocery.getShopingListEntryByLable("Allow H-E-B to take pictures").isPresent()) {
				PerfectoUtils.reportMessage("Allowing H-E-B to take pictures", MessageTypes.Info);
				androidcommon.getAppPopupBtnAllowPermission().verifyPresent();
				androidcommon.getAppPopupBtnAllowPermission().click();
			}
		} catch (Exception f) {
			// ignore
		}
	}

	/**
	 * Check the text field element "elementproperty" is empty and click on it.
	 * Hide Keyboard. By Checking the Tip element "elefortiptext" text equals to
	 * "elementName", Pass the step as Hint text is dislayed
	 * 
	 * @param elementproperty
	 *            Text field element
	 * @param elefortiptext
	 *            Tip element
	 * @param elementName
	 *            Text field element tip
	 */
	public static void validatehintfortext(QAFWebElement elementproperty, QAFWebElement elefortiptext,
			String elementName) {

		if (elementproperty.getText().equals("") && ((elementproperty.getAttribute("focused")).equals("false"))) {
			PerfectoUtils.reportMessage(elementName + " text field is empty", MessageTypes.Pass);
			elementproperty.click();
			PerfectoUtils.hidekeyboard();
			if ((elefortiptext.getText().equalsIgnoreCase(elementName))
					&& ((elementproperty.getAttribute("focused")).equals("true"))) {
				PerfectoUtils.reportMessage(
						"The hint for " + elementName + " text is displayed as " + elefortiptext.getText(),
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("The hint for " + elementName + " text is not displayed as expected");
			}
		}
	}

	/**
	 * Verify if Share page title is present. Swipe and verify Share bluetooth,
	 * Email, messages, facebook and Android beam label is present. Click on
	 * android device back button if Recipe details recipe name is not present.
	 */
	@QAFTestStep(description = "I validate share page")
	public void iValidateSharePage() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();
		ShareTestPage sharepage = new ShareTestPage();

		sharepage.getSharelblTitle().verifyPresent();

		if (swipeAndVerifyShareOption(couponsdetails.getLblSharebluetooth())) {
			PerfectoUtils.reportMessage("Bluetooth share option is present!!", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Bluetooth share option is not present!!", MessageTypes.Info);
		}

		if (swipeAndVerifyShareOption(couponsdetails.getLblShareemail())) {
			PerfectoUtils.reportMessage("Email share option is present!!", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Email share option is not present/Email share option is not applicable for Nexus!!Please check..",
					MessageTypes.Info);
		}

		if (swipeAndVerifyShareOption(couponsdetails.getLblSharemessage())) {
			PerfectoUtils.reportMessage("Message share option is present!!", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Message share option is not present!!", MessageTypes.Info);
		}

		if (swipeAndVerifyShareOption(couponsdetails.getLblSharefacebook())) {
			PerfectoUtils.reportMessage("Facebook share option is present!!", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Facebook share option is not present!! App might not be available in device!!",
					MessageTypes.Info);
		}

		if (swipeAndVerifyShareOption(couponsdetails.getLblShareandroidbeam())) {
			PerfectoUtils.reportMessage("Android beam share option is present!!", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Android beam share option is not present!! App might not be available in device!!",
					MessageTypes.Info);
		}

		if (!recipedetail.getRecipedetailpageRecipename().isPresent())
			PerfectoUtils.androiddeviceback();
	}

	/**
	 * Verify Attach button, Send button, To label, Recipient info edit field,
	 * Subject label, Email body label.
	 */
	@QAFTestStep(description = "I validate email content")
	public void iValidateEmailContent() {
		EmailcontentTestPage emailcontent = new EmailcontentTestPage();

		/* Validate the Content in Email Page */
		emailcontent.getBtnAttach().verifyPresent();
		emailcontent.getBtnSend().verifyPresent();
		emailcontent.getLblTo().verifyPresent();
		emailcontent.getEdtRecipientto().verifyPresent();
		emailcontent.getLblSubject().verifyPresent();
		emailcontent.getLblEmailbody().verifyPresent();
	}

	/**
	 * Get email, password, pop2server and smtserver details. Enter all these
	 * values in corresponding fields. Click Sign in or Next button. If Edit
	 * Names field is present. Click done button. If any error messages are
	 * present, print it and Fail the step.
	 */
	public void emailaddaccount() {
		ShareTestPage sharepage = new ShareTestPage();
		EmailcontentTestPage emailcontent = new EmailcontentTestPage();

		String username = ConfigurationManager.getBundle().getString("hotuser1.user.email");
		String password = ConfigurationManager.getBundle().getString("hotuser1.user.password");
		String pop3server = ConfigurationManager.getBundle().getString("pop2server.server");
		String smtpserver = ConfigurationManager.getBundle().getString("smtpserver.server");

		sharepage.waitForPageToLoad();

		sharepage.getEmailEdtEmailaddress().sendKeys(username);
		QAFWebElement webelement = null;
		if (sharepage.getEmailEdtPassword().isPresent()) {
			webelement = sharepage.getEmailEdtPassword();
		}
		webelement.sendKeys(password);

		performaction(sharepage.getBtnSignin(), sharepage.getBtnNext());
		performaction(emailcontent.getBtnPop3account(), emailcontent.getChkPop3());
		performaction(emailcontent.getBtnSignin(), sharepage.getBtnNext());

		/* Check for POP3 Server */
		if (emailcontent.getBtnSignin().isPresent() && (!emailcontent.getBtnSignin().isEnabled())) {
			emailcontent.getEdtServer().sendKeys(pop3server);
		} else if (sharepage.getBtnNext().isPresent() && (!sharepage.getBtnNext().isEnabled())) {
			emailcontent.getEdtServer().sendKeys(pop3server);
		}
		performaction(emailcontent.getBtnSignin(), sharepage.getBtnNext());

		/* Check for SMTP Server */
		if (emailcontent.getBtnSignin().isPresent() && (!emailcontent.getBtnSignin().isEnabled())) {
			emailcontent.getEdtSmtp().sendKeys(smtpserver);
		} else if (sharepage.getBtnNext().isPresent() && (!sharepage.getBtnNext().isEnabled())) {
			emailcontent.getEdtSmtp().sendKeys(smtpserver);
		}
		performaction(emailcontent.getBtnSignin(), sharepage.getBtnNext());

		emailcontent.getLblMessage().waitForNotPresent(10000);

		performaction(emailcontent.getBtnSignin(), sharepage.getBtnNext());

		emailcontent.getLblMessage().waitForNotPresent(15000);

		performaction(emailcontent.getBtnSignin(), sharepage.getBtnNext());

		if (emailcontent.getLblEditnames().isPresent()) {
			emailcontent.getBtnDone().click();
			PerfectoUtils.androiddeviceback();
		} else if (emailcontent.getLblMessage().isPresent()) {
			String errmsg = emailcontent.getLblMessage().getText();
			PerfectoUtils.reportMessage(errmsg, MessageTypes.Fail);
			emailcontent.getBtnOk().click();
		} else {
			emailcontent.getBtnDone().click();
		}
	}

	/**
	 * If any alert pop up present in Email content page, click on Continue
	 * button. if Element "tryaction" is present, click it. Else if
	 * "catchaction" is present, click it.
	 * 
	 * @param tryaction
	 *            element to be verified for present and click
	 * @param catchaction
	 *            element to be verified and click if tryaction is not present
	 */
	public static void performaction(QAFWebElement tryaction, QAFWebElement catchaction) {
		EmailcontentTestPage emailcontent = new EmailcontentTestPage();

		if (emailcontent.getLblAlertpopup().isPresent()) {
			emailcontent.getBtnContinue().click();
		}
		if (tryaction.isPresent()) {
			tryaction.click();
		} else if (catchaction.isPresent()) {
			catchaction.click();
		}
	}

	/**
	 * Swipe and verify Email, If email is present, click on it. Else, fail the
	 * step. And add account in Email if attach button is not present, email
	 * msg, select email or page header label are present.
	 */
	@QAFTestStep(description = "I navigate to email page")
	public void iNavigateToEmailPage() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();
		EmailcontentTestPage emailcontent = new EmailcontentTestPage();
		ShareTestPage sharepage = new ShareTestPage();

		if (swipeAndVerifyShareOption(couponsdetails.getLblShareemail())) {
			PerfectoUtils.reportMessage("Email share option is present!!", MessageTypes.Pass);
			if (couponsdetails.getLblShareemail().isPresent()) {
				couponsdetails.getLblShareemail().click();
			} else if (couponsdetails.getLblSharegmail().isPresent()) {
				couponsdetails.getLblSharegmail().click();
			}
		} else {
			PerfectoUtils.reportMessage("Email is not installed in this device!!Please Check", MessageTypes.Fail);
		}

		if (!emailcontent.getBtnAttach().isPresent()) {
			if (sharepage.getBtnAddaccount().isPresent()) {
				sharepage.getBtnAddaccount().click();
				emailaddaccount();
			} else if (sharepage.getLblEmailmsg().isPresent()) {
				sharepage.getEmailcontentBtnOk().click();
				if (sharepage.getLblOthers().isPresent()) {
					sharepage.getBtnOther().click();
				}
				emailaddaccount();
			} else if (sharepage.getLblSelectemail().isPresent()) {
				if (sharepage.getLblOthers().isPresent()) {
					sharepage.getLblOthers().click();
				}
				emailaddaccount();
			} else if (sharepage.getLblPageheader().isPresent()) {
				emailaddaccount();
			}
		}
	}

	/**
	 * Swipe to facebook option and click it.
	 */
	@QAFTestStep(description = "I navigate to social media page")
	public void iNavigateToSocialMediaPage() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();

		if (swipeAndVerifyShareOption(couponsdetails.getLblSharefacebook())) {
			PerfectoUtils.reportMessage("Facebook share option is present!!", MessageTypes.Pass);
			couponsdetails.getLblSharefacebook().click();
		} else {
			PerfectoUtils.reportMessage("Facebook share option is not present!! App might not be available in device!!",
					MessageTypes.Info);
		}
	}

	/**
	 * Verify facebook image, email text field, password text field, login
	 * button, Forgot password label, create account button. And click android
	 * device back button.
	 */
	@QAFTestStep(description = "I validate content of social media")
	public void iValidateContentOfSocialMedia() {
		ShareTestPage facebook = new ShareTestPage();

		if (facebook.getLblPopuptitle().isPresent()) {
			PerfectoUtils.reportMessage("facebook Popup present as expected.", MessageTypes.Pass);
		} else {

			PerfectoUtils.reportMessage("Validating the properties of facebook App..");
			facebook.waitForPageToLoad();
			facebook.getImageFacebook().verifyPresent();
			facebook.getEdtEmail().verifyPresent();
			facebook.getEdtPassword().verifyPresent();
			facebook.getBtnLogin().verifyPresent();
			facebook.getLblForgetpwd().verifyPresent();
			facebook.getBtnCreateaccount().verifyPresent();
			PerfectoUtils.androiddeviceback();
		}
	}

	/**
	 * Wait and click search products icon, Wait and click search text field.
	 */
	@QAFTestStep(description = "I click on search field from homepage")
	public void iClickOnSearchFieldFromHomepage() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		androidcommon.getAppIconSearchproducts().waitForPresent(5000);
		androidcommon.getAppIconSearchproducts().click();
		androidcommon.getAppTxtSearchproducts().waitForPresent(5000);
		androidcommon.getAppTxtSearchproducts().click();
		PerfectoUtils.reportMessage("Clicked on search field from homepage.", MessageTypes.Pass);
	}

	/**
	 * Perform image injection, if Scan receipt text is present, click. Fail if
	 * not present. Stop Image injection. If enable camera pop up displays,
	 * allow permission. If product/ recipes not found pop up displays, click
	 * Cancel or OK.
	 * 
	 */
	@QAFTestStep(description = "I navigate and scan the receipt from Scan Receipt screen")
	public void iNavigateAndScanTheReceiptFromScanReceiptScreen() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		ScannerTestPage scanner = new ScannerTestPage();

		/* Setting the image to "Scan" */
		String repositoryFile = ConfigurationManager.getBundle().getString("scanner.reporitoryimage.scanreceipts");
		String appName = ConfigurationManager.getBundle().getString("app.name");

		PerfectoUtils.imageInjection(repositoryFile, appName);

		/* Clicking on "Scan Receipts" option */
		if (androidcommon.getScanTxtScanreceipt().isPresent()) {
			androidcommon.getScanTxtScanreceipt().click();
			PerfectoUtils.reportMessage("Navigated to Scan Receipts page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Scan Receipts page", MessageTypes.Fail);
		}

		/* Stopping Image Injection */
		PerfectoUtils.stopimageinjection();

		/* Checking whether the "Enable camera" pop-up is present */
		try {
			if (androidcommon.getAppPopupBtnAllowPermission().isPresent()) {
				androidcommon.getAppPopupBtnAllowPermission().click();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		/* Handling the error pop-ups */
		if (scanner.getLblProductnotfound().isPresent()) {
			PerfectoUtils.reportMessage("Product not found!", MessageTypes.Info);
			if (scanner.getBtnCancelproductnotfound().isPresent()) {
				scanner.getBtnCancelproductnotfound().click();
			} else if (scanner.getBtnOkproductnotfound().isPresent()) {
				scanner.getBtnOkproductnotfound().click();
			}

		} else if (scanner.getLblNorecipesfound().isPresent()) {
			PerfectoUtils.reportMessage("No Recipes found!", MessageTypes.Fail);
			scanner.getBtnOknorecipesfound().click();
		}
	}

	/**
	 * Perform image injection, if Scan products button is present, click. Fail
	 * if not present. If enable camera pop up displays, allow permission. If
	 * product/ recipes not found pop up displays, click Cancel or OK. Stop
	 * Image injection.
	 */
	/*
	 * @QAFTestStep(description =
	 * "I navigate and scan the item by clicking scanner button") public void
	 * iNavigateAndScanTheItemByClickingScannerButton() { AndroidcommonTestPage
	 * androidcommon = new AndroidcommonTestPage(); ScannerTestPage scanner =
	 * new ScannerTestPage();
	 * 
	 * Setting the image to "Scan" String repositoryFile =
	 * ConfigurationManager.getBundle().getString(
	 * "scanner.reporitoryimage.scanproducts1"); String appName =
	 * ConfigurationManager.getBundle().getString("app.name");
	 * 
	 * PerfectoUtils.imageInjection(repositoryFile, appName);
	 * 
	 * Clicking on "Scan Products" option if
	 * (androidcommon.getHeaderBtnScanProducts().isPresent()) {
	 * androidcommon.getHeaderBtnScanProducts().click();
	 * PerfectoUtils.reportMessage( "Navigated to Scan Products page",
	 * MessageTypes.Pass); } else { PerfectoUtils.reportMessage(
	 * "Not navigated to Scan Receipts page", MessageTypes.Fail); }
	 * 
	 * // Handling the error pop-ups if
	 * (androidcommon.getAppPopupBtnAllowPermission().isPresent()) {
	 * androidcommon.getAppPopupBtnAllowPermission().click(); } else {
	 * PerfectoUtils.reportMessage("Allow pop-up is appeared from second time.."
	 * , MessageTypes.Info); }
	 * 
	 * if (scanner.getLblProductnotfound().isPresent()) {
	 * PerfectoUtils.reportMessage( "Product not found!", MessageTypes.Info); if
	 * (scanner.getBtnCancelproductnotfound().isPresent()) {
	 * scanner.getBtnCancelproductnotfound().click(); } else if
	 * (scanner.getBtnOkproductnotfound().isPresent()) {
	 * scanner.getBtnOkproductnotfound().click(); } } else if
	 * (scanner.getLblNorecipesfound().isPresent()) {
	 * PerfectoUtils.reportMessage( "No Recipes found!", MessageTypes.Fail);
	 * scanner.getBtnOknorecipesfound().click(); }
	 * 
	 * Stopping Image Injection PerfectoUtils.stopimageinjection(); }
	 */

	/**
	 * Wait for QAFWebElement qafWebElement, if it is not present swipe 4 times
	 * till the element is found.
	 * 
	 * @param qafWebElement
	 *            Element to be swipe and found
	 * @return boolean value for element availability
	 */
	public static boolean swipeAndVerifyShareOption(QAFWebElement qafWebElement) {
		boolean isPresent = false;

		try {
			qafWebElement.waitForPresent(3000);
			isPresent = true;
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
			try {
				qafWebElement.waitForPresent(2000);
				isPresent = true;
			} catch (Exception e1) {
				try {
					qafWebElement.waitForPresent(2000);
					isPresent = true;
				} catch (Exception e2) {
					for (int i = 2; i <= 5; i++) {
						Dimension size = getAppiumDriver().manage().window().getSize();
						int intStartX = (int) (size.width * 0.80);
						int intEndX = (int) (size.width * 0.30);
						int intStartY = (int) (size.height * 0.80);

						getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 2);
						if (qafWebElement.isPresent()) {
							isPresent = true;
							break;
						}
					}
				}
			}
		}
		return isPresent;
	}

	/**
	 * Get Device Size, Define Start swiping point as startSize% in total height
	 * and Ending swiping point as endSize% in total height, Do swipe for String
	 * "strname" duration "swipeDuration" till the element is present maximum of
	 * 20 times
	 * 
	 * @param strname
	 *            String for which swipe needs to be performed
	 * @param startSize
	 *            % in Total height from where swipe should be started
	 * @param endSize
	 *            % in Total height from where swipe should be ended
	 * @param swipeDuration
	 *            Duration in seconds for ow long it should swipe
	 */
	public static void scrollToString(String strname, float startSize, float endSize, int swipeDuration) {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		int i = 0;
		int intX = 50;
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartY = (int) (size.height * (startSize / 100));
		int intEndY = (int) (size.height * (endSize / 100));

		while (!weeklygrocery.getShopingListEntryByLable(strname).isPresent() && i < 20) {
			/* Swiping till half of the page */
			PerfectoUtils.getAppiumDriver().swipe(intX, intStartY, intX, intEndY, swipeDuration);
			i++;
		}

	}

	/**
	 * Wait for lists to be visible in My list page. Select over flow icon,
	 * Select Delete option, In delete mode, select the lists, and select delete
	 * icon from pop up.
	 */
	public static void deleteShoppingLists() {
		AndroidStepDefShoppingList androidStepDefShoppingList = new AndroidStepDefShoppingList();
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.getMyListsLblListname().get(0).waitForPresent(8000);
		int listSize = mylistpage.getMyListsLblListname().size();

		if (listSize > 5) {
			PerfectoUtils.reportMessage(listSize + " lists available. deleting some lists..", MessageTypes.Pass);
			androidStepDefShoppingList.iSelectTheOverflowIconFromMyListsPage();
			androidStepDefShoppingList.iShouldSeeTheListOfOptions();
			androidStepDefShoppingList.iSelectDeleteListOption();
			androidStepDefShoppingList.iShouldSeeMyListsPageInDeleteMode();
			androidStepDefShoppingList.iSelectFewListsToDelete();
			androidStepDefShoppingList.iSelectDeleteIcon();
			androidStepDefShoppingList.iShouldSeeTheDeleteListsPopup();
			androidStepDefShoppingList.iSelectTheDeleteButtonFromDeleteListPopup();
			PerfectoUtils.reportMessage("Deleted " + (listSize - 1) + " lists.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(listSize + " lists available", MessageTypes.Pass);
		}

	}

	/**
	 * Wait and Click Hamburger icon, Swipe, Wait and click App settings button,
	 * Wait and Click envCert1, Click login if present, else click logout.
	 */
	public static void selectEnvironment() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		androidcommon.getAppHamburger().waitForPresent(5000);
		androidcommon.getAppHamburger().click();

		PerfectoUtils.scrollToMobileElement(androidcommon.getAppSliderAppSettings());
		// PerfectoUtils.verticalswipeSlow();

		// PerfectoUtils.verticalswipe();
		try {
			androidcommon.getAppSliderAppSettings().click();
		} catch (Exception e) {
			e.printStackTrace();
		}

		// androidcommon.getAppSliderAppSettings().click();
		androidcommon.getRdbEnvcert1().waitForVisible(5000);
		androidcommon.getTestBase().getDriver().findElement(By.id("com.heb.android.debug:id/rbCert1")).click();
		// androidcommon.getRdbEnvcert1().waitForVisible(5000);;
		// androidcommon.getRdbEnvcert1().click();
		PerfectoUtils.reportMessage("Selected the environment as cert1", MessageTypes.Pass);

		/*
		 * Navigate back to LoginPage androidcommon.getAppHamburger().click();
		 * if (androidcommon.getAppSliderLogin().isPresent()) {
		 * androidcommon.getAppSliderLogin().click();
		 * androidcommon.getAppSliderLogin().waitForNotPresent(3000); } else {
		 * PerfectoUtils.verticalswipe();
		 * androidcommon.getAppSliderLogout().waitForPresent(5000);
		 * androidcommon.getAppSliderLogout().click();
		 * androidcommon.getAppSliderLogout().waitForNotPresent(3000); }
		 */
	}

	/**
	 * Check for Continue button in login page, wait for it and click, and
	 * execute selectEnvironment method, If Hamburger is present, and execute
	 * selectEnvironment method.
	 */
	public static void settingEnvironmentinApp() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();

		/* Setting Environment */
		/*
		 * if (loginsplash.getLoginLblContinue().isPresent() &&
		 * ((loginsplash.getLoginLblContinue().getAttribute("hidden")).equals(
		 * "false"))) { loginsplash.getLoginLblContinue().waitForPresent(5000);
		 * loginsplash.getLoginLblContinue().click();
		 * AndroidStepDef.selectEnvironment(); } else if
		 * (androidfun.getAppHamburger().isPresent() &&
		 * ((androidfun.getAppHamburger().getAttribute("hidden")).equals("false"
		 * ))) { AndroidStepDef.selectEnvironment(); }
		 */

		if (loginsplash.getLoginLblContinue().isPresent()) {
			loginsplash.getLoginLblContinue().waitForPresent(5000);
			loginsplash.getLoginLblContinue().click();
			AndroidStepDef.selectEnvironment();
		} else if (androidfun.getAppHamburger().isPresent()) {
			AndroidStepDef.selectEnvironment();
		}

		// not checking the hidden attribute

	}

	/**
	 * Wait for login pop up alert, Enter username and Password
	 * 
	 * @param username
	 *            Username for HEB app
	 * @param pswd
	 *            Password for HEB app
	 */
	@QAFTestStep(description = "I enter valid credentials {0}{1}")
	public void iEnterValidCredentials(String username, String pswd) {
		LoginpopupTestPage loginpopup = new LoginpopupTestPage();

		loginpopup.waitForPageToLoad();
		loginpopup.getLoginpopupTxtAlerttitle().waitForPresent(5000);

		/* Passing user name and password */
		loginpopup.getLoginpopupTxtfldEmail().sendKeys(username);
		loginpopup.getLoginpopupTxtfldPassword().sendKeys(pswd);
	}

	/**
	 * Execute iEnterValidCredentials method, Click on submit button and wait
	 * for login pop up to disappear
	 * 
	 * @param username
	 *            Username for HEB app
	 * @param pswd
	 *            Password for HEB app
	 */
	@QAFTestStep(description = "I am logging in as a hot user using {0}{1} credential from guest user")
	public void iAmLoggingInAsAHotUserUsingCredentialFromGuestUser(String username, String pswd) {
		AndroidStepDefShoppingList androidStepDefShoppingList = new AndroidStepDefShoppingList();
		LoginpopupTestPage loginpopup = new LoginpopupTestPage();

		iEnterValidCredentials(username, pswd);
		androidStepDefShoppingList.iClickOnLoginSubmitButton();
		loginpopup.getLoginpopupBtnOverlaylogin().waitForNotPresent(50000);
	}

	/**
	 * Wait and Verify for Search product icon
	 */
	@QAFTestStep(description = "I should see the Search Products screen")
	public void iShouldSeeTheSearchProductsScreen() {
		AndroidcommonTestPage comTestPage = new AndroidcommonTestPage();

		comTestPage.getAppTxtSearchproducts().waitForPresent(3000);
		comTestPage.getAppTxtSearchproducts().verifyPresent();
	}

	/**
	 * Disable and Enable WiFi
	 */
	public static void checkwificonnection() {

		/* Setting Wi-Fi connection */
		java.util.Map<String, Object> params2 = new HashMap<>();
		params2.put("wifi", "disabled");
		PerfectoUtils.getDriver().executeScript("mobile:network.settings:set", params2);
		params2.put("wifi", "enabled");
		PerfectoUtils.getDriver().executeScript("mobile:network.settings:set", params2);
	}

	/**
	 * If clicked coupons is not present, scroll and If it is not present after
	 * that fail the step.
	 */
	@QAFTestStep(description = "I verify the added coupons")
	public void iVerifyTheAddedCoupons() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		String clikedcoupons = ConfigurationManager.getBundle().getString("ChoosenProduct");
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		if (dcAutoEnrolFlag.contains("true")) {
			if (!weeklygrocery.getShopingListEntryByLable(clikedcoupons).isPresent())
				AndroidStepDef.scrollToListNameInMyList(clikedcoupons, 80, 50, 2);

			if (weeklygrocery.getShopingListEntryByLable(clikedcoupons).isPresent()) {
				PerfectoUtils.reportMessage("The coupon available in selected savings tab", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("The coupon is not avaiable in selected savings tab", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("DCAutoEnrol flag is false");
		}

	}

	/**
	 * Handle Skip, If login button is present then EnterCredentialsAndLogin,
	 * else logout from app thru Hamburger icon and EnterCredentialsAndLogin
	 */
	@QAFTestStep(description = "I am a hot user for Email update")
	public void iAmAHotUserForEmailUpdate() {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		String username = getBundle().getString("hebhotuser.emailchangeuser.email");
		String pswd = getBundle().getString("hebhotuser.emailchangeuser.password");

		getBundle().setProperty("CurrentPassword", pswd);

		/*
		 * Setting Environment before execution
		 */
		// settingEnvironmentinApp();

		PerfectoUtils.getAppiumDriver().context("NATIVE_APP");
		System.out.println("Checking for Pre-login");
		loginsplash.waitForPageToLoad();

		try {
			loginsplash.getLoginBtnLogin().waitForPresent(3000);
			;
		} catch (Exception e) {
			try {
				androidfun.getAppHamburger().waitForPresent(3000);
			} catch (Exception e1) {
				handlePopup();
			}
		}

		if (loginsplash.getLoginBtnLogin().isPresent()) {
			PerfectoUtils.reportMessage("User is in Login splash page.", MessageTypes.Pass);

			/* Logging In */
			EnterCredentialsAndLogin(username, pswd);

			/*
			 * Entering the alternate credentials, if the login is not
			 * successful
			 */
			EnterAlternateCredentialsAndLogIn();

		} else if (androidfun.getAppHamburger().isPresent()) {
			PerfectoUtils.reportMessage("User has an Pre-existing session.", MessageTypes.Pass);
			androidfun.getAppHamburger().verifyPresent();
			androidfun.getAppHamburger().click();

			if (!androidfun.getAppSliderLogout().isPresent()) {
				PerfectoUtils.verticalswipe();
			}

			androidfun.getAppSliderLogout().waitForPresent(3000);
			androidfun.getAppSliderLogout().click();
			PerfectoUtils.reportMessage("Logged out.", MessageTypes.Pass);

			/* Handle re-login pop up */
			if (appCrash.getReloginTitle().isPresent()) {
				PerfectoUtils.handleReloginPopup();
			}

			/* Logging In */
			loginsplash.getLoginTxtEmail().waitForPresent(3000);
			loginsplash.getLoginTxtEmail().click();
			loginsplash.getLoginTxtEmail().clear();
			loginsplash.getLoginTxtEmail().sendKeys(username);

			loginsplash.getLoginTxtPassword().click();
			loginsplash.getLoginTxtPassword().clear();
			loginsplash.getLoginTxtPassword().sendKeys(pswd);

			loginsplash.getLoginBtnLogin().click();
			PerfectoUtils.reportMessage("Clicked login button.", MessageTypes.Pass);

			/*
			 * Entering the alternate credentials, if the login is not
			 * successful
			 */
			EnterAlternateCredentialsAndLogIn();

		} else {
			PerfectoUtils.reportMessage("Unexpected error occured. Pls try again.", MessageTypes.Fail);
		}

	}

	/**
	 * If Hamburger is not present, enter alternate credentials and login
	 */
	public void EnterAlternateCredentialsAndLogIn() {

		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();

		String alternateEmail = "";
		String username = getBundle().getString("hebhotuser.emailchangeuser.email");
		String pswd = getBundle().getString("hebhotuser.emailchangeuser.password");

		try {
			androidfun.getAppHamburger().waitForPresent(10000);
			PerfectoUtils.reportMessage("Login Successful.", MessageTypes.Pass);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Login failed. Logging in again with the alternate email ID.",
					MessageTypes.Pass);

			if (username.contains("1")) {
				alternateEmail = username.replaceAll("1@heb.com", "@heb.com");
			} else {
				alternateEmail = username.replaceAll("@heb.com", "1@heb.com");
			}

			/* Logging in with the alternate Email */
			ClearAndEnterAlternateUser(alternateEmail, pswd);
		}
	}

	/**
	 * Wait, CLick, CLear and send keys to Email, Password fields. Click Login.
	 * If Hamburger is present Pass, else Fail.
	 * 
	 * @param username
	 * @param pswd
	 */
	public void ClearAndEnterAlternateUser(String username, String pswd) {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		loginsplash.getLoginTxtEmail().waitForPresent(3000);
		loginsplash.getLoginTxtEmail().click();
		loginsplash.getLoginTxtEmail().clear();
		loginsplash.getLoginTxtEmail().sendKeys(username);
		loginsplash.getLoginTxtPassword().click();
		loginsplash.getLoginTxtPassword().clear();
		loginsplash.getLoginTxtPassword().sendKeys(pswd);
		PerfectoUtils.reportMessage("Entered alternate creadentials.", MessageTypes.Pass);
		loginsplash.getLoginBtnLogin().click();

		PerfectoUtils.reportMessage("Clicked Login button.", MessageTypes.Pass);
		loginsplash.waitForPageToLoad();

		if (androidfun.getAppHamburger().isPresent()) {
			PerfectoUtils.reportMessage("Login Successful.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Login failed.", MessageTypes.Fail);
		}
	}

	/**
	 * Click on android device back button
	 */
	@QAFTestStep(description = "I click on Cancel/ device back button")
	public void iClickOnCancelDeviceBackButton() {

		/* Clicking device back button */
		PerfectoUtils.androiddeviceback();
	}

	/**
	 * Verify Hamburger and CLick, Verify, Wait and Click Coupons. Skip the
	 * Coupons exceptions if present.
	 */
	@QAFTestStep(description = "I navigate to Coupons page from footer")
	public void iNavigateToCouponsPageFromFooter() {

		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();

		androidcommon.getAppHamburger().verifyPresent();
		androidcommon.getAppHamburger().click();
		androidcommon.getAppSliderCoupons().verifyPresent();
		androidcommon.getAppSliderCoupons().waitForPresent(3000);
		androidcommon.getAppSliderCoupons().click();
		appcrash.waitForPageToLoad();

		/* Checking the skipper for 1st navigation */
		if (appcrash.getExceptionSkipCoupons().isPresent()) {
			System.out.println("skipper is present");
			appcrash.getExceptionSkipCoupons().click();
		}
	}

	/**
	 * Wait for Login pop up, hide keyboard, Cancel the login pop up.
	 */
	@QAFTestStep(description = "I click Continue without registering link/Cancel button")
	public void iClickContinueWithoutRegisteringLink() {
		LoginpopupTestPage loginpopup = new LoginpopupTestPage();

		loginpopup.getLoginpopupTxtAlerttitle().waitForPresent(5000);
		PerfectoUtils.hidekeyboard();
		loginpopup.getLoginpopupBtnCancel().click();
		PerfectoUtils.reportMessage("Clicked Cancel button from login popup..");
	}

	/**
	 * If Skip button is present, click on it
	 */
	public static void handleSkip() {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();

		if (androidfun.getBtnSkip().isPresent()) {
			androidfun.getBtnSkip().click();
			PerfectoUtils.reportMessage("Clicking on Skip button to see login splash page", MessageTypes.Info);
		}
	}

	/**
	 * Wait for Help Page title, Verify FAQ, Privacy policy, T&C.
	 */
	@QAFTestStep(description = "I validate sections in more/help page")
	public void iValidateSectionsInMoreHelpPage() {
		HelpmoreTestPage helppage = new HelpmoreTestPage();

		helppage.getLblPagetitle().waitForPresent(5000);

		/* Verifying the properties in Help page */
		PerfectoUtils.reportMessage("Verifying the properties of Help page as a cold user", MessageTypes.Pass);
		helppage.getLblFaq().verifyPresent();
		helppage.getLblPrivacypolicy().verifyPresent();
		helppage.getLblTermandconditions().verifyPresent();
	}

	/**
	 * Wait and Click Hamburger. Verify Register button and click. Verify if
	 * First name is present.
	 */
	@QAFTestStep(description = "I click Register button from Hamburger or More")
	public void iClickRegisterButtonFromHamburger() {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		RegistrastionTestPage registration = new RegistrastionTestPage();

		androidfun.getAppHamburger().waitForPresent(8000);
		androidfun.getAppHamburger().click();
		PerfectoUtils.reportMessage("Clicked on Hamburger..");

		androidfun.getAppSliderRegister().verifyPresent();
		androidfun.getAppSliderRegister().click();
		PerfectoUtils.reportMessage("Clicked on Register button..");

		if (registration.getRegistrationTxtFirstname().isPresent()) {
			PerfectoUtils.reportMessage("Able to see registration page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see registration page", MessageTypes.Fail);
		}

	}

	/**
	 * Validate product finder page
	 */
	@QAFTestStep(description = "I validate the Orginating page browse")
	public void iValidateTheOrginatingPage() {
		CommonStepDefProductFinder productfinder = new CommonStepDefProductFinder();

		productfinder.iValidateTheProductFinderPage();
	}

	/**
	 * Wait for Products in Home page. And fail if it is not present.
	 */
	@QAFTestStep(description = "I should see the Homepage/ More screen")
	public void iShouldSeeTheHomepageMoreScreen() {
		HomeTestPage homepage = new HomeTestPage();

		try {
			homepage.getHomeLblProduct().waitForPresent(3000);
			if (homepage.getHomeLblProduct().isPresent()) {
				PerfectoUtils.reportMessage("Navigated to homepage.", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Not navigated to homepage.", MessageTypes.Fail);
			}
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error Occurer while navigating to homepage.", MessageTypes.Fail);
		}
	}

	/**
	 * Stop Image Injection, Start image injection again, CLick Scan menu
	 * button, If Scan product is present, click it. Allow permission for enable
	 * camera pop up. Handle if any App crashes happen. Stop image injection.
	 * 
	 * @param repositoryFile
	 *            Perfecto Repository path of Scan image file
	 */
	@QAFTestStep(description = "I navigate and scan the item {0} from scan products screen")
	public static void iNavigateAndScanTheItemFromScanProductsScreen(String repositoryFile) {

		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();

		/* Setting the image to "Scan" */
		String appName = ConfigurationManager.getBundle().getString("app.name");

		/* Stopping Image Injection */
		PerfectoUtils.stopimageinjection();

		PerfectoUtils.imageInjection(repositoryFile, appName);

		listDetailspage.waitForPageToLoad();
		listDetailspage.getListpageBtnScanmenu().click();
		PerfectoUtils.reportMessage("Clicked the scanner button", MessageTypes.Pass);

		/* Clicking on "Scan Products" option */
		listDetailspage.getListpageBtnScanmenu().waitForNotPresent(3000);
		if (androidcommon.getScanTxtScanproduct().isPresent()) {
			androidcommon.getScanTxtScanproduct().click();
			PerfectoUtils.reportMessage("Clicked on ScanProduct button", MessageTypes.Pass);
		}

		/* Checking whether the "Enable camera" pop-up is present */
		try {
			androidcommon.getAppPopupBtnAllowPermission().waitForPresent(5000);
			androidcommon.getAppPopupBtnAllowPermission().click();
		} catch (Exception e) {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "Unfortunately, H-E-B has stopped.");
			String errmsg1 = (String) androidcommon.getTestBase().getDriver().executeScript("mobile:text:find",
					params1);

			if (errmsg1.equals("true")) {
				PerfectoUtils.reportMessage("Scan Product Failed due to 'Unfortunately, H-E-B has stopped.'",
						MessageTypes.Fail);
				params1.put("content", "OK");
				androidcommon.getTestBase().getDriver().executeScript("mobile:text:select", params1);
			} else {
				params1.clear();
				params1.put("content", "0 results for");
				String errmsg2 = (String) androidcommon.getTestBase().getDriver().executeScript("mobile:text:find",
						params1);
				if (errmsg2.equals("true")) {
					PerfectoUtils.reportMessage("Scan Product Failed due to '0 result'", MessageTypes.Fail);
					androidcommon.getTestBase().getDriver().executeScript("mobile:text:select", params1);
				} else {
					e.printStackTrace();
				}
			}

		}
		/* Stopping Image Injection */
		PerfectoUtils.stopimageinjection();
	}

	/*
	 * @QAFTestStep(description = "I am an cold user without setting store")
	 * public void iAmAnColdUserWithoutSettingStore() {
	 * 
	 * LoginsplashTestPage loginsplash = new LoginsplashTestPage();
	 * AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
	 * AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();
	 * 
	 * handleSkip(); try {
	 * loginsplash.getLoginLblContinue().waitForPresent(5000); } catch
	 * (Exception e) { androidfun.getAppHamburger().waitForPresent(10000);
	 * 
	 *//**************** Setting Environment before execution ***********//*
																			 * //
																			 * settingEnvironmentinApp
																			 * (
																			 * )
																			 * ;
																			 * 
																			 * if
																			 * (androidfun
																			 * .
																			 * getAppHamburger
																			 * (
																			 * )
																			 * .
																			 * isPresent
																			 * (
																			 * )
																			 * &&
																			 * (
																			 * (
																			 * androidfun
																			 * .
																			 * getAppHamburger
																			 * (
																			 * )
																			 * .
																			 * getAttribute
																			 * (
																			 * "hidden"
																			 * )
																			 * )
																			 * .
																			 * equals
																			 * (
																			 * "false"
																			 * )
																			 * )
																			 * )
																			 * {
																			 * Reporter
																			 * .
																			 * log(
																			 * "User has an Pre-existing session."
																			 * ,
																			 * MessageTypes
																			 * .
																			 * Pass
																			 * )
																			 * ;
																			 * androidfun
																			 * .
																			 * getAppHamburger
																			 * (
																			 * )
																			 * .
																			 * click
																			 * (
																			 * )
																			 * ;
																			 * PerfectoUtils
																			 * .
																			 * verticalswipe
																			 * (
																			 * )
																			 * ;
																			 * if
																			 * (
																			 * !
																			 * androidfun
																			 * .
																			 * getAppSliderLogout
																			 * (
																			 * )
																			 * .
																			 * isPresent
																			 * (
																			 * )
																			 * )
																			 * {
																			 * PerfectoUtils
																			 * .
																			 * verticalswipe
																			 * (
																			 * )
																			 * ;
																			 * }
																			 * androidfun
																			 * .
																			 * getAppSliderLogout
																			 * (
																			 * )
																			 * .
																			 * waitForPresent
																			 * (
																			 * 5000
																			 * )
																			 * ;
																			 * androidfun
																			 * .
																			 * getAppSliderLogout
																			 * (
																			 * )
																			 * .
																			 * click
																			 * (
																			 * )
																			 * ;
																			 * 
																			 * Handle
																			 * re
																			 * -
																			 * login
																			 * pop
																			 * up
																			 * if
																			 * (appCrash
																			 * .
																			 * getReloginTitle
																			 * (
																			 * )
																			 * .
																			 * isPresent
																			 * (
																			 * )
																			 * )
																			 * {
																			 * Reporter
																			 * .
																			 * log(
																			 * "Re-login popup found."
																			 * ,
																			 * MessageTypes
																			 * .
																			 * Pass
																			 * )
																			 * ;
																			 * PerfectoUtils
																			 * .
																			 * handleReloginPopup
																			 * (
																			 * )
																			 * ;
																			 * }
																			 * }
																			 * else
																			 * {
																			 * Reporter
																			 * .
																			 * log(
																			 * "User is in Login splash page."
																			 * ,
																			 * MessageTypes
																			 * .
																			 * Pass
																			 * )
																			 * ;
																			 * }
																			 * }
																			 * 
																			 * loginsplash
																			 * .
																			 * getLoginLblContinue
																			 * (
																			 * )
																			 * .
																			 * waitForPresent
																			 * (
																			 * 5000
																			 * )
																			 * ;
																			 * loginsplash
																			 * .
																			 * getLoginLblContinue
																			 * (
																			 * )
																			 * .
																			 * click
																			 * (
																			 * )
																			 * ;
																			 * Reporter
																			 * .
																			 * log(
																			 * "Logged in as a cold user."
																			 * ,
																			 * MessageTypes
																			 * .
																			 * Pass
																			 * )
																			 * ;
																			 * }
																			 */

	/**
	 * Verify home page is displayed
	 */
	@QAFTestStep(description = "I see home page")
	public void iShouldSeeHome() {
		AndroidcommonTestPage androidCommon = new AndroidcommonTestPage();
		HomeTestPage homePage = new HomeTestPage();

		if (androidCommon.getAppHamburger().isPresent())
			// homePage.getImageHeblogo().waitForPresent(3000);
			// if(homePage.getImageHeblogo().isPresent())
			PerfectoUtils.reportMessage("Home page is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Home page is not displayed", MessageTypes.Fail);

	}

	/**
	 * Verify home page hero image is displayed
	 */
	@QAFTestStep(description = "I verify the home hero image")
	public void iVerifyTheHomeHeroImage() {
		HomeTestPage homePage = new HomeTestPage();

		homePage.getImgHomeHero().waitForPresent(3000);
		if (homePage.getImgHomeHero().isPresent())
			PerfectoUtils.reportMessage("Home page hero image is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Home page hero image is not displayed", MessageTypes.Fail);

	}

	/**
	 * Verify home page top slot is displayed
	 */
	@QAFTestStep(description = "I verify the top slot")
	public void iVerifyTopSlot() {
		HomeTestPage homePage = new HomeTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		ProductlandingTestPage productlanding = new ProductlandingTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		AndroidStepDefWeeklyAds androidStepDefWeeklyAd = new AndroidStepDefWeeklyAds();
		WeeklyadslandingTestPage weeklyadlanding = new WeeklyadslandingTestPage();

		homePage.getImgTopslot().waitForPresent(3000);
		if (homePage.getImgTopslot().isPresent())
			PerfectoUtils.reportMessage("Home page top slot is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Home page top slot  is not displayed", MessageTypes.Fail);

		// Verify coupons
		homePage.getIconTopslotCoupon().verifyPresent();
		homePage.getLblTopslotCoupon().verifyPresent();
		if (homePage.getLblTopslotCoupon().getText().contains("Coupons"))
			PerfectoUtils.reportMessage("Coupons option is available in top slot");
		else
			PerfectoUtils.reportMessage("Coupons option is available in top slot", MessageTypes.Fail);

		// Verify products
		homePage.getIconTopslotProducts().verifyPresent();
		homePage.getLblTopslotProducts().verifyPresent();
		if (homePage.getLblTopslotProducts().getText().contains("Products"))
			PerfectoUtils.reportMessage("Products option is available in top slot");
		else
			PerfectoUtils.reportMessage("Products option is available in top slot", MessageTypes.Fail);

		// Verify weekly ad
		homePage.getIconTopslotWeeklyad().verifyPresent();
		homePage.getLblTopslotWeeklyad().verifyPresent();
		if (homePage.getLblTopslotWeeklyad().getText().contains("Weekly Ad"))
			PerfectoUtils.reportMessage("Weekly Ad option is available in top slot");
		else
			PerfectoUtils.reportMessage("Weekly Ad option is available in top slot", MessageTypes.Fail);

		// Verify coupon page navigation
		homePage.getIconTopslotCoupon().click();
		/* Checking the skipper for 1st navigation */
		if (appcrash.getExceptionSkipCoupons().isPresent()) {
			appcrash.getExceptionSkipCoupons().click();
		}

		// Verify coupon selection page
		couponsselection.getCouponselectionLblAllcoupons().waitForPresent(5000);
		if (couponsselection.getCouponselectionLblAllcoupons().isPresent()) {
			PerfectoUtils.reportMessage("Coupons selection page displayed successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons selection page is not displayed", MessageTypes.Fail);
		}

		PerfectoUtils.androiddeviceback();

		// Verify products page navigation
		homePage.getIconTopslotProducts().waitForPresent(3000);
		homePage.getIconTopslotProducts().click();
		productlanding.getProductsLblPagename().waitForPresent(3000);
		if (productlanding.getProductsLblPagename().isPresent()) {
			PerfectoUtils.reportMessage("Products page displayed successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Products page is not displayed", MessageTypes.Fail);
		}

		PerfectoUtils.androiddeviceback();

		// Verify weekly adds page navigation
		homePage.getIconTopslotWeeklyad().waitForPresent(3000);
		homePage.getIconTopslotWeeklyad().click();

		if (storelocator.getStorelocatorBtnAllow().isPresent()) {
			storelocator.getStorelocatorBtnAllow().click();
		}

		try {
			storelocatorErrorHandle();
		} catch (Exception e) {
			// ignore..
		}
		if (storelocator.getStorelocatorLblRefine().isPresent()) {
			androidStepDefWeeklyAd.iChooseAnStoreFromTheStoreListForGettingWeeklyads();
		}

		weeklyadlanding.getWeeklyadLblPageTitle().waitForPresent(6000);
		if (weeklyadlanding.getWeeklyadLblPageTitle().isPresent())
			PerfectoUtils.reportMessage("Navigated to Weekly Ads landing page.", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not navigated to Weekly Ads landing page.", MessageTypes.Fail);

	}

	/**
	 * Verify the sub menu order as cold user
	 */
	@QAFTestStep(description = "I verify the sub menu order as cold user")
	public void iVerifyTheSubMenuOrderAsColdUser() {
		HomeTestPage homePage = new HomeTestPage();
		boolean orderMatch1 = false, orderMatch2 = false, orderMatch3 = false, orderMatch4 = false;

		homePage.getLblHebBarcode().verifyNotPresent();
		homePage.getHomeLblShoppingList().verifyPresent();
		if (!homePage.getLblPharmacy().isPresent())
			PerfectoUtils.verticalswipeSlow();
		homePage.getLblPharmacy().verifyPresent();

		if ((homePage.getHomeLblShoppingList().isPresent()) && (homePage.getLblPharmacy().isPresent()))
			orderMatch1 = verifyElement1AboveElement2(homePage.getHomeLblShoppingList(), homePage.getLblPharmacy());

		PerfectoUtils.verticalswipe();
		homePage.getHomeLblStoreLocator().verifyPresent();
		homePage.getHomeLblRecipes().verifyPresent();
		homePage.getHomeLblShipToHome().verifyPresent();

		if ((homePage.getLblPharmacy().isPresent()) && (homePage.getHomeLblStoreLocator().isPresent()))
			orderMatch2 = verifyElement1AboveElement2(homePage.getLblPharmacy(), homePage.getHomeLblStoreLocator());

		if ((homePage.getHomeLblStoreLocator().isPresent()) && (homePage.getHomeLblRecipes().isPresent()))
			orderMatch3 = verifyElement1AboveElement2(homePage.getHomeLblStoreLocator(), homePage.getHomeLblRecipes());

		if ((homePage.getHomeLblRecipes().isPresent()) && (homePage.getHomeLblShipToHome().isPresent()))
			orderMatch4 = verifyElement1AboveElement2(homePage.getHomeLblRecipes(), homePage.getHomeLblShipToHome());

		if (orderMatch1 && orderMatch2 && orderMatch3 && orderMatch4)
			PerfectoUtils.reportMessage("Sub menu order is expected..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Sub menu order is not expected..", MessageTypes.Fail);

	}

	public boolean verifyElement1AboveElement2(QAFWebElement element1, QAFWebElement element2) {
		boolean orderMatch = true;
		if (PerfectoUtils.verifyOrderOfElements(element1, element2))
			PerfectoUtils.reportMessage(element1.getText() + " and " + element2.getText() + " order is expected");
		else {
			PerfectoUtils.reportMessage(element1.getText() + " and " + element2.getText() + " order is not expected");
			orderMatch = false;
		}
		return orderMatch;
	}

	/**
	 * Verify the sub menu order as hot user with curbside
	 */
	@QAFTestStep(description = "I verify the sub menu order as hot user with curbside store")
	public void iVerifyTheSubMenuOrderAsHotUser() {
		HomeTestPage homePage = new HomeTestPage();
		boolean orderMatch1 = true, orderMatch2 = false, orderMatch3 = false, orderMatch4 = false, orderMatch5 = false,
				orderMatch6 = false;
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (dcAutoEnrolFlag.contains("true")) {
			homePage.getLblRedeemCoupon().verifyPresent();
			homePage.getLblCurbsidePickup().verifyPresent();
			if ((homePage.getLblRedeemCoupon().isPresent()) && (homePage.getLblCurbsidePickup().isPresent()))
				orderMatch1 = verifyElement1AboveElement2(homePage.getLblRedeemCoupon(),
						homePage.getLblCurbsidePickup());
		}
		homePage.getLblCurbsidePickup().verifyPresent();
		if (!homePage.getHomeLblShoppingList().isPresent())
			PerfectoUtils.verticalswipeSlow();

		homePage.getHomeLblShoppingList().verifyPresent();

		if ((homePage.getLblCurbsidePickup().isPresent()) && (homePage.getHomeLblShoppingList().isPresent()))
			orderMatch2 = verifyElement1AboveElement2(homePage.getLblCurbsidePickup(),
					homePage.getHomeLblShoppingList());

		PerfectoUtils.verticalswipe();
		homePage.getLblPharmacy().verifyPresent();
		homePage.getHomeLblStoreLocator().verifyPresent();
		homePage.getHomeLblRecipes().verifyPresent();
		homePage.getHomeLblShipToHome().verifyPresent();

		if ((homePage.getHomeLblShoppingList().isPresent()) && (homePage.getLblPharmacy().isPresent()))
			orderMatch3 = verifyElement1AboveElement2(homePage.getHomeLblShoppingList(), homePage.getLblPharmacy());

		if ((homePage.getLblPharmacy().isPresent()) && (homePage.getHomeLblStoreLocator().isPresent()))
			orderMatch4 = verifyElement1AboveElement2(homePage.getLblPharmacy(), homePage.getHomeLblStoreLocator());

		if ((homePage.getHomeLblStoreLocator().isPresent()) && (homePage.getHomeLblRecipes().isPresent()))
			orderMatch5 = verifyElement1AboveElement2(homePage.getHomeLblStoreLocator(), homePage.getHomeLblRecipes());

		if ((homePage.getHomeLblRecipes().isPresent()) && (homePage.getHomeLblShipToHome().isPresent()))
			orderMatch6 = verifyElement1AboveElement2(homePage.getHomeLblRecipes(), homePage.getHomeLblShipToHome());

		if (orderMatch1 && orderMatch2 && orderMatch3 && orderMatch4 && orderMatch5 && orderMatch6)
			PerfectoUtils.reportMessage("Sub menu order is expected..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Sub menu order is not expected..", MessageTypes.Fail);

	}

	/**
	 * Verify the sub menu order as hot user without curbside
	 */
	@QAFTestStep(description = "I verify the sub menu order as hot user without curbside store")
	public void iVerifyTheSubMenuOrderAsHotUserWithoutCurbside() {
		HomeTestPage homePage = new HomeTestPage();
		boolean orderMatch1 = true, orderMatch2 = false, orderMatch3 = false, orderMatch4 = false, orderMatch5 = false,
				orderMatch6 = false;
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (dcAutoEnrolFlag.contains("true")) {
			homePage.getLblRedeemCoupon().verifyPresent();
			homePage.getHomeLblShoppingList().verifyPresent();
			if ((homePage.getLblRedeemCoupon().isPresent()) && (homePage.getHomeLblShoppingList().isPresent()))
				orderMatch1 = verifyElement1AboveElement2(homePage.getLblRedeemCoupon(),
						homePage.getHomeLblShoppingList());
		}

		homePage.getLblCurbsidePickup().verifyNotPresent();
		homePage.getHomeLblShoppingList().verifyPresent();

		if (!homePage.getLblPharmacy().isPresent())
			PerfectoUtils.verticalswipeSlow();

		PerfectoUtils.verticalswipe();
		homePage.getLblPharmacy().verifyPresent();
		homePage.getHomeLblStoreLocator().verifyPresent();
		homePage.getHomeLblRecipes().verifyPresent();
		homePage.getHomeLblShipToHome().verifyPresent();

		if ((homePage.getHomeLblShoppingList().isPresent()) && (homePage.getLblPharmacy().isPresent()))
			orderMatch2 = verifyElement1AboveElement2(homePage.getHomeLblShoppingList(), homePage.getLblPharmacy());

		if ((homePage.getLblPharmacy().isPresent()) && (homePage.getHomeLblStoreLocator().isPresent()))
			orderMatch3 = verifyElement1AboveElement2(homePage.getLblPharmacy(), homePage.getHomeLblStoreLocator());

		if ((homePage.getHomeLblStoreLocator().isPresent()) && (homePage.getHomeLblRecipes().isPresent()))
			orderMatch4 = verifyElement1AboveElement2(homePage.getHomeLblStoreLocator(), homePage.getHomeLblRecipes());

		if ((homePage.getHomeLblRecipes().isPresent()) && (homePage.getHomeLblShipToHome().isPresent()))
			orderMatch5 = verifyElement1AboveElement2(homePage.getHomeLblRecipes(), homePage.getHomeLblShipToHome());

		if (orderMatch1 && orderMatch2 && orderMatch3 && orderMatch4 && orderMatch5)
			PerfectoUtils.reportMessage("Sub menu order is expected..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Sub menu order is not expected..", MessageTypes.Fail);

	}

	/**
	 * Verify the sub menu navigation as hot user with curbside
	 */
	@QAFTestStep(description = "I verify the sub menu navigations as hot user")
	public void iVerifyTheSubMenuNavigationAsHotUserWithCurbside() {
		HomeTestPage homePage = new HomeTestPage();
		AndroidStepDefMyaccount androidMyacc = new AndroidStepDefMyaccount();
		MylistTestPage mylistpage = new MylistTestPage();
		CommonSteps commonsteps = new CommonSteps();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		RecipeslandingTestPage recipepage = new RecipeslandingTestPage();
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		// Verify redeem coupon page
		if (dcAutoEnrolFlag.contains("true")) {
			homePage.getLblRedeemCoupon().waitForPresent(3000);
			homePage.getLblRedeemCoupon().click();
			androidMyacc.iValidateAllElementsInMyHEBBarcodePage();
		}
		// PerfectoUtils.androiddeviceback();

		// Verify curbside page
		homePage.getLblCurbsidePickup().waitForPresent(3000);
		homePage.getLblCurbsidePickup().click();
		homePage.getLblCurbsideAlert().waitForPresent(3000);
		homePage.getLblCurbsideAlert().verifyPresent();
		homePage.getLblCurbsideAlertbody().verifyPresent();
		homePage.getLblCurbsideAlertcancel().verifyPresent();
		homePage.getLblCurbsideAlertok().verifyPresent();
		homePage.getLblCurbsideAlertcancel().click();

		if (!homePage.getHomeLblShoppingList().isPresent())
			PerfectoUtils.verticalswipeSlow();

		// Verify My list page
		homePage.getHomeLblShoppingList().waitForPresent(3000);
		homePage.getHomeLblShoppingList().click();

		mylistpage.getMyListLblPagetitle().waitForPresent(5000);
		if (mylistpage.getMyListLblPagetitle().isPresent())
			PerfectoUtils.reportMessage("Navigated to My lists page.", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not navigated to My lists page", MessageTypes.Fail);

		PerfectoUtils.androiddeviceback();
		homePage.getHomeLblShoppingList().waitForPresent(3000);
		PerfectoUtils.verticalswipe();

		// Verify Pharmacy page
		homePage.getLblPharmacy().click();
		commonsteps.verifyPharmacyPage();
		PerfectoUtils.androiddeviceback();

		// Verify store locator
		homePage.getHomeLblStoreLocator().waitForPresent(3000);
		homePage.getHomeLblStoreLocator().click();

		/* Store locator error handle */
		storelocatorErrorHandle();

		storelocator.getStorelocatorLblRefine().waitForPresent(5000);
		if (storelocator.getStorelocatorLblRefine().isPresent())
			PerfectoUtils.reportMessage("Navigated to Store locator page.", MessageTypes.Pass);

		PerfectoUtils.androiddeviceback();

		// Verify recipe page
		homePage.getHomeLblRecipes().waitForPresent(3000);
		homePage.getHomeLblRecipes().click();
		if (recipepage.getRecipesFeatured().isPresent())
			PerfectoUtils.reportMessage("Navigated to recipe page", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not Navigated to recipe page", MessageTypes.Fail);

		PerfectoUtils.androiddeviceback();

		// Verify ship to home
		homePage.getHomeLblShipToHome().waitForPresent(3000);
		homePage.getHomeLblShipToHome().click();

		homePage.getLblCurbsideAlert().waitForPresent(5000);
		homePage.getLblShiptohomeAlertbody().verifyPresent();
		homePage.getLblCurbsideAlertcancel().click();

	}

	/**
	 * Verify the sub menu navigation as cold user
	 */
	@QAFTestStep(description = "I verify the sub menu navigations as cold user")
	public void iVerifyTheSubMenuNavigationAsColdUser() {
		HomeTestPage homePage = new HomeTestPage();
		AndroidStepDefMyaccount androidMyacc = new AndroidStepDefMyaccount();
		MylistTestPage mylistpage = new MylistTestPage();
		CommonSteps commonsteps = new CommonSteps();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		RecipeslandingTestPage recipepage = new RecipeslandingTestPage();

		// Verify My list page
		homePage.getHomeLblShoppingList().waitForPresent(3000);
		homePage.getHomeLblShoppingList().click();

		mylistpage.getMyListLblPagetitle().waitForPresent(5000);
		if (mylistpage.getMyListLblPagetitle().isPresent())
			PerfectoUtils.reportMessage("Navigated to My lists page.", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not navigated to My lists page", MessageTypes.Fail);

		PerfectoUtils.androiddeviceback();
		homePage.getHomeLblShoppingList().waitForPresent(3000);

		// Verify Pharmacy page
		if (!homePage.getLblPharmacy().isPresent())
			PerfectoUtils.verticalswipeSlow();
		homePage.getLblPharmacy().click();
		commonsteps.verifyPharmacyPage();
		PerfectoUtils.androiddeviceback();
		PerfectoUtils.verticalswipe();

		// Verify store locator
		homePage.getHomeLblStoreLocator().waitForPresent(3000);
		homePage.getHomeLblStoreLocator().click();

		/* Store locator error handle */
		storelocatorErrorHandle();

		storelocator.getStorelocatorLblRefine().waitForPresent(5000);
		if (storelocator.getStorelocatorLblRefine().isPresent())
			PerfectoUtils.reportMessage("Navigated to Store locator page.", MessageTypes.Pass);

		PerfectoUtils.androiddeviceback();

		// Verify recipe page
		homePage.getHomeLblRecipes().waitForPresent(5000);
		homePage.getHomeLblRecipes().click();
		if (recipepage.getRecipesFeatured().isPresent())
			PerfectoUtils.reportMessage("Navigated to recipe page", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Not Navigated to recipe page", MessageTypes.Fail);

		PerfectoUtils.androiddeviceback();

		// Verify ship to home
		homePage.getHomeLblShipToHome().waitForPresent(3000);
		homePage.getHomeLblShipToHome().click();

		homePage.getLblCurbsideAlert().waitForPresent(5000);
		homePage.getLblShiptohomeAlertbody().verifyPresent();
		homePage.getLblCurbsideAlertcancel().click();

	}

	/**
	 * Verify the tool bar as cold user
	 */
	@QAFTestStep(description = "I verify the tool bar as cold user")
	public void iVerifyTheToolsBarAsColdUser() {
		HomeTestPage homePage = new HomeTestPage();
		AndroidcommonTestPage comTestPage = new AndroidcommonTestPage();
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();

		homePage.getHomeimgBarcodemodal().verifyNotPresent();
		homePage.getHomeIconSearch().verifyPresent();
		homePage.getHomeIconSearch().click();
		homePage.getHomeSearchBox().waitForPresent(3000);
		homePage.getHomeSearchBox().verifyPresent();
		listDetailspage.getListpageBtnScanmenu().verifyPresent();
	}

	/**
	 * Verify the tool bar as hot user
	 */
	@QAFTestStep(description = "I verify the tool bar as hot user")
	public void iVerifyTheToolsBarAsHotUser() {
		HomeTestPage homePage = new HomeTestPage();
		AndroidcommonTestPage comTestPage = new AndroidcommonTestPage();
		ListdetailsTestPage listDetailspage = new ListdetailsTestPage();
		AndroidStepDefMyaccount androidMyacc = new AndroidStepDefMyaccount();
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (dcAutoEnrolFlag.contains("true")) {
			homePage.getHomeimgBarcodemodal().waitForPresent(3000);
			homePage.getHomeimgBarcodemodal().verifyPresent();
			homePage.getHomeimgBarcodemodal().click();
			androidMyacc.iValidateAllElementsInMyHEBBarcodePage();
		} else {
			homePage.getHomeimgBarcodemodal().verifyNotPresent();
		}
		homePage.getHomeIconSearch().waitForPresent(3000);
		homePage.getHomeIconSearch().verifyPresent();
		homePage.getHomeIconSearch().click();
		homePage.getHomeSearchBox().waitForPresent(3000);
		homePage.getHomeSearchBox().verifyPresent();
		listDetailspage.getListpageBtnScanmenu().verifyPresent();
		homePage.gethomeimgNewbarcode().verifyNotPresent();
	}

	/**
	 * Verify the tool bar as hot user
	 */
	@QAFTestStep(description = "I verify the app slider as hot user")
	public void iVerifyTheAppSliderAsHotUser() {
		HomeTestPage homePage = new HomeTestPage();
		AndroidcommonTestPage comTestPage = new AndroidcommonTestPage();

		ArrayList<String> homeMenus = new ArrayList<String>();
		homeMenus.add("Home");
		homeMenus.add(homePage.getLblTopslotCoupon().getText());
		homeMenus.add(homePage.getLblTopslotProducts().getText());
		homeMenus.add(homePage.getLblTopslotWeeklyad().getText());
		int menuSize = homePage.getHomeMenuList().size();
		for (int i = 0; i < menuSize; i++) {
			homeMenus.add(homePage.getHomeMenuList().get(i).getText());
		}
		int listSize = homeMenus.size();
		PerfectoUtils.verticalswipe();
		menuSize = homePage.getHomeMenuList().size();
		for (int i = 0; i < menuSize; i++) {
			if (!homeMenus.contains(homePage.getHomeMenuList().get(i).getText())) {
				homeMenus.add(homePage.getHomeMenuList().get(i).getText());
				listSize++;
			}
		}
		PerfectoUtils.horizontalswipe();

		comTestPage.getAppHamburger().click();
		int j = 0;
		while ((!comTestPage.getAppSliderLogout().isPresent()) && (j < 4)) {
			PerfectoUtils.verticalswipeSlow(0.80, 0.75);
			j++;
		}
		ArrayList<String> appSliderMenus = new ArrayList<String>();
		int sliderSize = homeMenus.size();
		for (int i = 0; i < sliderSize; i++) {
			appSliderMenus.add(comTestPage.getLblAppsliderMenuList().get(i).getText());
		}
		System.out.println(homeMenus);
		System.out.println(appSliderMenus);
		if (homeMenus.containsAll(appSliderMenus))
			PerfectoUtils.reportMessage("App slider contains all home page menus..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("App slider not contains all home page menus..", MessageTypes.Fail);

		comTestPage.getAppSliderHome().click();

	}

	/**
	 * Verify the tool bar as hot user
	 */
	@QAFTestStep(description = "I verify the app slider as cold user")
	public void iVerifyTheAppSliderAsColdUser() {
		HomeTestPage homePage = new HomeTestPage();
		AndroidcommonTestPage comTestPage = new AndroidcommonTestPage();

		ArrayList<String> homeMenus = new ArrayList<String>();
		homeMenus.add("Home");
		homeMenus.add(homePage.getLblTopslotCoupon().getText());
		homeMenus.add(homePage.getLblTopslotProducts().getText());
		homeMenus.add(homePage.getLblTopslotWeeklyad().getText());
		PerfectoUtils.verticalswipe();
		int menuSize = homePage.getHomeMenuList().size();
		for (int i = 0; i < menuSize; i++) {
			homeMenus.add(homePage.getHomeMenuList().get(i).getText());
		}
		PerfectoUtils.horizontalswipe();

		comTestPage.getAppHamburger().click();
		PerfectoUtils.verticalswipe();

		ArrayList<String> appSliderMenus = new ArrayList<String>();
		int sliderSize = homeMenus.size();
		for (int i = 0; i < sliderSize; i++) {
			appSliderMenus.add(comTestPage.getLblAppsliderMenuList().get(i).getText());
		}
		System.out.println(homeMenus);
		System.out.println(appSliderMenus);
		if (homeMenus.containsAll(appSliderMenus))
			PerfectoUtils.reportMessage("App slider contains all home page menus..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("App slider not contains all home page menus..", MessageTypes.Fail);

		comTestPage.getAppSliderHome().click();

	}

	/**
	 * Verify user able to navigate to home page
	 */
	@QAFTestStep(description = "I navigate to home page")
	public void iNavigateToHomePage() {
		HomeTestPage homepage = new HomeTestPage();
		AndroidcommonTestPage comTestPage = new AndroidcommonTestPage();

		comTestPage.getAppHamburger().verifyPresent();
		comTestPage.getAppHamburger().click();

		comTestPage.getAppSliderHome().waitForPresent(3000);
		comTestPage.getAppSliderHome().verifyPresent();
		comTestPage.getAppSliderHome().click();

		PerfectoUtils.reportMessage("Clicked home options from 3 bar menu..");

	}

	/**
	 * Click on show password icon and validate
	 */
	@QAFTestStep(description = "I validate the show password functionality")
	public static void iValidateTheShowPasswordFunctionality() {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		String bfrShowPassword = getBundle().getString("currentPassword");
		loginsplash.getImgShowpassword().waitForPresent(3000);
		loginsplash.getImgShowpassword().click();
		String afterShowPassword = loginsplash.getLoginTxtPassword().getText();

		if (bfrShowPassword.equals(afterShowPassword)) {
			PerfectoUtils.reportMessage(
					"Show Password functionality works fine. Showing password as " + afterShowPassword,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Show Password functionality does not work. Mismatch between the entered and displaying password. Showing password as "
							+ afterShowPassword,
					MessageTypes.Fail);
		}

		loginsplash.getLoginBtnLogin().verifyPresent();
		loginsplash.getLoginBtnLogin().click();

		PerfectoUtils.reportMessage("Logged in after clicking show password", MessageTypes.Pass);
	}

	/**
	 * Clicking on Login button form More option.
	 */
	@QAFTestStep(description = "I click login button from Hamburger or More")
	public void iClickLoginButtonFromHamburger() {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		LoginsplashTestPage loginspalshpage = new LoginsplashTestPage();

		androidfun.getAppHamburger().waitForPresent(8000);
		androidfun.getAppHamburger().click();
		PerfectoUtils.reportMessage("Clicked on Hamburger..");

		androidfun.getAppSliderLogin().verifyPresent();
		androidfun.getAppSliderLogin().click();
		PerfectoUtils.reportMessage("Clicked on Login button..");

		if (loginspalshpage.getLoginTxtEmail().isPresent()) {
			PerfectoUtils.reportMessage("Able to see Login page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see Login page", MessageTypes.Fail);
		}

	}

	/**
	 * This method handles the popup such as skip, software update and allow
	 * popup
	 */
	public static void handlePopup() {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		if (androidfun.getBtnSkip().isPresent()) {
			androidfun.getBtnSkip().click();
			PerfectoUtils.reportMessage("Clicking on Skip button to see login splash page", MessageTypes.Info);
		} else if (appCrash.getSoftwareUpdatePopup().isPresent()) {
			appCrash.getSoftwareUpdateLater().click();
		} else if (appCrash.getAllowPopup().isPresent()) {
			appCrash.getAllowPopup().click();
			PerfectoUtils.reportMessage("Allow is enabled");
		}
	}

	@QAFTestStep(description = "I am a VPP user using {0}{1} credential")
	public static void iAmAVPPUserUsingCredential(String username, String pswd) {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		getBundle().setProperty("CurrentPassword", pswd);

		/* Setting Environment before execution */
		// settingEnvironmentinApp();

		PerfectoUtils.getAppiumDriver().context("NATIVE_APP");
		try {
			loginsplash.getLoginBtnLogin().waitForPresent(3000);
			;
		} catch (Exception e) {
			try {
				androidfun.getAppHamburger().waitForPresent(3000);
			} catch (Exception e1) {
				handlePopup();
			}
		}

		// settingEnvironmentinApp();

		if (loginsplash.getLoginBtnLogin().isPresent()) {
			PerfectoUtils.reportMessage("User is in Login splash page.", MessageTypes.Pass);
			EnterCredentialsAndLogin(username, pswd);
		} else if (androidfun.getAppHamburger().isPresent()) {
			PerfectoUtils.reportMessage("User has an Pre-existing session.", MessageTypes.Pass);
			androidfun.getAppHamburger().click();
			if (!androidfun.getAppSliderLogout().isPresent()) {
				PerfectoUtils.verticalswipe();
			}
			androidfun.getAppSliderLogout().waitForPresent(3000);
			androidfun.getAppSliderLogout().click();
			PerfectoUtils.reportMessage("Logged out.", MessageTypes.Pass);

			/* Handle re-login pop up */
			if (appCrash.getReloginTitle().isPresent()) {
				PerfectoUtils.handleReloginPopup();
			}

			/* Logging In */
			EnterCredentialsAndLogin(username, pswd);
		} else {
			PerfectoUtils.reportMessage("Unexpected error occured. Pls try again.", MessageTypes.Fail);
		}
	}

	/**
	 * Wait, Verify and Click Hamburger icon. Click on Hambuger again if it is
	 * not visible. Wait and Click on donations.
	 */
	@QAFTestStep(description = "I navigate to donation page")
	public void iNavigateToDonationPage() {
		AndroidcommonTestPage androidfunction = new AndroidcommonTestPage();

		/* Click hamburger */
		androidfunction.getAppHamburger().waitForPresent(80000);
		androidfunction.getAppHamburger().verifyPresent();
		androidfunction.getAppHamburger().click();

		androidfunction.getAppSliderHome().waitForPresent(50000);
		if (!androidfunction.getAppSliderHome().isPresent()) {
			androidfunction.getAppHamburger().waitForPresent(3000);
			androidfunction.getAppHamburger().click();
		}

		/* Click donations Link */
		androidfunction.getAppSliderDonations().waitForPresent(50000);
		androidfunction.getAppSliderDonations().verifyPresent();
		androidfunction.getAppSliderDonations().click();
		PerfectoUtils.reportMessage("Clicked on donations.", MessageTypes.Pass);
	}

	/**
	 * LinkView for donations page second item
	 */
	@QAFTestStep(description = "Verify donations Second item in the list")
	public void verifyDonationsSecondItemInTheList() {
		HomeTestPage homePage = new HomeTestPage();

		homePage.getHomeLblDonationsSecond().waitForPresent(50000);
		String donName = homePage.getHomeLblDonationsSecond().getText();

		if (donName.equalsIgnoreCase("Sutherland Springs Donations"))
			PerfectoUtils.reportMessage("Donations first item in the list", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Donations not first item in the list", MessageTypes.Fail);
	}

	/**
	 * LinkView for donations page first item
	 */
	@QAFTestStep(description = "Verify donations first item in the list")
	public void verifyDonationsFirstItemInTheList() {
		HomeTestPage homePage = new HomeTestPage();

		homePage.getHomeLblDonationsFirst().waitForPresent(50000);
		String donName = homePage.getHomeLblDonationsFirst().getText();

		if (donName.equalsIgnoreCase("Sutherland Springs Donations"))
			PerfectoUtils.reportMessage("Donations first item in the list", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Donations not first item in the list", MessageTypes.Fail);
	}

	/**
	 * Verify donations in the left nav drawer
	 */
	@QAFTestStep(description = "Verify donations in the left nav drawer")
	public void verifyDonationsInTheLeftNavdDrawer() {

		iNavigateToDonationPage();
		CommonSteps.validateDialogBoxOnHomePage();
		CommonSteps.iClickOnOK();
		CommonSteps.verifyDonationsPageOpensInTheMobileWebBrowse();
	}

}
