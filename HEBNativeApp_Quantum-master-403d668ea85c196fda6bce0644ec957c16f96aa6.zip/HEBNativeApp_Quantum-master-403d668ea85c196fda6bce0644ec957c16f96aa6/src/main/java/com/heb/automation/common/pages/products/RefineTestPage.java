package com.heb.automation.common.pages.products;

import java.util.List;

import com.heb.automation.common.components.ProductResult;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RefineTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "productsrefine.txt.pagetitle")
	private QAFWebElement refineTxtPagetitle;
	@FindBy(locator = "productsrefine.btn.done")
	private QAFWebElement refineBtnDone;
	@FindBy(locator = "productsrefine.btn.bestmatch")
	private QAFWebElement refineBtnBestmatch;
	@FindBy(locator = "productsrefine.btn.newest")
	private QAFWebElement refineBtnNewest;
	@FindBy(locator = "productsrefine.btn.ratings")
	private QAFWebElement refineBtnRatings;
	@FindBy(locator = "productsrefine.btn.pricelowtohigh")
	private QAFWebElement refineBtnPricelowtohigh;
	@FindBy(locator = "productsrefine.btn.pricehightolow")
	private QAFWebElement refineBtnPricehightolow;
	@FindBy(locator = "productsrefine.btn.ztoa")
	private QAFWebElement refineBtnZtoa;
	@FindBy(locator = "productsrefine.btn.atoz")
	private QAFWebElement refineBtnAtoz;
	@FindBy(locator = "productsrefine.btn.refine")
	private QAFWebElement BtnRefine;	
	@FindBy(locator = "productsrefine.btn.done")
	private QAFWebElement BtnDone;	
	@FindBy(locator = "productsrefine.list.productname")
	private List<ProductResult> productname;
	@FindBy(locator = "productsrefine.lbl.items")
	private List<QAFWebElement> LblItemslist;
	@FindBy(locator = "productsrefine.lbl.cells")
	private List<QAFWebElement> LblCells;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getRefineTxtPagetitle() {
		return refineTxtPagetitle;
	}

	public QAFWebElement getRefineBtnDone() {
		return refineBtnDone;
	}

	public QAFWebElement getRefineBtnBestmatch() {
		return refineBtnBestmatch;
	}

	public QAFWebElement getRefineBtnNewest() {
		return refineBtnNewest;
	}

	public QAFWebElement getRefineBtnRatings() {
		return refineBtnRatings;
	}

	public QAFWebElement getRefineBtnPricelowtohigh() {
		return refineBtnPricelowtohigh;
	}

	public QAFWebElement getRefineBtnPricehightolow() {
		return refineBtnPricehightolow;
	}

	public QAFWebElement getRefineBtnZtoa() {
		return refineBtnZtoa;
	}

	public QAFWebElement getRefineBtnAtoz() {
		return refineBtnAtoz;
	}	
	
	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
	
	public QAFWebElement getBtnDone() {
		return BtnDone;
	}
	
	public QAFWebElement getBtnRefine() {
		return BtnRefine;
	}
	public List<ProductResult> getProductname() {
		return productname;
	}
	
	// DYNAMIC value declaring
	public QAFWebElement getrefinedynamic(int label) {
		String loc = String.format(pageProps.getString("productsrefine.lbl.dynamic"), label);
		return new QAFExtendedWebElement(loc);
	}
	
	public List<QAFWebElement> getLblItemslist() {
		return LblItemslist;
	}
	
	public List<QAFWebElement> getLblCells() {
		return LblCells;
	}
	
	// DYNAMIC value declaring
		public QAFWebElement getdynamicheader(String label) {
			String loc = String.format(pageProps.getString("productsrefine.lbl.header"), label);
			return new QAFExtendedWebElement(loc);
		}
	
	
}
