package com.heb.automation.common;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import org.openqa.selenium.remote.DriverCommand;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.android.steps.AndroidStepDef;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.webdriver.CommandTracker;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElementCommandAdapter;
import com.qmetry.qaf.automation.util.Reporter;

public class AndroidWebElementListener extends QAFWebElementCommandAdapter {
	public void afterCommand(QAFExtendedWebElement element, CommandTracker commandTracker) {
		AndroidcommonTestPage androidfun = new AndroidcommonTestPage();
		try {
			if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.SEND_KEYS_TO_ELEMENT)) {
				PerfectoUtils.getAppiumDriver().hideKeyboard();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			if (element.equals(androidfun.getAppSliderHome())
					&& commandTracker.getCommand().equalsIgnoreCase(DriverCommand.CLICK)) {
				/* AndroidStepDef.handleHeroImage(); */
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			if (element.equals(androidfun.getHeaderBtnScanProducts())
					&& commandTracker.getCommand().equalsIgnoreCase(DriverCommand.CLICK)) {
				AndroidStepDef.handleHEBTakePicPopUp();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onFailure(QAFExtendedWebElement element, CommandTracker commandTracker) {
		/*super.onFailure(element, commandTracker);
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		if (appCrash.getAppcrashMsg().isPresent()) {
			PerfectoUtils.reportMessage("Unexpected error in Application. Click Ok button");
			appCrash.getExceptionBtnOk().click();

		} else if (appCrash.getExceptionBtnOk().isPresent()) {
			PerfectoUtils.reportMessage("Unexpected error in Application. Click Ok button");
			appCrash.getExceptionBtnOk().click();

		} else if (appCrash.getReloginTitle().isPresent()) {
			PerfectoUtils.reportMessage("Handling re-Login popup", MessageTypes.Pass);
			appCrash.getReloginPassword().clear();
			appCrash.getReloginPassword().sendKeys(getBundle().getString("currentPassword"));
			appCrash.getReloginLoginBtn().waitForPresent(10000);
			appCrash.getReloginLoginBtn().click();
		}
*/
	}

}
