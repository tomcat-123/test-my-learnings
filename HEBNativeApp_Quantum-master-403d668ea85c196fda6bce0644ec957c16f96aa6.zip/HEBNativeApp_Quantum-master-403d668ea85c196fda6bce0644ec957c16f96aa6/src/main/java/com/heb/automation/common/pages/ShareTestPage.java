package com.heb.automation.common.pages;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ShareTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "emailcontent.lbl.pagetitle")
	private QAFWebElement LblPagetitle;
	@FindBy(locator = "emailcontent.lbl.heading")
	private QAFWebElement LblHeading;
	@FindBy(locator = "emailcontent.btn.corporate")
	private QAFWebElement BtnCorporate;
	@FindBy(locator = "emailcontent.btn.yahoo")
	private QAFWebElement BtnYahoo;
	@FindBy(locator = "emailcontent.btn.aol")
	private QAFWebElement BtnAol;
	@FindBy(locator = "emailcontent.btn.outlook")
	private QAFWebElement BtnOutlook;
	@FindBy(locator = "emailcontent.btn.verizon")
	private QAFWebElement BtnVerizon;
	@FindBy(locator = "emailcontent.btn.gmail")
	private QAFWebElement BtnGmail;
	@FindBy(locator = "emailcontent.btn.addaccount")
	private QAFWebElement BtnAddaccount;
	@FindBy(locator = "facebook.image.facebook")
	private QAFWebElement Image;
	@FindBy(locator = "facebook.edt.email")
	private QAFWebElement EdtEmail;
	@FindBy(locator = "facebook.edt.password")
	private QAFWebElement EdtPassword;
	@FindBy(locator = "facebook.btn.login")
	private QAFWebElement BtnLogin;
	@FindBy(locator = "facebook.btn.createaccount")
	private QAFWebElement BtnCreateaccount;
	@FindBy(locator = "facebook.lbl.forgetpwd")
	private QAFWebElement LblForgetpwd;
	@FindBy(locator = "email.lbl.pagetitle")
	private QAFWebElement emailLblPagetitle;
	@FindBy(locator = "email.edt.emailaddress")
	private QAFWebElement emailEdtEmailaddress;
	@FindBy(locator = "email.edt.password")
	private QAFWebElement emailEdtPassword;
	@FindBy(locator = "email.chk.showpassword")
	private QAFWebElement chkShowpassword;
	@FindBy(locator = "email.btn.manualsetup")
	private QAFWebElement btnManualsetup;
	@FindBy(locator = "email.btn.signin")
	private QAFWebElement btnSignin;
	@FindBy(locator = "emailcontent.btn.other")
	private QAFWebElement btnOther;
	@FindBy(locator = "facebook.lbl.pleaselogin")
	private QAFWebElement lblPleaselogin;
	@FindBy(locator = "facebook.lbl.msgcontent")
	private QAFWebElement lblMsgcontent;
	@FindBy(locator = "facebook.btn.ok")
	private QAFWebElement btnOk;
	@FindBy(locator = "facebook.lbl.title")
	private QAFWebElement lblTitle;
	@FindBy(locator = "facebook.btn.cancel")
	private QAFWebElement btnCancel;
	@FindBy(locator = "facebook.btn.post")
	private QAFWebElement btnPost;
	@FindBy(locator = "facebook.edt.message")
	private QAFWebElement edtMessage;
	@FindBy(locator = "facebook.lbl.post")
	private QAFWebElement lblPost;
	@FindBy(locator = "facebook.lbl.hebsave")
	private QAFWebElement lblHebsave;
	@FindBy(locator = "facebook.img.product")
	private QAFWebElement imgProduct;
	@FindBy(locator = "emailcontent.lbl.emailmsg")
	private QAFWebElement lblEmailmsg;
	@FindBy(locator = "emailcontent.btn.ok")
	private QAFWebElement emailcontentBtnOk;
	@FindBy(locator = "emailcontent.lbl.selectemail")
	private QAFWebElement lblSelectemail;
	@FindBy(locator = "emailcontent.lbl.others")
	private QAFWebElement lblOthers;
	@FindBy(locator = "emailcontent.btn.Next")
	private QAFWebElement btnNext;
	@FindBy(locator = "emailcontent.lbl.pageheader")
	private QAFWebElement lblPageheader;
	@FindBy(locator = "share.lbl.title")
	private QAFWebElement sharelblTitle;

	@FindBy(locator = "facebook.lbl.popuptitle")
	private QAFWebElement lblPopuptitle;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblPagetitle() {
		return LblPagetitle;
	}

	public QAFWebElement getLblHeading() {
		return LblHeading;
	}

	public QAFWebElement getBtnCorporate() {
		return BtnCorporate;
	}

	public QAFWebElement getBtnYahoo() {
		return BtnYahoo;
	}

	public QAFWebElement getBtnAol() {
		return BtnAol;
	}

	public QAFWebElement getBtnOutlook() {
		return BtnOutlook;
	}

	public QAFWebElement getBtnVerizon() {
		return BtnVerizon;
	}

	public QAFWebElement getBtnGmail() {
		return BtnGmail;
	}

	public QAFWebElement getBtnAddaccount() {
		return BtnAddaccount;
	}

	public QAFWebElement getImageFacebook() {
		return Image;
	}

	public QAFWebElement getEdtEmail() {
		return EdtEmail;
	}

	public QAFWebElement getEdtPassword() {
		return EdtPassword;
	}

	public QAFWebElement getBtnLogin() {
		return BtnLogin;
	}

	public QAFWebElement getBtnCreateaccount() {
		return BtnCreateaccount;
	}

	public QAFWebElement getLblForgetpwd() {
		return LblForgetpwd;
	}

	public QAFWebElement getEmailLblPagetitle() {
		return emailLblPagetitle;
	}

	public QAFWebElement getEmailEdtEmailaddress() {
		return emailEdtEmailaddress;
	}

	public QAFWebElement getEmailEdtPassword() {
		return emailEdtPassword;
	}

	public QAFWebElement getChkShowpassword() {
		return chkShowpassword;
	}

	public QAFWebElement getBtnManualsetup() {
		return btnManualsetup;
	}

	public QAFWebElement getBtnSignin() {
		return btnSignin;
	}

	public QAFWebElement getBtnOther() {
		return btnOther;
	}

	public QAFWebElement getLblPleaselogin() {
		return lblPleaselogin;
	}

	public QAFWebElement getLblMsgcontent() {
		return lblMsgcontent;
	}

	public QAFWebElement getBtnOk() {
		return btnOk;
	}

	public QAFWebElement getLblTitle() {
		return lblTitle;
	}

	public QAFWebElement getBtnCancel() {
		return btnCancel;
	}

	public QAFWebElement getBtnPost() {
		return btnPost;
	}

	public QAFWebElement getEdtMessage() {
		return edtMessage;
	}

	public QAFWebElement getLblPost() {
		return lblPost;
	}

	public QAFWebElement getLblHebsave() {
		return lblHebsave;
	}

	public QAFWebElement getImgProduct() {
		return imgProduct;
	}

	public QAFWebElement getLblEmailmsg() {
		return lblEmailmsg;
	}

	public QAFWebElement getEmailcontentBtnOk() {
		return emailcontentBtnOk;
	}

	public QAFWebElement getLblSelectemail() {
		return lblSelectemail;
	}

	public QAFWebElement getLblOthers() {
		return lblOthers;
	}

	public QAFWebElement getBtnNext() {
		return btnNext;
	}

	public QAFWebElement getLblPageheader() {
		return lblPageheader;
	}

	public QAFWebElement getSharelblTitle() {
		return sharelblTitle;
	}

	public QAFWebElement getLblPopuptitle() {
		return lblPopuptitle;
	}

}
