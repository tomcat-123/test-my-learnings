package com.heb.automation.common.pages.coupons;

import java.util.List;

import com.heb.automation.common.components.Couponssearchresult;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CouponsdetailsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "couponsdetail.lbl.couponexpirationlabel")
	private QAFWebElement couponsdetailLblCouponexpirationlabel;
	@FindBy(locator = "couponsdetail.lbl.couponlimitvalue")
	private QAFWebElement couponsdetailLblCouponlimitvalue;
	@FindBy(locator = "couponsdetail.btn.login")
	private QAFWebElement couponsdetailBtnLogin;
	@FindBy(locator = "couponsdetail.btn.register")
	private QAFWebElement couponsdetailBtnRegister;
	@FindBy(locator = "couponsdetail.lbl.imageview")
	private QAFWebElement couponsdetailLblImageview;
	@FindBy(locator = "couponsdetail.btn.share")
	private QAFWebElement couponsdetailBtnShare;
	@FindBy(locator = "couponsdetail.lbl.coupontitle")
	private QAFWebElement couponsdetailLblCoupontitle;
	@FindBy(locator = "couponsdetail.lbl.couponterms")
	private QAFWebElement couponsdetailLblCouponterms;
	@FindBy(locator = "couponsdetail.btn.home")
	private QAFWebElement couponsdetailBtnHome;
	@FindBy(locator = "couponsdetail.btn.select")
	private QAFWebElement coupondetailsBtnSelect;
	@FindBy(locator = "coupondetails.btn.addtolist")
	private QAFWebElement coupondetailsBtnAddtolist;
	@FindBy(locator = "couponsdetail.lbl.pagetitle")
	private QAFWebElement LblPagetitle;
	@FindBy(locator = "couponsdetail.lbl.sharefacebook")
	private QAFWebElement LblSharefacebook;
	@FindBy(locator = "couponsdetail.lbl.shareemail")
	private QAFWebElement LblShareemail;
	@FindBy(locator = "couponsdetail.btn.ok")
	private QAFWebElement btnOk;
	@FindBy(locator = "couponsdetail.btn.cancel")
	private QAFWebElement btnCancel;
	@FindBy(locator = "couponsdetail.lbl.pagetitle")
	private QAFWebElement couponsdetaillblpagetitle;
	@FindBy(locator = "couponsdetail.lbl.sharecancel")
	private QAFWebElement LblSharecancel;
	@FindBy(locator = "couponsdetail.btn.selected")
	private QAFWebElement couponsdetailbtnselected;
	@FindBy(locator = "couponsdetail.lbl.sharemessage")
	private QAFWebElement lblSharemessage;
	@FindBy(locator = "couponsdetail.lbl.sharegmail")
	private QAFWebElement lblSharegmail;
	@FindBy(locator = "couponsdetail.lbl.shareandroidbeam")
	private QAFWebElement lblShareandroidbeam;
	@FindBy(locator = "couponsdetail.lbl.sharebluetooth")
	private QAFWebElement lblSharebluetooth;
	@FindBy(locator = "couponsdetail.lbl.sharehangouts")
	private QAFWebElement lblSharehangouts;
	@FindBy(locator = "couponsdetail.lbl.sharepagetitle")
	private QAFWebElement lblSharepagetitle;
	@FindBy(locator = "couponsdetail.lbl.popupdcerrortitle")
	private QAFWebElement lblPopupdcerrortitle;
	@FindBy(locator = "couponsdetail.btn.popupdcerrorok")
	private QAFWebElement btnPopupdcerrorok;
	@FindBy(locator = "couponsdetail.lbl.reminders")
	private QAFWebElement lblReminders;
	@FindBy(locator = "couponsdetail.btn.readmore")
	private QAFWebElement btnReadmore;
	@FindBy(locator = "couponsdetail.btn.readless")
	private QAFWebElement btnReadless;

	// Product Modal Section //
	@FindBy(locator = "couponsdetail.productmodal.txt.products")
	private QAFWebElement txtproducts;
	@FindBy(locator = "couponsdetail.productmodal.img.heblogo")
	private QAFWebElement imgheblogo;
	@FindBy(locator = "couponsdetail.productmodal.lbl.viewallproducts")
	private QAFWebElement lblviewallproducts;
	@FindBy(locator = "couponsdetail.productmodal.btn.cancel")
	private QAFWebElement btncancel;
	@FindBy(locator = "couponsdetail.productmodal.txt.couponbubble")
	private QAFWebElement txtcouponbubble;
	@FindBy(locator = "couponsdetail.productmodal.txt.coupondescription")
	private QAFWebElement txtcoupondescription;
	@FindBy(locator = "couponsdetail.productmodal.txt.productsname")
	private List<QAFWebElement> txtproductsnamelist;
	@FindBy(locator = "couponsdetail.productmodal.btn.addtolist")
	private List<QAFWebElement> btnaddtolist;
	@FindBy(locator = "couponsdetail.btn.addtolist")
	private QAFWebElement btnAddToList;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getCouponsdetailLblCouponexpirationlabel() {
		return couponsdetailLblCouponexpirationlabel;
	}

	public QAFWebElement getCouponsdetailLblCouponlimitvalue() {
		return couponsdetailLblCouponlimitvalue;
	}

	public QAFWebElement getCoupondetailsBtnAddtolist() {
		return coupondetailsBtnAddtolist;
	}

	public QAFWebElement getCouponsdetailBtnLogin() {
		return couponsdetailBtnLogin;
	}

	public QAFWebElement getCouponsdetailBtnRegister() {
		return couponsdetailBtnRegister;
	}

	public QAFWebElement getCouponsdetailLblImageview() {
		return couponsdetailLblImageview;
	}

	public QAFWebElement getCouponsdetailBtnShare() {
		return couponsdetailBtnShare;
	}

	public QAFWebElement getCouponsdetailLblCoupontitle() {
		return couponsdetailLblCoupontitle;
	}

	public QAFWebElement getCouponsdetailLblCouponterms() {
		return couponsdetailLblCouponterms;
	}

	public QAFWebElement getCouponsdetailBtnHome() {
		return couponsdetailBtnHome;
	}

	public QAFWebElement getCoupondetailsBtnSelect() {
		return coupondetailsBtnSelect;
	}

	public QAFWebElement getCouponsdetailLblPagetitle() {
		return couponsdetaillblpagetitle;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getLblPagetitle() {
		return LblPagetitle;
	}

	public QAFWebElement getLblSharefacebook() {
		return LblSharefacebook;
	}

	public QAFWebElement getLblShareemail() {
		return LblShareemail;
	}

	public QAFWebElement getBtnOk() {
		return btnOk;
	}

	public QAFWebElement getBtnCancel() {
		return btnCancel;
	}

	public QAFWebElement getLblSharecancel() {
		return LblSharecancel;
	}

	public QAFWebElement getLblSharemessage() {
		return lblSharemessage;
	}

	public QAFWebElement getLblSharegmail() {
		return lblSharegmail;
	}

	public QAFWebElement getLblShareandroidbeam() {
		return lblShareandroidbeam;
	}

	public QAFWebElement getLblSharebluetooth() {
		return lblSharebluetooth;
	}

	public QAFWebElement getLblSharehangouts() {
		return lblSharehangouts;
	}

	public QAFWebElement getLblSharepagetitle() {
		return lblSharepagetitle;
	}

	public QAFWebElement getLblPopupdcerrortitle() {
		return lblPopupdcerrortitle;
	}

	public QAFWebElement getBtnPopupdcerrorok() {
		return btnPopupdcerrorok;
	}

	public QAFWebElement getLblReminders() {
		return lblReminders;
	}

	public QAFWebElement gettxtproducts() {
		return txtproducts;
	}

	public QAFWebElement getimgheblogo() {
		return imgheblogo;
	}

	public QAFWebElement getlblviewallproducts() {
		return lblviewallproducts;
	}

	public QAFWebElement getbtncancel() {
		return btncancel;
	}

	public QAFWebElement gettxtcouponbubble() {
		return txtcouponbubble;
	}

	public QAFWebElement gettxtcoupondescription() {
		return txtcoupondescription;
	}

	public List<QAFWebElement> gettxtproductsnamelist() {
		return txtproductsnamelist;
	}

	public List<QAFWebElement> getbtnaddtolist() {
		return btnaddtolist;
	}

	public QAFWebElement getBtnReadmore() {
		return btnReadmore;
	}

	public QAFWebElement getBtnReadless() {
		return btnReadless;
	}
	public QAFWebElement getBtnAddToList() {
		return btnAddToList;
	}
}
