package com.automation.web.commonutils;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.perfecto.reportium.client.ReportiumClient;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class CommonUtils {
	
	public static final String PERFECTO_REPORT_CLIENT = "perfecto.report.client";
	
	// Constants for timing in Miliseconds
	public static final int MAX_WAIT_TIME = 10000;
	private static final int SLEEP_TIME = 3000;
	private int headerOffset = 0;

	Actions action = new Actions(getDriver());

	/**
	 * Constructor will determine current size of the header to create an offset
	 * for the scrolling
	 */
	public CommonUtils() {
		WebElement topHeader;
		WebElement lowHeader;
		try {
			topHeader = getDriver().findElement(By.className("middle-row"));
			lowHeader = getDriver().findElement(By.className("bottom-row"));
			headerOffset = (topHeader.getSize().getHeight() * 2) + lowHeader.getSize().getHeight();
		} catch (org.openqa.selenium.NoSuchElementException | NullPointerException e) {
			headerOffset = 0; // On the Unata Dashboard, set the offset to zero
		}
	}

	/**
	 * Creates and returns a static web driver for the Actions class
	 * 
	 * @return Current state of the web driver
	 */
	public static QAFExtendedWebDriver getDriver() {
		return new WebDriverTestBase().getDriver();
	}

	/**
	 * Logs given message to the QMetry reporter with Pass occurrence
	 * 
	 * @param msg
	 *            Meaningful message on what occurred
	 */
	public void pass(String msg) {
		//Reporter.log(msg, MessageTypes.Pass);
		reportMessage(msg, MessageTypes.Pass);
	}

	/**
	 * Logs given message to the QMetry reporter with Fail occurrence
	 * 
	 * @param msg
	 *            Meaningful message on what occurred
	 */
	public void fail(String msg) {
		//Reporter.log(msg, MessageTypes.Fail);
		reportMessage(msg, MessageTypes.Fail);
	}

	public static void reportMessage(String msg, MessageTypes result) {

        ReportiumClient reportClient = (ReportiumClient) getBundle().getObject(PERFECTO_REPORT_CLIENT);
        boolean asrtResult = false;

        if (result.equals(MessageTypes.Pass) || result.equals(MessageTypes.TestStepPass)) {
               asrtResult = true;
        } else if (result.equals(MessageTypes.Fail) || result.equals(MessageTypes.TestStepFail)) {
               asrtResult = false;
        } else if (result.equals(MessageTypes.Info) || result.equals(MessageTypes.TestStep)
                     || result.equals(MessageTypes.Warn)) {
               asrtResult = true;
        }

        //reportClient.reportiumAssert(msg, asrtResult);
        Reporter.log(msg, result);
        assertTrue(asrtResult, msg);

 }

 public static void reportMessage(String msg) {
        reportMessage(msg, MessageTypes.Info);
 }

	/**
	 * Logs given message to the QMetry reporter with Info occurrence
	 * 
	 * @param msg
	 *            Meaningful message on what occurred
	 */
	public void info(String msg) {
		//Reporter.log(msg, MessageTypes.Info);
		reportMessage(msg, MessageTypes.Info);
	}

	/**
	 * Sends specified credentials to web element given. Clears out any old
	 * values before sending new values to the area
	 * 
	 * @param elementName
	 *            Web element (button, label) to be entered into field
	 * @param elementValue
	 *            Value to enter
	 */
	public void enterValues(QAFWebElement elementName, String elementValue) {

		elementName.waitForPresent(MAX_WAIT_TIME);
		elementName.click();
		elementName.clear();;
		elementName.sendKeys(elementValue);
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Sends specific keys, such as the enter key, to the element given
	 * 
	 * @param elementName
	 *            Element to send value to
	 * @param key
	 *            Key to press
	 */
	public void enterKeys(QAFWebElement elementName, Keys key) {
		elementName.click();
		elementName.sendKeys(key);
		sleep();
	}

	/**
	 * Sends specified credentials to web element given. Clears out any old
	 * values before sending new values to the area, and then sends the enter
	 * key
	 * 
	 * @param elementName
	 *            Web element (button, label) to be entered into field
	 * @param elementValue
	 *            Value to enter
	 */
	public void enterValueAndSendEnter(QAFWebElement elementName, String elementValue) {
		elementName.click();
		elementName.sendKeys(elementValue);

		getDriver().getKeyboard().pressKey(Keys.ENTER);
	}

	/**
	 * Readability method. Waits for the element to appear. Uses the global
	 * MAX_WAIT_TIME as a reference for waiting in milliseconds
	 * 
	 * @param element
	 *            Webelement to wait on
	 */
	public static void waitForElement(QAFWebElement element) {
		try {
			element.waitForPresent(MAX_WAIT_TIME);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Moves over the initial item given, sleeps for SLEEP_TIME, and then moves
	 * to the intended target.
	 * 
	 * @param hoverItem
	 *            Starting item to populate required tab
	 * @param itemToClick
	 *            Intended item to be clicked
	 */
	public void mouseoverAndClick(QAFWebElement hoverItem, QAFWebElement itemToClick) {
		action.moveToElement(hoverItem);
		action.perform();
		sleep();

		action.moveToElement(itemToClick);
		action.click();
		action.perform();
	}

	/**
	 * Scrolls through page until element is confirmed present. Posts Pass
	 * message if element is verified present
	 * 
	 * @param element
	 *            Element to find
	 * @param label
	 *            Text of element being searched for
	 */
	public void scrollAndVerifyElement(QAFWebElement element, String label) {
		try {
			if (element.isDisplayed()) {
				element.verifyPresent();
			} else {
				scrolltoelement(element);
				if (element.isDisplayed()) {
					element.verifyPresent();
				} else {
					Reporter.log(label + " not found.", MessageTypes.Fail);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log(label + " not found.", MessageTypes.Fail);
		}
		Reporter.log(label + " found.", MessageTypes.Pass);
	}

	/**
	 * Performs a sleep to allow mouse over items to populate
	 */
	public static void sleep() {
		try {
			Thread.sleep(SLEEP_TIME);
		} catch (InterruptedException e) {

		}
	}

	/**
	 * Performs a quick sleep to allow items to populate
	 */
	public static void quickSleep() {
		try {
			Thread.sleep(SLEEP_TIME / 2);
		} catch (InterruptedException e) {

		}
	}

	public void moveToElement(QAFWebElement element) {
		action.moveToElement(element);
		action.build();
		action.perform();
	}

	public void moveToElement(WebElement element) {
		action.moveToElement(element);
		action.build();
		action.perform();
	}

	public void scrollWithoutHeader(WebElement element) {
		int y = element.getLocation().getY() + 500;
		int x = element.getLocation().getX();
		try {
			((JavascriptExecutor) getDriver()).executeScript("window.scrollBy(" + x + "," + y + ");");
		} catch (Exception e) {
			Reporter.log("Error occured while scrolling to the element.", MessageTypes.Info);
			e.printStackTrace();
		}
	}

	/**
	 * Scrolls to specified element and clicks on it. Will sleep for half the
	 * time of SLEEP_TIME.
	 * 
	 * @param element
	 *            Element to scroll to
	 */
	public void scrollAndClick(QAFWebElement element) {

		element.waitForPresent(MAX_WAIT_TIME);
		scrolltoelement(element);
		element.waitForPresent(MAX_WAIT_TIME);
		element.click();
		quickSleep();
	}

	/**
	 * Adds items to the cart
	 * 
	 * @param elementTo
	 *            Button for the elementTo.click()
	 * @param clickAmount
	 *            Amount of clicks requested
	 */
	public int multiClick(QAFWebElement elementTo, int clickAmount) {
		int totalAdded = 0;
		for (int i = 0; i < clickAmount; i++) {
			elementTo.click();
			totalAdded += 1;
		}
		return totalAdded;
	}

	/**
	 * If passed a select box web element, can scroll through and select the
	 * given item based on the string. So, if given a State selection box with
	 * the String "Texas," it will go through the options until the greatest
	 * state in the union is selected
	 * 
	 * @param menu
	 *            Menu box to scroll through
	 * @param clickMe
	 *            Item to select
	 */
	public void selectBoxSelection(QAFWebElement menu, String clickMe) {
		// act.moveToElement(menu);
		// act.perform();
		moveToElement(menu);

		menu.click();
		Select clickThis = new Select(menu);
		clickThis.selectByVisibleText(clickMe);
	}

	/**
	 * Returns a WebElement based on the given xpath
	 * 
	 * @param xpath
	 *            Xpath to the element to be created
	 * @return WebElement object
	 */
	public WebElement generateWebElement(String xpath) {
		return getDriver().findElement(By.xpath(xpath));
	}

	/**
	 * Returns a list of WebElements based on the given xpath
	 * 
	 * @param xpath
	 *            Xpath to the element to be created
	 * @return List of WebElements
	 */
	public List<WebElement> generateWebElementList(String xpath) {
		return getDriver().findElements(By.xpath(xpath));
	}

	/**
	 * Retrieves a String stored in the bundle hashmap
	 * 
	 * @param name
	 *            Item to be retrieved
	 * @return Stored string
	 */
	public String storedString(String name) {
		return getBundle().getString(name);
	}

	/**
	 * Debugging print message
	 * 
	 * @param msg
	 *            Message to print
	 */
	public void print(String msg) {
		System.out.println(msg);
	}

	/**
	 * Debugging print for line number
	 * 
	 * @param lineNumber
	 */
	public void pLine(int lineNumber) {
		System.out.println("Line number: " + lineNumber);
	}

	/**
	 * Perfecto- Scrolls to specified element.
	 * 
	 * @param element
	 *            Element to scroll to
	 */
	public static void scrolltoelement(QAFWebElement qafelement) {

		try {
			qafelement.waitForPresent(MAX_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor) PerfectoUtils.getDriver();
			js.executeScript("arguments[0].scrollIntoView(true);", qafelement);

		} catch (Exception e) {
			Reporter.log("Error occured while scrolling to the elemenet.");
			e.printStackTrace();
		}

	}

	public static void waitAngularHasFinishedProcessing() {
		WebDriverWait wait = new WebDriverWait(getDriver(), 35, 100);
		wait.until(angularHasFinishedProcessing());

	}

	public static ExpectedCondition<Boolean> angularHasFinishedProcessing() {
		return new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				return Boolean.valueOf(((JavascriptExecutor) driver)
						.executeScript(
								"return (window.angular !== undefined) && (angular.element(document).injector() !== undefined) && (angular.element(document).injector().get('$http').pendingRequests.length === 0)")
						.toString());
			}
		};
	}

}
