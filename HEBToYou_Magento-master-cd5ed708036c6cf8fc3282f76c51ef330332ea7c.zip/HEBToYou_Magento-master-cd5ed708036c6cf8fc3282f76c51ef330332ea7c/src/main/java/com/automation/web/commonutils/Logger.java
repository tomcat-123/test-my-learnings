/**
 * 
 */
package com.automation.web.commonutils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.xalan.processor.TransformerFactoryImpl;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class Logger  {

	 public static void logemail(String message) throws IOException { 
	      PrintWriter out = new PrintWriter(new FileWriter("resources\\testdata\\newaccounts.txt", true), true);
	      out.write("\n"+ message);
	      out.close();
	    }
	
	 public static void logpassword(String message) throws IOException { 
	      PrintWriter out = new PrintWriter(new FileWriter("resources\\testdata\\newaccounts.txt", true), true);
	      out.write("|"+ message);
	      out.close();
	    }
	
	 public static void writexml(String myemail , String mypass){

		  try {

			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

			// root elements
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("testdata");
			doc.appendChild(rootElement);

			// staff elements
			Element user = doc.createElement("user");
			rootElement.appendChild(user);
	/*
			// set attribute to staff element
			Attr attr = doc.createAttribute("id");
			attr.setValue("1");
			user.setAttributeNode(attr);

	*/		// shorten way
			// staff.setAttribute("id", "1");

			// firstname elements
			Element email = doc.createElement("email");
			email.appendChild(doc.createTextNode(myemail));
			user.appendChild(email);

			// lastname elements
			Element password = doc.createElement("password");
			password.appendChild(doc.createTextNode(mypass));
			user.appendChild(password);

			// write the content into xml file
			TransformerFactoryImpl transformerFactory = new TransformerFactoryImpl();
			Transformer transformer = transformerFactory.newTransformer();
			
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("resources\\testdata\\newaccounts.xml"));

			// Output to console for testing
			// StreamResult result = new StreamResult(System.out);

			transformer.transform(source, result);
			
			System.out.println(result);
			System.out.println("File saved!");

		  } catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		  } catch (TransformerException tfe) {
			tfe.printStackTrace();
		  }
		}

		 
	 }


