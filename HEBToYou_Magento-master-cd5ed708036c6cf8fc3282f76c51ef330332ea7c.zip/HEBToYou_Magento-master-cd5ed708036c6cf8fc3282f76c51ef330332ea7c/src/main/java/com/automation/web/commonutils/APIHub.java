package com.automation.web.commonutils;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static com.automation.web.commonutils.FunctionUtils.AVG_WEIGHT_KEY;
import static com.automation.web.commonutils.FunctionUtils.CONSM_PRCH_CD_KEY;
import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NAME_KEY;
import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NUMBER_KEY;
import static com.automation.web.commonutils.FunctionUtils.GLUTEN_FREE_KEY;
import static com.automation.web.commonutils.FunctionUtils.IS_DEAL_KEY;
import static com.automation.web.commonutils.FunctionUtils.IS_TAXABLE_KEY;
import static com.automation.web.commonutils.FunctionUtils.LIST_PRICE_KEY;
import static com.automation.web.commonutils.FunctionUtils.MAX_ORDER_KEY;
import static com.automation.web.commonutils.FunctionUtils.MIN_ORDER_KEY;
import static com.automation.web.commonutils.FunctionUtils.ON_SALE_KEY;
import static com.automation.web.commonutils.FunctionUtils.ORGANIC_KEY;
import static com.automation.web.commonutils.FunctionUtils.SALE_PRICE_KEY;
import static com.automation.web.commonutils.FunctionUtils.SALE_WT_SW_KEY;
import static com.automation.web.commonutils.FunctionUtils.TAX_PERCENTAGE_KEY;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

/**
 * APIHub opens a connection to the UAT OpenAPI to grab product information. Will grab the product's
 * information, parse it, and return only what is needed.
 * <p>Note: While they do have their own test steps, the price locations are used with the assumption that
 * the store's number has been previously set. Unable to make the steps execute within the common pages file,
 * so the steps are currently located in the steps.HomePage file
 * @author Garrett Griffin
 *
 */
public class APIHub {
	
	private String storesURL;
	private String categoriesURL;
	private String productsURL;
	private String priceLocURL;
	private String apiKey;
	
	CommonUtils util = new CommonUtils();
	static CloseableHttpClient client;
	HttpGet request;
	HttpResponse response; 
	
	/**
	 * Generates URLs and grabs information from properties file. 
	 */
	public APIHub(){
	//	APIHub.client = HttpClients.createDefault();
//		setProdKeys();
	//	setUATKeys();
	}
	
	private void setProdKeys(){
		this.storesURL = getBundle().getString("apihub.prod.storesURL");
		this.priceLocURL = getBundle().getString("apihub.prod.priceLocationsURL");
		this.apiKey = getBundle().getString("apihub.prod.apiKey");
		this.categoriesURL = getBundle().getString("apihub.prod.categoriesURL");
		this.productsURL = getBundle().getString("apihub.prod.productsURL");
	}
	
	private void setUATKeys(){
//		this.storesURL = getBundle().getString("apihub.uat.storesURL");
		this.storesURL = getBundle().getString("apihub.prod.storesURL");
		this.priceLocURL = getBundle().getString("apihub.uat.priceLocationsURL");
		this.apiKey = getBundle().getString("apihub.uat.apiKey");
		this.categoriesURL = getBundle().getString("apihub.uat.categoriesURL");
		this.productsURL = getBundle().getString("apihub.uat.productsURL");
	}
	
	/**
	 * Contacts the Hub with given input, and returns a reader containing all information of the item
	 * @param url APIHub url to contact, like /products or /stores
	 * @param inputId Store or product ID to get information on
	 * @return Reader of the requested data
	 */
	private BufferedReader contactHub(String url, String inputId) throws IOException, UnsupportedOperationException{
		String genUrl = url + inputId;

		this.request = new HttpGet(genUrl);

		// add request header
		request.addHeader("apiKey", this.apiKey);
		try {
			this.response = client.execute(this.request);
		} catch (IOException e) {
			e.printStackTrace();
		} 

		try {
			return new BufferedReader(
				new InputStreamReader(this.response.getEntity().getContent()));
		} catch (UnsupportedOperationException | IOException e) {
			util.fail("Unable to generate information from hub");
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * Generates an object containing all categories in the APIHub. Note that this
	 * is only for the categories API. Not compatible with products/stores/etc.
	 * @return Object containing all categories from the categories API Hub
	 */
	private JsonObject createJObject(BufferedReader apiContents){ 
		JsonParser jp = new JsonParser(); 
		JsonElement root = null;
		try {
			root = jp.parse(readAll(apiContents));
		} catch (JsonSyntaxException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return root.getAsJsonObject();
	}
	
	private static String readAll(Reader rd) throws IOException {
	    StringBuilder sb = new StringBuilder();
	    int cp;
	    while ((cp = rd.read()) != -1) {
	      sb.append((char) cp);
	    }
	    return sb.toString();
	  }
	
	
	/**
	 * Sets the given key and value in the hash map
	 * @param itemId Item to be paired with the given key
	 * @param key Key term to classify for the item
	 * @param value Value of the item given
	 */
	private void setKeyValue(String itemId, String key, String value){
		getBundle().setProperty(key + itemId, value);
		util.info(key + " set with " + value + " value");
	}

	/**
	 * Opens a new connection to the api hub, and sets the min/max order values
	 * and whether or not the item is taxable in the hash map
	 * @param inputId Unique item ID of the product
	 * @throws IOException 
	 * @throws UnsupportedOperationException 
	 */
	public void genProductInfo(String inputId) throws UnsupportedOperationException, IOException{ 
		BufferedReader rd = contactHub(this.productsURL, inputId);
		JsonObject priceObj = this.createJObject(rd);
		
		setKeyValue(inputId, AVG_WEIGHT_KEY, priceObj.get(AVG_WEIGHT_KEY) + ""); 
		setKeyValue(inputId, MIN_ORDER_KEY, priceObj.get(MIN_ORDER_KEY) + ""); 
		setKeyValue(inputId, MAX_ORDER_KEY, priceObj.get(MAX_ORDER_KEY) + ""); 
		setKeyValue(inputId, IS_TAXABLE_KEY, priceObj.get(IS_TAXABLE_KEY) + "");
		setKeyValue(inputId, CONSM_PRCH_CD_KEY, priceObj.get(CONSM_PRCH_CD_KEY) + "");

		if(priceObj.get("snipes") != null){ 
			JsonArray jArr = priceObj.getAsJsonArray("snipes");
			String snipeId = "";
			for(int i = 0; i < jArr.size(); i++){ 
				snipeId = jArr.get(i).getAsJsonObject().get("snipeId") + "";
				snipeId = snipeId.replaceAll("\"", ""); 
				switch(snipeId){
					case GLUTEN_FREE_KEY:
						setKeyValue(inputId, GLUTEN_FREE_KEY, true + "");
						break;
					case ORGANIC_KEY: 
						setKeyValue(inputId, ORGANIC_KEY, true + "");
				}
			}
		}
		
		this.request.reset();
		util.pass("isTaxable, min and max order values set correctly.");
	}
	
	/**
	 * Opens a connection to the stores API and sets the tax percentage
	 * in the hash map for later use
	 * @param inputId Store number to connect to
	 * @throws IOException 
	 * @throws UnsupportedOperationException 
	 */
	public void genTaxInfo(String inputId) throws UnsupportedOperationException, IOException{ 
//		util.print("stores url== " + storesURL + ", inputId: " + inputId);
		try{
			BufferedReader rd = contactHub(this.storesURL, inputId);
			JsonObject taxObject = createJObject(rd);
			String taxReturn = taxObject.get(TAX_PERCENTAGE_KEY) + "";

			getBundle().setProperty(TAX_PERCENTAGE_KEY, taxReturn);
			util.pass("Tax percentage " + taxReturn + "% set.");
		} catch (NullPointerException e){
			getBundle().setProperty(TAX_PERCENTAGE_KEY, getBundle().getString("defaultStore.tax"));
			util.fail("Tax percentage not set. Continuing to use default percentage");
		}
		this.request.reset(); 
	}
	
	/**
	 * Generates a store name based off the store name. Will set the result into the bundle hashmap
	 * @param storeNum Number for the store to be found
	 * @throws IOException 
	 * @throws UnsupportedOperationException 
	 */
	public void getStoreName(String storeNum) throws UnsupportedOperationException, IOException{ 
		String storeName = "";
		BufferedReader rd = contactHub(storesURL, storeNum);
		JsonObject storeObj = createJObject(rd); 
		
		storeName = storeObj.get("name") + "";
		storeName = storeName.replaceAll("\"", "");
		getBundle().setProperty(CUR_STORE_NAME_KEY, storeName);
		util.pass("Store name " + storeName + " found");
		
		this.request.reset(); 
	}
	
	
	/**
	 * Opens a connection to the price locations API and grabs the sale and regular pricing for the
	 * product at the given store
	 * <p>NOTE: Assumes store and product has been established in the hashmap
	 * @param inputId Store number to connect to
	 * @throws IOException 
	 * @throws UnsupportedOperationException 
	 */
	public void genPriceLocation(String inputId) throws IOException{ 
		String storeId = getBundle().getProperty(CUR_STORE_NUMBER_KEY) + "";
		
		String url = this.priceLocURL + inputId + "&strnbr=";	 
		
		BufferedReader rd = contactHub(url, storeId);
		JsonObject priceLocObj = createJObject(rd); 
		JsonArray jArr = priceLocObj.get("priceLocation").getAsJsonArray();
		priceLocObj = jArr.get(0).getAsJsonObject();
//		util.print("Is on sale: " + jArr.get(0).getAsJsonObject().get(ON_SALE_KEY));
//		util.print("Price loc obj: " + priceLocObj.toString());
		
		setKeyValue(inputId, ON_SALE_KEY, priceLocObj.get(ON_SALE_KEY) + "");  
		setKeyValue(inputId, IS_DEAL_KEY, priceLocObj.get(IS_DEAL_KEY) + "");  
		setKeyValue(inputId, LIST_PRICE_KEY, priceLocObj.get(LIST_PRICE_KEY) + ""); 
		setKeyValue(inputId, SALE_WT_SW_KEY, priceLocObj.get(SALE_WT_SW_KEY) + ""); 
		setKeyValue(inputId, SALE_PRICE_KEY, priceLocObj.get(SALE_PRICE_KEY) + ""); 
		
		this.request.reset();
	}
	
	public BufferedReader generateCategories() throws UnsupportedOperationException, IOException{
		return contactHub(this.categoriesURL, "");
	}
	
	public void verifyL2Cat(){
//		JsonObject jObj = createJObject();
//		JsonArray jArr = jObj.getAsJsonObject("categories").getAsJsonArray("children");
		
	}
	
	/**
	 * Close the connection to the hub. Will be called once the scenario finishes
	 */
	public static void closeHub(){
//		try {
//			client.close();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}
}
