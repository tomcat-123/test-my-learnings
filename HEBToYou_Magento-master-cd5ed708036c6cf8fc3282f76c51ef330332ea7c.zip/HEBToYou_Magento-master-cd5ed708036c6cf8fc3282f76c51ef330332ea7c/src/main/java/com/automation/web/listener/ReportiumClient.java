package com.automation.web.listener;
//import com.perfecto.reportium.client.ReportiumClient;

public class ReportiumClient {

	public ReportiumClient() {
		// TODO Auto-generated constructor stub
	}

}