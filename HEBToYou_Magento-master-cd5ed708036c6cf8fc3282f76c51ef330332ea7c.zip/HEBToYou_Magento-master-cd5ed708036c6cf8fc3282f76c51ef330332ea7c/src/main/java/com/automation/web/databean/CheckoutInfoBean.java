package com.automation.web.databean;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.qmetry.qaf.automation.data.BaseFormDataBean;
import com.qmetry.qaf.automation.ui.annotations.UiElement;
import com.qmetry.qaf.automation.util.RandomStringGenerator.RandomizerTypes;
import com.qmetry.qaf.automation.util.Randomizer;
import com.automation.web.commonutils.CommonUtils;

/**
 * Class to generate a random user information at checkout. @UiElement will populate
 * at whatever location is given, so different location names are important. Sample invocation
 * of UiElement will look like:
 * <code>
 * <p>{@literal @}Randomizer(type = RandomizerTypes.{@literal <}Type Style>, length = {@literal <}string length>, suffix = {@literal <}String addendum>")</p>
 * <p>{@literal @}UiElement(fieldLoc = {@literal <}.loc variable>, order = {@literal <}order of execution>)</p>
 * <p>private String stringName;</p>
 * </code>
 * <p>Note: Can also randomize buttons on whether or not they need to be clicked. 
 *
 */
public class CheckoutInfoBean extends BaseFormDataBean{

	private CommonUtils util = new CommonUtils();
	
	@Override
	public void fillRandomData() { 
//		this.firstName = getBundle().getString("hotuser1.user.firstName");
		this.firstName = util.storedString("hotuser1.user.firstName");
		this.lastName = getBundle().getString("hotuser1.user.lastName");
		this.mobileNum = getBundle().getString("validPhoneNumbers.mobile");
		this.homeNum = getBundle().getString("validPhoneNumbers.home");
		this.workNum = getBundle().getString("validPhoneNumbers.work");
		this.otherNum = getBundle().getString("validPhoneNumbers.other");
		super.fillRandomData(); 
	}	

	@UiElement(fieldLoc = "schedule.edt.firstName", order = 1)
	private String firstName;

	@UiElement(fieldLoc = "schedule.edt.lastName", order = 2)
	private String lastName;
	 
	@UiElement(fieldLoc = "schedule.edt.mobileNum", order = 4)
	private String mobileNum;
	 
	@UiElement(fieldLoc = "schedule.edt.homeNum", order = 5)
	private String homeNum;
	 
	@UiElement(fieldLoc = "schedule.edt.workNum", order = 6)
	private String workNum;
	 
	@UiElement(fieldLoc = "schedule.edt.otherNum", order = 7)
	private String otherNum;

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getMobileNum() {
		return mobileNum;
	}

	public String getHomeNum() {
		return homeNum;
	}

	public String getWorkNum() {
		return workNum;
	}

	public String getOtherNum() {
		return otherNum;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	public void setHomeNum(String homeNum) {
		this.homeNum = homeNum;
	}

	public void setWorkNum(String workNum) {
		this.workNum = workNum;
	}

	public void setOtherNum(String otherNum) {
		this.otherNum = otherNum;
	}
}
