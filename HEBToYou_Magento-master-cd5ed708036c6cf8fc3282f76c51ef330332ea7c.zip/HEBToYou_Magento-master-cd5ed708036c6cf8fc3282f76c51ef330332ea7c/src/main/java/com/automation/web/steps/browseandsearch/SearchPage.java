package com.automation.web.steps.browseandsearch;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static com.automation.web.commonutils.CommonUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.CommonUtils.getDriver;
import static com.automation.web.commonutils.FunctionUtils.CART_UNIQUE_ITEM_CNT_KEY;
import static com.automation.web.commonutils.FunctionUtils.CONSM_PRCH_CD_KEY;
import static com.automation.web.commonutils.FunctionUtils.ITEM_ID_KEY;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.ObjectUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.automation.web.commonutils.APIHub;
import com.automation.web.commonutils.CommonUtils;
import com.automation.web.commonutils.FunctionUtils;
import com.automation.web.pages.browseandsearch.SearchTestPage;

public class SearchPage{
		
	CommonUtils util = new CommonUtils();
	APIHub hub = new APIHub();

	private String [] WAYS_TO_SHOP = {"", "Products On Sale", "Previously Purchased","Yellow Coupons"
									 , "Organic Products", "Gluten Free Products"
									 , "Local Products", "New Products"};
	
	Actions act = new Actions(CommonUtils.getDriver());

	/**
	 * Adds the item and its current count to the hash map. If it exists, it will only 
	 * add to its current amount and not to the unique item count
	 * @param itemToAdd What item to add to the hash map
	 * @param itemAmnt Amount to add
	 * @param uniqueItemCnt Current unique item count
	 */
	private void addCntToMap(String itemToAdd, int itemAmnt, int uniqueItemCnt){
		// Check to see if property exists. If it doesn't, add it to the hash map
		if(! getBundle().containsKey(ITEM_ID_KEY + itemToAdd)){
			getBundle().setProperty(ITEM_ID_KEY + itemToAdd, itemAmnt);
			getBundle().setProperty(CART_UNIQUE_ITEM_CNT_KEY, uniqueItemCnt);
		} else {
			// Item exists. Add it onto current amount in the hash, but don't increment
			// unique item count
			int curCount =  (int) getBundle().getProperty(ITEM_ID_KEY + itemToAdd);
			getBundle().setProperty(ITEM_ID_KEY + itemToAdd, (itemAmnt + curCount));
		}
	}
	
	@QAFTestStep(description = "User searches for {search item}")
	public void iSearchForX(String searchItem){
		SearchTestPage searchPg = new SearchTestPage();
		
		searchPg.getSearchEdtSearchBarInput().waitForEnabled(MAX_WAIT_TIME);
		try{
			act.moveToElement(searchPg.getSearchEdtSearchBarInput());
			act.click();
			act.perform();
		} catch (WebDriverException e){
//			CommonUtils.quickSleep();

			searchPg.getSearchEdtSearchBarInput().waitForEnabled(MAX_WAIT_TIME);
			util.scrollAndClick(searchPg.getSearchEdtSearchBarInput());			
		}
		util.enterValues(searchPg.getSearchEdtSearchBarInput(), searchItem);
		util.info("Item " + searchItem + " entered into search bar");
	}
	
	
	@QAFTestStep(description = "User adds {poundAmt} lbs of the {by each weight|weight}(st|th|nd) item")
	public void addXlbsOfTheYItem(String poundAmt, String listPosition){
		SearchTestPage searchPg = new SearchTestPage();
		FunctionUtils u = new FunctionUtils();
		String itemToAdd = u.generateItemID(searchPg.getSearchGetAddItemPic(listPosition)
				.getAttribute("style"));
//		try {
//			hub.genProductInfo(itemToAdd);
//		} catch (UnsupportedOperationException | IOException e) {
//			util.fail("Product information not generated for " + itemToAdd);
//		}
		String itemType = (String) getBundle().getProperty(CONSM_PRCH_CD_KEY + itemToAdd);
//		int itemCnt = (int) getBundle().getProperty(CART_UNIQUE_ITEM_CNT_KEY);

		if(itemType.equals("null")){
			itemType = "\"WEIGH\"";
			getBundle().setProperty(CONSM_PRCH_CD_KEY + itemToAdd, "WEIGH");
		}
		if(itemType.equals("\"WEIGH\"")){ 
			String [] weight = searchPg.getSearchGetDdCurrentItemSelect(listPosition).getText().split(" ");
			weight = weight[1].split("\n"); 
			util.selectBoxSelection(searchPg.getSearchGetDdCurrentItemSelect(listPosition), poundAmt + " " + weight[0]); 
		} else {
			iAddXoftheYItem(poundAmt, listPosition);
		}
		util.pass("Item added to cart");
	}

	
	@QAFTestStep(description = "User adds {itemAmt} of the {by each}(st|th|nd|rd) item")
	public void iAddXoftheYItem(String itemAmount, String listPosition){
		SearchTestPage searchPg = new SearchTestPage();
		FunctionUtils u = new FunctionUtils();
		String itemToAdd = "";
		
		itemToAdd = u.generateItemID(searchPg.getSearchGetAddItemPic(listPosition)
				.getAttribute("style"));

//		try {
//			hub.genProductInfo(itemToAdd);
//		} catch (UnsupportedOperationException | IOException e) {
//			util.fail("Item information not generated for " + itemToAdd);
//		} catch(NullPointerException e){
//
//		}
		
		String itemType = (String) getBundle().getProperty(CONSM_PRCH_CD_KEY + itemToAdd);

		int itemCnt = (int) getBundle().getProperty(CART_UNIQUE_ITEM_CNT_KEY);
		int clickCnt = 0;
		
		searchPg.getSearchGetBtnCurrentItemAdd(listPosition).waitForEnabled(MAX_WAIT_TIME);
	
		itemCnt += 1;
		
		if(! searchPg.getSearchGetBtnCurrentItemAdd(listPosition).isDisplayed()){
			CommonUtils.scrolltoelement(searchPg.getSearchGetBtnCurrentItemAdd(listPosition));
		}		
		
		if(itemType == null){
			itemType = "EACH";
		}

		if(! itemType.equals("\"WEIGH\"")){ 
			clickCnt = util.multiClick(searchPg.getSearchGetBtnCurrentItemAdd(listPosition)
					, Integer.parseInt(itemAmount));
			addCntToMap(itemToAdd, clickCnt, itemCnt); 
			util.pass(clickCnt + " of " + itemToAdd + " added to cart");
		} else {
			addXlbsOfTheYItem(itemAmount, listPosition);
		}
	}
 
	@QAFTestStep(description = "User clicks on the search icon")
	public void iClickOnTheSearchIcon(){
		SearchTestPage searchPg = new SearchTestPage();
		
		searchPg.getSearchBtnSearchBtnConf().waitForPresent(MAX_WAIT_TIME);
		searchPg.getSearchBtnSearchBtnConf().waitForEnabled(MAX_WAIT_TIME);
		searchPg.getSearchBtnSearchBtnConf().click();
		searchPg.getSearchTxtResultsFound().waitForPresent(MAX_WAIT_TIME);

		util.pass("Search page loaded successfully");
	}

	@QAFTestStep(description= "Verify user is on the search page")
	public void verifySearchPage(){
		SearchTestPage searchPg = new SearchTestPage();
		searchPg.getSearchPageLoadItem().waitForEnabled(MAX_WAIT_TIME * 2);
		String [] resultHeaderM = searchPg.getSearchTxtResultsFound().getText().split(" ", 4);
		
		util.pass(resultHeaderM[0] + " items of " + resultHeaderM[3].replace("\"", "") + " found on search page");
	}

	
	@QAFTestStep(description = "Verify search data is correct")
	public void verifyResultAmount(){
		SearchTestPage searchPg = new SearchTestPage();
		
		QAFWebElement nextPage;
		searchPg.loadPage();
		boolean hasNextPage = false;
		String [] resultHeaderM = searchPg.getSearchTxtResultsFound().getText().split(" ", 4);
		int itemsFound = Integer.parseInt(resultHeaderM[0]);
		int curSearchCnt = 0;
		
		do{			
			for(WebElement row : searchPg.getSearchTxtSearchList()){
				act.moveToElement(row);
				act.perform();				
				curSearchCnt += 1;
			}

			try{
				nextPage = searchPg.getSearchTxtNextPageIcon();
				hasNextPage = nextPage.isPresent();
				if (hasNextPage==true){
				CommonUtils.scrolltoelement(nextPage);
				nextPage.click();
				}
				else  {util.info("No next page from search result section");}
			} catch (NoSuchElementException e){
				hasNextPage = false;
			}
		} while(hasNextPage);
		if(itemsFound == curSearchCnt){
			util.pass("All items visible");
		} else {
			util.fail("Total search items expected: " + itemsFound + ", items found: " + curSearchCnt);
		}
	}
	
	@QAFTestStep(description = "User on search page for {searchTerm}")
	public void onPageForX(String searchTerm){
		SearchTestPage searchPg = new SearchTestPage();
		String searchUrl = getBundle().getString("searchURL");
		
		searchTerm = searchUrl + searchTerm;
		CommonUtils.getDriver().get(searchTerm);
		searchPg.getSearchEdtSearchBarInput().waitForEnabled(MAX_WAIT_TIME * 2);
		util.pass("Landed on correct page");
	}

	@QAFTestStep(description = "Verify ways to shop page lists")
	public void verifyMainWaysToShop(){
		SearchTestPage searchPg = new SearchTestPage();
		
		List<QAFWebElement> shopElements = searchPg.getSearchLnkWayToShopList();
		HashMap<String, String> foundElements = new HashMap<>();
		HashMap<String, String> storedElements = new HashMap<>();
		for(int i = 1; i < WAYS_TO_SHOP.length; i++){
			foundElements.put(shopElements.get(i -1).getText(), shopElements.get(i - 1).getText());
			storedElements.put(WAYS_TO_SHOP[i], WAYS_TO_SHOP[i]);
		}
		Set<String> set1 = foundElements.keySet();
		Set<String> set2 = storedElements.keySet();
		if(set1.equals(set2)){
			util.pass("Ways to shop Item sets are present in Home page!");
		} else {
			util.fail("Ways to shop Item sets do not match");
			return;
		}

//		for(int i = 1; i < WAYS_TO_SHOP.length; i++){
//			shopElements.get(i - 1).click();
////			util.generateWebElement("");
//
//		}
	}
}
