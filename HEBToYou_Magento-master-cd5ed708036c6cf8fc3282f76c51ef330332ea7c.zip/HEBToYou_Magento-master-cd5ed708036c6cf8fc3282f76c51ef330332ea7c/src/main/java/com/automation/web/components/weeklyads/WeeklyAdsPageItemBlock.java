package com.automation.web.components.weeklyads;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class WeeklyAdsPageItemBlock extends QAFWebComponent {

	public WeeklyAdsPageItemBlock(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}

	@FindBy(locator = "wklyad.img.weeklyaditemimage")
	private QAFWebElement imgWeeklyadItemImage;
	
	@FindBy(locator = "wklyad.img.weeklyadgroupeditemimage")
	private QAFWebElement imgWeeklyAdGroupedItemImage;

	@FindBy(locator = "wklyad.lbl.weeklyaditemtitle")
	private QAFWebElement lblWeeklyadItemTitle;
	
	@FindBy(locator = "wklyad.lbl.weeklyaditemstrikeprice")
	private QAFWebElement lblWeeklyadItempStrikeprice;

	@FindBy(locator = "wklyad.lbl.weeklyaditemprice")
	private QAFWebElement lblWeeklyadItemprice;
	
	@FindBy(locator = "wklyad.lbl.weeklyaditemunit")
	private QAFWebElement lblWeeklyadItemUnit;
	
	@FindBy(locator = "wklyad.lbl.weeklyadunitprice")
	private QAFWebElement lblWeeklyadUnitprice;

	@FindBy(locator = "wklyad.btn.weeklyadaddtolist")
	private QAFWebElement btnWeeklyadAddtolist;
	
	@FindBy(locator = "wklyad.btn.addtocart")
	private QAFWebElement btnWeeklyadAdtocart;
	
	@FindBy(locator = "wklyad.btn.addedtocart")
	private QAFWebElement btnAddedToCart;
	
	@FindBy(locator = "wklyad.lbl.weeklyadsavetag")
	private QAFWebElement lblWeklyAdSavetag;
	
	@FindBy(locator = "wklyad.lbl.weeklyadgroupedsavetag")
	private QAFWebElement lblWeeklyAdGroupedSavetag;
	
	@FindBy(locator = "wklyad.lbl.weeklyadgroupeditemtag")
	private QAFWebElement lblWeklyAdGroupedItemtag;
	
	@FindBy(locator = "wklyad.lbl.weeklyadgroupeditemcount")
	private QAFWebElement lblWeeklyAdGroupedItemcount;
	
	@FindBy(locator = "wklyad.btn.weeklyadanext")
	private QAFWebElement btnWeeklyAdaNext;
	
	public QAFWebElement getBtnWeeklyAdaNext() {
		return btnWeeklyAdaNext;
	}

	public QAFWebElement getLblWeeklyadItempStrikeprice() {
		return lblWeeklyadItempStrikeprice;
	}

	public QAFWebElement getLblWeeklyAdGroupedItemcount() {
		return lblWeeklyAdGroupedItemcount;
	}

	public QAFWebElement getLblWeeklyAdGroupedSavetag() {
		return lblWeeklyAdGroupedSavetag;
	}
	
	public QAFWebElement getBtnAddedToCart() {
		return btnAddedToCart;
	}
	
	public QAFWebElement getLblWeklyAdSavetag() {
		return lblWeklyAdSavetag;
	}

	public QAFWebElement getLblWeklyAdGroupedItemtag() {
		return lblWeklyAdGroupedItemtag;
	}
	
	public QAFWebElement getImgWeeklyadItemImage() {
		return imgWeeklyadItemImage;
	}

	public QAFWebElement getLblWeeklyadItemTitle() {
		return lblWeeklyadItemTitle;
	}

	public QAFWebElement getLblWeeklyadItempStrikerice() {
		return lblWeeklyadItempStrikeprice;
	}

	public QAFWebElement getLblWeeklyadItemprice() {
		return lblWeeklyadItemprice;
	}

	public QAFWebElement getLblWeeklyadItemUnit() {
		return lblWeeklyadItemUnit;
	}

	public QAFWebElement getLblWeeklyadUnitprice() {
		return lblWeeklyadUnitprice;
	}

	public QAFWebElement getBtnWeeklyadAddtolist() {
		return btnWeeklyadAddtolist;
	}

	public QAFWebElement getBtnWeeklyadAdtocart() {
		return btnWeeklyadAdtocart;
	}

	public QAFWebElement getImgWeeklyAdGroupedItemImage() {
		return imgWeeklyAdGroupedItemImage;
	}

	


}
