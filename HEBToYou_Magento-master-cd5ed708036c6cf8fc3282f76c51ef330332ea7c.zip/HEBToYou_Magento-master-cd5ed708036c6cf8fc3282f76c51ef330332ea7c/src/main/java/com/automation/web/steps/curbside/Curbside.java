package com.automation.web.steps.curbside;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static com.automation.web.commonutils.CommonUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.FunctionUtils.CURBSIDE_SET;
import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NAME_KEY;
import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NUMBER_KEY;
import static com.automation.web.commonutils.FunctionUtils.FULFILLMENT_TYPE_KEY;

import java.io.IOException;
import java.util.List;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MaximizeAction;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

import com.automation.web.commonutils.APIHub;
import com.automation.web.commonutils.CommonUtils;
import com.automation.web.commonutils.FunctionUtils;
import com.automation.web.pages.cartandcheckout.CartTestPage;
import com.automation.web.pages.cartandcheckout.CurbsideTestPage;
import com.automation.web.pages.homepage.HomeTestPage;
import com.perfecto.reportium.client.ReportiumClient;
import com.perfecto.reportium.client.ReportiumClientFactory;


public class Curbside{
	CommonUtils util = new CommonUtils();
	protected ReportiumClient reportiumClient;
	Actions act = new Actions(CommonUtils.getDriver());

	/**
	 * Needs to wait for the pop up to be fully opened for the test to pass.
	 * All future curbside tests using this case can assume window populated
	 */
	@QAFTestStep(description = "User opens curbside window")
	public void iOpenCurbisdeWindow(){
		HomeTestPage homeTest = new HomeTestPage();
		CurbsideTestPage curbsideTest = new CurbsideTestPage();
		CartTestPage testcart = new CartTestPage();
//		testcart.waitForPageToLoad();
//		curbsideTest.waitForPageToLoad();
//		homeTest.loadPage();
		curbsideTest.getCurbBtnHdrChooseCurb().click();
		CommonUtils.waitAngularHasFinishedProcessing();
		util.info("Curbside service selected");
		//reportiumClient.reportiumAssert("sdsdsdsd", false);
	}

	/**
	 * Unata eliminated the close button. Sending escape key now
	 */
	@QAFTestStep(description = "User closes curbside window")
	public void iCloseCurbsideWindow(){
		act.sendKeys(Keys.ESCAPE).perform();
		util.pass("Closed curbside window");
	}

	/**
	 * Awesome thing that's been happening on the website lately. They can't decide whether or not they
	 * want the curbside button to REALLY be a button, or if they just want it as an "a" element. 
	 * The try catch will attempt to handle this
	 */
	@QAFTestStep(description = "User selects curbside pickup")
	public void iSelectCSPickup(){
		CurbsideTestPage csTest = new CurbsideTestPage();
		getBundle().setProperty("selenium.wait.timeout", "5000");
		try{
			csTest.getCurbBtnChangeCurb().waitForEnabled(MAX_WAIT_TIME); 
			util.mouseoverAndClick(csTest.getCurbBtnChangeCurb(), csTest.getCurbBtnChangeCurb());
			
		} catch (NoSuchElementException | TimeoutException e){ 
			QAFWebElement changeCurb = csTest.getCurbLnkChageFromWindow();
			util.mouseoverAndClick(changeCurb, changeCurb); 
		} finally {
			getBundle().setProperty("selnium.wait.timeout", "20000");
			CommonUtils.waitAngularHasFinishedProcessing();
		} 
		getBundle().setProperty(FULFILLMENT_TYPE_KEY, CURBSIDE_SET);
		util.pass("Curbside clicked");
		CommonUtils.waitAngularHasFinishedProcessing();
	}

	@QAFTestStep(description = "User changes to curbside")
	public void iChangeCurbside(){
		CurbsideTestPage csTest = new CurbsideTestPage();
		CommonUtils.waitAngularHasFinishedProcessing();
		CommonUtils.waitForElement(csTest.getCurbBtnSelectCurb());
		csTest.getCurbBtnSelectCurb().click();
		CommonUtils.waitAngularHasFinishedProcessing();
		CommonUtils.waitForElement(csTest.getCurbHdrMapLoadItem());
		csTest.getCurbTxtStoreFromwndow().get(0).waitForPresent(MAX_WAIT_TIME*10);
		util.pass("Curbside changed");
	}

	/**
	 * Because of the fact they keep changing whether or not the names are passed
	 * in all caps or mixed case, toLower() is called for both the cmp name and store name
	 * @param storeName Store to search for
	 */
	@QAFTestStep(description = "User chooses {storeName}")
	public void choosesStoreByName(String storeName){
		CurbsideTestPage csTest = new CurbsideTestPage();
		CommonUtils.waitAngularHasFinishedProcessing();
		csTest.getCurbTxtStoreFromwndow().get(0).waitForPresent(MAX_WAIT_TIME*5);
		List<QAFWebElement> table_element = csTest.getCurbTxtStoreFromwndow(); 
		//APIHub hub = new APIHub();
		String cmpName = "";
		storeName = storeName.trim();
		QAFWebElement retRow = null;
		QAFWebElement defRow = null;
		String storeNum = "";
		FunctionUtils u = new FunctionUtils();

		for(QAFWebElement row : table_element ){
			CommonUtils.scrolltoelement(row);
			cmpName = row.findElement(By.className("name")).getText().toLowerCase();
			
			if(cmpName.equals(getBundle().getString("defaultstore.name"))){
				defRow = (QAFWebElement) row.findElement(By.tagName("button"));
			}
			
			if(cmpName.equals(storeName.toLowerCase())){
				retRow = (QAFWebElement) row.findElement(By.tagName("button"));
				getBundle().setProperty(CUR_STORE_NAME_KEY, cmpName); 
				storeNum = u.generateStoreNum(retRow.getAttribute("id")); 
				getBundle().setProperty(CUR_STORE_NUMBER_KEY, storeNum);
//				// Call API Hub to generate tax rate
//				try {
//					hub.genTaxInfo(storeNum);
//				} catch (UnsupportedOperationException | IOException e) {
//					util.info("Tax information not generated for " + storeName);
//					util.info("Using default tax rate");
//				}

				break;
			}
		}
		
		try{
			csTest.getCurbTxtStoreFromwndow().get(0).waitForPresent(MAX_WAIT_TIME*10);;
			retRow.waitForPresent(MAX_WAIT_TIME*5);
			retRow.click();
			CommonUtils.waitAngularHasFinishedProcessing();
			util.pass(storeName + " selected");
		} catch(NullPointerException e){
			util.info("Store " + storeName + " is not listed, selecting " + getBundle().getString("defaultstore.name"));
			defRow.click();
		}
		CommonUtils.sleep();
	}

	@QAFTestStep(description = "User inputs {zipcode} and selects closest store")
	public void chooseStoreByZip(String zipcode){
		CurbsideTestPage csTest = new CurbsideTestPage();

		util.enterValueAndSendEnter(csTest.getCurbEdtEnterZip(), zipcode);
		
		CommonUtils.waitForElement(csTest.getCurbBtnGetMapStoreSel(1 + ""));
		util.mouseoverAndClick(csTest.getCurbBtnGetMapStoreSel(1 + ""), csTest.getCurbBtnGetMapStoreSel(1 + ""));
		getBundle().setProperty(CUR_STORE_NAME_KEY, csTest.getCurbGetSelectedStoreName(1 + "").getText());

		util.pass("Closest store selected!");
	}

	@QAFTestStep(description = "Verify the user selected store is displaying on the home page")
	public void selectedStoreVerification(){
		HomeTestPage homepage = new HomeTestPage();
		String cmpName = getBundle().getProperty(CUR_STORE_NAME_KEY) + "";
		cmpName = cmpName.replaceAll("[\"'\u2018\u2019\u201c\u201d]", ""); 
		homepage.getHomeTxtCurCurbDisplay().waitForText(cmpName.toUpperCase(), MAX_WAIT_TIME);
		util.pass("Store displayed " + cmpName + " as expected");
	}
	
	@QAFTestStep(description = "Verify the user selected zipcode is displaying on the home page")
	public void selectedZipVerification(){
		HomeTestPage homepage = new HomeTestPage();
		String cmpName = getBundle().getProperty(CUR_STORE_NAME_KEY) + "";
		cmpName = cmpName.replaceAll("[\"'\u2018\u2019\u201c\u201d]", ""); 
		homepage.getHomeTxtCurDelDisplay().waitForText(cmpName, MAX_WAIT_TIME);
		util.pass("Store displayed " + cmpName + " as expected");
	}

	@QAFTestStep(description = "User navigates to store selection from curbside window")
	public void navToStoreSelect(){
		CurbsideTestPage curbside = new CurbsideTestPage();
		curbside.getCurbBtnChooseStoreMain().click();
		CommonUtils.waitForElement(curbside.getCurbBoxMapBox());
		util.pass("Navigated to store selection");
	}

	@QAFTestStep(description = "User selects store based on {number}")
	public void storeSelectByNum(String storeNumber){
		CurbsideTestPage csTest = new CurbsideTestPage();
		//APIHub hub = new APIHub();
//		try {
//			hub.getStoreName(storeNumber);
//			hub.genTaxInfo(storeNumber);
//		} catch (UnsupportedOperationException | IOException e) {
//			util.fail("Store information not set for " + storeNumber);
//		}		
		
		String cmpName =  (String)getBundle().getProperty(CUR_STORE_NAME_KEY);
		
		util.enterValueAndSendEnter(csTest.getCurbEdtEnterZip(), cmpName.replaceAll("\"", ""));

		CommonUtils.waitForElement(csTest.getCurbBtnGetMapStoreSel(1 + ""));
		util.mouseoverAndClick(csTest.getCurbBtnGetMapStoreSel(1 + ""), csTest.getCurbBtnGetMapStoreSel(1 + ""));

		util.pass(cmpName.replaceAll("\"", "") + " selected!");
	}
}
