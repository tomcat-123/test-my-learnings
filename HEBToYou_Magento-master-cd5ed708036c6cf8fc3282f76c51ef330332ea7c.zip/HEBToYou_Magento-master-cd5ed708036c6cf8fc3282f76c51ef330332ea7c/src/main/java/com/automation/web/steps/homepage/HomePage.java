package com.automation.web.steps.homepage;

import static com.automation.web.commonutils.CommonUtils.MAX_WAIT_TIME;


import static com.automation.web.commonutils.CommonUtils.getDriver;
import static com.automation.web.commonutils.FunctionUtils.CART_UNIQUE_ITEM_CNT_KEY;
import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NAME_KEY;
import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NUMBER_KEY;
import static com.automation.web.commonutils.FunctionUtils.FULFILLMENT_TYPE_KEY;
import static com.automation.web.commonutils.FunctionUtils.TAX_PERCENTAGE_KEY;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.APIHub;
import com.automation.web.commonutils.CommonUtils;
import com.automation.web.commonutils.FunctionUtils;

import com.automation.web.pages.browseandsearch.SearchTestPage;
import com.automation.web.pages.browseandsearch.ShopTestPage;
import com.automation.web.pages.homepage.HomeTestPage;

import com.automation.web.pages.homepage.RegisterTestPage;

import com.automation.web.steps.curbside.Curbside;
import com.automation.web.steps.delivery.Delivery;
import com.perfecto.reportium.client.ReportiumClient;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*
All the Steps under HomePage file 

User clicks login/Register button
User closes login popup
User on home page
User closes the banners
User clicks User Account tab
User views profile information
Hot user clicks logout tab
User logs out of account
User clicks on My Profile
Verify categories displayed in main content of categories page
Verify aisle categories displayed
Verify each category in the left nav pane on the categories page
Verify each category in the header
User clicks {category} in header
Verify the landing page of {category}
Generate product info for {product ID Number}
Generate tax percentage for {Store Number}
Generate product price listing for {Product Number}
Verify fulfillment type and store change to default
Verify store reverts to last store on logout
Verify item check for availability on selecting {store}
Verify item check switching from Curbside to Delivery
Navigate to Ways To Shop Page
Verify ways to shop page left nav pane




*/

public class HomePage{
	// List of header category titles.
	// 0 position is null for easier navigation
	private static final String [] CATEGORY_TYPES =
		{ "", "Fruit & Vegetables"
		, "Meat & Seafood", "Dairy & Frozen"
		, "Food to Go", "Drinks, Beer, & Wine"
		};
	
	protected ReportiumClient reportiumclient ;
	
	CommonUtils util = new CommonUtils();
	Actions act = new Actions(CommonUtils.getDriver());
	


	@QAFTestStep(description="User clicks login/Register button")
	public void userClicksLoginRegisterButton(){
		HomeTestPage homeTestPage = new HomeTestPage();
		homeTestPage.waitForPageToLoad();
		
		homeTestPage.getHomeImgHeblogo().verifyPresent();
		homeTestPage.getHomeLblLogin().waitForEnabled(MAX_WAIT_TIME);
		CommonUtils.scrolltoelement(homeTestPage.getHomeLblLogin());
		homeTestPage.getHomeLblLogin().click();
		//homeTestPage.loadPage();
		util.pass("Clicked login/Register button");
	}
	
	
	/**
	 * Unata eliminated the close button, so sending the "Escape" key now
	 */
	@QAFTestStep(description = "User closes login popup")
	public void iCloseLoginPopup() {
		HomeTestPage htp = new HomeTestPage();
		act.sendKeys(Keys.ESCAPE).perform();
		htp.loadPage();
		util.pass("Login window closed.");
	}

	/**
	 * Opens application and initializes cart count to zero
	 */
	@QAFTestStep(description = "User on home page")
	public synchronized void iAmOnHomePage() {
		HomeTestPage homeTestPage = new HomeTestPage();
		String defaultStoreName = getBundle().getString("defaultStore.name");
		String defaultStoreNum = getBundle().getString("defaultStore.number");


		// Set property values: Item count, current store, current tax percent
		getBundle().setProperty(CART_UNIQUE_ITEM_CNT_KEY, 0);
		getBundle().setProperty(CUR_STORE_NAME_KEY, defaultStoreName);
		getBundle().setProperty(CUR_STORE_NUMBER_KEY, defaultStoreNum);
		getBundle().setProperty(TAX_PERCENTAGE_KEY, 0.0);
		// getTax(defaultStoreNum);

		System.out.println("Opening HEBToYou Application");
		// reportiumclient.reportiumAssert("APplication launched successful as a
		// cold user", true);
		homeTestPage.waitForPageToLoad();
		getBundle().setProperty("User", "Cold");
		getBundle().setProperty("myEmail", "Cold");
		destroyBanner();
		util.pass("HEBToYou Home page is Displayed");
		
	}
	
	

	/**
	 * Deletes all the banners that may interfere with later operations. If no banners are currently active, function
	 * simply returns
	 */
	@QAFTestStep(description = "User closes the banners")
	public void destroyBanner(){		
		HomeTestPage homepage = new HomeTestPage();
		
		List<QAFWebElement> banners = homepage.getHomeBtnBannerClose();		
		Actions act = new Actions(CommonUtils.getDriver());
		int num = banners.size();
		if (num>0){		
		try{
			act.moveToElement(banners.get(0));
		} catch(IndexOutOfBoundsException e){
			return;
		}
		
		for(int i = 0; i < num; i++){
			act.click();
			act.perform();
		}
		}
		else
		{util.info("Banners not exist in Home page");}

	}

	/**
	 * If the user has anything in their cart, the sidecart will "jump" in front of tab just long enough
	 * to close out the options. The sleep call cancels this effect
	 */
	@QAFTestStep(description = "User clicks User Account tab")
	public void iClickYourAcctTab(){
		HomeTestPage htp = new HomeTestPage();
//		htp.loadPage();
		CommonUtils.sleep();
		CommonUtils.scrolltoelement(htp.getHomeBtnYourAccount());
		
		htp.getHomeBtnYourAccount().click();
		util.pass("User options tab opened");
	}

	@QAFTestStep(description = "User views profile information")
	public void iGetUserAccountInformation(){
		RegisterTestPage register = new RegisterTestPage();
		register.getRegisterEdtCiEmail().waitForEnabled(MAX_WAIT_TIME);

		util.pass("Navigated to My Profile");
	}
	
	@QAFTestStep(description = "Hot user clicks logout tab")
	public void userClicksLogoutTab(){
		HomeTestPage htp = new HomeTestPage();
		
		htp.getHomeLnkLogout().click();
		CommonUtils.waitAngularHasFinishedProcessing();
		htp.getHomeLblLogin().waitForText("Log In / Register", MAX_WAIT_TIME * 3);
		util.pass("Logout clicked");
	}
	
	@QAFTestStep(description = "User logs out of account")
	public void userLogsOut(){
		iClickYourAcctTab();
		userClicksLogoutTab();
	}

	/**
	 * Will navigate to user's name link to create dropdown
	 */
	@QAFTestStep(description = "User clicks on My Profile")
	public void iClickOnMyAccountUser() {
		RegisterTestPage register = new RegisterTestPage();

//		QAFWebElement isOpen = (QAFWebElement) util.generateWebElement("//span[@class='dropdown open']");
//		isOpen.waitForEnabled(MAX_WAIT_TIME);
		
		//register.getRegisterLnkMyAccount().waitForPresent(MAX_WAIT_TIME);
		//register.getRegisterLnkMyAccount().click();
		
		register.getRegisterLnkMyProfile().waitForPresent(MAX_WAIT_TIME);
		register.getRegisterLnkMyProfile().click();
		
		//QAFWebElement profile = register.getRegisterLnkMyProfile(); 
		//profile.click();

		try{
			register.getRegisterEdtCiEmail().waitForEnabled(MAX_WAIT_TIME*3);
		} catch (TimeoutException e){
			this.iClickYourAcctTab();
			register.getRegisterLnkMyProfile().click();
		//	profile.click();
		}
		register.getRegisterEdtCiEmail().waitForEnabled(MAX_WAIT_TIME);
		util.pass("My Profile clicked");
	}
		
	@QAFTestStep(description = "Verify categories displayed in main content of categories page")
	public void catInMainContent(){
		SearchTestPage scp = new SearchTestPage();
		
		getDriver().get(getBundle().getString("env.baseurl") + "/shop/categories");
		QAFWebElement catImg = scp.getSearchLnkFisrtResultFromCdp();
		catImg.waitForEnabled(MAX_WAIT_TIME);
		ShopTestPage nav = new ShopTestPage();

		CommonUtils.scrolltoelement(nav.getNavLiMainCat().get(0));
		compareCategories(nav.getNavLiMainCat());
//		for(int i = 1; i < CATEGORY_TYPES.length; i++){
//			util.print(nav.getNavLiMainCat().get(i - 1).getText());
//			nav.getNavLiMainCat().get(i-1).waitForEnabled(MAX_WAIT_TIME);
//			if(nav.getNavLiMainCat().get(i - 1).getText().equals(CATEGORY_TYPES[i])){
//				util.info("Nav Pane Category found: " + nav.getNavLiMainCat().get(i - 1).getText());
//			} else {
//				util.fail("Category found: + " + nav.getNavLiMainCat().get(i-1));
//				return;
//			}
//		}
//		util.pass("All categories match");
	}
	
	
	@QAFTestStep(description = "Verify aisle categories displayed")
	public void verifyAisleCategories(){
		ShopTestPage nav = new ShopTestPage();
		HomeTestPage homepage = new HomeTestPage();
		
		QAFWebElement catImg = homepage.getHomeTxtShopByAisle();
		catImg.waitForEnabled(MAX_WAIT_TIME);
		CommonUtils.sleep();
		act.moveToElement(nav.getNavLiAislePane().get(nav.getNavLiAislePane().size() - 1));
		act.perform();
		compareCategories(nav.getNavLiAislePane());
	}
	
	
	@QAFTestStep(description = "Verify each category in the left nav pane on the categories page")
	public void verifyCategoriesInNavPane(){
		getDriver().get(getBundle().getString("env.baseurl") + "/shop/categories");
		ShopTestPage nav = new ShopTestPage(); 

		compareCategories(nav.getNavLiNavPaneCat());
	}

	/**
	 * Builds a hashmap of the elements found and expected elements, then generates a set
	 * to compare the two items. If the sets match, then all the categories are accounted for
	 * @param listFound Categories generated with XPath or .loc file
	 */
	private void compareCategories(List<QAFWebElement> listFound){
		HashMap<String, String> foundElements = new HashMap<>();
		HashMap<String, String> storedElements = new HashMap<>();

		for(int i = 1; i < CATEGORY_TYPES.length; i++){
			foundElements.put(listFound.get(i - 1).getText(), listFound.get(i - 1).getText());
			storedElements.put(CATEGORY_TYPES[i], CATEGORY_TYPES[i]);
			util.info("Category found: " + listFound.get(i - 1).getText());
		}

		Set<String> set1 = foundElements.keySet();
		Set<String> set2 = storedElements.keySet();
		if(set1.equals(set2)){
			util.pass("All categories found");
		} else {
			util.fail("Categories missing");

		}
	}

	@QAFTestStep(description = "Verify each category in the header")
	public void iVerifyEachCategoryInTheHeader(){
		ShopTestPage navigation = new ShopTestPage();
		HomeTestPage htp = new HomeTestPage();
		String categoryHeaderName;
		// Click on header, verify, navigate home, and continue
		for(int i = 1; i < CATEGORY_TYPES.length; i++){
			navigation.getNavGetICatHeader(i+"").click();
			navigation.loadPage();
			categoryHeaderName=navigation.getNavPageLoadItem().getText();
			//if(navigation.getNavPageLoadItem().getText().equals(CATEGORY_TYPES[i]))

			if(categoryHeaderName.trim().contains(CATEGORY_TYPES[i].trim()))
				util.info("Successfully navigated to " + CATEGORY_TYPES[i]);
			else
				util.fail("Unable to navigate to " + CATEGORY_TYPES[i]);

			htp.getNavBtnToHome().click();
			htp.loadPage();
		}
		util.pass("All headers successfully navigated and verified");
	}

	@QAFTestStep(description = "User clicks {category} in header")
	public void clickOnXInHeader(String categoryName){
		ShopTestPage navigation = new ShopTestPage();
		for(int i = 1; i < CATEGORY_TYPES.length; i++){
			if(CATEGORY_TYPES[i].toLowerCase().equals(categoryName.toLowerCase())){
				navigation.getNavGetICatHeader(i+"").click();
				navigation.loadPage();
				String header = navigation.getNavPageLoadItem().getText(); 
				util.pass(header + " has loaded");
			}
		}
	}

	/**
	 * Checks for a single header page. NEEDS to be correct syntax used in array constant above
	 */
	@QAFTestStep(description = "Verify the landing page of {category}")
	public void verifyLandingPageOfX(String categoryName){
		ShopTestPage navigation = new ShopTestPage();
		for(int i = 1; i < CATEGORY_TYPES.length; i++){
			if(CATEGORY_TYPES[i].toLowerCase().equals(categoryName.toLowerCase())){
				String curPage = navigation.getNavPageLoadItem().getText();
				if(curPage.toLowerCase().equals(categoryName.toLowerCase())){
					util.pass(categoryName + " is verified");
				}
			}
		}
//		util.fail(categoryName + " page not loaded correctly");
	}

	/**
	 * Generates the min, max value, as well as whether or not a product is taxable
	 * by item number. Can be called independently
	 * @param productIdNum Product to gather information on. Can contain the leading
	 * zeroes
	 */
	@QAFTestStep(description = "Generate product info for {product ID Number}")
	public void getProduct(String productIdNum){
		APIHub hub = new APIHub();
		try {
			hub.genProductInfo(productIdNum);
		} catch (UnsupportedOperationException | IOException e) {
			util.fail("Product information not loaded for " + productIdNum);
		}
	}

	/**
	 * Store to get the tax rate of. Can be called independently
	 * @param storeNum Store number to get the tax rate from
	 */
	@QAFTestStep(description = "Generate tax percentage for {Store Number}")
	public void getTax(String storeNum){
		APIHub hub = new APIHub();
		try {
			hub.genTaxInfo(storeNum);
			if(getBundle().getProperty(TAX_PERCENTAGE_KEY).equals("null")){
				getBundle().setProperty(TAX_PERCENTAGE_KEY, ".0825");
				util.fail("Tax not generated for store number " + storeNum + ", set to default percentage");
			}
		} catch (UnsupportedOperationException | IOException e) {
			util.fail("Tax not generated for store number " + storeNum);
		}
	}

	/**
	 * Gets the sale and location price of an item. Assumes the store number has been populated in
	 * the bundle() hash map
	 * @param productIdNum Product to get information of
	 */
	@QAFTestStep(description = "Generate product price listing for {Product Number}")
	public void getListing(String productIdNum){
		APIHub hub = new APIHub();
		try {
			hub.genPriceLocation(productIdNum);
		} catch (UnsupportedOperationException | IOException e) {
			util.fail("Store information not generated for store number " 
					+ getBundle().getProperty(FunctionUtils.CUR_STORE_NUMBER_KEY)
					+ ", product num: " + productIdNum);	
		}
	}
	
	@QAFTestStep(description = "Verify fulfillment type and store change to default")
	public void changeToDefault(){
		HomeTestPage htp = new HomeTestPage();
		if(htp.getHomeTxtCurbOrDelVal().getText().toLowerCase().equals("curbside pickup")){
			util.pass("Curbside Displayed!");
		} else {
			util.fail("Curbside not displayed");
		}
		String foundDisplay = htp.getHomeTxtCurCurbDisplay().getText().toLowerCase();

		String storedDisplay = getBundle().getString("defaultStore.name").toLowerCase();
		
		if(foundDisplay.equals(storedDisplay)){
			util.pass("Default store set to: " + getBundle().getString("defaultStore.name"));
		} else {
			util.fail("Default store improperly set to: " + htp.getHomeTxtCurCurbDisplay().getText());
		}
		
		if(htp.getHomeTxtReservedTime().getText().contains("RESERVE")){
			util.pass("Time slot set to default");
		} else {
			util.fail("Timeslot not set to default. Displayed: " + htp.getHomeTxtReservedTime().getText());
		}
	}
	
	@QAFTestStep(description = "Verify store reverts to last store on logout")
	public void verifySameStore(){
		HomeTestPage htp = new HomeTestPage();
		String fulfillmentType = getBundle().getProperty(FULFILLMENT_TYPE_KEY) + "";
		String storeName = getBundle().getProperty(CUR_STORE_NAME_KEY) + "";
		if(htp.getHomeTxtCurbOrDelVal().getText().toLowerCase().equals(fulfillmentType.toLowerCase())){
			util.pass("Fulfillment type reverted correctly");
		} else {
			util.info("Displayed: " + htp.getHomeTxtCurbOrDelVal().getText());
			util.info("Bundle: " + fulfillmentType);
			util.fail("Fulfillment types do not match");
		}
		
		if(htp.getHomeTxtCurCurbDisplay().getText().toLowerCase().equals(storeName.toLowerCase())){
			util.pass("Store displayed correctly: " + storeName);
		} else {
			util.fail("Store incorrectly set to: " + htp.getHomeTxtCurCurbDisplay().getText());
		}
	}
	
	@QAFTestStep(description = "Verify item check for availability on selecting {store}")
	public void verifyItemAvail(String storeName){
		ShopTestPage nav = new ShopTestPage();
		Curbside curbside = new Curbside();
		curbside.iOpenCurbisdeWindow();
		curbside.iSelectCSPickup();
		curbside.iChangeCurbside();
		curbside.choosesStoreByName(storeName);
		nav.getNavBoxCompareCartModal().waitForVisible(MAX_WAIT_TIME);
		util.pass("Items checked");
	}
	
	@QAFTestStep(description = "Verify item check switching from Curbside to Delivery")
	public void verifyCurbSwitch(){
		Delivery delivery = new Delivery();
		Curbside curbside = new Curbside();
		ShopTestPage nav = new ShopTestPage();
		curbside.iOpenCurbisdeWindow();
		curbside.iSelectCSPickup();
		delivery.userSelectsDeliveryService();
		try{
			nav.getNavBoxCompareCartModal().waitForVisible(MAX_WAIT_TIME);
			util.pass("Cart availability checked");
		} catch(TimeoutException e){
			util.fail("Warning module not activated.");
		}
	}
	
	@QAFTestStep(description = "Navigate to Ways To Shop Page")
	public void navigateToWaysToShopPage() {
		HomeTestPage home = new HomeTestPage();
		ShopTestPage shop = new ShopTestPage();
		home.getLnkSeemorewaytoshop().waitForPresent(MAX_WAIT_TIME);
		home.getLnkSeemorewaytoshop().click();
		util.pass("Clicked on see more-way to shop link");
		if (shop.gettxtHeader().isPresent()) {
			util.pass("Successfully naviagted to WayToShop Page");
		} else {
			util.fail("WayToShop Page is not displayed");
		}

	}

	@QAFTestStep(description = "Verify ways to shop page left nav pane")
	public void verifyWaysToShopPageLeftNavPane() {
		ShopTestPage shop = new ShopTestPage();

		List<QAFWebElement> leftNav = shop.getLiLeftnavigations();

		List<String> leftNavFromPage = new ArrayList<String>();

		List<String> leftNavFromTestData = ConfigurationManager.getBundle().getList("wayToShop.leftNav.value");

		for (QAFWebElement ele : leftNav) {
			leftNavFromPage.add(ele.getText());
		}

		if (leftNavFromTestData.containsAll(leftNavFromPage)) {
			util.pass(
					"Successfully Verfied the WaysToShop Page left nav pane lists:  departments, previous purchases, weekly ad, collection ");
		} else {
			util.fail(
					"Failed to verfiy the WaysToShop Page left nav pane lists:  departments, previous purchases, weekly ad, collection ");
		}
	}
	
	
}
