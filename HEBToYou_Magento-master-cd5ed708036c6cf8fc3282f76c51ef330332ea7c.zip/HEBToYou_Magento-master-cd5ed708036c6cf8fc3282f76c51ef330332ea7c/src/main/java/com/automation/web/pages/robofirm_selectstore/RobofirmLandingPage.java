package com.automation.web.pages.robofirm_selectstore;

import java.util.List;
import static com.automation.web.commonutils.CommonUtils.MAX_WAIT_TIME;


import com.automation.web.components.weeklyads.WeeklyAdsOverlayItemBlock;
import com.automation.web.components.weeklyads.WeeklyAdsPageItemBlock;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RobofirmLandingPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}
	
	
	@FindBy(locator = "robofirm.txt.storeserach")
	private QAFWebElement txtStoreserach;

	@FindBy(locator = "robofirm.btn.findstore")
	private QAFWebElement btnFindstore;
	
	@FindBy(locator = "robofirm.lbl.storename")
	private QAFWebElement lblStorename;
	
	@FindBy(locator = "robofirm.btn.startshoping")
	private QAFWebElement btnStartShoping;
	
	
	

	public QAFWebElement getTxtStoreserach() {
		return txtStoreserach;
	}

	public QAFWebElement getBtnFindstore() {
		return btnFindstore;
	}

	public QAFWebElement getLblStorename() {
		return lblStorename;
	}

	public QAFWebElement getBtnStartShoping() {
		return btnStartShoping;
	}


	
	
	

}