package com.automation.web.components.SearchAndBrowse;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ProductBlocks extends QAFWebComponent {

	public ProductBlocks(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}

	@FindBy(locator = "product.img.itemPicture")
	private QAFWebElement imgItemPicture;

	public QAFWebElement getImgItemPicture() {
		return imgItemPicture;
	}

}
