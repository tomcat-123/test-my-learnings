package com.automation.web.steps.registerandlogin;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static com.automation.web.commonutils.CommonUtils.MAX_WAIT_TIME;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import com.qmetry.qaf.automation.step.QAFTestStep;

import com.automation.web.commonutils.CommonUtils;
import com.automation.web.databean.NewUserRegisterBean;
import com.automation.web.pages.homepage.HomeTestPage;
import com.automation.web.pages.homepage.RegisterTestPage;
import com.automation.web.steps.cartandcheckout.CartSteps;
import com.automation.web.steps.cartandcheckout.CheckoutSteps;

public class Registration{
	Actions act = new Actions(CommonUtils.getDriver());
	CommonUtils util = new CommonUtils();

	/**
	 * Method to confirm that bad information has been submitted for account registration
	 * @param register Register object for verification
	 * @param msg Message to be sent to the reporter log
	 */
	public void registrationFailSubmit(RegisterTestPage register, String msg){
		CommonUtils.scrolltoelement(register.getRegisterBtnCreateNewAcc());
		register.getRegisterBtnCreateNewAcc().click();

		if(register.getRegisterLblRegiFailed().verifyEnabled())
			util.pass(msg);
		else
			util.fail("Registration successful");
	}

	@QAFTestStep(description = "User clicks registration tab")
	public void iClickRegistrationPage() {
		RegisterTestPage register = new RegisterTestPage();
		CommonUtils.waitForElement(register.getRegisterTabNewUsrTab());

		register.getRegisterTabNewUsrTab().click();

		if (register.getRegisterEdtEmail().isPresent()) {
			util.pass("Navigated to register page.");
		} else {
			util.fail("Not navigated to register page.");
		}
	}

	@QAFTestStep(description = "Enter valid phone number")
	public void enterValidPhoneNumber(){
		RegisterTestPage register = new RegisterTestPage();
		String mobileNum = getBundle().getString("hotuser1.mobile");

		CommonUtils.waitForElement(register.getRegisterEdtMobileNum());
		util.enterValues(register.getRegisterEdtMobileNum(), mobileNum);
		util.pass("Mobile Number " + mobileNum + " entered");
	}

	@QAFTestStep(description = "Enter valid email id")
	public void enterValidEmailId(){
		NewUserRegisterBean registerBean = new NewUserRegisterBean();
		registerBean.fillRandomData();
		String email = registerBean.getEmail();
		
		RegisterTestPage register = new RegisterTestPage();

		CommonUtils.waitForElement(register.getRegisterEdtEmail());
		util.enterValues(register.getRegisterEdtEmail(), email);
		util.info("Email " + email + " entered");
	}

	@QAFTestStep(description = "User enters required fields in registration page")
	public void iEnterAllRequiredFieldsInregistrationPage(){
		NewUserRegisterBean registerBean = new NewUserRegisterBean();
		registerBean.fillRandomData();
		registerBean.setMobileNum(getBundle().getString("hotuser1.mobile"));
		registerBean.fillUiElements();
		util.pass("Registration fields filled");
	}

	@QAFTestStep(description = "User sucessfully submits the registration form")
	public void iSubmitTheregistrationForm(){
		RegisterTestPage register = new RegisterTestPage();
		register.getRegisterBtnCreateNewAcc().click();
		register.getRegisterBtnCreateNewAcc().waitForNotVisible(MAX_WAIT_TIME * 2);

		if(register.getRegisterLblRegiFailed().isPresent()){
			util.info("Registration not accepted");
		} else {
			util.pass("Registration successful");
		}
	}

	@QAFTestStep(description = "User enters invalid password in register")
	public void submitBadFirstPass(){
		RegisterTestPage register = new RegisterTestPage();

		NewUserRegisterBean registerBean = new NewUserRegisterBean();
		registerBean.fillRandomData();
		registerBean.setPassword("1234");
		registerBean.fillUiElements();

		registrationFailSubmit(register, "Registration failed. Bad password submitted.");
	}

	@QAFTestStep(description = "Enter wrong confirm password in register")
	public void iSubmitBadPasswords(){
		RegisterTestPage register = new RegisterTestPage();
		NewUserRegisterBean registerBean = new NewUserRegisterBean();
		registerBean.fillRandomData();
		registerBean.setConfPassword("ClearlyWrongPassword");
		registerBean.fillUiElements();
		util.pass("Registration fields filled");

		registrationFailSubmit(register, "Registration failed. Wrong confirm password submitted.");
	}

	@QAFTestStep(description = "User enters invalid email id in register")
	public void iSubmitBadEmail(){
		RegisterTestPage register = new RegisterTestPage();
		NewUserRegisterBean registerBean = new NewUserRegisterBean();
		registerBean.fillRandomData();
		registerBean.setEmail("ggtest2gmail.com");
		registerBean.setMobileNum(getBundle().getString("hotuser1.mobile"));
		registerBean.fillUiElements();
		util.pass("Registration fields filled");
		Actions act = new Actions(CommonUtils.getDriver());
		act.moveToElement(register.getRegisterBtnCreateNewAcc());
		act.perform();
		if(! register.getRegisterBtnCreateNewAcc().isEnabled()){
			util.pass("Registration not successful");
		} else {
			util.fail("Registration successful");
		}
	}

	@QAFTestStep(description = "User clicks opt-in button")
	public void iClickOptInBtn(){
		RegisterTestPage register = new RegisterTestPage();
		register.getRegisterChkPromotions().click();
		util.pass("Opt in button clicked");
	}

	@QAFTestStep(description = "User closes registration window")
	public void iCloseRegistrationWindow(){
		HomeTestPage htp = new HomeTestPage();
		act.sendKeys(Keys.ESCAPE).perform();
		htp.loadPage();
		util.pass("Registration window closed");

	}

	/**
	 * Edits first, last, and email using class constants
	 */
	@QAFTestStep(description = "I edit my contact information")
	public void iEditMyContactInformation(){
		RegisterTestPage register = new RegisterTestPage();
		util.enterValues(register.getRegisterEdtCiFirstName(), getBundle().getString("hotuser1.firstName"));
		util.enterValues(register.getRegisterEdtCiLastName(), getBundle().getString("hotuser1.lastName"));
		util.enterValues(register.getRegisterEdtCiEmail(), getBundle().getString("hotuser1.email"));
	}	
	
	@QAFTestStep(description = "User creates new account after Reviewing Cart")
	public void createAcctAfterCart(){
		CartSteps cart = new CartSteps();
		cart.continueFromReviewCartPg();
		this.iClickRegistrationPage();
		this.iEnterAllRequiredFieldsInregistrationPage();
		this.iSubmitTheregistrationForm();
	}
}
