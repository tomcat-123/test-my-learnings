package com.automation.web.databean;

import com.qmetry.qaf.automation.data.BaseFormDataBean;
import com.qmetry.qaf.automation.ui.annotations.UiElement;
import com.qmetry.qaf.automation.util.Randomizer;
/**
 * Class to generate a random user information at checkout. @UiElement will populate
 * at whatever location is given, so different location names are important. Sample invocation
 * of UiElement will look like:
 * <code>
 * <p>{@literal @}Randomizer(type = RandomizerTypes.{@literal <}Type Style>, length = {@literal <}string length>, suffix = {@literal <}String addendum>")</p>
 * <p>{@literal @}UiElement(fieldLoc = {@literal <}.loc variable>, order = {@literal <}order of execution>)</p>
 * <p>private String stringName;</p>
 * </code>
 * <p>Note: Can also randomize buttons on whether or not they need to be clicked. 
 * @author Garrett Griffin
 *
 */
public class EditPersonalInfoBean extends BaseFormDataBean{
	@Randomizer(format = "99/", minval = 01, maxval = 12)
	private String birthdayMon;
	
	@Randomizer(format = "99/", minval = 01, maxval = 31)
	private String birthdayDay;
	
	@Randomizer(format = "9999", minval = 1900, maxval = 2000)
	private String birthdayYear;
	
	@UiElement(fieldLoc = "register.edt.Birthday", order = 8)
	private String birthdayInput;
	
	@Randomizer(dataset = {"male", "female"})
	private String gender;
	
	/**
	 * Checks if the date is a leap year or not. If it is, do nothing. If it is, change the month to
	 * January. Just easier that way
	 */
	private void validDate(){
		if((Integer.parseInt(birthdayYear) % 4 == 0 && Integer.parseInt(birthdayYear) % 100 != 0)
				|| Integer.parseInt(birthdayYear) % 400 == 0){
			birthdayMon = (Integer.parseInt(this.birthdayMon) - 1) + "";
		}
		
	}

	@Override
	/**
	 * Fills in all data, creates a valid birthday, and generates a readable set of instructions
	 */
	public void fillRandomData() {
		super.fillRandomData();
		validDate();
		this.birthdayInput = this.birthdayDay + this.birthdayMon + this.birthdayYear;
	}

	public String getBirthdayMon() {
		return birthdayMon;
	}

	public String getBirthdayDay() {
		return birthdayDay;
	}

	public String getBirthdayYear() {
		return birthdayYear;
	}

	public String getBirthdayInput() {
		return birthdayInput;
	}

	public void setBirthdayMon(String birthdayMon) {
		this.birthdayMon = birthdayMon;
	}

	public void setBirthdayDay(String birthdayDay) {
		this.birthdayDay = birthdayDay;
	}

	public void setBirthdayYear(String birthdayYear) {
		this.birthdayYear = birthdayYear;
	}

	public void setBirthdayInput(String birthdayInput) {
		this.birthdayInput = birthdayInput;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
}
