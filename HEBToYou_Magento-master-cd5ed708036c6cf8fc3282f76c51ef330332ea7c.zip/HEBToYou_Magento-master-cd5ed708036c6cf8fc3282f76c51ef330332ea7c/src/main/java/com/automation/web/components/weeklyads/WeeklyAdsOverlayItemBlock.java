package com.automation.web.components.weeklyads;

import java.util.List;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class WeeklyAdsOverlayItemBlock extends QAFWebComponent {

	public WeeklyAdsOverlayItemBlock(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}
	

	@FindBy(locator = "wklyad.lbl.weeklyadoverlaysavetag")
	private QAFWebElement  lblWeeklyAdOverlaySavetag;
	
	@FindBy(locator = "wklyad.btn.weeklyadoverlayaddedtocart")
	private QAFWebElement  btnWeeklyAdOverlayAddedToCart;
	
	
	@FindBy(locator = "wklyad.btn.weeklyadoverlayaddtocart")
	private QAFWebElement  btnWeeklyAdOverlayAddtocart;
	
	@FindBy(locator = "wklyad.img.weeklyadoverlayitmimg")
	private QAFWebElement  imgWeeklyAdOverlayItmImg;
	
	
	public QAFWebElement getImgWeeklyAdOverlayItmImg() {
		return imgWeeklyAdOverlayItmImg;
	}


	public QAFWebElement getBtnWeeklyAdOverlayAddtocart() {
		return btnWeeklyAdOverlayAddtocart;
	}


	public QAFWebElement getBtnWeeklyAdOverlayAddedToCart() {
		return btnWeeklyAdOverlayAddedToCart;
	}


	public QAFWebElement getLblWeeklyAdOverlaySavetag() {
		return lblWeeklyAdOverlaySavetag;
	}


}
