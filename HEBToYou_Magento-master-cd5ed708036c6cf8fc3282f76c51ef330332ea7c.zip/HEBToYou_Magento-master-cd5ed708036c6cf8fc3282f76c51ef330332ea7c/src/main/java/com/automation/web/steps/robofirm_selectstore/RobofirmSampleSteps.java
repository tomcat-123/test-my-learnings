package com.automation.web.steps.robofirm_selectstore;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import static com.automation.web.commonutils.CommonUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.FunctionUtils.CART_UNIQUE_ITEM_CNT_KEY;
import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NAME_KEY;
import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NUMBER_KEY;
import static com.automation.web.commonutils.FunctionUtils.TAX_PERCENTAGE_KEY;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.automation.web.commonutils.CommonUtils;
import com.automation.web.commonutils.PerfectoUtils;

import com.automation.web.components.weeklyads.WeeklyAdsOverlayItemBlock;
import com.automation.web.components.weeklyads.WeeklyAdsPageItemBlock;
import com.automation.web.pages.browseandsearch.ShopTestPage;
import com.automation.web.pages.cartandcheckout.CartTestPage;
import com.automation.web.pages.homepage.HomeTestPage;
import com.automation.web.pages.robofirm_selectstore.RobofirmLandingPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RobofirmSampleSteps {
	CommonUtils util = new CommonUtils();
	boolean itemfoundL3 = false;

	@QAFTestStep(description = "The user is on Robofirm landing page")
	public synchronized void userOnRobofirmLandingpage() {
		HomeTestPage homeTestPage = new HomeTestPage();
		
		String StoreName = getBundle().getString("store1.name");
		String StoreNum = getBundle().getString("store1.number");


		// Set property values: Item count, current store, current tax percent
		getBundle().setProperty(CUR_STORE_NAME_KEY, StoreName);
		getBundle().setProperty(CUR_STORE_NUMBER_KEY, StoreNum);
		// getTax(defaultStoreNum);

		System.out.println("Opening Robofirm landing page Application");
		// reportiumclient.reportiumAssert("APplication launched successful as a
		// cold user", true);
		homeTestPage.waitForPageToLoad();
		getBundle().setProperty("User", "Cold");
		getBundle().setProperty("myEmail", "Cold");
		util.pass("Launched Robofirm landing page");

	}

	@QAFTestStep(description = "Select a store from Robofirm landing page")
	public synchronized void selectAstoreFromRobofirmLandingPage() {
		HomeTestPage homeTestPage = new HomeTestPage();
		RobofirmLandingPage selectStore = new RobofirmLandingPage();

		String defaultStoreName = getBundle().getString("store1.name");
		util.enterValues(selectStore.getTxtStoreserach(), defaultStoreName);
		selectStore.getBtnFindstore().click();
		selectStore.getLblStorename().waitForPresent(MAX_WAIT_TIME);
		util.info("Selected Store Name: "+selectStore.getLblStorename().getText());
		selectStore.getBtnStartShoping().click();
		util.info("Clicked Start Shopping Btn ");
		homeTestPage.getHomeEdtSearchtext().waitForPresent(MAX_WAIT_TIME);
		util.pass("Store Selected Successfully from Robofirm landing page");
	}

//	@QAFTestStep(description = "User on home page")
//	public synchronized void iAmOnHomePage() {
//		HomeTestPage homeTestPage = new HomeTestPage();
//		String defaultStoreName = getBundle().getString("defaultStore.name");
//		String defaultStoreNum = getBundle().getString("defaultStore.number");
//
//
//		// Set property values: Item count, current store, current tax percent
//		getBundle().setProperty(CART_UNIQUE_ITEM_CNT_KEY, 0);
//		getBundle().setProperty(CUR_STORE_NAME_KEY, defaultStoreName);
//		getBundle().setProperty(CUR_STORE_NUMBER_KEY, defaultStoreNum);
//		getBundle().setProperty(TAX_PERCENTAGE_KEY, 0.0);
//		// getTax(defaultStoreNum);
//
//		System.out.println("Opening HEBToYou Application");
//		// reportiumclient.reportiumAssert("APplication launched successful as a
//		// cold user", true);
//		homeTestPage.waitForPageToLoad();
//		getBundle().setProperty("User", "Cold");
//		getBundle().setProperty("myEmail", "Cold");
//		destroyBanner();
//		util.pass("HEBToYou Home page is Displayed");
//
//	}

//	/**
//	 * Deletes all the banners that may interfere with later operations. If no
//	 * banners are currently active, function simply returns
//	 */
//	@QAFTestStep(description = "User closes the banners")
//	public void destroyBanner() {
//		HomeTestPage homepage = new HomeTestPage();
//
//		List<QAFWebElement> banners = homepage.getHomeBtnBannerClose();
//		Actions act = new Actions(CommonUtils.getDriver());
//		int num = banners.size();
//		if (num > 0) {
//			try {
//				act.moveToElement(banners.get(0));
//			} catch (IndexOutOfBoundsException e) {
//				return;
//			}
//
//			for (int i = 0; i < num; i++) {
//				act.click();
//				act.perform();
//			}
//		} else {
//			util.info("Banners not exist in Home page");
//		}
//
//	}

	

	@QAFTestStep(description = "Navigate to Random Category")
	public synchronized void navigateToRandomCategory() {
		ShopTestPage category=new ShopTestPage();
		CommonUtils utill = new CommonUtils();

		boolean itemfound = false;

		int min = 1;
		int L1catcount = category.getLiLeftnavLOneCategory().size();
		int randomlevelCat = mathRandom(min, L1catcount - min);
		category.getLiLeftnavLOneCategory().get(randomlevelCat).verifyPresent();
		category.getLiLeftnavLOneCategory().get(randomlevelCat).click();
		if (itemfoundL3) {
			// ignore
		} else {
			if (category.getLblErrmsgnoitem().isPresent()) {
				navigateToRandomCategory();
			}

			if (itemfoundL3) {
				// ignore
			} else {

				category.getBtnAddtocart().get(min - 1).waitForPresent(MAX_WAIT_TIME);
				itemfound = category.getBtnAddtocart().get(min - 1).isPresent();

				// click L2 random child category
				int L2catcount = category.getLiLeftnavLTwoCategory().size();
				int level = 2;
				boolean itemfoundL2 = clickOnRandomL2Category(itemfound, itemfoundL3, L2catcount, level);

				if (itemfoundL3) {
					// ignore
				} else {
					if (itemfound == true && itemfoundL2 == true) {
						// click L3 category
						int L3catcount = category.getLiLeftnavLTwoCategory().size();
						level = 3;
						itemfoundL3 = clickOnRandomL2Category(itemfound, itemfoundL3, L3catcount, level);
						if (itemfoundL3) {
							category.getBtnAddtocart().get(min - 1).verifyPresent();
							utill.pass("Random product is choosen from L3 category");
						}
					} 
				}
			}
		}

	}

	public boolean clickOnRandomL2Category(boolean itemfound, boolean itemfoundL3, int L2catcount, int level) {
		
		ShopTestPage category=new ShopTestPage();
		boolean itemfoundL2 = false;

		int temp = L2catcount;

		if (itemfoundL3) {
			// ignore
		} else {
			if (itemfoundL2) {
				// ignore
			} else {
				if (temp == 0) {
					navigateToRandomCategory();
				}
				if (itemfoundL3) {
					// ignore
				} else {
					int min = 1;
					int randomlevelCat = mathRandom(min, L2catcount - min);
					// CommonUtils.scrolltoelement(category.getLiLeftnavLTwoCategory().get(randomlevelCat));
					PerfectoUtils.mousehoverusingActions(category.getLiLeftnavLTwoCategory().get(randomlevelCat - 1));
					category.getLiLeftnavLTwoCategory().get(randomlevelCat - 1).verifyPresent();
					category.getLiLeftnavLTwoCategory().get(randomlevelCat - 1).click();
					if (category.getLblErrmsgnoitem().isPresent()) {
						category.getLiCatbreadcrumpse().get(level-2).click();
						clickOnRandomL2Category(itemfound, itemfoundL3, temp - 1, level);
					}
					if (itemfoundL3) {
						// ignore
					} else {

						category.getLblTxtHeaderpage().waitForPresent(MAX_WAIT_TIME);
						itemfoundL2 = category.getBtnAddtocart().get(min - 1).isPresent();

					}
				}
			}
		}
		return itemfoundL2;

	}

	@QAFTestStep(description = "Add Random item to cart")
	public synchronized void addRandomItemToCart() {
		ShopTestPage addRandom=new ShopTestPage();
		CommonUtils utill = new CommonUtils();
		CartTestPage carticon= new CartTestPage();
		
		int min = 1;
		int L2AddCartCount = addRandom.getBtnAddtocart().size();
		int addtocart = mathRandom(min, L2AddCartCount - min);
		addRandom.getBtnAddtocart().get(addtocart - 1).waitForPresent(MAX_WAIT_TIME);
		PerfectoUtils.mousehoverusingActions(addRandom.getBtnAddtocart().get(addtocart - 1));
		addRandom.getBtnAddtocart().get(addtocart - 1).verifyPresent();
		addRandom.getBtnAddtocart().get(addtocart - 1).click();
		addRandom.getBtnAddedtocart().waitForPresent(MAX_WAIT_TIME);
		addRandom.getBtnAddedtocart().verifyPresent();
		if (addRandom.getBtnAddedtocart().isPresent()){
		String productName=addRandom.getLblAddedProductname().getText();
		String addedmsgHeader=addRandom.getLblAddedProductMsgHeader().getText();
		utill.info("Product Name: "+productName);
			if (addedmsgHeader.contains(productName)){
			addRandom.getLblAddedProductMsgHeader().waitForPresent(MAX_WAIT_TIME);
			carticon.getCartTxtBtnItemQty().waitForPresent(MAX_WAIT_TIME);
			PerfectoUtils.mousehoverusingActions(addRandom.getLblAddedProductMsgHeader());
			utill.info("Confirmation Message: "+addedmsgHeader);
			utill.pass("Product is added to cart successfully");
			}
			else {
				utill.fail("Fail to Add item to Cart");
			}
			
		}
		else {
			utill.fail("Fail to Add item to Cart");
		}
}
	public int mathRandom(int min, int max) {
		int range = (max - min) + 1;
		return (int) (Math.random() * range) + min;
	}
}
