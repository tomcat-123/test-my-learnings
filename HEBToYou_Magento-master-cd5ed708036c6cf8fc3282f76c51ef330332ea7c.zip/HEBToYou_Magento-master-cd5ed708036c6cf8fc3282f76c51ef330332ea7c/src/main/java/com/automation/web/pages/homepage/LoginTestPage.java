package com.automation.web.pages.homepage;

import java.util.List;
import static com.automation.web.commonutils.CommonUtils.MAX_WAIT_TIME;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class LoginTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}

	public synchronized void loadPage(){
		loginPageLoadItem.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}

	@FindBy(locator = "login.edt.email")
	private QAFWebElement loginEdtEmail;

	@FindBy(locator = "login.edt.password")
	private QAFWebElement loginEdtPassword;

	@FindBy(locator = "login.btn.submit")
	private QAFWebElement loginBtnSubmit;

	@FindBy(locator = "login.tab.login")
	private QAFWebElement loginTabLogin;

	@FindBy(locator = "login.tab.register")
	private QAFWebElement loginTabRegister;

	@FindBy(locator = "login.lnk.forgotpwd")
	private QAFWebElement loginLnkForgotpwd;

	@FindBy(locator = "login.pageLoadItem")
	private QAFWebElement loginPageLoadItem;

	@FindBy(locator = "login.lnk.userAcct")
	private QAFWebElement loginLnkUserAcct;

	@FindBy(locator = "login.lnk.userProf")
	private QAFWebElement loginLnkUserProf;

	@FindBy(locator = "login.lnk.userHist")
	private QAFWebElement loginLnkUserHist;

	@FindBy(locator = "login.lnk.userSave")
	private QAFWebElement loginLnkUserSave;

	@FindBy(locator = "login.lnk.logout")
	private QAFWebElement loginLnkLogout;

	@FindBy(locator = "login.wnd.forgottenPass")
	private QAFWebElement loginWndForgottenPass;

	@FindBy(locator = "login.edt.fpEmail")
	private QAFWebElement loginEdtFpEmail;

	@FindBy(locator = "login.btn.fpConfirm")
	private QAFWebElement loginBtnFpConfirm;

	@FindBy(locator = "login.lnk.backToLogin")
	private QAFWebElement loginLnkBackToLogin;

	@FindBy(locator = "login.txt.forgottenPass")
	private QAFWebElement loginTxtForgottenPass;

	@FindBy(locator = "login.txt.emailSentSuccess")
	private QAFWebElement loginTxtEmailSentSuccess;

	@FindBy(locator = "login.txt.emailSentFail")
	private QAFWebElement loginTxtEmailSentFail;

	@FindBy(locator = "login.txt.loginFail")
	private QAFWebElement loginTxtLoginFail;

	/**
	 * Editview for Email
	 */
	public QAFWebElement getLoginEdtEmail(){ return loginEdtEmail; }

	/**
	 * Editview for Password
	 */
	public QAFWebElement getLoginEdtPassword(){ return loginEdtPassword; }

	/**
	 * Textview for submit button
	 */
	public QAFWebElement getLoginBtnSubmit(){ return loginBtnSubmit; }

	/**
	 * Tab to switch to login
	 */
	public QAFWebElement getLoginTabLogin(){ return loginTabLogin; }

	/**
	 * Tab to switch to register new user
	 */
	public QAFWebElement getLoginTabRegister(){ return loginTabRegister; }

	/**
	 * LinkView for forgotten password
	 */
	public QAFWebElement getLoginLnkForgotpwd(){ return loginLnkForgotpwd; }

	/**
	 * Item to wait for page to load
	 */
	public QAFWebElement getLoginPageLoadItem(){ return loginPageLoadItem; }

	/**
	 * Pull down tab for user profile
	 */
	public QAFWebElement getLoginLnkUserAcct(){ return loginLnkUserAcct; }

	/**
	 * Link to edit/view user information
	 */
	public QAFWebElement getLoginLnkUserProf(){ return loginLnkUserProf; }

	/**
	 * Link to view order history
	 */
	public QAFWebElement getLoginLnkUserHist(){ return loginLnkUserHist; }

	/**
	 * Lists for saving for later
	 */
	public QAFWebElement getLoginLnkUserSave(){ return loginLnkUserSave; }

	/**
	 * Link for Logout
	 */
	public QAFWebElement getLoginLnkLogout(){ return loginLnkLogout; }

	/**
	 * Window containing forgotten password info
	 */
	public QAFWebElement getLoginWndForgottenPass(){ return loginWndForgottenPass; }

	/**
	 * Email input for forgotten password
	 */
	public QAFWebElement getLoginEdtFpEmail(){ return loginEdtFpEmail; }

	/**
	 * Button to reset password
	 */
	public QAFWebElement getLoginBtnFpConfirm(){ return loginBtnFpConfirm; }

	/**
	 * Link to return to login screen
	 */
	public QAFWebElement getLoginLnkBackToLogin(){ return loginLnkBackToLogin; }

	/**
	 * Box containing forgotten pass text
	 */
	public QAFWebElement getLoginTxtForgottenPass(){ return loginTxtForgottenPass; }

	/**
	 * Success text box for forgotten password
	 */
	public QAFWebElement getLoginTxtEmailSentSuccess(){ return loginTxtEmailSentSuccess; }

	/**
	 * Fail text box for forgotten password
	 */
	public QAFWebElement getLoginTxtEmailSentFail(){ return loginTxtEmailSentFail; }

	/**
	 * Box for failure to enter correct email or password
	 */
	public QAFWebElement getLoginTxtLoginFail(){ return loginTxtLoginFail; }

}