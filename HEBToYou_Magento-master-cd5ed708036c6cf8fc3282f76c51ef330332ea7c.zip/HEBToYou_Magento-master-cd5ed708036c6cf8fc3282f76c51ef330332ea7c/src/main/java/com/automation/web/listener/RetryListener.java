package com.automation.web.listener;

import static com.automation.web.commonutils.FunctionUtils.CART_UNIQUE_ITEM_CNT_KEY;
import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NAME_KEY;
import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NUMBER_KEY;
import static com.automation.web.commonutils.FunctionUtils.IS_TAXABLE_KEY;
import static com.automation.web.commonutils.FunctionUtils.ITEM_ID_KEY;
import static com.automation.web.commonutils.FunctionUtils.LIST_PRICE_KEY;
import static com.automation.web.commonutils.FunctionUtils.MAX_ORDER_KEY;
import static com.automation.web.commonutils.FunctionUtils.MIN_ORDER_KEY;
import static com.automation.web.commonutils.FunctionUtils.SALE_PRICE_KEY;
import static com.automation.web.commonutils.FunctionUtils.TAX_PERCENTAGE_KEY;
import static com.automation.web.commonutils.FunctionUtils.TIME_BEGIN_KEY;
import static com.automation.web.commonutils.FunctionUtils.TIME_END_KEY;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

/**
 * Retry listener for the project. While this could be done in the properties
 * file, this gives you more control over steps and whether or not your able to
 * clean out the getBundle() properties.
 * 
 * @author Garrett Griffin
 *
 */
public class RetryListener implements IRetryAnalyzer {

	private static int retryCount = 0;
	private static final int MAX_RETRY_CNT = 1;

	@Override
	public boolean retry(ITestResult result) {
		if (retryCount < MAX_RETRY_CNT) {
			clearItemKeys();
			retryCount += 1;
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Removes all keys that are not test steps
	 */
	private void clearItemKeys() {
		getBundle().clearProperty(CART_UNIQUE_ITEM_CNT_KEY);
		getBundle().clearProperty(CUR_STORE_NAME_KEY);
		getBundle().clearProperty(CUR_STORE_NUMBER_KEY);
		getBundle().clearProperty(TAX_PERCENTAGE_KEY);
		getBundle().clearProperty(TIME_END_KEY);
		getBundle().clearProperty(TIME_BEGIN_KEY);
		getBundle().clearTree(ITEM_ID_KEY);
		getBundle().clearTree(MAX_ORDER_KEY);
		getBundle().clearTree(MIN_ORDER_KEY);
		getBundle().clearTree(SALE_PRICE_KEY);
		getBundle().clearTree(LIST_PRICE_KEY);
		getBundle().clearTree(IS_TAXABLE_KEY);
	}
}
