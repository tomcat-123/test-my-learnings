package com.automation.web.steps.cartandcheckout;

import static com.automation.web.commonutils.CommonUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.CommonUtils.getDriver;
import static com.automation.web.commonutils.FunctionUtils.IS_TAXABLE_KEY;
import static com.automation.web.commonutils.FunctionUtils.ON_SALE_KEY;
import static com.automation.web.commonutils.FunctionUtils.SALE_WT_SW_KEY;
import static com.automation.web.commonutils.FunctionUtils.SAVED_TAX_KEY;
import static com.automation.web.commonutils.FunctionUtils.SUBTOTAL_KEY;
import static com.automation.web.commonutils.FunctionUtils.TAX_PERCENTAGE_KEY;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.automation.web.commonutils.APIHub;
import com.automation.web.commonutils.CommonUtils;
import com.automation.web.commonutils.FunctionUtils;
import com.automation.web.commonutils.PerfectoUtils;
import com.automation.web.components.Cart.CartItemBlocks;
import com.automation.web.pages.cartandcheckout.CartTestPage;
import com.automation.web.pages.cartandcheckout.PayTestPage;
import com.automation.web.steps.common.CommonSteps;
import com.automation.web.steps.homepage.HomePage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*
All the steps definitions for CartSteps 

User removes all items from cart
User clicks side checkout
Verify price of all cart items
User continues from Review Cart Page
Register a new user from checkout page
User Selects the timeslot and checkout info
Verify the user able to add credit cards
Verify the payment card required fields
I am an hotuser with new order placed
Verify the Saved credit card is available


*/

public class CartSteps {

	CommonUtils util = new CommonUtils();
	Actions act = new Actions(CommonUtils.getDriver());

	/**
	 * Assumes you've navigated to the Review Cart page
	 */
	@QAFTestStep(description = "User removes all items from cart")
	public void removeAllItemsFromCart() {
		CartTestPage ctPage = new CartTestPage();
		CommonUtils CommonUtils =new CommonUtils();
		
		//util.scrollAndClick(ctPage.getChkOutBtnRemoveAll());
		//CommonUtils.scrolltoelement(qafelement);
		ctPage.getChkOutBtnRemoveAll().click();
		ctPage.getChkOutBtnCancelRemAll().waitForPresent(MAX_WAIT_TIME);;
		ctPage.getChkOutBtnConfRemAll().click();
		if (ctPage.getChkOutBtnNotFound().isPresent()){
		util.pass("All items removed");
		}
		else{
			util.fail("All items not removed");
		}
	}

	/**
	 * Currently need to figure out how to verify side cart is fully visible
	 */
	@QAFTestStep(description = "User clicks side checkout")
	public void iClickCheckout() {
		CartTestPage cartTestPage = new CartTestPage();

		util.mouseoverAndClick(cartTestPage.getCartGetICartAdd(1 + ""), cartTestPage.getCartBtnCheckOut());

		cartTestPage.getChkOutHdrReviewHeader().waitForEnabled(MAX_WAIT_TIME);
		util.pass("Checkout page successfully loaded");
	}

	@QAFTestStep(description = "Verify price of all cart items")
	public void checkCartItems() {
		CartTestPage cart = new CartTestPage();

		cart.getLiCartitemsblocks().get(0).waitForPresent(MAX_WAIT_TIME);
		int cartItemSize = cart.getLiCartitemsblocks().size();
		String temp;
		double runningItemTotal = 0;

		if (cartItemSize > 0) {

			for (CartItemBlocks ele : cart.getLiCartitemsblocks()) {
				
				double itemPrice = Double.parseDouble(ele.getLiCartitemsblockprice().getText().replace("$", ""));
				double itemQty = Double.parseDouble(ele.getLiCartitemsblockqty().getAttribute("value"));
				double itemTotal = Double.parseDouble(ele.getLiCartitemsblockitemtotal().getText().replace("$", ""));
				double itemPriceQtyTotal =itemPrice * itemQty;
				
				 temp = String.format("%.2f", itemPriceQtyTotal);
				itemPriceQtyTotal = Double.parseDouble(temp);
				if (itemPriceQtyTotal == itemTotal) {
					runningItemTotal += itemTotal;
					temp = String.format("%.2f", runningItemTotal);
					runningItemTotal = Double.parseDouble(temp);
					continue;
				} else {
					util.fail("Qty * Price doesn't match with the item total..");
					break;
				}
			}

			// Validating the Running total with the Item Sub-total
			double itemSubTotal = Double.parseDouble(cart.getCkconTxtSubtotal().getText().replace("$", ""));

			if (itemSubTotal == runningItemTotal) {
				util.pass("Sub-total matched with the running item total..");
			} else {
				util.fail("Sub-total doesn't match with the running item total..");
			}
			
		} else {
			util.fail("No cart items found..");
		}

	}

	private double taxItem(String itemToAdd, double beforeTaxPrice, double currentItemQty) {
		double currentTaxAmount = 0f;
		double taxRate = 0f;
		boolean isTaxable = Boolean.parseBoolean((String) getBundle().getProperty(IS_TAXABLE_KEY + itemToAdd));
		if (isTaxable) {
			taxRate = Double.parseDouble(getBundle().getProperty(TAX_PERCENTAGE_KEY) + "");
			try {
				currentTaxAmount = Double.parseDouble((String) getBundle().getProperty(SAVED_TAX_KEY));
			} catch (NullPointerException e) {
				currentTaxAmount = 0;
			}
			currentTaxAmount += beforeTaxPrice * taxRate;
		}

		return currentTaxAmount;

	}

	@QAFTestStep(description = "User continues from Review Cart Page")
	public void continueFromReviewCartPg() {
		WebElement continueBtn = util.generateWebElement("//div[@class='right']/button");
		continueBtn.click();

		util.pass("Continuing from Review Cart Page");
	}

	/**
	 * Because of how the current structure of the row is set up, there is no
	 * discernible way to grab the total. So, if you do a getText() on the
	 * entire row, the total will always be the last number. Convert it into an
	 * array and grab the last element to get the total.
	 * 
	 * @param rowText
	 *            All text items of the row
	 * @return Total price of the base price times the qty of the item
	 */
	private double parseTotal(String rowText) {
		String[] splitRow = rowText.split(" ");
		String dollarTotal = splitRow[splitRow.length - 1];

		return Double.parseDouble(dollarTotal.replace("$", ""));
	}

	/**
	 * Needs to be broken into two categories: By each and by each weight
	 * 
	 * @param row
	 *            Row of web elements for the current item
	 * @param hub
	 *            Instance of the hub to grab items for
	 * @return
	 */
	private double basePriceCheck(String curItemId, WebElement row, APIHub hub) {
		FunctionUtils funUtil = new FunctionUtils();
		String temp = "";

		double avgWeight = 0.00;
		double siteItemAmount = 0.00;
		double hubItemAmount = 0.00;

		boolean onSale = false;
		boolean saleByEaWt = false;

		curItemId = funUtil.generateItemID(row.findElement(By.className("item-image")).getAttribute("style"));
		// try {
		// hub.genPriceLocation(curItemId);
		// } catch (UnsupportedOperationException | IOException e) {
		// util.fail("Product information for id: " + curItemId + " not set for
		// store "
		// + getBundle().getProperty(FunctionUtils.CUR_STORE_NUMBER_KEY));
		// }
		saleByEaWt = Boolean.parseBoolean((String) (getBundle().getProperty(SALE_WT_SW_KEY + curItemId)));
		// String byWeight =
		onSale = Boolean.parseBoolean((String) getBundle().getProperty(ON_SALE_KEY + curItemId));

		if (onSale) {
			temp = row.findElement(By.className("product-prices")).findElement(By.className("sale")).getText()
					.replace("$", "");
			temp = temp.replaceFirst(" / ea", "");
			siteItemAmount = Double.parseDouble(temp);
			// temp = (String) getBundle().getProperty(SALE_PRICE_KEY +
			// curItemId);
			// hubItemAmount = Double.parseDouble(temp.replace("$", ""));
			// util.print("Hub amount set to: " + hubItemAmount);
		} else {
			siteItemAmount = Double.parseDouble(row.findElement(By.className("amount")).getText().replace("$", ""));
			// temp = (String) getBundle().getProperty(LIST_PRICE_KEY +
			// curItemId);
			// try {
			// hubItemAmount = Double.parseDouble(temp.replace("$", ""));
			// } catch (NullPointerException e) {
			// hubItemAmount = 0;
			// } catch (NumberFormatException e) {
			// util.fail("Bad number read. Provided: " +
			// getBundle().getProperty(LIST_PRICE_KEY + curItemId));
			// hubItemAmount = 0;
			// }
		}

		// avgWeight = Double.parseDouble((String)
		// getBundle().getProperty(AVG_WEIGHT_KEY + curItemId));
		// if (avgWeight != 0 && saleByEaWt) {
		// // util.print("avgWeight set to: " + avgWeight);
		// hubItemAmount *= avgWeight;
		// }

		// temp = String.format("%.2f", hubItemAmount);
		// hubItemAmount = Double.parseDouble(temp);

		if (siteItemAmount == hubItemAmount) {
			util.info(curItemId + " matches hub information");
		} else {
			util.fail("Prices do not match for " + curItemId + ". Site amount == " + siteItemAmount + ", hub == "
					+ hubItemAmount);
		}

		return siteItemAmount;
	}

	@QAFTestStep(description = "Register a new user from checkout page")
	public void registerANewUserFromCheckoutPage() {

		HomePage home = new HomePage();
		home.userClicksLoginRegisterButton();;
		CommonSteps.newAcctRegi();
	}

	
	@QAFTestStep(description = "Verify the user able to add credit cards")
	public void verifyTheUserAbleToAddCreditCards() {
		CheckoutSteps checkout = new CheckoutSteps();
		PayTestPage chckoutconfirm = new PayTestPage();

		String creditCardType = getBundle().getString("creditCards.MasterCard.type");

		checkout.clickCreditCardButton();
		checkout.createNewCreditCard(creditCardType);
		//checkout.addCreditCard();

		chckoutconfirm.getLnkDeletecredeitcard().waitForPresent(MAX_WAIT_TIME);

		if (chckoutconfirm.getLnkDeletecredeitcard().isPresent())
			util.pass("Able to add the credit card..");
		else
			util.fail("Failed to add credit card..");
	}

	@QAFTestStep(description = "Verify the payment card required fields")
	public void verifyThePaymentCardRequiredFields() {
		CheckoutSteps checkout = new CheckoutSteps();
		PayTestPage chckoutconfirm = new PayTestPage();

		checkout.clickCreditCardButton();

		String expMandatoryFieldColour = getBundle().getString("creditCards.MandatoryFieldColorvalue");

		util.info("Mandatory Fields are..");
		if (chckoutconfirm.getCardSelEdtCardNumber().getCssValue("color").equalsIgnoreCase(expMandatoryFieldColour)) {
			util.pass("Card Number");
		} else {
			util.fail("Card Number is not highlighted as Mandatory field..");
		}

		// Card Holder name
		if (chckoutconfirm.getCardSelEdtHolderName().getCssValue("color").equalsIgnoreCase(expMandatoryFieldColour)) {
			util.pass("Card Holder name");
		} else {
			util.fail("Card holder name is not highlighted as Mandatory field..");
		}

		// CVV Code
		if (chckoutconfirm.getCardSelEdtCvvNum().getCssValue("color").equalsIgnoreCase(expMandatoryFieldColour)) {
			util.pass("CVV num");
		} else {
			util.fail("CVV num is not highlighted as Mandatory field..");
		}

		// ZipCode
		if (chckoutconfirm.getCardSelEdtZipcode().getCssValue("color").equalsIgnoreCase(expMandatoryFieldColour)) {
			util.pass("Zip Code");
		} else {
			util.fail("Zip Code is not highlighted as Mandatory field..");
		}

		// Card description
		if (chckoutconfirm.getCardSelEdtDescription().getCssValue("color").equalsIgnoreCase(expMandatoryFieldColour)) {
			util.pass("Card description");
		} else {
			util.fail("Card description is not highlighted as Mandatory field..");
		}
	}

	@QAFTestStep(description = "I am an hotuser with new order placed")
	public void iAmAnHotuserWithNewOrderPlaced() {

		String searchItem = getBundle().getString("ItemType.EachWeight.name");
		String itemAmount = getBundle().getString("search.itemamount");
		String listPosition = getBundle().getString("search.listposition");
		CommonSteps.quickAdd(searchItem, itemAmount, listPosition);

		CheckoutSteps.selectTimeSlot();
		//CommonStepDef.navToPymtPage();

		String cardType = getBundle().getString("creditCards.MasterCard.type");
		CommonSteps.createNewCCWithBilling(cardType);
		CheckoutSteps.confirmPurchase();
	}

	@QAFTestStep(description = "Verify the Saved credit card is available")
	public void verifyTheSavedCreditCardIsAvailable() {
		CheckoutSteps checkout = new CheckoutSteps();
		PayTestPage chckoutconfirm = new PayTestPage();

		checkout.clickCreditCardButton();

		chckoutconfirm.getLnkDeletecredeitcard().waitForPresent(MAX_WAIT_TIME);

		if (chckoutconfirm.getLnkDeletecredeitcard().isPresent())
			util.pass("Added credit card available. Able to save credir card..");
		else
			util.fail("Failed to Save credit card.. Added credit card not available");
	}

}
