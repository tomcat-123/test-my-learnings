package com.automation.web.steps.delivery;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static com.automation.web.commonutils.FunctionUtils.CUR_STORE_NAME_KEY;
import static com.automation.web.commonutils.FunctionUtils.DELIVERY_SET;
import static com.automation.web.commonutils.FunctionUtils.FULFILLMENT_TYPE_KEY;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

import com.automation.web.commonutils.CommonUtils;
import com.automation.web.pages.cartandcheckout.CurbsideTestPage;

public class Delivery {
	
	CommonUtils util = new CommonUtils();
	
	@QAFTestStep(description = "User selects delivery service")
	public void userSelectsDeliveryService(){
		CurbsideTestPage csTest = new CurbsideTestPage();
		csTest.getCurbBtnSelectDelivery().click();
		QAFWebElement header = (QAFWebElement)util.generateWebElement("//h1");
		if(header.isEnabled()){
			getBundle().setProperty(FULFILLMENT_TYPE_KEY, DELIVERY_SET);
			util.pass("Delivery selected");
		} else {
			util.fail("Delivery not selected");
		}
	}

	/**
	 * Even though the value of the fulfillment type changes, the time selection modal will not disappear completely.
	 * Needs to sleep to wait for it to fully vanish.
	 * @param zipcode
	 */
	@QAFTestStep(description = "User selects valid store by zipcode {valid zipcode}")
	public void validStoreByZip(String zipcode){
		CurbsideTestPage curbside = new CurbsideTestPage();   
		
		QAFWebElement enterZip = curbside.getCurbEdtEnterZipcode(); 
		QAFWebElement submitBtn = curbside.getCurbBtnSubmit(); 
		util.enterValues(enterZip, zipcode);
		util.mouseoverAndClick(submitBtn, submitBtn);

		CommonUtils.sleep(); // Compensate for lag
		
		getBundle().setProperty(CUR_STORE_NAME_KEY, zipcode);
		
		util.pass("Zipcode entered");
	}
}
