package com.automation.web.steps.common;

import com.automation.web.commonutils.CommonUtils;
import com.automation.web.pages.cartandcheckout.OrderCompleteTestPage;
import com.automation.web.pages.cartandcheckout.PayTestPage;
import com.automation.web.pages.homepage.HomeTestPage;
import com.automation.web.steps.browseandsearch.SearchPage;
import com.automation.web.steps.cartandcheckout.CartSteps;
import com.automation.web.steps.cartandcheckout.CheckoutSteps;
import com.automation.web.steps.curbside.Curbside;
import com.automation.web.steps.delivery.Delivery;
import com.automation.web.steps.homepage.HomePage;
import com.automation.web.steps.registerandlogin.LoginPage;
import com.automation.web.steps.registerandlogin.Registration;

import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

import static com.automation.web.commonutils.CommonUtils.MAX_WAIT_TIME;

/**
 * Clubbed versions of commonly used steps. Good starting point for figuring out
 * project/site functionality
 * 
 */






public class CommonSteps {
	CommonUtils util = new CommonUtils();

	/**
	 * Takes in search term, and adds pounds/each of the item specified.
	 * 
	 * @param searchItem
	 *            Term to search for
	 * @param itemAmount
	 *            Amount to add to cart
	 * @param listPosition
	 *            Position in search for item
	 */
	@QAFTestStep(description = "User searches for {searchItem}, and adds {itemAmount} of "
			+ "{listPosition}(st|nd|rd) item to cart")
	public static void userAddsItemX(String searchItem, String itemAmount, String listPosition) {
		SearchPage searchPage = new SearchPage();
		searchPage.iSearchForX(searchItem);
		searchPage.iClickOnTheSearchIcon();
		searchPage.verifySearchPage();
		searchPage.iAddXoftheYItem(itemAmount, listPosition);
	}

	@QAFTestStep(description = "From homepage, user searches for {searchItem}, adds {itemAmount} of {listPosition}(st|nd|rd|th) item, and navigates to checkout")
	public static void quickAdd(String searchItem, String itemAmount, String listPosition) {
		CheckoutSteps checkout = new CheckoutSteps();
		CartSteps cart = new CartSteps();
		HomePage home = new HomePage();

		home.iAmOnHomePage();
		userAddsItemX(searchItem, itemAmount, listPosition);
		checkout.iClickMainCheckout();
		//cart.checkCartItems();
	}

	/**
	 * Clicks the timeslot button in the top header, and sets the reservation
	 * time to the provided day of the month, and timeslot
	 * 
	 * @param dayOfMonth
	 * @param startTime
	 * @param endTime
	 */
	@QAFTestStep(description = "User selects timeslot {dayOfMonth}(st|th) of the month, time range of {startTime}"
			+ " to {endTime}")
	public void timeSlotSelection(String dayOfMonth, String startTime, String endTime) {
		CheckoutSteps checkout = new CheckoutSteps();
		checkout.clickTimeslotButton();
		checkout.selectDayTS(dayOfMonth);
		checkout.selectTime(startTime, endTime);
		checkout.verifyTimeAndDate();
	}

//	@QAFTestStep(description = "User registers new account while navigating to payment page to add a credit card")
//	public static void navToPymtPage() {
//		CheckoutSteps checkout = new CheckoutSteps();
//		CartSteps cart = new CartSteps();
//		HomePage home = new HomePage();
//		home.userClicksLoginRegisterButton();
//		newAcctRegi();
//		cart.continueFromReviewCartPg();
//		CheckoutSteps.selectTimeSlot();
//		checkout.delConfirmation();
//		checkout.navToPaymentPage();
//		checkout.clickCreditCardButton();
//	}

//	@QAFTestStep(description = "User navigates from main checkout to payment page")
//	public void fromMChkoutToPymtPg() {
//		CheckoutSteps checkout = new CheckoutSteps();
//		CartSteps cart = new CartSteps();
//		cart.continueFromReviewCartPg();
//		checkout.delConfirmation();
//		checkout.navToPaymentPage();
//	}

	@QAFTestStep(description = "User adds a new {creditCard}")
	public void generateNewCC(String creditCard) {
		CheckoutSteps checkout = new CheckoutSteps();
		checkout.createNewCreditCard(creditCard);
		checkout.addCreditCard();
		checkout.verifyCreditCard(creditCard);
	}

	@QAFTestStep(description = "User creates new {creditCard} and fills in valid billing information")
	public static void createNewCCWithBilling(String creditCardType) {
		CheckoutSteps checkout = new CheckoutSteps();
		
		// util.generateWebElement("//div[@class='payment-gateway']/div/div/button").click();
		//checkout.clickCreditCardButton();
		checkout.createNewCreditCard(creditCardType);
		checkout.verifyCreditCard(creditCardType);
		checkout.verifyBilling();
	}

	
	/**
	 * Clicks the header curbside button, then selects the given store name
	 * 
	 * @param storeName
	 */
	@QAFTestStep(description = "User selects curbside and selects {storeName}")
	public void curbStoreSelect(String storeName) {
		Curbside curbside = new Curbside();
		curbside.iOpenCurbisdeWindow();
		curbside.iSelectCSPickup();
		curbside.iChangeCurbside();
		curbside.choosesStoreByName(storeName);
		curbside.selectedStoreVerification();
	}

	@QAFTestStep(description = "User selects delivery and enters {zipcode}")
	public void deliveryQuickSelect(String zipcode) {
		Delivery delivery = new Delivery();
		Curbside curbside = new Curbside();
		curbside.iOpenCurbisdeWindow();
		curbside.iSelectCSPickup();
		delivery.userSelectsDeliveryService();
		delivery.validStoreByZip(zipcode);
		curbside.selectedZipVerification();
	}

	@QAFTestStep(description = "User enters {zipcode} for delivery, selects {dayOfMonth} timeslot from {startTime} to {endTime}")
	public void deliveryWithTimeslots(String zipcode, String dayOfMonth, String startTime, String endTime) {
		deliveryQuickSelect(zipcode);
		timeSlotSelection(dayOfMonth, startTime, endTime);
	}

	
	/*
	 * 
	 * Please use re-usable steps instead of new customized steps 
	 * 
	 **/
	@QAFTestStep(description = "User enters {zipcode} for delivery, selects first available timeslot")
	public void deliverWithFirstTS(String zipcode) {
		CheckoutSteps checkout = new CheckoutSteps();
		deliveryQuickSelect(zipcode);
		checkout.firstTimeSlot();
	}
	 

	/**
	 * A "Given" starting point. Starts on the homepage to establish baseline
	 * for all items (hot user, tax, etc.), then selects store and reservation
	 * times
	 * 
	 * @param storeName
	 * @param startTime
	 * @param endTime
	 * @param dayOfMonth
	 */
	@QAFTestStep(description = "User on homepage selects {storeName} for curbside, "
			+ "timeslot {startTime} to {endTime} on {dayOfMonth}")
	public void homePageCurbsideSet(String storeName, String startTime, String endTime, String dayOfMonth) {
		HomePage homePg = new HomePage();
		homePg.iAmOnHomePage();
		curbStoreSelect(storeName);
		timeSlotSelection(dayOfMonth, startTime, endTime);

	}

	
	  
	  // Please use re-usable steps instead of new customized steps 
	 
	  @QAFTestStep(description = "User on homepage selects {storeName} for curbside, and first timeslot")
	public void homePageFirstCurbSet(String storeName) {
		HomePage homePg = new HomePage();
		CheckoutSteps checkout = new CheckoutSteps();
		homePg.iAmOnHomePage();
		curbStoreSelect(storeName);
		checkout.firstTimeSlot();
	}

	@QAFTestStep(description = "User sucessfully registers new account")
	public static void newAcctRegi() {
		Registration register = new Registration();
		register.iClickRegistrationPage();
		register.iEnterAllRequiredFieldsInregistrationPage();
		register.iSubmitTheregistrationForm();
		CommonUtils.waitAngularHasFinishedProcessing();
	}

	@QAFTestStep(description = "User selects {store} for curbside, and registers new account")
	public void registerAndCurb(String storeName) {
		HomePage homePg = new HomePage();
		homePg.iAmOnHomePage();
		homePg.userClicksLoginRegisterButton();
		newAcctRegi();
		curbStoreSelect(storeName);
		CheckoutSteps.secondTimeSlot();
	}

	@QAFTestStep(description = "User logs into verified account with {email} {password}")
	public void loginToAcct(String email, String password) {
		HomePage homePg = new HomePage();
		LoginPage login = new LoginPage();
		homePg.userClicksLoginRegisterButton();
		login.iEnterValidEmailAndPassword(email, password);
	}

	@QAFTestStep(description = "User navigates from Review Cart and logs into account with {email} {password}")
	public void navFromReviewAndLogin(String email, String password) {
		CartSteps cart = new CartSteps();
		LoginPage login = new LoginPage();
		cart.continueFromReviewCartPg();
		login.iEnterValidEmailAndPassword(email, password);

	}

	@QAFTestStep(description = "User logs in with {email} and {password} and selects {storeName} for curbside")
	public void loginAndSelectCurb(String email, String password, String storeName) {
		loginToAcct(email, password);
		curbStoreSelect(storeName);
	}

	@QAFTestStep(description = "User on homepage logs in with {email}{password}, selects {storeName} for curbside,"
			+ "timeslot {startTime} to {endTime} on {dayOfMonth}")
	public void hotUserCurbsideSet(String email, String password, String storeName, String startTime, String endTime,
			String dayOfMonth) {
		homePageCurbsideSet(storeName, startTime, endTime, dayOfMonth);
		loginToAcct(email, password);
	}

	@QAFTestStep(description = "Click on Heb to you logo and navigate to Homepage")
	public void clickOnHebToYouLogoAndNavigateToHomepage() {
		//OrderCompleteTestPage ordercomplete = new OrderCompleteTestPage();
		HomeTestPage ordercomplete =new HomeTestPage();
		ordercomplete.getHomeImgHeblogo().waitForPresent(MAX_WAIT_TIME);
		ordercomplete.getHomeImgHeblogo().click();
		util.pass("Clicked on HEB To You Logo..");
	}
}
