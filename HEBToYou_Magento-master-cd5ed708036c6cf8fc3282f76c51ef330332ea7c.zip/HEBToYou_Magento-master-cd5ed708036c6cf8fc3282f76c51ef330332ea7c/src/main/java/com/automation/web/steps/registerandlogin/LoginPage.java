package com.automation.web.steps.registerandlogin;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static com.automation.web.commonutils.CommonUtils.MAX_WAIT_TIME;
import static com.automation.web.commonutils.FunctionUtils.TIME_BEGIN_KEY;
import static com.automation.web.commonutils.FunctionUtils.TIME_DATE_KEY;
import static com.automation.web.commonutils.FunctionUtils.TIME_END_KEY;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import com.qmetry.qaf.automation.step.QAFTestStep;

import com.automation.web.commonutils.CommonUtils;
import com.automation.web.pages.homepage.HomeTestPage;
import com.automation.web.pages.homepage.LoginTestPage;

public class LoginPage{
	CommonUtils util = new CommonUtils();
	Actions action = new Actions(CommonUtils.getDriver());

	/**
	 * Does a check to see if the user has previously registered a time slot to set the internal time properties.
	 * Sleep needed due to site functionality.
	 */
	@QAFTestStep(description = "User enters valid email and password")
	public void iEnterValidCredential() {
		LoginTestPage loginpage = new LoginTestPage();
		HomeTestPage htp = new HomeTestPage();
		String [] dayAndTime;

		String email = getBundle().getString("validUser.email");
		String validPass = getBundle().getString("validUser.password");


		util.info("Credentials Entered: " + email + " " + validPass);

		util.enterValues(loginpage.getLoginEdtEmail(), email);
		util.enterValues(loginpage.getLoginEdtPassword(), validPass);
		loginpage.getLoginBtnSubmit().click();
		CommonUtils.sleep();
		if(! htp.getHomeTxtReservedTime().getText().toLowerCase().contains("reserve")){
			dayAndTime = htp.getHomeTxtReservedTime().getText().split(" ");
			getBundle().setProperty(TIME_DATE_KEY, dayAndTime[1].replaceAll(",", ""));
			
			dayAndTime = dayAndTime[2].split("-");
			getBundle().setProperty(TIME_BEGIN_KEY, dayAndTime[0]);
			getBundle().setProperty(TIME_END_KEY, dayAndTime[1]);
		}

		util.pass("Credentials accepted");
	}

	@QAFTestStep(description = "User enters email and password {email} {pass}")
	public void iEnterValidEmailAndPassword(String email, String password) {
		LoginTestPage loginpage = new LoginTestPage();
		loginpage.getLoginEdtEmail().waitForEnabled(MAX_WAIT_TIME*2);
		util.enterValues(loginpage.getLoginEdtEmail(), email);
		util.enterValues(loginpage.getLoginEdtPassword(), password);
		util.info("Credentials Entered: " + email + " " + password);

		loginpage.getLoginBtnSubmit().click();
		loginpage.getLoginTabLogin().waitForNotPresent(MAX_WAIT_TIME*3);

		util.pass("Credentials accepted");
	}

	@QAFTestStep(description = "User enters invalid password")
	public void iEnterInvalidPassword() {
		LoginTestPage loginpage = new LoginTestPage();
		String password = getBundle().getString("badUser.password");
		String email = getBundle().getString("validUser.email");

		util.info("Credentials Entered: " + email + " " + password);

		util.enterValues(loginpage.getLoginEdtEmail(), email);
		util.enterValues(loginpage.getLoginEdtPassword(), password);

		util.pass("Credentials not accepted");
	}
	
	@QAFTestStep(description = "User enters invalid email")
	public void iEnterInvalidEmail() {
		LoginTestPage loginpage = new LoginTestPage();

		String email = getBundle().getString("badUser.email");
		String password = getBundle().getString("hotuser1.user.password");
		util.info("Credentials Entered: " + email + " " + password);

		util.enterValues(loginpage.getLoginEdtEmail(), email);
		util.enterValues(loginpage.getLoginEdtPassword(), password);
		CommonUtils.getDriver().getKeyboard().sendKeys(Keys.ENTER);
		util.pass("Credentials not accepted");
	}

}
