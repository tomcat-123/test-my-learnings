/**
 * 
 */
package com.automation.web.listener;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.DriverCommand;

import com.automation.web.commonutils.APIHub;
import com.qmetry.qaf.automation.ui.webdriver.CommandTracker;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriverCommandAdapter;;

public class SeleniumWebDriverListener extends QAFWebDriverCommandAdapter {

	@Override
	public void onInitialize(QAFExtendedWebDriver driver) {
		
		driver.get(getBundle().getString("env.baseurl"));
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();

		// driver.getCapabilities().getCapability("acceptInsecureCerts");
		
				}

	@Override
	public void onFailure(QAFExtendedWebDriver driver, CommandTracker commandTracker) {
		System.out.println(commandTracker.getCommand());
//		PerfectoUtils.scrolltoelement(commandTracker.getCommand().);
	}
	
	@Override
	public void beforeCommand(QAFExtendedWebDriver driver, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.QUIT)) {
			try {
				APIHub.closeHub();
				driver.close();
				if(driver!=null){
					driver.close();
				}
			
			} catch (Exception e) {
				// ignore
			}
	}
	}
	@Override
	public void afterCommand(QAFExtendedWebDriver driver, CommandTracker commandTracker) {

		// commandTracker.setEndTime(60000);
		super.afterCommand(driver, commandTracker);
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.CLOSE)) {
			try {
			} catch (Exception e) {
				// ignore
			}
		}
	}

	@Override
	public void beforeInitialize(Capabilities desiredCapabilities) {

		if (getBundle().getString("driver.name").equalsIgnoreCase("FirefoxDriver")) {
			System.setProperty("webdriver.gecko.driver", "lib\\geckodriver.exe");
		}
		// desiredCapabilities = (Capabilities) DesiredCapabilities.firefox();
		// ((DesiredCapabilities)desiredCapabilities).setCapability("raisesAccessibilityExceptions",
		// true);
		// desiredCapabilities.getCapability("acceptInsecureCerts");
		// desiredCapabilities.getCapability("profile");
		//
		/*
		 * ProfilesIni prof = new ProfilesIni(); FirefoxProfile ffProfile=
		 * prof.getProfile(getBundle().getString("webdriver.firefox.profile"));
		 * ffProfile.setAcceptUntrustedCertificates(true);
		 * ffProfile.setAssumeUntrustedCertificateIssuer(false);
		 */

		// ((DesiredCapabilities)desiredCapabilities).setCapability(CapabilityType.ACCEPT_SSL_CERTS,
		// true);

		/*
		 * DesiredCapabilities capabilities = new DesiredCapabilities();
		 * capabilities.setBrowserName("safari"); CommandExecutor executor = new
		 * SeleneseCommandExecutor(new URL("http://localhost:4444/"), new
		 * URL("http://www.google.com/"), capabilities); WebDriver driver = new
		 * RemoteWebDriver(executor, capabilities);
		 */
		// }

		// if
		// (getBundle().getString("driver.name").equalsIgnoreCase("iExplorerDriver"))
		// {
		// System.setProperty("webdriver.ie.driver", "lib\\IEDriverServer.exe");
		// }

	}

	private void closeApp() {

		try {
			//HomePage homepage = new HomePage();
			// homepage.iNavigateToHomePage();
			// homepage.iClickOnLogout();
		} catch (Exception e) {
			// ignore
		}
	}

	public void giftCardCreation(QAFExtendedWebDriver driver) {
		driver.get("lib\\XMLTest.htm");
	}

}
