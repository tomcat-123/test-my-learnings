package com.automation.web.databean;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.qmetry.qaf.automation.data.BaseFormDataBean;
import com.qmetry.qaf.automation.ui.annotations.UiElement;
import com.qmetry.qaf.automation.util.Randomizer;
/**
 * Class to generate a random user information at checkout. @UiElement will populate
 * at whatever location is given, so different location names are important. Sample invocation
 * of UiElement will look like:
 * <code>
 * <p>{@literal @}Randomizer(type = RandomizerTypes.{@literal <}Type Style>, length = {@literal <}string length>, suffix = {@literal <}String addendum>")</p>
 * <p>{@literal @}UiElement(fieldLoc = {@literal <}.loc variable>, order = {@literal <}order of execution>)</p>
 * <p>private String stringName;</p>
 * </code>
 * <p>Note: Can also randomize buttons on whether or not they need to be clicked. 
 * @author Garrett Griffin
 *
 */
public class EditContactInfoBean extends BaseFormDataBean{
	@UiElement(fieldLoc = "register.edt.ciFirstName", order = 1)
	private String firstName;
	
	@UiElement(fieldLoc = "register.edt.ciLastName", order = 2)
	private String lastName;
	
	@Randomizer(skip = true)
	@UiElement(fieldLoc = "register.edt.ciEmail", order = 3)
	private String email;
	
	@UiElement(fieldLoc = "register.edt.SMSMobile", order = 4)
	private String mobileNum;
	
	@UiElement(fieldLoc = "register.edt.SMSHome", order = 5)
	private String homeNum;
	
	@UiElement(fieldLoc = "register.edt.SMSWork", order = 6)
	private String workNum;
	
	@UiElement(fieldLoc = "register.edt.SMSOther", order = 7)
	private String otherNum;
	
	@Override
	public void fillRandomData() { 
		this.firstName = getBundle().getString("hotuser1.user.firstName");
		this.lastName = getBundle().getString("hotuser1.user.lastName");
		this.mobileNum = getBundle().getString("validPhoneNumbers.mobile");
		this.homeNum = getBundle().getString("validPhoneNumbers.home");
		this.workNum = getBundle().getString("validPhoneNumbers.work");
		this.otherNum = getBundle().getString("validPhoneNumbers.other");
		super.fillRandomData(); 
	}
	
	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getEmail() {
		return email;
	}

	public String getMobileNum() {
		return mobileNum;
	}

	public String getHomeNum() {
		return homeNum;
	}

	public String getWorkNum() {
		return workNum;
	}

	public String getOtherNum() {
		return otherNum;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	public void setHomeNum(String homeNum) {
		this.homeNum = homeNum;
	}

	public void setWorkNum(String workNum) {
		this.workNum = workNum;
	}

	public void setOtherNum(String otherNum) {
		this.otherNum = otherNum;
	}
}
