package com.automation.web.commonutils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.remote.DriverCommand;
import org.openqa.selenium.remote.RemoteExecuteMethod;
import org.openqa.selenium.support.ui.Select;


import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class PerfectoUtils implements JavascriptExecutor {

	public static QAFExtendedWebDriver getDriver() {
		return new WebDriverTestBase().getDriver();
	}

	public static void scrolltoelement(QAFWebElement qafelement) {

		/*
		 * try { JavascriptExecutor js = (JavascriptExecutor)
		 * PerfectoUtils.getDriver();
		 * js.executeScript("arguments[0].scrollIntoView(true);", qafelement);
		 * 
		 * } catch (Exception e) { Reporter.log(
		 * "Error occured while scrolling to the elemenet.", MessageTypes.Info);
		 * e.printStackTrace(); }
		 */

		// Suggested Method 3
		/*
		 * switchToContext(getDriver(), "VISUAL");
		 * getDriver().findElement(By.linkText("Ship to Home"));
		 */

		// Suggested Method 2
		/*
		 * Actions clicker = new Actions(getDriver());
		 * clicker.sendKeys(Keys.PAGE_DOWN); try { Thread.sleep(1000); } catch
		 * (InterruptedException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */

		// Suggested method 1

		/*
		 * Locatable element = (Locatable) QAFelement; Point p =
		 * element.getCoordinates().getLocationOnScreen(); JavascriptExecutor js
		 * = (JavascriptExecutor) getDriver();
		 * js.executeScript("window.scrollTo(" + p.getX() + "," + (p.getY() +
		 * 150) + ");");
		 */

		/*
		 * WebElement element1 = (WebElement)element; Coordinates coordinate =
		 * ((Locatable)element1).getCoordinates(); coordinate.onPage();
		 * coordinate.inViewPort(); }
		 */
	}

	private static void switchToContext(QAFExtendedWebDriver driver, String context) {

		RemoteExecuteMethod executeMethod = new RemoteExecuteMethod(driver);
		Map<String, String> params = new HashMap<String, String>();
		params.put("name", context);
		executeMethod.execute(DriverCommand.SWITCH_TO_CONTEXT, params);

	}

	public static void verifyChildWindow() {
		String parentWindow = PerfectoUtils.getDriver().getWindowHandle();
		Set<String> allWindowHandles = PerfectoUtils.getDriver().getWindowHandles();
		int numberoftabs = allWindowHandles.size();
		System.out.println(numberoftabs);
		if (numberoftabs == 1) {
			Reporter.log("Child window is not present:", MessageTypes.Info);
		} else {
			for (String winHandle : allWindowHandles) {
				System.out.println(winHandle);
				PerfectoUtils.getDriver().switchTo().window(winHandle);
				Reporter.logWithScreenShot("Child window is opened:", MessageTypes.Info);
				// PerfectoUtils.getDriver().close();
				PerfectoUtils.getDriver().switchTo().window(parentWindow);
				// PerfectoUtils.getDriver().close();
				Reporter.logWithScreenShot("Parent window is opened:", MessageTypes.Info);
			}
		}
	}

	public static void mouseover(QAFWebElement moveToElement) {
		// Actions class
		// Actions act = new Actions(PerfectoUtils.getDriver());
		// WebElement element1 = (WebElement) moveToElement;
		// act.moveToElement(element1).build().perform();

		// Robot Class
		// Point point = moveToElement.getLocation();
		// int xAxis = point.getX();
		// int yAxis = point.getY();
		// Robot robot = new Robot();
		// robot.mouseMove(xAxis, yAxis);

		// Qmetry Approach
		// Locatable locatable = (Locatable) moveToElement;
		// Coordinates arg0 = locatable.getCoordinates();
		// System.out.println(arg0);
		// getDriver().getMouse().mouseMove(arg0);

		// Java Script
		try {
			String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
			JavascriptExecutor js = (JavascriptExecutor) getDriver();
			WebElement element = (WebElement) moveToElement;
			js.executeScript(mouseOverScript, element);
		} catch (Exception e) {
			Actions action = new Actions(PerfectoUtils.getDriver());
			action.moveToElement(moveToElement).build().perform();
		}

	}

	public static void mouseoverandclick(QAFWebElement moveAndClickElement) {
		// Actions class
		// Actions act = new Actions(PerfectoUtils.getDriver());
		//
		// WebElement element1 = (WebElement) moveAndClickElement;
		// act.moveToElement(element1).click().perform();
		// // act.click().perform();

		// Robot Class
		// Point point = moveAndClickElement.getLocation();
		// int xAxis = point.getX();
		// int yAxis = point.getY();
		//
		// Robot robot = new Robot();
		// robot.mouseMove(xAxis, yAxis);

		// Qmetry Approach
		// Locatable locatable = (Locatable) moveAndClickElement;
		// Coordinates arg0 = locatable.getCoordinates();
		// System.out.println(arg0);
		// getDriver().getMouse().mouseMove(arg0);
		// getDriver().getMouse().click(arg0);

		// Java Script
		String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		WebElement element = (WebElement) moveAndClickElement;
		js.executeScript(mouseOverScript, element);
		moveAndClickElement.click();

	}

	public static void mouseoverandclick(QAFWebElement moveElement, QAFWebElement clickElement) {
		// Actions class
		Actions act = new Actions(PerfectoUtils.getDriver());

		WebElement element1 = (WebElement) moveElement;
		WebElement element2 = (WebElement) clickElement;
		act.moveToElement(element1).click(element2).build().perform();

		// // Robot Class
		// Point point = moveElement.getLocation();
		// int xAxis = point.getX();
		// int yAxis = point.getY();
		//
		// robot.mouseMove(xAxis, yAxis);
		// robot.mousePress(InputEvent.getMaskForButton(2));
		// robot.mouseRelease(InputEvent.getMaskForButton(2));

		/*
		 * try { // Java Script String mouseOverScript =
		 * "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}"
		 * ; JavascriptExecutor js = (JavascriptExecutor) getDriver();
		 * WebElement element = (WebElement) moveElement;
		 * js.executeScript(mouseOverScript, element); clickElement.click(); }
		 * catch (Exception e) { // Qmetry Steps Locatable locatable =
		 * (Locatable) (WebElement) moveElement; Coordinates arg0 =
		 * locatable.getCoordinates(); getDriver().getMouse().mouseMove(arg0);
		 * Locatable locatable1 = (Locatable) (WebElement) clickElement;
		 * Coordinates arg1 = locatable1.getCoordinates();
		 * getDriver().getMouse().click(arg1); }
		 */

	}

	public static void verifypresentwithscroll(QAFWebElement element, String label) {

		try {

			if (element.isDisplayed()) {
				element.verifyPresent();
			} else {
				scrolltoelement(element);
				if (element.isDisplayed()) {
					element.verifyPresent();
				} else {
					Reporter.log(label + " not found.", MessageTypes.Fail);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log(label + " not found.", MessageTypes.Fail);
		}
	}

	public static synchronized void navigateToPage(QAFWebElement clickElement, QAFWebElement verifyElement,
			String strPageTitle) {

		// Clicking the element
		try {
			clickElement.waitForPresent(10000);
			clickElement.click();
		} catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Error occured while navigating to " + strPageTitle);
		}

		// Verify whether navigated to the next page
		verifyElement.waitForPresent(15000);
		if (verifyElement.isPresent()) {
			Reporter.log("Navigated to " + strPageTitle, MessageTypes.Pass);
		} else {
			Reporter.log("Not navigated to " + strPageTitle, MessageTypes.Fail);
		}
	}

	public static void waitForElement(QAFWebElement element, int waittime) {

		try {
			element.waitForPresent(waittime);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static String removeSpecialCharacters(String value) {

		StringBuilder myNumbers = new StringBuilder();
		for (int i = 0; i < value.length(); i++) {
			if (Character.isDigit(value.charAt(i))) {
				myNumbers.append(value.charAt(i));
			} else if (Character.isLetter(value.charAt(i))) {
				myNumbers.append(value.charAt(i));
			} else {
				System.out.println(value.charAt(i) + " not a digit or Character.");
			}
		}
		return myNumbers.toString();

	}

//	public static void ClickContinueOnCogException() {
//		ExcepHandleTestPage exceptionhandle = new ExcepHandleTestPage();
//
//		if (exceptionhandle.getExcepFrameBlockcnt().isPresent()) {
//
//			getDriver().switchTo().frame(exceptionhandle.getExcepFrameBlockcnt());
//			exceptionhandle.getExcepRdbBusiness().click();
//			exceptionhandle.getExcepBtnContinue().click();
//			Reporter.log("Clicked Exception on Cog Exception", MessageTypes.Info);
//		}
//	}

	public static String getIntCharacters(String value) {

		StringBuilder myNumbers = new StringBuilder();
		for (int i = 0; i < value.length(); i++) {
			if (Character.isDigit(value.charAt(i))) {
				myNumbers.append(value.charAt(i));
			}
		}
		return myNumbers.toString();

	}

	public static String getOnlyChars(String value) {

		StringBuilder myNumbers = new StringBuilder();
		for (int i = 0; i < value.length(); i++) {
			if (Character.isLetter(value.charAt(i))) {
				myNumbers.append(value.charAt(i));
			} else {
				System.out.println(value.charAt(i) + " not a digit or Character.");
			}
		}
		return myNumbers.toString();
	}

	public static void mousehover(WebElement moveElement) {
		// Java Script
		try {
			String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
			JavascriptExecutor js = (JavascriptExecutor) getDriver();
			WebElement element = (WebElement) moveElement;
			js.executeScript(mouseOverScript, element);
		} catch (Exception e) {
			Actions action = new Actions(PerfectoUtils.getDriver());
			action.moveToElement(moveElement).build().perform();
		}
	}

	public static void mousehoverusingActions(WebElement moveElement) {
		Actions action = new Actions(PerfectoUtils.getDriver());
		action.moveToElement(moveElement).build().perform();
	}

	public static void dropdownSelectByValue(WebElement element, String text) {
		Select dropdown = new Select(element);
		dropdown.selectByValue(text);
	}

	public static void dropdownSelectByIndex(WebElement element, int index) {
		Select dropdown = new Select(element);
		dropdown.selectByIndex(index);
	}

	public static void ClickContainsTEXTas(List<QAFWebElement> list, String text) {
		int n = list.size();
		for (int i = 0; i < n; i++) {

			System.out.println("########## List Name ########" + list.get(i).getText());
			if (list.get(i).getText().contains(text)) {
				list.get(i).click();
				break;
			}

		}

	}

	public static void sleep(int seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {

		}
	}

	@Override
	public Object executeScript(String script, Object... args) {
		JavascriptExecutor js = (JavascriptExecutor) PerfectoUtils.getDriver();
		js.executeScript(script, args);
		return null;
	}

	@Override
	public Object executeAsyncScript(String script, Object... args) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void scrollToBottom() {
		Actions action = new Actions(getDriver());
		action.sendKeys(Keys.PAGE_DOWN);
	}

	public static void setMockLocation(String latitude, String longitude) {
		getDriver().executeScript(
				"window.navigator.geolocation.getCurrentPosition = function(success){var position = {'coords' : {'latitude': '"
						+ latitude + "','longitude': '" + longitude + "'}};success(position);}");
	}

}
