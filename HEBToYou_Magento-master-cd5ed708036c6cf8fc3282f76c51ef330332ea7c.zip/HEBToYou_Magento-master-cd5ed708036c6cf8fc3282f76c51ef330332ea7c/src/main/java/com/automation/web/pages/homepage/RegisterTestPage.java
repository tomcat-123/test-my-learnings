package com.automation.web.pages.homepage;

import java.util.List;
import static com.automation.web.commonutils.CommonUtils.MAX_WAIT_TIME;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RegisterTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}

	public synchronized void loadPage(){
		registerPageLoadItem.waitForPresent(MAX_WAIT_TIME);
		super.waitForPageToLoad();
	}

	@FindBy(locator = "register.pageLoadItem")
	private QAFWebElement registerPageLoadItem;

	@FindBy(locator = "register.edt.password")
	private QAFWebElement registerEdtPassword;

	@FindBy(locator = "register.edt.reenterpwd")
	private QAFWebElement registerEdtReenterpwd;

	@FindBy(locator = "register.edt.email")
	private QAFWebElement registerEdtEmail;

	@FindBy(locator = "register.edt.mobileNum")
	private QAFWebElement registerEdtMobileNum;

	@FindBy(locator = "register.chk.promotions")
	private QAFWebElement registerChkPromotions;

	@FindBy(locator = "register.btn.createNewAcc")
	private QAFWebElement registerBtnCreateNewAcc;

	@FindBy(locator = "register.tab.newUsrTab")
	private QAFWebElement registerTabNewUsrTab;

	@FindBy(locator = "register.lbl.regiFailed")
	private QAFWebElement registerLblRegiFailed;

	@FindBy(locator = "register.edt.ciFirstName")
	private QAFWebElement registerEdtCiFirstName;

	@FindBy(locator = "register.edt.ciLastName")
	private QAFWebElement registerEdtCiLastName;

	@FindBy(locator = "register.edt.ciEmail")
	private QAFWebElement registerEdtCiEmail;

	@FindBy(locator = "register.edt.SMSMobile")
	private QAFWebElement registerEdtSMSMobile;

	@FindBy(locator = "register.edt.SMSHome")
	private QAFWebElement registerEdtSMSHome;

	@FindBy(locator = "register.edt.SMSWork")
	private QAFWebElement registerEdtSMSWork;

	@FindBy(locator = "register.edt.SMSOther")
	private QAFWebElement registerEdtSMSOther;

	@FindBy(locator = "register.edt.Birthday")
	private QAFWebElement registerEdtBirthday;

	@FindBy(locator = "register.btn.genderM")
	private QAFWebElement registerBtnGenderM;

	@FindBy(locator = "register.btn.genderF")
	private QAFWebElement registerBtnGenderF;

	@FindBy(locator = "register.edt.daFirstName")
	private QAFWebElement registerEdtDaFirstName;

	@FindBy(locator = "register.edt.daLastName")
	private QAFWebElement registerEdtDaLastName;

	@FindBy(locator = "register.edt.daStreetOne")
	private QAFWebElement registerEdtDaStreetOne;

	@FindBy(locator = "register.edt.daStreetTwo")
	private QAFWebElement registerEdtDaStreetTwo;

	@FindBy(locator = "register.edt.daCity")
	private QAFWebElement registerEdtDaCity;

	@FindBy(locator = "register.dd.daStateSelect")
	private QAFWebElement registerDdDaStateSelect;

	@FindBy(locator = "register.get.stateSelect")
	private QAFWebElement registerGetStateSelect;

	@FindBy(locator = "register.edt.daZip")
	private QAFWebElement registerEdtDaZip;

	@FindBy(locator = "register.edt.daInstructions")
	private QAFWebElement registerEdtDaInstructions;

	@FindBy(locator = "register.btn.SaveChanges")
	private QAFWebElement registerBtnSaveChanges;

	@FindBy(locator = "register.lbl.profileSaved")
	private QAFWebElement registerLblProfileSaved;
	
	@FindBy(locator = "register.lnk.myaccount")
	private QAFWebElement registerlnkmyaccount;

	@FindBy(locator = "register.lnk.myprofile")
	private QAFWebElement registerlnkmyprofile;
	
	/**
	 * My Profile Link from Account Tab
	 */
	public QAFWebElement getRegisterLnkMyProfile(){ return registerlnkmyprofile; }
	
	/**
	 * My Account Link from Registration Tab
	 */
	public QAFWebElement getRegisterLnkMyAccount(){ return registerlnkmyaccount; }
	
	/**
	 * Load item for registration page
	 */
	public QAFWebElement getRegisterPageLoadItem(){ return registerPageLoadItem; }

	/**
	 * Enter new password
	 */
	public QAFWebElement getRegisterEdtPassword(){ return registerEdtPassword; }

	/**
	 * Confirm Password
	 */
	public QAFWebElement getRegisterEdtReenterpwd(){ return registerEdtReenterpwd; }

	/**
	 * Edit user email
	 */
	public QAFWebElement getRegisterEdtEmail(){ return registerEdtEmail; }

	/**
	 * Edit user phone number
	 */
	public QAFWebElement getRegisterEdtMobileNum(){ return registerEdtMobileNum; }

	/**
	 * Opt in or out of promos
	 */
	public QAFWebElement getRegisterChkPromotions(){ return registerChkPromotions; }

	/**
	 * Confirmation button for creating new account
	 */
	public QAFWebElement getRegisterBtnCreateNewAcc(){ return registerBtnCreateNewAcc; }

	/**
	 * Tab to enter new user creation
	 */
	public QAFWebElement getRegisterTabNewUsrTab(){ return registerTabNewUsrTab; }

	/**
	 * Passwords not matching error code
	 */
	public QAFWebElement getRegisterLblRegiFailed(){ return registerLblRegiFailed; }

	/**
	 * Contact Information First Name
	 */
	public QAFWebElement getRegisterEdtCiFirstName(){ return registerEdtCiFirstName; }

	/**
	 * Contact Information Last Name
	 */
	public QAFWebElement getRegisterEdtCiLastName(){ return registerEdtCiLastName; }

	/**
	 * Contact Information listed email
	 */
	public QAFWebElement getRegisterEdtCiEmail(){ return registerEdtCiEmail; }

	/**
	 * Mobile number info edit
	 */
	public QAFWebElement getRegisterEdtSMSMobile(){ return registerEdtSMSMobile; }

	/**
	 * Home number info edit
	 */
	public QAFWebElement getRegisterEdtSMSHome(){ return registerEdtSMSHome; }

	/**
	 * Work number info edit
	 */
	public QAFWebElement getRegisterEdtSMSWork(){ return registerEdtSMSWork; }

	/**
	 * Other number info edit
	 */
	public QAFWebElement getRegisterEdtSMSOther(){ return registerEdtSMSOther; }

	/**
	 * Birthday in MM/DD/YYYY format
	 */
	public QAFWebElement getRegisterEdtBirthday(){ return registerEdtBirthday; }

	/**
	 * Male select button
	 */
	public QAFWebElement getRegisterBtnGenderM(){ return registerBtnGenderM; }

	/**
	 * Female select button
	 */
	public QAFWebElement getRegisterBtnGenderF(){ return registerBtnGenderF; }

	/**
	 * Delivery Address first name box
	 */
	public QAFWebElement getRegisterEdtDaFirstName(){ return registerEdtDaFirstName; }

	/**
	 * Delivery Address Last name box
	 */
	public QAFWebElement getRegisterEdtDaLastName(){ return registerEdtDaLastName; }

	/**
	 * Delivery Address Street box1
	 */
	public QAFWebElement getRegisterEdtDaStreetOne(){ return registerEdtDaStreetOne; }

	/**
	 * Delivery Address Street box2
	 */
	public QAFWebElement getRegisterEdtDaStreetTwo(){ return registerEdtDaStreetTwo; }

	/**
	 * Delivery Address city input
	 */
	public QAFWebElement getRegisterEdtDaCity(){ return registerEdtDaCity; }

	/**
	 * Drop Down box for state selection
	 */
	public QAFWebElement getRegisterDdDaStateSelect(){ return registerDdDaStateSelect; }

	/**
	 * State choices to choose from in drop down
	 */
	public QAFWebElement getRegisterGetStateSelect(String item){ 
		String retElm = String.format(pageProps.getString("register.get.stateSelect"), item);
	    return new QAFExtendedWebElement(retElm);
	}

	/**
	 * Delivery address zip input
	 */
	public QAFWebElement getRegisterEdtDaZip(){ return registerEdtDaZip; }

	/**
	 * Delivery Address special instructions box
	 */
	public QAFWebElement getRegisterEdtDaInstructions(){ return registerEdtDaInstructions; }

	/**
	 * Button to save changes to User Profile
	 */
	public QAFWebElement getRegisterBtnSaveChanges(){ return registerBtnSaveChanges; }

	/**
	 * Confirmation Box for registration changes
	 */
	public QAFWebElement getRegisterLblProfileSaved(){ return registerLblProfileSaved; }

}