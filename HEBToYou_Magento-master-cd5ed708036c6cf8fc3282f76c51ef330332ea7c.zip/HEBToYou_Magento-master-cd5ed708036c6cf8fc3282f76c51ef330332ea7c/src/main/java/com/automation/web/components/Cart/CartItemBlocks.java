package com.automation.web.components.Cart;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CartItemBlocks extends QAFWebComponent {

	public CartItemBlocks(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}

	@FindBy(locator = "cart.li.cartitemsblockprice")
	private QAFWebElement liCartitemsblockprice;

	@FindBy(locator = "cart.li.cartitemsblockqty")
	private QAFWebElement liCartitemsblockqty;

	@FindBy(locator = "cart.li.cartitemsblockitemtotal")
	private QAFWebElement liCartitemsblockitemtotal;

	public QAFWebElement getLiCartitemsblockprice() {
		return liCartitemsblockprice;
	}

	public QAFWebElement getLiCartitemsblockqty() {
		return liCartitemsblockqty;
	}

	public QAFWebElement getLiCartitemsblockitemtotal() {
		return liCartitemsblockitemtotal;
	}

}
