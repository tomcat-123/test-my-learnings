package com.automation.web.databean;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.qmetry.qaf.automation.data.BaseFormDataBean;
import com.qmetry.qaf.automation.ui.annotations.UiElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.RandomStringGenerator.RandomizerTypes;
import com.qmetry.qaf.automation.util.Randomizer;

import com.automation.web.commonutils.CommonUtils;
import com.automation.web.pages.homepage.RegisterTestPage;

/**
 * Class to generate a random user information at checkout. @UiElement will populate
 * at whatever location is given, so different location names are important. Sample invocation
 * of UiElement will look like:
 * <code>
 * <p>{@literal @}Randomizer(type = RandomizerTypes.{@literal <}Type Style>, length = {@literal <}string length>, suffix = {@literal <}String addendum>")</p>
 * <p>{@literal @}UiElement(fieldLoc = {@literal <}.loc variable>, order = {@literal <}order of execution>)</p>
 * <p>private String stringName;</p>
 * </code>
 * <p>Note: Can also randomize buttons on whether or not they need to be clicked. 
 * @author Garrett Griffin
 *
 */
public class EditDeliveryInformationBean extends BaseFormDataBean{
	private CommonUtils util = new CommonUtils();

	@UiElement(fieldLoc = "register.edt.daFirstName", order = 11)
	private String daFirstName;

	@UiElement(fieldLoc = "register.edt.daLastName", order = 12)
	private String daLastName;

	@UiElement(fieldLoc = "register.edt.daStreetOne", order = 13)
	private String daStreetOne;

	@UiElement(fieldLoc = "register.edt.daStreetOne", order = 14)
	private String daStreetTwo;
	
	@UiElement(fieldLoc = "register.edt.daCity")
	private String city;
	
	@UiElement(fieldLoc = "register.edt.daZip")
	private String zip;

	@UiElement(fieldLoc = "register.edt.daInstructions", order = 15)
	private String instructions;
	

	/**
	 * Fills in all data, creates a valid birthday, and generates a readable set of instructions
	 */
	@Override
	public void fillRandomData() { 
		super.fillRandomData();
		RegisterTestPage register = new RegisterTestPage();
		this.daFirstName = getBundle().getString("hotuser1.user.firstName");
		this.daLastName = getBundle().getString("hotuser1.user.lastName");
		util.selectBoxSelection(register.getRegisterDdDaStateSelect(), util.storedString("hotuser1.user.state"));
		this.city = getBundle().getString("hotuser1.user.city");
		this.zip = getBundle().getString("hotuser1.user.zip");
		
		this.instructions = "In my younger and more vulnerable years my father gave me some advice" +
				" that I've been turning over in my mind ever since.\n\n'Whenever you feel like "+
				"criticizing any one,' he told me, 'just remember that all the people in this"
				+ " world haven't had the advantages that you've had.'";
	}

	public String getDaFirstName() {
		return daFirstName;
	}

	public String getDaLastName() {
		return daLastName;
	}

	public String getDaStreetOne() {
		return daStreetOne;
	}

	public String getDaStreetTwo() {
		return daStreetTwo;
	}

	public String getCity() {
		return city;
	}

	public String getZip() {
		return zip;
	}

	public String getInstructions() {
		return instructions;
	}

	public void setDaFirstName(String daFirstName) {
		this.daFirstName = daFirstName;
	}

	public void setDaLastName(String daLastName) {
		this.daLastName = daLastName;
	}

	public void setDaStreetOne(String daStreetOne) {
		this.daStreetOne = daStreetOne;
	}

	public void setDaStreetTwo(String daStreetTwo) {
		this.daStreetTwo = daStreetTwo;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}
}
