package com.automation.web.pages.cartandcheckout;

import java.util.List;
//import static common.CommonUtils.MAX_WAIT_TIME;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class PayTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}

	@FindBy(locator = "pay.lbl.pickfeeinheadersec")
	private QAFWebElement chkOutLblPickfeeinheadersec ;

	@FindBy(locator = "pay.btn.placeOrder")
	private QAFWebElement ckconBtnPlaceOrder;
	
	@FindBy(locator = "pay.txt.paymentMethodBox")
	private QAFWebElement ckconTxtPaymentMethodBox;
	
	@FindBy(locator = "pay.btn.selectCC")
	private QAFWebElement cardSelBtnSelectCC;

	@FindBy(locator = "pay.hdr.billingAdr")
	private QAFWebElement cardSelHdrBillingAdr;

	@FindBy(locator = "pay.dd.cardType")
	private QAFWebElement cardSelDdCardType;

	@FindBy(locator = "pay.edt.cardNumber")
	private QAFWebElement cardSelEdtCardNumber;

	@FindBy(locator = "pay.edt.holderName")
	private QAFWebElement cardSelEdtHolderName;

	@FindBy(locator = "pay.edt.cvvNum")
	private QAFWebElement cardSelEdtCvvNum;

	@FindBy(locator = "pay.dd.expMon")
	private QAFWebElement cardSelDdExpMon;

	@FindBy(locator = "pay.dd.expYear")
	private QAFWebElement cardSelDdExpYear;

	@FindBy(locator = "pay.edt.zipcode")
	private QAFWebElement cardSelEdtZipcode;

	@FindBy(locator = "pay.edt.description")
	private QAFWebElement cardSelEdtDescription;

	@FindBy(locator = "pay.btn.addCard")
	private QAFWebElement cardSelBtnAddCard;

	@FindBy(locator = "pay.btn.addAnotherCard")
	private QAFWebElement cardSelBtnAddAnotherCard;

	@FindBy(locator = "pay.edt.billingAddress")
	private QAFWebElement cardSelEdtBillingAddress;

	@FindBy(locator = "pay.edt.billingCity")
	private QAFWebElement cardSelEdtBillingCity;

	@FindBy(locator = "pay.dd.stateSel")
	private QAFWebElement cardSelDdStateSel;

	@FindBy(locator = "pay.edt.billingZip")
	private QAFWebElement cardSelEdtBillingZip;

	@FindBy(locator = "pay.txt.mainCard")
	private List<QAFWebElement> cardSelTxtMainCard;

	@FindBy(locator = "pay.txt.cardFail")
	private QAFWebElement cardSelTxtCardFail;

	@FindBy(locator = "pay.box.errModal")
	private QAFWebElement cardSelBoxErrModal;
	
	@FindBy(locator = "pay.lnk.deletecredeitcard")
	private QAFWebElement lnkDeletecredeitcard;
	/**
	 * Button to select credit cards
	 */
	public QAFWebElement getCardSelBtnSelectCC(){ return cardSelBtnSelectCC; }

	/**
	 * Header for the billing address
	 */
	public QAFWebElement getCardSelHdrBillingAdr(){ return cardSelHdrBillingAdr; }

	/**
	 * Drop down for card selection
	 */
	public QAFWebElement getCardSelDdCardType(){ return cardSelDdCardType; }

	/**
	 * Input for card number
	 */
	public QAFWebElement getCardSelEdtCardNumber(){ return cardSelEdtCardNumber; }

	/**
	 * Input for card holder name
	 */
	public QAFWebElement getCardSelEdtHolderName(){ return cardSelEdtHolderName; }

	/**
	 * Input for CVV Code
	 */
	public QAFWebElement getCardSelEdtCvvNum(){ return cardSelEdtCvvNum; }

	/**
	 * Drop down for card expiration month
	 */
	public QAFWebElement getCardSelDdExpMon(){ return cardSelDdExpMon; }

	/**
	 * Drop down for card expiration year
	 */
	public QAFWebElement getCardSelDdExpYear(){ return cardSelDdExpYear; }

	/**
	 * Input for zip code
	 */
	public QAFWebElement getCardSelEdtZipcode(){ return cardSelEdtZipcode; }

	/**
	 * Input for card description
	 */
	public QAFWebElement getCardSelEdtDescription(){ return cardSelEdtDescription; }

	/**
	 * Button to add card
	 */
	public QAFWebElement getCardSelBtnAddCard(){ return cardSelBtnAddCard; }

	/**
	 * Add another card
	 */
	public QAFWebElement getCardSelBtnAddAnotherCard(){ return cardSelBtnAddAnotherCard; }

	/**
	 * Edit for billing address
	 */
	public QAFWebElement getCardSelEdtBillingAddress(){ return cardSelEdtBillingAddress; }

	/**
	 * Edit for city
	 */
	public QAFWebElement getCardSelEdtBillingCity(){ return cardSelEdtBillingCity; }

	/**
	 * Different state options
	 */
	public QAFWebElement getCardSelDdStateSel(){ return cardSelDdStateSel; }

	/**
	 * Billing zipcode
	 */
	public QAFWebElement getCardSelEdtBillingZip(){ return cardSelEdtBillingZip; }

	/**
	 * Main card selected
	 */
	public List<QAFWebElement> getCardSelTxtMainCard(){ return cardSelTxtMainCard; }

	/**
	 * Failure text for adding card
	 */
	public QAFWebElement getCardSelTxtCardFail(){ return cardSelTxtCardFail; }

	/**
	 * Error modal for incorrect billing
	 */
	public QAFWebElement getCardSelBoxErrModal(){ return cardSelBoxErrModal; }
	
	/**
	 * Payment method displays
	 */
	public QAFWebElement getCkconTxtPaymentMethodBox(){ return ckconTxtPaymentMethodBox; }
	
	/**
	 * Place order button
	 */
	public QAFWebElement getCkconBtnPlaceOrder(){ return ckconBtnPlaceOrder; }

	public QAFWebElement getChkOutLblPickfeeinheadersec() {
		return chkOutLblPickfeeinheadersec;
	}
	public QAFWebElement getLnkDeletecredeitcard() {
		return lnkDeletecredeitcard;
	}
}