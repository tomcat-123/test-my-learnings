package com.automation.web.components.coupons;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class YellowCouponsItemBlock extends QAFWebComponent {

	public YellowCouponsItemBlock(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}

	@FindBy(locator = "yellowcoupon.img.couponitemimage")
	private QAFWebElement imgCouponItemImage;
	
	@FindBy(locator = "yellowcoupon.lbl.couponitemtitle=")
	private QAFWebElement lblCouponItemTitle;
	
	@FindBy(locator = "yellowcoupon.lbl.couponitemexprydt")
	private QAFWebElement lblCouponItemExprydt;
	
	@FindBy(locator = "yellowcoupon.btn.couponclipped")
	private QAFWebElement btnCouponClipped;
	
	@FindBy(locator = "yellowcoupon.btn.couponunclipped")
	private QAFWebElement btnCouponUnClipped;
	
	public QAFWebElement getImgCouponItemImage() {
		return imgCouponItemImage;
	}

	public QAFWebElement getLblCouponItemTitle() {
		return lblCouponItemTitle;
	}

	public QAFWebElement getLblCouponItemExprydt() {
		return lblCouponItemExprydt;
	}

	public QAFWebElement getBtnCouponClipped() {
		return btnCouponClipped;
	}

	public QAFWebElement getBtnCouponUnClipped() {
		return btnCouponUnClipped;
	}
	

}
